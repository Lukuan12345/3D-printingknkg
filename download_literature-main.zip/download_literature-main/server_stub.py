#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
server_stub.py —— KB / KG HTTP 服务 FastAPI Stub

封装人员在此基础上填充实现。
数据文件路径通过环境变量配置（见 Settings）。

启动:
    pip install fastapi uvicorn
    uvicorn server_stub:app --host 0.0.0.0 --port 8000 --workers 1

    # 后台运行
    nohup uvicorn server_stub:app --host 0.0.0.0 --port 8000 > server.log 2>&1 &
"""

import os
import sys
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np
from fastapi import FastAPI, HTTPException, Header
from pydantic import BaseModel

# ============================================================
# 配置（通过环境变量覆盖）
# ============================================================

class Settings:
    # KB
    KB_INDEX_DIR: str    = os.getenv("KB_INDEX_DIR",    "kb_mvp/index")
    KB_EMBED_URL: str    = os.getenv("KB_EMBED_URL",    "http://35.220.164.252:3888")
    KB_EMBED_KEY: str    = os.getenv("KB_EMBED_KEY",    "")

    # KG
    KG_DB_PATH: str      = os.getenv("KG_DB_PATH",      "scientific_kgqa/artifacts/kgqa.db")
    KG_PKL_PATH: str     = os.getenv("KG_PKL_PATH",     "scientific_kgqa/artifacts/retriever.pkl")
    KG_LLM_BASE_URL: str = os.getenv("KG_LLM_BASE_URL", "https://api-zjlab.sohoyo.io")
    KG_LLM_API_KEY: str  = os.getenv("KG_LLM_API_KEY",  "")
    KG_LLM_MODEL: str    = os.getenv("KG_LLM_MODEL",    "claude-haiku-4-5-20251001")

    # Auth
    API_KEY: str         = os.getenv("SERVER_API_KEY",  "")   # 空 = 不校验

cfg = Settings()

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
logger = logging.getLogger("kb_kg_server")

app = FastAPI(title="KB/KG Search Service", version="1.0.0")


# ============================================================
# 懒加载单例
# ============================================================

_kb_searcher = None
_kg_engine   = None


def get_kb_searcher():
    global _kb_searcher
    if _kb_searcher is None:
        logger.info("Loading HybridSearcher ...")
        # ---- 封装人员填写 ----
        # 示例（路径按实际调整）:
        #   sys.path.insert(0, "/app/kb_mvp/src")
        #   from searcher import HybridSearcher
        #   _kb_searcher = HybridSearcher(index_dir=cfg.KB_INDEX_DIR)
        # ---------------------
        raise NotImplementedError("请初始化 HybridSearcher")
    return _kb_searcher


def get_kg_engine():
    global _kg_engine
    if _kg_engine is None:
        logger.info("Loading QAEngine ...")
        # ---- 封装人员填写 ----
        # 示例:
        #   sys.path.insert(0, "/app/scientific_kgqa/src")
        #   from scientific_kgqa.storage import SQLiteStore
        #   from scientific_kgqa.retriever import Retriever
        #   from scientific_kgqa.llm_client import LLMClient
        #   from scientific_kgqa.qa_engine import QAEngine
        #   store     = SQLiteStore(cfg.KG_DB_PATH)
        #   retriever = Retriever.lazy_load(cfg.KG_PKL_PATH)
        #   llm       = LLMClient(api_key=cfg.KG_LLM_API_KEY,
        #                         base_url=cfg.KG_LLM_BASE_URL,
        #                         model=cfg.KG_LLM_MODEL)
        #   _kg_engine = QAEngine(store, retriever, llm_client=llm)
        # ---------------------
        raise NotImplementedError("请初始化 QAEngine")
    return _kg_engine


# ============================================================
# Auth 中间件（可选）
# ============================================================

def _check_auth(x_api_key: Optional[str]):
    if cfg.API_KEY and x_api_key != cfg.API_KEY:
        raise HTTPException(status_code=401, detail="Unauthorized")


# ============================================================
# 请求 / 响应模型
# ============================================================

class KBSearchRequest(BaseModel):
    query: str
    query_json: Optional[Dict[str, Any]] = None
    filters: Optional[Dict[str, Any]] = None
    top_k: int = 10
    top_k_each: int = 20


class KBEmbedRequest(BaseModel):
    texts: List[str]
    normalize: bool = True


class KBChunksForPapersRequest(BaseModel):
    paper_ids: List[str]
    top_n_per_paper: int = 5


class KBChunkEmbeddingsRequest(BaseModel):
    indices: List[int]


class KGAnswerRequest(BaseModel):
    query: str
    task_type: Optional[str] = None


# ============================================================
# KB 接口
# ============================================================

@app.post("/kb/search")
def kb_search(req: KBSearchRequest, x_api_key: Optional[str] = Header(None)):
    _check_auth(x_api_key)
    searcher = get_kb_searcher()
    try:
        result = searcher.search(
            query=req.query,
            query_json=req.query_json,
            filters=req.filters,
            top_k=req.top_k,
            top_k_each=req.top_k_each,
        )
        return {
            "chunks": result.get("top_k", []),
            "stats":  result.get("stats", {}),
        }
    except Exception as e:
        logger.exception("kb_search error")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/kb/embed")
def kb_embed(req: KBEmbedRequest, x_api_key: Optional[str] = Header(None)):
    _check_auth(x_api_key)
    searcher = get_kb_searcher()
    try:
        # 封装人员：调用 searcher 的 embedding 客户端，或直接调用 35.220:3888
        embs = searcher.embed_texts(req.texts, normalize=req.normalize)
        if isinstance(embs, np.ndarray):
            embs = embs.tolist()
        return {"embeddings": embs, "dim": len(embs[0]) if embs else 0}
    except Exception as e:
        logger.exception("kb_embed error")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/kb/papers")
def kb_papers(x_api_key: Optional[str] = Header(None)):
    _check_auth(x_api_key)
    searcher = get_kb_searcher()
    try:
        papers = searcher.get_papers_titles()   # [(paper_id, title), ...]
        return {"papers": [{"paper_id": p, "title": t} for p, t in papers]}
    except Exception as e:
        logger.exception("kb_papers error")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/kb/chunks_for_papers")
def kb_chunks_for_papers(req: KBChunksForPapersRequest, x_api_key: Optional[str] = Header(None)):
    _check_auth(x_api_key)
    searcher = get_kb_searcher()
    try:
        chunks = searcher.fetch_chunks_for_papers(req.paper_ids, top_n=req.top_n_per_paper)
        return {"chunks": chunks}
    except Exception as e:
        logger.exception("kb_chunks_for_papers error")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/kb/chunk_embeddings")
def kb_chunk_embeddings(req: KBChunkEmbeddingsRequest, x_api_key: Optional[str] = Header(None)):
    _check_auth(x_api_key)
    searcher = get_kb_searcher()
    try:
        embs = searcher.get_chunk_embeddings_by_idx(req.indices)
        if isinstance(embs, np.ndarray):
            embs = embs.tolist()
        return {"embeddings": embs, "dim": len(embs[0]) if embs else 0}
    except Exception as e:
        logger.exception("kb_chunk_embeddings error")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================
# KG 接口
# ============================================================

@app.post("/kg/answer")
def kg_answer(req: KGAnswerRequest, x_api_key: Optional[str] = Header(None)):
    _check_auth(x_api_key)
    engine = get_kg_engine()
    try:
        result = engine.answer(
            query=req.query,
            task_type_override=req.task_type,
        )
        return {
            "reasoning_paths": result.get("reasoning_paths", []),
            "evidence":        result.get("evidence", []),
            "summary":         result.get("summary", ""),
            "confidence":      result.get("confidence", 0.0),
            "kg_intent":       result.get("kg_intent", ""),
            "timings":         result.get("timings", {}),
        }
    except Exception as e:
        logger.exception("kg_answer error")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================
# 健康检查
# ============================================================

@app.get("/health")
def health():
    return {
        "status": "ok",
        "kb_loaded": _kb_searcher is not None,
        "kg_loaded": _kg_engine is not None,
    }


@app.on_event("startup")
def _startup():
    logger.info("Server started. KB/KG will lazy-load on first request.")
    logger.info("KB_INDEX_DIR = %s", cfg.KB_INDEX_DIR)
    logger.info("KG_DB_PATH   = %s", cfg.KG_DB_PATH)
    logger.info("KG_PKL_PATH  = %s", cfg.KG_PKL_PATH)


if __name__ == "__main__":
    # 直接 `python server_stub.py` 启动（等价于 uvicorn server_stub:app）。
    # 可用环境变量覆盖监听地址：HOST / PORT（默认 0.0.0.0:8000）。
    import uvicorn

    host = os.environ.get("HOST", "0.0.0.0")
    port = int(os.environ.get("PORT", "8000"))
    logger.info("Launching uvicorn on %s:%d (server_stub:app)", host, port)
    uvicorn.run(app, host=host, port=port, workers=1)
