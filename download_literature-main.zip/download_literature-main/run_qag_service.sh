#!/usr/bin/env bash
set -euo pipefail

echo "[run_qag_service] starting..."

# 进入项目根目录：/mnt/shared-storage-user/suyulin/gen_key
cd "$(dirname "$0")"

# 服务端口：默认 8001；如果部署页面端口用 8000，可以在页面环境变量里覆盖 PORT=8000
export PORT="${PORT:-8001}"
export HOST="${HOST:-0.0.0.0}"

# 这些目录放容器本地，不放共享盘，避免用户库/上传文件暴露在 GPFS 上
export QAG_DATA_DIR="${QAG_DATA_DIR:-/tmp/qag_data}"
export QAG_WORKSPACE_ROOT="${QAG_WORKSPACE_ROOT:-/tmp/qag_workspaces}"

# 图谱权重目录，在 GPFS 上
export KGQA_ARTIFACTS_DIR="${KGQA_ARTIFACTS_DIR:-/mnt/shared-storage-user/suyulin/literature_knowledge_extractor_new/scientific_kgqa/artifacts}"

mkdir -p "$QAG_DATA_DIR" "$QAG_WORKSPACE_ROOT"

echo "[run_qag_service] project root       = $(pwd)"
echo "[run_qag_service] HOST               = $HOST"
echo "[run_qag_service] PORT               = $PORT"
echo "[run_qag_service] QAG_DATA_DIR       = $QAG_DATA_DIR"
echo "[run_qag_service] QAG_WORKSPACE_ROOT = $QAG_WORKSPACE_ROOT"
echo "[run_qag_service] KGQA_ARTIFACTS_DIR = $KGQA_ARTIFACTS_DIR"

# ── 出网代理(经开发机中转)────────────────────────────────────────────────────
# 部署容器网络隔离：既连不上公网 LLM 网关，也连不上集群代理 httpproxy-headless。
# 唯一通路 = 开发机(suyulin-dev, 内网 100.101.135.177)上跑的 pproxy:8080，
# 它再经集群代理出公网。出题/图谱测评子进程要访问公网 LLM(43.153.x / api-zjlab)，
# 故全局走此中转。Flask 在此 export，subprocess 子进程自动继承。
# no_proxy 含平台内网(.pjlab.org.cn / 10.x / 100.96.x / 回环)，内部服务直连不受影响。
# 开发机 IP 变动时，用部署环境变量 QAG_EGRESS_PROXY 覆盖即可，无需改本脚本。
EGRESS_PROXY="${QAG_EGRESS_PROXY:-http://100.101.135.177:8080}"
export http_proxy="$EGRESS_PROXY"
export https_proxy="$EGRESS_PROXY"
export no_proxy="${no_proxy:-10.0.0.0/8,100.96.0.0/12,.pjlab.org.cn,localhost,127.0.0.1}"
export HTTP_PROXY="$http_proxy" HTTPS_PROXY="$https_proxy" NO_PROXY="$no_proxy"
# Embedding 客户端默认跳过系统代理；这里让它也走出网代理，否则连不上公网 embedding 端点。
export EMBED_TRUST_ENV="${EMBED_TRUST_ENV:-1}"
# 图谱测评 embedding 重试收敛快些：端点不可达时最多 ~20s 内失败回退，而非空等十几分钟。
export EMBED_MAX_RETRIES="${EMBED_MAX_RETRIES:-3}"
export EMBED_RETRY_DELAY="${EMBED_RETRY_DELAY:-3}"
# 图谱测评逐题并发线程数（LLM/embedding 都是 I/O 密集，多线程显著提速）。
export KG_EVAL_WORKERS="${KG_EVAL_WORKERS:-4}"
echo "[run_qag_service] egress proxy = $http_proxy (经开发机中转出公网)"
echo "[run_qag_service] no_proxy     = $no_proxy"

echo "[run_qag_service] bootstrap setup..."
bash kg_eval/scripts/bootstrap_deploy.sh

echo "[run_qag_service] launching web service..."

# 注意：这里必须 exec 前台启动，不能 nohup，不能 --start
exec .venv/bin/python kg_eval/qag/qag_ui_server.py --host "$HOST" --port "$PORT"
