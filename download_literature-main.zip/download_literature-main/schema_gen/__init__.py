"""schema_gen — 基于领域偏好和研究问题自动生成提取 Schema 的最小 MVP。

包入口暴露了 :func:`run` 高层函数和配置/领域偏好相关数据类，方便外部调用。
"""

from .core import (
    DomainPrefer,
    LLMConfig,
    PipelineConfig,
    SchemaGenConfig,
    apply_cli_overrides,
    build_domain_instruction,
    load_config,
    parse_domain_prefer,
    run,
)

__all__ = [
    "DomainPrefer",
    "LLMConfig",
    "PipelineConfig",
    "SchemaGenConfig",
    "apply_cli_overrides",
    "build_domain_instruction",
    "load_config",
    "parse_domain_prefer",
    "run",
]
