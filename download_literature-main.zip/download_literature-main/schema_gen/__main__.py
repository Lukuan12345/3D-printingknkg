"""命令行入口：``python -m schema_gen --config configs/example.yaml``。

所有运行参数都从 YAML 读，命令行只接受少量 **覆盖项**：

- ``--config / -c <path>``        必填，YAML 配置文件路径。
- ``--schema-models <models>``    覆盖 ``llm.schema_model``（+ 可选架构师模型）。
  逗号分隔，**第一个是主 schema 模型**，其余为架构师模型，例如：
  ``--schema-models gpt-5.4-pro,claude-4-sonnet,gemini-2.5-pro``。
  写成 ``model:endpoint`` 可单独指定模型的 endpoint（chat / responses）。
- ``--output-dir <path>``         覆盖输出目录。
- ``--csv-filename <name>``       覆盖最终 CSV 文件名。
- ``--domain-prefer-file <path>`` 覆盖领域偏好文件路径。
- ``-v / --verbose``              打开 DEBUG 日志。
"""

from __future__ import annotations

import argparse
import logging
import sys

from .core import apply_cli_overrides, load_config, run


def _build_argparser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="python -m schema_gen",
        description="基于 domain_prefer/<project>.txt 和 YAML 配置生成提取 Schema。",
    )
    p.add_argument("-c", "--config", required=True, help="YAML 配置文件路径")
    p.add_argument(
        "--schema-models",
        help=(
            "逗号分隔的模型列表，第一个覆盖 llm.schema_model，其余覆盖架构师模型。"
            "支持 model 或 model:endpoint 写法。例如 gpt-5.4-pro 或 "
            "claude-4-sonnet:chat,gpt-5.4-pro:responses。"
        ),
    )
    p.add_argument("--output-dir", help="覆盖配置中的 output_dir")
    p.add_argument("--csv-filename", help="覆盖最终 CSV 文件名")
    p.add_argument("--domain-prefer-file", help="覆盖 domain_prefer 文件路径")
    p.add_argument("-v", "--verbose", action="store_true", help="打开 DEBUG 日志")
    return p


def main(argv: list[str] | None = None) -> int:
    args = _build_argparser().parse_args(argv)

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )

    # 自动加载 gen_key 根目录的 .env（与仓库其余模块一致），让 ${LLM_BASE_URL} 等占位符可展开
    try:
        from env_bootstrap import load_env
        load_env()
    except Exception:  # noqa: BLE001
        pass

    cfg = load_config(args.config)
    overrides = {
        "schema_models": args.schema_models,
        "output_dir": args.output_dir,
        "csv_filename": args.csv_filename,
        "domain_prefer_file": args.domain_prefer_file,
    }
    cfg = apply_cli_overrides(cfg, {k: v for k, v in overrides.items() if v})

    try:
        csv_path = run(cfg)
    except Exception as exc:  # noqa: BLE001
        logging.error("schema 生成失败: %s", exc, exc_info=args.verbose)
        return 1

    print(csv_path)
    return 0


if __name__ == "__main__":
    sys.exit(main())
