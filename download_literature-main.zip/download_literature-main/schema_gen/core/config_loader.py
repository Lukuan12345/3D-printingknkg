"""schema_gen 的 YAML 配置文件加载器。

设计原则：所有运行参数都从 YAML 来，命令行只作覆盖。``${ENV_VAR}`` 占位符会
从环境变量展开（找不到就保留原样）。如果 YAML 路径用相对路径写，会基于
配置文件所在目录解析成绝对路径。
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional


_ENV_PATTERN = re.compile(r"\$\{([A-Z0-9_]+)\}")


def _expand_env(value: Any) -> Any:
    """递归展开字符串里的 ${VAR} 占位符。"""
    if isinstance(value, str):
        def _sub(m: re.Match) -> str:
            return os.environ.get(m.group(1), m.group(0))
        return _ENV_PATTERN.sub(_sub, value)
    if isinstance(value, dict):
        return {k: _expand_env(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_expand_env(v) for v in value]
    return value


def _abs_path(base: Path, p: Optional[str]) -> Optional[str]:
    if not p:
        return None
    pp = Path(p)
    return str(pp if pp.is_absolute() else (base / pp).resolve())


@dataclass
class LLMConfig:
    api_key: str = ""
    base_url: str = ""
    schema_model: str = "gemini-2.5-pro"
    architect_models: List[str] = field(default_factory=list)
    endpoint: str = "chat"
    temperature: float = 0.2
    max_retries: int = 5
    retry_delay: int = 10


@dataclass
class PipelineConfig:
    num_architects: int = 3
    enable_clustering: bool = True
    resume: bool = True


@dataclass
class SchemaGenConfig:
    project_name: str
    domain_prefer_file: str
    output_dir: str
    csv_filename: str = "final_schema.csv"
    usage_scope: str = ""
    llm: LLMConfig = field(default_factory=LLMConfig)
    pipeline: PipelineConfig = field(default_factory=PipelineConfig)


def load_config(path: str | Path) -> SchemaGenConfig:
    """加载 YAML 配置文件并解析为 SchemaGenConfig。

    依赖 PyYAML（``pip install pyyaml``）。
    """
    try:
        import yaml  # noqa: WPS433
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError(
            "schema_gen 需要 PyYAML 解析配置文件，请运行 `pip install pyyaml`。"
        ) from exc

    cfg_path = Path(path).resolve()
    if not cfg_path.exists():
        raise FileNotFoundError(f"配置文件不存在: {cfg_path}")
    raw = yaml.safe_load(cfg_path.read_text(encoding="utf-8")) or {}
    raw = _expand_env(raw)

    base_dir = cfg_path.parent
    project_name = raw.get("project_name") or cfg_path.stem
    domain_prefer_file = _abs_path(base_dir, raw.get("domain_prefer_file"))
    if not domain_prefer_file:
        raise ValueError("配置缺少必填项 domain_prefer_file")
    output_dir = _abs_path(base_dir, raw.get("output_dir") or f"./schema_output/{project_name}")
    csv_filename = raw.get("csv_filename") or f"refined_schema_{project_name}.csv"

    llm_raw = raw.get("llm") or {}
    arch_models = llm_raw.get("architect_models") or []
    if isinstance(arch_models, str):
        arch_models = [m.strip() for m in arch_models.split(",") if m.strip()]
    llm = LLMConfig(
        api_key=llm_raw.get("api_key", "") or os.environ.get("LLM_API_KEY", ""),
        base_url=llm_raw.get("base_url", "") or os.environ.get("LLM_BASE_URL", ""),
        schema_model=llm_raw.get("schema_model") or llm_raw.get("model") or "gemini-2.5-pro",
        architect_models=list(arch_models),
        endpoint=llm_raw.get("endpoint", "chat"),
        temperature=float(llm_raw.get("temperature", 0.2)),
        max_retries=int(llm_raw.get("max_retries", 5)),
        retry_delay=int(llm_raw.get("retry_delay", 10)),
    )

    pipe_raw = raw.get("pipeline") or {}
    pipeline = PipelineConfig(
        num_architects=int(pipe_raw.get("num_architects", PipelineConfig.num_architects)),
        enable_clustering=bool(pipe_raw.get("enable_clustering", True)),
        resume=bool(pipe_raw.get("resume", True)),
    )

    return SchemaGenConfig(
        project_name=project_name,
        domain_prefer_file=domain_prefer_file,
        output_dir=output_dir,
        csv_filename=csv_filename,
        usage_scope=raw.get("usage_scope", ""),
        llm=llm,
        pipeline=pipeline,
    )


def apply_cli_overrides(cfg: SchemaGenConfig, overrides: Dict[str, Any]) -> SchemaGenConfig:
    """把命令行覆盖值合并进 cfg（原地修改）。

    支持的 key：
      - ``schema_models``: 逗号分隔字符串。第一个元素覆盖
        ``cfg.llm.schema_model``；其余元素覆盖 ``cfg.llm.architect_models``
        （留空则继承单一 schema_model 给所有架构师）。
        每个元素可写成 ``model`` 或 ``model:endpoint``；主模型的 ``:endpoint``
        会同步覆盖 ``cfg.llm.endpoint``（架构师的 endpoint 由 generator 解析）。
      - ``output_dir``、``csv_filename``、``domain_prefer_file``：直接覆盖。
    """
    if overrides.get("schema_models"):
        models = [m.strip() for m in overrides["schema_models"].split(",") if m.strip()]
        if models:
            # 主模型：拆 model:endpoint
            head = models[0]
            if ":" in head:
                m, ep = head.split(":", 1)
                cfg.llm.schema_model = m.strip()
                if ep.strip():
                    cfg.llm.endpoint = ep.strip()
            else:
                cfg.llm.schema_model = head
            cfg.llm.architect_models = models[1:]  # 架构师由 generator 二次解析
    for key in ("output_dir", "csv_filename", "domain_prefer_file"):
        v = overrides.get(key)
        if v:
            setattr(cfg, key, v)
    return cfg
