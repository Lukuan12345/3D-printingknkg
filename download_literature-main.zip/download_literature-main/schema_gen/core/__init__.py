"""核心模块：配置加载、领域偏好解析、SchemaGenerator 包装。"""

from .config_loader import (
    LLMConfig,
    PipelineConfig,
    SchemaGenConfig,
    apply_cli_overrides,
    load_config,
)
from .domain_prefer import (
    DomainPrefer,
    build_domain_instruction,
    parse_domain_prefer,
)
from .generator import run

__all__ = [
    "LLMConfig",
    "PipelineConfig",
    "SchemaGenConfig",
    "apply_cli_overrides",
    "load_config",
    "DomainPrefer",
    "build_domain_instruction",
    "parse_domain_prefer",
    "run",
]
