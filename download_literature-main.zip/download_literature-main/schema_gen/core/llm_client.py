#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LLM 客户端模块 —— 封装与大语言模型 API 的所有交互逻辑。

本模块提供两层抽象：
  1. call_llm()          —— 底层通用函数，负责构建 OpenAI-compatible 的 HTTP 请求、
                            自动重试、超时控制等，返回纯文本字符串。
  2. call_llm_json()     —— 在 call_llm() 基础上，自动从 LLM 返回的文本中提取
                            并解析 JSON（支持 ```json ``` 代码块、裸 JSON 等多种格式）。

典型用法::

    from literature_knowledge_extractor.llm_client import call_llm, call_llm_json

    # 纯文本调用
    text = call_llm(
        prompt="请介绍一下催化反应",
        base_url="http://your-api-server/v1",
        api_key="sk-xxx",
        model_name="gemini-2.5-pro",
    )

    # JSON 调用（自动解析）
    data = call_llm_json(
        prompt="请以 JSON 格式输出反应温度列表",
        base_url="http://your-api-server/v1",
        api_key="sk-xxx",
        model_name="gemini-2.5-pro",
    )
"""

import re
import json
import time
import logging
from typing import Any, Optional

import requests

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# 底层 LLM 调用函数
# ---------------------------------------------------------------------------

def call_llm(
    prompt: str,
    base_url: str,
    api_key: str,
    model_name: str = "gemini-2.5-pro",
    system_prompt: Optional[str] = None,
    temperature: Optional[float] = None,
    thinking_mode: bool = True,
    response_format: Optional[dict] = None,
    endpoint: str = "chat",
    max_retries: int = 5,
    retry_delay: int = 10,
    timeout: int = 1800,
    max_tokens: Optional[int] = None,
) -> Optional[str]:
    """
    调用 LLM API 并返回纯文本响应。支持两种端点：

    - ``endpoint="chat"``      → ``/v1/chat/completions``（默认，兼容 OpenAI/Gemini/Claude）
    - ``endpoint="responses"`` → ``/v1/responses``（OpenAI Responses API，gpt-5.4-pro 等）

    内部实现了自动重试（针对服务器 5xx 和网络超时），最多重试 ``max_retries`` 次，
    每次间隔 ``retry_delay`` 秒。

    Args:
        prompt:         用户输入的文本提示（必填）。
        base_url:       API 服务的基础 URL，例如 ``http://host:port`` 或
                        ``http://host:port/v1``（末尾 ``/v1`` 会被自动处理）。
        api_key:        API 密钥。
        model_name:     要使用的模型名称，默认 ``"gemini-2.5-pro"``。
        system_prompt:  可选的系统提示词，用于定义 LLM 角色。
        temperature:    采样温度（0 ~ 2），越低越确定性，越高越多样。
        thinking_mode:  是否在 payload 中启用思考模式（部分模型支持）。
        response_format: 结构化输出格式约束，例如：
                        ``{"type": "json_object"}`` —— 保证输出合法 JSON
                        ``{"type": "json_schema", "json_schema": {...}}`` —— 严格 Schema 约束
                        默认 None（不启用）。
        max_retries:    最大重试次数。
        retry_delay:    每次重试之间的等待秒数。
        timeout:        单次 HTTP 请求的超时秒数。

    Returns:
        LLM 返回的文本字符串；若所有重试均失败，返回 ``None``。
    """
    # ---------- 拼接 URL ----------
    clean_base = base_url.rstrip("/")
    if clean_base.endswith("/v1"):
        clean_base = clean_base[:-3]

    use_responses = (endpoint == "responses")
    if use_responses:
        api_url = f"{clean_base}/v1/responses"
    else:
        api_url = f"{clean_base}/v1/chat/completions"

    # ---------- 构建请求头 ----------
    headers = {
        "Accept": "application/json",
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }

    # ---------- 构建 Payload ----------
    if use_responses:
        # OpenAI Responses API 格式（不支持 temperature 参数）
        payload: dict[str, Any] = {
            "model": model_name,
            "input": prompt,
        }
        if system_prompt:
            payload["instructions"] = system_prompt
        if response_format is not None:
            payload["text"] = {"format": response_format}
    else:
        # Chat Completions API 格式
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})

        payload = {
            "model": model_name,
            "messages": messages,
        }
        if thinking_mode and "thinking" in model_name.lower():
            payload["thinking_mode"] = True
        if temperature is not None:
            payload["temperature"] = temperature
        if response_format is not None:
            payload["response_format"] = response_format
        # 设置 max_tokens：默认 128K，为 thinking 模型留足空间
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens
        else:
            payload["max_tokens"] = 128000

    # ---------- 响应文本提取辅助 ----------
    def _extract_text(resp_json: dict) -> Optional[str]:
        if use_responses:
            # Responses API: output[].content[].text
            for item in resp_json.get("output", []):
                if item.get("type") == "message":
                    for c in item.get("content", []):
                        if c.get("type") == "output_text":
                            return c["text"]
            return None
        else:
            # Chat Completions: choices[0].message.content
            return resp_json["choices"][0]["message"]["content"]

    # ---------- 带重试的请求循环 ----------
    for attempt in range(1, max_retries + 1):
        try:
            resp = requests.post(api_url, headers=headers, json=payload, timeout=timeout)
            if resp.status_code == 200:
                resp_json = resp.json()
                # 检测输出截断（finish_reason == "length" 表示 token 耗尽）
                finish_reason = None
                if not use_responses:
                    choices = resp_json.get("choices", [])
                    if choices:
                        finish_reason = choices[0].get("finish_reason")
                if finish_reason == "length":
                    logger.warning(
                        "LLM 输出被截断（finish_reason=length），"
                        "模型: %s — 考虑增加 max_tokens 或简化 prompt",
                        model_name,
                    )
                return _extract_text(resp_json)
            elif resp.status_code == 400:
                body = resp.text
                logger.error("客户端错误 (400)，请求被拒绝。响应: %s", body)
                return None
            elif resp.status_code >= 500 or resp.status_code == 429:
                # 服务器错误 / 限速 → 通常可重试
                body = resp.text

                # 短路：某些 new-api / 多渠道网关会把"模型不存在 / 权限缺失"这类
                # **事实上不可恢复** 的配置错误包装成 503（说明"上游无可用渠道"）。
                # 对这类错误继续重试只会浪费 5 × retry_delay 秒，直接结束即可。
                fatal_codes = ("model_not_found", "invalid_api_key",
                               "insufficient_quota", "permission_denied")
                is_fatal = any(f'"code":"{c}"' in body or f"'code': '{c}'" in body
                               for c in fatal_codes)
                if is_fatal:
                    logger.error(
                        "网关返回不可恢复错误 (%d)，跳过重试。模型=%s  响应=%s",
                        resp.status_code, model_name, body,
                    )
                    return None

                if attempt < max_retries:
                    logger.warning(
                        "服务器错误 (%d)，%d 秒后重试 (%d/%d)。响应: %s",
                        resp.status_code, retry_delay, attempt, max_retries, body,
                    )
                    time.sleep(retry_delay)
                    continue
                else:
                    logger.error("服务器错误 (%d)，已达最大重试次数。响应: %s",
                                 resp.status_code, body)
                    return None
            else:
                # 4xx 等客户端错误 → 打印响应体后抛异常
                body = resp.text
                logger.error("客户端错误 (%d)。响应: %s", resp.status_code, body)
                resp.raise_for_status()

        except requests.exceptions.Timeout:
            if attempt < max_retries:
                logger.warning("请求超时，%d 秒后重试 (%d/%d)...", retry_delay, attempt, max_retries)
                time.sleep(retry_delay)
            else:
                logger.error("请求超时，已达最大重试次数")
                return None

        except requests.exceptions.RequestException as exc:
            if attempt < max_retries:
                logger.warning("API 请求异常: %s，%d 秒后重试 (%d/%d)...", exc, retry_delay, attempt, max_retries)
                time.sleep(retry_delay)
            else:
                logger.error("API 请求异常: %s", exc)
                return None

        except Exception as exc:  # noqa: BLE001
            logger.error("处理响应时发生未知错误: %s", exc)
            return None

    return None


# ---------------------------------------------------------------------------
# JSON 解析辅助
# ---------------------------------------------------------------------------

def _try_repair_truncated_json(text: str) -> Any:
    """
    尝试修复被截断的 JSON（因 max_tokens 限制输出不完整）。

    典型截断场景::

        ```json
        {"fields": [
            {"field_name": "a", ...},
            {"field_name": "b", ...},
            {"field_name": "c", "description": "some text that got cut

    修复策略：
      1. 提取 JSON 起始部分（从第一个 ``{`` 或 ``[`` 开始）
      2. 找到最后一个完整的数组元素（最后一个 ``},`` 或 ``}`` 后跟换行）
      3. 砍掉不完整的尾部，补全所有未闭合的括号

    Returns:
        修复后解析成功的 Python 对象，或 ``None``。
    """
    # 从代码块或全文中定位 JSON 起始
    # 找第一个 { 或 [
    json_start = -1
    for i, ch in enumerate(text):
        if ch in ('{', '['):
            json_start = i
            break
    if json_start == -1:
        return None

    json_text = text[json_start:]

    # 尝试直接解析（没截断的情况）
    try:
        return json.loads(json_text)
    except json.JSONDecodeError:
        pass

    # 统计未闭合的括号
    open_stack = []
    last_complete_pos = 0  # 最后一个可以安全截断的位置

    in_string = False
    escape_next = False

    for i, ch in enumerate(json_text):
        if escape_next:
            escape_next = False
            continue
        if ch == '\\' and in_string:
            escape_next = True
            continue
        if ch == '"' and not escape_next:
            in_string = not in_string
            continue
        if in_string:
            continue

        if ch in ('{', '['):
            open_stack.append(ch)
        elif ch == '}':
            if open_stack and open_stack[-1] == '{':
                open_stack.pop()
                # 如果栈深度 <= 2（外层对象 + fields 数组），
                # 这是一个完整的数组元素结束位置
                if len(open_stack) <= 2:
                    last_complete_pos = i + 1
        elif ch == ']':
            if open_stack and open_stack[-1] == '[':
                open_stack.pop()
                if len(open_stack) <= 1:
                    last_complete_pos = i + 1

    if last_complete_pos <= 1:
        return None

    # 截断到最后一个完整元素，去掉尾部逗号
    repaired = json_text[:last_complete_pos].rstrip().rstrip(',')

    # 重新计算需要补全的闭合括号
    open_stack_2 = []
    in_string = False
    escape_next = False
    for ch in repaired:
        if escape_next:
            escape_next = False
            continue
        if ch == '\\' and in_string:
            escape_next = True
            continue
        if ch == '"':
            in_string = not in_string
            continue
        if in_string:
            continue
        if ch in ('{', '['):
            open_stack_2.append(ch)
        elif ch == '}' and open_stack_2 and open_stack_2[-1] == '{':
            open_stack_2.pop()
        elif ch == ']' and open_stack_2 and open_stack_2[-1] == '[':
            open_stack_2.pop()

    # 补全闭合括号
    closing = ""
    for bracket in reversed(open_stack_2):
        closing += ']' if bracket == '[' else '}'

    repaired += closing

    try:
        result = json.loads(repaired)
        logger.info("截断 JSON 修复成功（保留至 %d 字符，补全 %d 个括号）",
                     last_complete_pos, len(closing))
        return result
    except json.JSONDecodeError:
        return None


def _extract_json_from_text(text: str) -> Any:
    """
    从 LLM 返回的文本中 **稳健地** 提取 JSON 对象或数组。

    解析策略（按优先级）：
      1. 直接 ``json.loads(text)`` —— 整段就是合法 JSON。
      2. 从 ````` ```json ... ``` ````` 代码块中提取（**从后往前**尝试，
         适配 thinking 模型：思考过程中可能含有代码块，真正结果在最后）。
      3. 找到**最后一个**完整 JSON 对象/数组（``{...}`` 或 ``[...]``），
         从后往前扫描，跳过思考过程中的碎片 JSON。

    Args:
        text: LLM 返回的原始文本。

    Returns:
        解析后的 Python 对象（dict / list），解析失败返回 ``None``。
    """
    if not text or not text.strip():
        return None

    text = text.strip()

    # 预处理：剥离 thinking 模型的思考标签（<think>...</think>、<thinking>...</thinking>）
    # 代理转发 Claude thinking 模型时，思考内容可能被包裹在这些标签中
    text = re.sub(r"<think(?:ing)?>\s*[\s\S]*?</think(?:ing)?>", "", text).strip()

    # 策略 1：直接解析（整段就是合法 JSON）
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    # 策略 2：从 markdown 代码块中提取（从后往前尝试所有匹配）
    # 大小写不敏感，兼容 ```json / ```JSON / 无语言标记的 ```
    matches = list(re.finditer(r"```(?:json|JSON)?\s*\n?([\s\S]*?)\n?\s*```", text))
    for match in reversed(matches):
        candidate = match.group(1).strip()
        if not candidate:
            continue
        try:
            return json.loads(candidate)
        except json.JSONDecodeError:
            continue

    # 策略 2.5：截断修复 —— 输出被 max_tokens 截断时，JSON 不完整
    # 典型场景：```json\n{"fields": [{...}, {...}, ... (被截断)
    # 策略：找到最后一个完整的 } 或 ]，砍掉后面的残片，补全闭合括号
    truncated = _try_repair_truncated_json(text)
    if truncated is not None:
        return truncated

    # 策略 3：从后往前找最后一个完整 JSON 对象/数组
    # 对于 thinking 模型，真正的结果通常在输出末尾
    # 优先尝试 {} 对象（外层通常是 {"fields": [...]} 这类包装对象），
    # 但需要找到 **最大** 的合法 JSON，而不是最内层的小对象。
    # 因此对 {} 采用多轮尝试：如果解析出的对象不含 "fields" 等预期键，
    # 继续向前寻找更外层的 {}。
    candidates = []
    for open_ch, close_ch in [('{', '}'), ('[', ']')]:
        end = text.rfind(close_ch)
        if end == -1:
            continue
        # 从 end 往前找配对的开括号
        depth = 0
        for i in range(end, -1, -1):
            if text[i] == close_ch:
                depth += 1
            elif text[i] == open_ch:
                depth -= 1
            if depth == 0:
                try:
                    parsed = json.loads(text[i : end + 1])
                    candidates.append((i, parsed))
                except json.JSONDecodeError:
                    pass
                break  # 配对找到了，跳过此括号类型

    if candidates:
        # 优先选择包含 "fields" / "new_fields" / "clusters" 键的对象（schema 生成常见格式），
        # 或者是列表类型（多个 field），否则选最靠前（最大范围）的候选。
        for _, parsed in candidates:
            if isinstance(parsed, dict) and any(
                k in parsed for k in ("fields", "new_fields", "clusters")
            ):
                return parsed
        for _, parsed in candidates:
            if isinstance(parsed, list) and len(parsed) > 1:
                return parsed
        # 回退：返回最靠前的候选（覆盖范围最大）
        candidates.sort(key=lambda x: x[0])
        return candidates[0][1]

    logger.warning("JSON 解析失败，原始文本片段: %s...", text[:200])
    return None


def call_llm_json(
    prompt: str,
    base_url: str,
    api_key: str,
    model_name: str = "gemini-2.5-pro",
    system_prompt: Optional[str] = None,
    temperature: Optional[float] = None,
    thinking_mode: bool = True,
    response_format: Optional[dict] = None,
    endpoint: str = "chat",
    max_retries: int = 5,
    retry_delay: int = 10,
    max_tokens: Optional[int] = None,
) -> Any:
    """
    调用 LLM 并自动将返回文本解析为 JSON 对象。

    默认启用 Structured Output（``response_format={"type": "json_object"}``），
    让模型在 API 层面保证输出合法 JSON。如果 API 不支持，可传 ``response_format=None``
    回退到纯文本模式（此时靠 ``_extract_json_from_text`` 从文本中提取 JSON）。

    参数含义同 :func:`call_llm`。

    Returns:
        解析后的 Python 对象（dict / list），失败返回 ``None``。
    """
    # 默认启用 json_object 结构化输出
    if response_format is None:
        response_format = {"type": "json_object"}

    # Thinking 模型（含 "thinking" 的模型名）通常不支持 response_format，
    # 代理会尝试强制解析 thinking 输出为 JSON 导致返回空内容。
    # 跳过 response_format，靠 _extract_json_from_text() 从文本中提取。
    if "thinking" in model_name.lower():
        response_format = None

    raw = call_llm(
        prompt=prompt,
        base_url=base_url,
        api_key=api_key,
        model_name=model_name,
        system_prompt=system_prompt,
        temperature=temperature,
        thinking_mode=thinking_mode,
        response_format=response_format,
        endpoint=endpoint,
        max_retries=max_retries,
        retry_delay=retry_delay,
        max_tokens=max_tokens,
    )
    if raw is None:
        return None
    return _extract_json_from_text(raw)
