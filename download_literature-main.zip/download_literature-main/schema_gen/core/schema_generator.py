#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Schema 生成模块 —— 基于用户查询自动生成关键字提取 Schema。

实现了一个 **5+1 步多 Agent 协作** 的 Schema 生成流水线：

  1. **问题拆解** (Step 1)   —— 将用户查询分解为四个逻辑层级
     - Level 1: 宏观环境与背景
     - Level 2: 中观机理与主体（核心过程、优化参数）
     - Level 3: 微观结果与指标（转化率、评价标准）
     - Level 4: 优化与因果关系（哪些变量影响了结果）

  2. **并发生成** (Step 2)   —— 启动多个"架构师"Agent 并行提出字段建议
  3. **归纳组织** (Step 3)   —— 将多架构师的建议合并为统一 Schema
  4. **发散扩展** (Step 3.5) —— 用横向思维识别被遗漏的字段
  5. **反思完善** (Step 4)   —— 精炼描述、标注重点字段
  6. **聚类分析** (Step 5)   —— 将字段按语义分组（可选）
  7. **子领域归类** (Step 6) —— 给每个字段标注适用子领域

最终对外产物是 ``refined_schema_<project>.csv``（各 step 的中间结果落在 ``_intermediate/``）。

典型用法（实际项目里通过 ``python -m schema_gen --config <yaml>`` 入口跑，
所有参数由 YAML 驱动；下面只是直接 import 时的最小示例）::

    from literature_knowledge_extractor.schema_generator import SchemaGenerator

    generator = SchemaGenerator(
        base_url="http://your-api-server/v1",
        api_key="sk-xxx",
        model_name="gemini-2.5-pro",
        num_architects=3,   # YAML pipeline.num_architects 透传过来
    )

    schema, csv_path = generator.generate(
        user_query="aerospace metamaterial broadband absorber design optimization",
        output_dir="./output/schema_session",
    )
"""

import json
import re
import logging
import pathlib
from typing import Optional, Dict, Any, List, Tuple
from concurrent.futures import ThreadPoolExecutor, as_completed

from .llm_client import call_llm, call_llm_json
from .utils import json_to_csv_schema, save_json

logger = logging.getLogger(__name__)


# ===================================================================
# 默认 Prompt 模板
# ===================================================================
# 以下模板与原始 optimizer 项目中的配置保持一致。
# 用户可以通过构造函数传入 ``prompts`` 参数来覆盖任意模板。

DEFAULT_PROMPTS = {
    # -------------------- Step 1: 问题拆解 --------------------
    "decomposition": """# Task
The user wants to extract information about **"{user_query}"** from a large number of unstructured documents.
We have a detailed experiment process for the task(optional):
{idea}
The user concerns about the following additional information(optional):
{additional_info}
Your task is not to list keywords directly, but to mimic the thought process of a domain expert and break down the problem into four logical levels. Subsequent steps will use your breakdown to determine specific database fields.
# Methodology: The 4-Level Thinking Process
Please strictly follow the logical framework below to delve into the problem:
**Level 1: Macro Context & Environment**
- Think about the background and broad system constraints in which the task occurs.
- *Ask yourself: In this broad domain, what common external factors will affect the outcome?*
**Level 2: Meso Mechanism & Subjects**
- Think about the core processes, design parameters, study variables, and their interactions, or intrinsic properties involved in the given information(user query, experiment process and additional information).
- *Ask yourself: What are the properties of the core subjects? What are the key process/design conditions that participate in the entire study? What are the key optimization parameters that influence the outcome? How do they interact? What are the key intermediate states?*
**Level 3: Micro Outcome & Metrics**
- Think about the specific results, particular metrics, evaluation criteria, or final outputs that the user is most concerned about.
- *Ask yourself: How is "success" defined? What specific parameters directly describe the final outcome (static values)?*
**Level 4: Optimization & Causality [Crucial]**
- Think about which variables (independent variables) the author usually adjusts to optimize performance.
- What outcome changes (trends/correlations) do these adjustments usually lead to?
- *Ask yourself: We not only need to know "what the result is," but also "what factors led to this result" and "the mechanism behind it."*
# Your Output
Please provide your four-level breakdown analysis for the user's Query: **"{user_query}"**. Present the key factors to consider for each level clearly in a list format.
**Important**: Be concise — list key factors as bullet points only. Do NOT write lengthy explanations, examples, or sub-classifications for each factor. Aim for 3-8 bullet points per level, totaling no more than 2000 words.""",

    # -------------------- Step 2: 架构师生成 --------------------
    "architect": """# Context
We are building an information extraction database for the task: "{user_query}".
and we have a detailed experiment process for the task(optional):
{idea}
The user concerns about the following additional information(optional):
{additional_info}
A domain expert has already performed the following logical breakdown of the task:
{step_1_output}
# Task
Please analyze the given information(user query, experiment process and additional information) and pay attention to the variables changed during the study (e.g., design parameters, process settings, material properties, simulation conditions, etc.). These variables are the key variables to be extracted from the literature.
Please consider the additional information provided by the user, as it contains some specific requirements for the schema generation.
Based on the key variables changed during the study and the four levels of breakdown above (environment, mechanism, outcome, optimization & causality), please brainstorm a specific **list of fields (Attribution Schema)** to be extracted from the literature.
# Requirements
For each field, please provide:
1. **Field Name**: The standard English name for the field (e.g., `operating_frequency`, `material_density`, `optimization_method`).
2. **Chinese Name**: The Chinese name for the field, which should be concise (usually no more than 10 characters), accurately reflect the field's meaning, and use professional terminology.
3. **Description**: A detailed description of the field's meaning.
4. **Importance**: Which level the field belongs to (Level 1/2/3/4).
5. **Extraction Tip**: A tip for the extractor on where in the document (e.g., "experimental section," "results and discussion," "model definition," "parameter table") this information might be found.
Please output in JSON format as follows:
```json
{{
  "fields": [
    {{
      "field_name": "example_field",
      "chinese_name": "中文名称",
      "description": "Field description",
      "importance": "Level 1",
      "extraction_tip": "Extraction tip"
    }}
    ...
  ]
}}
```""",

    # -------------------- Step 3: 归纳与组织 --------------------
    "aggregator": """# Input
You have received lists of field suggestions from {num_architects} architects for the same task.
Task: "{user_query}"
Architects' Suggestion Lists:
{architect_suggestions}
# Task
Your goal is to integrate these suggestions into a **union set**, not an intersection. Please follow these principles for cleaning and organizing:
1. **Preserve Diversity**: Do not arbitrarily delete fields. If it's the same concept with different names (e.g., `temp` and `temperature`), merge and unify the naming; if they are different concepts, keep them all.
2. **Structured Classification**: Use the previously defined "Level 1/2/3/4" logic to categorize all fields into these four levels.
3. **Mark Rarity**:
   - Mark as **[Core]**: Core, high-frequency fields mentioned by multiple architects.
   - Mark as **[Niche]**: Long-tail fields mentioned by only a few architects but with specific depth.
# Output
Please output the final organized Schema as a key-value JSON object.
**Important**: The output format must be a JSON object where:
- **key**: The standard English name for the field (keyword).
- **value**: An object containing:
  - `chinese_name`: The Chinese name for the field.
  - `description`: The meaning of the field.
  - `extraction_tip`: Important notes for extraction.
  - `level`: The level it belongs to (Level 1/2/3/4).
  - `tag`: The tag ([Core] or [Niche]).
Please output in JSON format as follows:
```json
{{
  "design_parameter": {{
    "chinese_name": "设计参数",
    "description": "Key design or process parameter that influences performance",
    "extraction_tip": "Look for parameter tables, model definition, or experimental setup sections",
    "level": "Level 1",
    "tag": "[Core]"
  }}
  ...
}}
```""",

    # -------------------- Step 3.5: 发散扩展 --------------------
    "expansion": """# Context
We are building an information extraction database for the task: "{user_query}".
We have a detailed experiment process for the task(optional):
{idea}
The user concerns about the following additional information(optional):
{additional_info}
We have already generated a preliminary list of fields (Schema) through a multi-agent process.
# Current Schema
{current_schema}
# Task
Please review the current schema and the user's request. Your goal is to **brainstorm and expand** the schema by identifying missing but valuable fields using **Lateral Thinking**.

Think divergently based on the following angles:
1. **Task-Related**: Are there any missing parameters that are mentioned in the additional information but not in the current schema?
2. **Completeness**: Are there any missing parameters that usually accompany the existing fields? (e.g., if "thickness" exists, is "areal density" needed? if "frequency" exists, is "bandwidth" needed?)
3. **Context**: Are there environmental conditions, experimental setups, simulation settings, or pre-processing steps missing?
4. **Outliers & Edge Cases**: Are there any domain-specific properties or conditions that are currently overlooked?
5. **Causality**: If there are result metrics, are the corresponding causal factors (independent variables) fully covered?

# Requirement
- Only output **NEW** fields that are not in the current schema.
- If you find no new fields are needed, output an empty list.
- Follow the specific JSON structure for each field.

# Output
Please output in JSON format as follows:
```json
{{
  "new_fields":
  [
    {{
      "field_name": "operating_bandwidth_GHz",
      "chinese_name": "工作带宽",
      "description": "Operating bandwidth of the device or structure",
      "extraction_tip": "Look for bandwidth data in results tables or performance summary",
      "level": "Level 3",
      "tag": "[Expansion]"
    }}
    ...
  ]
}}
```""",

    # -------------------- Step 4: 反思与完善 --------------------
    "reflection": """# Context
We are building an information extraction database for the task: "{user_query}".
A preliminary Schema has been generated, and now you need to reflect on and refine it.
# Current Schema
{current_schema}
# Task
Please review and refine each field:
1. **Refine Descriptions**:
   - If a description is not clear enough, improve it to be more precise.
   - If an extraction tip is not specific enough, add more detailed guidance.
   - If a Chinese name is not accurate, optimize it.
2. **Mark Key Fields**:
   - Identify the 8-12 most core key fields from all fields.
   - Add the `is_key_field: true` tag to these key fields, and `is_key_field: false` to the others.
3. **Rank the fields**:
   - Rank the fields based on the importance level (Level 1/2/3/4).
   - The fields with the highest importance level should be ranked first.
# Output
Please output the refined Schema in the same format as the input (key-value JSON format), including the refined information for all fields.
```json
{{
  "field_name": {{
    "chinese_name": "中文名称",
    "description": "Refined description",
    "extraction_tip": "Refined extraction tip",
    "level": "Level 1",
    "tag": "[Core]",
    "is_key_field": true
  }}
  ...
}}
```""",

    # -------------------- Step 5: 字段聚类 --------------------
    "cluster_analyzer": """# Task
You have received a list of field definitions for a knowledge graph Schema. Please deeply analyze the relationship patterns between these fields and cluster them into **5-8 categories**.
# Fields Data
{fields_data}
# Requirements
- Consider semantic relevance, functional grouping, hierarchical relationships, dependencies, and usage scenarios.
- Each category should have a clear theme and boundary.
- All fields must be assigned to a category.
# Output Format
Please output the clustering results in JSON format as follows:
```json
{{
  "clusters": [
    {{
      "cluster_id": "cluster_1",
      "cluster_name": "类别名称 (中文)",
      "cluster_name_en": "Category Name (English)",
      "description": "A detailed description of this category.",
      "field_count": 5,
      "fields": [
        {{
          "field_name": "field_name",
          "chinese_name": "中文名称",
          "level": "Level 2",
          "tag": "[Core]",
          "is_key_field": true
        }}
      ],
      "key_characteristics": ["Characteristic 1", "Characteristic 2"]
    }}
  ],
  "summary": {{
    "total_fields": 39,
    "total_clusters": 6
  }}
}}
```""",

    # -------------------- Step 6: 子领域分类 --------------------
    "subdomain_classifier": """# Task
You are given a list of extracted-knowledge-graph fields and a closed list of subdomains.
For **every** field, decide which subdomain(s) from the provided list it applies to.
A field MAY belong to multiple subdomains. If a field is generic and applies to all
subdomains, list all of them. Do NOT invent subdomains outside the provided list.

# Subdomains (closed set)
{subdomain_list}

# Schema Fields
{fields_data}

# Output Format
Return a JSON object whose keys are field names and whose values are arrays of
subdomain strings (each value must be exactly one of the listed subdomains):
```json
{{
  "field_name_1": ["radome", "metamaterial"],
  "field_name_2": ["absorber"]
}}
```
Output ONLY the JSON object, no commentary.""",
}


# ===================================================================
# SchemaGenerator 主类
# ===================================================================

class SchemaGenerator:
    """
    关键字 Schema 生成器 —— 通过五步 LLM 协作流水线，自动为用户查询
    生成结构化的知识提取 Schema。

    Args:
        base_url:           LLM API 的基础 URL。
        api_key:            LLM API 密钥。
        model_name:         使用的模型名称，默认 ``"gemini-2.5-pro"``。
        temperature:        采样温度，默认 0.2。
        num_architects:     Step 2 中并行"架构师"的数量；
                            由 YAML ``pipeline.num_architects`` 配置（缺省 3）。
        enable_clustering:  是否执行 Step 5（字段聚类），默认 True。
        prompts:            自定义 prompt 模板字典。键名需与
                            :data:`DEFAULT_PROMPTS` 一致。传入的模板会覆盖默认值。
        max_retries:        LLM 调用的最大重试次数，默认 5。
        retry_delay:        LLM 调用重试间隔（秒），默认 10。
    """

    def __init__(
        self,
        base_url: str,
        api_key: str,
        model_name: str = "gemini-2.5-pro",
        temperature: float = 0.2,
        *,
        num_architects: int,
        enable_clustering: bool = True,
        prompts: Optional[Dict[str, str]] = None,
        endpoint: str = "chat",
        architect_models: Optional[List[Tuple[str, str]]] = None,
        max_retries: int = 5,
        retry_delay: int = 10,
        domain_instruction: str = "",
        subdomains: Optional[List[str]] = None,
        usage_scope: str = "",
    ):
        self.base_url = base_url
        self.api_key = api_key
        self.model_name = model_name
        self.temperature = temperature
        self.num_architects = num_architects
        self.enable_clustering = enable_clustering
        self.endpoint = endpoint
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        # 混合架构师模型：[(model_name, endpoint), ...]
        # 未指定时所有架构师使用默认 model_name + endpoint
        self.architect_models = architect_models

        # ---- 领域偏好（动态注入到每个 prompt 顶部） ----
        # domain_instruction 是一段在 schema 生成前 LLM 已经写好的领域相关指令文本，
        # 由 build_domain_instruction() 根据 domain_prefer/<project>.txt 里的关键词、
        # query 和子领域分类列表动态生成。
        self.domain_instruction = (domain_instruction or "").strip()
        self.subdomains = list(subdomains) if subdomains else []
        self.usage_scope = usage_scope or ""

        # 合并默认 prompts 和用户自定义 prompts
        self.prompts = {**DEFAULT_PROMPTS}
        if prompts:
            self.prompts.update(prompts)

        # 会话输出目录（在 generate() 调用时设置）
        self._session_dir: Optional[pathlib.Path] = None

    # ------------------------------------------------------------------
    # 内部 LLM 调用封装（自动注入通用参数）
    # ------------------------------------------------------------------

    def _call_text(self, prompt: str, system_prompt: Optional[str] = None) -> Optional[str]:
        """调用 LLM，返回纯文本。"""
        return call_llm(
            prompt=prompt,
            base_url=self.base_url,
            api_key=self.api_key,
            model_name=self.model_name,
            system_prompt=system_prompt,
            temperature=self.temperature,
            endpoint=self.endpoint,
            max_retries=self.max_retries,
            retry_delay=self.retry_delay,
        )

    def _call_json(self, prompt: str, system_prompt: Optional[str] = None) -> Any:
        """调用 LLM 并解析 JSON。"""
        return call_llm_json(
            prompt=prompt,
            base_url=self.base_url,
            api_key=self.api_key,
            model_name=self.model_name,
            system_prompt=system_prompt,
            temperature=self.temperature,
            endpoint=self.endpoint,
            max_retries=self.max_retries,
            retry_delay=self.retry_delay,
        )

    def _get_prompt(self, key: str, **kwargs) -> str:
        """获取并格式化指定的 prompt 模板。"""
        if key not in self.prompts:
            raise KeyError(f"Prompt 模板 '{key}' 不存在。可用: {list(self.prompts.keys())}")
        body = self.prompts[key].format(**kwargs)
        # 把 domain_instruction 注入到 schema 生成相关的步骤（不含聚类/子领域分类，
        # 因为那两步只对已有字段做后处理，不需要领域引导）。
        if self.domain_instruction and key in (
            "decomposition", "architect", "aggregator", "expansion", "reflection",
        ):
            body = f"{self.domain_instruction}\n\n{body}"
        return body

    def _save_artifact(self, filename: str, content: str) -> None:
        """保存中间产物到会话的 _intermediate 子目录（不污染最终输出根目录）。"""
        if self._session_dir:
            inter = self._session_dir / "_intermediate"
            inter.mkdir(parents=True, exist_ok=True)
            (inter / filename).write_text(content, encoding="utf-8")

    def _load_artifact(self, filename: str) -> Optional[str]:
        """从会话的 _intermediate 子目录加载中间产物。"""
        if not self._session_dir:
            return None
        path = self._session_dir / "_intermediate" / filename
        if path.exists():
            text = path.read_text(encoding="utf-8").strip()
            return text if text else None
        return None

    def _load_artifact_json(self, filename: str) -> Any:
        """从会话目录加载 JSON 中间产物，文件不存在/为空/解析失败返回 None。"""
        text = self._load_artifact(filename)
        if not text:
            return None
        try:
            data = json.loads(text)
            # 空字典/空列表视为无效
            if not data:
                return None
            return data
        except json.JSONDecodeError:
            return None

    # ==================================================================
    # Step 1: 问题拆解
    # ==================================================================

    def _step1_decompose(
        self,
        user_query: str,
        idea: Optional[str] = None,
        additional_info: Optional[str] = None,
    ) -> str:
        """
        Step 1: 问题拆解 —— 将用户查询分解为四个逻辑层级。

        使用"第一性原理"和"层次化思维"，从宏观到微观逐层分析问题，
        为后续的字段生成提供思维框架。

        Args:
            user_query:      用户的研究查询。
            idea:            可选的实验流程描述。
            additional_info: 可选的额外信息或约束条件。

        Returns:
            LLM 生成的四层分析文本。
        """
        logger.info("=" * 60)
        logger.info("Step 1: 问题拆解")
        logger.info("=" * 60)

        prompt = self._get_prompt(
            "decomposition",
            user_query=user_query,
            idea=idea or "",
            additional_info=additional_info or "",
        )
        system_prompt = (
            "You are a cross-domain knowledge graph construction expert. "
            "You excel at using 'first principles' and 'hierarchical thinking' "
            "to break down complex user queries into metadata dimensions "
            "required for building a database."
        )

        result = self._call_text(prompt, system_prompt=system_prompt)
        logger.info("拆解完成，结果长度: %d 字符", len(result or ""))

        # Claude 等模型可能生成极长的拆解（17K-28K），后续 architect prompt
        # 会将此文本完整嵌入，总长度过大会导致 API 返回空。截断至 8K 保留核心信息。
        MAX_DECOMPOSITION_CHARS = 10000
        if result and len(result) > MAX_DECOMPOSITION_CHARS:
            logger.warning(
                "Step 1 输出过长（%d 字符），截断至 %d 字符",
                len(result), MAX_DECOMPOSITION_CHARS,
            )
            result = result[:MAX_DECOMPOSITION_CHARS] + "\n\n[... truncated for brevity ...]"

        self._save_artifact("step1_decomposition.txt", result or "")
        return result or ""

    # ==================================================================
    # Step 2: 并发架构师生成
    # ==================================================================

    def _step2_single_architect(
        self,
        agent_id: int,
        user_query: str,
        step_1_output: str,
        idea: Optional[str] = None,
        additional_info: Optional[str] = None,
        override_model: Optional[str] = None,
        override_endpoint: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        单个架构师 Agent 的工作函数。

        每个架构师独立地根据 Step 1 的拆解结果，提出一组字段建议。
        可通过 override_model/override_endpoint 指定该架构师使用的模型。

        Returns:
            ``{"agent_id": N, "fields": [...]}``
        """
        model = override_model or self.model_name
        ep = override_endpoint or self.endpoint
        logger.info("  架构师 %d 开始工作...（模型: %s）", agent_id, model)

        prompt = self._get_prompt(
            "architect",
            user_query=user_query,
            idea=idea or "",
            step_1_output=step_1_output,
            additional_info=additional_info or "",
        )
        system_prompt = (
            "You are a senior data architect. You are proficient in using "
            "'first principles' and 'hierarchical thinking' to break down "
            "complex user queries into metadata dimensions required for "
            "building a database."
        )

        # 使用指定模型调用 LLM
        # 先获取原始文本用于诊断保存，再解析 JSON
        from .llm_client import call_llm, _extract_json_from_text
        raw_text = call_llm(
            prompt=prompt,
            base_url=self.base_url,
            api_key=self.api_key,
            model_name=model,
            system_prompt=system_prompt,
            temperature=self.temperature,
            endpoint=ep,
            max_retries=self.max_retries,
            retry_delay=self.retry_delay,
        )
        parsed = _extract_json_from_text(raw_text) if raw_text else None
        # 兼容多种 LLM 返回格式：
        #   1. {"fields": [{...}, {...}]}       → 标准格式
        #   2. [{...}, {...}]                   → 直接数组
        #   3. {"field_name": "...", ...}        → 单个 field（Claude thinking 常见）
        if isinstance(parsed, dict) and "fields" in parsed:
            fields = parsed["fields"]
        elif isinstance(parsed, list):
            fields = parsed
        elif isinstance(parsed, dict) and "field_name" in parsed:
            fields = [parsed]
        else:
            fields = []

        # 调试：记录 LLM 实际返回值类型，帮助定位 0 fields 问题
        if not fields:
            logger.warning(
                "  架构师 %d 返回 0 字段 — parsed type=%s, value=%s",
                agent_id, type(parsed).__name__,
                str(parsed)[:300] if parsed is not None else "None",
            )

        logger.info("  架构师 %d 完成，生成 %d 个字段", agent_id, len(fields))

        result = {"agent_id": agent_id, "fields": fields}
        self._save_artifact(
            f"step2_architect_{agent_id}.json",
            json.dumps(result, ensure_ascii=False, indent=2),
        )
        return result

    def _step2_generate_concurrently(
        self,
        user_query: str,
        step_1_output: str,
        idea: Optional[str] = None,
        additional_info: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        Step 2: 并发生成 —— 启动多个架构师 Agent 并行生成字段建议。

        使用 ThreadPoolExecutor 实现并发，所有架构师共享相同的输入，
        但独立产出不同的字段建议，最大化覆盖面。

        Args:
            user_query:      用户查询。
            step_1_output:   Step 1 的拆解结果。
            idea:            实验流程描述。
            additional_info: 额外信息。

        Returns:
            所有架构师结果的列表，按 agent_id 排序。
        """
        logger.info("=" * 60)
        logger.info("Step 2: 并发生成（%d 个架构师）", self.num_architects)
        logger.info("=" * 60)

        results = []
        with ThreadPoolExecutor(max_workers=self.num_architects) as executor:
            futures = []
            for i in range(self.num_architects):
                # 混合架构师模型：按序分配，循环使用
                if self.architect_models:
                    m, ep = self.architect_models[i % len(self.architect_models)]
                else:
                    m, ep = None, None  # 使用默认模型
                futures.append(executor.submit(
                    self._step2_single_architect,
                    i + 1, user_query, step_1_output, idea, additional_info,
                    override_model=m, override_endpoint=ep,
                ))
            for future in as_completed(futures):
                results.append(future.result())

        results.sort(key=lambda x: x.get("agent_id", 0))
        total = sum(len(r.get("fields", [])) for r in results)
        logger.info("所有架构师完成，共收集 %d 个字段建议", total)
        return results

    # ==================================================================
    # Step 3: 归纳与组织
    # ==================================================================

    def _step3_aggregate(
        self,
        user_query: str,
        architect_suggestions: List[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """
        Step 3: 归纳与组织 —— 将多架构师的建议合并为统一 Schema。

        合并原则：
          - 取并集而非交集，保留多样性
          - 同义概念合并统一命名
          - 按 Level 1-4 结构化分类
          - 标记 [Core]（高频）和 [Niche]（长尾）

        Args:
            user_query:             用户查询。
            architect_suggestions:  Step 2 的架构师建议列表。

        Returns:
            统一后的 Schema 字典 ``{field_name: {meta...}}``。
        """
        logger.info("=" * 60)
        logger.info("Step 3: 归纳与组织")
        logger.info("=" * 60)

        suggestions_text = json.dumps(architect_suggestions, ensure_ascii=False, indent=2)
        prompt = self._get_prompt(
            "aggregator",
            num_architects=len(architect_suggestions),
            user_query=user_query,
            architect_suggestions=suggestions_text,
        )
        system_prompt = (
            "You are a senior schema standardization engineer. You are proficient "
            "in using 'first principles' and 'hierarchical thinking' to break down "
            "complex user queries into metadata dimensions required for building "
            "a database."
        )

        result = self._call_json(prompt, system_prompt=system_prompt)
        if result:
            logger.info("归纳成功，生成 %d 个统一字段", len(result))
            self._save_artifact(
                "step3_aggregation.json",
                json.dumps(result, ensure_ascii=False, indent=2),
            )
        else:
            logger.error("归纳失败，无法解析 LLM 返回结果")

        return result or {}

    # ==================================================================
    # Step 3.5: 发散扩展
    # ==================================================================

    def _step3_5_expand(
        self,
        user_query: str,
        current_schema: Dict[str, Any],
        idea: Optional[str] = None,
        additional_info: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Step 3.5: 发散扩展 —— 利用横向思维发现遗漏的字段。

        从任务相关性、完整性、上下文、边界案例、因果关系五个角度
        审视当前 Schema，识别缺失的有价值字段。

        Args:
            user_query:      用户查询。
            current_schema:  当前的 Schema 字典。
            idea:            实验流程描述。
            additional_info: 额外信息。

        Returns:
            扩展后的 Schema 字典（在 current_schema 上原地添加新字段后返回）。
        """
        logger.info("=" * 60)
        logger.info("Step 3.5: 发散扩展")
        logger.info("=" * 60)

        schema_text = json.dumps(current_schema, ensure_ascii=False, indent=2)
        prompt = self._get_prompt(
            "expansion",
            user_query=user_query,
            current_schema=schema_text,
            idea=idea or "",
            additional_info=additional_info or "",
        )
        system_prompt = (
            "You are a creative domain expert and data scientist. "
            "You excel at lateral thinking and identifying missing "
            "dimensions in data schemas."
        )

        result = self._call_json(prompt, system_prompt=system_prompt)

        if result and "new_fields" in result:
            new_fields = result["new_fields"]
            logger.info("扩展成功，发现 %d 个新字段", len(new_fields))
            self._save_artifact(
                "step3_5_expansion.json",
                json.dumps(result, ensure_ascii=False, indent=2),
            )
            # 将新字段合并到当前 Schema
            for field in new_fields:
                name = field.get("field_name")
                if name and name not in current_schema:
                    current_schema[name] = {
                        "chinese_name": field.get("chinese_name"),
                        "description": field.get("description"),
                        "extraction_tip": field.get("extraction_tip"),
                        "level": field.get("importance", "Level 2"),
                        "tag": field.get("tag", "[Expansion]"),
                    }
        else:
            logger.info("扩展未发现新字段或解析失败")

        return current_schema

    # ==================================================================
    # Step 4: 反思与完善
    # ==================================================================

    def _step4_reflect(
        self,
        user_query: str,
        current_schema: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Step 4: 反思与完善 —— 精炼字段描述并标注重点字段。

        具体操作：
          - 改进不够清晰的 description
          - 增加更具体的 extraction_tip
          - 优化不准确的 chinese_name
          - 从所有字段中选出 8-12 个最核心的，标记 ``is_key_field: true``
          - 按重要性排序

        Args:
            user_query:      用户查询。
            current_schema:  当前的 Schema 字典。

        Returns:
            精炼后的 Schema 字典。
        """
        logger.info("=" * 60)
        logger.info("Step 4: 反思与完善")
        logger.info("=" * 60)

        schema_text = json.dumps(current_schema, ensure_ascii=False, indent=2)
        prompt = self._get_prompt(
            "reflection",
            user_query=user_query,
            current_schema=schema_text,
        )
        system_prompt = (
            "You are a senior data architect and quality control expert. "
            "You are proficient in using 'first principles' and 'hierarchical "
            "thinking' to break down complex user queries into metadata "
            "dimensions required for building a database."
        )

        result = self._call_json(prompt, system_prompt=system_prompt)

        if result:
            key_count = sum(
                1 for v in result.values()
                if isinstance(v, dict) and v.get("is_key_field")
            )
            logger.info("反思完成，标记了 %d 个重点字段", key_count)
            self._save_artifact(
                "step4_reflection.json",
                json.dumps(result, ensure_ascii=False, indent=2),
            )
            return result
        else:
            logger.warning("反思失败，使用前一阶段的 Schema")
            return current_schema

    # ==================================================================
    # Step 5: 字段聚类分析（可选）
    # ==================================================================

    def _step5_cluster(self, final_schema: Dict[str, Any]) -> Dict[str, Any]:
        """
        Step 5: 字段聚类分析 —— 将字段按语义分组为 5-8 个类别。

        综合考虑语义相关性、功能分组、层次关系、依赖关系和使用场景，
        为每个字段分配 ``cluster_id``、``cluster_name``、``cluster_name_en``。

        Args:
            final_schema: 经过 Step 4 精炼的 Schema 字典。

        Returns:
            添加了聚类信息的 Schema 字典。
        """
        logger.info("=" * 60)
        logger.info("Step 5: 字段聚类分析")
        logger.info("=" * 60)

        fields_data = json.dumps(final_schema, ensure_ascii=False, indent=2)
        prompt = self._get_prompt("cluster_analyzer", fields_data=fields_data)
        system_prompt = (
            "You are a senior data architect and knowledge graph expert. "
            "You are proficient in using 'first principles' and 'hierarchical "
            "thinking' to break down complex user queries into metadata "
            "dimensions required for building a database."
        )

        result = self._call_json(prompt, system_prompt=system_prompt)

        if result and "clusters" in result:
            logger.info("聚类成功，生成 %d 个类别", len(result["clusters"]))
            self._save_artifact(
                "step5_clustering.json",
                json.dumps(result, ensure_ascii=False, indent=2),
            )
            # 将聚类信息合并回主 Schema
            field_to_cluster = {
                f["field_name"]: {
                    "cluster_id": c.get("cluster_id"),
                    "cluster_name": c.get("cluster_name"),
                    "cluster_name_en": c.get("cluster_name_en"),
                }
                for c in result["clusters"]
                for f in c.get("fields", [])
            }
            for name, info in field_to_cluster.items():
                if name in final_schema:
                    final_schema[name].update(info)
        else:
            logger.warning("聚类失败，跳过此步骤")

        return final_schema

    # ==================================================================
    # Step 6: 子领域分类（每个字段标注适用领域）
    # ==================================================================

    def _step6_classify_subdomains(
        self, final_schema: Dict[str, Any],
    ) -> Dict[str, Any]:
        """为每个字段打子领域标签，结果写回 ``final_schema[field]['applicable_domain']``。

        使用 ``domain_prefer/<project>.txt`` 里 ``Subdomains:`` 段定义的封闭列表。
        若 ``self.subdomains`` 为空则跳过该步骤。
        """
        if not self.subdomains:
            logger.info("Step 6: 未配置子领域列表，跳过")
            return final_schema

        logger.info("=" * 60)
        logger.info("Step 6: 子领域分类（%d 个候选子领域）", len(self.subdomains))
        logger.info("=" * 60)

        # 缩减字段载荷：只把 LLM 判断子领域真正需要看的列丢过去，省 token
        compact = {
            name: {
                "chinese_name": v.get("chinese_name", ""),
                "description": v.get("description", ""),
                "level": v.get("level", ""),
                "cluster_name": v.get("cluster_name", ""),
            }
            for name, v in final_schema.items()
        }
        prompt = self._get_prompt(
            "subdomain_classifier",
            subdomain_list="; ".join(self.subdomains),
            fields_data=json.dumps(compact, ensure_ascii=False, indent=2),
        )
        system_prompt = (
            "You are a domain taxonomy classifier. You assign each schema field to "
            "one or more subdomains from a closed list. You never invent subdomains."
        )
        result = self._call_json(prompt, system_prompt=system_prompt)

        if not isinstance(result, dict):
            logger.warning("Step 6: 子领域分类返回非 dict，全部置空")
            for name in final_schema:
                final_schema[name]["applicable_domain"] = ""
            return final_schema

        valid = set(self.subdomains)
        # 大小写不敏感的子领域名 → 规范化版本（保留 self.subdomains 的原始大小写）
        case_map = {s.lower(): s for s in self.subdomains}
        unmatched = 0
        for name, meta in final_schema.items():
            tags = result.get(name, [])
            if not isinstance(tags, list):
                tags = [tags] if tags else []
            cleaned: List[str] = []
            for t in tags:
                if not isinstance(t, str):
                    continue
                t_norm = t.strip()
                if t_norm in valid:
                    cleaned.append(t_norm)
                elif t_norm.lower() in case_map:
                    cleaned.append(case_map[t_norm.lower()])
            # 去重保序
            seen = set()
            cleaned = [x for x in cleaned if not (x in seen or seen.add(x))]
            if not cleaned:
                unmatched += 1
            meta["applicable_domain"] = ", ".join(cleaned)

        if unmatched:
            logger.warning("Step 6: %d 个字段未匹配到任何子领域", unmatched)

        self._save_artifact(
            "step6_subdomain_classification.json",
            json.dumps(result, ensure_ascii=False, indent=2),
        )
        return final_schema

    def generate(
        self,
        user_query: str,
        output_dir: str,
        idea: Optional[str] = None,
        additional_info: Optional[str] = None,
        resume: bool = True,
        csv_filename: str = "final_schema.csv",
    ) -> Tuple[Dict[str, Any], str]:
        """
        执行完整的五步流程，生成关键字提取 Schema。

        支持断点续跑：如果 ``resume=True``（默认），会检查 ``output_dir`` 中已有的
        中间产物文件，跳过已完成的步骤，从断点处继续执行。

        会在 ``output_dir`` 下保存所有中间产物和最终结果：
          - ``step1_decomposition.txt``       —— 问题拆解
          - ``step2_architect_N.json``         —— 各架构师建议
          - ``step3_aggregation.json``         —— 归纳结果
          - ``step3_5_expansion.json``         —— 扩展结果
          - ``step4_reflection.json``          —— 反思结果
          - ``step5_clustering.json``          —— 聚类结果（可选）
          - ``final_schema.json``              —— 最终 Schema
          - ``final_schema.csv``               —— 最终 Schema 的 CSV 版本

        Args:
            user_query:      用户的研究查询（如 "aerospace metamaterial broadband absorber design"）。
            output_dir:      输出目录路径。
            idea:            可选的实验流程描述。
            additional_info: 可选的额外信息或约束条件。
            resume:          是否启用断点续跑（默认 True）。

        Returns:
            二元组 ``(schema_dict, csv_path)``：
              - ``schema_dict``: 最终 Schema 字典。
              - ``csv_path``:    CSV 文件路径。
        """
        self._session_dir = pathlib.Path(output_dir)
        self._session_dir.mkdir(parents=True, exist_ok=True)
        logger.info("Schema 生成会话目录: %s", self._session_dir)

        # ---- 快速返回：最终 CSV 已存在 ----
        if resume:
            csv_candidate = self._session_dir / csv_filename
            cached_schema = self._load_artifact_json("step4_reflection.json")
            if cached_schema and csv_candidate.exists():
                logger.info("最终 CSV 已存在，直接返回（跳过全部步骤）")
                return cached_schema, str(csv_candidate)

        # ---- Step 1: 问题拆解 ----
        step1_output = None
        if resume:
            step1_output = self._load_artifact("step1_decomposition.txt")
            if step1_output:
                logger.info("Step 1: 从检查点恢复（跳过）")
        if not step1_output:
            step1_output = self._step1_decompose(user_query, idea, additional_info)

        # ---- Step 2: 并发架构师生成 ----
        architect_suggestions = None
        if resume:
            loaded = []
            for i in range(1, self.num_architects + 1):
                data = self._load_artifact_json(f"step2_architect_{i}.json")
                if data and isinstance(data, dict) and data.get("fields"):
                    loaded.append(data)
            if len(loaded) == self.num_architects:
                architect_suggestions = loaded
                total = sum(len(r.get("fields", [])) for r in loaded)
                logger.info("Step 2: 从检查点恢复（跳过），共 %d 个字段", total)
        if architect_suggestions is None:
            architect_suggestions = self._step2_generate_concurrently(
                user_query, step1_output, idea, additional_info,
            )

        # ---- Step 3: 归纳与组织 ----
        aggregated = None
        if resume:
            aggregated = self._load_artifact_json("step3_aggregation.json")
            if aggregated:
                logger.info("Step 3: 从检查点恢复（跳过），共 %d 个字段", len(aggregated))
        if not aggregated:
            aggregated = self._step3_aggregate(user_query, architect_suggestions)
            if not aggregated:
                logger.error("Step 3 归纳失败，流程中止")
                return {}, ""

        # ---- Step 3.5: 发散扩展 ----
        expanded = None
        if resume:
            expanded = self._load_artifact_json("step3_5_expansion.json")
            if expanded:
                # step3_5_expansion.json 保存的是 {"new_fields": [...]},
                # 需要将新字段合并到 aggregated 上重建 expanded
                new_fields = expanded.get("new_fields", [])
                expanded = dict(aggregated)  # 复制 aggregated
                for field in new_fields:
                    name = field.get("field_name")
                    if name and name not in expanded:
                        expanded[name] = {
                            "chinese_name": field.get("chinese_name"),
                            "description": field.get("description"),
                            "extraction_tip": field.get("extraction_tip"),
                            "level": field.get("importance", "Level 2"),
                            "tag": field.get("tag", "[Expansion]"),
                        }
                logger.info("Step 3.5: 从检查点恢复（跳过），扩展后 %d 个字段", len(expanded))
        if not expanded:
            expanded = self._step3_5_expand(user_query, aggregated, idea, additional_info)

        # ---- Step 4: 反思与完善 ----
        final_schema = None
        if resume:
            final_schema = self._load_artifact_json("step4_reflection.json")
            if final_schema:
                logger.info("Step 4: 从检查点恢复（跳过），共 %d 个字段", len(final_schema))
        if not final_schema:
            final_schema = self._step4_reflect(user_query, expanded)

        # ---- Step 5: 字段聚类（可选） ----
        if self.enable_clustering:
            has_cluster = False
            if resume:
                cluster_data = self._load_artifact_json("step5_clustering.json")
                if cluster_data and "clusters" in cluster_data:
                    # 将聚类信息合并回主 Schema
                    field_to_cluster = {
                        f["field_name"]: {
                            "cluster_id": c.get("cluster_id"),
                            "cluster_name": c.get("cluster_name"),
                            "cluster_name_en": c.get("cluster_name_en"),
                        }
                        for c in cluster_data["clusters"]
                        for f in c.get("fields", [])
                    }
                    for name, info in field_to_cluster.items():
                        if name in final_schema:
                            final_schema[name].update(info)
                    has_cluster = True
                    logger.info("Step 5: 从检查点恢复（跳过），%d 个类别",
                                len(cluster_data["clusters"]))
            if not has_cluster:
                final_schema = self._step5_cluster(final_schema)

        # ---- Step 6: 子领域分类 ----
        # 即使断点续跑也总是重新跑一次，因为子领域配置可能会变；如有缓存就用，
        # 没有就跑一次新的。
        cached_sub = self._load_artifact_json("step6_subdomain_classification.json") if resume else None
        if cached_sub and isinstance(cached_sub, dict):
            valid = set(self.subdomains)
            case_map = {s.lower(): s for s in self.subdomains}
            for name, meta in final_schema.items():
                tags = cached_sub.get(name, [])
                if not isinstance(tags, list):
                    tags = [tags] if tags else []
                cleaned: List[str] = []
                for t in tags:
                    if not isinstance(t, str):
                        continue
                    t_norm = t.strip()
                    if t_norm in valid:
                        cleaned.append(t_norm)
                    elif t_norm.lower() in case_map:
                        cleaned.append(case_map[t_norm.lower()])
                seen = set()
                cleaned = [x for x in cleaned if not (x in seen or seen.add(x))]
                meta["applicable_domain"] = ", ".join(cleaned)
            logger.info("Step 6: 从检查点恢复（跳过）")
        else:
            final_schema = self._step6_classify_subdomains(final_schema)

        # 给每个字段补上 usage_scope（同一项目所有字段共享同一个值）
        for meta in final_schema.values():
            meta.setdefault("usage_scope", self.usage_scope)

        # 转换为 CSV（最终唯一对外产物）
        csv_path = str(self._session_dir / csv_filename)
        try:
            json_to_csv_schema(
                final_schema, csv_path,
                include_applicable_domain=True,
                include_usage_scope=True,
                default_usage_scope=self.usage_scope,
            )
        except Exception as exc:
            logger.warning("CSV 转换失败: %s", exc)
            csv_path = ""

        return final_schema, csv_path
