"""domain_prefer 文件解析器。

domain_prefer/<project>.txt 单文件混合格式，用 ``Subdomains:`` / ``Keywords:`` /
``Queries:`` 三段标题区分内容。**三段都是必填**，缺任意一段
:func:`gen_key.schema_gen.run` 都会拒绝执行。

- ``Subdomains:`` 子领域闭合列表，驱动 Step 6 给每个字段打 "适用领域" 标签。
- ``Keywords:`` 文献库的检索关键词（直接从 ``dims/qN.txt`` 复制过来），让 LLM
  在 schema 生成时围绕这些关键词偏向取材。
- ``Queries:`` 想用这个知识库解决的科学问题（直接从 ``query/tryN.txt`` 复制
  过来），作为 ``user_query`` 喂给 SchemaGenerator 的每个 step。

示例::

    # ====== Subdomains ======
    Subdomains: [radome; metamaterial; absorber]

    # ====== Keywords ======
    Keywords:
    Dimension 1:
    layer1: [allylic amination, photocatalysis, regioselective] 1
    layer2: [allylic C-H functionalization | allylic C–H functionalization, amination, photoredox] 2

    Dimension 2:
    layer1: [dual catalysis, allylic substitution, regiocontrol] 2

    Dimension 3: [nitrogen radical, allylic, visible light]

    # ====== Queries ======
    Queries:
    如何实现光化学条件下苯胺参与的位点选择性烯丙位胺化  反应物1：...  产物：...

返回值是 :class:`DomainPrefer` 数据类，调用方拿来调用
:func:`build_domain_instruction` 拼一段 LLM-ready 的 system 前缀文本。
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import List


# 段落标题（不区分大小写）。冒号可选，等号 / 短横线分隔线允许出现。
_HEADER_RE = re.compile(
    r"^\s*(?:#+\s*=*\s*)?"                         # 可选的 markdown # 前缀
    r"(subdomains|keywords|queries)"               # 段名
    r"\s*[:：]?\s*=*\s*$",                         # 末尾冒号 / 等号
    re.IGNORECASE,
)


@dataclass
class DomainPrefer:
    subdomains: List[str] = field(default_factory=list)
    keywords_text: str = ""
    queries_text: str = ""

    @property
    def has_content(self) -> bool:
        return bool(self.subdomains or self.keywords_text or self.queries_text)


def parse_domain_prefer(path: str | Path) -> DomainPrefer:
    """解析 domain_prefer 文件。文件不存在直接抛 FileNotFoundError。"""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"domain_prefer 文件不存在: {p}")

    text = p.read_text(encoding="utf-8")
    lines = text.splitlines()

    # 先把 Subdomains 行单独捞出来（兼容多种写法：
    #   Subdomains: [radome; metamaterial; absorber]    ← 单行带值
    #   # ====== Subdomains ======                       ← 段标题
    #   Subdomains:                                      ← 段标题（无 = 号）
    #   [radome; metamaterial]                           ← 段标题下面的内容
    # 同时支持在段内写 `#` 开头的注释行，会被跳过。
    sections: dict[str, List[str]] = {"subdomains": [], "keywords": [], "queries": []}
    current: str | None = None
    # "Subdomains: [...]" / "Keywords: ..." 单行写法（捕获 section + 值）
    _SINGLE_LINE_RE = re.compile(
        r"^\s*(subdomains|keywords|queries)\s*[:：]\s*(.+)$", re.IGNORECASE,
    )
    for raw in lines:
        line = raw.rstrip()
        if not line.strip():
            continue
        # 1) 段标题（# ====== Subdomains ======  或  Subdomains:）
        m = _HEADER_RE.match(line)
        if m:
            current = m.group(1).lower()
            continue
        # 2) 注释行（`#` 开头但既不是段标题、也不是同行带值的形式）→ 跳过
        if line.lstrip().startswith("#"):
            continue
        # 3) 单行带值："<section>: <value>"
        single_line = _SINGLE_LINE_RE.match(line)
        if single_line:
            sec = single_line.group(1).lower()
            sections[sec].append(single_line.group(2))
            current = sec
            continue
        # 4) 段内普通内容
        if current:
            sections[current].append(line)

    subdomains = _parse_subdomain_list("\n".join(sections["subdomains"]))
    keywords_text = "\n".join(sections["keywords"]).strip()
    queries_text = "\n".join(sections["queries"]).strip()
    return DomainPrefer(
        subdomains=subdomains,
        keywords_text=keywords_text,
        queries_text=queries_text,
    )


def _parse_subdomain_list(s: str) -> List[str]:
    """把 ``[radome; metamaterial; absorber]`` 这类字符串拆成 list。

    支持 ``[]`` 包裹或不包裹，分隔符 ``;`` / ``；`` / ``,`` / ``，``。空段返回空 list。
    """
    s = s.strip()
    if not s:
        return []
    # 去掉外层 [ ]
    s = s.strip().strip("[]【】").strip()
    # 一行可能多行写：先压成单行
    s = re.sub(r"\s*\n\s*", " ", s)
    parts = re.split(r"[;；,，]", s)
    out = [p.strip() for p in parts if p.strip()]
    # 去重保序
    seen = set()
    return [x for x in out if not (x in seen or seen.add(x))]


def build_domain_instruction(pref: DomainPrefer) -> str:
    """根据 DomainPrefer 拼接一段 LLM-ready 的系统前缀指令。

    用于在 schema 生成的每一步前 **动态注入领域上下文**：先告诉 LLM
    ``这个文献库根据什么关键词检索来的`` + ``希望解决什么科学问题`` +
    ``属于哪些子领域``，再让 LLM 跑后续的 4-level 拆解 / 字段头脑风暴 / 反思。
    """
    if not pref.has_content:
        return ""

    parts: List[str] = ["# Domain Preference (injected before schema generation)"]
    if pref.subdomains:
        parts.append(
            "The literature corpus belongs to the following subdomains "
            f"(closed list, used later for per-field tagging): {', '.join(pref.subdomains)}."
        )
    if pref.keywords_text:
        parts.append(
            "The corpus was retrieved using the following multi-dimensional keyword "
            "queries (each Dimension is an AND-of-layers, each layer is at-least-M-of-N "
            "of the comma-separated terms; `|` lists synonym variants for one term):\n"
            f"```\n{pref.keywords_text.strip()}\n```"
        )
    if pref.queries_text:
        parts.append(
            "The downstream knowledge base must help answer the following scientific "
            f"question(s):\n```\n{pref.queries_text.strip()}\n```"
        )
    parts.append(
        "When generating fields, prioritize concepts that are central to the keyword "
        "queries above and that materially help answer the scientific question(s). "
        "Avoid generic boilerplate fields that wouldn't differentiate one paper from "
        "another in this domain."
    )
    return "\n\n".join(parts)
