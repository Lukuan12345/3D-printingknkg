#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
工具函数模块 —— 提供 JSON-to-CSV 转换等通用辅助功能。

包含以下主要功能：
  - ``json_to_csv_schema()``  : 将 Schema JSON 转换为可读的 CSV 表格。
  - ``json_to_csv_variable_space()`` : 将变量空间 JSON 转换为 CSV。
  - ``save_json()``           : 安全地保存 JSON 到文件。
  - ``load_json()``           : 从文件加载 JSON。

这些函数主要被 :mod:`schema_generator` 和 :mod:`knowledge_extractor` 内部调用，
也可以独立使用。
"""

import json
import csv
import logging
from pathlib import Path
from typing import Dict, Any, List

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# JSON 文件读写
# ---------------------------------------------------------------------------

def save_json(data: Any, file_path: str, ensure_ascii: bool = False, indent: int = 2) -> None:
    """
    将 Python 对象序列化为 JSON 并保存到文件。

    自动创建不存在的父目录。

    Args:
        data:           要保存的数据（dict / list / 基础类型）。
        file_path:      目标文件路径。
        ensure_ascii:   是否将非 ASCII 字符转义。默认 False（保留中文）。
        indent:         缩进空格数。
    """
    path = Path(file_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(data, ensure_ascii=ensure_ascii, indent=indent),
        encoding="utf-8",
    )


def load_json(file_path: str) -> Any:
    """
    从文件读取并解析 JSON。

    Args:
        file_path: JSON 文件路径。

    Returns:
        解析后的 Python 对象。

    Raises:
        FileNotFoundError:  文件不存在。
        json.JSONDecodeError: 文件内容不是合法 JSON。
    """
    return json.loads(Path(file_path).read_text(encoding="utf-8"))


# ---------------------------------------------------------------------------
# Schema JSON → CSV 转换
# ---------------------------------------------------------------------------

def json_to_csv_schema(
    data: Dict[str, Any],
    csv_file_path: str,
    include_applicable_domain: bool = False,
    include_usage_scope: bool = False,
    default_usage_scope: str = "",
) -> None:
    """
    将 Schema JSON（由 :class:`SchemaGenerator` 生成）转换为 CSV 表格。

    CSV 包含以下列：
      - 字段名（英文）     —— Schema 中的 key
      - 字段名（中文）     —— ``chinese_name``，若缺失则从 description 截取
      - 完整描述           —— ``description``
      - 提取提示           —— ``extraction_tip``
      - 层级               —— ``level`` (Level 1/2/3/4)
      - 标签               —— ``tag`` ([Core] / [Niche] / [Expansion])
      - 重点字段           —— ``is_key_field`` → "是" / "否"
      - 聚类ID             —— ``cluster_id``
      - 聚类名称           —— ``cluster_name``
      - 聚类名称（英文）   —— ``cluster_name_en``

    Args:
        data:           Schema 字典，格式为 ``{field_name: {meta...}, ...}``。
        csv_file_path:  输出 CSV 文件的路径。
    """
    rows: List[Dict[str, str]] = []

    for key, value in data.items():
        # ---------- 中文名称 ----------
        # 优先使用 LLM 生成的 chinese_name；若缺失，则从 description 中截取
        chinese_name = value.get("chinese_name", "")
        if not chinese_name:
            desc = value.get("description", "")
            chinese_name = desc
            # 尝试在第一个句号/逗号处截断
            for sep in ("。", ".", "，", ","):
                idx = desc.find(sep)
                if 0 < idx < 30:
                    chinese_name = desc[:idx].strip()
                    break
            # 去掉英文括号后面的内容
            if "(" in chinese_name and "（" not in chinese_name:
                chinese_name = chinese_name.split("(")[0].strip()
            # 过长则截断
            if len(chinese_name) > 40:
                chinese_name = chinese_name[:40] + "..."

        rows.append({
            "字段名（英文）": key,
            "字段名（中文）": chinese_name,
            "完整描述": value.get("description", ""),
            "提取提示": value.get("extraction_tip", ""),
            "层级": value.get("level", ""),
            "标签": value.get("tag", ""),
            "重点字段": "是" if value.get("is_key_field") else "否",
            "聚类ID": value.get("cluster_id", ""),
            "聚类名称": value.get("cluster_name", ""),
            "聚类名称（英文）": value.get("cluster_name_en", ""),
            "适用领域": value.get("applicable_domain", ""),
            "使用范围": value.get("usage_scope", default_usage_scope),
        })

    fieldnames = [
        "字段名（英文）", "字段名（中文）", "完整描述", "提取提示",
        "层级", "标签", "重点字段", "聚类ID", "聚类名称", "聚类名称（英文）",
    ]
    if include_applicable_domain:
        fieldnames.append("适用领域")
    if include_usage_scope:
        fieldnames.append("使用范围")

    Path(csv_file_path).parent.mkdir(parents=True, exist_ok=True)
    with open(csv_file_path, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)

    logger.info("Schema CSV 已保存: %s （共 %d 条记录）", csv_file_path, len(rows))


def json_to_csv_variable_space(data: Dict[str, Any], csv_file_path: str) -> None:
    """
    将变量空间 JSON 转换为 CSV 表格。

    CSV 包含以下列：
      - 变量名（英文）
      - 变量名（中文）
      - 变量类型
      - 取值范围
      - 典型值
      - 重要性
      - 完整描述
      - 维度
      - 标签
      - 重点变量

    Args:
        data:           变量空间字典。
        csv_file_path:  输出 CSV 文件路径。
    """
    rows: List[Dict[str, str]] = []

    for key, value in data.items():
        typical = value.get("typical_values", [])
        if isinstance(typical, list):
            typical_str = ", ".join(str(v) for v in typical)
        else:
            typical_str = str(typical) if typical else ""

        rows.append({
            "变量名（英文）": key,
            "变量名（中文）": value.get("chinese_name", ""),
            "变量类型": value.get("variable_type", ""),
            "取值范围": value.get("value_range", ""),
            "典型值": typical_str,
            "重要性": value.get("importance", ""),
            "完整描述": value.get("description", ""),
            "维度": value.get("dimension", ""),
            "标签": value.get("tag", ""),
            "重点变量": "是" if value.get("is_key_variable") else "否",
        })

    fieldnames = [
        "变量名（英文）", "变量名（中文）", "变量类型", "取值范围", "典型值",
        "重要性", "完整描述", "维度", "标签", "重点变量",
    ]

    Path(csv_file_path).parent.mkdir(parents=True, exist_ok=True)
    with open(csv_file_path, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    logger.info("变量空间 CSV 已保存: %s （共 %d 条记录）", csv_file_path, len(rows))
