"""schema_gen 的高层入口：把 config + domain_prefer 拼装成 SchemaGenerator 调用。

负责：
1. 解析 ``domain_prefer/<project>.txt`` 得到关键词 / 子领域 / 查询问题。
2. 用 :func:`build_domain_instruction` 拼一段动态注入到 LLM 的领域前缀。
3. 把 :class:`SchemaGenConfig` 里的 LLM / pipeline 参数喂给底层
   :class:`literature_knowledge_extractor.SchemaGenerator`，让它跑 5+1 步流水线。
4. 仅保留 CSV 产出（与 :file:`refined_schema_output/refined_schema_200_2.csv` 同列）。
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import List, Tuple

from .config_loader import SchemaGenConfig
from .domain_prefer import DomainPrefer, build_domain_instruction, parse_domain_prefer
from .schema_generator import SchemaGenerator

logger = logging.getLogger(__name__)


def _architect_models_from_strings(
    names: List[str], default_endpoint: str,
) -> List[Tuple[str, str]]:
    """把 ``["m1", "m2:responses"]`` 转成 ``[(m1, default_endpoint), (m2, responses)]``。

    支持 ``model_name`` 单独写，或 ``model_name:endpoint`` 显式指定 endpoint。
    """
    out: List[Tuple[str, str]] = []
    for raw in names:
        if not raw:
            continue
        if ":" in raw:
            m, ep = raw.split(":", 1)
            out.append((m.strip(), ep.strip() or default_endpoint))
        else:
            out.append((raw.strip(), default_endpoint))
    return out


def run(cfg: SchemaGenConfig) -> str:
    """根据 cfg 跑完整 schema 生成流程，返回 CSV 绝对路径。"""
    if not cfg.llm.api_key:
        raise ValueError("LLM api_key 未配置（YAML llm.api_key 或环境变量 LLM_API_KEY）")
    if not cfg.llm.base_url:
        raise ValueError("LLM base_url 未配置（YAML llm.base_url 或环境变量 LLM_BASE_URL）")

    pref: DomainPrefer = parse_domain_prefer(cfg.domain_prefer_file)
    missing = [
        name for name, val in (
            ("Subdomains", pref.subdomains),
            ("Keywords",   pref.keywords_text),
            ("Queries",    pref.queries_text),
        ) if not val
    ]
    if missing:
        raise ValueError(
            f"domain_prefer 文件 {cfg.domain_prefer_file} 缺少必填段: "
            f"{', '.join(missing)}。三段（Subdomains / Keywords / Queries）都必须填写。"
        )

    domain_instruction = build_domain_instruction(pref)

    # 把 queries_text 整体作为 user_query 投喂给 SchemaGenerator —— 它会被
    # 嵌入到每个 step 的 prompt 里；同时 domain_instruction 会被 SchemaGenerator
    # 自动拼到 schema 生成相关 step 的最前面。
    user_query = pref.queries_text

    architect_models = _architect_models_from_strings(
        cfg.llm.architect_models, default_endpoint=cfg.llm.endpoint,
    ) or None  # 空列表 → None，让所有架构师都用 schema_model

    generator = SchemaGenerator(
        base_url=cfg.llm.base_url,
        api_key=cfg.llm.api_key,
        model_name=cfg.llm.schema_model,
        temperature=cfg.llm.temperature,
        num_architects=cfg.pipeline.num_architects,
        enable_clustering=cfg.pipeline.enable_clustering,
        endpoint=cfg.llm.endpoint,
        architect_models=architect_models,
        max_retries=cfg.llm.max_retries,
        retry_delay=cfg.llm.retry_delay,
        domain_instruction=domain_instruction,
        subdomains=pref.subdomains,
        usage_scope=cfg.usage_scope,
    )

    logger.info("=" * 60)
    logger.info("项目: %s", cfg.project_name)
    logger.info("domain_prefer: %s", cfg.domain_prefer_file)
    logger.info("  ├─ subdomains : %s", pref.subdomains or "(none)")
    logger.info("  ├─ keywords   : %d 字符", len(pref.keywords_text))
    logger.info("  └─ queries    : %d 字符", len(pref.queries_text))
    logger.info("schema_model: %s  (endpoint=%s)", cfg.llm.schema_model, cfg.llm.endpoint)
    if architect_models:
        logger.info("architect_models: %s", architect_models)
    logger.info("输出目录: %s", cfg.output_dir)
    logger.info("=" * 60)

    _, csv_path = generator.generate(
        user_query=user_query,
        output_dir=cfg.output_dir,
        resume=cfg.pipeline.resume,
        csv_filename=cfg.csv_filename,
    )

    if not csv_path:
        raise RuntimeError("schema 生成失败，未产出 CSV。请查看上方日志定位 step。")

    # 仅保留 CSV：清理 _intermediate 里的中间产物可以由用户手动做，
    # 这里默认保留以便排查问题；但确保最终输出根目录只有那一个 CSV。
    csv_abs = str(Path(csv_path).resolve())
    logger.info("✓ 最终 CSV: %s", csv_abs)
    return csv_abs
