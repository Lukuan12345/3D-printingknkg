#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
fast_ingest.py -- 高速 KB 索引构建器（本地 BGE-M3 优先）

自动选择 embedding 方式：
  - 若本地 BGE-M3 模型存在（retrieval_weights/models/bge-m3/）→ 本地运行，无网络限制，无 TPM 限速
  - 否则 → 远程 API + 异步并发（有 TPM 限速，但也比原版快 10x）

本地 CPU 速度参考（BGE-M3）：
  batch=128  ~25 texts/s  → 136K chunks 约 90 分钟
  (如有 GPU：batch=256  ~500 texts/s  → 136K chunks 约 5 分钟)

API 模式速度（并发 4×batch64，遇限速退避）：
  ~60-100 texts/s  → 136K chunks 约 20-40 分钟

用法：
  # 下载本地模型（一次性，~2.3GB；缺模型时也会自动从 HuggingFace 拉取）
  huggingface-cli download BAAI/bge-m3 --local-dir retrieval_weights/models/bge-m3

  # 全量重建
  python fast_ingest.py --force

  # 增量（只加新 chunks）
  python fast_ingest.py --incremental

  # 指定 KB JSON
  python fast_ingest.py --kb-json path/to/subset.json --force

  # API 模式调参（本地模型不存在时生效）
  python fast_ingest.py --force --concurrency 4 --batch-size 64
"""
from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import logging
import pickle
import sqlite3
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import httpx
import numpy as np
import faiss
import jieba
from rank_bm25 import BM25Okapi

sys.path.insert(0, str(Path(__file__).resolve().parent))
from env_bootstrap import load_env
load_env()
from kb_mvp.src import config as cfg
from kb_mvp.src.embedding import get_client, LocalEmbeddingClient

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logger = logging.getLogger(__name__)


def _atomic_write_json(path: Path, obj) -> None:
    """先写临时文件再原子替换，避免写一半进程被杀导致 cache 损坏。"""
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False)
    tmp.replace(path)


# ============================================================
# 1. SQLite 建表（复用 ingest.py 的 schema）
# ============================================================

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS papers_metadata (
    paper_id           TEXT PRIMARY KEY,
    title              TEXT,
    is_domain_relevant INTEGER DEFAULT 1,
    domains            TEXT,
    extracted_schema   TEXT,
    novel_findings     TEXT
);
CREATE INDEX IF NOT EXISTS idx_papers_relevant ON papers_metadata(is_domain_relevant);

CREATE TABLE IF NOT EXISTS paper_chunks (
    chunk_id       TEXT PRIMARY KEY,
    paper_id       TEXT NOT NULL,
    field_type     TEXT NOT NULL,
    content        TEXT NOT NULL,
    embedding_idx  INTEGER,
    FOREIGN KEY (paper_id) REFERENCES papers_metadata(paper_id)
);
CREATE INDEX IF NOT EXISTS idx_chunks_paper ON paper_chunks(paper_id);
CREATE INDEX IF NOT EXISTS idx_chunks_field ON paper_chunks(field_type);
"""


def init_db(db_path: Path, force: bool = False) -> sqlite3.Connection:
    if force and db_path.exists():
        logger.warning("--force: 删除旧数据库 %s", db_path)
        db_path.unlink()
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path))
    conn.executescript(SCHEMA_SQL)
    conn.commit()
    return conn


# ============================================================
# 2. 导入 metadata & chunks
# ============================================================

def load_and_ingest(conn: sqlite3.Connection, kb: Dict, incremental: bool) -> List[Dict]:
    cursor = conn.cursor()
    chunks: List[Dict] = []
    existing = set()
    if incremental:
        existing = {row[0] for row in conn.execute("SELECT chunk_id FROM paper_chunks").fetchall()}

    for paper_id, paper in kb.items():
        ed = paper.get("extracted_data", {})
        title = paper.get("paper_title") or (ed.get("title", [""])[0] if ed.get("title") else "")
        domains = ed.get("domains") or ed.get("data_source") or ed.get("application_sector") or []
        if isinstance(domains, str):
            domains = [domains]

        cursor.execute(
            "INSERT OR REPLACE INTO papers_metadata "
            "(paper_id, title, is_domain_relevant, domains, extracted_schema, novel_findings) "
            "VALUES (?,?,?,?,?,?)",
            (paper_id, title, 1,
             json.dumps(domains, ensure_ascii=False),
             json.dumps(ed, ensure_ascii=False),
             json.dumps({}, ensure_ascii=False)),
        )
        for field in cfg.CHUNK_FIELDS:
            content = paper.get(field, "")
            if not content or not content.strip():
                continue
            chunk_id = f"{paper_id}_{field}"
            if incremental and chunk_id in existing:
                continue
            cursor.execute(
                "INSERT OR REPLACE INTO paper_chunks "
                "(chunk_id, paper_id, field_type, content, embedding_idx) VALUES (?,?,?,?,?)",
                (chunk_id, paper_id, field, content, None),
            )
            chunks.append({"chunk_id": chunk_id, "paper_id": paper_id,
                           "field_type": field, "content": content, "title": title})
    conn.commit()
    logger.info("导入完成: %d 篇论文, %d 条新 chunks", len(kb), len(chunks))
    return chunks


# ============================================================
# 3. 异步并发 Embedding
# ============================================================

def _hash(text: str) -> str:
    return hashlib.md5(text.encode("utf-8")).hexdigest()


async def _embed_batch_async(
    client: httpx.AsyncClient,
    texts: List[str],
    semaphore: asyncio.Semaphore,
    max_retries: int = 10,
) -> List[List[float]]:
    """单个 batch 的异步 embedding，带指数退避重试（最多 max_retries 次，对 429/5xx 退避）。"""
    async with semaphore:
        url = cfg.API_BASE_URL.rstrip("/") + "/v1/embeddings"
        payload = {"input": texts, "model": cfg.EMBEDDING_MODEL, "encoding_format": "float"}
        headers = {"Authorization": f"Bearer {cfg.API_KEY}"}
        for attempt in range(1, max_retries + 1):
            try:
                r = await client.post(url, json=payload, headers=headers)
                if r.status_code == 200:
                    return [d["embedding"] for d in r.json()["data"]]
                elif r.status_code == 429:
                    # TPM 限速：等待更长时间
                    wait = min(10 * (2 ** (attempt - 1)), 120)
                    logger.warning("TPM rate limit (429), retry %d/%d in %ds", attempt, max_retries, wait)
                    await asyncio.sleep(wait)
                elif r.status_code in (500, 502, 503, 504):
                    wait = min(5 * (2 ** (attempt - 1)), 60)
                    logger.warning("HTTP %d, retry %d/%d in %ds", r.status_code, attempt, max_retries, wait)
                    await asyncio.sleep(wait)
                else:
                    raise RuntimeError(f"HTTP {r.status_code}: {r.text[:200]}")
            except (httpx.TimeoutException, httpx.NetworkError) as e:
                wait = min(5 * (2 ** (attempt - 1)), 60)
                logger.warning("Network error %s, retry %d/%d in %ds", e, attempt, max_retries, wait)
                await asyncio.sleep(wait)
        raise RuntimeError(f"Embedding failed after {max_retries} retries")


async def embed_all_async(
    texts: List[str],
    batch_size: int = 64,
    concurrency: int = 8,
    cache: Optional[Dict[str, List[float]]] = None,
    cache_path: Optional[Path] = None,
    cache_save_every: int = 200,
) -> np.ndarray:
    """
    并发异步 embedding：把所有 texts embed 完，返回 np.ndarray。
    自动跳过 cache 中已有的 texts。
    """
    if cache is None:
        cache = {}

    results: List[Optional[List[float]]] = [None] * len(texts)
    to_fetch_idx: List[int] = []
    to_fetch_texts: List[str] = []

    # 命中缓存 / 空文本
    for i, t in enumerate(texts):
        if not t or not t.strip():
            results[i] = [0.0] * cfg.EMBEDDING_DIM
        else:
            h = _hash(t)
            if h in cache:
                results[i] = cache[h]
            else:
                to_fetch_idx.append(i)
                to_fetch_texts.append(t)

    if not to_fetch_texts:
        return np.asarray(results, dtype=np.float32)

    n_batches = (len(to_fetch_texts) + batch_size - 1) // batch_size
    logger.info("Embedding %d texts in %d batches (concurrency=%d, batch_size=%d)...",
                len(to_fetch_texts), n_batches, concurrency, batch_size)

    semaphore = asyncio.Semaphore(concurrency)
    t_start = time.perf_counter()
    completed = 0

    async with httpx.AsyncClient(trust_env=False, timeout=httpx.Timeout(120.0)) as client:
        # 切成 batch 列表
        batches: List[Tuple[int, List[int], List[str]]] = []
        for start in range(0, len(to_fetch_texts), batch_size):
            batch_texts = to_fetch_texts[start:start + batch_size]
            batch_idx = to_fetch_idx[start:start + batch_size]
            batches.append((start // batch_size, batch_idx, batch_texts))

        async def process_batch(b_num: int, b_idx: List[int], b_texts: List[str]):
            nonlocal completed
            vecs = await _embed_batch_async(client, b_texts, semaphore)
            for j, (idx, text, vec) in enumerate(zip(b_idx, b_texts, vecs)):
                results[idx] = vec
                cache[_hash(text)] = vec
            completed += 1
            # 进度
            elapsed = time.perf_counter() - t_start
            done_texts = completed * batch_size
            tps = done_texts / elapsed if elapsed > 0 else 0
            eta = (len(to_fetch_texts) - done_texts) / tps if tps > 0 else 0
            logger.info("  batch %d/%d  %.1f texts/s  ETA %.0fs",
                        completed, n_batches, tps, eta)
            # 增量落盘（原子写）
            if cache_path and completed % cache_save_every == 0:
                _atomic_write_json(cache_path, cache)
                logger.info("  cache snapshot: %d entries saved", len(cache))

        await asyncio.gather(*[process_batch(b, bi, bt) for b, bi, bt in batches])

    # 最终落盘（原子写）
    if cache_path:
        _atomic_write_json(cache_path, cache)
        logger.info("Cache saved: %d entries → %s", len(cache), cache_path)

    elapsed_total = time.perf_counter() - t_start
    logger.info("Embedding done: %d texts in %.1fs (%.1f texts/s)",
                len(to_fetch_texts), elapsed_total,
                len(to_fetch_texts) / elapsed_total if elapsed_total > 0 else 0)
    return np.asarray(results, dtype=np.float32)


# ============================================================
# 4. 归一化 + FAISS 建索引
# ============================================================

def build_faiss_index(
    chunks: List[Dict],
    embeddings: np.ndarray,
    conn: sqlite3.Connection,
) -> None:
    norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
    norms[norms == 0] = 1.0
    emb_norm = (embeddings / norms).astype(np.float32)

    index = faiss.IndexHNSWFlat(cfg.EMBEDDING_DIM, cfg.FAISS_M, faiss.METRIC_INNER_PRODUCT)
    index.hnsw.efConstruction = cfg.FAISS_EF_CONSTRUCT
    index.hnsw.efSearch = cfg.FAISS_EF_SEARCH
    index.add(emb_norm)
    logger.info("FAISS HNSW built: ntotal=%d", index.ntotal)

    cfg.INDEX_DIR.mkdir(parents=True, exist_ok=True)
    # Windows Unicode path fallback
    try:
        faiss.write_index(index, str(cfg.FAISS_INDEX_PATH))
    except RuntimeError:
        buf = faiss.serialize_index(index)
        with open(str(cfg.FAISS_INDEX_PATH), "wb") as f:
            f.write(bytes(buf))
    np.save(cfg.EMBEDDINGS_PATH, emb_norm)

    # 回填 embedding_idx
    cursor = conn.cursor()
    for i, c in enumerate(chunks):
        cursor.execute("UPDATE paper_chunks SET embedding_idx=? WHERE chunk_id=?", (i, c["chunk_id"]))
    conn.commit()

    chunk_ids = [c["chunk_id"] for c in chunks]
    with open(cfg.CHUNK_IDS_PATH, "w", encoding="utf-8") as f:
        json.dump(chunk_ids, f, ensure_ascii=False)
    logger.info("FAISS index saved → %s", cfg.FAISS_INDEX_PATH)
    logger.info("embeddings.npy saved → %s", cfg.EMBEDDINGS_PATH)


# ============================================================
# 5. BM25
# ============================================================

def tokenize_cn(text: str) -> List[str]:
    return [t for t in jieba.lcut_for_search(text.lower()) if t.strip()]


def build_bm25_index(chunks: List[Dict]) -> None:
    logger.info("Building BM25 index (%d chunks)...", len(chunks))
    tokenized = [tokenize_cn(c.get("title", "") + " " + c["content"]) for c in chunks]
    bm25 = BM25Okapi(tokenized)
    with open(cfg.BM25_INDEX_PATH, "wb") as f:
        pickle.dump({"bm25": bm25, "tokenized_corpus": tokenized,
                     "chunk_ids": [c["chunk_id"] for c in chunks]}, f)
    logger.info("BM25 saved → %s", cfg.BM25_INDEX_PATH)


# ============================================================
# 主流程
# ============================================================

def main():
    parser = argparse.ArgumentParser(description="高速 KB 索引构建器")
    parser.add_argument("--force", action="store_true", help="清空旧数据库重建")
    parser.add_argument("--incremental", action="store_true", help="只处理新增 chunks")
    parser.add_argument("--kb-json", default=None, help="指定 KB JSON 路径（默认用 config.KB_JSON_PATH）")
    parser.add_argument("--concurrency", type=int, default=4,
                        help="并发 embedding 请求数（默认 4，TPM 稳定；可试 8 但会更多 429）")
    parser.add_argument("--batch-size", type=int, default=64, help="每个请求的文本数（默认 64）")
    parser.add_argument("--bm25-only", action="store_true", help="只重建 BM25（已有 embedding 时用）")
    parser.add_argument("--use-api", action="store_true",
                        help="强制使用远程 API embedding（无视本地模型；适合无 GPU 时快速跑全量）")
    args = parser.parse_args()

    kb_json_path = Path(args.kb_json) if args.kb_json else cfg.KB_JSON_PATH
    logger.info("=" * 70)
    logger.info("Fast KB Ingest")
    logger.info("  kb_json:     %s", kb_json_path)
    logger.info("  concurrency: %d  batch_size: %d", args.concurrency, args.batch_size)
    logger.info("  mode:        %s", "incremental" if args.incremental else "force" if args.force else "normal")
    logger.info("=" * 70)

    conn = init_db(cfg.DB_PATH, force=args.force)

    # BM25-only 模式
    if args.bm25_only:
        conn.row_factory = sqlite3.Row
        rows = conn.execute(
            "SELECT c.chunk_id, c.paper_id, c.field_type, c.content, m.title "
            "FROM paper_chunks c JOIN papers_metadata m ON c.paper_id=m.paper_id"
        ).fetchall()
        chunks = [dict(r) for r in rows]
        build_bm25_index(chunks)
        conn.close()
        return

    # 加载 KB JSON
    t0 = time.perf_counter()
    with open(kb_json_path, "r", encoding="utf-8") as f:
        kb = json.load(f)
    logger.info("KB loaded: %d papers in %.1fs", len(kb), time.perf_counter()-t0)

    # 导入 metadata & chunks
    chunks = load_and_ingest(conn, kb, incremental=args.incremental)

    # incremental 模式下：若 DB 里所有 chunks 都在，但 embedding_idx 为空，也要重建 embedding
    if not chunks:
        # 检查是否有未 embed 的 chunks
        conn.row_factory = sqlite3.Row
        unembed = conn.execute(
            "SELECT c.chunk_id, c.paper_id, c.field_type, c.content, m.title "
            "FROM paper_chunks c JOIN papers_metadata m ON c.paper_id=m.paper_id "
            "WHERE c.embedding_idx IS NULL"
        ).fetchall()
        if unembed:
            logger.info("Found %d chunks with NULL embedding_idx, embedding them...", len(unembed))
            chunks = [dict(r) for r in unembed]
        else:
            logger.info("所有 chunks 已 embed，仅重建 FAISS + BM25")
            # 读所有 chunks 重建索引
            all_chunks = conn.execute(
                "SELECT c.chunk_id, c.paper_id, c.field_type, c.content, m.title "
                "FROM paper_chunks c JOIN papers_metadata m ON c.paper_id=m.paper_id "
                "ORDER BY c.embedding_idx"
            ).fetchall()
            chunks = [dict(r) for r in all_chunks]
            # 直接从 embeddings.npy 重建（不重新 embed）
            if cfg.EMBEDDINGS_PATH.exists():
                embeddings = np.load(str(cfg.EMBEDDINGS_PATH))
                if len(embeddings) == len(chunks):
                    build_faiss_index(chunks, embeddings, conn)
                    build_bm25_index(chunks)
                    conn.close()
                    logger.info("Done! (reused existing embeddings.npy)")
                    return
            logger.info("No valid embeddings.npy, need full re-embed")
            # fall through to re-embed all

    # ── Embedding（本地模型优先，API 兜底）──────────────────────────────
    emb_client = get_client() if not args.use_api else None
    texts = [c["content"] for c in chunks]

    if emb_client is not None and isinstance(emb_client, LocalEmbeddingClient):
        # 本地模型：直接调用，无 TPM 限制
        logger.info("Using LOCAL BGE-M3 (retrieval_weights/models/bge-m3/) — no rate limit")
        embeddings = emb_client.embed(texts)
    else:
        # 远程 API：异步并发 + 断点续传
        logger.info("Using REMOTE API (concurrency=%d, batch=%d)",
                    args.concurrency, args.batch_size)
        cache_path = cfg.INDEX_DIR / "embedding_cache.json"
        cache: Dict[str, List[float]] = {}
        if cache_path.exists():
            try:
                with open(cache_path, encoding="utf-8") as f:
                    cache = json.load(f)
                logger.info("Loaded %d cached embeddings", len(cache))
            except Exception as e:
                logger.warning("Cache load failed: %s", e)

        embeddings = asyncio.run(
            embed_all_async(
                texts,
                batch_size=args.batch_size,
                concurrency=args.concurrency,
                cache=cache,
                cache_path=cache_path,
                cache_save_every=200,
            )
        )

    # FAISS + BM25
    build_faiss_index(chunks, embeddings, conn)
    build_bm25_index(chunks)

    conn.close()
    logger.info("=" * 70)
    logger.info("Done!")
    logger.info("  DB:   %s", cfg.DB_PATH)
    logger.info("  FAISS:%s", cfg.FAISS_INDEX_PATH)
    logger.info("  BM25: %s", cfg.BM25_INDEX_PATH)
    logger.info("=" * 70)


if __name__ == "__main__":
    main()
