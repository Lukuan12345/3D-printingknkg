#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
quick_start.py - 快速开始示例

演示如何使用kb_mvp进行单次查询
"""

import sys
from pathlib import Path

# 添加项目路径
KB_MVP_ROOT = Path(__file__).resolve().parent
PROJECT_ROOT = KB_MVP_ROOT.parent
sys.path.insert(0, str(PROJECT_ROOT))
sys.path.insert(0, str(KB_MVP_ROOT))

from src import config
from src.searcher import HybridSearcher
from src.query_structurizer import QueryStructurizer
from src.answer_generator import AnswerGenerator
from src.result_clusterer import ResultClusterer


def main():
    """快速开始示例"""
    print("="*70)
    print("KB_MVP 快速开始示例")
    print("="*70)

    # 启用三路融合
    config.ENABLE_THREE_WAY_FUSION = True

    # 初始化组件
    print("\n[1/5] 初始化组件...")
    searcher = HybridSearcher()
    structurizer = QueryStructurizer()
    clusterer = ResultClusterer()
    generator = AnswerGenerator()

    # 用户问题
    question = "FR4基板X波段吸波体设计如何优化？"
    print(f"\n[2/5] 用户问题: {question}")

    # Step 1: 结构化查询
    print("\n[3/5] 结构化查询...")
    query_json = structurizer.structurize(question)
    print(f"  结构化结果:")
    print(f"    - 核心主题: {query_json.get('core_topic', 'N/A')}")
    print(f"    - 频段: {query_json.get('operating_frequency_range', 'N/A')}")
    print(f"    - 材料: {query_json.get('substrate_material', 'N/A')}")
    print(f"    - 结构: {query_json.get('structure_class', 'N/A')}")

    # Step 2: 三路融合检索
    print("\n[4/5] 三路融合检索...")
    result = searcher.search(
        query=query_json.get('core_topic', question),
        query_json=query_json,
        top_k=5
    )

    print(f"  检索统计:")
    print(f"    - Metadata召回: {result['stats'].get('metadata_count', 0)} 篇")
    print(f"    - Dense召回: {result['stats'].get('dense_count', 0)} 个chunks")
    print(f"    - Sparse召回: {result['stats'].get('sparse_count', 0)} 个chunks")
    print(f"    - 融合后Top-5:")

    for i, chunk in enumerate(result['top_k'][:5], 1):
        print(f"      [{i}] {chunk['paper_id']} (score={chunk['fused_score']:.3f})")
        print(f"          Metadata={chunk.get('metadata_score', 0):.2f}, "
              f"Dense={chunk.get('dense_score', 0):.2f}, "
              f"Sparse={chunk.get('sparse_score', 0):.2f}")

    # Step 3: 聚类展示
    clustered = clusterer.cluster_by_match_pattern(result['top_k'])
    summary = clusterer.get_summary(clustered)
    print(f"\n  聚类统计:")
    print(f"    - 全匹配: {summary['full_match_count']} 篇")
    print(f"    - 材料/频段匹配: {summary['material_freq_count']} 篇")
    print(f"    - 纯语义匹配: {summary['semantic_only_count']} 篇")

    # Step 4: 生成回答
    print("\n[5/5] 生成综合回答...")
    answer = generator.generate(
        question=question,
        query_json=query_json,
        top_chunks=result['top_k'][:5]
    )

    # 输出回答
    print("\n" + "="*70)
    print("综合技术回答")
    print("="*70)
    print(f"\n{answer['answer']}\n")

    print(f"关键发现:")
    for i, finding in enumerate(answer.get('key_findings', []), 1):
        print(f"  {i}. {finding}")

    print(f"\n知识库局限:")
    print(f"  {answer.get('limitations', 'N/A')}")

    print(f"\n置信度: {answer.get('confidence', 0.0):.2f}")

    print(f"\n引用来源:")
    for cite in answer.get('citation_details', []):
        print(f"  [{cite['id']}] {cite['paper_id']} - {cite['title']}")
        print(f"      融合分数={cite['fused_score']:.3f}")

    print("\n" + "="*70)
    print("[OK] 快速开始示例完成！")
    print("="*70)


if __name__ == '__main__':
    main()
