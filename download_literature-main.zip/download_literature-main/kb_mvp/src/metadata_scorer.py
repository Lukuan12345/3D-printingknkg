#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
metadata_scorer.py - Metadata打分器（Phase 3核心）

功能：
1. 在papers_metadata.extracted_schema上进行精确匹配打分
2. 频段区间重叠计算
3. 材料/结构精确+模糊匹配
4. 记录matched_fields详情
5. 返回每个paper的metadata_score

"""

import re
import json
import sqlite3
import logging
import sys
from pathlib import Path
from typing import Dict, List, Tuple, Any, Optional
from dataclasses import dataclass

# 添加项目路径
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from kb_mvp.src.config import DB_PATH

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)


@dataclass
class MetadataScore:
    """Metadata打分结果"""
    paper_id: str
    score: float                           # 总分（0-1）
    matched_fields: Dict[str, Any]         # 匹配的字段详情
    field_scores: Dict[str, float]         # 各字段得分


class MetadataScorer:
    """
    Metadata打分器

    在papers_metadata.extracted_schema上进行结构化字段匹配打分
    """

    def __init__(self, db_path: Optional[Path] = None):
        """
        初始化Metadata打分器

        Args:
            db_path: 数据库路径
        """
        self.db_path = db_path or DB_PATH

        # 字段权重配置
        self.field_weights = {
            'operating_frequency_range': 0.35,  # 频段最重要
            'substrate_material': 0.25,         # 材料次之
            'conductor_material': 0.10,
            'structure_class': 0.20,            # 结构类型重要
            'dominant_mechanism': 0.10,
        }

    def score(self,
              query_json: Dict[str, Any],
              top_k: int = 30) -> List[MetadataScore]:
        """
        为查询打分，返回Top-K论文

        Args:
            query_json: 结构化查询JSON
            top_k: 返回前K个

        Returns:
            MetadataScore列表（按分数降序）
        """
        logger.info(f"Metadata scoring for query...")

        # 连接数据库
        conn = sqlite3.connect(self.db_path, check_same_thread=False)
        cur = conn.cursor()

        # 读取所有论文的extracted_schema
        cur.execute("""
            SELECT paper_id, extracted_schema
            FROM papers_metadata
            WHERE extracted_schema IS NOT NULL
        """)

        rows = cur.fetchall()
        conn.close()

        if not rows:
            logger.warning("No papers with extracted_schema found")
            return []

        # 逐个论文打分
        scores = []
        for paper_id, schema_json in rows:
            try:
                paper_schema = json.loads(schema_json)
                score_result = self._score_single(query_json, paper_id, paper_schema)
                if score_result.score > 0:  # 只保留有分数的
                    scores.append(score_result)
            except json.JSONDecodeError:
                logger.warning(f"Invalid JSON in {paper_id}, skipped")
                continue

        # 按分数降序排序
        scores.sort(key=lambda x: x.score, reverse=True)

        logger.info(f"Metadata scored {len(scores)} papers, returning top {top_k}")

        return scores[:top_k]

    def _score_single(self,
                     query_json: Dict[str, Any],
                     paper_id: str,
                     paper_schema: Dict[str, Any]) -> MetadataScore:
        """
        为单个论文打分

        Args:
            query_json: 查询JSON
            paper_id: 论文ID
            paper_schema: 论文的extracted_schema

        Returns:
            MetadataScore
        """
        total_score = 0.0
        matched_fields = {}
        field_scores = {}

        # 1. 频段匹配
        if 'operating_frequency_range' in query_json:
            score = self._match_frequency(
                query_json['operating_frequency_range'],
                paper_schema.get('operating_frequency_range', [])
            )
            if score > 0:
                field_scores['operating_frequency_range'] = score
                matched_fields['operating_frequency_range'] = paper_schema.get('operating_frequency_range', [])
                total_score += score * self.field_weights['operating_frequency_range']

        # 2. 基板材料匹配
        if 'substrate_material' in query_json:
            score = self._match_material(
                query_json['substrate_material'],
                paper_schema.get('substrate_material', [])
            )
            if score > 0:
                field_scores['substrate_material'] = score
                matched_fields['substrate_material'] = paper_schema.get('substrate_material', [])
                total_score += score * self.field_weights['substrate_material']

        # 3. 导体材料匹配
        if 'conductor_material' in query_json:
            score = self._match_material(
                query_json['conductor_material'],
                paper_schema.get('conductor_material', [])
            )
            if score > 0:
                field_scores['conductor_material'] = score
                matched_fields['conductor_material'] = paper_schema.get('conductor_material', [])
                total_score += score * self.field_weights['conductor_material']

        # 4. 结构类型匹配
        if 'structure_class' in query_json:
            score = self._match_structure(
                query_json['structure_class'],
                paper_schema.get('structure_class', [])
            )
            if score > 0:
                field_scores['structure_class'] = score
                matched_fields['structure_class'] = paper_schema.get('structure_class', [])
                total_score += score * self.field_weights['structure_class']

        # 5. 主导机理匹配
        if 'dominant_mechanism' in query_json:
            score = self._match_mechanism(
                query_json['dominant_mechanism'],
                paper_schema.get('dominant_mechanism', [])
            )
            if score > 0:
                field_scores['dominant_mechanism'] = score
                matched_fields['dominant_mechanism'] = paper_schema.get('dominant_mechanism', [])
                total_score += score * self.field_weights['dominant_mechanism']

        return MetadataScore(
            paper_id=paper_id,
            score=min(total_score, 1.0),  # 归一化到[0,1]
            matched_fields=matched_fields,
            field_scores=field_scores
        )

    def _match_frequency(self, query_freq: Any, paper_freq: Any) -> float:
        """
        频段匹配（支持区间重叠计算）

        Args:
            query_freq: 查询频段（可能是字符串或列表）
            paper_freq: 论文频段

        Returns:
            匹配分数（0-1）
        """
        # 转换为列表
        query_ranges = self._normalize_to_list(query_freq)
        paper_ranges = self._normalize_to_list(paper_freq)

        if not query_ranges or not paper_ranges:
            return 0.0

        # 提取频段范围
        max_overlap = 0.0

        for q_range in query_ranges:
            q_low, q_high = self._parse_frequency_range(q_range)
            if q_low is None:
                continue

            for p_range in paper_ranges:
                p_low, p_high = self._parse_frequency_range(p_range)
                if p_low is None:
                    continue

                # 计算重叠率
                overlap = self._calculate_overlap(q_low, q_high, p_low, p_high)
                max_overlap = max(max_overlap, overlap)

        return max_overlap

    def _parse_frequency_range(self, freq_str: str) -> Tuple[Optional[float], Optional[float]]:
        """
        解析频段字符串

        支持格式：
        - "8-12 GHz"
        - "X-band"（转换为8-12 GHz）
        - "10 GHz"（单点频率）

        Returns:
            (low_ghz, high_ghz) 或 (None, None)
        """
        if not isinstance(freq_str, str):
            return None, None

        # 波段映射
        band_map = {
            'L-band': (1, 2),
            'S-band': (2, 4),
            'C-band': (4, 8),
            'X-band': (8, 12),
            'Ku-band': (12, 18),
            'K-band': (18, 27),
            'Ka-band': (27, 40),
            'V-band': (40, 75),
            'W-band': (75, 110),
        }

        freq_str = freq_str.strip()

        # 检查是否是波段名称
        for band_name, (low, high) in band_map.items():
            if band_name.lower() in freq_str.lower():
                return float(low), float(high)

        # 解析数值范围（如 "8-12 GHz"）
        # 匹配模式：数字-数字 GHz/MHz/THz
        match = re.search(r'([\d.]+)\s*[-–~]\s*([\d.]+)\s*(GHz|MHz|THz)', freq_str, re.IGNORECASE)
        if match:
            low = float(match.group(1))
            high = float(match.group(2))
            unit = match.group(3).lower()

            # 单位转换为GHz
            if unit == 'mhz':
                low /= 1000
                high /= 1000
            elif unit == 'thz':
                low *= 1000
                high *= 1000

            return low, high

        # 单点频率（如 "10 GHz"）
        match = re.search(r'([\d.]+)\s*(GHz|MHz|THz)', freq_str, re.IGNORECASE)
        if match:
            freq = float(match.group(1))
            unit = match.group(2).lower()

            if unit == 'mhz':
                freq /= 1000
            elif unit == 'thz':
                freq *= 1000

            # 单点频率视为±10%范围
            return freq * 0.9, freq * 1.1

        return None, None

    def _calculate_overlap(self, q_low: float, q_high: float,
                          p_low: float, p_high: float) -> float:
        """
        计算两个频段区间的重叠率

        Args:
            q_low, q_high: 查询频段范围
            p_low, p_high: 论文频段范围

        Returns:
            重叠率（0-1）
        """
        # 计算重叠区间
        overlap_low = max(q_low, p_low)
        overlap_high = min(q_high, p_high)

        if overlap_high <= overlap_low:
            return 0.0  # 无重叠

        overlap_width = overlap_high - overlap_low
        query_width = q_high - q_low

        # 重叠率 = 重叠宽度 / 查询宽度
        return min(overlap_width / query_width, 1.0)

    def _match_material(self, query_materials: Any, paper_materials: Any) -> float:
        """
        材料匹配（精确+模糊）

        Args:
            query_materials: 查询材料
            paper_materials: 论文材料

        Returns:
            匹配分数（0-1）
        """
        query_list = self._normalize_to_list(query_materials)
        paper_list = self._normalize_to_list(paper_materials)

        if not query_list or not paper_list:
            return 0.0

        # 精确匹配
        query_set = {m.lower().strip() for m in query_list if isinstance(m, str)}
        paper_set = {m.lower().strip() for m in paper_list if isinstance(m, str)}

        exact_matches = query_set & paper_set
        if exact_matches:
            return 1.0  # 精确匹配得满分

        # 模糊匹配（包含关系）
        for q in query_set:
            for p in paper_set:
                if q in p or p in q:
                    return 0.7  # 模糊匹配得0.7分

        return 0.0

    def _match_structure(self, query_structures: Any, paper_structures: Any) -> float:
        """
        结构类型匹配

        Args:
            query_structures: 查询结构
            paper_structures: 论文结构

        Returns:
            匹配分数（0-1）
        """
        query_list = self._normalize_to_list(query_structures)
        paper_list = self._normalize_to_list(paper_structures)

        if not query_list or not paper_list:
            return 0.0

        query_set = {s.lower().strip() for s in query_list if isinstance(s, str)}
        paper_set = {s.lower().strip() for s in paper_list if isinstance(s, str)}

        # 精确匹配
        exact_matches = query_set & paper_set
        if exact_matches:
            return 1.0

        # 关键词匹配
        # 例如: "metamaterial absorber" 包含 "absorber"
        for q in query_set:
            for p in paper_set:
                if q in p or p in q:
                    return 0.8

        return 0.0

    def _match_mechanism(self, query_mechanisms: Any, paper_mechanisms: Any) -> float:
        """
        主导机理匹配

        Args:
            query_mechanisms: 查询机理
            paper_mechanisms: 论文机理

        Returns:
            匹配分数（0-1）
        """
        # 与结构类型匹配类似
        return self._match_structure(query_mechanisms, paper_mechanisms)

    def _normalize_to_list(self, value: Any) -> List[str]:
        """
        将输入规范化为字符串列表

        Args:
            value: 可能是字符串、列表或其他类型

        Returns:
            字符串列表
        """
        if value is None:
            return []
        if isinstance(value, str):
            return [value]
        if isinstance(value, list):
            return [str(v) for v in value if v]
        return [str(value)]


def main():
    """测试Metadata打分器"""
    print("="*70)
    print("Metadata打分器测试")
    print("="*70)

    # 初始化
    scorer = MetadataScorer()

    # 测试查询
    test_query = {
        'operating_frequency_range': '8-12 GHz',
        'substrate_material': ['FR4'],
        'structure_class': ['metamaterial absorber']
    }

    print(f"\n测试查询:")
    print(f"  频段: {test_query['operating_frequency_range']}")
    print(f"  材料: {test_query['substrate_material']}")
    print(f"  结构: {test_query['structure_class']}")

    # 打分
    print(f"\n开始Metadata打分...")
    results = scorer.score(test_query, top_k=10)

    print(f"\n得分Top-10论文:")
    print(f"{'='*70}")

    for i, result in enumerate(results, 1):
        print(f"\n[{i}] {result.paper_id}")
        print(f"  总分: {result.score:.3f}")
        print(f"  匹配字段:")
        for field, value in result.matched_fields.items():
            score = result.field_scores.get(field, 0.0)
            print(f"    - {field}: {value} (score={score:.2f})")

    if results:
        print(f"\n{'='*70}")
        print(f"[OK] 找到 {len(results)} 个匹配论文")
        print(f"最高分: {results[0].score:.3f}")
        print(f"{'='*70}")
    else:
        print(f"\n[WARN] 未找到匹配论文")

    print(f"\n[OK] Metadata打分器测试完成！")


if __name__ == '__main__':
    main()
