#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
config.py —— kb_mvp 全局配置（融合版）

合并到主项目后：
- 路径根改为主项目根目录
- KB JSON 默认指向 scientific_kgqa/data/knowledge_base.json
- Schema CSV 指向 scientific_kgqa/data/schema.csv
- API base_url / api_key 优先读环境变量 LKE_LLM_BASE_URL / LKE_LLM_API_KEY，
  无 env 时退回硬编码（仅本地开发用）
"""

import os
from pathlib import Path


# ============================================================
# 路径
# ============================================================

KB_MVP_ROOT = Path(__file__).resolve().parent.parent          # .../kb_mvp
PROJECT_ROOT = KB_MVP_ROOT.parent                              # 主项目根

DATA_DIR   = KB_MVP_ROOT / "data"
INDEX_DIR  = KB_MVP_ROOT / "index"
SRC_DIR    = KB_MVP_ROOT / "src"

DB_PATH          = DATA_DIR  / "kb.db"
EMBEDDINGS_PATH  = INDEX_DIR / "embeddings.npy"
FAISS_INDEX_PATH = INDEX_DIR / "faiss.index"
BM25_INDEX_PATH  = INDEX_DIR / "bm25.pkl"
CHUNK_IDS_PATH   = INDEX_DIR / "chunk_ids.json"   # embedding_idx → chunk_id

# 数据源：与 scientific_kgqa 共用同一份 KB JSON / schema
KB_JSON_PATH    = PROJECT_ROOT / "scientific_kgqa" / "data" / "knowledge_base.json"
SCHEMA_CSV_PATH = PROJECT_ROOT / "scientific_kgqa" / "data" / "schema.csv"
QUERY_JSON_PATH = KB_MVP_ROOT / "tests" / "test_query.json"
RESULT_DIR      = KB_MVP_ROOT / "results"


# ============================================================
# API（embedding 服务专用，固定到 35.220 网关，不与 LLM 共用 base_url）
# ============================================================

# embedding 服务（BGE-M3）固定在 35.220 网关，不读 LKE_LLM_BASE_URL
# 避免被 KG/LLM 的环境变量污染（KG LLM 用 sohoyo，embedding 用 35.220）
API_BASE_URL = os.environ.get(
    "EMBED_BASE_URL",
    os.environ.get("LKE_EMBED_BASE_URL", "http://35.220.164.252:3888"),
)
API_KEY = os.environ.get(
    "EMBED_API_KEY",
    os.environ.get("LKE_EMBED_API_KEY", ""),
)

# LLM 服务（用于 QueryStructurizer、AnswerGenerator 等）
# 独立于 embedding API，通常指向 sohoyo 或其他 LLM 网关
LLM_BASE_URL = os.environ.get(
    "LLM_BASE_URL",
    os.environ.get("LKE_LLM_BASE_URL", ""),
)
LLM_API_KEY = os.environ.get(
    "LLM_API_KEY",
    os.environ.get("LKE_LLM_API_KEY", ""),
)

EMBEDDING_MODEL = "BAAI/bge-m3"
EMBEDDING_DIM   = 1024
# 本地模型（CPU）最优 batch=128；GPU 时可改 256；API 模式用 64
EMBEDDING_BATCH_SIZE = 64

# "auto"（默认）= 本地模型存在则用本地，否则 API；"local" = 强制本地；"api" = 强制 API
EMBED_MODE = os.environ.get("EMBED_MODE", "auto")

CHAT_MODEL = "claude-sonnet-4-6"


# ============================================================
# 分块策略 —— 对应 paper_chunks.field_type
# ============================================================

CHUNK_FIELDS = [
    "problem_context",
    "study_process_description",
    "design_optimization_logic",
    "physical_mechanism",
    "fabrication_process",
    "design_method",
    "influence_analysis",
]


# ============================================================
# FAISS 参数
# ============================================================

FAISS_M          = 32
FAISS_EF_CONSTRUCT = 200
FAISS_EF_SEARCH  = 64


# ============================================================
# 混合检索权重
# ============================================================

# 旧版（两路）
WEIGHT_DENSE  = 0.7
WEIGHT_SPARSE = 0.3

# 新版（三路融合）
ENABLE_THREE_WAY_FUSION = True
WEIGHT_METADATA = 0.2
WEIGHT_DENSE_V2 = 0.6
WEIGHT_SPARSE_V2 = 0.2

TOP_K_DENSE   = 20
TOP_K_SPARSE  = 20
TOP_K_METADATA = 30
TOP_K_FINAL   = 10


# ============================================================
# Schema约束配置
# ============================================================

USE_SCHEMA_CONSTRAINT = True
SCHEMA_MAX_CLUSTERS = 5
SCHEMA_MAX_FIELDS_PER_CLUSTER = 8

ENABLE_CLUSTER_EXPANSION = True
MAX_EXPANDED_KEYWORDS = 10
