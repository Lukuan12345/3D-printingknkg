#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
result_clusterer.py - 结果聚类器（Phase 4）

功能：
1. 按匹配模式对检索结果分组
2. 分组类型：
   - 全匹配：metadata + dense + sparse都命中
   - 材料频段匹配：metadata命中 + dense或sparse命中
   - 纯语义匹配：只有dense/sparse命中，无metadata
3. 生成分组展示的Markdown格式

用法：
    clusterer = ResultClusterer()
    clustered = clusterer.cluster_by_match_pattern(results)
"""

import logging
from typing import List, Dict, Any
from collections import defaultdict

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)


class ResultClusterer:
    """
    结果聚类器

    按匹配模式对检索结果分组展示
    """

    def __init__(self):
        pass

    def cluster_by_match_pattern(self, results: List[Dict[str, Any]]) -> Dict[str, List[Dict]]:
        """
        按匹配模式分组

        Args:
            results: 检索结果列表

        Returns:
            {
                "full_match": [...],      # 全匹配
                "material_freq": [...],   # 材料频段匹配
                "semantic_only": [...]    # 纯语义匹配
            }
        """
        clustered = {
            "full_match": [],      # metadata + dense + sparse
            "material_freq": [],   # metadata + (dense or sparse)
            "semantic_only": []    # dense or sparse only
        }

        for result in results:
            # 判断匹配类型
            has_metadata = result.get('metadata_score', 0.0) > 0
            has_dense = result.get('dense_score', 0.0) > 0
            has_sparse = result.get('sparse_score', 0.0) > 0

            if has_metadata and has_dense and has_sparse:
                clustered["full_match"].append(result)
            elif has_metadata and (has_dense or has_sparse):
                clustered["material_freq"].append(result)
            else:
                clustered["semantic_only"].append(result)

        logger.info(f"Clustered results: full={len(clustered['full_match'])}, "
                   f"material_freq={len(clustered['material_freq'])}, "
                   f"semantic_only={len(clustered['semantic_only'])}")

        return clustered

    def render_markdown(self, clustered: Dict[str, List[Dict]]) -> str:
        """
        渲染为Markdown格式

        Args:
            clustered: 聚类后的结果

        Returns:
            Markdown文本
        """
        lines = []

        # 1. 全匹配组
        if clustered["full_match"]:
            lines.append("### 🎯 全匹配论文（Metadata + 语义双重验证）\n")
            lines.append("这些论文同时满足：结构化字段精确匹配 + 语义相似度高\n")

            for i, result in enumerate(clustered["full_match"], 1):
                lines.append(f"#### [{i}] {result['paper_id']} - {result.get('title', 'N/A')}\n")
                lines.append(f"**融合得分**: {result['fused_score']:.3f} "
                           f"(Metadata={result.get('metadata_score', 0):.2f}, "
                           f"Dense={result.get('dense_score', 0):.2f}, "
                           f"Sparse={result.get('sparse_score', 0):.2f})\n")

                # Metadata匹配详情
                if result.get('metadata_detail') and result['metadata_detail'].get('matched_fields'):
                    lines.append("\n**Metadata匹配字段**:")
                    for field, value in result['metadata_detail']['matched_fields'].items():
                        score = result['metadata_detail']['field_scores'].get(field, 0.0)
                        if isinstance(value, list):
                            value_str = ', '.join(str(v) for v in value[:3])
                            if len(value) > 3:
                                value_str += f" (+{len(value)-3} more)"
                        else:
                            value_str = str(value)
                        lines.append(f"- {field}: {value_str} (score={score:.2f})")

                lines.append(f"\n**内容片段**: {result.get('content', '')[:200]}...\n")
                lines.append("---\n")

        # 2. 材料频段匹配组
        if clustered["material_freq"]:
            lines.append("\n### 📦 材料/频段匹配论文（结构化字段命中）\n")
            lines.append("这些论文满足材料、频段等结构化字段匹配，但语义相似度可能较低\n")

            for i, result in enumerate(clustered["material_freq"], 1):
                lines.append(f"#### [{i}] {result['paper_id']} - {result.get('title', 'N/A')}\n")
                lines.append(f"**融合得分**: {result['fused_score']:.3f} "
                           f"(Metadata={result.get('metadata_score', 0):.2f})\n")

                # Metadata匹配详情
                if result.get('metadata_detail') and result['metadata_detail'].get('matched_fields'):
                    lines.append("\n**匹配字段**: ")
                    fields = list(result['metadata_detail']['matched_fields'].keys())
                    lines.append(', '.join(fields))

                lines.append(f"\n**内容片段**: {result.get('content', '')[:200]}...\n")
                lines.append("---\n")

        # 3. 纯语义匹配组
        if clustered["semantic_only"]:
            lines.append("\n### 🔍 纯语义匹配论文（关键词/主题相关）\n")
            lines.append("这些论文在语义上相关，但结构化字段可能不匹配\n")

            for i, result in enumerate(clustered["semantic_only"], 1):
                lines.append(f"#### [{i}] {result['paper_id']} - {result.get('title', 'N/A')}\n")
                lines.append(f"**融合得分**: {result['fused_score']:.3f} "
                           f"(Dense={result.get('dense_score', 0):.2f}, "
                           f"Sparse={result.get('sparse_score', 0):.2f})\n")
                lines.append(f"\n**内容片段**: {result.get('content', '')[:200]}...\n")
                lines.append("---\n")

        return "\n".join(lines)

    def get_summary(self, clustered: Dict[str, List[Dict]]) -> Dict[str, Any]:
        """
        获取聚类统计摘要

        Args:
            clustered: 聚类后的结果

        Returns:
            统计摘要字典
        """
        return {
            "full_match_count": len(clustered["full_match"]),
            "material_freq_count": len(clustered["material_freq"]),
            "semantic_only_count": len(clustered["semantic_only"]),
            "total": sum(len(v) for v in clustered.values())
        }


def main():
    """测试结果聚类器"""
    print("="*70)
    print("结果聚类器测试")
    print("="*70)

    # 模拟测试数据
    test_results = [
        {
            "paper_id": "P001",
            "title": "FR4 X-band Absorber",
            "fused_score": 0.95,
            "metadata_score": 0.9,
            "dense_score": 0.8,
            "sparse_score": 0.7,
            "content": "This paper presents a metamaterial absorber...",
            "metadata_detail": {
                "matched_fields": {
                    "substrate_material": ["FR4"],
                    "operating_frequency_range": ["8-12 GHz"]
                },
                "field_scores": {
                    "substrate_material": 1.0,
                    "operating_frequency_range": 1.0
                }
            }
        },
        {
            "paper_id": "P002",
            "title": "Rogers Substrate Study",
            "fused_score": 0.6,
            "metadata_score": 0.5,
            "dense_score": 0.0,
            "sparse_score": 0.3,
            "content": "This study focuses on Rogers substrate...",
            "metadata_detail": {
                "matched_fields": {
                    "substrate_material": ["Rogers 5880"]
                },
                "field_scores": {
                    "substrate_material": 0.7
                }
            }
        },
        {
            "paper_id": "P003",
            "title": "Antenna Design Methods",
            "fused_score": 0.4,
            "metadata_score": 0.0,
            "dense_score": 0.6,
            "sparse_score": 0.5,
            "content": "Various antenna design methodologies are discussed...",
        }
    ]

    # 聚类
    clusterer = ResultClusterer()
    clustered = clusterer.cluster_by_match_pattern(test_results)

    # 统计
    summary = clusterer.get_summary(clustered)
    print(f"\n聚类统计:")
    print(f"  全匹配: {summary['full_match_count']} 篇")
    print(f"  材料频段匹配: {summary['material_freq_count']} 篇")
    print(f"  纯语义匹配: {summary['semantic_only_count']} 篇")
    print(f"  总计: {summary['total']} 篇")

    # 渲染Markdown
    print(f"\nMarkdown渲染（前500字符）:")
    print("="*70)
    markdown = clusterer.render_markdown(clustered)
    print(markdown[:500])
    print("...")

    print(f"\n{'='*70}")
    print("[OK] 结果聚类器测试完成！")
    print(f"{'='*70}")


if __name__ == '__main__':
    main()
