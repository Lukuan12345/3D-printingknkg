#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
query_structurizer.py - 查询结构化器（Schema约束版）

功能：
1. 将自然语言问题转换为符合schema标准的结构化查询JSON
2. 注入Schema约束到LLM Prompt
3. 集成聚类关键词扩展
4. 字段名100%对齐refined_schema_200_2_cleaned.csv

用法：
    structurizer = QueryStructurizer()
    query_json = structurizer.structurize("FR4基板X波段吸波体设计")
"""

import sys
import json
import logging
from pathlib import Path
from typing import Dict, Any, Optional

# 添加项目路径
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from kb_mvp.src.schema_loader import SchemaLoader
from kb_mvp.src.config import (
    SCHEMA_MAX_CLUSTERS, SCHEMA_MAX_FIELDS_PER_CLUSTER,
    USE_SCHEMA_CONSTRAINT
)
from literature_knowledge_extractor.llm_client import call_llm
from literature_knowledge_extractor.config import DEFAULT_CONFIG

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)


class QueryStructurizer:
    """
    查询结构化器（Schema约束版）

    将用户的自然语言技术问题转换为符合schema标准的结构化JSON
    """

    def __init__(self,
                 schema_loader: Optional[SchemaLoader] = None,
                 use_schema_constraint: bool = True):
        """
        初始化查询结构化器

        Args:
            schema_loader: Schema加载器（如果不提供则自动创建）
            use_schema_constraint: 是否使用Schema约束
        """
        self.use_schema_constraint = use_schema_constraint

        # 加载Schema
        if schema_loader is None:
            self.schema_loader = SchemaLoader()
        else:
            self.schema_loader = schema_loader

        # 配置LLM API
        llm_config = DEFAULT_CONFIG.get('llm', {})
        self.api_base_url = llm_config.get('base_url')
        self.api_key = llm_config.get('api_key')
        self.model_name = llm_config.get('model_name')

        logger.info(f"QueryStructurizer initialized (use_schema={use_schema_constraint})")

    def _build_system_prompt(self) -> str:
        """构建System Prompt"""

        if self.use_schema_constraint:
            # 使用Schema约束
            schema_constraint = self.schema_loader.build_constraint_prompt(
                max_clusters=SCHEMA_MAX_CLUSTERS,
                max_fields_per_cluster=SCHEMA_MAX_FIELDS_PER_CLUSTER
            )
        else:
            # 不使用Schema约束（旧版）
            schema_constraint = ""

        system_prompt = f"""你是科学/技术文献领域的专家。你的任务是将用户的自然语言技术问题转换为结构化的查询JSON。

{schema_constraint}

# 输出格式要求

严格按照以下JSON格式输出，字段名必须100%精确匹配上述schema：

{{
  "core_topic": "一句话概括查询核心（20字内）",
  "<schema字段名>": "对应取值（或字符串数组）",
  "search_keywords_cn": ["中文关键词数组"],
  "search_keywords_en": ["英文关键词数组"]
}}

# 关键规则

1. **字段名精确匹配**：必须使用上方 schema 中定义的英文字段名，不能自创
2. **值标准化**：使用领域内的标准缩写 / 标准术语 / 统一单位格式
3. **完整性**：尽可能从问题中提取所有相关字段
4. **省略原则**：未提及的字段直接省略，不要填null或空数组
5. **关键词丰富**：search_keywords要覆盖核心技术点，包括同义词、相关术语

# 示例（格式示意，字段名以上方 schema 为准）

输入：<某领域的一个技术问题，含若干技术参数>

输出：
{{
  "core_topic": "<一句话核心>",
  "<schema字段A>": "<取值>",
  "<schema字段B>": ["<取值1>", "<取值2>"],
  "search_keywords_cn": ["<中文关键词1>", "<中文关键词2>"],
  "search_keywords_en": ["<英文关键词1>", "<英文关键词2>"]
}}
"""
        return system_prompt

    def _build_user_prompt(self, question: str) -> str:
        """构建User Prompt"""
        return f"""# 用户技术问题

{question}

---

请将上述问题转换为结构化查询JSON。记住：
1. 字段名必须精确匹配schema定义
2. 提取所有可识别的技术参数
3. 关键词要丰富全面

请输出JSON："""

    def structurize(self, question: str) -> Dict[str, Any]:
        """
        将自然语言问题转换为结构化查询JSON

        Args:
            question: 用户的自然语言技术问题

        Returns:
            结构化查询JSON（字段名符合schema标准）
        """
        logger.info(f"Structurizing query: {question[:50]}...")

        # 构建Prompt
        system_prompt = self._build_system_prompt()
        user_prompt = self._build_user_prompt(question)

        # 调用LLM
        try:
            response = call_llm(
                prompt=user_prompt,
                system_prompt=system_prompt,
                base_url=self.api_base_url,
                api_key=self.api_key,
                model_name=self.model_name,
                temperature=0.1,  # 低温度确保一致性
                max_tokens=4000,
                max_retries=5,
                retry_delay=10
            )

            if not response:
                raise ValueError("LLM返回为空")

            # 解析JSON
            json_text = self._extract_json(response)
            query_json = json.loads(json_text)

            # 验证字段名
            if self.use_schema_constraint:
                validation = self.schema_loader.validate_query_json(query_json)
                if not validation['valid']:
                    logger.warning(f"未知字段名: {validation['unknown_fields']}")
                    if validation['suggestions']:
                        logger.info(f"字段名建议: {validation['suggestions']}")

            # 添加元数据
            query_json['_meta'] = {
                'original_question': question,
                'schema_constrained': self.use_schema_constraint
            }

            logger.info(f"[OK] Structurization successful")
            return query_json

        except Exception as e:
            logger.error(f"Structurization failed: {e}")
            # 返回最小可用结构
            return {
                'core_topic': question[:50],
                'search_keywords_cn': [],
                'search_keywords_en': [],
                '_meta': {
                    'original_question': question,
                    'error': str(e)
                }
            }

    def _extract_json(self, text: str) -> str:
        """从LLM回复中提取JSON"""
        if '```json' in text:
            return text.split('```json')[1].split('```')[0].strip()
        elif '```' in text:
            return text.split('```')[1].split('```')[0].strip()
        else:
            # 尝试找到第一个{和最后一个}
            start = text.find('{')
            end = text.rfind('}')
            if start >= 0 and end > start:
                return text[start:end+1]
            return text

    def batch_structurize(self, questions: list) -> list:
        """
        批量结构化查询

        Args:
            questions: 问题列表

        Returns:
            结构化查询JSON列表
        """
        results = []
        for i, q in enumerate(questions, 1):
            logger.info(f"[{i}/{len(questions)}] Processing...")
            query_json = self.structurize(q)
            results.append(query_json)

        return results


def main():
    """测试查询结构化器"""
    print("="*70)
    print("查询结构化器测试")
    print("="*70)

    # 初始化
    structurizer = QueryStructurizer(use_schema_constraint=True)

    # 测试问题
    test_questions = [
        "设计FR4基板X波段吸波体，厚度2mm，吸收率90%",
        "Ka频段双极化FSS，相对带宽68%，±40度角稳定",
        "使用GAN逆向设计5-12 GHz宽带吸波体"
    ]

    print(f"\n测试问题数: {len(test_questions)}\n")

    for i, q in enumerate(test_questions, 1):
        print(f"\n{'='*70}")
        print(f"[{i}] 原始问题:")
        print(f"{q}")
        print(f"\n结构化结果:")

        query_json = structurizer.structurize(q)

        # 显示关键字段
        print(f"  core_topic: {query_json.get('core_topic', 'N/A')}")
        print(f"  operating_frequency_range: {query_json.get('operating_frequency_range', 'N/A')}")
        print(f"  substrate_material: {query_json.get('substrate_material', 'N/A')}")
        print(f"  structure_class: {query_json.get('structure_class', 'N/A')[:2] if 'structure_class' in query_json else 'N/A'}")
        print(f"  keywords_cn: {len(query_json.get('search_keywords_cn', []))} 个")
        print(f"  keywords_en: {len(query_json.get('search_keywords_en', []))} 个")

        # 验证
        if '_meta' in query_json and 'error' in query_json['_meta']:
            print(f"  [ERROR] {query_json['_meta']['error']}")
        else:
            print(f"  [OK] 结构化成功")

    print(f"\n{'='*70}")
    print("[OK] 查询结构化器测试完成！")
    print(f"{'='*70}")


if __name__ == '__main__':
    main()
