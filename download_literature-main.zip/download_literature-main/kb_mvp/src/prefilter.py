#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
prefilter.py —— Phase 3：JSONB 预过滤层（对应 PDF "第一步：Metadata 预过滤"）

利用 SQLite JSON1 函数，在 papers_metadata 上做**极速条件过滤**，
将候选论文从全库极速缩小到数百篇，供下游向量/BM25 召回使用。

对应 PostgreSQL 版本（未来升级）:
    WHERE is_aerospace_relevant = TRUE
      AND extracted_schema->>'substrate_material' = 'FR4'
      AND domains @> '["metamaterial"]'::jsonb
      AND novel_findings ? '_mass_reduction_transmitarray'
"""

import sqlite3
import logging
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple

from . import config

logger = logging.getLogger(__name__)


# ============================================================
# 过滤条件 DSL
# ============================================================

class FilterBuilder:
    """
    将用户 filter dict 转成 SQL WHERE 片段 + 参数。

    支持的 filter keys:
      is_domain_relevant: bool
      paper_ids:          List[str]                # 白名单
      schema_eq:          {field: value}           # extracted_schema 精确匹配
      schema_contains:    {field: substring}       # extracted_schema 模糊匹配
      schema_in:          {field: [v1, v2, ...]}   # extracted_schema 值属于集合
      domains_any:        List[str]                # 领域并集 (OR)
      domains_all:        List[str]                # 领域交集 (AND)
      novel_has_key:      str | List[str]          # novel_findings 含有特定 key
    """

    def __init__(self) -> None:
        self.clauses: List[str] = []
        self.params:  List[Any] = []

    def _add(self, clause: str, *params: Any) -> None:
        self.clauses.append(clause)
        self.params.extend(params)

    # ---------- bool ----------
    def is_domain_relevant(self, flag: bool) -> "FilterBuilder":
        self._add("is_domain_relevant = ?", 1 if flag else 0)
        return self

    # ---------- id whitelist ----------
    def paper_ids(self, ids: List[str]) -> "FilterBuilder":
        if ids:
            placeholders = ",".join(["?"] * len(ids))
            self._add(f"paper_id IN ({placeholders})", *ids)
        return self

    # ---------- extracted_schema 精确相等 ----------
    def schema_eq(self, field: str, value: Any) -> "FilterBuilder":
        # json_extract 返回的是 JSON 标量，对比需要 JSON 同形式
        # extracted_schema 里常见是 list（如 ["FR4"]），所以用 json_each 展开
        self._add(
            "EXISTS (SELECT 1 FROM json_each("
            "  json_extract(extracted_schema, '$.' || ?)"
            ") WHERE value = ?)",
            field, value,
        )
        return self

    # ---------- extracted_schema 子串（不区分大小写）----------
    def schema_contains(self, field: str, substr: str) -> "FilterBuilder":
        self._add(
            "EXISTS (SELECT 1 FROM json_each("
            "  json_extract(extracted_schema, '$.' || ?)"
            ") WHERE LOWER(value) LIKE LOWER(?))",
            field, f"%{substr}%",
        )
        return self

    # ---------- extracted_schema 值属于集合 ----------
    def schema_in(self, field: str, values: List[str]) -> "FilterBuilder":
        if not values:
            return self
        placeholders = ",".join(["?"] * len(values))
        self._add(
            "EXISTS (SELECT 1 FROM json_each("
            f"  json_extract(extracted_schema, '$.' || ?)"
            f") WHERE value IN ({placeholders}))",
            field, *values,
        )
        return self

    # ---------- domains 包含 ANY ----------
    def domains_any(self, doms: List[str]) -> "FilterBuilder":
        if not doms:
            return self
        placeholders = ",".join(["?"] * len(doms))
        self._add(
            f"EXISTS (SELECT 1 FROM json_each(domains) WHERE value IN ({placeholders}))",
            *doms,
        )
        return self

    # ---------- domains 包含 ALL ----------
    def domains_all(self, doms: List[str]) -> "FilterBuilder":
        for d in doms:
            self._add("EXISTS (SELECT 1 FROM json_each(domains) WHERE value = ?)", d)
        return self

    # ---------- novel_findings 含有某 key ----------
    def novel_has_key(self, keys) -> "FilterBuilder":
        """对应 PostgreSQL: novel_findings ? 'key'"""
        if isinstance(keys, str):
            keys = [keys]
        for k in keys:
            self._add(
                "json_extract(novel_findings, '$.' || ?) IS NOT NULL",
                k,
            )
        return self

    # ---------- build ----------
    def to_sql(self) -> Tuple[str, List[Any]]:
        where = " AND ".join(self.clauses) if self.clauses else "1=1"
        return where, self.params


# ============================================================
# MetadataFilter —— 主入口
# ============================================================

class MetadataFilter:
    """第一层预过滤器：只读 papers_metadata，返回 paper_id 列表。"""

    def __init__(self, db_path: Optional[Path] = None):
        self.db_path = Path(db_path) if db_path else config.DB_PATH
        self._conn: Optional[sqlite3.Connection] = None

    @property
    def conn(self) -> sqlite3.Connection:
        if self._conn is None:
            self._conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
            self._conn.row_factory = sqlite3.Row
        return self._conn

    def close(self) -> None:
        if self._conn is not None:
            self._conn.close()
            self._conn = None

    # ------------------------------------------------------------
    def filter(self, filters: Optional[Dict[str, Any]] = None) -> List[str]:
        """
        返回满足条件的 paper_id 列表。

        filters 示例:
          {
            "is_domain_relevant": True,
            "schema_contains":    {"substrate_material": "FR4"},
            "domains_any":        ["metamaterial"],
            "novel_has_key":      "_mass_reduction_transmitarray",
          }
        """
        fb = FilterBuilder()
        filters = filters or {}

        if "is_domain_relevant" in filters:
            fb.is_domain_relevant(bool(filters["is_domain_relevant"]))
        if "paper_ids" in filters:
            fb.paper_ids(filters["paper_ids"])
        if "schema_eq" in filters:
            for k, v in (filters["schema_eq"] or {}).items():
                fb.schema_eq(k, v)
        if "schema_contains" in filters:
            for k, v in (filters["schema_contains"] or {}).items():
                fb.schema_contains(k, v)
        if "schema_in" in filters:
            for k, v in (filters["schema_in"] or {}).items():
                fb.schema_in(k, v)
        if "domains_any" in filters:
            fb.domains_any(filters["domains_any"] or [])
        if "domains_all" in filters:
            fb.domains_all(filters["domains_all"] or [])
        if "novel_has_key" in filters:
            fb.novel_has_key(filters["novel_has_key"])

        where, params = fb.to_sql()
        sql = f"SELECT paper_id FROM papers_metadata WHERE {where}"
        rows = self.conn.execute(sql, params).fetchall()
        return [r["paper_id"] for r in rows]

    # ------------------------------------------------------------
    def get_chunk_indices(self, paper_ids: List[str]) -> List[int]:
        """
        给定一组 paper_id，返回它们所有 chunks 对应的 FAISS embedding_idx 列表。
        这是第一层预过滤的最终产物，传给第二层召回。
        """
        if not paper_ids:
            return []
        placeholders = ",".join(["?"] * len(paper_ids))
        sql = (f"SELECT embedding_idx FROM paper_chunks "
               f"WHERE paper_id IN ({placeholders}) AND embedding_idx IS NOT NULL")
        rows = self.conn.execute(sql, paper_ids).fetchall()
        return [r["embedding_idx"] for r in rows]

    # ------------------------------------------------------------
    def get_chunk_info(self, chunk_ids: List[str]) -> List[Dict[str, Any]]:
        """根据 chunk_id 列表获取完整信息（含论文标题、field_type 等）。"""
        if not chunk_ids:
            return []
        placeholders = ",".join(["?"] * len(chunk_ids))
        sql = (f"SELECT c.chunk_id, c.paper_id, c.field_type, c.content, "
               f"       c.embedding_idx, p.title "
               f"FROM paper_chunks c "
               f"JOIN papers_metadata p ON c.paper_id = p.paper_id "
               f"WHERE c.chunk_id IN ({placeholders})")
        rows = self.conn.execute(sql, chunk_ids).fetchall()
        return [dict(r) for r in rows]


# ============================================================
# CLI / 自测
# ============================================================

def _demo():
    import io, sys, json
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

    flt = MetadataFilter()
    cases = [
        ("无过滤", {}),
        ("仅相关", {"is_domain_relevant": True}),
        ("基板 FR4",    {"schema_contains": {"substrate_material": "FR4"}}),
        ("导体含铜",    {"schema_contains": {"conductor_material": "copper"}}),
        ("结构:超材料", {"schema_contains": {"structure_class": "metamaterial"}}),
        ("基板 Rogers", {"schema_contains": {"substrate_material": "Rogers"}}),
    ]
    for name, f in cases:
        ids = flt.filter(f)
        print(f"[{name:12}] filter={f}")
        print(f"  → {len(ids)} 篇: {ids[:10]}{' ...' if len(ids) > 10 else ''}")
    flt.close()


if __name__ == "__main__":
    _demo()
