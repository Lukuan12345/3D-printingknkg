#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
schema_loader.py - Schema约束加载器

功能：
1. 加载 refined_schema_200_2_cleaned.csv 的200个标准字段
2. 按13个聚类分组字段
3. 从KB提取值空间（材料、频段、结构的规范值）
4. 构建LLM约束Prompt

用法：
    loader = SchemaLoader()
    print(f"字段数: {len(loader.fields)}")
    print(f"聚类数: {len(loader.clusters)}")
    prompt = loader.build_constraint_prompt()
"""

import csv
import json
import sqlite3
from pathlib import Path
from typing import Dict, List, Set, Any
from collections import defaultdict


class SchemaLoader:
    """Schema约束加载器"""

    def __init__(self, schema_csv_path: Path = None, db_path: Path = None):
        """
        初始化Schema加载器

        Args:
            schema_csv_path: Schema CSV文件路径（默认使用 kb_mvp/src/config.py 的 SCHEMA_CSV_PATH）
            db_path: SQLite数据库路径（默认使用 kb_mvp/src/config.py 的 DB_PATH）
        """
        # 确定路径（融合后：从 config 读，避免硬编码）
        if schema_csv_path is None:
            try:
                from kb_mvp.src import config as _kb_cfg
                schema_csv_path = _kb_cfg.SCHEMA_CSV_PATH
            except Exception:
                project_root = Path(__file__).resolve().parent.parent.parent
                schema_csv_path = (
                    project_root / "scientific_kgqa" / "data" / "schema.csv"
                )

        if db_path is None:
            db_path = Path(__file__).resolve().parent.parent / "data" / "kb.db"

        self.schema_csv_path = schema_csv_path
        self.db_path = db_path

        # 核心数据结构
        self.fields: List[Dict[str, Any]] = []          # 200个字段的完整信息
        self.clusters: Dict[str, List[Dict]] = {}       # 13个聚类分组
        self.value_spaces: Dict[str, Set[str]] = {}     # 从KB提取的值空间

        # 加载数据
        self._load_schema()
        self._extract_value_spaces()

    def _load_schema(self):
        """从CSV加载schema定义"""
        with open(self.schema_csv_path, 'r', encoding='utf-8-sig') as f:
            reader = csv.DictReader(f)

            # 读取所有字段
            for row in reader:
                field_info = {
                    'en': row['字段名（英文）'].strip(),
                    'cn': row['字段名（中文）'].strip(),
                    'desc': row['完整描述'].strip(),
                    'cluster_id': row['聚类ID'].strip(),
                    'cluster_cn': row['聚类名称'].strip(),
                    'cluster_en': row['聚类名称（英文）'].strip(),
                    'is_core': row.get('重点字段', '') == '是',
                    'tag': row.get('标签', '').strip()
                }
                self.fields.append(field_info)

                # 按聚类分组
                cluster_id = field_info['cluster_id']
                if cluster_id not in self.clusters:
                    self.clusters[cluster_id] = []
                self.clusters[cluster_id].append(field_info)

        print(f"[OK] 加载Schema: {len(self.fields)} 个字段, {len(self.clusters)} 个聚类")

    def _extract_value_spaces(self):
        """
        从KB的papers_metadata表提取值空间

        提取字段：
        - substrate_material: 基板材料的规范值
        - conductor_material: 导体材料的规范值
        - operating_frequency_range: 频段格式示例
        - structure_class: 结构类型的规范值
        """
        if not self.db_path.exists():
            print(f"[WARN] 数据库不存在: {self.db_path}，跳过值空间提取")
            return

        conn = sqlite3.connect(self.db_path, check_same_thread=False)
        cur = conn.cursor()

        # 检查表是否存在
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='papers_metadata'")
        if not cur.fetchone():
            print(f"[WARN] papers_metadata表不存在，跳过值空间提取")
            conn.close()
            return

        # 提取所有论文的extracted_schema
        cur.execute("SELECT extracted_schema FROM papers_metadata WHERE extracted_schema IS NOT NULL")
        rows = cur.fetchall()

        # 聚合值空间
        value_accumulator = defaultdict(set)

        for (schema_json,) in rows:
            try:
                schema = json.loads(schema_json)

                # 提取各字段的值
                for key in ['substrate_material', 'conductor_material',
                           'operating_frequency_range', 'structure_class']:
                    if key in schema:
                        values = schema[key]
                        if isinstance(values, list):
                            for v in values:
                                if v and isinstance(v, str):
                                    value_accumulator[key].add(v.strip())
                        elif isinstance(values, str) and values:
                            value_accumulator[key].add(values.strip())

            except json.JSONDecodeError:
                continue

        conn.close()

        # 转换为dict[str, set]
        self.value_spaces = dict(value_accumulator)

        print(f"[OK] 提取值空间:")
        for key, values in self.value_spaces.items():
            print(f"  - {key}: {len(values)} 个规范值")

    def get_core_fields(self, max_count: int = 40) -> List[Dict]:
        """
        获取核心字段（标记为"重点字段"的）

        Args:
            max_count: 最多返回的字段数

        Returns:
            核心字段列表
        """
        core = [f for f in self.fields if f['is_core']]
        return core[:max_count]

    def get_cluster_fields(self, cluster_id: str) -> List[Dict]:
        """
        获取指定聚类的所有字段

        Args:
            cluster_id: 聚类ID（如 'cluster_4'）

        Returns:
            该聚类下的字段列表
        """
        return self.clusters.get(cluster_id, [])

    def build_constraint_prompt(self,
                                max_clusters: int = 5,
                                max_fields_per_cluster: int = 8) -> str:
        """
        构建用于注入LLM Prompt的Schema约束文本

        Args:
            max_clusters: 最多包含的聚类数
            max_fields_per_cluster: 每个聚类最多包含的字段数

        Returns:
            格式化的约束文本（Markdown格式）
        """
        lines = ["# Schema字段约束（必须严格遵守）\n"]
        lines.append("以下是知识库的标准字段定义，生成的JSON字段名必须100%匹配！\n")

        # 按聚类输出
        for cluster_id in sorted(self.clusters.keys())[:max_clusters]:
            fields = self.clusters[cluster_id]

            if not fields:
                continue

            # 聚类标题
            cluster_name_cn = fields[0]['cluster_cn']
            cluster_name_en = fields[0]['cluster_en']
            lines.append(f"## {cluster_name_cn} ({cluster_name_en})\n")

            # 字段列表
            for field in fields[:max_fields_per_cluster]:
                line = f"- **{field['en']}** ({field['cn']})"

                # 如果有值空间，添加示例
                if field['en'] in self.value_spaces:
                    examples = list(self.value_spaces[field['en']])[:3]
                    if examples:
                        line += f" - 示例: {', '.join(examples)}"

                lines.append(line)

            lines.append("")

        # 值空间约束
        if self.value_spaces:
            lines.append("## 值空间约束\n")
            lines.append("以下字段的值应从已知规范值中选择（或使用相近的标准术语）：\n")

            for key, values in list(self.value_spaces.items())[:4]:
                examples = list(values)[:10]
                lines.append(f"### {key}")
                lines.append(f"规范值: {', '.join(examples)}")
                if len(values) > 10:
                    lines.append(f"（共 {len(values)} 个，此处仅展示前10个）")
                lines.append("")

        return "\n".join(lines)

    def get_cluster_keywords(self, cluster_id: str) -> List[str]:
        """
        获取指定聚类的所有字段的中英文名称（用于关键词扩展）

        Args:
            cluster_id: 聚类ID

        Returns:
            关键词列表（中英文混合）
        """
        fields = self.get_cluster_fields(cluster_id)
        keywords = []

        for field in fields:
            keywords.append(field['cn'])
            keywords.append(field['en'])

        return keywords

    def find_related_clusters(self, query_fields: List[str]) -> List[str]:
        """
        根据查询中已有的字段，推断相关的聚类

        Args:
            query_fields: 查询中已提取的字段名列表

        Returns:
            相关聚类ID列表
        """
        related = set()

        for field_name in query_fields:
            # 查找该字段属于哪个聚类
            for field in self.fields:
                if field['en'] == field_name:
                    related.add(field['cluster_id'])
                    break

        return sorted(related)

    def get_field_info(self, field_name: str) -> Dict[str, Any]:
        """
        获取指定字段的详细信息

        Args:
            field_name: 字段名（英文）

        Returns:
            字段信息字典，如果不存在则返回None
        """
        for field in self.fields:
            if field['en'] == field_name:
                return field
        return None

    def validate_query_json(self, query_json: Dict[str, Any]) -> Dict[str, Any]:
        """
        验证查询JSON的字段名是否符合schema标准

        Args:
            query_json: LLM生成的查询JSON

        Returns:
            验证结果
            {
                "valid": bool,
                "unknown_fields": List[str],  # 未知字段名
                "suggestions": Dict[str, str]  # 建议的字段名映射
            }
        """
        known_field_names = {f['en'] for f in self.fields}
        query_fields = set(query_json.keys())

        unknown = query_fields - known_field_names

        # 尝试模糊匹配建议
        suggestions = {}
        for uf in unknown:
            # 简单的模糊匹配（小写+去下划线）
            uf_normalized = uf.lower().replace('_', '')

            for kf in known_field_names:
                kf_normalized = kf.lower().replace('_', '')
                if uf_normalized == kf_normalized or uf_normalized in kf_normalized:
                    suggestions[uf] = kf
                    break

        return {
            "valid": len(unknown) == 0,
            "unknown_fields": list(unknown),
            "suggestions": suggestions
        }


def main():
    """测试Schema加载器"""
    print("="*70)
    print("Schema加载器测试")
    print("="*70)

    # 初始化
    loader = SchemaLoader()

    # 验证基础数据
    print(f"\n[OK] 字段总数: {len(loader.fields)}")
    print(f"[OK] 聚类总数: {len(loader.clusters)}")

    # 显示聚类概况
    print(f"\n聚类概况:")
    for cluster_id in sorted(loader.clusters.keys()):
        fields = loader.clusters[cluster_id]
        cluster_name = fields[0]['cluster_cn'] if fields else "未知"
        print(f"  {cluster_id}: {cluster_name} ({len(fields)} 个字段)")

    # 显示核心字段
    core_fields = loader.get_core_fields(max_count=10)
    print(f"\n核心字段（前10个）:")
    for f in core_fields:
        print(f"  - {f['en']} ({f['cn']}) [{f['cluster_cn']}]")

    # 显示值空间
    print(f"\n值空间:")
    for key, values in loader.value_spaces.items():
        examples = list(values)[:5]
        print(f"  - {key}: {len(values)} 个规范值")
        print(f"    示例: {', '.join(examples)}")

    # 构建约束Prompt
    print(f"\n构建约束Prompt（前500字符）:")
    prompt = loader.build_constraint_prompt()
    print(prompt[:500])
    print(f"... (总长度: {len(prompt)} 字符)")

    # 验证测试
    print(f"\n字段名验证测试:")
    test_query = {
        "operating_frequency_range": "8-12 GHz",
        "substrate_material": ["FR4"],
        "frequency_range": "错误字段名",  # 应该是 operating_frequency_range
    }
    validation = loader.validate_query_json(test_query)
    print(f"  valid: {validation['valid']}")
    print(f"  unknown_fields: {validation['unknown_fields']}")
    print(f"  suggestions: {validation['suggestions']}")

    print(f"\n{'='*70}")
    print("[OK] Schema加载器测试完成！")
    print(f"{'='*70}")


if __name__ == '__main__':
    main()
