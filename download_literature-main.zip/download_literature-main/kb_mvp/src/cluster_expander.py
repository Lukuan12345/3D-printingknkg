#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
cluster_expander.py - 聚类关键词扩展器

功能：
1. 基于13个语义聚类扩展查询关键词
2. 根据查询中已有的字段，识别相关聚类
3. 从相关聚类中提取同义词、相关术语
4. 增强关键词覆盖率，提升召回

用法：
    expander = ClusterExpander(schema_loader)
    expanded_keywords = expander.expand(query_json)
"""

import logging
from typing import Dict, List, Set, Any
from kb_mvp.src.schema_loader import SchemaLoader
from kb_mvp.src.config import MAX_EXPANDED_KEYWORDS

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)


class ClusterExpander:
    """
    聚类关键词扩展器

    基于schema的13个语义聚类，扩展查询关键词
    """

    def __init__(self, schema_loader: SchemaLoader):
        """
        初始化扩展器

        Args:
            schema_loader: Schema加载器
        """
        self.schema_loader = schema_loader

    def expand(self,
               query_json: Dict[str, Any],
               max_keywords: int = MAX_EXPANDED_KEYWORDS) -> Dict[str, List[str]]:
        """
        扩展查询关键词

        Args:
            query_json: 结构化查询JSON
            max_keywords: 每个聚类最多扩展关键词数

        Returns:
            {
                "expanded_keywords_cn": [...],
                "expanded_keywords_en": [...],
                "related_clusters": [...]
            }
        """
        # 1. 识别查询中涉及的字段
        query_fields = [k for k in query_json.keys() if not k.startswith('_')]

        # 2. 找到相关聚类
        related_clusters = self.schema_loader.find_related_clusters(query_fields)

        if not related_clusters:
            logger.info("未找到相关聚类，跳过扩展")
            return {
                "expanded_keywords_cn": [],
                "expanded_keywords_en": [],
                "related_clusters": []
            }

        logger.info(f"相关聚类: {related_clusters}")

        # 3. 从相关聚类中提取关键词
        all_keywords_cn = set()
        all_keywords_en = set()

        for cluster_id in related_clusters:
            keywords = self.schema_loader.get_cluster_keywords(cluster_id)

            for kw in keywords:
                # 简单判断中英文
                if self._is_chinese(kw):
                    all_keywords_cn.add(kw)
                else:
                    all_keywords_en.add(kw)

        # 4. 限制关键词数量（选择最相关的）
        expanded_cn = list(all_keywords_cn)[:max_keywords]
        expanded_en = list(all_keywords_en)[:max_keywords]

        # 5. 去除已存在的关键词
        existing_cn = set(query_json.get('search_keywords_cn', []))
        existing_en = set(query_json.get('search_keywords_en', []))

        expanded_cn = [kw for kw in expanded_cn if kw not in existing_cn]
        expanded_en = [kw for kw in expanded_en if kw not in existing_en]

        logger.info(f"扩展关键词: {len(expanded_cn)} 个中文, {len(expanded_en)} 个英文")

        return {
            "expanded_keywords_cn": expanded_cn,
            "expanded_keywords_en": expanded_en,
            "related_clusters": related_clusters
        }

    def expand_and_merge(self, query_json: Dict[str, Any]) -> Dict[str, Any]:
        """
        扩展关键词并直接合并到query_json中

        Args:
            query_json: 结构化查询JSON

        Returns:
            更新后的query_json（包含扩展关键词）
        """
        expansion = self.expand(query_json)

        # 合并关键词
        query_json['search_keywords_cn'] = query_json.get('search_keywords_cn', []) + expansion['expanded_keywords_cn']
        query_json['search_keywords_en'] = query_json.get('search_keywords_en', []) + expansion['expanded_keywords_en']

        # 添加元数据
        if '_meta' not in query_json:
            query_json['_meta'] = {}

        query_json['_meta']['cluster_expansion'] = {
            'related_clusters': expansion['related_clusters'],
            'expanded_count_cn': len(expansion['expanded_keywords_cn']),
            'expanded_count_en': len(expansion['expanded_keywords_en'])
        }

        return query_json

    def _is_chinese(self, text: str) -> bool:
        """
        判断文本是否主要为中文

        Args:
            text: 待判断文本

        Returns:
            True if 主要为中文
        """
        if not text:
            return False

        chinese_chars = sum(1 for c in text if '一' <= c <= '鿿')
        return chinese_chars / len(text) > 0.5


def main():
    """测试聚类扩展器"""
    import sys
    from pathlib import Path

    PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
    sys.path.insert(0, str(PROJECT_ROOT))

    from kb_mvp.src.schema_loader import SchemaLoader
    from kb_mvp.src.query_structurizer import QueryStructurizer

    print("="*70)
    print("聚类关键词扩展器测试")
    print("="*70)

    # 初始化
    schema_loader = SchemaLoader()
    expander = ClusterExpander(schema_loader)
    structurizer = QueryStructurizer(schema_loader, use_schema_constraint=True)

    # 测试问题
    test_question = "设计FR4基板X波段吸波体，厚度2mm，吸收率90%"

    print(f"\n[1] 原始问题:")
    print(f"{test_question}\n")

    # 结构化查询
    print(f"[2] 结构化查询...")
    query_json = structurizer.structurize(test_question)

    print(f"  原始关键词:")
    print(f"    中文: {len(query_json.get('search_keywords_cn', []))} 个")
    print(f"    英文: {len(query_json.get('search_keywords_en', []))} 个")

    # 扩展关键词
    print(f"\n[3] 扩展关键词...")
    expanded_query = expander.expand_and_merge(query_json)

    print(f"  扩展后关键词:")
    print(f"    中文: {len(expanded_query.get('search_keywords_cn', []))} 个")
    print(f"    英文: {len(expanded_query.get('search_keywords_en', []))} 个")

    if '_meta' in expanded_query and 'cluster_expansion' in expanded_query['_meta']:
        meta = expanded_query['_meta']['cluster_expansion']
        print(f"\n  相关聚类: {meta['related_clusters']}")
        print(f"  新增中文: {meta['expanded_count_cn']} 个")
        print(f"  新增英文: {meta['expanded_count_en']} 个")

    print(f"\n  部分新增关键词:")
    expanded_cn = expanded_query.get('search_keywords_cn', [])[-5:]
    expanded_en = expanded_query.get('search_keywords_en', [])[-5:]
    print(f"    中文: {', '.join(expanded_cn)}")
    print(f"    英文: {', '.join(expanded_en)}")

    print(f"\n{'='*70}")
    print("[OK] 聚类关键词扩展器测试完成！")
    print(f"{'='*70}")


if __name__ == '__main__':
    main()
