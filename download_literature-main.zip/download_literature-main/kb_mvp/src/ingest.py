#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ingest.py —— Phase 2：数据管道

流程:
  1. 读取 haiku_knowledge_base.json (30 篇)
  2. 创建 SQLite 数据库（papers_metadata + paper_chunks）
  3. 每篇论文的 7 个叙述字段切分为 chunks（≈210 个）
  4. 调用 embedding API 批量生成向量
  5. 构建 FAISS HNSW 索引
  6. 构建 BM25 倒排索引（jieba 中文分词）
  7. 保存所有索引文件

对应 PDF 架构:
  - papers_metadata 表（JSONB + GIN 语义）→ SQLite + JSON1
  - paper_chunks 表（vector + FTS）→ SQLite + FAISS + rank_bm25

用法:
  python -m kb_mvp.src.ingest
  python -m kb_mvp.src.ingest --force   # 强制重建（清空旧库）
"""

import io
import sys
import json
import sqlite3
import pickle
import logging
import argparse
from pathlib import Path
from typing import List, Dict, Any

import numpy as np
import faiss
import jieba
from rank_bm25 import BM25Okapi

from . import config
from .embedding import get_client

# Windows 控制台 UTF-8
if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)


# ============================================================
# 1. SQLite 建表
# ============================================================

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS papers_metadata (
    paper_id           TEXT PRIMARY KEY,
    title              TEXT,
    is_domain_relevant INTEGER DEFAULT 1,
    domains            TEXT,           -- JSON array as string
    extracted_schema   TEXT,           -- JSON object (对应 extracted_data)
    novel_findings     TEXT            -- JSON object (未来填充，当前留空)
);
CREATE INDEX IF NOT EXISTS idx_papers_relevant ON papers_metadata(is_domain_relevant);

CREATE TABLE IF NOT EXISTS paper_chunks (
    chunk_id       TEXT PRIMARY KEY,
    paper_id       TEXT NOT NULL,
    field_type     TEXT NOT NULL,      -- problem_context / physical_mechanism / ...
    content        TEXT NOT NULL,
    embedding_idx  INTEGER,            -- 对应 FAISS 中的向量行号
    FOREIGN KEY (paper_id) REFERENCES papers_metadata(paper_id)
);
CREATE INDEX IF NOT EXISTS idx_chunks_paper ON paper_chunks(paper_id);
CREATE INDEX IF NOT EXISTS idx_chunks_field ON paper_chunks(field_type);
"""


def init_db(db_path: Path, force: bool = False) -> sqlite3.Connection:
    if force and db_path.exists():
        logger.warning("--force: 删除已有数据库 %s", db_path)
        db_path.unlink()
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path))
    conn.executescript(SCHEMA_SQL)
    conn.commit()
    logger.info("SQLite 初始化完成: %s", db_path)
    return conn


# ============================================================
# 2. 导入论文元数据 & 切分 chunks
# ============================================================

def load_kb(kb_path: Path) -> Dict[str, Any]:
    with open(kb_path, "r", encoding="utf-8") as f:
        return json.load(f)


def ingest_metadata_and_chunks(
    conn: sqlite3.Connection, kb: Dict[str, Any], incremental: bool = False
) -> List[Dict[str, Any]]:
    """
    把 kb 中每篇论文：
      - 元数据写入 papers_metadata
      - 每个 CHUNK_FIELDS 字段切为一条 chunk 写入 paper_chunks
    返回 chunks 列表（供后续向量化用）。

    incremental=True 时：DB 里已存在的 chunk_id 跳过（不重复写、不返回），
    只返回本次新增的 chunks（与 fast_ingest 语义一致）。
    """
    cursor = conn.cursor()
    chunks: List[Dict[str, Any]] = []

    existing: set[str] = set()
    if incremental:
        existing = {
            row[0] for row in cursor.execute("SELECT chunk_id FROM paper_chunks").fetchall()
        }
        logger.info("增量模式：DB 已有 %d 个 chunk，本次只处理新增", len(existing))

    for paper_id, paper in kb.items():
        ed = paper.get("extracted_data", {})

        # 论文标题
        title = paper.get("paper_title") or \
                (ed.get("title", [""])[0] if ed.get("title") else "")

        # 领域推断：从 extracted_data.data_source 或 application_sector
        domains = ed.get("domains") or \
                  ed.get("data_source") or \
                  ed.get("application_sector") or []
        if isinstance(domains, str):
            domains = [domains]

        # 写 papers_metadata（INSERT OR REPLACE 幂等；增量下也刷新元数据）
        cursor.execute(
            "INSERT OR REPLACE INTO papers_metadata "
            "(paper_id, title, is_domain_relevant, domains, extracted_schema, novel_findings) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (
                paper_id,
                title,
                1,                                     # MVP 全部视为相关
                json.dumps(domains, ensure_ascii=False),
                json.dumps(ed, ensure_ascii=False),   # extracted_data → extracted_schema
                json.dumps({}, ensure_ascii=False),   # novel_findings 预留
            ),
        )

        # 切分 chunks
        for field in config.CHUNK_FIELDS:
            content = paper.get(field, "")
            if not content or not content.strip():
                continue
            chunk_id = f"{paper_id}_{field}"
            if incremental and chunk_id in existing:
                continue  # 已建过的 chunk，跳过
            cursor.execute(
                "INSERT OR REPLACE INTO paper_chunks "
                "(chunk_id, paper_id, field_type, content, embedding_idx) "
                "VALUES (?, ?, ?, ?, ?)",
                (chunk_id, paper_id, field, content, None),  # embedding_idx 稍后填
            )
            chunks.append({
                "chunk_id": chunk_id,
                "paper_id": paper_id,
                "field_type": field,
                "content": content,
            })

    conn.commit()
    if incremental:
        logger.info("增量导入: %d 篇论文扫描完成, 新增 %d 个 chunks", len(kb), len(chunks))
    else:
        logger.info("导入元数据: %d 篇论文, %d 个 chunks", len(kb), len(chunks))
    return chunks


# ============================================================
# 3. 向量化 + FAISS 索引
# ============================================================

def build_faiss_index(chunks: List[Dict[str, Any]],
                      conn: sqlite3.Connection) -> np.ndarray:
    """
    批量 embedding + 建 FAISS HNSW 索引。
    同时回填 paper_chunks.embedding_idx。
    返回 (embeddings, chunk_ids)
    """
    texts = [c["content"] for c in chunks]
    logger.info("开始 Embedding %d 个 chunk (model=%s, dim=%d)...",
                len(texts), config.EMBEDDING_MODEL, config.EMBEDDING_DIM)

    client = get_client()
    embeddings = client.embed(texts)
    logger.info("Embedding 完成: shape=%s", embeddings.shape)

    # 归一化 -> 用 Inner Product 等价于 cosine similarity
    norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
    norms[norms == 0] = 1.0
    embeddings_norm = embeddings / norms

    # HNSW 索引
    index = faiss.IndexHNSWFlat(config.EMBEDDING_DIM, config.FAISS_M, faiss.METRIC_INNER_PRODUCT)
    index.hnsw.efConstruction = config.FAISS_EF_CONSTRUCT
    index.hnsw.efSearch = config.FAISS_EF_SEARCH
    index.add(embeddings_norm.astype(np.float32))
    logger.info("FAISS HNSW 索引构建完成: ntotal=%d, dim=%d", index.ntotal, index.d)

    # 保存索引
    config.INDEX_DIR.mkdir(parents=True, exist_ok=True)
    try:
        faiss.write_index(index, str(config.FAISS_INDEX_PATH))
    except RuntimeError as e:
        # Windows 中文路径 fallback：序列化为字节再写文件
        if "could not open" in str(e) or "No such file" in str(e):
            logger.info("Fallback: serialize FAISS index to bytes (Unicode path)")
            buf = faiss.serialize_index(index)
            with open(str(config.FAISS_INDEX_PATH), "wb") as fout:
                fout.write(bytes(buf))
        else:
            raise
    np.save(config.EMBEDDINGS_PATH, embeddings_norm)
    logger.info("已保存 FAISS 索引: %s", config.FAISS_INDEX_PATH)
    logger.info("已保存向量: %s (shape=%s)", config.EMBEDDINGS_PATH, embeddings_norm.shape)

    # 回填 embedding_idx
    cursor = conn.cursor()
    for i, c in enumerate(chunks):
        cursor.execute(
            "UPDATE paper_chunks SET embedding_idx = ? WHERE chunk_id = ?",
            (i, c["chunk_id"]),
        )
    conn.commit()

    # 保存 chunk_ids 顺序列表（FAISS idx -> chunk_id 映射）
    chunk_ids = [c["chunk_id"] for c in chunks]
    with open(config.CHUNK_IDS_PATH, "w", encoding="utf-8") as f:
        json.dump(chunk_ids, f, ensure_ascii=False)
    logger.info("已保存 FAISS idx -> chunk_id 映射: %s", config.CHUNK_IDS_PATH)

    return embeddings_norm


# ============================================================
# 4. BM25 索引
# ============================================================

def tokenize_cn(text: str) -> List[str]:
    """中文分词：jieba 搜索引擎模式 + 过滤单字符噪声。"""
    tokens = jieba.lcut_for_search(text.lower())
    return [t for t in tokens if len(t.strip()) > 0]


def build_bm25_index(chunks: List[Dict[str, Any]]) -> None:
    logger.info("构建 BM25 索引 (jieba 分词)...")
    # title + content 作为 BM25 文档，确保论文标题也被索引覆盖。
    # 解决问题：P001 的 chunks 在 BM25 中无法被"一种宽通带低插损..."这样的标题词命中，
    # 导致通用 FSS 论文（P029/P030）抢占 top-3。加入标题后 BM25 能直接匹配该论文。
    tokenized_corpus = [
        tokenize_cn(c.get("title", "") + " " + c["content"])
        for c in chunks
    ]
    bm25 = BM25Okapi(tokenized_corpus)

    with open(config.BM25_INDEX_PATH, "wb") as f:
        pickle.dump({
            "bm25": bm25,
            "tokenized_corpus": tokenized_corpus,
            "chunk_ids": [c["chunk_id"] for c in chunks],
        }, f)
    logger.info("BM25 索引已保存: %s (%d chunks)",
                config.BM25_INDEX_PATH, len(chunks))


# ============================================================
# 主流程
# ============================================================

def rebuild_bm25_only(conn: sqlite3.Connection) -> None:
    """
    从已有 SQLite 数据库读取 chunks（含 title），只重建 BM25 索引。
    不需要重新 embedding，适合只改了 BM25 文档构造逻辑后的快速重建。
    """
    rows = conn.execute(
        "SELECT c.chunk_id, c.paper_id, c.field_type, c.content, m.title "
        "FROM paper_chunks c "
        "JOIN papers_metadata m ON c.paper_id = m.paper_id "
        "ORDER BY c.chunk_id"
    ).fetchall()
    chunks = [
        {
            "chunk_id": r["chunk_id"],
            "paper_id": r["paper_id"],
            "field_type": r["field_type"],
            "content": r["content"],
            "title": r["title"] or "",
        }
        for r in rows
    ]
    logger.info("从数据库读取 %d 个 chunks（含 title）", len(chunks))
    build_bm25_index(chunks)


def _read_all_chunks(conn: sqlite3.Connection) -> List[Dict[str, Any]]:
    """从 DB 读全部 chunks（含 title），按 chunk_id 稳定排序，供全量重建索引用。"""
    conn.row_factory = sqlite3.Row
    rows = conn.execute(
        "SELECT c.chunk_id, c.paper_id, c.field_type, c.content, m.title "
        "FROM paper_chunks c "
        "JOIN papers_metadata m ON c.paper_id = m.paper_id "
        "ORDER BY c.chunk_id"
    ).fetchall()
    return [
        {"chunk_id": r["chunk_id"], "paper_id": r["paper_id"],
         "field_type": r["field_type"], "content": r["content"],
         "title": r["title"] or ""}
        for r in rows
    ]


def main():
    parser = argparse.ArgumentParser(description="Phase 2: 数据管道")
    parser.add_argument("--force", action="store_true", help="清空旧数据库重新构建")
    parser.add_argument(
        "--incremental", action="store_true",
        help="增量：DB 已有的 chunk 跳过，只 embed 新增 chunk（旧向量走 embedding_cache 复用），"
             "再用全量 chunks 重建 FAISS + BM25。与 fast_ingest --incremental 语义一致",
    )
    parser.add_argument(
        "--bm25-only", action="store_true",
        help="只重建 BM25 索引（从已有数据库读 chunks，跳过 embedding）",
    )
    args = parser.parse_args()

    if args.force and args.incremental:
        logger.error("--force 与 --incremental 互斥：--force 清空全量重建，--incremental 只加新")
        sys.exit(1)

    logger.info("=" * 70)
    logger.info("Phase 2: 数据管道  (mode=%s)",
                "incremental" if args.incremental else "force" if args.force else "full")
    logger.info("=" * 70)

    # --bm25-only 模式：快速重建 BM25，不动 FAISS
    if args.bm25_only:
        logger.info("--bm25-only 模式：从已有数据库重建 BM25 索引")
        if not config.DB_PATH.exists():
            logger.error("数据库不存在: %s  请先运行完整 ingest", config.DB_PATH)
            sys.exit(1)
        conn = sqlite3.connect(str(config.DB_PATH))
        conn.row_factory = sqlite3.Row
        rebuild_bm25_only(conn)
        conn.close()
        logger.info("BM25 重建完成: %s", config.BM25_INDEX_PATH)
        return

    # 完整 / 增量构建流程
    conn = init_db(config.DB_PATH, force=args.force)
    kb = load_kb(config.KB_JSON_PATH)
    logger.info("已加载 knowledge_base: %d 篇论文 (from %s)",
                len(kb), config.KB_JSON_PATH.name)
    new_chunks = ingest_metadata_and_chunks(conn, kb, incremental=args.incremental)

    if args.incremental:
        # 增量：embedding_cache 让已建 chunk 命中缓存、不重复调 API；
        # 但 FAISS/BM25 必须用「全量 chunks」重建，否则索引会丢掉旧论文。
        if not new_chunks:
            logger.info("增量模式：无新增 chunk，DB 未变。")
            # 仍重建索引以兜底（例如手工删过 index 文件）；全量重建从缓存取向量，几乎不耗 API。
        all_chunks = _read_all_chunks(conn)
        # build_faiss_index 复用 ingest 内的 APIEmbeddingClient 缓存：旧 chunk 命中缓存零调用，
        # 只有新 chunk 真正打 embedding API。
        build_faiss_index(all_chunks, conn)
        build_bm25_index(all_chunks)
    else:
        build_faiss_index(new_chunks, conn)
        build_bm25_index(new_chunks)

    conn.close()
    logger.info("=" * 70)
    logger.info("Phase 2 完成！")
    logger.info("  数据库:   %s", config.DB_PATH)
    logger.info("  FAISS:    %s", config.FAISS_INDEX_PATH)
    logger.info("  向量:     %s", config.EMBEDDINGS_PATH)
    logger.info("  BM25:     %s", config.BM25_INDEX_PATH)
    logger.info("=" * 70)


if __name__ == "__main__":
    main()
