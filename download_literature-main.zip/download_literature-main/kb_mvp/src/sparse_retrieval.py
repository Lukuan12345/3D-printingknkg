#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
sparse_retrieval.py —— Phase 4：BM25 关键词召回（对应 PDF "字面路 Sparse Keyword"）

利用 rank_bm25 + jieba 分词，精准捕捉专业术语、材料牌号、型号名
（如 "Ti-6Al-4V"、"Rogers RT5880"），弥补向量模型对专业术语理解的不足。

关键特性:
  1. 支持 candidate 白名单过滤（chunk_id 列表）
  2. 中文 jieba 搜索模式分词，保留英文术语原样
  3. 返回 BM25 原始得分（后续由 fusion 模块做归一化）
"""

import pickle
import logging
from pathlib import Path
from typing import List, Optional, Tuple

import numpy as np

from . import config

logger = logging.getLogger(__name__)


# ============================================================
# 分词（与 ingest.py 保持一致）
# ============================================================

import threading as _threading
_jieba_inited = False
_jieba_lock = _threading.Lock()

def _ensure_jieba():
    global _jieba_inited
    if not _jieba_inited:
        with _jieba_lock:
            if not _jieba_inited:  # double-checked locking
                import jieba
                jieba.initialize()
                _jieba_inited = True


def tokenize_cn(text: str) -> List[str]:
    import jieba
    _ensure_jieba()
    tokens = jieba.lcut_for_search(text.lower())
    return [t for t in tokens if len(t.strip()) > 0]


# ============================================================
# Sparse Retriever
# ============================================================

class SparseRetriever:
    """BM25 关键词召回器。"""

    def __init__(self, index_path: Optional[Path] = None):
        self.index_path = Path(index_path) if index_path else config.BM25_INDEX_PATH
        logger.info("Loading BM25 index from %s", self.index_path)
        with open(self.index_path, "rb") as f:
            obj = pickle.load(f)
        self.bm25 = obj["bm25"]
        self.chunk_ids: List[str] = obj["chunk_ids"]
        self._id_to_idx = {cid: i for i, cid in enumerate(self.chunk_ids)}
        # 预计算 BM25 sparse 矩阵，加速 get_scores（原 Python loop → 矩阵乘法）
        self._bm25_matrix = None
        self._vocab: Optional[dict] = None
        self._build_bm25_matrix()

    def _build_bm25_matrix(self):
        """把 BM25 的 doc_freqs + idf + doc_len 预计算成 scipy sparse 矩阵。

        原 get_scores：每个 query token 做一次 Python list comp 遍历 13 万 doc
          → 100 token × 13 万 doc = 1300 万次 dict 查找，约 3 分钟
        新方案：预构 (n_docs × vocab_size) sparse 矩阵，打分时 1 次矩阵乘
          → ~10 秒

        矩阵每个元素 M[d, t] 存储 BM25 分母归一化后的频率权重：
          M[d,t] = q_freq[d,t] * (k1+1) / (q_freq[d,t] + k1*(1-b+b*doc_len[d]/avgdl))
        打分时只需 score = idf_vec @ M（向量乘 sparse 矩阵转置等价于 M.T @ idf_vec）。
        结果与 rank_bm25.get_scores() 数学上完全等价。
        """
        try:
            from scipy.sparse import lil_matrix, csr_matrix
            bm25 = self.bm25
            n_docs = bm25.corpus_size
            vocab = {word: i for i, word in enumerate(bm25.idf.keys())}
            self._vocab = vocab
            v_size = len(vocab)

            k1, b = bm25.k1, bm25.b
            avgdl = bm25.avgdl
            doc_len = np.array(bm25.doc_len, dtype=np.float32)
            # 分母中与 doc 相关的部分（不含 q_freq）
            len_norm = k1 * (1 - b + b * doc_len / avgdl)  # shape (n_docs,)

            mat = lil_matrix((n_docs, v_size), dtype=np.float32)
            for d_idx, doc_freq in enumerate(bm25.doc_freqs):
                ln = len_norm[d_idx]
                for word, freq in doc_freq.items():
                    t_idx = vocab.get(word)
                    if t_idx is None:
                        continue
                    f = float(freq)
                    mat[d_idx, t_idx] = f * (k1 + 1) / (f + ln)

            self._bm25_matrix = csr_matrix(mat)  # (n_docs, vocab)
            logger.info(
                "BM25 sparse matrix built: %d docs x %d vocab, nnz=%d",
                n_docs, v_size, self._bm25_matrix.nnz,
            )
        except Exception as e:
            logger.warning("BM25 sparse matrix build failed (%s), fallback to get_scores", e)
            self._bm25_matrix = None
            self._vocab = None

    def _fast_scores(self, tokens: List[str]) -> np.ndarray:
        """用预构 sparse 矩阵打分，比 get_scores 快 ~20 倍。"""
        vocab = self._vocab
        idf = self.bm25.idf
        # 构造 query idf 向量（只有命中 vocab 的 token 才有值）
        idf_vec = np.zeros(len(vocab), dtype=np.float32)
        for t in tokens:
            idx = vocab.get(t)
            if idx is not None:
                idf_vec[idx] += float(idf.get(t) or 0)
        # scores[d] = sum_t( idf[t] * M[d,t] ) = M @ idf_vec
        return self._bm25_matrix.dot(idf_vec)  # shape (n_docs,)

    # ------------------------------------------------------------
    def search(
        self,
        query: str,
        candidate_chunk_ids: Optional[List[str]] = None,
        top_k: int = config.TOP_K_SPARSE,
    ) -> List[Tuple[str, float]]:
        """
        给定 query，返回 Top-K (chunk_id, bm25_score) 列表。

        Args:
            query:                用户查询
            candidate_chunk_ids:  白名单 chunk_id 列表。传入则只在白名单内排序；
                                  不传则全库排序。
            top_k:                返回数量

        Perf: 优先用 _fast_scores（sparse 矩阵乘 ~10s），
              fallback 到 bm25.get_scores（~3min）。
        """
        tokens = tokenize_cn(query)
        if not tokens:
            return []

        if self._bm25_matrix is not None:
            scores = self._fast_scores(tokens)
        else:
            scores = np.asarray(self.bm25.get_scores(tokens))

        if candidate_chunk_ids is not None:
            mask = np.zeros(len(self.chunk_ids), dtype=bool)
            id_to_idx = self._id_to_idx
            for cid in candidate_chunk_ids:
                idx = id_to_idx.get(cid)
                if idx is not None:
                    mask[idx] = True
            mask &= scores > 0
        else:
            mask = scores > 0

        valid_idxs = np.where(mask)[0]
        if len(valid_idxs) == 0:
            return []
        valid_scores = scores[valid_idxs]

        if len(valid_scores) <= top_k:
            order = np.argsort(-valid_scores)
        else:
            top = np.argpartition(-valid_scores, top_k)[:top_k]
            order = top[np.argsort(-valid_scores[top])]

        return [(self.chunk_ids[int(valid_idxs[o])], float(valid_scores[o]))
                for o in order]


# ============================================================
# 自测
# ============================================================

def _demo():
    import io, sys
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
    logging.basicConfig(level=logging.INFO, format="%(message)s")

    r = SparseRetriever()
    for q in [
        "Rogers RT5880 substrate_material",
        "FR4 基板 极化不敏感 吸波体",
        "Ti-6Al-4V",
        "GAN 逆向设计",
    ]:
        print(f"\nQuery: {q}")
        for cid, s in r.search(q, top_k=5):
            print(f"  {s:.3f}  {cid}")


if __name__ == "__main__":
    _demo()
