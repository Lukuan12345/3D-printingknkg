#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
dense_retrieval.py —— Phase 4：向量召回（对应 PDF "语义路 Dense Vector"）

利用 FAISS HNSW 索引做 query → Top-K chunk 的近似最近邻搜索，
捕捉隐式语义关联（如提问"减轻重量" 能匹配原文"轻量化设计"）。

关键特性:
  1. 支持 candidate 白名单过滤（接收 Phase 3 预过滤的 embedding_idx 列表）
  2. 使用内积 + 归一化 = 余弦相似度
  3. 单例加载：FAISS 索引 + chunk_ids 映射只加载一次
"""

import json
import logging
from pathlib import Path
from typing import List, Optional, Tuple

import numpy as np
import faiss

from . import config
from .embedding import get_client

logger = logging.getLogger(__name__)


class DenseRetriever:
    """FAISS 向量召回器。"""

    def __init__(self, index_path: Optional[Path] = None,
                 chunk_ids_path: Optional[Path] = None):
        self.index_path = Path(index_path) if index_path else config.FAISS_INDEX_PATH
        self.chunk_ids_path = Path(chunk_ids_path) if chunk_ids_path else config.CHUNK_IDS_PATH

        logger.info("Loading FAISS index from %s", self.index_path)
        # Windows 路径含 Unicode（如中文）时 faiss.read_index 会失败，先读字节再反序列化
        try:
            self.index = faiss.read_index(str(self.index_path))
        except RuntimeError as e:
            if "could not open" not in str(e):
                raise
            logger.info("Fallback: deserialize FAISS index from bytes (Unicode path)")
            data = np.fromfile(str(self.index_path), dtype=np.uint8)
            self.index = faiss.deserialize_index(data)

        with open(self.chunk_ids_path, "r", encoding="utf-8") as f:
            self.chunk_ids: List[str] = json.load(f)

        # chunk_id -> faiss_idx 反查
        self._id_to_idx = {cid: i for i, cid in enumerate(self.chunk_ids)}

        # 预加载 embeddings.npy 用于白名单精确召回（HNSW search 非全局遍历，有漏召）
        emb_path = Path(str(self.index_path).replace("faiss.index", "embeddings.npy"))
        if not emb_path.exists():
            emb_path = config.EMBEDDINGS_PATH
        self._embeddings: Optional[np.ndarray] = None
        if emb_path.exists():
            try:
                self._embeddings = np.load(str(emb_path))
                logger.info("Loaded embeddings.npy shape=%s for whitelist exact search", self._embeddings.shape)
            except Exception as e:
                logger.warning("Failed to load embeddings.npy: %s", e)

        # embedding client
        self.embedder = get_client()

    # ------------------------------------------------------------
    def search(
        self,
        query: str,
        candidate_indices: Optional[List[int]] = None,
        top_k: int = config.TOP_K_DENSE,
    ) -> List[Tuple[str, float]]:
        """
        给定 query 字符串，返回 Top-K (chunk_id, cosine_similarity) 列表。

        Args:
            query:             用户查询
            candidate_indices: 白名单（FAISS embedding_idx 列表）。
                              传入时只在白名单内召回；不传则全局召回。
            top_k:             返回数量

        Returns:
            List[(chunk_id, score)], score ∈ [-1, 1]，越大越相似
        """
        # Embedding
        q_vec = self.embedder.embed_one(query)
        norm = np.linalg.norm(q_vec)
        if norm == 0:
            return []
        q_vec = (q_vec / norm).astype(np.float32).reshape(1, -1)

        # 白名单过滤策略：
        # FAISS HNSW 是图索引，search(q, ntotal) 并非全局遍历，会漏召白名单内的向量。
        # 修复：有 embeddings.npy 时，直接对白名单 embedding 做矩阵内积（精确）。
        # 但若白名单 ≥ 全库 80%，视为"无过滤"，用 FAISS 全局召回更快。
        if candidate_indices:
            candidate_set = set(candidate_indices)
            full_index_size = len(self.chunk_ids)

            # 白名单接近全库时退化到 FAISS 全局召回（避免 19012×1024 矩阵乘法拖慢 fast）
            if len(candidate_set) >= full_index_size * 0.8:
                D, I = self.index.search(q_vec, top_k)
                return [(self.chunk_ids[i], float(s)) for s, i in zip(D[0], I[0]) if i >= 0]

            cand_list = sorted(candidate_set)  # 保持确定顺序

            # 精确召回：从 embeddings.npy 取白名单行，矩阵乘法
            if self._embeddings is not None and len(cand_list) > 0:
                try:
                    valid = [i for i in cand_list if 0 <= i < len(self._embeddings)]
                    if valid:
                        cand_vecs = self._embeddings[valid].astype(np.float32)
                        scores = (cand_vecs @ q_vec.T).flatten()
                        order = np.argsort(-scores)
                        results = [
                            (self.chunk_ids[valid[o]], float(scores[o]))
                            for o in order[:top_k]
                        ]
                        logger.info("Whitelist exact search: %d/%d candidates → %d results",
                                    len(valid), len(cand_list), len(results))
                        return results
                except Exception as e:
                    logger.warning("Whitelist exact search failed (%s), falling back to HNSW", e)

            # Fallback：HNSW 扩大召回（可能不完整，但比无结果好）
            k_enlarge = min(top_k * 5, self.index.ntotal)
            D, I = self.index.search(q_vec, k_enlarge)
            results = []
            for score, idx in zip(D[0], I[0]):
                if idx < 0:
                    continue
                if idx in candidate_set:
                    results.append((self.chunk_ids[idx], float(score)))
                    if len(results) >= top_k:
                        break
            return results
        else:
            D, I = self.index.search(q_vec, top_k)
            return [(self.chunk_ids[i], float(s))
                    for s, i in zip(D[0], I[0]) if i >= 0]


# ============================================================
# 自测
# ============================================================

def _demo():
    import io, sys
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
    logging.basicConfig(level=logging.INFO, format="%(message)s")

    r = DenseRetriever()
    for q in [
        "FR4 基板 极化不敏感 宽角吸波体 8-12 GHz",
        "GAN 逆向设计吸波体 PCB 工艺",
        "棋盘格 AMC 结构 RCS 减缩",
    ]:
        print(f"\nQuery: {q}")
        for cid, s in r.search(q, top_k=5):
            print(f"  {s:.3f}  {cid}")


if __name__ == "__main__":
    _demo()
