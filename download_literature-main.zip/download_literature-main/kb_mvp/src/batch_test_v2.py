#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
batch_test_v2.py - 批量测试（新版：集成所有改进功能）

新版特性：
1. ✅ Schema约束的查询结构化
2. ✅ 三路融合（Metadata + Dense + Sparse）
3. ✅ 结果聚类展示（按匹配模式分组）
4. ✅ LLM综合回答生成（带引用标注）
5. ✅ 完整的Markdown报告

用法：
    python src/batch_test_v2.py --query tests/test_query.json
"""

import io
import sys
import json
import logging
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, Optional

# 添加项目路径
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
KB_MVP_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))
sys.path.insert(0, str(KB_MVP_ROOT))

from src import config
from src.searcher import HybridSearcher
from src.query_structurizer import QueryStructurizer
from src.result_clusterer import ResultClusterer
from src.answer_generator import AnswerGenerator

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)


def run_batch_v2(
    query_json_path: Path,
    top_k: int = 10,
    enable_three_way: bool = True,
    generate_answer: bool = True,
) -> Dict[str, Any]:
    """
    批量测试（新版）

    Args:
        query_json_path: 测试用例JSON路径
        top_k: 返回Top-K结果
        enable_three_way: 是否启用三路融合
        generate_answer: 是否生成LLM回答

    Returns:
        完整结果字典
    """
    # 1. 初始化所有组件
    logger.info("Initializing components...")

    # 设置三路融合模式
    original_setting = config.ENABLE_THREE_WAY_FUSION
    config.ENABLE_THREE_WAY_FUSION = enable_three_way

    searcher = HybridSearcher()
    structurizer = QueryStructurizer() if enable_three_way else None
    clusterer = ResultClusterer()
    generator = AnswerGenerator() if generate_answer else None

    # 2. 读取测试用例
    with open(query_json_path, "r", encoding="utf-8") as f:
        q_data = json.load(f)

    test_cases = q_data.get("test_cases", [])

    logger.info(f"Loaded {len(test_cases)} test cases from {query_json_path}")

    # 3. 构建结果结构
    results = {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "engine": "kb_mvp_v2 (SQLite + FAISS + BM25 + Metadata)",
        "embedding": f"{config.EMBEDDING_MODEL} (dim={config.EMBEDDING_DIM})",
        "mode": "three_way" if enable_three_way else "two_way",
        "weights": {
            "metadata": config.WEIGHT_METADATA if enable_three_way else 0.0,
            "dense": config.WEIGHT_DENSE_V2 if enable_three_way else config.WEIGHT_DENSE,
            "sparse": config.WEIGHT_SPARSE_V2 if enable_three_way else config.WEIGHT_SPARSE
        },
        "top_k": top_k,
        "total_queries": len(test_cases),
        "results": [],
    }

    # 4. 逐个处理测试用例
    for idx, test_case in enumerate(test_cases, 1):
        qid = test_case.get("id", f"Q{idx:03d}")
        question = test_case.get("question", "")

        logger.info(f"[{idx}/{len(test_cases)}] {qid}: {question[:50]}...")

        try:
            t0 = time.time()

            # Step 1: 查询结构化（如果启用三路融合）
            if enable_three_way and structurizer:
                # 如果test_case已包含结构化字段，直接使用
                if 'core_topic' in test_case:
                    query_json = test_case
                else:
                    query_json = structurizer.structurize(question)
                query_text = query_json.get('core_topic', question)
            else:
                query_json = None
                query_text = question

            # Step 2: 检索
            search_result = searcher.search(
                query=query_text,
                query_json=query_json,
                top_k=top_k
            )

            top_chunks = search_result['top_k']
            stats = search_result['stats']

            # Step 3: 结果聚类
            clustered = clusterer.cluster_by_match_pattern(top_chunks)
            cluster_summary = clusterer.get_summary(clustered)

            # Step 4: 生成回答（可选）
            generated_answer = None
            if generate_answer and generator and query_json:
                generated_answer = generator.generate(
                    question=question,
                    query_json=query_json,
                    top_chunks=top_chunks[:5]  # 使用Top-5生成回答
                )

            elapsed = time.time() - t0

            # 保存结果
            results["results"].append({
                "query_id": qid,
                "question": question,
                "query_json": query_json,
                "elapsed_ms": round(elapsed * 1000, 1),
                "search_stats": stats,
                "cluster_summary": cluster_summary,
                "clustered_results": {
                    "full_match": [_simplify_hit(h) for h in clustered["full_match"]],
                    "material_freq": [_simplify_hit(h) for h in clustered["material_freq"]],
                    "semantic_only": [_simplify_hit(h) for h in clustered["semantic_only"]]
                },
                "generated_answer": generated_answer,
                "top_k_hits": [_simplify_hit(h) for h in top_chunks]
            })

            logger.info(f"  ✓ Completed in {elapsed:.2f}s "
                       f"(full={cluster_summary['full_match_count']}, "
                       f"material_freq={cluster_summary['material_freq_count']}, "
                       f"semantic={cluster_summary['semantic_only_count']})")

        except Exception as e:
            logger.error(f"  ✗ Failed: {e}")
            results["results"].append({
                "query_id": qid,
                "question": question,
                "error": str(e)
            })

    # 恢复原设置
    config.ENABLE_THREE_WAY_FUSION = original_setting

    return results


def _simplify_hit(hit: Dict[str, Any]) -> Dict[str, Any]:
    """简化hit结构（去除过长的content）"""
    return {
        "paper_id": hit.get('paper_id'),
        "title": hit.get('title'),
        "chunk_id": hit.get('chunk_id'),
        "field_type": hit.get('field_type'),
        "content_preview": hit.get('content', '')[:200],
        "fused_score": hit.get('fused_score'),
        "metadata_score": hit.get('metadata_score', 0.0),
        "dense_score": hit.get('dense_score', 0.0),
        "sparse_score": hit.get('sparse_score', 0.0),
        "reasons": hit.get('reasons', []),
        "metadata_detail": hit.get('metadata_detail')
    }


def render_markdown_v2(results: Dict[str, Any]) -> str:
    """渲染为Markdown（新版）"""
    lines = []

    # Header
    lines.append("# 混合检索测试报告（新版）\n")
    lines.append(f"- **生成时间**: {results['generated_at']}")
    lines.append(f"- **检索引擎**: {results['engine']}")
    lines.append(f"- **模式**: {results['mode']}")
    lines.append(f"- **融合权重**: Metadata={results['weights']['metadata']:.1f}, "
                f"Dense={results['weights']['dense']:.1f}, "
                f"Sparse={results['weights']['sparse']:.1f}")
    lines.append(f"- **Top-K**: {results['top_k']}")
    lines.append(f"- **总查询数**: {results['total_queries']}\n")
    lines.append("---\n")

    # 每个查询的结果
    for item in results["results"]:
        qid = item["query_id"]
        question = item["question"]

        lines.append(f"## {qid}\n")
        lines.append(f"### 原始问题\n")
        lines.append(f"> {question}\n")

        # 如果有错误
        if "error" in item:
            lines.append(f"**错误**: {item['error']}\n")
            lines.append("---\n")
            continue

        # 1. LLM生成回答（如果有）
        if item.get("generated_answer"):
            answer = item["generated_answer"]
            lines.append("### 综合技术回答\n")
            lines.append(answer.get('answer', 'N/A'))
            lines.append("\n")

            # 关键发现
            if answer.get('key_findings'):
                lines.append("#### 关键发现\n")
                for finding in answer['key_findings']:
                    lines.append(f"- {finding}")
                lines.append("\n")

            # 局限性
            if answer.get('limitations'):
                lines.append("#### 知识库局限\n")
                lines.append(answer['limitations'])
                lines.append("\n")

            # 引用详情
            if answer.get('citation_details'):
                lines.append("#### 引用来源\n")
                for cite in answer['citation_details']:
                    lines.append(f"[{cite['id']}] **{cite['paper_id']}** - {cite['title']}")
                    lines.append(f"   - 融合分数: {cite['fused_score']:.3f}")
                    if cite.get('metadata_score', 0) > 0:
                        lines.append(f"   - Metadata={cite['metadata_score']:.2f}, "
                                   f"Dense={cite['dense_score']:.2f}, "
                                   f"Sparse={cite['sparse_score']:.2f}")
                    lines.append("")
                lines.append("\n")

        # 2. 聚类统计
        summary = item.get("cluster_summary", {})
        lines.append("### 检索统计\n")
        lines.append(f"- 全匹配论文: {summary.get('full_match_count', 0)} 篇")
        lines.append(f"- 材料/频段匹配: {summary.get('material_freq_count', 0)} 篇")
        lines.append(f"- 纯语义匹配: {summary.get('semantic_only_count', 0)} 篇")
        lines.append(f"- 耗时: {item['elapsed_ms']:.1f} ms\n")

        # 3. 聚类展示（折叠）
        clustered = item.get("clustered_results", {})

        # 全匹配
        if clustered.get("full_match"):
            lines.append("<details><summary>点击展开：全匹配论文详情</summary>\n")
            for i, hit in enumerate(clustered["full_match"][:5], 1):
                lines.append(f"**[{i}] {hit['paper_id']}** (score={hit['fused_score']:.3f})")
                if hit.get('metadata_detail') and hit['metadata_detail'].get('matched_fields'):
                    fields = ', '.join(hit['metadata_detail']['matched_fields'].keys())
                    lines.append(f"- Metadata匹配: {fields}")
                lines.append(f"- 内容: {hit.get('content_preview', '')}...\n")
            lines.append("</details>\n")

        # 材料频段匹配
        if clustered.get("material_freq"):
            lines.append("<details><summary>点击展开：材料/频段匹配论文</summary>\n")
            for i, hit in enumerate(clustered["material_freq"][:5], 1):
                lines.append(f"**[{i}] {hit['paper_id']}** (score={hit['fused_score']:.3f})")
                lines.append(f"- 内容: {hit.get('content_preview', '')}...\n")
            lines.append("</details>\n")

        lines.append("---\n")

    return "\n".join(lines)


def main():
    """主函数"""
    import argparse

    parser = argparse.ArgumentParser(
        description="批量测试（新版：集成所有改进功能）"
    )
    parser.add_argument(
        '--query',
        default='tests/test_query.json',
        help='测试用例JSON路径'
    )
    parser.add_argument(
        '--top-k',
        type=int,
        default=10,
        help='返回Top-K结果'
    )
    parser.add_argument(
        '--two-way',
        action='store_true',
        help='使用二路融合（默认三路）'
    )
    parser.add_argument(
        '--no-answer',
        action='store_true',
        help='不生成LLM回答'
    )
    parser.add_argument(
        '--output',
        help='输出路径前缀（默认自动生成）'
    )

    args = parser.parse_args()

    # 解析路径
    query_path = KB_MVP_ROOT / args.query
    if not query_path.exists():
        logger.error(f"Query file not found: {query_path}")
        sys.exit(1)

    # 运行测试
    logger.info("="*70)
    logger.info("Starting batch test (v2)...")
    logger.info("="*70)

    results = run_batch_v2(
        query_json_path=query_path,
        top_k=args.top_k,
        enable_three_way=not args.two_way,
        generate_answer=not args.no_answer
    )

    # 保存结果
    if args.output:
        output_prefix = Path(args.output)
    else:
        mode = "3way" if not args.two_way else "2way"
        output_prefix = KB_MVP_ROOT / "results" / f"batch_test_{mode}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

    output_prefix.parent.mkdir(parents=True, exist_ok=True)

    # 保存JSON
    json_path = output_prefix.parent / f"{output_prefix.name}.json"
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    logger.info(f"✓ JSON saved to: {json_path}")

    # 保存Markdown
    md_path = output_prefix.parent / f"{output_prefix.name}.md"
    markdown = render_markdown_v2(results)
    with open(md_path, 'w', encoding='utf-8') as f:
        f.write(markdown)
    logger.info(f"✓ Markdown saved to: {md_path}")

    # 打印摘要
    logger.info("="*70)
    logger.info("Batch test completed!")
    logger.info(f"  Total queries: {results['total_queries']}")
    logger.info(f"  Mode: {results['mode']}")
    logger.info(f"  Results saved to: {output_prefix.parent}")
    logger.info("="*70)


if __name__ == '__main__':
    main()
