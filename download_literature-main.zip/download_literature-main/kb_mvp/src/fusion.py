#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
fusion.py —— Phase 5：融合重排序（对应 PDF "第三步：Score Fusion"）

将 Dense 路和 Sparse 路的得分归一化到 [0, 1]，然后按加权求和：
    fused_score = w_dense * norm(dense) + w_sparse * norm(sparse)

Phase 3扩展：三路融合
    fused_score = w_metadata * norm(metadata) + w_dense * norm(dense) + w_sparse * norm(sparse)

PDF 默认: fused_score = 0.7 * cosine + 0.3 * bm25_norm

归一化策略:
  - metadata: min-max 归一化（precision match得分，已在[0,1]）
  - dense (cosine): 直接用 (x+1)/2 把 [-1,1] 映射到 [0,1]
                    实际 bge-m3 cosine 多在 [0.3, 0.7]，再做 min-max 使对比更分明
  - sparse (bm25):  没有上限，用 min-max 归一化到 [0,1]
"""

import sys
from pathlib import Path
from typing import List, Tuple, Dict
import numpy as np

# 添加项目路径（用于MetadataScore类型）
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(PROJECT_ROOT))


# ============================================================
# 归一化
# ============================================================

def _minmax(values: List[float], floor: float = 0.0) -> List[float]:
    """min-max 归一化到 [0, 1]。同值时全部设为 floor。"""
    if not values:
        return []
    lo, hi = min(values), max(values)
    if hi - lo < 1e-9:
        return [floor] * len(values)
    return [(v - lo) / (hi - lo) for v in values]


def _cos_to_unit(cos_values: List[float]) -> List[float]:
    """
    cosine ∈ [-1, 1] 先做 min-max（查询内相对比较更合理），
    再保证顺序单调。
    """
    return _minmax(cos_values)


# ============================================================
# 融合
# ============================================================

def fuse(
    dense_hits: List[Tuple[str, float]],
    sparse_hits: List[Tuple[str, float]],
    w_dense: float = 0.7,
    w_sparse: float = 0.3,
) -> List[Dict]:
    """
    将两路召回结果融合为统一排序。

    输入:
        dense_hits:  [(chunk_id, cosine_score), ...]
        sparse_hits: [(chunk_id, bm25_score), ...]

    输出:
        [{chunk_id, fused_score, dense_score, sparse_score, dense_rank, sparse_rank}, ...]
        按 fused_score 降序
    """
    # 归一化
    d_ids, d_scores = (list(x) for x in zip(*dense_hits)) if dense_hits else ([], [])
    s_ids, s_scores = (list(x) for x in zip(*sparse_hits)) if sparse_hits else ([], [])

    d_norm = _cos_to_unit(d_scores) if d_scores else []
    s_norm = _minmax(s_scores) if s_scores else []

    # 构建分数表
    fused: Dict[str, Dict] = {}

    for rank, (cid, raw, norm) in enumerate(zip(d_ids, d_scores, d_norm), start=1):
        fused[cid] = {
            "chunk_id": cid,
            "dense_raw":   raw,
            "dense_norm":  norm,
            "dense_rank":  rank,
            "sparse_raw":  0.0,
            "sparse_norm": 0.0,
            "sparse_rank": None,
        }

    for rank, (cid, raw, norm) in enumerate(zip(s_ids, s_scores, s_norm), start=1):
        if cid not in fused:
            fused[cid] = {
                "chunk_id": cid,
                "dense_raw":   0.0,
                "dense_norm":  0.0,
                "dense_rank":  None,
                "sparse_raw":  raw,
                "sparse_norm": norm,
                "sparse_rank": rank,
            }
        else:
            fused[cid]["sparse_raw"]  = raw
            fused[cid]["sparse_norm"] = norm
            fused[cid]["sparse_rank"] = rank

    # 加权求和
    for entry in fused.values():
        entry["fused_score"] = round(
            w_dense * entry["dense_norm"] + w_sparse * entry["sparse_norm"],
            4,
        )
        entry["dense_raw"]  = round(entry["dense_raw"], 4)
        entry["dense_norm"] = round(entry["dense_norm"], 4)
        entry["sparse_raw"] = round(entry["sparse_raw"], 4)
        entry["sparse_norm"] = round(entry["sparse_norm"], 4)

    ordered = sorted(fused.values(), key=lambda e: -e["fused_score"])
    return ordered


# ============================================================
# 三路融合（Phase 3新增）
# ============================================================

def fuse_three_way(
    metadata_scores: List,  # List[MetadataScore]
    dense_hits: List[Tuple[str, float]],
    sparse_hits: List[Tuple[str, float]],
    chunk_to_paper_map: Dict[str, str],  # chunk_id -> paper_id映射
    w_metadata: float = 0.2,
    w_dense: float = 0.6,
    w_sparse: float = 0.2,
) -> List[Dict]:
    """
    三路融合：Metadata + Dense + Sparse

    Args:
        metadata_scores: MetadataScore列表（paper级别）
        dense_hits: [(chunk_id, cosine_score), ...]
        sparse_hits: [(chunk_id, bm25_score), ...]
        chunk_to_paper_map: chunk_id -> paper_id映射
        w_metadata, w_dense, w_sparse: 权重

    Returns:
        [{chunk_id, fused_score, metadata_score, dense_score, sparse_score, ...}, ...]
        按 fused_score 降序
    """
    # 1. 构建metadata的paper_id -> score映射
    metadata_map = {ms.paper_id: ms.score for ms in metadata_scores}
    metadata_raw_scores = [ms.score for ms in metadata_scores]

    # 归一化metadata分数（已在[0,1]，但仍做min-max以增强对比度）
    metadata_norm_map = {}
    if metadata_raw_scores:
        lo, hi = min(metadata_raw_scores), max(metadata_raw_scores)
        if hi - lo > 1e-9:
            for ms in metadata_scores:
                metadata_norm_map[ms.paper_id] = (ms.score - lo) / (hi - lo)
        else:
            # 全部相同分数
            for ms in metadata_scores:
                metadata_norm_map[ms.paper_id] = 0.5

    # 为metadata创建rank映射
    sorted_metadata = sorted(metadata_scores, key=lambda ms: -ms.score)
    metadata_rank_map = {ms.paper_id: rank for rank, ms in enumerate(sorted_metadata, start=1)}

    # 2. 归一化Dense和Sparse
    d_ids, d_scores = (list(x) for x in zip(*dense_hits)) if dense_hits else ([], [])
    s_ids, s_scores = (list(x) for x in zip(*sparse_hits)) if sparse_hits else ([], [])

    d_norm = _cos_to_unit(d_scores) if d_scores else []
    s_norm = _minmax(s_scores) if s_scores else []

    # 3. 构建融合表（chunk级别）
    fused: Dict[str, Dict] = {}

    # Dense路
    for rank, (cid, raw, norm) in enumerate(zip(d_ids, d_scores, d_norm), start=1):
        paper_id = chunk_to_paper_map.get(cid)
        metadata_raw = metadata_map.get(paper_id, 0.0) if paper_id else 0.0
        metadata_norm = metadata_norm_map.get(paper_id, 0.0) if paper_id else 0.0
        metadata_rank = metadata_rank_map.get(paper_id) if paper_id else None

        fused[cid] = {
            "chunk_id": cid,
            "dense_raw":   raw,
            "dense_norm":  norm,
            "dense_rank":  rank,
            "sparse_raw":  0.0,
            "sparse_norm": 0.0,
            "sparse_rank": None,
            "metadata_raw": metadata_raw,
            "metadata_norm": metadata_norm,
            "metadata_rank": metadata_rank,
        }

    # Sparse路
    for rank, (cid, raw, norm) in enumerate(zip(s_ids, s_scores, s_norm), start=1):
        paper_id = chunk_to_paper_map.get(cid)
        metadata_raw = metadata_map.get(paper_id, 0.0) if paper_id else 0.0
        metadata_norm = metadata_norm_map.get(paper_id, 0.0) if paper_id else 0.0
        metadata_rank = metadata_rank_map.get(paper_id) if paper_id else None

        if cid not in fused:
            fused[cid] = {
                "chunk_id": cid,
                "dense_raw":   0.0,
                "dense_norm":  0.0,
                "dense_rank":  None,
                "sparse_raw":  raw,
                "sparse_norm": norm,
                "sparse_rank": rank,
                "metadata_raw": metadata_raw,
                "metadata_norm": metadata_norm,
                "metadata_rank": metadata_rank,
            }
        else:
            fused[cid]["sparse_raw"]  = raw
            fused[cid]["sparse_norm"] = norm
            fused[cid]["sparse_rank"] = rank

    # 4. 加权求和
    for entry in fused.values():
        entry["fused_score"] = round(
            w_metadata * entry["metadata_norm"] +
            w_dense * entry["dense_norm"] +
            w_sparse * entry["sparse_norm"],
            4,
        )
        entry["dense_raw"]  = round(entry["dense_raw"], 4)
        entry["dense_norm"] = round(entry["dense_norm"], 4)
        entry["sparse_raw"] = round(entry["sparse_raw"], 4)
        entry["sparse_norm"] = round(entry["sparse_norm"], 4)
        entry["metadata_raw"] = round(entry["metadata_raw"], 4)
        entry["metadata_norm"] = round(entry["metadata_norm"], 4)

    ordered = sorted(fused.values(), key=lambda e: -e["fused_score"])
    return ordered
