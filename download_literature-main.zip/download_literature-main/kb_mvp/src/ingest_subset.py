#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ingest_subset.py —— 在受限的时间预算内构建一个与 KG 同源的 KB 子集

策略：
1. 读 knowledge_base.json（19934 篇，sha1 paper_uid 为 key）
2. 按关键词过滤出与测试集场景相关的子集（FSS/metasurface/absorber/transparent/...）
3. 跑标准 ingest 流程，但只处理这个子集

输出 SQLite + FAISS + BM25 三件套与全量构建结构完全一致，
只是 paper 数量从 19934 → ~2000，可在 1-2 小时内完成。
"""
from __future__ import annotations

import argparse
import json
import logging
import sys
import io
from pathlib import Path

import sqlite3

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)


# 与最终测试题强相关的关键词
KEYWORDS = [
    # 频率选择表面
    "frequency selective surface", "fss", "frequency-selective",
    # 超表面
    "metasurface", "metamaterial", "meta-surface", "meta-material",
    # 透波/吸波
    "absorber", "absorption", "transparent", "transmission", "transmissive",
    "rasorber", "absorptive",
    # 角度域
    "wide-angle", "wide angle", "oblique", "incidence",
    # 天线罩
    "radome", "antenna",
    # 极化
    "polarization", "dual-polarized", "polarizer",
    # 频段
    "frequency selective", "bandpass", "wideband", "broadband",
    # 高温
    "high-temperature", "high temperature", "thermal",
    # 工艺
    "metasurface design", "fss design",
]


def is_relevant(paper: dict) -> bool:
    """根据 paper_title + extracted_data 关键字段做粗筛。"""
    title = (paper.get("paper_title") or "").lower()
    if not title:
        return False
    # 检查标题
    for kw in KEYWORDS:
        if kw in title:
            return True
    # 检查 extracted_data 几个关键字段（用 design_method / physical_mechanism）
    for fld in ("physical_mechanism", "design_method", "problem_context"):
        v = (paper.get(fld) or "").lower()
        if not v:
            continue
        for kw in KEYWORDS:
            if kw in v:
                return True
    return False


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--kb-json",
                        default="scientific_kgqa/data/knowledge_base.json")
    parser.add_argument("--max-papers", type=int, default=2500,
                        help="最多保留多少篇相关论文（按字典序前N）")
    parser.add_argument("--force", action="store_true", help="重建索引")
    parser.add_argument("--out-json",
                        default="kb_mvp/data/knowledge_base_subset.json",
                        help="筛后子集 JSON 路径")
    args = parser.parse_args()

    project_root = Path(__file__).resolve().parent.parent.parent
    src_json = project_root / args.kb_json
    out_json = project_root / args.out_json

    logger.info("Loading %s ...", src_json)
    with open(src_json, "r", encoding="utf-8") as f:
        data = json.load(f)
    logger.info("Total papers: %d", len(data))

    # 筛选
    subset = {}
    for puid, paper in data.items():
        if is_relevant(paper):
            subset[puid] = paper
            if len(subset) >= args.max_papers:
                break
    logger.info("Subset papers: %d", len(subset))

    out_json.parent.mkdir(parents=True, exist_ok=True)
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(subset, f, ensure_ascii=False)
    logger.info("Subset JSON saved: %s", out_json)

    # 切换 KB_JSON_PATH 指向子集，再跑标准 ingest
    from . import config as kbcfg
    # monkey-patch
    kbcfg.KB_JSON_PATH = out_json
    logger.info("Patched config.KB_JSON_PATH = %s", out_json)

    from .ingest import init_db, ingest_metadata_and_chunks, build_faiss_index, build_bm25_index
    conn = init_db(kbcfg.DB_PATH, force=args.force)
    chunks = ingest_metadata_and_chunks(conn, subset)
    build_faiss_index(chunks, conn)
    build_bm25_index(chunks)
    conn.close()
    logger.info("Subset ingest done: %d chunks", len(chunks))


if __name__ == "__main__":
    main()
