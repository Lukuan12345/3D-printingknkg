#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
answer_generator.py - 回答生成器（Phase 5）

功能：
1. 从检索结果中提取信息
2. 调用LLM生成综合技术回答
3. 添加引用标注[1][2]
4. 返回结构化回答JSON

用法：
    generator = AnswerGenerator()
    answer = generator.generate(question, query_json, top_chunks)
"""

import sys
import json
import re
import logging
from pathlib import Path
from typing import Dict, List, Any, Optional

# 添加项目路径
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from literature_knowledge_extractor.llm_client import call_llm
from literature_knowledge_extractor.config import DEFAULT_CONFIG

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)


class AnswerGenerator:
    """
    回答生成器

    从检索结果生成带引用标注的综合技术回答
    """

    def __init__(self):
        """初始化回答生成器"""
        # 配置LLM
        llm_config = DEFAULT_CONFIG.get('llm', {})
        self.api_base_url = llm_config.get('base_url')
        self.api_key = llm_config.get('api_key')
        self.model_name = llm_config.get('model_name')

    def generate(self,
                question: str,
                query_json: Dict[str, Any],
                top_chunks: List[Dict[str, Any]],
                max_chunks: int = 5) -> Dict[str, Any]:
        """
        生成综合技术回答

        Args:
            question: 原始问题
            query_json: 结构化查询JSON
            top_chunks: 检索结果（已排序）
            max_chunks: 最多使用的chunk数

        Returns:
            {
                "answer": str,               # 主回答
                "confidence": float,          # 置信度
                "key_findings": List[str],   # 关键发现
                "limitations": str,           # 知识库局限
                "citation_details": List[dict]  # 引用详情
            }
        """
        logger.info(f"Generating answer for: {question[:50]}...")

        # 1. 构建context
        context = self._build_context(top_chunks[:max_chunks])

        # 2. 构建Prompt
        system_prompt = self._build_system_prompt()
        user_prompt = self._build_user_prompt(question, query_json, context)

        # 3. 调用LLM
        try:
            response = call_llm(
                prompt=user_prompt,
                system_prompt=system_prompt,
                base_url=self.api_base_url,
                api_key=self.api_key,
                model_name=self.model_name,
                temperature=0.3,  # 适中温度，平衡创造性和准确性
                max_tokens=4000,
                max_retries=5,
                retry_delay=10
            )

            if not response:
                raise ValueError("LLM返回为空")

            # 4. 解析回答
            answer_json = self._parse_answer(response)

            # 5. 添加引用详情
            answer_json['citation_details'] = self._build_citations(top_chunks[:max_chunks])

            # 6. 计算置信度
            answer_json['confidence'] = self._calculate_confidence(answer_json, top_chunks)

            logger.info(f"[OK] Answer generated (confidence={answer_json['confidence']:.2f})")
            return answer_json

        except Exception as e:
            logger.error(f"Answer generation failed: {e}")
            return {
                "answer": f"抱歉，无法生成回答。原因：{str(e)}",
                "confidence": 0.0,
                "key_findings": [],
                "limitations": "回答生成失败",
                "citation_details": [],
                "error": str(e)
            }

    def _build_context(self, chunks: List[Dict[str, Any]]) -> List[Dict[str, str]]:
        """
        构建LLM的context

        Args:
            chunks: chunk列表

        Returns:
            [{paper_id, title, field_type, content}, ...]
        """
        context = []
        for i, chunk in enumerate(chunks, 1):
            context.append({
                "id": i,
                "paper_id": chunk.get('paper_id', 'N/A'),
                "title": chunk.get('title', 'N/A'),
                "field_type": chunk.get('field_type', 'N/A'),
                "content": chunk.get('content', '')[:800],  # 限制长度
                "fused_score": chunk.get('fused_score', 0.0)
            })
        return context

    def _build_system_prompt(self) -> str:
        """构建System Prompt"""
        return """你是科学/技术文献领域的技术专家。你的任务是基于检索到的文献片段，生成准确、专业的技术回答。

# 回答要求

1. **准确性优先**：只引用context中的信息，不编造内容
2. **引用标注**：每个关键陈述后添加[1][2]等引用标记
3. **结构化**：分段落组织，逻辑清晰
4. **专业性**：使用领域术语，但确保可读性
5. **完整性**：覆盖问题的所有关键点

# 引用规则

- 每个具体数据、方法、结论后必须添加引用[N]
- 引用编号对应context中的文献ID
- 同一信息可以来自多个文献：[1][2]

# 输出格式

严格按照以下JSON格式输出：

```json
{
  "answer": "主回答文本（包含引用标注[1][2]）",
  "key_findings": ["关键发现1", "关键发现2"],
  "limitations": "知识库未覆盖的内容或局限性"
}
```

# 示例（格式示意，与具体领域无关）

输入问题：<某技术问题>
Context: [1] <证据片段一> [2] <证据片段二>

输出：
{
  "answer": "<结合 [1][2] 证据的专业回答，关键陈述后带引用标记>",
  "key_findings": [
    "<关键发现一[1]>",
    "<关键发现二[2]>"
  ],
  "limitations": "<知识库未覆盖的内容或局限性>"
}
"""

    def _build_user_prompt(self,
                          question: str,
                          query_json: Dict[str, Any],
                          context: List[Dict[str, str]]) -> str:
        """构建User Prompt"""
        # 格式化context
        context_text = "\n\n".join([
            f"[{ctx['id']}] {ctx['paper_id']} - {ctx['title']}\n"
            f"字段类型: {ctx['field_type']}\n"
            f"内容: {ctx['content']}"
            for ctx in context
        ])

        # 格式化查询意图
        query_intent = []
        if 'operating_frequency_range' in query_json:
            query_intent.append(f"频段: {query_json['operating_frequency_range']}")
        if 'substrate_material' in query_json:
            materials = query_json['substrate_material']
            if isinstance(materials, list):
                materials = ', '.join(materials)
            query_intent.append(f"材料: {materials}")
        if 'structure_class' in query_json:
            structures = query_json['structure_class']
            if isinstance(structures, list):
                structures = ', '.join(structures[:2])
            query_intent.append(f"结构: {structures}")

        query_intent_text = '\n'.join([f"  - {item}" for item in query_intent])

        return f"""# 用户问题

{question}

# 查询意图（结构化）

{query_intent_text}

# 检索到的文献片段（Context）

{context_text}

---

请基于上述context生成技术回答。记住：
1. 每个关键陈述后添加引用[N]
2. 不要编造context中没有的信息
3. 如果context不足以回答某个方面，在limitations中说明
4. 输出严格遵守JSON格式

请输出JSON："""

    def _parse_answer(self, response: str) -> Dict[str, Any]:
        """
        解析LLM回复

        Args:
            response: LLM原始回复

        Returns:
            解析后的JSON
        """
        # 提取JSON
        json_text = self._extract_json(response)

        try:
            answer_json = json.loads(json_text)

            # 验证必需字段
            if 'answer' not in answer_json:
                raise ValueError("Missing 'answer' field")

            # 设置默认值
            answer_json.setdefault('key_findings', [])
            answer_json.setdefault('limitations', '')

            return answer_json

        except json.JSONDecodeError as e:
            logger.error(f"JSON parse error: {e}")
            logger.error(f"Problematic JSON text (first 500 chars): {json_text[:500]}")

            # 尝试二次解析：处理JSON中的转义问题
            try:
                # 尝试修复常见的JSON格式问题
                # 1. 移除```json和```标记
                cleaned_text = json_text.replace('```json', '').replace('```', '').strip()
                # 2. 尝试解析
                answer_json = json.loads(cleaned_text)

                if 'answer' in answer_json:
                    answer_json.setdefault('key_findings', [])
                    answer_json.setdefault('limitations', '')
                    logger.info("Successfully parsed JSON after cleaning")
                    return answer_json
            except:
                pass

            # 如果二次解析也失败，返回清理后的文本（移除代码块标记）
            cleaned_response = response
            # 移除```json代码块标记
            if '```json' in cleaned_response:
                cleaned_response = cleaned_response.split('```json')[1].split('```')[0].strip()
            elif '```' in cleaned_response:
                cleaned_response = cleaned_response.split('```')[1].split('```')[0].strip()

            # 尝试从清理后的文本中提取answer字段
            if '{' in cleaned_response and '}' in cleaned_response:
                try:
                    temp_json = json.loads(cleaned_response)
                    if 'answer' in temp_json:
                        temp_json.setdefault('key_findings', [])
                        temp_json.setdefault('limitations', '回答格式轻微异常，已修复')
                        logger.info("Successfully extracted answer from cleaned text")
                        return temp_json
                except:
                    pass

            # 最后兜底：返回原始文本，但确保没有代码块标记
            return {
                "answer": cleaned_response if cleaned_response else response,
                "key_findings": [],
                "limitations": "回答格式解析失败"
            }

    def _extract_json(self, text: str) -> str:
        """从LLM回复中提取JSON"""
        if '```json' in text:
            return text.split('```json')[1].split('```')[0].strip()
        elif '```' in text:
            return text.split('```')[1].split('```')[0].strip()
        else:
            # 尝试找到第一个{和最后一个}
            start = text.find('{')
            end = text.rfind('}')
            if start >= 0 and end > start:
                return text[start:end+1]
            return text

    def _build_citations(self, chunks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        构建引用详情列表

        Args:
            chunks: chunk列表

        Returns:
            引用详情列表
        """
        citations = []
        for i, chunk in enumerate(chunks, 1):
            citations.append({
                "id": i,
                "paper_id": chunk.get('paper_id', 'N/A'),
                "title": chunk.get('title', 'N/A'),
                "field_type": chunk.get('field_type', 'N/A'),
                "fused_score": chunk.get('fused_score', 0.0),
                "metadata_score": chunk.get('metadata_score', 0.0),
                "dense_score": chunk.get('dense_score', 0.0),
                "sparse_score": chunk.get('sparse_score', 0.0)
            })
        return citations

    def _calculate_confidence(self,
                             answer_json: Dict[str, Any],
                             chunks: List[Dict[str, Any]]) -> float:
        """
        计算回答置信度

        考虑因素：
        1. 顶部chunk的分数
        2. 引用数量
        3. 是否有关键发现

        Args:
            answer_json: 生成的回答
            chunks: 使用的chunk

        Returns:
            置信度（0-1）
        """
        confidence = 0.0

        # 1. 顶部chunk分数（权重0.5）
        if chunks:
            top_score = chunks[0].get('fused_score', 0.0)
            confidence += 0.5 * top_score

        # 2. 引用数量（权重0.3）
        answer_text = answer_json.get('answer', '')
        citation_count = len(re.findall(r'\[\d+\]', answer_text))
        citation_score = min(citation_count / 5.0, 1.0)  # 5个引用=满分
        confidence += 0.3 * citation_score

        # 3. 关键发现数量（权重0.2）
        findings_count = len(answer_json.get('key_findings', []))
        findings_score = min(findings_count / 3.0, 1.0)  # 3个发现=满分
        confidence += 0.2 * findings_score

        return min(confidence, 1.0)


def main():
    """测试回答生成器"""
    print("="*70)
    print("回答生成器测试")
    print("="*70)

    # 初始化
    generator = AnswerGenerator()

    # 测试数据
    test_question = "FR4基板X波段吸波体如何设计？"
    test_query_json = {
        "operating_frequency_range": "8-12 GHz",
        "substrate_material": ["FR4"],
        "structure_class": ["metamaterial absorber"]
    }
    test_chunks = [
        {
            "paper_id": "P001",
            "title": "FR4-based X-band Metamaterial Absorber",
            "field_type": "physical_mechanism",
            "content": "This paper presents a metamaterial absorber using FR4 substrate (εr=4.4, tanδ=0.02) for X-band applications. The design achieves >90% absorption rate in 8-12 GHz frequency range with thickness <2mm. A square ring resonator topology with 6mm periodicity is employed.",
            "fused_score": 0.95
        },
        {
            "paper_id": "P002",
            "title": "Polarization-insensitive Absorber Design",
            "content": "Cross-shaped resonators provide excellent polarization-insensitive performance due to four-fold symmetry. The unit cell period of 5-7mm is optimal for X-band applications.",
            "field_type": "design_method",
            "fused_score": 0.82
        }
    ]

    print(f"\n问题: {test_question}")
    print(f"\n生成回答...")

    # 生成回答
    answer = generator.generate(test_question, test_query_json, test_chunks)

    # 显示结果
    print(f"\n{'='*70}")
    print(f"生成的回答:")
    print(f"{'='*70}")
    print(f"\n{answer.get('answer', 'N/A')}")

    print(f"\n关键发现:")
    for i, finding in enumerate(answer.get('key_findings', []), 1):
        print(f"  {i}. {finding}")

    print(f"\n局限性:")
    print(f"  {answer.get('limitations', 'N/A')}")

    print(f"\n置信度: {answer.get('confidence', 0.0):.2f}")

    print(f"\n引用详情:")
    for cite in answer.get('citation_details', []):
        print(f"  [{cite['id']}] {cite['paper_id']} (score={cite['fused_score']:.2f})")

    print(f"\n{'='*70}")
    print("[OK] 回答生成器测试完成！")
    print(f"{'='*70}")


if __name__ == '__main__':
    main()
