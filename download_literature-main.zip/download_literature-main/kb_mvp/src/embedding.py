#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
embedding.py -- Embedding 客户端（本地优先，API 兜底）

优先级：
  1. 本地 BGE-M3（models/bge-m3/ 或 HF cache）-- 无网络限制，速度取决于 CPU/GPU
  2. 远程 API（35.220.164.252:3888）          -- 有 TPM 限速，需要网络

本地模型路径（按优先级查找，见 _LOCAL_MODEL_CANDIDATES）：
  - retrieval_weights/models/bge-m3/   （首选；huggingface-cli download 到此目录）
  - retrieval_weights/bge-m3/
  - PROJECT_ROOT/models/bge-m3/
  - HF_HOME 缓存（~/.cache/huggingface/hub/models--BAAI--bge-m3）
  - 自动从 HuggingFace 下载（首次使用时，约 2.3GB）

预下命令（可选；缺模型会自动拉取）：
  huggingface-cli download BAAI/bge-m3 --local-dir retrieval_weights/models/bge-m3

用法：
  from kb_mvp.src.embedding import get_client
  client = get_client()
  vec = client.embed_one("some text")
  vecs = client.embed(["text1", "text2"])   # shape=(2, 1024)
"""

import hashlib
import json
import logging
import os
import threading
import time
from pathlib import Path
from typing import List, Optional

import numpy as np
import requests

from . import config

logger = logging.getLogger(__name__)

# 项目根下的本地模型路径，按优先级依次查找
_PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
# 显式 env 覆盖（EMBED_MODEL_DIR）排在最前：可指向共享盘上已有的 bge-m3 权重，
# 无需把 2.3GB 拷进本仓库。例如：
#   EMBED_MODEL_DIR=/mnt/shared-storage-user/suyulin/literature_knowledge_extractor_new/retrieval_weights/models/bge-m3
_LOCAL_MODEL_CANDIDATES = [
    p for p in [
        Path(os.environ["EMBED_MODEL_DIR"]).expanduser() if os.environ.get("EMBED_MODEL_DIR") else None,
        _PROJECT_ROOT / "retrieval_weights" / "models" / "bge-m3",
        _PROJECT_ROOT / "retrieval_weights" / "bge-m3",
        _PROJECT_ROOT / "models" / "bge-m3",
    ] if p is not None
]
_LOCAL_MODEL_DIR = next(
    (p for p in _LOCAL_MODEL_CANDIDATES if p.exists() and (p / "config.json").exists()),
    _LOCAL_MODEL_CANDIDATES[0],  # 不存在时占位，LocalEmbeddingClient 内部会走 HF 下载
)


# ============================================================
# 本地模型客户端（sentence-transformers）
# ============================================================

class LocalEmbeddingClient:
    """使用本地 BGE-M3 权重，无网络限制。"""

    def __init__(self, model_path: Optional[str] = None, batch_size: Optional[int] = None,
                 cache_path: Optional[Path] = None):
        from sentence_transformers import SentenceTransformer
        import torch

        if model_path is None:
            if _LOCAL_MODEL_DIR.exists() and (_LOCAL_MODEL_DIR / "config.json").exists():
                model_path = str(_LOCAL_MODEL_DIR)
                logger.info("LocalEmbeddingClient: using project-local model %s", model_path)
            else:
                model_path = "BAAI/bge-m3"
                logger.info("LocalEmbeddingClient: loading BAAI/bge-m3 (may download ~2.3GB)")

        device = "cuda" if torch.cuda.is_available() else "cpu"
        # 未显式指定时：GPU 默认 256，CPU 默认 128
        self.batch_size = batch_size if batch_size else (256 if device == "cuda" else 128)
        logger.info("LocalEmbeddingClient: device=%s  batch_size=%d  model=%s",
                    device, self.batch_size, model_path)
        self.model = SentenceTransformer(model_path, device=device)
        self.cache_path = cache_path
        self.cache: dict = {}
        self._cache_lock = threading.Lock()   # 并发测评时多线程共享同一 client
        if cache_path and cache_path.exists():
            try:
                with open(cache_path, encoding="utf-8") as f:
                    self.cache = json.load(f)
                logger.info("Loaded %d cached embeddings", len(self.cache))
            except Exception:
                self.cache = {}

        # 测速
        dummy = self.model.encode(["warmup"], batch_size=1, show_progress_bar=False)
        logger.info("LocalEmbeddingClient ready: dim=%d", dummy.shape[-1])

    @staticmethod
    def _hash(text: str) -> str:
        return hashlib.md5(text.encode("utf-8")).hexdigest()

    def embed(self, texts: List[str]) -> np.ndarray:
        if not texts:
            return np.zeros((0, config.EMBEDDING_DIM), dtype=np.float32)

        results = [None] * len(texts)
        to_encode_idx = []
        to_encode_texts = []

        for i, t in enumerate(texts):
            if not t or not t.strip():
                results[i] = np.zeros(config.EMBEDDING_DIM, dtype=np.float32)
            else:
                h = self._hash(t)
                if h in self.cache:
                    results[i] = self.cache[h]
                else:
                    to_encode_idx.append(i)
                    to_encode_texts.append(t)

        if to_encode_texts:
            t0 = time.perf_counter()
            vecs = self.model.encode(
                to_encode_texts,
                batch_size=self.batch_size,
                show_progress_bar=len(to_encode_texts) > 500,
                normalize_embeddings=True,
            )
            elapsed = time.perf_counter() - t0
            logger.info("Local embed: %d texts in %.1fs (%.0f texts/s)",
                        len(to_encode_texts), elapsed,
                        len(to_encode_texts) / max(elapsed, 0.001))
            for j, (idx, text) in enumerate(zip(to_encode_idx, to_encode_texts)):
                results[idx] = vecs[j].tolist()
                with self._cache_lock:
                    self.cache[self._hash(text)] = vecs[j].tolist()

            if self.cache_path:
                self.cache_path.parent.mkdir(parents=True, exist_ok=True)
                with self._cache_lock:   # 锁内完成 dump+写盘，避免并发截断同一文件
                    with open(self.cache_path, "w", encoding="utf-8") as f:
                        json.dump(self.cache, f, ensure_ascii=False)

        return np.asarray(results, dtype=np.float32)

    def embed_one(self, text: str) -> np.ndarray:
        return self.embed([text])[0]


# ============================================================
# 远程 API 客户端（原有实现）
# ============================================================

class APIEmbeddingClient:
    """调用远程 /v1/embeddings 接口（带缓存、重试）。"""

    def __init__(self, model: str = config.EMBEDDING_MODEL,
                 batch_size: int = config.EMBEDDING_BATCH_SIZE,
                 max_retries: int = None,
                 retry_delay: int = None,
                 cache_path: Optional[Path] = None):
        self.model = model
        self.batch_size = batch_size
        # 重试次数/退避默认走环境变量，部署时可调低以免端点不可达时空等十几分钟。
        #   EMBED_MAX_RETRIES（默认 3）、EMBED_RETRY_DELAY 秒（默认 3）。
        self.max_retries = int(os.environ.get("EMBED_MAX_RETRIES", "3")) if max_retries is None else max_retries
        self.retry_delay = int(os.environ.get("EMBED_RETRY_DELAY", "3")) if retry_delay is None else retry_delay
        self.cache_path = cache_path
        self.cache: dict = {}
        self._cache_lock = threading.Lock()   # 并发测评时多线程共享同一 client
        if cache_path and cache_path.exists():
            try:
                with open(cache_path, encoding="utf-8") as f:
                    self.cache = json.load(f)
                logger.info("Loaded %d cached embeddings from %s", len(self.cache), cache_path)
            except Exception as exc:
                logger.warning("Failed to load embedding cache: %s", exc)

        # 代理策略：默认跳过系统代理（构建机内网直连 embedding 端点）。
        # 但隔离部署容器里 embedding 端点是公网，必须经出网代理中转——
        # 设 EMBED_TRUST_ENV=1 让 session 读取 http_proxy/https_proxy/no_proxy，
        # 否则直连公网会一路 Timeout 重试到失败。
        self._session = requests.Session()
        _trust = os.environ.get("EMBED_TRUST_ENV", "").strip().lower()
        self._session.trust_env = _trust in ("1", "true", "yes")

    @staticmethod
    def _hash(text: str) -> str:
        return hashlib.md5(text.encode("utf-8")).hexdigest()

    def _request_batch(self, texts: List[str]) -> List[List[float]]:
        url = config.API_BASE_URL.rstrip("/") + "/v1/embeddings"
        payload = {"input": texts, "model": self.model, "encoding_format": "float"}
        headers = {"Content-Type": "application/json",
                   "Authorization": f"Bearer {config.API_KEY}"}
        for attempt in range(1, self.max_retries + 1):
            try:
                r = self._session.post(url, json=payload, headers=headers, timeout=60)
                if r.status_code == 200:
                    return [d["embedding"] for d in r.json()["data"]]
                elif r.status_code in (429, 500, 502, 503, 504):
                    backoff = min(self.retry_delay * (2 ** (attempt - 1)), 120)
                    logger.warning("Server %d, retry %d/%d in %ds",
                                   r.status_code, attempt, self.max_retries, backoff)
                    time.sleep(backoff)
                else:
                    raise RuntimeError(f"HTTP {r.status_code}: {r.text[:300]}")
            except requests.exceptions.Timeout:
                backoff = min(self.retry_delay * (2 ** (attempt - 1)), 120)
                logger.warning("Timeout, retry %d/%d in %ds", attempt, self.max_retries, backoff)
                time.sleep(backoff)
            except requests.exceptions.RequestException as exc:
                backoff = min(self.retry_delay * (2 ** (attempt - 1)), 120)
                logger.warning("Network error %s, retry %d/%d in %ds",
                               exc, attempt, self.max_retries, backoff)
                time.sleep(backoff)
        raise RuntimeError(f"Embedding API failed after {self.max_retries} retries")

    def embed(self, texts: List[str]) -> np.ndarray:
        if not texts:
            return np.zeros((0, config.EMBEDDING_DIM), dtype=np.float32)
        results = [None] * len(texts)
        to_fetch_idx, to_fetch_texts = [], []
        for i, t in enumerate(texts):
            if not t or not t.strip():
                results[i] = [0.0] * config.EMBEDDING_DIM
            else:
                h = self._hash(t)
                if h in self.cache:
                    results[i] = self.cache[h]
                else:
                    to_fetch_idx.append(i)
                    to_fetch_texts.append(t)

        if to_fetch_texts:
            logger.info("API embedding %d texts...", len(to_fetch_texts))
            n_batches = (len(to_fetch_texts) + self.batch_size - 1) // self.batch_size
            batch_idx = 0
            for start in range(0, len(to_fetch_texts), self.batch_size):
                chunk = to_fetch_texts[start:start + self.batch_size]
                vecs = self._request_batch(chunk)   # 网络请求在锁外，不串行化并发调用
                with self._cache_lock:
                    for j, v in enumerate(vecs):
                        results[to_fetch_idx[start + j]] = v
                        self.cache[self._hash(to_fetch_texts[start + j])] = v
                batch_idx += 1
                if self.cache_path and batch_idx % 100 == 0:
                    with self._cache_lock:   # 锁内完成 dump+写盘，避免并发截断同一文件
                        with open(self.cache_path, "w", encoding="utf-8") as f:
                            json.dump(self.cache, f, ensure_ascii=False)
                        n_entries = len(self.cache)
                    logger.info("Cache snapshot: %d entries (%d/%d batches, %.0f%%)",
                                n_entries, batch_idx, n_batches,
                                100.0 * batch_idx / max(1, n_batches))
            if self.cache_path:
                with self._cache_lock:
                    with open(self.cache_path, "w", encoding="utf-8") as f:
                        json.dump(self.cache, f, ensure_ascii=False)
        return np.asarray(results, dtype=np.float32)

    def embed_one(self, text: str) -> np.ndarray:
        return self.embed([text])[0]


# ============================================================
# 工厂：自动选择本地 or API
# ============================================================

_default_client: Optional[object] = None


def get_client() -> "LocalEmbeddingClient | APIEmbeddingClient":
    """
    根据 EMBED_MODE 环境变量选择 embedding 客户端：
      - "auto"（默认）：本地模型存在则用 LocalEmbeddingClient，否则 APIEmbeddingClient
      - "local"：强制本地（模型不存在时抛错）
      - "api"：强制远程 API
    """
    global _default_client
    if _default_client is not None:
        return _default_client

    cache_path = config.INDEX_DIR / "embedding_cache.json"
    mode = config.EMBED_MODE

    local_available = _LOCAL_MODEL_DIR.exists() and (_LOCAL_MODEL_DIR / "config.json").exists()

    if mode == "local" or (mode == "auto" and local_available):
        logger.info("get_client: using LocalEmbeddingClient (model=%s)", _LOCAL_MODEL_DIR)
        _default_client = LocalEmbeddingClient(
            model_path=str(_LOCAL_MODEL_DIR) if local_available else None,
            cache_path=cache_path,
        )
    else:
        logger.info("get_client: using APIEmbeddingClient (remote=%s)", config.API_BASE_URL)
        _default_client = APIEmbeddingClient(cache_path=cache_path)

    return _default_client
