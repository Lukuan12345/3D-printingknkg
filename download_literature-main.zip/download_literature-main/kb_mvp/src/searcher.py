#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
searcher.py —— Phase 5：完整混合检索流水线

对应 PDF 的漏斗式检索模型：
    1. Metadata 预过滤 (JSONB)          → paper_ids / chunk 白名单
    2. 双路并发召回 (Dense + Sparse)    → 各 Top-K
    3. 融合重排序                       → Top-K 最终结果
"""

import io
import sys
import json
import logging
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import List, Dict, Optional, Any

from . import config
from .prefilter import MetadataFilter
from .dense_retrieval import DenseRetriever
from .sparse_retrieval import SparseRetriever
from .fusion import fuse
from .metadata_scorer import MetadataScorer  # 新增

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

logger = logging.getLogger(__name__)


# ============================================================
# HybridSearcher —— 主入口
# ============================================================

class HybridSearcher:
    """
    混合检索引擎（对应 PDF 三层漏斗）。

    基本用法:
        searcher = HybridSearcher()
        results = searcher.search(
            query="FR4 基板吸波体在 8-12 GHz 如何设计",
            filters={"schema_contains": {"substrate_material": "FR4"}},
            top_k=5,
        )
    """

    def __init__(self):
        logger.info("Initializing HybridSearcher ...")
        self.prefilter = MetadataFilter()
        self.dense  = DenseRetriever()
        self.sparse = SparseRetriever()

        # Phase 3: 新增Metadata打分器
        if config.ENABLE_THREE_WAY_FUSION:
            self.metadata_scorer = MetadataScorer()
            logger.info("Three-way fusion enabled (Metadata + Dense + Sparse)")
        else:
            self.metadata_scorer = None
            logger.info("Two-way fusion (Dense + Sparse only)")

        logger.info("HybridSearcher ready.")

    # ------------------------------------------------------------
    def _resolve_chunk_candidates(
        self, filters: Optional[Dict[str, Any]]
    ) -> tuple:
        """
        根据 filters 解析出预过滤后的 chunk 白名单。
        返回: (paper_ids, chunk_faiss_indices, chunk_ids)

        Perf: 当 paper_ids 接近全库（≥95%）时跳过 `WHERE paper_id IN (?,...)`，
        改为全表扫描——SQLite 在 IN 列表巨大时性能急剧下降（19934 参数 ~48s），
        全表扫只需几秒。
        """
        paper_ids = self.prefilter.filter(filters or {})
        if not paper_ids:
            return [], [], []

        # 缓存全库 paper 总数
        if not hasattr(self.prefilter, "_total_paper_count"):
            row = self.prefilter.conn.execute(
                "SELECT COUNT(*) FROM papers_metadata"
            ).fetchone()
            self.prefilter._total_paper_count = int(row[0]) if row else 0

        total = self.prefilter._total_paper_count
        # filter 接近全库 → 跳过 IN，直接全表查 paper_chunks
        if total > 0 and len(paper_ids) >= int(total * 0.95):
            sql = ("SELECT chunk_id, embedding_idx FROM paper_chunks "
                   "WHERE embedding_idx IS NOT NULL")
            rows = self.prefilter.conn.execute(sql).fetchall()
        else:
            placeholders = ",".join(["?"] * len(paper_ids))
            sql = (f"SELECT chunk_id, embedding_idx FROM paper_chunks "
                   f"WHERE paper_id IN ({placeholders}) AND embedding_idx IS NOT NULL")
            rows = self.prefilter.conn.execute(sql, paper_ids).fetchall()
        chunk_ids     = [r["chunk_id"]      for r in rows]
        faiss_indices = [r["embedding_idx"] for r in rows]
        return paper_ids, faiss_indices, chunk_ids

    # ------------------------------------------------------------
    def search(
        self,
        query: str,
        query_json: Optional[Dict[str, Any]] = None,  # 结构化查询JSON
        filters: Optional[Dict[str, Any]] = None,
        top_k: int = config.TOP_K_FINAL,
        w_dense: float = config.WEIGHT_DENSE,
        w_sparse: float = config.WEIGHT_SPARSE,
        w_metadata: float = None,  # metadata权重（仅三路融合时使用）
        top_k_each: int = 20,
        dedupe_by_paper: bool = True,
        # ── v2 新增：KG 引导的 chunk 白名单（来自 S3 BridgeKGtoKB）──
        chunk_id_whitelist: Optional[set] = None,
        chunk_type_filter: Optional[set] = None,
        kg_anchor_papers: Optional[Dict[str, float]] = None,
        w_kg_anchor: float = 0.0,
    ) -> Dict[str, Any]:
        """
        三层漏斗检索（v2 支持 KG 引导白名单）。

        Args:
            chunk_id_whitelist:  来自 KG 推演的 chunk 白名单。
                                 提供时三路融合**仅在白名单内召回**；为空时退回全库。
            chunk_type_filter:   仅保留 paper_chunks.field_type ∈ 此集合的 chunk
                                 （用于按 EXPECTED_IN 路标限定）
            kg_anchor_papers:    paper_id → KG 锚定分（softmax 权重和）。
                                 final_score 上加 w_kg_anchor * anchor[paper_id]
            w_kg_anchor:         KG 锚定分在融合中的权重，默认 0（关）
        """
        # --- Step 1: 候选 chunk 集合 ---
        if chunk_id_whitelist:
            # v2: 用 KG 提供的白名单
            sql = (
                "SELECT chunk_id, embedding_idx FROM paper_chunks "
                "WHERE chunk_id IN ({}) AND embedding_idx IS NOT NULL"
            ).format(",".join("?" * len(chunk_id_whitelist)))
            rows = self.prefilter.conn.execute(sql, list(chunk_id_whitelist)).fetchall()
            chunk_ids = [r["chunk_id"] for r in rows]
            faiss_indices = [r["embedding_idx"] for r in rows]
            paper_ids = list({r["chunk_id"].split("_", 1)[0] for r in rows
                              if "_" in r["chunk_id"]})
            # 再按 chunk_type_filter 削
            if chunk_type_filter:
                ph = ",".join("?" * len(chunk_ids))
                type_rows = self.prefilter.conn.execute(
                    f"SELECT chunk_id, field_type FROM paper_chunks WHERE chunk_id IN ({ph})",
                    chunk_ids,
                ).fetchall()
                keep_cids = {r["chunk_id"] for r in type_rows
                             if r["field_type"] in chunk_type_filter}
                if keep_cids and len(keep_cids) >= 10:  # 防过滤过空
                    chunk_ids = [c for c in chunk_ids if c in keep_cids]
                    faiss_indices = [r["embedding_idx"] for r in rows if r["chunk_id"] in keep_cids]
            logger.info(
                "KG-whitelist mode: %d chunks from %d unique papers (type_filter=%s)",
                len(chunk_ids), len(paper_ids),
                list(chunk_type_filter) if chunk_type_filter else None,
            )
        else:
            paper_ids, faiss_indices, chunk_ids = self._resolve_chunk_candidates(filters)
            logger.info("Pre-filter: %d papers → %d candidate chunks",
                        len(paper_ids), len(chunk_ids))

        if not chunk_ids:
            logger.warning("候选 chunk 为空，回退为全库检索")
            faiss_indices = None
            chunk_ids = None

        # --- Step 2: 并发召回（二路或三路）---
        if config.ENABLE_THREE_WAY_FUSION and self.metadata_scorer and query_json:
            # 三路并发
            logger.info("Three-way retrieval: Metadata + Dense + Sparse")

            # 确定metadata权重
            if w_metadata is None:
                w_metadata = config.WEIGHT_METADATA
                w_dense = config.WEIGHT_DENSE_V2
                w_sparse = config.WEIGHT_SPARSE_V2

            with ThreadPoolExecutor(max_workers=3) as ex:
                metadata_future = ex.submit(self.metadata_scorer.score,
                                          query_json, config.TOP_K_METADATA)
                dense_future  = ex.submit(self.dense.search,
                                         query, faiss_indices, top_k_each)
                sparse_future = ex.submit(self.sparse.search,
                                         query, chunk_ids, top_k_each)

                metadata_scores = metadata_future.result()
                dense_hits  = dense_future.result()
                sparse_hits = sparse_future.result()

            logger.info("Three-way recall: metadata=%d, dense=%d, sparse=%d",
                       len(metadata_scores), len(dense_hits), len(sparse_hits))

            # 构建chunk_id -> paper_id映射
            all_chunk_ids = set([hit[0] for hit in dense_hits] + [hit[0] for hit in sparse_hits])
            chunk_to_paper_map = self._build_chunk_to_paper_map(list(all_chunk_ids))

            # --- Step 3: 三路融合 ---
            from .fusion import fuse_three_way
            fused = fuse_three_way(metadata_scores, dense_hits, sparse_hits,
                                  chunk_to_paper_map, w_metadata, w_dense, w_sparse)

            # --- Step 4: 富化 + 论文去重 ---
            enriched = self._enrich_three_way(fused, metadata_scores)
            # v2: KG anchor bonus
            if kg_anchor_papers and w_kg_anchor > 0:
                # 归一 anchor 分到 [0,1]
                anchor_max = max(kg_anchor_papers.values()) if kg_anchor_papers else 1.0
                anchor_max = anchor_max if anchor_max > 0 else 1.0
                for c in enriched:
                    raw = kg_anchor_papers.get(c.get("paper_id"), 0.0)
                    norm = raw / anchor_max
                    c["kg_anchor_score"] = round(norm, 4)
                    c["fused_score"] = (c.get("fused_score", 0) or 0) + w_kg_anchor * norm
                enriched.sort(key=lambda c: -float(c.get("fused_score") or 0))
            if dedupe_by_paper:
                enriched = self._dedupe_by_paper(enriched)

            return {
                "top_k": enriched[:top_k],
                "metadata_scores": metadata_scores,
                "stats": {
                    "mode": "three_way",
                    "metadata_hits": len(metadata_scores),
                    "dense_hits": len(dense_hits),
                    "sparse_hits": len(sparse_hits),
                    "fused_hits": len(fused),
                    "final_hits": len(enriched[:top_k]),
                    "kg_whitelist_mode": chunk_id_whitelist is not None,
                    "kg_anchor_applied": bool(kg_anchor_papers and w_kg_anchor > 0),
                }
            }

        else:
            # 二路并发（原有逻辑）
            logger.info("Two-way retrieval: Dense + Sparse")

            with ThreadPoolExecutor(max_workers=2) as ex:
                dense_future  = ex.submit(self.dense.search,
                                         query, faiss_indices, top_k_each)
                sparse_future = ex.submit(self.sparse.search,
                                         query, chunk_ids, top_k_each)
                dense_hits  = dense_future.result()
                sparse_hits = sparse_future.result()

            logger.info("Two-way recall: dense=%d, sparse=%d",
                       len(dense_hits), len(sparse_hits))

            # --- Step 3: 融合重排序 ---
            fused = fuse(dense_hits, sparse_hits, w_dense, w_sparse)

            # --- Step 4: 富化 + 论文去重 ---
            enriched = self._enrich(fused)
            if dedupe_by_paper:
                enriched = self._dedupe_by_paper(enriched)

            return {
                "top_k": enriched[:top_k],
                "metadata_scores": None,
                "stats": {
                    "mode": "two_way",
                    "dense_hits": len(dense_hits),
                    "sparse_hits": len(sparse_hits),
                    "fused_hits": len(fused),
                    "final_hits": len(enriched[:top_k])
                }
            }

    # ------------------------------------------------------------
    def _enrich(self, fused: List[Dict]) -> List[Dict]:
        """给 fused 结果附上 paper 元数据和 chunk 内容。"""
        if not fused:
            return []
        chunk_ids = [f["chunk_id"] for f in fused]
        info_map = {c["chunk_id"]: c for c in self.prefilter.get_chunk_info(chunk_ids)}

        out = []
        for f in fused:
            info = info_map.get(f["chunk_id"], {})
            # 生成匹配原因
            reasons = []
            if f["dense_rank"]:
                reasons.append(f"dense #{f['dense_rank']} cos={f['dense_raw']:.3f}")
            if f["sparse_rank"]:
                reasons.append(f"bm25 #{f['sparse_rank']} score={f['sparse_raw']:.2f}")
            out.append({
                "paper_id":    info.get("paper_id"),
                "title":       info.get("title"),
                "chunk_id":    f["chunk_id"],
                "field_type":  info.get("field_type"),
                "content":     info.get("content", ""),
                "embedding_idx": info.get("embedding_idx"),
                "fused_score": f["fused_score"],
                "dense_score": f["dense_norm"],
                "sparse_score": f["sparse_norm"],
                "dense_raw":   f["dense_raw"],
                "sparse_raw":  f["sparse_raw"],
                "dense_rank":  f["dense_rank"],
                "sparse_rank": f["sparse_rank"],
                "reasons":     reasons,
            })
        return out

    # ------------------------------------------------------------
    def _enrich_three_way(self, fused: List[Dict], metadata_scores: List) -> List[Dict]:
        """
        给三路融合结果附上 paper 元数据和 chunk 内容

        Args:
            fused: 融合后的结果
            metadata_scores: MetadataScore列表

        Returns:
            富化后的结果
        """
        if not fused:
            return []

        # 构建metadata_score映射
        metadata_map = {ms.paper_id: ms for ms in metadata_scores}

        chunk_ids = [f["chunk_id"] for f in fused]
        info_map = {c["chunk_id"]: c for c in self.prefilter.get_chunk_info(chunk_ids)}

        out = []
        for f in fused:
            info = info_map.get(f["chunk_id"], {})
            paper_id = info.get("paper_id")

            # 生成匹配原因
            reasons = []
            if f.get("metadata_rank"):
                reasons.append(f"metadata #{f['metadata_rank']} score={f['metadata_raw']:.3f}")
            if f.get("dense_rank"):
                reasons.append(f"dense #{f['dense_rank']} cos={f['dense_raw']:.3f}")
            if f.get("sparse_rank"):
                reasons.append(f"bm25 #{f['sparse_rank']} score={f['sparse_raw']:.2f}")

            # 获取metadata详情
            metadata_detail = None
            if paper_id in metadata_map:
                ms = metadata_map[paper_id]
                metadata_detail = {
                    "matched_fields": ms.matched_fields,
                    "field_scores": ms.field_scores
                }

            out.append({
                "paper_id":    paper_id,
                "title":       info.get("title"),
                "chunk_id":    f["chunk_id"],
                "field_type":  info.get("field_type"),
                "content":     info.get("content", ""),
                "embedding_idx": info.get("embedding_idx"),
                "fused_score": f["fused_score"],
                "metadata_score": f.get("metadata_norm", 0.0),
                "dense_score": f.get("dense_norm", 0.0),
                "sparse_score": f.get("sparse_norm", 0.0),
                "metadata_raw": f.get("metadata_raw", 0.0),
                "dense_raw":   f.get("dense_raw", 0.0),
                "sparse_raw":  f.get("sparse_raw", 0.0),
                "metadata_rank": f.get("metadata_rank"),
                "dense_rank":  f.get("dense_rank"),
                "sparse_rank": f.get("sparse_rank"),
                "reasons":     reasons,
                "metadata_detail": metadata_detail,
            })
        return out

    # ------------------------------------------------------------
    def _build_chunk_to_paper_map(self, chunk_ids: List[str]) -> Dict[str, str]:
        """
        构建chunk_id -> paper_id映射

        Args:
            chunk_ids: chunk_id列表

        Returns:
            {chunk_id: paper_id} 映射
        """
        if not chunk_ids:
            return {}

        placeholders = ",".join(["?"] * len(chunk_ids))
        sql = f"SELECT chunk_id, paper_id FROM paper_chunks WHERE chunk_id IN ({placeholders})"
        rows = self.prefilter.conn.execute(sql, chunk_ids).fetchall()

        return {row["chunk_id"]: row["paper_id"] for row in rows}

    # ------------------------------------------------------------
    def _dedupe_by_paper(self, results: List[Dict]) -> List[Dict]:
        """同篇论文多个 chunk 命中：只保留 fused_score 最高的一条。"""
        seen: Dict[str, Dict] = {}
        for r in results:
            pid = r["paper_id"]
            if pid not in seen or r["fused_score"] > seen[pid]["fused_score"]:
                seen[pid] = r
        return sorted(seen.values(), key=lambda x: -x["fused_score"])


# ============================================================
# 自测
# ============================================================

def _demo():
    logging.basicConfig(level=logging.INFO, format="%(message)s")

    s = HybridSearcher()
    cases = [
        ("Q001 测试", "FR4 基板 极化不敏感 宽角吸波体 8-12 GHz", None),
        ("材料约束测试", "吸波体 散热",
         {"schema_contains": {"substrate_material": "FR4"}}),
        ("领域约束测试", "RCS 减缩 超表面",
         {"schema_contains": {"structure_class": "metamaterial"}}),
    ]

    for name, query, filters in cases:
        print("\n" + "=" * 80)
        print(f"【{name}】 query='{query}'  filters={filters}")
        print("=" * 80)
        for r in s.search(query, filters, top_k=5):
            print(f"  score={r['fused_score']:.3f} (d={r['dense_score']:.3f}, "
                  f"s={r['sparse_score']:.3f})  [{r['paper_id']}] "
                  f"{r['field_type']:25}")
            print(f"    └─ {r['title'][:75]}")
            print(f"    └─ reasons: {r['reasons']}")


if __name__ == "__main__":
    _demo()
