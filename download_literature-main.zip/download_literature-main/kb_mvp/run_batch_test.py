#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
run_batch_test.py - 批量测试启动脚本

快速运行批量测试的便捷脚本
"""

import sys
from pathlib import Path
from datetime import datetime

# 添加项目路径
KB_MVP_ROOT = Path(__file__).resolve().parent
PROJECT_ROOT = KB_MVP_ROOT.parent
sys.path.insert(0, str(PROJECT_ROOT))
sys.path.insert(0, str(KB_MVP_ROOT))

from src.batch_test_v2 import run_batch_v2, render_markdown_v2


def main():
    """运行批量测试"""
    print("="*70)
    print("KB_MVP 批量测试")
    print("="*70)

    # 配置
    test_query_path = KB_MVP_ROOT / "tests" / "test_query.json"
    top_k = 5                    # Top-K结果数
    enable_three_way = True      # 启用三路融合
    generate_answer = True       # 生成LLM回答

    print(f"\n配置:")
    print(f"  - 测试用例: {test_query_path.name}")
    print(f"  - Top-K: {top_k}")
    print(f"  - 融合模式: {'三路' if enable_three_way else '二路'}")
    print(f"  - 生成回答: {'是' if generate_answer else '否'}")

    # 运行测试
    print(f"\n开始批量测试...")
    results = run_batch_v2(
        query_json_path=test_query_path,
        top_k=top_k,
        enable_three_way=enable_three_way,
        generate_answer=generate_answer
    )

    # 保存结果
    output_dir = KB_MVP_ROOT / "results"
    output_dir.mkdir(exist_ok=True)

    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    mode = "3way" if enable_three_way else "2way"

    # JSON
    json_path = output_dir / f"batch_test_{mode}_{timestamp}.json"
    import json
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

    # Markdown
    md_path = output_dir / f"batch_test_{mode}_{timestamp}.md"
    markdown = render_markdown_v2(results)
    with open(md_path, 'w', encoding='utf-8') as f:
        f.write(markdown)

    # 打印摘要
    print("\n" + "="*70)
    print("批量测试完成！")
    print("="*70)
    print(f"  总查询数: {results['total_queries']}")
    print(f"  融合模式: {results['mode']}")
    print(f"  输出路径:")
    print(f"    - JSON: {json_path}")
    print(f"    - Markdown: {md_path}")
    print("="*70)


if __name__ == '__main__':
    main()
