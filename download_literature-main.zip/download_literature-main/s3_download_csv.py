"""
从CSV文件中读取origin_path，下载文件并命名为 时间-期刊-doi.pdf
基于唯一键（年份-期刊-DOI）实现断点续传，已存在则直接跳过（不添加序号）

调用示例：
python s3_download_csv.py --csv-file "C:/path/to/data.csv" --save-dir "C:/path/to/pdf/"

"""

import os
import re
import csv
import argparse
import hashlib
import threading
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
from collections import defaultdict

from env_bootstrap import load_env
load_env()

# ===================== 配置 =====================
MAX_WORKERS = 15

# 保护 existing_key_map / in-progress 集合的并发读写（dict 非线程安全）
_MAP_LOCK = threading.Lock()

DOWNLOAD_URL = "https://data-workbench.dc.shlab.tech/api/s3/v1/bucket/download"
# 凭据只从环境变量 / .env 读取，源码不放明文（见 .env.example 的 WORKBENCH_API_KEY）
API_KEY = os.environ.get("WORKBENCH_API_KEY", "")
HEADERS = {"X-API-Key": API_KEY}


def sanitize_filename(filename):
    """清理文件名，移除非法字符"""
    illegal_chars = r'[<>:"/\\|?*]'
    sanitized = re.sub(illegal_chars, '_', filename)
    sanitized = re.sub(r'[\x00-\x1f\x7f-\x9f]', '', sanitized)
    sanitized = sanitized.strip('. ')
    if len(sanitized) > 200:
        sanitized = sanitized[:200]
    return sanitized if sanitized else "untitled"


def compute_unique_key(metadata):
    """
    根据 年份-期刊-DOI 计算唯一标识
    用于判断该论文是否已经下载过
    """
    pub_date = metadata.get("publication_date", "") or ""
    year = ""
    if pub_date:
        year_match = re.search(r'(\d{4})', pub_date)
        if year_match:
            year = year_match.group(1)
    if not year:
        year = "no_date"

    journal = metadata.get("journal_name", "") or metadata.get("journal", "") or "unknown_journal"
    journal = sanitize_filename(journal)

    doi = metadata.get("doi", "") or "no_doi"
    doi_clean = sanitize_filename(doi)

    return f"{year}-{journal}-{doi_clean}"


def generate_filename_from_key(key):
    """根据唯一键生成标准文件名"""
    return f"{key}.pdf"


def load_existing_key_map(directory):
    """
    扫描目录，建立 {unique_key: actual_filename} 映射
    只处理标准命名的文件（格式：year-journal-doi.pdf 或 year-journal-doi_1.pdf 等）
    """
    key_map = {}
    if not os.path.exists(directory):
        return key_map

    for fname in os.listdir(directory):
        if not fname.endswith('.pdf'):
            continue
        # 移除可能存在的序号后缀 _数字.pdf
        base = fname
        if re.search(r'_\d+\.pdf$', fname):
            base = re.sub(r'_\d+\.pdf$', '.pdf', fname)
        # 尝试提取 key
        parts = base.split('-', 2)
        if len(parts) >= 3:
            year = parts[0]
            journal = parts[1]
            title_part = parts[2].replace('.pdf', '')
            key = f"{year}-{journal}-{title_part}"
            key_map[key] = fname
        else:
            # 非标准命名，忽略（不参与跳过）
            continue
    return key_map


def load_records_from_csv(csv_path):
    """从 CSV 读取记录，返回 (origin_path, metadata) 列表"""
    records = []
    with open(csv_path, "r", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for row in reader:
            origin_path = row.get("origin_path", "").strip()
            if not origin_path:
                continue
            pub_date = (
                row.get("publication_date")
                or row.get("pub_time")
                or ""
            ).strip()
            journal = (
                row.get("journal_name")
                or row.get("magazine")
                or row.get("journal")
                or ""
            ).strip()
            metadata = {
                "title": row.get("title", "").strip(),
                "publication_date": pub_date,
                "journal_name": journal,
                "doi": row.get("doi", "").strip(),
                "origin_path": origin_path,
            }
            records.append((origin_path, metadata))
    return records


def download_file(s3_path, metadata, existing_key_map, save_dir, in_progress):
    """
    下载单个文件
    1. 计算 unique_key，若已存在于 existing_key_map 中则跳过
    2. 否则生成标准文件名，下载并保存
    并发安全：existing_key_map / in_progress 的读改写都在 _MAP_LOCK 内完成，
    同一 key 只会被一个线程认领下载，其余线程直接跳过。
    """
    key = compute_unique_key(metadata)
    filename = generate_filename_from_key(key)
    save_path = os.path.join(save_dir, filename)

    with _MAP_LOCK:
        # 检查是否已存在相同 key 的文件
        existing_filename = existing_key_map.get(key)
        if existing_filename:
            existing_path = os.path.join(save_dir, existing_filename)
            if os.path.exists(existing_path) and os.path.getsize(existing_path) > 0:
                size_mb = os.path.getsize(existing_path) / (1024 * 1024)
                return {
                    'success': True, 'status': 'skip', 'filename': existing_filename,
                    'doi': metadata.get("doi", "N/A"),
                    'title': metadata.get("title", "")[:50], 'size_mb': size_mb,
                }
            # 文件丢失，从映射中移除，继续下载
            existing_key_map.pop(key, None)

        # 已落地的同名文件（其它进程/上次运行留下的）
        if os.path.exists(save_path) and os.path.getsize(save_path) > 0:
            size_mb = os.path.getsize(save_path) / (1024 * 1024)
            existing_key_map[key] = filename
            return {
                'success': True, 'status': 'skip', 'filename': filename,
                'doi': metadata.get("doi", "N/A"),
                'title': metadata.get("title", "")[:50], 'size_mb': size_mb,
            }

        # 同一 key 正被另一线程下载 → 跳过，避免重复下载/写同一文件
        if key in in_progress:
            return {
                'success': True, 'status': 'skip', 'filename': filename,
                'doi': metadata.get("doi", "N/A"),
                'title': metadata.get("title", "")[:50], 'size_mb': 0.0,
            }
        in_progress.add(key)

    try:
        resp = requests.get(
            DOWNLOAD_URL, headers=HEADERS, params={"path": s3_path},
            stream=True, timeout=(60, 600),
        )
        if resp.status_code == 200:
            os.makedirs(save_dir, exist_ok=True)
            with open(save_path, "wb") as f:
                for chunk in resp.iter_content(chunk_size=1024 * 1024):
                    if chunk:
                        f.write(chunk)
            size_mb = os.path.getsize(save_path) / (1024 * 1024)
            # 成功下载，更新映射
            with _MAP_LOCK:
                existing_key_map[key] = filename
            return {
                'success': True,
                'status': 'ok',
                'filename': filename,
                'doi': metadata.get("doi", "N/A"),
                'title': metadata.get("title", "")[:50],
                'size_mb': size_mb
            }
        else:
            return {
                'success': False,
                'status': 'fail',
                'filename': filename,
                'doi': metadata.get("doi", "N/A"),
                'title': metadata.get("title", "")[:50],
                'error': f"HTTP {resp.status_code}"
            }
    except Exception as e:
        if os.path.exists(save_path):
            os.remove(save_path)
        return {
            'success': False,
            'status': 'error',
            'filename': filename,
            'doi': metadata.get("doi", "N/A"),
            'title': metadata.get("title", "")[:50],
            'error': str(e)
        }
    finally:
        with _MAP_LOCK:
            in_progress.discard(key)


def main():
    parser = argparse.ArgumentParser(description="PDF 批量下载工具")
    parser.add_argument("--csv-file", required=True, help="CSV文件路径")
    parser.add_argument("--save-dir", required=True, help="PDF保存目录")
    args = parser.parse_args()

    csv_file = args.csv_file
    save_dir = args.save_dir

    if not API_KEY:
        raise SystemExit(
            "缺少 WORKBENCH_API_KEY：请在仓库根目录 .env 里设置（参见 .env.example），"
            "或 export WORKBENCH_API_KEY=..."
        )

    print("=" * 70)
    print("  PDF 批量下载工具（基于 年份-期刊-DOI 断点续传，已存在则跳过）")
    print("=" * 70)
    print(f"CSV文件: {csv_file}")
    print(f"保存目录: {save_dir}")
    print(f"并发数: {MAX_WORKERS}")
    print()

    os.makedirs(save_dir, exist_ok=True)

    # 获取已存在文件的 key->filename 映射
    existing_key_map = load_existing_key_map(save_dir)
    print(f"📁 发现已存在的 {len(existing_key_map)} 个PDF文件（基于唯一键）")

    # 加载 CSV 记录
    print("正在读取CSV文件...")
    records = load_records_from_csv(csv_file)
    total = len(records)
    print(f"✓ 共读取 {total} 条有效记录（含origin_path）\n")

    if total == 0:
        print("❌ 没有找到有效的 origin_path 记录，退出")
        return

    # 显示前几条记录及其唯一键
    print("前3条记录示例:")
    for i, (_, meta) in enumerate(records[:3]):
        key = compute_unique_key(meta)
        print(f"  {i+1}. 唯一键: {key[:80]}...")
        print(f"     标题: {meta['title'][:60]}...")
        print(f"     日期: {meta['publication_date']}  期刊: {meta['journal_name']}")
        print()

    stats = defaultdict(int)
    results = []

    print("开始下载...")
    print("-" * 70)

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        in_progress = set()
        futures = {
            executor.submit(download_file, path, meta, existing_key_map, save_dir, in_progress): (path, meta)
            for path, meta in records
        }
        for i, future in enumerate(as_completed(futures), 1):
            result = future.result()
            results.append(result)
            stats[result['status']] += 1

            status_symbol = {'ok': '✓', 'skip': '⏭', 'fail': '✗', 'error': '⚠'}.get(result['status'], '?')
            status_text = {'ok': '下载成功', 'skip': '已存在跳过', 'fail': '失败', 'error': '错误'}.get(result['status'], '未知')

            if result['status'] == 'ok':
                print(f"[{i:4d}/{total}] {status_symbol} {status_text}: {result['filename']} ({result['size_mb']:.1f} MB)")
                print(f"               📄 {result['title']}...")
            elif result['status'] == 'skip':
                print(f"[{i:4d}/{total}] {status_symbol} {status_text}: {result['filename']} ({result['size_mb']:.1f} MB)")
            else:
                print(f"[{i:4d}/{total}] {status_symbol} {status_text}: {result['filename']}")
                print(f"               ❌ {result.get('error', 'unknown')}")

    print("-" * 70)
    print("\n" + "=" * 70)
    print("  下载完成统计")
    print("=" * 70)
    print(f"  ✅ 成功下载: {stats['ok']} 个")
    print(f"  ⏭ 跳过已存在: {stats['skip']} 个")
    print(f"  ❌ 下载失败: {stats['fail'] + stats['error']} 个")
    print(f"  📊 总计处理: {total} 个文件")

    final_files = [f for f in os.listdir(save_dir) if f.endswith('.pdf')]
    print(f"\n📁 最终目录中的PDF文件总数: {len(final_files)}")

    if stats['fail'] + stats['error'] > 0:
        print("\n失败的文件:")
        for r in results:
            if not r['success']:
                print(f"  - {r['filename']} (DOI: {r['doi']})")
                print(f"    错误: {r.get('error', 'unknown')}")

    print(f"\n📁 文件保存位置: {os.path.abspath(save_dir)}")
    print("✅ 所有任务完成!")


if __name__ == "__main__":
    main()