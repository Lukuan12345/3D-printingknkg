#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""assemble_content_store.py —— 把 S3 上 MinerU 解析结果落成 gen_key 的 content_store。

S3 布局（步骤3 写回）:  parsed/<book>/<part_xxx>/full.md (+ images/ + *.json + origin.pdf)
目标布局:               content_store/<paper_id>/full.md          (paper_id = <book_slug>__<part_xxx>)

默认**每个 20 页 part = 一个抽取单元**（教材整本过大、远超单调用 90k 上限）。
用 --merge-per-book 可改成「整本合并成一个 full.md」（仅适合小册子，不推荐用于大部头）。

只拉 full.md（--include "**/full.md"），不拉 images，省带宽。

用法:
    # 从 S3 拉取并落库
    python assemble_content_store.py \
        --s3 "ai4cmp:ai4cmp/suyulin/materials/parsed" \
        --content-store scientific_kgqa/data/content_store
    # 若解析结果已在本地，跳过拉取：
    python assemble_content_store.py --local materials_parsed_md --content-store ...
"""
from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
from pathlib import Path

S3_PARSED_DEFAULT = "ai4cmp:ai4cmp/suyulin/materials/parsed"
PULL_DIR_DEFAULT = "C:/Users/suyulin/Downloads/materials/_parsed_md"
CONTENT_STORE_DEFAULT = "scientific_kgqa/data/content_store"
RCLONE_BIN = "rclone"


def _slug(name: str, n: int = 80) -> str:
    """书名 → 文件系统安全 id 片段（保留 unicode 字母/数字，空格转 _）。"""
    s = re.sub(r"\s+", "_", name.strip())
    s = re.sub(r'[\\/:*?"<>|,;&\'()\[\]]+', "", s)
    return s[:n].strip("_") or "book"


def pull_from_s3(s3: str, pull_dir: Path) -> bool:
    if shutil.which(RCLONE_BIN) is None:
        print(f"[ERROR] 找不到 {RCLONE_BIN}"); return False
    pull_dir.mkdir(parents=True, exist_ok=True)
    cmd = [RCLONE_BIN, "copy", s3, str(pull_dir),
           "--include", "**/full.md", "--transfers", "16", "--progress"]
    print(f"[pull] {' '.join(cmd)}")
    return subprocess.run(cmd).returncode == 0


def assemble(src_root: Path, content_store: Path, merge_per_book: bool) -> dict:
    content_store.mkdir(parents=True, exist_ok=True)
    manifest = {}
    books = sorted([d for d in src_root.iterdir() if d.is_dir()])
    n_units = 0
    for book in books:
        book_slug = _slug(book.name)
        parts = sorted(book.glob("part_*"))
        mds = [(p.name, p / "full.md") for p in parts if (p / "full.md").exists()]
        if not mds:
            # 兼容：full.md 直接在 book 下
            if (book / "full.md").exists():
                mds = [("part_001", book / "full.md")]
        if not mds:
            print(f"  [skip] {book.name}: 无 full.md"); continue

        if merge_per_book:
            paper_id = book_slug
            text = "\n\n".join(f"<!-- {pn} -->\n" + mp.read_text(encoding="utf-8", errors="ignore")
                               for pn, mp in mds)
            dst = content_store / paper_id
            dst.mkdir(parents=True, exist_ok=True)
            (dst / "full.md").write_text(text, encoding="utf-8")
            manifest[paper_id] = {"book": book.name, "parts": [pn for pn, _ in mds]}
            n_units += 1
        else:
            for pn, mp in mds:
                paper_id = f"{book_slug}__{pn}"
                dst = content_store / paper_id
                dst.mkdir(parents=True, exist_ok=True)
                shutil.copy2(mp, dst / "full.md")
                manifest[paper_id] = {"book": book.name, "part": pn,
                                      "source": f"{book.name}/{pn}/full.md"}
                n_units += 1
        print(f"  [ok] {book.name}: {len(mds)} part(s)")

    (content_store / "_assemble_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"books": len(books), "units": n_units}


def main():
    ap = argparse.ArgumentParser(description="S3 解析结果 → content_store")
    ap.add_argument("--s3", default=S3_PARSED_DEFAULT, help="S3 parsed 路径（rclone remote）")
    ap.add_argument("--local", default="", help="若解析结果已在本地，指向其根目录，跳过 S3 拉取")
    ap.add_argument("--pull-dir", default=PULL_DIR_DEFAULT, help="S3 拉取落地目录")
    ap.add_argument("--content-store", default=CONTENT_STORE_DEFAULT)
    ap.add_argument("--merge-per-book", action="store_true", help="整本合并为一个 full.md（默认每 part 一个单元）")
    args = ap.parse_args()

    if args.local:
        src = Path(args.local)
    else:
        src = Path(args.pull_dir)
        if not pull_from_s3(args.s3, src):
            raise SystemExit("[ERROR] S3 拉取失败")
    if not src.exists():
        raise SystemExit(f"[ERROR] 源目录不存在: {src}")

    stats = assemble(src, Path(args.content_store), args.merge_per_book)
    print("=" * 56)
    print(f"content_store 落地完成: {stats['books']} 本书 → {stats['units']} 个单元")
    print(f"  paper_id 规则: <book_slug>__part_xxx   (--merge-per-book 时为 <book_slug>)")
    print(f"  -> {args.content_store}")
    print("=" * 56)


if __name__ == "__main__":
    main()
