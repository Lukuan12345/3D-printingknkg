#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
env_bootstrap.py —— 轻量 .env 加载器（无第三方依赖）。

各入口脚本在最顶部 `from env_bootstrap import load_env; load_env()` 即可，
把仓库根目录的 .env 读进 os.environ（已存在的环境变量不覆盖）。
这样所有真实凭据 / 服务地址只需写在 .env（参见 .env.example），
源码里不再放明文密钥。
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

_LOADED = False


def load_env(dotenv_path: Optional[Path] = None) -> None:
    """读取仓库根目录的 .env 到 os.environ；已存在的 key 不覆盖。只生效一次。"""
    global _LOADED
    if _LOADED:
        return
    _LOADED = True

    if dotenv_path is None:
        dotenv_path = Path(__file__).resolve().parent / ".env"
    if not dotenv_path.exists():
        return

    with open(dotenv_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, value = line.partition("=")
            key = key.strip()
            value = value.strip().strip('"').strip("'")
            if key and key not in os.environ:
                os.environ[key] = value
