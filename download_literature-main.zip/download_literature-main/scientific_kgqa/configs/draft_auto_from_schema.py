#!/usr/bin/env python3
# =============================================================================
# draft_auto_from_schema.py —— 读 schema.csv + 专家区骨架，调 LLM 自动草拟
# 【LLM 草稿区】expert_template_auto.yaml（词典 + 字段映射）。
#
# 定位：与 build_expert_config.py 同目录，构成「专家配置流水线」前后两段：
#
#   schema.csv ─┐
#               ├─► draft_auto_from_schema.py ─► expert_template_auto.yaml(LLM草稿,人工改)
#   expert.yaml ┘                                        │
#                                                        ├─► build_expert_config.py
#   expert_template_expert.yaml(专家填配比) ──────────────┘        │
#                                                                  ▼
#                                                    expert_weights_em.yaml(代码读)
#
# 它做的事：
#   1) 解析 schema.csv → 「可选字段池」（field_en | field_zh | 描述 | cluster）；
#   2) 从 expert 文件读出骨架三件：功能类型名列表 / 维度子项 / 任务名列表；
#   3) 拼 prompt 让 LLM 输出严格 JSON：每个功能类型的 keywords/patterns、
#      每个维度子项映射到的 schema 字段、每个任务的 query keywords/chunk_types；
#   4) 校验清洗：删 schema 里不存在的字段、过滤非法 chunk_type、key 与骨架对齐；
#   5) 写出 expert_template_auto.yaml（顶部注释提示人工检查）。
#
# 它【不碰】expert 文件里的权重配比（那是价值判断，留给人）。
#
# 用法：
#   python configs/draft_auto_from_schema.py \
#       --schema scientific_kgqa/data/schema.csv \
#       --expert configs/expert_template_expert.yaml \
#       --out    configs/expert_template_auto.yaml
#
#   # 只看将发给 LLM 的内容、不真正调用：
#   python configs/draft_auto_from_schema.py --schema ... --dry-run
#
# 凭据沿用 cli_build.py 的回退链（CLI 优先，再 env），与仓库一致。
# =============================================================================
from __future__ import annotations

import argparse
import csv
import json
import os
import sys
from pathlib import Path
from typing import Dict, List

import yaml

# ---- 让脚本无论从哪跑都能 import scientific_kgqa 包 ----
_HERE = Path(__file__).resolve().parent
_PKG_SRC = _HERE.parents[0] / "src"  # scientific_kgqa/src
if str(_PKG_SRC) not in sys.path:
    sys.path.insert(0, str(_PKG_SRC))

from scientific_kgqa.llm_client import LLMClient, LLMClientError  # noqa: E402

# CHUNK_TYPES 的权威来源是 scientific_kgqa.utils，但 utils 会 import jieba（重依赖）。
# 本脚本只需要这 7 个常量，故优先复用、import 失败时回退到一份同步副本，避免逼用户装 jieba。
try:
    from scientific_kgqa.utils import CHUNK_TYPES  # noqa: E402
except ImportError:
    CHUNK_TYPES = [
        "problem_context",
        "study_process_description",
        "design_optimization_logic",
        "physical_mechanism",
        "fabrication_process",
        "design_method",
        "influence_analysis",
    ]


# 中文 → 内部键的列映射（对齐 builder.py:_SCHEMA_COL_MAP，含英文兜底列名）
_SCHEMA_COL_MAP = {
    "字段名（英文）": "field_en",
    "字段名（中文）": "field_zh",
    "完整描述": "description",
    "提取提示": "extraction_hint",
    "层级": "level",
    "标签": "tag",
    "聚类名称": "cluster_zh",
    "聚类名称（英文）": "cluster_en",
    "适用领域": "applicable_domain",
    "使用范围": "use_scope",
    "field_en": "field_en",
    "english_name": "field_en",
    "field_zh": "field_zh",
    "chinese_name": "field_zh",
    "description": "description",
    "tag": "tag",
}


# =============================================================================
# schema.csv 解析
# =============================================================================

def load_schema_fields(schema_path: Path) -> List[Dict[str, str]]:
    """解析 schema.csv → [{field_en, field_zh, description, cluster}]（按出现顺序）。

    用 csv.DictReader（零依赖，不引 pandas）；编码 utf-8-sig 兼容 BOM。
    """
    rows: List[Dict[str, str]] = []
    with schema_path.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        for raw in reader:
            rec: Dict[str, str] = {}
            for col, val in raw.items():
                key = _SCHEMA_COL_MAP.get((col or "").strip())
                if key and val is not None:
                    rec[key] = str(val).strip()
            field_en = rec.get("field_en", "")
            if not field_en:
                continue
            rows.append({
                "field_en": field_en,
                "field_zh": rec.get("field_zh", ""),
                "description": rec.get("description", ""),
                "cluster": rec.get("cluster_zh", "") or rec.get("cluster_en", ""),
            })
    return rows


def render_field_pool(fields: List[Dict[str, str]], desc_chars: int = 120) -> str:
    """把字段池渲染成紧凑文本：`field_en | field_zh | 描述前 N 字 | cluster`。"""
    lines = []
    for r in fields:
        desc = (r["description"] or "").replace("\n", " ")
        if len(desc) > desc_chars:
            desc = desc[:desc_chars] + "…"
        lines.append(f"- {r['field_en']} | {r['field_zh']} | {desc} | {r['cluster']}")
    return "\n".join(lines)


# =============================================================================
# expert 文件骨架读取
# =============================================================================

def load_expert_skeleton(expert_path: Path) -> Dict:
    """从 expert 文件读出 LLM 草拟所需的骨架（不读权重配比）。"""
    data = yaml.safe_load(expert_path.read_text(encoding="utf-8")) or {}
    return {
        "functional_types_order": list(data.get("functional_types_order", []) or []),
        "dimension_subitems": dict(data.get("dimension_subitems", {}) or {}),
        "task_names": [t["name"] for t in (data.get("tasks", []) or []) if t.get("name")],
    }


# =============================================================================
# Prompt 拼装
# =============================================================================

_SYSTEM = """You are a configuration assistant for a scientific-literature retrieval system.

Your job: given a fixed SCHEMA FIELD POOL (extracted from papers) and a SKELETON of
category names chosen by a domain expert, draft the OBJECTIVE dictionaries and
field-mappings. You do NOT decide importance/weights — only fill in keywords,
value patterns, schema-field mappings, and chunk types.

You MUST return ONE strict JSON object, no prose, no code fence.

Definitions you must respect:
  • keywords  : terms a USER types in a QUERY (used to detect intent / functional type / task).
  • patterns  : terms that appear inside a PAPER'S EXTRACTED FIELD VALUES (used to gate a
                paper into a functional type). keywords and patterns overlap but are NOT the same.
  • fields    : MUST be field_en values that EXIST in the SCHEMA FIELD POOL. Never invent fields.
  • chunk_types: MUST be chosen ONLY from the allowed CHUNK_TYPES list.

Output JSON shape (use EXACTLY these keys; keep the expert's names verbatim):
{
  "functional_types": { "<ft_name>": {"keywords": [...], "patterns": [...]}, ... },
  "probe_fields": [ <field_en used to detect functional type, from pool> ],
  "dimensions": {
     "<dim>": { "<sub>": {"fields": [<field_en from pool>], "emphasis": [<query words>]}, ... }
  },
  "tasks": { "<task_name>": {"keywords": [<query words>], "chunk_types": [<from CHUNK_TYPES>]} }
}

Rules:
  - Provide both English and (where natural) Chinese surface forms in keywords/patterns.
  - "emphasis" is optional; only meaningful for performance sub-items. Use [] if unsure.
  - Map each sub-item to 1-4 of the MOST relevant schema fields. Omit a field rather than guess.
  - Keep every functional_type / dimension sub / task key that the skeleton lists; fill what you can.
"""


def build_user_prompt(field_pool: str, skeleton: Dict) -> str:
    dims_desc = "\n".join(
        f"  {dim}: {subs}" for dim, subs in skeleton["dimension_subitems"].items()
    )
    return f"""SCHEMA FIELD POOL (field_en | field_zh | description | cluster):
{field_pool}

ALLOWED CHUNK_TYPES (chunk_types may ONLY use these):
{CHUNK_TYPES}

EXPERT SKELETON — fill the dictionaries/mappings for exactly these names:

functional_types (give each keywords + patterns), in priority order:
  {skeleton['functional_types_order']}

dimension sub-items (map each sub to schema fields from the pool above):
{dims_desc}

tasks (give each query keywords + chunk_types):
  {skeleton['task_names']}

Return the strict JSON object now."""


# =============================================================================
# LLM 输出校验 / 清洗
# =============================================================================

def sanitize(raw: Dict, fields: List[Dict[str, str]], skeleton: Dict):
    """对齐骨架 + 删除幻觉字段 + 过滤非法 chunk_type。返回 (auto_dict, warnings)。"""
    warnings: List[str] = []
    valid_fields = {r["field_en"] for r in fields}
    valid_chunks = set(CHUNK_TYPES)

    def keep_fields(flist, where):
        out = []
        for f in flist or []:
            if f in valid_fields:
                out.append(f)
            else:
                warnings.append(f"[{where}] 字段 '{f}' 不在 schema 字段池，已删除。")
        return out

    raw = raw or {}
    out: Dict = {}

    # ---- functional_types：对齐 functional_types_order ----
    raw_fts = raw.get("functional_types", {}) or {}
    fts: Dict = {}
    for ft in skeleton["functional_types_order"]:
        spec = raw_fts.get(ft) or {}
        if not spec:
            warnings.append(f"[functional_type '{ft}'] LLM 未给出 keywords/patterns，已留空。")
        fts[ft] = {
            "keywords": list(spec.get("keywords", []) or []),
            "patterns": list(spec.get("patterns", []) or []),
        }
    for ft in raw_fts:
        if ft not in fts:
            warnings.append(f"[functional_type '{ft}'] LLM 多给的、不在专家骨架，已忽略。")
    out["functional_types"] = fts

    # ---- probe_fields：只保留 schema 里真实存在的 ----
    out["probe_fields"] = keep_fields(raw.get("probe_fields", []), "probe_fields")

    # ---- dimensions：对齐 dimension_subitems ----
    raw_dims = raw.get("dimensions", {}) or {}
    dims: Dict = {}
    for dim, subs in skeleton["dimension_subitems"].items():
        raw_dim = raw_dims.get(dim, {}) or {}
        dims[dim] = {}
        for sub in subs:
            spec = raw_dim.get(sub) or {}
            if not spec:
                warnings.append(f"[{dim}.{sub}] LLM 未给字段映射，已留空。")
            entry = {"fields": keep_fields(spec.get("fields", []), f"{dim}.{sub}")}
            emph = list(spec.get("emphasis", []) or [])
            if emph:
                entry["emphasis"] = emph
            dims[dim][sub] = entry
    out["dimensions"] = dims

    # ---- tasks：对齐 task_names，chunk_types 过滤非法值 ----
    raw_tasks = raw.get("tasks", {}) or {}
    tasks: Dict = {}
    for name in skeleton["task_names"]:
        spec = raw_tasks.get(name) or {}
        if not spec:
            warnings.append(f"[task '{name}'] LLM 未给 keywords/chunk_types，已留空。")
        chunks = []
        for c in spec.get("chunk_types", []) or []:
            if c in valid_chunks:
                chunks.append(c)
            else:
                warnings.append(f"[task '{name}'] chunk_type '{c}' 非法，已删除。"
                                f"合法值：{CHUNK_TYPES}")
        tasks[name] = {
            "keywords": list(spec.get("keywords", []) or []),
            "chunk_types": chunks,
        }
    out["tasks"] = tasks

    return out, warnings


# =============================================================================
# 写出
# =============================================================================

_HEADER = """# =============================================================================
# expert_template_auto.yaml —— 【LLM 草稿区】由 draft_auto_from_schema.py 自动草拟。
# =============================================================================
# ⚠️ 这是机器草稿，请人工检查后再用：
#   - functional_types[*].keywords / patterns：是否贴合你的领域、有无漏/错词
#   - dimensions[dim][sub].fields：字段映射是否对（脚本已保证字段都在 schema 内）
#   - tasks[*].keywords / chunk_types：query 关键词是否齐、chunk 优先级是否合理
#
# 结构由 expert_template_expert.yaml 决定（同名 key 对应）。检查改好后生成最终配置：
#   python configs/build_expert_config.py --split \\
#       configs/expert_template_expert.yaml configs/expert_template_auto.yaml \\
#       configs/expert_weights_em.yaml
# =============================================================================

"""


def write_auto(out_path: Path, auto: Dict):
    body = yaml.safe_dump(auto, allow_unicode=True, sort_keys=False, default_flow_style=False)
    out_path.write_text(_HEADER + body, encoding="utf-8")


# =============================================================================
# main
# =============================================================================

def main():
    # Windows 控制台默认 GBK，prompt 里含 •/… 等字符会编码报错；尽量切到 UTF-8。
    try:
        sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]
        sys.stderr.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]
    except (AttributeError, ValueError):
        pass

    parser = argparse.ArgumentParser(
        description="读 schema.csv + expert 骨架，调 LLM 草拟 expert_template_auto.yaml")
    parser.add_argument("--schema", required=True, help="refined_schema_*.csv 路径")
    parser.add_argument("--expert", default=str(_HERE / "expert_template_expert.yaml"),
                        help="专家骨架文件（默认 configs/expert_template_expert.yaml）")
    parser.add_argument("--out", default=str(_HERE / "expert_template_auto.yaml"),
                        help="输出（默认 configs/expert_template_auto.yaml）")
    parser.add_argument("--llm-api-key", default=None,
                        help="API key（或 env ANTHROPIC_AUTH_TOKEN / LLM_API_KEY / OPENAI_API_KEY）")
    parser.add_argument("--llm-base-url", default=None,
                        help="API base URL（或 env ANTHROPIC_BASE_URL / LLM_BASE_URL，"
                             "默认 http://43.153.42.7:3001/v1）")
    parser.add_argument("--llm-model", default=None,
                        help="模型名（或 env LLM_MODEL，默认 gemini-3.1-pro-preview）")
    parser.add_argument("--max-tokens", type=int, default=8192, help="LLM 最大输出 token")
    parser.add_argument("--dry-run", action="store_true",
                        help="只打印 schema 摘要 + prompt，不调用 LLM、不写文件")
    args = parser.parse_args()

    schema_path = Path(args.schema)
    if not schema_path.exists():
        parser.error(f"schema 文件不存在：{schema_path}")
    expert_path = Path(args.expert)
    if not expert_path.exists():
        parser.error(f"expert 文件不存在：{expert_path}")

    fields = load_schema_fields(schema_path)
    if not fields:
        parser.error(f"schema 没解析出任何字段（检查列头 / 编码）：{schema_path}")
    skeleton = load_expert_skeleton(expert_path)
    field_pool = render_field_pool(fields)
    user_prompt = build_user_prompt(field_pool, skeleton)

    print(f"[schema] {len(fields)} 个字段；"
          f"[skeleton] {len(skeleton['functional_types_order'])} 功能类型 / "
          f"{len(skeleton['dimension_subitems'])} 维度 / {len(skeleton['task_names'])} 任务")

    if args.dry_run:
        print("\n========== SYSTEM ==========\n" + _SYSTEM)
        print("\n========== USER ==========\n" + user_prompt)
        print("\n[dry-run] 未调用 LLM、未写文件。")
        return

    # ---- 凭据回退链（对齐 cli_build.py）----
    api_key = (args.llm_api_key
               or os.environ.get("ANTHROPIC_AUTH_TOKEN")
               or os.environ.get("LLM_API_KEY")
               or os.environ.get("OPENAI_API_KEY"))
    if not api_key:
        parser.error("缺 LLM API key：传 --llm-api-key 或设 LLM_API_KEY/ANTHROPIC_AUTH_TOKEN 环境变量"
                     "（或加 --dry-run 先看 prompt）")
    base_url = (args.llm_base_url
                or os.environ.get("ANTHROPIC_BASE_URL")
                or os.environ.get("LLM_BASE_URL")
                or "http://43.153.42.7:3001/v1")
    model = args.llm_model or os.environ.get("LLM_MODEL") or "gemini-3.1-pro-preview"

    print(f"[LLM] model={model} base_url={base_url}")
    client = LLMClient(api_key=api_key, model=model, base_url=base_url,
                       max_tokens=args.max_tokens)
    try:
        raw = client.chat_json(_SYSTEM, user_prompt, temperature=0.1)
    except LLMClientError as e:
        print(f"[ERROR] LLM 调用失败：{e}", file=sys.stderr)
        sys.exit(1)

    auto, warnings = sanitize(raw, fields, skeleton)
    out_path = Path(args.out)
    write_auto(out_path, auto)

    print(f"[OK] 已草拟 {out_path}")
    if warnings:
        print("\n[NOTE] warnings:")
        for w in warnings:
            print("  - " + w)
    print("\n下一步：人工检查上面文件的 keywords/patterns/字段映射，再跑 build_expert_config.py --split 生成最终配置。")


if __name__ == "__main__":
    main()
