#!/usr/bin/env python3
# =============================================================================
# build_expert_config.py —— 把「人填模板」expert_template.yaml 解析、归一化，
# 生成代码真正读取的 expert_weights_em.yaml。
#
# 用法：
#   单文件模板：
#     python configs/build_expert_config.py [模板路径] [输出路径]
#     默认 configs/expert_template.yaml -> configs/expert_weights_em.yaml
#   拆分模板（专家区 + LLM草稿区）：
#     python configs/build_expert_config.py --split [专家.yaml] [auto.yaml] [输出路径]
#     默认 expert_template_expert.yaml + expert_template_auto.yaml -> expert_weights_em.yaml
#
# 做的事：
#   1) 把每个 task 的 5 维「相对重要度整数」归一化成和=1.0 的小数；
#   2) 把每个维度内子项整数归一化成和=1.0；
#   3) 把模板里「列表顺序」展开成代码需要的各种 *_priority 列表；
#   4) 把功能类型 keywords/patterns、维度字段映射、emphasis 等拆回扁平结构；
#   5) 校验：维度名是否只用了代码支持的 5 个；functional_type>=0.80 的 gating 提示。
#
# 设计依据（与代码对齐）：
#   - 维度名固定：functional_type / performance / material / structure / mechanism
#     （compute_expert_score() 硬编码）。
#   - task 名、子项名、关键词、字段映射全部 data-driven，可自由增删。
# =============================================================================
import sys
from pathlib import Path

import yaml

# 代码 compute_expert_score() 支持的 5 个维度（顺序无关，但必须是这些名字）
FIXED_DIMS = ["functional_type", "performance", "material", "structure", "mechanism"]
SUB_DIMS = ["performance", "material", "structure", "mechanism"]  # 有子项的 4 个
GATING_THRESHOLD = 0.80  # functional_type 归一化权重 >= 此值 → 该 task 启用强 gating


def _normalize(int_map, places=4):
    """整数相对值 → 归一化小数（和=1.0）。空 / 全 0 → 空 dict。"""
    int_map = {k: float(v) for k, v in (int_map or {}).items() if v and v > 0}
    total = sum(int_map.values())
    if total <= 0:
        return {}
    return {k: round(v / total, places) for k, v in int_map.items()}


def _dim_int(weights, dim):
    """取某维度的「维度级整数」。functional_type 直接是数；其余在 .dim 里。"""
    node = weights.get(dim, 0)
    if isinstance(node, dict):
        return float(node.get("dim", 0) or 0)
    return float(node or 0)


def _dim_sub(weights, dim):
    """取某维度的子项整数 dict。"""
    node = weights.get(dim, 0)
    if isinstance(node, dict):
        return node.get("sub", {}) or {}
    return {}


def build(template: dict) -> dict:
    out = {}
    warnings = []

    # ---- 功能类型：拆成 keywords / patterns / 优先级 ----
    fts = template.get("functional_types", {}) or {}
    ft_order = list(fts.keys())  # 列表/插入顺序 = 优先级
    out["functional_type_keywords"] = {k: v.get("keywords", []) for k, v in fts.items()}
    out["functional_type_priority"] = ft_order
    out["functional_type_value_patterns"] = {k: v.get("patterns", []) for k, v in fts.items()}
    out["functional_type_probe_fields"] = template.get("probe_fields", [])

    # ---- 维度字段映射：dimensions.<dim>.<sub>.fields → <dim>_fields[sub] ----
    dims = template.get("dimensions", {}) or {}
    for dim in SUB_DIMS:
        field_map = {}
        for sub, spec in (dims.get(dim, {}) or {}).items():
            field_map[sub] = (spec or {}).get("fields", [])
        out[f"{dim}_fields"] = field_map

    # ---- task_weights（归一化）+ 关键词 + chunk 优先级 + emphasis ----
    tasks = template.get("tasks", []) or []
    task_weights = {}
    task_type_keywords = {}
    task_chunk_type_priority = {}
    task_type_priority = []          # 列表顺序 = 优先级
    emphasis_triggers = {}

    for t in tasks:
        name = t["name"]
        task_type_priority.append(name)
        task_type_keywords[name] = t.get("keywords", [])
        task_chunk_type_priority[name] = t.get("chunk_types", [])

        w = t.get("weights", {}) or {}

        # 校验维度名
        for dim in w:
            if dim not in FIXED_DIMS:
                warnings.append(
                    f"[task {name}] 维度 '{dim}' 不被代码支持，已忽略。"
                    f"只能用：{FIXED_DIMS}"
                )

        # 维度级整数 → 归一化（5 维之和=1.0）
        dim_ints = {dim: _dim_int(w, dim) for dim in FIXED_DIMS}
        dim_norm = _normalize(dim_ints)

        # functional_type gating 提示
        ft_w = dim_norm.get("functional_type", 0.0)
        if ft_w >= GATING_THRESHOLD:
            warnings.append(
                f"[task {name}] functional_type 归一化权重={ft_w} >= {GATING_THRESHOLD}，"
                f"该 task 将启用强 gating（功能类型不匹配的论文直接丢弃）。"
            )

        # 组装该 task 的权重块（对齐 expert_weights_em.yaml 结构）
        block = {}
        block["functional_type"] = dim_norm.get("functional_type", 0.0)
        for dim in SUB_DIMS:
            total = dim_norm.get(dim, 0.0)
            sub_norm = _normalize(_dim_sub(w, dim)) if total > 0 else {}
            block[dim] = {"total": total, "sub": sub_norm}
        task_weights[name] = block

        # emphasis：task 启用的子项 → 从 dimensions 里取词表
        enabled = t.get("emphasis", []) or []
        if enabled:
            trig = {}
            perf_subs = dims.get("performance", {}) or {}
            for sub in enabled:
                trig[sub] = (perf_subs.get(sub, {}) or {}).get("emphasis", [])
            emphasis_triggers[name] = trig

    out["task_weights"] = task_weights
    out["task_type_keywords"] = task_type_keywords
    out["task_type_priority"] = task_type_priority
    out["task_chunk_type_priority"] = task_chunk_type_priority
    out["emphasis_triggers"] = emphasis_triggers

    # ---- 杂项 + 透传 ----
    out["gating_penalty"] = template.get("gating_penalty", 1.0)
    if "graph_walk" in template:
        out["graph_walk"] = template["graph_walk"]

    return out, warnings


def merge_split(expert: dict, auto: dict):
    """把【专家区】+【LLM 草稿区】两文件合并成 build() 消费的单一 unified 模板。

    对应关系(同名 key):
      expert.functional_types_order  + auto.functional_types[ft].{keywords,patterns}
      expert.dimension_subitems[dim] + auto.dimensions[dim][sub].{fields,emphasis}
      expert.tasks[].{name,weights,emphasis} + auto.tasks[name].{keywords,chunk_types}
    顺序一律以**专家区**为准(它定义"有哪几类/什么顺序")。
    """
    warnings = []
    unified = {}

    # ---- 功能类型:顺序来自 expert,词典来自 auto ----
    ft_order = expert.get("functional_types_order", []) or []
    auto_fts = auto.get("functional_types", {}) or {}
    fts = {}
    for ft in ft_order:
        spec = auto_fts.get(ft)
        if spec is None:
            warnings.append(f"[functional_type '{ft}'] 专家区已列出,但 auto 区缺 keywords/patterns,已留空。")
            spec = {}
        fts[ft] = spec
    for ft in auto_fts:
        if ft not in ft_order:
            warnings.append(f"[functional_type '{ft}'] 只在 auto 区出现、不在专家区 functional_types_order,已忽略。")
    unified["functional_types"] = fts
    unified["probe_fields"] = auto.get("probe_fields", [])

    # ---- 维度:子项划分来自 expert,字段映射来自 auto ----
    subitems = expert.get("dimension_subitems", {}) or {}
    auto_dims = auto.get("dimensions", {}) or {}
    dims = {}
    for dim, subs in subitems.items():
        dim_auto = auto_dims.get(dim, {}) or {}
        dims[dim] = {}
        for sub in subs:
            spec = dim_auto.get(sub)
            if spec is None:
                warnings.append(f"[{dim}.{sub}] 专家区已列出,但 auto 区缺 fields 映射,已留空。")
                spec = {}
            dims[dim][sub] = spec
    unified["dimensions"] = dims

    # ---- 任务:名字/权重/优先级来自 expert,关键词/chunk 来自 auto ----
    auto_tasks = auto.get("tasks", {}) or {}
    tasks = []
    for t in expert.get("tasks", []) or []:
        name = t["name"]
        ta = auto_tasks.get(name)
        if ta is None:
            warnings.append(f"[task '{name}'] 专家区已定义,但 auto 区缺 keywords/chunk_types,已留空。")
            ta = {}
        tasks.append({
            "name": name,
            "weights": t.get("weights", {}),
            "emphasis": t.get("emphasis", []),
            "keywords": ta.get("keywords", []),
            "chunk_types": ta.get("chunk_types", []),
        })
    unified["tasks"] = tasks

    # ---- 杂项 / 透传(都来自 expert 区)----
    unified["gating_penalty"] = expert.get("gating_penalty", 1.0)
    if "graph_walk" in expert:
        unified["graph_walk"] = expert["graph_walk"]

    return unified, warnings


def main():
    here = Path(__file__).resolve().parent
    argv = sys.argv[1:]

    if argv and argv[0] == "--split":
        # 拆分模式:--split <expert.yaml> <auto.yaml> [out.yaml]
        rest = argv[1:]
        expert_path = Path(rest[0]) if len(rest) > 0 else here / "expert_template_expert.yaml"
        auto_path = Path(rest[1]) if len(rest) > 1 else here / "expert_template_auto.yaml"
        dst = Path(rest[2]) if len(rest) > 2 else here / "expert_weights_em.yaml"

        expert = yaml.safe_load(expert_path.read_text(encoding="utf-8")) or {}
        auto = yaml.safe_load(auto_path.read_text(encoding="utf-8")) or {}
        template, merge_warns = merge_split(expert, auto)
        out, build_warns = build(template)
        warnings = merge_warns + build_warns
        src_note = f"{expert_path.name} + {auto_path.name}"
    else:
        # 单文件模式:<template.yaml> [out.yaml]
        src = Path(argv[0]) if len(argv) > 0 else here / "expert_template.yaml"
        dst = Path(argv[1]) if len(argv) > 1 else here / "expert_weights_em.yaml"
        template = yaml.safe_load(src.read_text(encoding="utf-8")) or {}
        out, warnings = build(template)
        src_note = src.name

    header = (
        "# 本文件由 build_expert_config.py 自动生成，请勿手改。\n"
        "# 改配置请编辑源模板后重新运行生成脚本。\n"
        f"# 源模板：{src_note}\n\n"
    )
    body = yaml.safe_dump(out, allow_unicode=True, sort_keys=False, default_flow_style=False)
    dst.write_text(header + body, encoding="utf-8")

    print(f"[OK] generated {dst}")
    if warnings:
        print("\n[NOTE] warnings:")
        for w in warnings:
            print("  - " + w)


if __name__ == "__main__":
    main()
