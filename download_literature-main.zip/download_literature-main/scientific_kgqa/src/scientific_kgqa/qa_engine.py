from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Tuple

from rapidfuzz import fuzz

from .expert_weights import (
    ExpertConfig,
    chunk_types_for_task,
    compute_expert_score,
    detect_task_type,
    extract_emphasis_words,
    extract_functional_type,
    get_active_config,
    make_facts_cache,
)
from .llm_client import LLMClient
from .retriever import Retriever
from .storage import SQLiteStore
from .utils import CHUNK_TYPES, extract_year_range, infer_intent, normalize_text
from .walk import OnlineGraph, WalkConfig, beam_search, personalized_ppr, set_active_walk_config
from .domain_context import load_kg_prompts, prompt_or


@dataclass
class QuerySpec:
    raw_query: str
    intent: str
    field_hits: List[str]
    prototype_hits: List[str]
    chunk_types: List[str]
    year_range: Tuple[Optional[int], Optional[int]]
    task_type: Optional[str] = None
    functional_type: Optional[str] = None
    emphasis_words: Set[str] = field(default_factory=set)
    translated_query: Optional[str] = None  # set when Chinese→English translation was applied


class QAEngine:
    def __init__(self, store: SQLiteStore, retriever: Retriever,
                 llm_client: Optional[LLMClient] = None,
                 expert_config: Optional[ExpertConfig] = None,
                 domain_instruction: str = "",
                 kg_prompts: Optional[dict] = None):
        self.store = store
        self.retriever = retriever
        self.llm_client = llm_client
        self.graph = OnlineGraph(store)
        self.schema_fields = self.store.list_schema_fields()
        self.prototypes = self.store.list_concept_names()  # 新版用 Concept 节点（仅名称）
        # 语义种子选择：懒加载 concept embedding 矩阵
        self._concept_ids: Optional[List[int]] = None
        self._concept_matrix = None    # np.ndarray shape=(N,1024)
        # 一次 answer() 内复用 LLM anchor terms + term embedding，避免重复调用
        self._anchor_cache = None  # Tuple[query_str, (terms, vecs)] | None

        # 领域上下文前缀（来自 domain_prefer）；为空时查询期 prompt 保持纯通用
        self.domain_instruction = (domain_instruction or "").strip()

        # 专家配置 + 自动降级（O4）：配置引用的字段与本 schema 无交集时关闭 task-aware 重排
        self.expert_config = expert_config or get_active_config()
        field_names = [f["canonical_name"] for f in self.schema_fields]
        self.expert_enabled = self.expert_config.is_applicable_to(field_names)
        if not self.expert_enabled:
            print("[QAEngine] expert_config 字段与当前 schema 无交集 → "
                  "关闭 task-aware 重排，回退通用打分")

        # 图谱游走配置（walk.py）：从 expert_config 的 graph_walk 段构造并设为活动配置；
        # 缺失则 walk.py 回退代码内默认值（与 EM 示例一致），行为不变。
        set_active_walk_config(WalkConfig.from_dict(getattr(self.expert_config, "graph_walk", None)))

        # 查询期引导词（prompts_em.yaml）：None → 加载默认出货示例；缺 key → 内置中立常量
        prompts = kg_prompts if kg_prompts is not None else load_kg_prompts()
        self.translate_sys = prompt_or(prompts, "qa.translate_system", self._TRANSLATE_SYS)
        self.seed_expand_sys = prompt_or(prompts, "qa.seed_expand_system", self._SEED_EXPAND_SYS)
        self.sub_constraint_sys = prompt_or(prompts, "qa.sub_constraint_system", self._SUB_CONSTRAINT_SYS)
        # 答案生成 system（供 prompt_builder.build_qa_prompt 使用）；空串 → 由 prompt_builder 用其中立默认
        self.qa_answer_system = prompt_or(prompts, "qa.answer_system", "")


    def _ensure_concept_embeddings(self) -> bool:
        """懒加载 Concept embedding 矩阵，返回是否可用。"""
        if self._concept_matrix is not None:
            return True
        try:
            ids, matrix = self.store.get_all_concept_embeddings()
            if len(ids) == 0:
                return False
            self._concept_ids = ids
            self._concept_matrix = matrix
            return True
        except Exception:
            return False

    def answer(self, query: str, task_type_override: Optional[str] = None) -> Dict:
        # Step 0: translate Chinese query → English for KG/retriever matching
        en_query = self._translate_query(query)

        q = self.parse_query(en_query, task_type_override=task_type_override)
        if en_query != query:
            q.translated_query = en_query

        seed_ids = self.map_seeds(q)

        if not seed_ids:
            return {
                "query": query,
                "summary": "未找到明确 seed。建议在问题中加入具体机制、结构原型、性能指标或年份范围。",
                "reasoning_paths": [],
                "evidence": [],
                "evolution_context": [],
                "retrieval_plan": {},
                "confidence": 0.1,
            }

        # 预计算 query 与每个 Concept 的 embedding 相似度，用于 query-aware PPR
        # 让 PPR mass 倾向流向语义相关的 concept（而不是图结构上最常共现的）
        query_sim_map = self._compute_query_concept_similarities(en_query)

        ppr = personalized_ppr(self.graph, seed_ids, q.intent, query_sim_map=query_sim_map)
        # 放宽到 250（原 180），同时加入种子 2 跳邻居
        top_nodes = list(ppr.keys())[:250]
        two_hop: set = set()
        for nid in seed_ids:
            for e1 in self.graph.out_edges(nid):
                two_hop.add(e1.dst)
                for e2 in self.graph.out_edges(e1.dst):
                    two_hop.add(e2.dst)
        # candidate_nodes = PPR top-250 + 种子 2 跳邻居（更全面的覆盖）
        candidate_nodes: set[int] = set(top_nodes) | two_hop

        paths = beam_search(self.graph, seed_ids, candidate_nodes, q.intent)

        plan = self.make_retrieval_plan(q, seed_ids, paths)
        if en_query != query:
            plan["translated_query"] = en_query

        # For mechanism / optimization / parameter_effect: explicitly hop
        # FIELD_INSTANTIATES from every SchemaField in soft_node_ids to collect
        # Prototype nodes (which carry physical_mechanism postings).
        # PPR can dilute mass over long paths; this explicit step is a safety net.
        if q.intent in ("mechanism", "optimization", "parameter_effect"):
            extra_protos = self._expand_proto_from_fields(plan["soft_node_ids"])
            if extra_protos:
                plan["soft_node_ids"] = list(dict.fromkeys(plan["soft_node_ids"] + extra_protos))

        # Compute posting_node_ids: SchemaField / Concept / Prototype / MetricBucket carry postings
        # 一次批量查所有 soft_node_ids，避免 N 次单查（200+ 节点在压力下慢得离谱）
        _POSTING_TYPES = {"SchemaField", "Concept", "Prototype", "MetricBucket"}
        soft_ids = plan["soft_node_ids"]
        node_map = self.store.get_graph_nodes_by_ids(soft_ids)
        posting_node_ids = [
            nid for nid in soft_ids
            if node_map.get(nid, {}).get("node_type") in _POSTING_TYPES
        ]
        plan["posting_node_ids"] = posting_node_ids

        candidate_chunk_ids = self.store.get_posting_chunk_ids(
            plan["soft_node_ids"],
            chunk_types=plan["chunk_types"],
            year_range=plan["year_range"],
        )

        # Primary: graph-guided candidates (contextual, tied to seed nodes)
        primary_hits = self.retriever.search(
            en_query,
            candidate_chunk_ids=candidate_chunk_ids or None,
            chunk_types=plan["chunk_types"],
            topk=60,
        )

        # Secondary: full-corpus search restricted to top-priority chunk types only.
        # Ensures high-priority chunks (e.g. physical_mechanism for mechanism intent)
        # are reachable even when they have no node_chunk_posting to the seed nodes.
        secondary_hits: List[Dict] = []
        preferred_types = plan["chunk_types"][:2]
        if preferred_types:
            secondary_hits = self.retriever.search(
                en_query,
                candidate_chunk_ids=None,
                chunk_types=preferred_types,
                topk=40,
            )

        # Merge: per chunk_id keep the hit with the higher retrieval score
        merged: Dict[str, Dict] = {}
        for h in primary_hits + secondary_hits:
            cid = h["chunk_id"]
            if cid not in merged or h["score"] > merged[cid]["score"]:
                merged[cid] = h
        hits = list(merged.values())
        ranked = self.rerank(plan, hits)

        evolution_context = []
        if q.intent == "evolution":
            evolution_context = self.expand_evolution_context(ranked[:8])

        return self.compose_answer(query, q, paths, ranked, evolution_context, plan)

    def parse_query(self, query: str, task_type_override: Optional[str] = None) -> QuerySpec:
        intent = infer_intent(query)
        qnorm = normalize_text(query)
        year_range = extract_year_range(query)

        # task_type：CLI override 优先；否则从 query 自动检测（专家重排关闭时跳过）
        if self.expert_enabled:
            task_type = task_type_override or detect_task_type(query, self.expert_config)
            functional_type = extract_functional_type(query, self.expert_config) if task_type else None
            emphasis = extract_emphasis_words(query, task_type, self.expert_config) if task_type else set()
        else:
            task_type = task_type_override
            functional_type = None
            emphasis = set()

        field_hits = []
        for f in self.schema_fields:
            cands = [f["canonical_name"], normalize_text(f.get("display_name_zh") or "")]
            if any(x and x in qnorm for x in cands):
                field_hits.append(f["canonical_name"])
                continue
            if max([fuzz.partial_ratio(qnorm, x) for x in cands if x] or [0]) >= 88:
                field_hits.append(f["canonical_name"])

        prototype_hits = []
        for p in self.prototypes:
            name = p["canonical_name"]
            if not name:
                continue
            # Concept名は8-10語の長いフレーズ。完全一致のみ（fuzzy全件スキャンは遅すぎる）
            if name in qnorm:
                prototype_hits.append(name)

        # task_type 命中时优先用 task_type 的 chunk_type 优先级
        chunk_types = chunk_types_for_task(task_type, self.expert_config) or self._infer_chunk_types(intent)
        return QuerySpec(
            raw_query=query,
            intent=intent,
            field_hits=list(dict.fromkeys(field_hits)),
            prototype_hits=list(dict.fromkeys(prototype_hits)),
            chunk_types=chunk_types,
            year_range=year_range,
            task_type=task_type,
            functional_type=functional_type,
            emphasis_words=emphasis,
        )

    def _infer_chunk_types(self, intent: str) -> List[str]:
        if intent == "mechanism":
            return ["physical_mechanism", "influence_analysis", "design_method"]
        if intent == "optimization":
            return ["design_optimization_logic", "design_method", "influence_analysis"]
        if intent == "fabrication":
            return ["fabrication_process", "physical_mechanism", "influence_analysis"]
        if intent == "evolution":
            return ["design_optimization_logic", "physical_mechanism", "study_process_description", "influence_analysis"]
        if intent == "parameter_effect":
            return ["influence_analysis", "design_optimization_logic", "physical_mechanism"]
        return CHUNK_TYPES

    def map_seeds(self, q: QuerySpec) -> List[int]:
        seed_ids = []
        qn = normalize_text(q.raw_query)

        for field_name in q.field_hits:
            node = self.store.get_graph_node("SchemaField", field_name)
            if node:
                seed_ids.append(int(node["node_id"]))

        for proto in q.prototype_hits:
            for ntype in ("Concept", "Prototype"):
                node = self.store.get_graph_node(ntype, proto)
                if node:
                    seed_ids.append(int(node["node_id"]))
                    break

        # alias-based matching (picks up Chinese field aliases)
        if not seed_ids:
            for alias in self.store.search_aliases(qn, min_score=85):
                seed_ids.append(int(alias["node_id"]))

        # 主路径：LLM 抽 query 核心术语 + 每个术语单独 embedding 匹配
        # 这一步取代了原来"整段 query embedding semantic search"
        # 原因：整段 query 包含大量描述性词（"工程约束""硬性指标"），
        # 这些词在 BGE-M3 上会与"performance requirements""thickness parametrization"
        # 等结构力学/拓扑优化术语高度相似 → 引入大量无关 seed
        en_q = getattr(q, "translated_query", None) or q.raw_query
        llm_seeds = self._expand_seeds_with_llm(en_q)
        seed_ids = list(dict.fromkeys(seed_ids + llm_seeds))

        # evolution fallback: seed from top EVOLVES_TO source nodes
        if not seed_ids and q.intent == "evolution":
            seed_ids = self.store.get_top_evolves_to_nodes(limit=5)

        # 仅当 LLM 失败 / 返回过少时，才用整段 query embedding 做兜底
        # 阈值提高到 0.60（原 0.35），防止误匹通用语境
        if len(seed_ids) < 3:
            print(f"[map_seeds] LLM anchors yielded {len(seed_ids)} seeds, "
                  f"falling back to whole-query semantic (relaxed threshold)")
            semantic_seeds = self._map_seeds_semantic(en_q, min_sim=0.40)
            seed_ids = list(dict.fromkeys(seed_ids + semantic_seeds))

        return list(dict.fromkeys(seed_ids))

    def make_retrieval_plan(self, q: QuerySpec, seed_ids: List[int], paths: List[List[int]]) -> Dict:
        soft_node_ids = set(seed_ids)
        for p in paths[:10]:
            for nid in p:
                soft_node_ids.add(nid)

        return {
            "intent": q.intent,
            "seed_ids": seed_ids,
            "soft_node_ids": list(soft_node_ids),
            "chunk_types": q.chunk_types,
            "paths": paths[:10],
            "year_range": q.year_range,
            "task_type": q.task_type,
            "functional_type": q.functional_type,
            "emphasis_words": list(q.emphasis_words),
        }

    def rerank(self, plan: Dict, hits: List[Dict]) -> List[Dict]:
        ranked = []
        seed_node_ids = set(plan["seed_ids"])
        y0, y1 = plan["year_range"]

        chunk_type_rank = {t: idx for idx, t in enumerate(plan["chunk_types"])}
        n_types = max(1, len(plan["chunk_types"]))

        # task_type 命中时启用专家维度打分（且本 schema 适用该专家配置）
        task_type = plan.get("task_type")
        functional_type = plan.get("functional_type")
        emphasis = set(plan.get("emphasis_words", []) or [])
        use_expert = bool(self.expert_enabled and task_type in self.expert_config.task_weights)

        # 单次查询内复用一个事实缓存，避免重复扫 paper_fact
        facts_cache = make_facts_cache(self.store) if use_expert else None
        # 任务一/二 functional_type 权重 >= 0.80 时启用强 gating
        ft_w = self.expert_config.task_weights.get(task_type, {}).get("functional_type", 0.0) if use_expert else 0.0
        gating_active = bool(use_expert and functional_type and ft_w >= 0.80)

        for h in hits:
            chunk = self.store.get_chunk(h["chunk_id"])
            if not chunk:
                continue

            year = chunk.get("year")
            if y0 is not None and year is not None and year < y0:
                continue
            if y1 is not None and year is not None and year > y1:
                continue

            chunk_node_ids = set(self.store.get_chunk_node_ids(h["chunk_id"]))
            # Coverage = fraction of seed concepts covered by this chunk's postings.
            # Using seed_ids as denominator (2-5 nodes) instead of all soft nodes
            # (70+) makes coverage a meaningful signal rather than near-zero noise.
            coverage = len(chunk_node_ids & seed_node_ids) / max(1, len(seed_node_ids))

            authority = self.store.get_paper_authority(h["paper_id"])

            evolution_bonus = 0.0
            if plan["intent"] == "evolution":
                neighbors = self.store.get_local_neighbors(h["paper_id"])
                evolution_bonus = min(
                    1.0,
                    0.05 * len(neighbors["references"]) + 0.05 * len(neighbors["citations"])
                )

            type_rank = chunk_type_rank.get(h["chunk_type"], n_types)
            type_priority = max(0.2, 1.0 - 0.25 * type_rank)

            if use_expert:
                expert_score, ft_match = compute_expert_score(
                    h["paper_id"], task_type, functional_type, emphasis, facts_cache,
                    self.expert_config,
                )
                # gating：任务一/二 显式不匹配的 paper 直接丢弃（"不对则不参考"）
                if gating_active and ft_match is False:
                    continue

                final_score = (
                    0.30 * h["score"] +
                    0.40 * expert_score +
                    0.15 * coverage +
                    0.10 * authority +
                    0.05 * type_priority
                )
                h["expert_score"] = round(expert_score, 4)
                h["functional_type_match"] = ft_match  # True/False/None
            else:
                final_score = (
                    0.45 * h["score"] +
                    0.20 * coverage +
                    0.15 * authority +
                    0.10 * evolution_bonus +
                    0.10 * type_priority
                )

            h["coverage"] = coverage
            h["authority"] = authority
            h["type_priority"] = round(type_priority, 4)
            h["final_score"] = final_score
            ranked.append(h)

        ranked.sort(key=lambda x: x["final_score"], reverse=True)
        return ranked[:15]

    def expand_evolution_context(self, ranked_hits: List[Dict]) -> List[Dict]:
        out = []
        seen = set()

        for h in ranked_hits[:5]:
            paper_id = h["paper_id"]
            neighbors = self.store.get_local_neighbors(paper_id)

            refs = sorted(
                neighbors["references"],
                key=lambda x: ((x.get("year") or 0), (x.get("citation_count") or 0)),
                reverse=True,
            )[:3]
            cits = sorted(
                neighbors["citations"],
                key=lambda x: ((x.get("year") or 0), (x.get("citation_count") or 0)),
                reverse=True,
            )[:3]

            for ref in refs:
                key = ("reference", paper_id, ref["paper_id"])
                if key in seen:
                    continue
                seen.add(key)
                out.append({
                    "type": "reference",
                    "center_paper_id": paper_id,
                    "neighbor_paper_id": ref["paper_id"],
                    "neighbor_title": ref["paper_title"],
                    "neighbor_year": ref["year"],
                    "neighbor_citation_count": ref["citation_count"],
                })

            for cit in cits:
                key = ("citation", paper_id, cit["paper_id"])
                if key in seen:
                    continue
                seen.add(key)
                out.append({
                    "type": "citation",
                    "center_paper_id": paper_id,
                    "neighbor_paper_id": cit["paper_id"],
                    "neighbor_title": cit["paper_title"],
                    "neighbor_year": cit["year"],
                    "neighbor_citation_count": cit["citation_count"],
                })

        return out[:12]

    def compose_answer(
        self,
        query: str,
        q: QuerySpec,
        paths: List[List[int]],
        ranked: List[Dict],
        evolution_context: List[Dict],
        plan: Dict,
    ) -> Dict:
        # 展示层路径筛选规则：
        #   1. 边数 >= 3（节点数 >= 4），过滤 trivial 短路径
        #   2. 每个 seed (path[0]) 最多展示 1 条
        #   3. 同前缀去重（包含关系视为同分支）
        #   4. 总展示数上限 MAX_DISPLAY（按 path_score 降序优先）
        # 注意：本筛选只影响 reasoning_paths 展示，不影响 plan["soft_node_ids"]
        MIN_EDGES = 3
        PER_SEED_LIMIT = 1
        MAX_DISPLAY = 8

        per_seed_count: dict = {}
        diverse_paths: List[List[int]] = []
        for p in paths:
            if len(p) - 1 < MIN_EDGES:
                continue
            seed = p[0]
            if per_seed_count.get(seed, 0) >= PER_SEED_LIMIT:
                continue

            # 同前缀去重：当前 path 不能是已选 path 的扩展，反之亦然
            redundant = False
            p_tuple = tuple(p)
            for kept in diverse_paths:
                k_tuple = tuple(kept)
                if p_tuple[: len(k_tuple)] == k_tuple or k_tuple[: len(p_tuple)] == p_tuple:
                    redundant = True
                    break
            if redundant:
                continue

            diverse_paths.append(p)
            per_seed_count[seed] = per_seed_count.get(seed, 0) + 1
            if len(diverse_paths) >= MAX_DISPLAY:
                break

        path_texts = []
        for p in diverse_paths:
            names = []
            for nid in p:
                node = self.store.get_graph_node_by_id(nid)
                if node:
                    names.append(f'{node["node_type"]}:{node["canonical_name"]}')
            if names:
                path_texts.append(" -> ".join(names))

        evidence = []
        for h in ranked[:5]:
            chunk = self.store.get_chunk(h["chunk_id"])
            ev = {
                "paper_id": h["paper_id"],
                "paper_title": chunk["paper_title"] if chunk else h["paper_id"],
                "year": chunk["year"] if chunk else None,
                "chunk_type": h["chunk_type"],
                "score": round(h["final_score"], 4),
                "authority": round(h["authority"], 4),
                "coverage": round(h["coverage"], 4),
                "text": h["text"],
            }
            if "expert_score" in h:
                ev["expert_score"] = h["expert_score"]
                ev["functional_type_match"] = h.get("functional_type_match")
            evidence.append(ev)

        if evidence:
            summary = self._make_summary(q, evidence, path_texts, evolution_context)
            confidence = min(0.95, 0.40 + 0.07 * len(evidence) + 0.05 * len(path_texts))
        else:
            summary = "未检索到足够证据。建议缩小问题范围、补充字段名/机制名，或指定年份。"
            confidence = 0.15

        # 完整种子 / 软节点（含 type+name），便于专家审计图谱拓展范围
        seed_nodes_full = self._describe_nodes(plan["seed_ids"])
        soft_nodes_full = self._describe_nodes(plan["soft_node_ids"])
        posting_nodes_full = self._describe_nodes(plan.get("posting_node_ids", []) or [])

        return {
            "query": query,
            "intent": q.intent,
            "summary": summary,
            "reasoning_paths": path_texts,
            "evidence": evidence,
            "evolution_context": evolution_context,
            "retrieval_plan": {
                "intent": plan["intent"],
                "task_type": plan.get("task_type"),
                "functional_type": plan.get("functional_type"),
                "emphasis_words": plan.get("emphasis_words", []),
                "seed_ids": plan["seed_ids"],
                "seed_nodes": seed_nodes_full,
                "soft_node_ids": plan["soft_node_ids"],
                "soft_nodes": soft_nodes_full,
                "soft_node_count": len(plan["soft_node_ids"]),
                "posting_node_ids": plan.get("posting_node_ids", []),
                "posting_nodes": posting_nodes_full,
                "posting_node_count": len(plan.get("posting_node_ids", [])),
                "chunk_types": plan["chunk_types"],
                "year_range": plan["year_range"],
                "translated_query": plan.get("translated_query"),
            },
            "confidence": round(confidence, 3),
        }

    # ------------------------------------------------------------------ helpers

    _TRANSLATE_SYS = (
        "You are a scientific/technical domain expert. "
        "Translate the following query to English. Preserve ALL technical terms, named "
        "methods, materials, and domain acronyms exactly as written. "
        'Output JSON only: {"translated": "..."}'
    )

    _SEED_EXPAND_SYS = (
        "You are a scientific/technical domain expert helping extract knowledge graph "
        "search anchors from a user's research query.\n\n"
        "Your job: identify 4-7 SHORT canonical technical terms that the query is "
        "DIRECTLY about. These will be matched against a knowledge graph of concept nodes.\n\n"
        "STRICT RULES:\n"
        "- Each term must be 1-3 words, the canonical name a domain expert would use\n"
        "- Use established domain terms / acronyms, not paraphrases\n"
        "- Only extract terms the query EXPLICITLY mentions or directly requires.\n"
        "- DO NOT invent related but tangential concepts.\n"
        "- DO NOT extract generic words ('design', 'optimization', 'requirement', 'analysis', "
        "  'performance', 'constraint', 'method') — these are noise.\n"
        "- DO NOT extract numerical specs or units — only conceptual terms.\n"
        "- If the query targets a specific application scenario, include it as a term.\n\n"
        "Output JSON only: {\"terms\": [\"term1\", \"term2\", ...]}"
    )

    def _sys_with_domain(self, base: str) -> str:
        """把领域上下文前缀拼到查询期 system prompt 前；无注入时返回 base。"""
        return f"{self.domain_instruction}\n\n{base}" if self.domain_instruction else base

    def _translate_query(self, query: str) -> str:
        """Return English translation of query; return original if no Chinese or LLM unavailable."""
        import re
        if not re.search(r'[一-鿿]', query) or self.llm_client is None:
            return query
        try:
            result = self.llm_client.chat_json(self._sys_with_domain(self.translate_sys), query, temperature=0.1)
            translated = (result.get("translated") or "").strip()
            return translated if translated else query
        except Exception:
            return query

    def _extract_anchor_terms_and_vecs(self, en_query: str):
        """LLM 从 query 抽核心术语 + 生成 term embeddings。

        返回 (clean_terms, term_vecs) 或 (None, None)。
        被 _expand_seeds_with_llm 和 _compute_query_concept_similarities 共用，
        避免重复调用 LLM 和 embedding API。

        缓存到 self._anchor_cache，同一次 answer() 内只调用一次。
        """
        cache_key = en_query
        if getattr(self, "_anchor_cache", None) is not None:
            ck, cv = self._anchor_cache
            if ck == cache_key:
                return cv

        if self.llm_client is None:
            self._anchor_cache = (cache_key, (None, None))
            return None, None

        try:
            result = self.llm_client.chat_json(self._sys_with_domain(self.seed_expand_sys), en_query, temperature=0.1)
            terms = result.get("terms") or []
        except Exception as e:
            print(f"[anchor_terms] LLM call failed: {e}")
            self._anchor_cache = (cache_key, (None, None))
            return None, None

        if not terms:
            print("[anchor_terms] LLM returned no terms")
            self._anchor_cache = (cache_key, (None, None))
            return None, None

        # 清洗 + 去重：保留前 7 个非空 1-4 词术语
        clean_terms: List[str] = []
        seen: Set[str] = set()
        for t in terms:
            if not isinstance(t, str):
                continue
            tn = t.strip().lower()
            if not tn or tn in seen:
                continue
            n_tok = len(tn.split())
            if n_tok < 1 or n_tok > 4:
                continue
            clean_terms.append(tn)
            seen.add(tn)
            if len(clean_terms) >= 7:
                break

        if not clean_terms:
            self._anchor_cache = (cache_key, (None, None))
            return None, None

        print(f"[anchor_terms] core terms = {clean_terms}")

        try:
            import numpy as np
            from kb_mvp.src.embedding import get_client as get_embed_client
            embed_client = get_embed_client()
            term_vecs = np.asarray(embed_client.embed(clean_terms), dtype=np.float32)
            norms = np.linalg.norm(term_vecs, axis=1, keepdims=True)
            norms = np.where(norms == 0, 1, norms)
            term_vecs = term_vecs / norms
            self._anchor_cache = (cache_key, (clean_terms, term_vecs))
            return clean_terms, term_vecs
        except Exception as e:
            print(f"[anchor_terms] embedding failed: {e}")
            self._anchor_cache = (cache_key, (None, None))
            return None, None

    def _expand_seeds_with_llm(self, en_query: str) -> List[int]:
        """用 LLM 抽出的核心术语，每个单独做 embedding 找最近邻 Concept 节点。"""
        clean_terms, term_vecs = self._extract_anchor_terms_and_vecs(en_query)
        if not clean_terms or term_vecs is None:
            return []
        if not self._ensure_concept_embeddings():
            return []

        try:
            import numpy as np
            PER_TERM_TOPK = 3
            MIN_SIM = 0.55
            seed_ids: List[int] = []
            for i, term in enumerate(clean_terms):
                sims = self._concept_matrix @ term_vecs[i]
                idxs = np.argsort(sims)[-PER_TERM_TOPK:][::-1]
                hits = []
                for j in idxs:
                    s = float(sims[j])
                    if s >= MIN_SIM:
                        hits.append((self._concept_ids[j], s))
                if hits:
                    print(f"[llm_seeds]   '{term}' -> top_sim={hits[0][1]:.3f}, n={len(hits)}")
                    seed_ids.extend(nid for nid, _ in hits)
                else:
                    top_s = float(sims[idxs[0]]) if len(idxs) > 0 else 0.0
                    print(f"[llm_seeds]   '{term}' -> top_sim={top_s:.3f} (below {MIN_SIM})")
            return list(dict.fromkeys(seed_ids))
        except Exception as e:
            print(f"[llm_seeds] search failed: {e}")
            return []

    def _expand_proto_from_fields(self, node_ids: List[int]) -> List[int]:
        """Traverse FIELD_INSTANTIATES from every node in node_ids to collect Prototype nodes."""
        proto_ids = []
        for nid in node_ids:
            for e in self.graph.out_edges(nid):
                if e.relation_type == "FIELD_INSTANTIATES":
                    proto_ids.append(e.dst)
        return list(dict.fromkeys(proto_ids))

    def _describe_nodes(self, node_ids: List[int]) -> List[Dict]:
        """node_id 列表 → [{node_id, node_type, canonical_name}, ...]，便于审计。
        批量查询一次性拿回，避免 N 次 SQL。
        """
        if not node_ids:
            return []
        node_map = self.store.get_graph_nodes_by_ids(list(node_ids))
        out: List[Dict] = []
        for nid in node_ids:
            n = node_map.get(int(nid))
            if n:
                out.append({
                    "node_id": int(nid),
                    "node_type": n["node_type"],
                    "canonical_name": n["canonical_name"],
                })
            else:
                out.append({"node_id": int(nid), "node_type": None, "canonical_name": None})
        return out

    def _make_summary(self, q: QuerySpec, evidence: List[Dict], paths: List[str], evolution_context: List[Dict]) -> str:
        top = evidence[0]
        parts = [
            f"系统优先在 {', '.join(q.chunk_types)} 中检索证据。",
            f"当前最强证据来自《{top['paper_title']}》({top.get('year')}) 的 {top['chunk_type']} 段。",
        ]

        if q.field_hits:
            parts.append(f"识别到字段：{', '.join(q.field_hits[:4])}。")
        if q.prototype_hits:
            parts.append(f"识别到原型：{', '.join(q.prototype_hits[:4])}。")
        if q.year_range != (None, None):
            parts.append(f"已应用年份约束：{q.year_range}。")
        if paths:
            parts.append("图谱路径主要沿 schema field -> prototype -> metric/state 或 evolution edge 传播。")
        if q.intent == "evolution" and evolution_context:
            parts.append(f"另外从本地 citation/reference 网络补充了 {len(evolution_context)} 条局部演化上下文。")

        return " ".join(parts)

    # ──────────────────────────────────────────────────────────────────
    # 子查询约束：防止 beam_search 发散
    # ──────────────────────────────────────────────────────────────────

    _SUB_CONSTRAINT_SYS = (
        "You are a scientific/technical domain expert. "
        "Extract 4-6 short technical terms (canonical domain wording) that a relevant KG node "
        "name MUST be related to in order to be useful for answering this query. "
        "These are hard constraints — unrelated concepts should be excluded. "
        'Output JSON only: {"terms": ["term1", ...]}'
    )

    def _extract_sub_constraints(self, en_query: str) -> List[str]:
        """用 LLM 从 query 提取约束词，用于剪枝候选节点。"""
        if self.llm_client is None:
            return []
        try:
            result = self.llm_client.chat_json(
                self._sys_with_domain(self.sub_constraint_sys), en_query, temperature=0.1
            )
            terms = result.get("terms") or []
            return [normalize_text(t) for t in terms[:6] if t]
        except Exception:
            return []

    def _filter_nodes_by_constraints(
        self, node_ids: set, sub_terms: List[str]
    ) -> set:
        """
        保留与任意一个 sub_term 相关的节点（token_sort_ratio >= 45）。
        种子节点（已在 seed_ids）不受此过滤影响。
        过滤后若剩余节点太少，降级返回原集合。
        """
        if not sub_terms:
            return node_ids

        kept: set = set()
        for nid in node_ids:
            node = self.store.get_graph_node_by_id(nid)
            if not node:
                continue
            name = normalize_text(node.get("canonical_name") or "")
            # 单词节点直接放行（seed 附近的基础节点）
            if len(name.split()) <= 1:
                kept.add(nid)
                continue
            # 与任一约束词相关则保留
            for term in sub_terms:
                if fuzz.token_sort_ratio(name, term) >= 45:
                    kept.add(nid)
                    break

        # 降级保护：若过滤后太少，回退到原集合
        if len(kept) < 10:
            return node_ids
        return kept

    # ──────────────────────────────────────────────────────────────────────
    # 语义种子选择（基于 BGE-M3 embedding）
    # ──────────────────────────────────────────────────────────────────────

    def _map_seeds_semantic(self, query: str, topk: int = 8, min_sim: float = 0.35) -> List[int]:
        """用 query embedding 在所有 Concept 节点的 embedding 矩阵中找最近邻。

        解决字符串匹配无法覆盖的同义词和跨语言问题：
        - "transparent metasurface" ↔ "transmissive FSS"
        - "单层超表面" ↔ "single-layer metasurface"
        """
        if not self._ensure_concept_embeddings():
            return []

        try:
            import numpy as np
            from kb_mvp.src.embedding import get_client as get_embed_client

            embed_client = get_embed_client()
            q_vec = embed_client.embed_one(query).astype(np.float32)
            q_norm = np.linalg.norm(q_vec)
            if q_norm > 0:
                q_vec = q_vec / q_norm

            # cosine 相似度（矩阵已归一化）
            sims = self._concept_matrix @ q_vec
            idxs = np.argsort(sims)[-topk:][::-1]

            seed_ids = []
            for i in idxs:
                if float(sims[i]) >= min_sim:
                    seed_ids.append(self._concept_ids[i])
            print(f"[semantic_seeds] top_sim={float(sims[idxs[0]]):.3f} found={len(seed_ids)} min_sim={min_sim}")
            return seed_ids
        except Exception as e:
            print(f"[semantic_seeds] failed: {e}")
            return []

    def _compute_query_concept_similarities(self, query: str) -> Optional[Dict[int, float]]:
        """计算 query 与所有 Concept 节点的 cosine 相似度，用于 query-aware PPR。

        关键设计：query embedding **不用整段 query**。
        原因：query 含大量泛用工程词（"硬性约束""工程指标"），整段 embedding
        会被 BGE-M3 对齐到 "performance requirements"/"system-level requirements"
        等结构力学/拓扑优化术语（实测 cosine 0.61，远高于 FSS/transparent 等
        真正相关 concept），导致 PPR mass 流向无关方向。

        改用 LLM 抽出的核心术语的平均 embedding 作为 query 表示，避免被
        泛用工程词污染。LLM 不可用时回退到整段 query embedding（兜底）。
        """
        if not self._ensure_concept_embeddings():
            return None
        try:
            import numpy as np

            # 优先用 LLM 抽核心术语的平均向量作为 query 表示
            clean_terms, term_vecs = self._extract_anchor_terms_and_vecs(query)
            q_vec: Optional[np.ndarray] = None
            if term_vecs is not None and len(term_vecs) > 0:
                q_vec = term_vecs.mean(axis=0).astype(np.float32)
                q_norm = np.linalg.norm(q_vec)
                if q_norm > 0:
                    q_vec = q_vec / q_norm
                src = f"avg of {len(clean_terms)} anchor terms"
            else:
                # 兜底：用整段 query embedding（已知会污染，但比 None 强）
                from kb_mvp.src.embedding import get_client as get_embed_client
                embed_client = get_embed_client()
                q_vec = embed_client.embed_one(query).astype(np.float32)
                q_norm = np.linalg.norm(q_vec)
                if q_norm > 0:
                    q_vec = q_vec / q_norm
                src = "whole-query fallback (LLM unavailable)"

            sims = self._concept_matrix @ q_vec
            sim_map = {self._concept_ids[i]: max(0.0, float(sims[i]))
                       for i in range(len(self._concept_ids))}

            # 调试：top-K 与 query 最相关的 concept
            top_idx = np.argsort(sims)[-10:][::-1]
            top_names = []
            for j in top_idx[:5]:
                nid = self._concept_ids[j]
                node = self.store.get_graph_node_by_id(nid)
                name = node["canonical_name"] if node else f"id={nid}"
                top_names.append(f"{name}({float(sims[j]):.2f})")
            print(f"[query_sim] source={src} | top5: {' | '.join(top_names)}")
            return sim_map
        except Exception as e:
            print(f"[query_sim] failed: {e}")
            return None


