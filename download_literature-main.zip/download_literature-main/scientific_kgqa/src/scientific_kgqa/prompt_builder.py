"""prompt_builder.py — 把 QAEngine.answer() 输出拼成 LLM system + user prompt。

核心函数：build_qa_prompt(qa_result, query, max_evidence) -> (system, user)

设计要点：
  - system 固定中文模板，强调"严格基于证据"
  - user 动态拼推理路径 + 文献证据 + 演化上下文
  - 每条 evidence 截断 600 char，最多 max_evidence 条 → 总输入控制在 ~10k tokens
"""
from __future__ import annotations

from typing import Dict, List, Tuple


SYSTEM_PROMPT = """你是科学/技术文献领域的专家助手。基于下面提供的知识图谱推理路径和文献证据，回答用户问题。

要求：
1. 严格基于提供的证据回答，不编造未在证据中出现的事实
2. 引用证据时使用 [证据N] 标记（N = 证据编号）
3. 当证据不足时明确说明"根据现有证据无法确定"，不要硬答
4. 输出结构：先给出结论，再列举支撑证据
5. 回答用中文，专业术语保留原文（通常是英文）

请严格按以下 JSON 格式输出（不要包裹 markdown 代码块）：
{
  "answer": "<完整自然语言回答，包含 [证据N] 引用标记>"
}
"""


def _format_paths(paths: List[str], max_paths: int = 5) -> str:
    if not paths:
        return "（KG 游走未产生有效路径）"
    lines = []
    for i, p in enumerate(paths[:max_paths], 1):
        lines.append(f"{i}. {p}")
    return "\n".join(lines)


def _format_evidence(evidence: List[Dict], max_evidence: int = 8, snippet_len: int = 600) -> str:
    if not evidence:
        return "（未检索到相关文献证据）"
    lines = []
    for i, e in enumerate(evidence[:max_evidence], 1):
        title = e.get("paper_title", "<无标题>")
        year = e.get("year") or "未知年份"
        ctype = e.get("chunk_type", "")
        score = e.get("score", 0.0)
        text = (e.get("text") or "").strip().replace("\n", " ")
        if len(text) > snippet_len:
            text = text[:snippet_len].rstrip() + "…"
        lines.append(
            f"[证据{i}] 《{title}》({year}, {ctype}, score={score:.3f})\n{text}"
        )
    return "\n\n".join(lines)


def _format_evolution(evo_ctx: List[Dict], max_items: int = 8) -> str:
    if not evo_ctx:
        return ""
    lines = ["\n## 演化上下文（基于本地引用网络）"]
    for ec in evo_ctx[:max_items]:
        kind = "引用" if ec.get("type") == "reference" else "被引"
        title = ec.get("neighbor_title", "<无标题>")
        year = ec.get("neighbor_year") or "?"
        cite_n = ec.get("neighbor_citation_count") or 0
        lines.append(
            f"- {kind}: 《{title}》({year}, 被引 {cite_n} 次)"
        )
    return "\n".join(lines) + "\n"


def build_qa_prompt(
    qa_result: Dict,
    query: str,
    max_evidence: int = 8,
    snippet_len: int = 600,
    domain_instruction: str = "",
    system_prompt: str = "",
) -> Tuple[str, str]:
    """构建 (system_prompt, user_prompt) 二元组。

    system_prompt 非空时作为答案生成 system 基底（来自 prompts 配置 qa.answer_system）；
    为空则用内置中立 SYSTEM_PROMPT。domain_instruction 非空时再拼到最前做领域偏向。

    qa_result 来自 QAEngine.answer()，期待字段：
      - intent: str
      - reasoning_paths: List[str]
      - evidence: List[{paper_title, year, chunk_type, score, text, ...}]
      - evolution_context: List[{type, neighbor_title, ...}]
      - retrieval_plan: {chunk_types, year_range, soft_node_count, ...}
    """
    intent = qa_result.get("intent", "unknown")
    paths = qa_result.get("reasoning_paths", []) or []
    evidence = qa_result.get("evidence", []) or []
    evo_ctx = qa_result.get("evolution_context", []) or []
    plan = qa_result.get("retrieval_plan", {}) or {}

    # chunk_types 用于让 LLM 理解检索口径
    chunk_types = plan.get("chunk_types", [])
    chunk_types_str = ", ".join(chunk_types) if chunk_types else "全部 chunk 类型"

    # 任务类型上下文（启发构型/参数寻优/工艺标准库）
    task_type = plan.get("task_type")
    functional_type = plan.get("functional_type")
    emphasis = plan.get("emphasis_words") or []
    task_block = ""
    if task_type:
        task_label = {
            "heuristic_config": "启发式构型（功能类型主导）",
            "param_optimization": "参数寻优（结构/机理主导）",
            "process_library": "工艺/标准库（结构/材料主导）",
        }.get(task_type, task_type)
        task_block = f"- 任务类型: **{task_label}**"
        if functional_type:
            task_block += f"\n- 目标功能类型: {functional_type}（已对该类型不匹配的论文做硬过滤）"
        if emphasis:
            task_block += f"\n- 强调维度: {', '.join(emphasis)}"
        task_block += "\n"

    user_prompt = f"""## 用户问题
{query}

## 检索上下文
- 推断意图: **{intent}**
- 检索 chunk 类型（按优先级）: {chunk_types_str}
- 涉及节点数: {plan.get("soft_node_count", 0)}（图游走扩散范围）
{task_block}
## 知识图谱推理路径
{_format_paths(paths)}

## 文献证据
{_format_evidence(evidence, max_evidence, snippet_len)}
{_format_evolution(evo_ctx)}
请基于以上推理路径与证据，回答用户问题。严格按 system 中要求的 JSON 格式输出。
"""
    base = system_prompt.strip() if system_prompt and system_prompt.strip() else SYSTEM_PROMPT
    final_system = (
        f"{domain_instruction.strip()}\n\n{base}"
        if domain_instruction and domain_instruction.strip()
        else base
    )
    return final_system, user_prompt
