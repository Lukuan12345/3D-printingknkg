"""cli_pipeline.py — 端到端 QA CLI: KG 游走 + KB 检索 + LLM 生成式回答。

用法：
    python -m scientific_kgqa.cli_pipeline \\
        --query "哪些机制有助于提升 angular stability 并保持较低 insertion loss?" \\
        --db scientific_kgqa/artifacts/kgqa.db \\
        --retriever scientific_kgqa/artifacts/retriever.pkl \\
        --llm-config configs/extract_config_aero.yaml \\
        --llm-model claude-haiku-4-5-20251001

LLM 配置三种来源（优先级从高到低）：
    1. CLI 旗标 --llm-base-url / --llm-api-key
    2. --llm-config 指向的主框架 yaml 的 llm 段
    3. 环境变量 LLM_BASE_URL / LLM_API_KEY
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Optional, Tuple

from .config import DEFAULT_DB_PATH, DEFAULT_RETRIEVER_PATH
from .llm_client import LLMClient
from .pipeline import DomainPipeline
from .retriever import Retriever
from .storage import SQLiteStore


def _load_llm_from_yaml(yaml_path: Path) -> Tuple[Optional[str], Optional[str]]:
    """从主框架 yaml 配置（configs/extract_config_aero.yaml）读 llm.base_url / api_key。"""
    try:
        import yaml
    except ImportError:
        print("[FAIL] pyyaml 未安装，无法读 --llm-config", file=sys.stderr)
        return None, None

    if not yaml_path.exists():
        print(f"[FAIL] yaml 配置不存在: {yaml_path}", file=sys.stderr)
        return None, None

    with open(yaml_path, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f) or {}
    llm = cfg.get("llm", {}) or {}
    return llm.get("base_url"), llm.get("api_key")


def _resolve_llm(args) -> Tuple[Optional[str], Optional[str]]:
    """按优先级 CLI > yaml > env 解析 base_url + api_key。"""
    base_url = args.llm_base_url
    api_key = args.llm_api_key

    if (not base_url or not api_key) and args.llm_config:
        yb, yk = _load_llm_from_yaml(Path(args.llm_config))
        base_url = base_url or yb
        api_key = api_key or yk

    base_url = base_url or os.environ.get("LLM_BASE_URL")
    api_key = api_key or os.environ.get("LLM_API_KEY") or os.environ.get("ANTHROPIC_AUTH_TOKEN")
    return base_url, api_key


def main():
    p = argparse.ArgumentParser(
        description="KG 游走 + KB 检索 + LLM 生成式 QA",
    )
    p.add_argument("--query", required=True, help="用户问题")
    p.add_argument("--db", default=str(DEFAULT_DB_PATH),
                   help="KGQA SQLite 路径（默认指向 demo db）")
    p.add_argument("--retriever", default=str(DEFAULT_RETRIEVER_PATH),
                   help="Retriever pickle 路径")
    p.add_argument("--llm-config", default=None,
                   help="主框架 yaml 配置文件（提取 llm 段）")
    p.add_argument("--llm-base-url", default=None,
                   help="LLM API base URL（覆盖 yaml/env）")
    p.add_argument("--llm-api-key", default=None,
                   help="LLM API key（覆盖 yaml/env）")
    p.add_argument("--llm-model", default="claude-haiku-4-5-20251001",
                   help="LLM 模型名")
    p.add_argument("--max-evidence", type=int, default=8,
                   help="送给 LLM 的证据条数上限")
    p.add_argument("--snippet-len", type=int, default=600,
                   help="每条证据正文截断字符数")
    p.add_argument("--max-tokens", type=int, default=2048,
                   help="LLM 回答最大 token 数")
    p.add_argument("--task-type", default=None,
                   choices=["heuristic_config", "param_optimization", "process_library"],
                   help="覆盖任务类型自动识别（启发构型/参数寻优/工艺标准库）")
    p.add_argument("--no-llm", action="store_true",
                   help="跳过 LLM 生成，仅返回 KG 游走 + 检索结果")
    p.add_argument("--pretty", action="store_true",
                   help="JSON 输出 indent=2（默认 indent=2）")
    args = p.parse_args()

    # 加载 store + retriever
    db_path = Path(args.db)
    if not db_path.exists():
        print(f"[FAIL] db 不存在: {db_path}", file=sys.stderr)
        return 2
    retriever_path = Path(args.retriever)
    if not retriever_path.exists():
        print(f"[FAIL] retriever 不存在: {retriever_path}", file=sys.stderr)
        return 2

    store = SQLiteStore(db_path)
    retriever = Retriever.load(retriever_path)

    # 解析 LLM 配置
    llm_client: Optional[LLMClient] = None
    if not args.no_llm:
        base_url, api_key = _resolve_llm(args)
        if not base_url or not api_key:
            print(
                "[warn] LLM base_url/api_key 未配置（CLI/yaml/env 都没有），"
                "降级为 --no-llm 模式（仅返回检索结果）",
                file=sys.stderr,
            )
        else:
            llm_client = LLMClient(
                api_key=api_key,
                model=args.llm_model,
                base_url=base_url,
                max_tokens=args.max_tokens,
            )
            print(
                f"[llm] enabled model={args.llm_model} base_url={base_url}",
                file=sys.stderr,
            )

    # 跑 pipeline
    pipeline = DomainPipeline(
        store=store,
        retriever=retriever,
        llm_client=llm_client,
        max_evidence=args.max_evidence,
        snippet_len=args.snippet_len,
    )

    print(f"[query] {args.query}", file=sys.stderr)
    if args.task_type:
        print(f"[task-type] override = {args.task_type}", file=sys.stderr)
    result = pipeline.answer(args.query, task_type=args.task_type)

    # 输出（JSON 到 stdout，方便管道）
    out = json.dumps(result, ensure_ascii=False, indent=2)
    sys.stdout.buffer.write((out + "\n").encode("utf-8"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
