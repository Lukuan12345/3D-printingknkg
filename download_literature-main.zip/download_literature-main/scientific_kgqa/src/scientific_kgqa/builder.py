from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
from statistics import median
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd
from rapidfuzz import fuzz
from tqdm import tqdm

from .storage import SQLiteStore
from .utils import (
    CHUNK_TYPES,
    PROTOTYPE_SOURCE_FIELDS,
    choose_source_chunk,
    extract_candidate_phrases,
    extract_citation_links,
    extract_paper_meta,
    guess_opt_direction,
    infer_value_type,
    is_metric_like_field,
    is_noise_prototype,
    iter_kb_records,
    jaccard_text,
    load_json,
    log_squash,
    normalize_doi,
    normalize_key,
    normalize_text,
    normalize_title,
    parse_numeric,
    parse_range,
    prototype_signature,
    safe_mid,
    split_multi_value,
)


@dataclass
class FactObj:
    fact_id: int
    paper_id: str
    chunk_id: Optional[str]
    field_name: str
    value_type: str
    value_raw: str
    value_norm: Optional[str] = None
    num_value: Optional[float] = None
    range_low: Optional[float] = None
    range_high: Optional[float] = None
    unit: Optional[str] = None


class GraphBuilder:
    def __init__(self, store: SQLiteStore, llm_extractor=None):
        self.store = store
        self.node_cache: dict[tuple[str, str], int] = {}
        self.schema_specs: dict[str, dict[str, Any]] = {}

        self.paper_fields = defaultdict(set)
        self.paper_prototypes = defaultdict(set)
        self.paper_buckets = defaultdict(set)

        self.paper_year: Dict[str, Optional[int]] = {}
        self.proto_years = defaultdict(list)
        self.paper_metric_values = defaultdict(lambda: defaultdict(list))

        self.local_by_doi: Dict[str, str] = {}
        self.local_by_title: Dict[str, List[str]] = defaultdict(list)
        # token → set of norm_titles，用于 O(candidates) 模糊匹配
        self.local_by_token: Dict[str, set] = defaultdict(set)

        # LLM-derived extractions (populated by _run_llm_extraction if enabled)
        self.llm_extractor = llm_extractor
        self.llm_concepts: Dict[str, List[Dict[str, Any]]] = {}    # paper_id → [{canonical_name, kind, related_fields, confidence}]
        self.llm_improvements: Dict[str, List[Dict[str, Any]]] = {}

    # ---------- public ----------
    def run(self, schema_csv_path: str, kb_json_path: str, llm_workers: int = 1,
            rebuild_graph_only: bool = False):
        kb_obj = load_json(kb_json_path)
        records = list(iter_kb_records(kb_obj))

        self._scan_local_registry(records)
        self._load_schema(schema_csv_path)
        self.store.commit()

        if not rebuild_graph_only:
            # facts 落入 SQLite（QA 专家打分读 paper_fact 表）；不再保留内存大列表（O2）
            self._ingest_papers_chunks_facts(records)
            self.store.commit()

            self._ingest_links(records)
            self.store.commit()

        # LLM 提取 Concept 是必须步骤
        if self.llm_extractor is None:
            print("[WARNING] llm_extractor not provided. "
                  "Concept nodes will be empty — KG quality will be very poor. "
                  "Please run with --llm-api-key to enable LLM extraction.")
        else:
            self._run_llm_extraction(records, max_workers=llm_workers)
            # 尾部增量落盘缓存（O3：抽取期间按阈值批量写，结束强制 flush 一次）
            if hasattr(self.llm_extractor, "flush_cache"):
                self.llm_extractor.flush_cache()
            self.store.commit()

        if rebuild_graph_only:
            print("[rebuild_graph_only] clearing old graph nodes/edges/postings ...")
            self.store.clear_graph()

        # 核心构图（新流程）
        self._build_concepts()          # 构建 Concept 节点 + FIELD_INSTANTIATES 边
        self.store.commit()
        self._build_paper_evidence_edges()   # PAPER_EVIDENCE 边
        self.store.commit()
        self._build_concept_cooccur_edges()  # CONCEPT_COOCCUR 边
        self.store.commit()
        self._build_concept_evolves_edges()  # CONCEPT_EVOLVES 边
        self.store.commit()

    # ---------- helpers ----------
    def _upsert_node(self, node_type: str, canonical_name: str, **kwargs) -> int:
        key = (node_type, canonical_name)
        if key in self.node_cache:
            return self.node_cache[key]
        node_id = self.store.upsert_graph_node(node_type=node_type, canonical_name=canonical_name, **kwargs)
        self.node_cache[key] = node_id
        return node_id

    def _upsert_edge(self, src: int, dst: int, rel: str, weight: float, directed: bool = True, **kwargs) -> int:
        return self.store.upsert_graph_edge(
            src_node_id=src,
            dst_node_id=dst,
            relation_type=rel,
            directed=directed,
            weight=weight,
            **kwargs,
        )

    # ---------- registry ----------
    def _scan_local_registry(self, records: List[Dict[str, Any]]):
        for item in records:
            meta = extract_paper_meta(item)
            paper_id = meta["paper_id"]
            self.paper_year[paper_id] = meta["year"]

            if meta["norm_doi"]:
                self.local_by_doi[meta["norm_doi"]] = paper_id
            if meta["norm_title"]:
                self.local_by_title[meta["norm_title"]].append(paper_id)
                # 建 token 倒排索引
                for tok in meta["norm_title"].split():
                    if len(tok) >= 3:  # 过滤超短词（of/a/in 等），降低候选集噪声
                        self.local_by_token[tok].add(meta["norm_title"])
    # Mapping from Chinese column names (actual CSV) to internal keys
    _SCHEMA_COL_MAP = {
        "字段名（英文）": "field_en",
        "字段名（中文）": "field_zh",
        "完整描述": "description",
        "提取提示": "extraction_hint",
        "层级": "level",
        "标签": "tag",
        "重点字段": "is_key",
        "聚类ID": "cluster",
        "聚类名称": "cluster_zh",
        "聚类名称（英文）": "cluster_en",
        "适用领域": "applicable_domain",
        "使用范围": "use_scope",
        # English fallback column names
        "field_en": "field_en",
        "english_name": "field_en",
        "field_zh": "field_zh",
        "chinese_name": "field_zh",
        "cluster": "cluster",
        "description": "description",
        "level": "level",
        "tag": "tag",
        "is_key": "is_key",
        "applicable_domain": "applicable_domain",
        "use_scope": "use_scope",
        "value_type": "value_type",
        "unit": "unit",
        "opt_direction": "opt_direction",
    }

    def _load_schema(self, schema_csv_path: str):
        df = pd.read_csv(schema_csv_path, encoding="utf-8-sig")
        # Normalize column names via mapping
        df = df.rename(columns={c: self._SCHEMA_COL_MAP[c] for c in df.columns if c in self._SCHEMA_COL_MAP})

        for _, row in df.iterrows():
            field_en = normalize_key(row.get("field_en", ""))
            if not field_en:
                continue

            raw_cluster = row.get("cluster", "")
            cluster_key = normalize_key(str(raw_cluster)) if raw_cluster and str(raw_cluster).strip() else "unknown_cluster"
            cluster_display_en = str(row.get("cluster_en", "")).strip() or cluster_key

            raw_is_key = row.get("is_key", False)
            is_key = raw_is_key in (True, 1, "是", "yes", "true", "True", "1")

            spec = {
                "field_en": field_en,
                "field_zh": row.get("field_zh"),
                "description": row.get("description", ""),
                "cluster": cluster_key,
                "level": row.get("level"),
                "tag": row.get("tag"),
                "is_key": is_key,
                "applicable_domain": row.get("applicable_domain"),
                "use_scope": row.get("use_scope"),
                "value_type": row.get("value_type"),
                "unit": row.get("unit"),
                "opt_direction": row.get("opt_direction"),
            }
            self.schema_specs[field_en] = spec

            cluster_id = self._upsert_node(
                "Cluster", cluster_key,
                display_name_en=cluster_display_en,
                attrs_json={"cluster_name": cluster_key, "cluster_en": cluster_display_en},
            )
            field_id = self._upsert_node(
                "SchemaField",
                field_en,
                display_name_zh=spec["field_zh"],
                attrs_json=spec,
                source="schema",
            )

            self.store.upsert_node_alias(field_id, field_en, field_en, alias_type="schema_en")
            if spec["field_zh"] and str(spec["field_zh"]).strip():
                zh = str(spec["field_zh"]).strip()
                self.store.upsert_node_alias(field_id, zh, normalize_text(zh), alias_type="schema_zh")

            self._upsert_edge(cluster_id, field_id, "HAS_FIELD", 1.0, directed=True)

            for chunk_type in self._infer_expected_chunks(field_en):
                chunk_id = self._upsert_node("ChunkType", chunk_type, source="schema")
                self._upsert_edge(field_id, chunk_id, "EXPECTED_IN", 1.0)

        self._create_chunk_flow()

    def _infer_expected_chunks(self, field_name: str) -> List[str]:
        f = field_name
        if "mechanism" in f:
            return ["physical_mechanism"]
        if "optimization" in f or "novelty" in f or "contribution" in f:
            return ["design_optimization_logic"]
        if "fabrication" in f or "process" in f:
            return ["fabrication_process"]
        if "influence" in f or "parameter" in f:
            return ["influence_analysis"]
        if "method" in f or "strategy" in f or "shape" in f or "model" in f or "symmetry" in f:
            return ["design_method"]
        return ["study_process_description"]

    def _create_chunk_flow(self):
        ordered = [
            "problem_context",
            "study_process_description",
            "design_method",
            "design_optimization_logic",
            "physical_mechanism",
            "influence_analysis",
        ]
        ids = [self._upsert_node("ChunkType", x, source="schema") for x in ordered]
        for a, b in zip(ids[:-1], ids[1:]):
            self._upsert_edge(a, b, "CHUNK_FLOW", 1.0)

        fp = self._upsert_node("ChunkType", "fabrication_process", source="schema")
        pm = self._upsert_node("ChunkType", "physical_mechanism", source="schema")
        ia = self._upsert_node("ChunkType", "influence_analysis", source="schema")
        self._upsert_edge(fp, pm, "CHUNK_FLOW", 0.8)
        self._upsert_edge(fp, ia, "CHUNK_FLOW", 0.8)

    # ---------- ingest ----------
    def _ingest_papers_chunks_facts(self, records: List[Dict[str, Any]]) -> List[FactObj]:
        fact_objects: List[FactObj] = []

        for idx_paper, item in enumerate(tqdm(records, desc="ingest_kb")):
            meta = extract_paper_meta(item)
            paper_id = meta["paper_id"]

            self.store.insert_paper({
                **meta,
                "journal": item.get("journal"),
                "authors_json": item.get("authors", []),
                "metadata_json": {
                    "citation_info_exists": bool(item.get("citation_info")),
                },
            })

            chunk_id_map = {}
            for idx, chunk_type in enumerate(CHUNK_TYPES):
                text = item.get(chunk_type)
                if not text or not str(text).strip():
                    continue
                chunk_id = f"{paper_id}::{chunk_type}"
                chunk_id_map[chunk_type] = chunk_id
                self.store.insert_chunk({
                    "chunk_id": chunk_id,
                    "paper_id": paper_id,
                    "chunk_type": chunk_type,
                    "chunk_text": str(text),
                    "chunk_order": idx,
                    "attrs_json": {},
                })

            extracted = item.get("extracted_data", {}) or {}
            for raw_field, raw_value in extracted.items():
                field_name = normalize_key(raw_field)
                if not field_name:
                    continue

                spec = self.schema_specs.get(field_name, {})
                field_node = self.store.get_graph_node("SchemaField", field_name)
                field_node_id = field_node["node_id"] if field_node else None

                chunk_type = choose_source_chunk(field_name)
                chunk_id = chunk_id_map.get(chunk_type)

                values = raw_value if isinstance(raw_value, list) else [raw_value]
                for one_value in values:
                    row = self._normalize_fact_row(
                        paper_id=paper_id,
                        chunk_id=chunk_id,
                        field_name=field_name,
                        raw_value=one_value,
                        field_node_id=field_node_id,
                        spec=spec,
                    )

                    fact_id = self.store.insert_fact(row)
                    fobj = FactObj(
                        fact_id=fact_id,
                        paper_id=paper_id,
                        chunk_id=chunk_id,
                        field_name=field_name,
                        value_type=row["value_type"],
                        value_raw=row["value_raw"],
                        value_norm=row["value_norm"],
                        num_value=row["num_value"],
                        range_low=row["range_low"],
                        range_high=row["range_high"],
                        unit=row["unit"],
                    )
                    fact_objects.append(fobj)

                    if field_node_id and chunk_id:
                        self.store.upsert_node_chunk_posting(
                            node_id=field_node_id,
                            chunk_id=chunk_id,
                            paper_id=paper_id,
                            support_score=1.0,
                            support_role="direct_fact",
                        )
                        self.paper_fields[paper_id].add(field_node_id)

                    metric_v = row["num_value"]
                    if metric_v is None and row["range_low"] is not None:
                        metric_v = safe_mid(row["range_low"], row["range_high"])
                    if metric_v is not None:
                        self.paper_metric_values[paper_id][field_name].append(float(metric_v))

            if (idx_paper + 1) % 500 == 0:
                self.store.commit()

        return fact_objects

    def _normalize_fact_row(
        self,
        paper_id: str,
        chunk_id: Optional[str],
        field_name: str,
        raw_value: Any,
        field_node_id: Optional[int],
        spec: Dict[str, Any],
    ) -> Dict[str, Any]:
        value_type = spec.get("value_type") or infer_value_type(raw_value)

        row = {
            "paper_id": paper_id,
            "chunk_id": chunk_id,
            "field_name": field_name,
            "field_node_id": field_node_id,
            "value_type": value_type,
            "value_raw": str(raw_value),
            "value_norm": None,
            "num_value": None,
            "range_low": None,
            "range_high": None,
            "unit": spec.get("unit"),
            "sign_label": None,
            "prototype_node_id": None,
            "bucket_node_id": None,
            "confidence": 1.0,
            "attrs_json": {},
        }

        if isinstance(raw_value, dict) and raw_value.get("value_num") is not None:
            v, u = parse_numeric(raw_value, spec.get("unit"), field_name)
            row["value_type"] = "numeric"
            row["value_raw"] = str(raw_value.get("raw") or raw_value.get("value_num"))
            row["num_value"] = v
            row["unit"] = u
            row["value_norm"] = str(v) if v is not None else normalize_text(raw_value.get("raw"))
            return row

        if value_type == "numeric":
            v, u = parse_numeric(raw_value, spec.get("unit"), field_name)
            row["num_value"] = v
            row["unit"] = u
            row["value_norm"] = str(v) if v is not None else normalize_text(raw_value)

        elif value_type == "range":
            low, high, u = parse_range(raw_value, spec.get("unit"), field_name)
            row["range_low"] = low
            row["range_high"] = high
            row["unit"] = u
            row["value_norm"] = f"[{low},{high}]"

        elif value_type == "categorical":
            row["value_norm"] = normalize_text(raw_value)

        else:
            row["value_norm"] = normalize_text(raw_value)

        return row

    def _ingest_links(self, records: List[Dict[str, Any]]):
        """批量导入论文引用关系。

        改进：先建 DOI 和标题的完整倒排索引（O(1) 精确查找），
        只有在精确匹配失败时才用 fuzzy（大幅降低单条处理时间）。
        """
        # 一次性构建精确索引（O(N) 预处理）
        doi_index: Dict[str, str] = {}      # norm_doi → paper_id
        title_index: Dict[str, str] = {}    # norm_title → paper_id（唯一时才存）
        for pid, nd in self.local_by_doi.items():
            doi_index[nd] = pid
        for norm_t, pids in self.local_by_title.items():
            if len(pids) == 1:
                title_index[norm_t] = pids[0]

        inserted: set = set()
        for idx_link, item in enumerate(tqdm(records, desc="ingest_links")):
            current_meta = extract_paper_meta(item)
            current_pid = current_meta["paper_id"]

            links = extract_citation_links(item)
            for link in links:
                if link["relation_kind"] != "reference":
                    continue

                # 快速精确匹配
                dst_pid, conf, method = self._resolve_local_paper_fast(
                    title=link.get("dst_title"),
                    doi=link.get("dst_doi"),
                    year=link.get("dst_year"),
                    doi_index=doi_index,
                    title_index=title_index,
                )

                dedup_key = (
                    "reference",
                    current_pid,
                    dst_pid or normalize_doi(link.get("dst_doi")) or normalize_title(link.get("dst_title")),
                )
                if dedup_key in inserted:
                    continue
                inserted.add(dedup_key)

                self.store.insert_paper_link({
                    "relation_kind": "reference",
                    "provider": link.get("provider"),
                    "src_paper_id": current_pid,
                    "src_title": current_meta["paper_title"],
                    "src_norm_title": current_meta["norm_title"],
                    "src_doi": current_meta["doi"],
                    "src_norm_doi": current_meta["norm_doi"],
                    "src_year": current_meta["year"],
                    "dst_paper_id": dst_pid,
                    "dst_title": link.get("dst_title"),
                    "dst_norm_title": normalize_title(link.get("dst_title")),
                    "dst_doi": link.get("dst_doi"),
                    "dst_norm_doi": normalize_doi(link.get("dst_doi")),
                    "dst_year": link.get("dst_year"),
                    "match_confidence": conf,
                    "match_method": method,
                    "attrs_json": {},
                })

            if (idx_link + 1) % 1000 == 0:
                self.store.commit()

    def _resolve_local_paper_fast(
        self,
        title: Optional[str],
        doi: Optional[str],
        year: Optional[int],
        doi_index: Dict[str, str],
        title_index: Dict[str, str],
    ) -> Tuple[Optional[str], float, str]:
        """快速论文匹配：优先精确索引，最后才 fuzzy。"""
        norm_doi = normalize_doi(doi)
        norm_title = normalize_title(title)

        # 1) DOI 精确（O(1)）
        if norm_doi and norm_doi in doi_index:
            return doi_index[norm_doi], 0.99, "doi_exact"

        # 2) 标题精确（O(1)）
        if norm_title and norm_title in title_index:
            return title_index[norm_title], 0.96, "title_exact"

        # 3) token 倒排 + fuzzy（仅在精确失败时）
        if norm_title:
            query_tokens = [t for t in norm_title.split() if len(t) >= 3]
            if query_tokens:
                cand_counter: Counter = Counter()
                for tok in query_tokens:
                    for cand_title in self.local_by_token.get(tok, set()):
                        cand_counter[cand_title] += 1
                min_shared = max(1, min(2, len(query_tokens) - 1))
                candidates = [t for t, cnt in cand_counter.items() if cnt >= min_shared]

                best_pid, best_score = None, 0.0
                for local_title in candidates:
                    score = fuzz.token_sort_ratio(norm_title, local_title)
                    if score < 93:
                        continue
                    for pid in self.local_by_title[local_title]:
                        py = self.paper_year.get(pid)
                        final = score / 100.0
                        if year is not None and py is not None and abs(year - py) <= 1:
                            final += 0.03
                        if final > best_score:
                            best_score, best_pid = final, pid
                if best_pid:
                    return best_pid, min(0.95, best_score), "title_fuzzy"

        return None, 0.0, "unmatched"

    # ──────────────────────────────────────────────────────────────────────
    # 新构图方法（2 节点 + 4 边 设计）
    # ──────────────────────────────────────────────────────────────────────

    def _build_concepts(self):
        """从 LLM 提取结果构建 Concept 节点和 FIELD_INSTANTIATES 边。

        双层 Concept 模型：
        - LLM 输出每个 item: atoms (1-3 短术语) + claim (描述句)
        - atoms 各自建/合并为 Concept 节点（跨论文共享，用于多跳推理）
        - claim 写入 paper_concept.claim（每篇论文的具体上下文，用于精准检索/答案）

        核心步骤：
        1. 把每个 LLM item 拆成 N 个候选（每个 atom 一个），共享同一 claim
        2. 同一 (paper, atom) 出现多次时保留 confidence 最高的 claim
        3. 用 embedding cosine 去重 atoms（≥0.88 合并）
        4. 创建 Concept 节点 + alias + paper_concept(带 claim) + FIELD_INSTANTIATES
        """
        if not self.llm_concepts:
            print("[build_concepts] no llm_concepts extracted, skipping.")
            return

        # Step 1: 收集候选，每个 atom 一个候选项；同 (paper, atom) 取 confidence 最高
        best_per_pa: Dict[tuple, Dict] = {}
        compat_legacy = 0  # 旧 schema（canonical_name）兼容计数
        for paper_id, concepts in self.llm_concepts.items():
            for c in concepts:
                atoms = c.get("atoms") or []
                claim = (c.get("claim") or "").strip()
                # 兼容旧 schema：没有 atoms 时把 canonical_name 当单 atom
                if not atoms:
                    legacy = (c.get("canonical_name") or "").strip()
                    if legacy:
                        atoms = [legacy]
                        if not claim:
                            claim = legacy
                        compat_legacy += 1
                if not isinstance(atoms, list):
                    continue

                kind = c.get("kind", "physical_mechanism")
                related_fields = c.get("related_fields") or []
                confidence = float(c.get("confidence") or 0.8)

                for atom in atoms:
                    if not isinstance(atom, str):
                        continue
                    atom_clean = atom.strip()
                    if not atom_clean:
                        continue
                    atom_norm = normalize_text(atom_clean)
                    if not atom_norm:
                        continue
                    key = (paper_id, atom_norm)
                    cand = {
                        "paper_id": paper_id,
                        "canonical_name": atom_clean,
                        "claim": claim,
                        "kind": kind,
                        "related_fields": list(related_fields),
                        "confidence": confidence,
                    }
                    prev = best_per_pa.get(key)
                    if prev is None or confidence > prev["confidence"]:
                        best_per_pa[key] = cand

        all_candidates = list(best_per_pa.values())
        if compat_legacy:
            print(f"[build_concepts] {compat_legacy} legacy items used canonical_name (old cache?)")
        if not all_candidates:
            return
        print(f"[build_concepts] collected {len(all_candidates)} (paper, atom) candidates "
              f"from {len(self.llm_concepts)} papers")

        # Step 2: embedding 去重（cosine ≥ 0.88 + token_sort_ratio ≥ 75 合并）
        canonical_groups = self._cluster_concepts_by_embedding(all_candidates)

        # Step 3: 创建 Concept 节点
        for group in canonical_groups:
            rep = group["representative"]   # 代表名称（出现频次最高）
            members = group["members"]

            concept_id = self._upsert_node(
                "Concept",
                rep,
                subtype=group["kind"],
                source="llm",
                attrs_json={"concept_kind": group["kind"]},
            )
            # 注册别名
            self.store.upsert_node_alias(concept_id, rep, normalize_text(rep), alias_type="concept")
            for m in members:
                alias = normalize_text(m["canonical_name"])
                if alias and alias != normalize_text(rep):
                    self.store.upsert_node_alias(concept_id, m["canonical_name"], alias, alias_type="concept_variant")

            # 跟踪 paper → concept 映射（用于后续 PAPER_EVIDENCE 边 + COOCCUR/EVOLVES）
            # 同 paper 内同一 concept 可能来自多个 atom 来源，按 best_per_pa 已去重
            for m in members:
                self.paper_prototypes[m["paper_id"]].add(concept_id)

                py = self.paper_year.get(m["paper_id"])
                if py is not None:
                    self.proto_years[concept_id].append(py)

                # 记录到 paper_concept 表，带 claim（保留语义上下文）
                chunk_types_str = ",".join({"physical_mechanism", "design_method", "design_optimization_logic"})
                self.store.upsert_paper_concept(
                    paper_id=m["paper_id"],
                    concept_id=concept_id,
                    confidence=m["confidence"],
                    chunk_types=chunk_types_str,
                    claim=m.get("claim", ""),
                )

            # Step 4: FIELD_INSTANTIATES 边（所有 related_fields 都建边）
            field_counter: Counter = Counter()
            for m in members:
                for fn in m["related_fields"]:
                    if fn:
                        field_counter[fn] += 1

            for field_name, cnt in field_counter.items():
                field_node = self.store.get_graph_node("SchemaField", field_name)
                if not field_node:
                    continue
                w = log_squash(cnt)
                self._upsert_edge(
                    field_node["node_id"],
                    concept_id,
                    "FIELD_INSTANTIATES",
                    weight=max(0.3, w),   # 最小 0.3 保证 LLM 语义边有基础权重
                    corpus_support=w,
                    support_paper_count=cnt,
                )

    def _cluster_concepts_by_embedding(self, candidates: List[Dict]) -> List[Dict]:
        """用 embedding cosine 相似度对 Concept 候选去重分组。

        Returns: list of {representative, kind, members}
        """
        import numpy as np

        names = [c["canonical_name"] for c in candidates]
        norm_names = [normalize_text(n) for n in names]

        # 尝试 embedding 去重
        vectors = None
        try:
            from kb_mvp.src.embedding import get_client as get_embed_client
            embed_client = get_embed_client()
            vecs = embed_client.embed(names)  # shape (N, 1024)
            # 归一化
            norms = np.linalg.norm(vecs, axis=1, keepdims=True)
            norms = np.where(norms == 0, 1, norms)
            vectors = vecs / norms
        except Exception as e:
            print(f"[build_concepts] embedding unavailable ({e}), falling back to string dedup")

        # Union-Find 分组
        n = len(candidates)
        parent = list(range(n))

        def find(x):
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x

        def union(x, y):
            px, py = find(x), find(y)
            if px != py:
                parent[px] = py

        EMBED_THRESH = 0.88
        STR_THRESH = 75

        if vectors is not None:
            import numpy as _np
            # 分块计算 cosine，每块 1024 行，仅取上三角候选（避免 N×N 全矩阵 OOM）
            BLOCK = 1024
            for i_start in tqdm(range(0, n, BLOCK), desc="embed_dedup"):
                i_end = min(i_start + BLOCK, n)
                block = vectors[i_start:i_end]       # (B, D)
                sim_block = block @ vectors.T         # (B, N)
                rows, cols = _np.where(sim_block >= EMBED_THRESH)
                for bi, j in zip(rows, cols):
                    i = i_start + bi
                    if j <= i:
                        continue
                    if fuzz.token_sort_ratio(norm_names[i], norm_names[j]) >= STR_THRESH:
                        union(i, j)
        else:
            # embedding 不可用时：只做精确归一化名称匹配（O(N)），不做 O(N²) fuzzy
            # 原因：8万+概念做 fuzzy 两两比对需要几十小时，不可接受
            # 效果：相同名称合并，略微不同的变体保留为独立节点（可接受的损失）
            exact_groups: Dict[str, int] = {}  # norm_name → 第一个出现的 index
            for i, name in enumerate(norm_names):
                if name in exact_groups:
                    union(i, exact_groups[name])
                else:
                    exact_groups[name] = i

        # 按 root 收集分组
        groups_map: Dict[int, List[int]] = defaultdict(list)
        for i in range(n):
            groups_map[find(i)].append(i)

        result = []
        for root, idxs in groups_map.items():
            members = [candidates[i] for i in idxs]
            # 选代表：出现次数最多的名称
            name_counter = Counter(normalize_text(m["canonical_name"]) for m in members)
            rep_norm = max(name_counter, key=lambda x: (name_counter[x], len(x)))
            rep_orig = next((m["canonical_name"] for m in members if normalize_text(m["canonical_name"]) == rep_norm), members[0]["canonical_name"])
            # kind：多数投票
            kind_counter = Counter(m["kind"] for m in members)
            dominant_kind = kind_counter.most_common(1)[0][0]

            # 存储 embedding 向量
            if vectors is not None:
                # 用组内平均向量代表该 concept
                avg_vec = vectors[idxs].mean(axis=0)
                avg_norm = np.linalg.norm(avg_vec)
                if avg_norm > 0:
                    avg_vec = avg_vec / avg_norm
                concept_id_placeholder = id(rep_orig)  # 临时 key，在节点创建后更新
                self._pending_concept_vectors = getattr(self, "_pending_concept_vectors", {})
                self._pending_concept_vectors[rep_orig] = avg_vec.astype(np.float32).tobytes()

            result.append({
                "representative": rep_orig,
                "kind": dominant_kind,
                "members": members,
            })

        return result

    def _build_paper_evidence_edges(self):
        """将 paper_concept 表桥接到 node_chunk_posting，让 qa_engine 能通过 Concept 节点找到 chunk。

        同时存储 embedding 向量。
        注：Paper 节点没有图 node_id，所以 PAPER_EVIDENCE 边改为通过 node_chunk_posting 实现：
        Concept → chunk（属于该论文的 physical_mechanism/design_method/design_optimization_logic）
        """
        pending_vecs = getattr(self, "_pending_concept_vectors", {})

        TARGET_CHUNK_TYPES = {
            "physical_mechanism",
            "design_method",
            "design_optimization_logic",
            "study_process_description",
        }

        for concept_node in tqdm(self.store.list_nodes(), desc="build_postings"):
            if concept_node["node_type"] != "Concept":
                continue
            concept_id = int(concept_node["node_id"])
            concept_name = concept_node["canonical_name"]

            # 存储 embedding
            vec_bytes = pending_vecs.get(concept_name)
            if vec_bytes:
                self.store.upsert_concept_embedding(concept_id, vec_bytes)

            # 从 paper_concept 表取关联论文
            papers = self.store.get_papers_by_concept(concept_id)
            for p in papers:
                paper_id = p["paper_id"]
                confidence = float(p["confidence"])

                # 把该论文的核心 chunk 写入 node_chunk_posting
                # 这样 qa_engine 的 get_posting_chunk_ids 就能通过 Concept 找到 chunk
                chunks = self.store.list_chunks_by_paper(paper_id)
                for chunk in chunks:
                    if chunk.get("chunk_type") not in TARGET_CHUNK_TYPES:
                        continue
                    self.store.upsert_node_chunk_posting(
                        node_id=concept_id,
                        chunk_id=chunk["chunk_id"],
                        paper_id=paper_id,
                        support_score=confidence,
                        support_role="concept_evidence",
                    )

        self.store.commit()

    def _build_concept_cooccur_edges(self):
        """创建 CONCEPT_COOCCUR 边：同一篇论文中共现的 Concept 对（无向）。

        最少 3 篇论文共现才建边（避免噪声）。
        """
        pair_counter: Counter = Counter()
        for paper_id, concept_ids in self.paper_prototypes.items():
            cs = sorted(concept_ids)
            for i in range(len(cs)):
                for j in range(i + 1, len(cs)):
                    pair_counter[(cs[i], cs[j])] += 1

        for (a, b), cnt in pair_counter.items():
            if cnt < 2:   # 至少 2 篇共现
                continue
            w = log_squash(cnt)
            self._upsert_edge(a, b, "CONCEPT_COOCCUR", w, directed=False,
                              corpus_support=w, support_paper_count=cnt)

    def _build_concept_evolves_edges(self):
        """创建 CONCEPT_EVOLVES 边：Concept_旧 → Concept_新（有向）。

        权重 = 0.5×citation_support + 0.3×temporal_score + 0.2×perf_score
        最少 3 篇论文对支撑。
        """
        flow_weight: Dict[tuple, float] = defaultdict(float)
        flow_count: Dict[tuple, int] = defaultdict(int)

        for row in self.store.list_resolved_links(min_confidence=0.80):
            src_pid = row["src_paper_id"]   # 引用者（更新论文）
            dst_pid = row["dst_paper_id"]   # 被引者（更老论文）
            conf = float(row.get("match_confidence") or 0.8)

            src_protos = self.paper_prototypes.get(src_pid, set())
            dst_protos = self.paper_prototypes.get(dst_pid, set())
            if not src_protos or not dst_protos:
                continue

            sy = self.paper_year.get(src_pid)
            dy = self.paper_year.get(dst_pid)
            temporal_bonus = 1.0 if (sy and dy and sy >= dy) else 0.6

            for old_concept in dst_protos:
                for new_concept in src_protos:
                    if old_concept == new_concept:
                        continue
                    key = (old_concept, new_concept)
                    flow_weight[key] += conf * temporal_bonus
                    flow_count[key] += 1

        for (old_c, new_c), total_w in flow_weight.items():
            cnt = flow_count[(old_c, new_c)]
            if cnt < 2:
                continue

            years_old = self.proto_years.get(old_c, [])
            years_new = self.proto_years.get(new_c, [])
            old_year = median(years_old) if years_old else None
            new_year = median(years_new) if years_new else None
            temporal = 1.0 if (old_year and new_year and old_year <= new_year) else 0.55

            citation = min(1.0, total_w / max(1.0, cnt))
            weight = 0.5 * citation + 0.3 * temporal + 0.2 * 0.5  # perf_score 默认 0.5

            self._upsert_edge(
                old_c, new_c, "CONCEPT_EVOLVES", weight,
                directed=True,
                citation_score=citation,
                temporal_score=temporal,
                support_paper_count=cnt,
            )
    def _run_llm_extraction(self, records: List[Dict[str, Any]],
                             max_workers: int = 4):
        """Call LLM once per paper to extract Concept + improvement claims.
        Results populate self.llm_concepts / self.llm_improvements.

        - 4 并发线程（ThreadPoolExecutor），约 4x 加速
        - LLMExtractor 内置 llm_cache.json，断点重建时已缓存的论文直接跳过
        """
        import threading
        from concurrent.futures import ThreadPoolExecutor, as_completed

        schema_rows = self.store.list_schema_fields()
        schema_names = [r["canonical_name"] for r in schema_rows]
        if hasattr(self.llm_extractor, "allowed_fields"):
            self.llm_extractor.allowed_fields = set(schema_names)

        target_types = ["physical_mechanism", "design_method", "design_optimization_logic"]
        lock = threading.Lock()

        def process_one(item):
            meta = extract_paper_meta(item)
            paper_id = meta["paper_id"]
            title = meta.get("paper_title") or paper_id
            chunks_by_type = {t: str(item.get(t) or "") for t in target_types}
            result = self.llm_extractor.extract_paper(paper_id, title, chunks_by_type)
            return paper_id, result

        futures = []
        with ThreadPoolExecutor(max_workers=max_workers) as pool:
            for item in records:
                futures.append(pool.submit(process_one, item))

            for fut in tqdm(as_completed(futures), total=len(futures), desc="llm_extract"):
                try:
                    paper_id, result = fut.result()
                    with lock:
                        self.llm_concepts[paper_id] = (
                            result.get("concepts") or result.get("prototypes") or []
                        )
                        self.llm_improvements[paper_id] = result.get("improvements_over", [])
                except Exception as e:
                    print(f"[llm_extract] worker error: {e}")
