import argparse
import json
import sys

from .config import DEFAULT_DB_PATH, DEFAULT_RETRIEVER_PATH
from .qa_engine import QAEngine
from .retriever import Retriever
from .storage import SQLiteStore


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--db", default=str(DEFAULT_DB_PATH))
    parser.add_argument("--retriever", default=str(DEFAULT_RETRIEVER_PATH))
    parser.add_argument("--query", required=True)
    args = parser.parse_args()

    store = SQLiteStore(args.db)
    retriever = Retriever.load(args.retriever)
    engine = QAEngine(store, retriever)
    result = engine.answer(args.query)
    out = json.dumps(result, ensure_ascii=False, indent=2)
    sys.stdout.buffer.write((out + "\n").encode("utf-8"))


if __name__ == "__main__":
    main()
