from __future__ import annotations

import hashlib
import json
import threading
from pathlib import Path
from typing import Dict, List, Optional, Set

from .llm_client import LLMClient, LLMClientError

SYSTEM_PROMPT = """You are an expert annotator extracting structured concepts from scientific / engineering papers.

Your task: extract 4-8 "Concept items" from a paper's text. Each item has TWO LAYERS:
  • atoms : 1-3 SHORT canonical technical terms (the searchable index keys)
  • claim : ONE descriptive sentence stating what THIS paper does with these atoms

The atoms are used to build a shared cross-paper concept graph (different papers describing the
same idea must produce the same atom names). The claim preserves this paper's specific context.

────────────────────────────────────────────────────────────────────────
ATOMS — short canonical terms (CRITICAL: must match across papers)
────────────────────────────────────────────────────────────────────────
Each atom must be:
  • 1-4 words (prefer 2-3), in the language the field conventionally uses (usually English)
  • A noun phrase naming a structure / mechanism / material / method / property / phenomenon
  • The exact wording a domain expert would type into a search box
  • Lowercase, except established acronyms

GOOD atoms (illustrative — use YOUR domain's equivalents, NOT these literally):
  a canonical method name, a named mechanism or effect, a specific material or reagent,
  a characteristic structure, a measurable property. Each is a precise multi-word noun phrase.

BAD atoms (NEVER use as atoms, in ANY domain):
  Long phrases packing several ideas into one string
    → split into separate atoms
  Sentences or clauses
  Generic single words ("design", "optimization", "method", "system", "analysis")
  Tool / software names
  Bare numbers or pure geometry with no concept attached

────────────────────────────────────────────────────────────────────────
CLAIM — one descriptive sentence (this paper's specific context)
────────────────────────────────────────────────────────────────────────
The claim must:
  • 8-20 words
  • Describe what THIS paper does with these atoms (mechanism/method + purpose/scenario)
  • Be readable by another expert as a one-line summary

Shape (atoms → claim), domain-agnostic illustration:
  atoms: ["<canonical method>", "<key mechanism>", "<target application>"]
  claim: "<what the paper does with these atoms, as a single specific sentence>"

────────────────────────────────────────────────────────────────────────
RULES
────────────────────────────────────────────────────────────────────────
- Always prefer the canonical term the field actually uses over a descriptive paraphrase
- Never put scenarios or numbers in atoms — keep atoms abstract and reusable
- atoms[] must be DIFFERENT from each other within one item
- If an idea is multi-faceted, split into multiple items each with its own atoms+claim

Also extract improvement claims: cases where the paper explicitly claims to improve upon prior work.
If no such claim exists, return empty list.
"""

USER_TEMPLATE = """Paper title: {title}

[physical_mechanism]
{physical_mechanism}

[design_method]
{design_method}

[design_optimization_logic]
{design_optimization_logic}

Allowed SchemaField names for related_fields (pick at most 3):
{allowed_fields}

Output strictly as JSON (no markdown fences):
{{
  "concepts": [
    {{
      "atoms": ["term1", "term2"],
      "claim": "8-20 word descriptive sentence stating what this paper does with these atoms",
      "kind": "physical_mechanism | design_method",
      "related_fields": ["field_name_from_allowed_list"],
      "confidence": 0.8
    }}
  ],
  "improvements_over": [
    {{
      "prior_concept": "short term naming the prior idea being improved",
      "improvement_brief": "what this paper improves (one sentence)"
    }}
  ]
}}

If a section is empty, concepts / improvements_over may be empty arrays.
"""


class LLMExtractor:
    """Uses LLM to extract structured Concept mentions and improvement claims per paper.

    Thread-safe: multiple workers can call extract_paper() concurrently.
    Results are cached on disk keyed by (paper_id, chunk_text_hash) so reruns are free.
    """

    def __init__(
        self,
        client: LLMClient,
        schema_fields: List[str],
        cache_path: Optional[Path] = None,
        domain_instruction: str = "",
        base_system_prompt: Optional[str] = None,
        cache_flush_every: int = 50,
    ):
        self.client = client
        self.allowed_fields: Set[str] = set(schema_fields)
        self.cache_path = Path(cache_path) if cache_path else None
        # 领域上下文前缀（来自 domain_prefer 文件）；为空时 system prompt 保持纯通用
        self.domain_instruction = (domain_instruction or "").strip()
        # 抽取 system 基底：来自 prompts 配置（concept_extraction.system）；缺省 → 内置中立 SYSTEM_PROMPT
        self.base_system_prompt = (base_system_prompt or "").strip() or SYSTEM_PROMPT
        self._cache: Dict[str, Dict] = self._load_cache()
        self._cache_lock = threading.Lock()
        # O3: 不再每篇都全量重写磁盘；累计 cache_flush_every 次未落盘的写入后再 flush
        self._cache_flush_every = max(1, cache_flush_every)
        self._dirty_since_flush = 0

    @property
    def system_prompt(self) -> str:
        """领域上下文 + 抽取指令基底（配置注入或内置中立）。"""
        if self.domain_instruction:
            return f"{self.domain_instruction}\n\n{self.base_system_prompt}"
        return self.base_system_prompt

    def _load_cache(self) -> Dict[str, Dict]:
        if not self.cache_path or not self.cache_path.exists():
            return {}
        try:
            return json.loads(self.cache_path.read_text(encoding="utf-8"))
        except Exception:
            return {}

    def _save_cache(self, force: bool = False):
        """落盘缓存。force=True 立即写；否则累计到阈值才写（O3 降低写盘频次）。"""
        if not self.cache_path:
            return
        with self._cache_lock:
            self._dirty_since_flush += 1
            if not force and self._dirty_since_flush < self._cache_flush_every:
                return
            self._dirty_since_flush = 0
            self.cache_path.parent.mkdir(parents=True, exist_ok=True)
            self.cache_path.write_text(
                json.dumps(self._cache, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )

    def flush_cache(self):
        """对外暴露：抽取全部结束后调用一次，确保尾部增量落盘。"""
        self._save_cache(force=True)

    @staticmethod
    def _make_cache_key(paper_id: str, chunks_by_type: Dict[str, str]) -> str:
        combined = paper_id + "|" + json.dumps(chunks_by_type, sort_keys=True, ensure_ascii=False)
        return hashlib.sha256(combined.encode("utf-8")).hexdigest()

    def extract_paper(
        self,
        paper_id: str,
        title: str,
        chunks_by_type: Dict[str, str],
    ) -> Dict:
        """Extract concepts + improvements for one paper. Thread-safe."""
        cache_key = self._make_cache_key(paper_id, chunks_by_type)
        with self._cache_lock:
            if cache_key in self._cache:
                return self._cache[cache_key]

        combined_text = " ".join(chunks_by_type.values()).strip()
        if not combined_text:
            empty = {"concepts": [], "improvements_over": []}
            with self._cache_lock:
                self._cache[cache_key] = empty
            return empty

        user_prompt = USER_TEMPLATE.format(
            title=title or paper_id,
            physical_mechanism=(chunks_by_type.get("physical_mechanism") or "(none)")[:3000],
            design_method=(chunks_by_type.get("design_method") or "(none)")[:3000],
            design_optimization_logic=(chunks_by_type.get("design_optimization_logic") or "(none)")[:3000],
            allowed_fields=", ".join(sorted(self.allowed_fields)),
        )

        try:
            raw = self.client.chat_json(self.system_prompt, user_prompt)
        except LLMClientError as e:
            print(f"[llm_extract] paper={paper_id} failed: {e}")
            empty = {"concepts": [], "improvements_over": []}
            with self._cache_lock:
                self._cache[cache_key] = empty
            self._save_cache()
            return empty

        cleaned = self._validate(raw)
        with self._cache_lock:
            self._cache[cache_key] = cleaned
        self._save_cache()
        return cleaned

    def _validate(self, raw: Dict) -> Dict:
        """Sanity-check LLM output. Output schema:
            {"concepts": [{"atoms": [...], "claim": "...", "kind": ..., "related_fields": [...], "confidence": ...}],
             "improvements_over": [...]}
        """
        out = {"concepts": [], "improvements_over": []}

        # Support both new schema ("concepts" with "atoms"+"claim") and old ("canonical_name").
        items = raw.get("concepts") or raw.get("prototypes") or []
        for p in items:
            if not isinstance(p, dict):
                continue

            # ---- atoms 校验：1-3 个，每个 1-4 词且 ≥3 字符 ----
            atoms_raw = p.get("atoms")
            # backward compat: old "canonical_name" treated as single-atom item
            if not atoms_raw:
                old_name = (p.get("canonical_name") or "").strip()
                atoms_raw = [old_name] if old_name else []
            if not isinstance(atoms_raw, list):
                continue

            atoms_clean: List[str] = []
            seen: Set[str] = set()
            for a in atoms_raw:
                if not isinstance(a, str):
                    continue
                a_norm = a.strip().lower()
                if not a_norm or a_norm in seen:
                    continue
                n_tok = len(a_norm.split())
                if n_tok < 1 or n_tok > 4:
                    continue
                if len(a_norm) < 3:
                    continue
                # 单字必须 ≥4 字符或含数字（防"a"/"of"）
                if n_tok == 1 and not (any(ch.isdigit() for ch in a_norm) or len(a_norm) >= 4):
                    continue
                atoms_clean.append(a_norm)
                seen.add(a_norm)
                if len(atoms_clean) >= 3:
                    break
            if not atoms_clean:
                continue

            # ---- claim 校验：8-20 词的描述句 ----
            claim = (p.get("claim") or "").strip()
            if not claim:
                # backward compat: 没有 claim 时把 atoms 拼起来当 claim
                claim = " ".join(atoms_clean)
            n_tok_claim = len(claim.split())
            if n_tok_claim < 4 or n_tok_claim > 30:
                # 容忍宽松一点，超出区间但非空的截断/保留
                if n_tok_claim > 30:
                    claim = " ".join(claim.split()[:30])

            kind = p.get("kind")
            if kind not in {"physical_mechanism", "design_method"}:
                kind = "physical_mechanism"
            fields = p.get("related_fields") or []
            if not isinstance(fields, list):
                fields = []
            fields = [f for f in fields if isinstance(f, str) and f in self.allowed_fields][:3]
            confidence = float(p.get("confidence") or 0.8)
            confidence = max(0.5, min(1.0, confidence))
            out["concepts"].append({
                "atoms": atoms_clean,
                "claim": claim,
                "kind": kind,
                "related_fields": fields,
                "confidence": confidence,
            })

        for imp in (raw.get("improvements_over") or []):
            if not isinstance(imp, dict):
                continue
            prior = (imp.get("prior_concept") or "").strip()
            brief = (imp.get("improvement_brief") or "").strip()
            if not prior:
                continue
            out["improvements_over"].append({
                "prior_concept": prior[:300],
                "improvement_brief": brief[:300],
            })

        return out
