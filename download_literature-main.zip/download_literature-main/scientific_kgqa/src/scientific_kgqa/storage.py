from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


class SQLiteStore:
    def __init__(self, db_path: str | Path):
        self.db_path = str(db_path)
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        # WAL mode + relaxed sync: safe for single-writer batch builds,
        # reduces fsync overhead from per-INSERT commit to near zero.
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA synchronous=NORMAL")
        self.conn.execute("PRAGMA cache_size=-65536")   # 64 MB page cache
        self.conn.execute("PRAGMA temp_store=MEMORY")
        self.create_tables()

    def commit(self) -> None:
        self.conn.commit()

    def close(self):
        self.conn.close()

    def reset(self):
        cur = self.conn.cursor()
        cur.executescript("""
        DROP TABLE IF EXISTS edge_chunk_evidence;
        DROP TABLE IF EXISTS node_chunk_posting;
        DROP TABLE IF EXISTS paper_concept;
        DROP TABLE IF EXISTS concept_embedding;
        DROP TABLE IF EXISTS paper_fact;
        DROP TABLE IF EXISTS paper_chunk;
        DROP TABLE IF EXISTS paper_link;
        DROP TABLE IF EXISTS paper;
        DROP TABLE IF EXISTS graph_edge;
        DROP TABLE IF EXISTS node_alias;
        DROP TABLE IF EXISTS graph_node;
        """)
        self.conn.commit()
        self.create_tables()

    def clear_graph(self):
        """仅清空图结构（节点/边/posting/concept），保留 paper/chunk/fact/link。"""
        cur = self.conn.cursor()
        cur.executescript("""
        DELETE FROM node_chunk_posting;
        DELETE FROM paper_concept;
        DELETE FROM concept_embedding;
        DELETE FROM graph_edge;
        DELETE FROM node_alias;
        DELETE FROM graph_node;
        """)
        self.conn.commit()

    def _json(self, obj: Any) -> str:
        return json.dumps(obj or {}, ensure_ascii=False)

    def create_tables(self):
        cur = self.conn.cursor()
        cur.executescript("""
        CREATE TABLE IF NOT EXISTS graph_node (
            node_id INTEGER PRIMARY KEY AUTOINCREMENT,
            node_type TEXT NOT NULL,
            canonical_name TEXT NOT NULL,
            display_name_zh TEXT,
            display_name_en TEXT,
            subtype TEXT,
            source TEXT,
            online_walk INTEGER DEFAULT 1,
            attrs_json TEXT DEFAULT '{}',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(node_type, canonical_name)
        );

        CREATE TABLE IF NOT EXISTS node_alias (
            alias_id INTEGER PRIMARY KEY AUTOINCREMENT,
            node_id INTEGER NOT NULL,
            alias_text TEXT NOT NULL,
            lang TEXT,
            norm_text TEXT NOT NULL,
            alias_type TEXT,
            confidence REAL DEFAULT 1.0,
            UNIQUE(node_id, norm_text)
        );

        CREATE TABLE IF NOT EXISTS graph_edge (
            edge_id INTEGER PRIMARY KEY AUTOINCREMENT,
            src_node_id INTEGER NOT NULL,
            dst_node_id INTEGER NOT NULL,
            relation_type TEXT NOT NULL,
            directed INTEGER DEFAULT 1,
            weight REAL NOT NULL,
            corpus_support REAL DEFAULT 0,
            semantic_score REAL DEFAULT 0,
            llm_score REAL DEFAULT 0,
            citation_score REAL DEFAULT 0,
            temporal_score REAL DEFAULT 0,
            performance_score REAL DEFAULT 0,
            support_paper_count INTEGER DEFAULT 0,
            support_chunk_count INTEGER DEFAULT 0,
            attrs_json TEXT DEFAULT '{}',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(src_node_id, dst_node_id, relation_type, directed)
        );

        CREATE TABLE IF NOT EXISTS paper (
            paper_id TEXT PRIMARY KEY,
            paper_title TEXT NOT NULL,
            norm_title TEXT,
            year INTEGER,
            doi TEXT,
            norm_doi TEXT,
            journal TEXT,
            citation_count INTEGER,
            reference_count INTEGER,
            openalex_id TEXT,
            s2_paper_id TEXT,
            authors_json TEXT,
            matched_sources_json TEXT DEFAULT '{}',
            metadata_json TEXT DEFAULT '{}'
        );

        CREATE TABLE IF NOT EXISTS paper_link (
            link_id INTEGER PRIMARY KEY AUTOINCREMENT,
            relation_kind TEXT NOT NULL,          -- reference / citation
            provider TEXT,
            src_paper_id TEXT,
            src_title TEXT,
            src_norm_title TEXT,
            src_doi TEXT,
            src_norm_doi TEXT,
            src_year INTEGER,
            dst_paper_id TEXT,
            dst_title TEXT,
            dst_norm_title TEXT,
            dst_doi TEXT,
            dst_norm_doi TEXT,
            dst_year INTEGER,
            match_confidence REAL DEFAULT 0,
            match_method TEXT,
            attrs_json TEXT DEFAULT '{}'
        );

        CREATE TABLE IF NOT EXISTS paper_chunk (
            chunk_id TEXT PRIMARY KEY,
            paper_id TEXT NOT NULL,
            chunk_type TEXT NOT NULL,
            chunk_text TEXT NOT NULL,
            chunk_order INTEGER,
            attrs_json TEXT DEFAULT '{}'
        );

        CREATE TABLE IF NOT EXISTS paper_fact (
            fact_id INTEGER PRIMARY KEY AUTOINCREMENT,
            paper_id TEXT NOT NULL,
            chunk_id TEXT,
            field_name TEXT NOT NULL,
            field_node_id INTEGER,
            value_type TEXT NOT NULL,
            value_raw TEXT,
            value_norm TEXT,
            num_value REAL,
            range_low REAL,
            range_high REAL,
            unit TEXT,
            sign_label TEXT,
            prototype_node_id INTEGER,
            bucket_node_id INTEGER,
            confidence REAL DEFAULT 1.0,
            attrs_json TEXT DEFAULT '{}'
        );

        CREATE TABLE IF NOT EXISTS node_chunk_posting (
            node_id INTEGER NOT NULL,
            chunk_id TEXT NOT NULL,
            paper_id TEXT NOT NULL,
            support_score REAL DEFAULT 1.0,
            support_role TEXT,
            PRIMARY KEY(node_id, chunk_id)
        );

        CREATE TABLE IF NOT EXISTS edge_chunk_evidence (
            edge_id INTEGER NOT NULL,
            chunk_id TEXT NOT NULL,
            paper_id TEXT NOT NULL,
            evidence_score REAL DEFAULT 1.0,
            evidence_role TEXT,
            snippet TEXT,
            PRIMARY KEY(edge_id, chunk_id)
        );

        CREATE INDEX IF NOT EXISTS idx_graph_node_type_name ON graph_node(node_type, canonical_name);
        CREATE INDEX IF NOT EXISTS idx_node_alias_norm ON node_alias(norm_text);
        CREATE INDEX IF NOT EXISTS idx_graph_edge_src ON graph_edge(src_node_id, relation_type);
        CREATE INDEX IF NOT EXISTS idx_graph_edge_dst ON graph_edge(dst_node_id, relation_type);
        CREATE INDEX IF NOT EXISTS idx_paper_norm_title ON paper(norm_title);
        CREATE INDEX IF NOT EXISTS idx_paper_norm_doi ON paper(norm_doi);
        CREATE INDEX IF NOT EXISTS idx_paper_year ON paper(year);
        CREATE INDEX IF NOT EXISTS idx_paper_link_src ON paper_link(src_paper_id, relation_kind);
        CREATE INDEX IF NOT EXISTS idx_paper_link_dst ON paper_link(dst_paper_id, relation_kind);
        CREATE INDEX IF NOT EXISTS idx_paper_chunk_paper_type ON paper_chunk(paper_id, chunk_type);
        CREATE INDEX IF NOT EXISTS idx_paper_fact_field ON paper_fact(field_name);
        CREATE INDEX IF NOT EXISTS idx_paper_fact_num ON paper_fact(field_name, num_value);
        CREATE INDEX IF NOT EXISTS idx_paper_fact_range ON paper_fact(field_name, range_low, range_high);
        CREATE INDEX IF NOT EXISTS idx_node_chunk_posting_node ON node_chunk_posting(node_id);

        -- ── 新增：概念-论文直连（PAPER_EVIDENCE 边的数据基础）──────────────
        CREATE TABLE IF NOT EXISTS paper_concept (
            paper_id   TEXT NOT NULL,
            concept_id INTEGER NOT NULL,
            confidence REAL DEFAULT 1.0,
            chunk_types TEXT DEFAULT '',
            claim TEXT DEFAULT '',
            PRIMARY KEY (paper_id, concept_id)
        );
        CREATE INDEX IF NOT EXISTS idx_paper_concept_concept ON paper_concept(concept_id);
        CREATE INDEX IF NOT EXISTS idx_paper_concept_paper   ON paper_concept(paper_id);

        -- 旧库迁移：若 claim 字段不存在则补一个（无副作用，已存在则报错被吞掉）

        -- ── 新增：概念 embedding 向量（用于语义种子选择和去重）──────────────
        CREATE TABLE IF NOT EXISTS concept_embedding (
            concept_id INTEGER PRIMARY KEY,
            vector     BLOB NOT NULL,
            model      TEXT DEFAULT 'bge-m3',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        """)
        # 兼容旧库：补 claim 字段（已存在时 ALTER 会报 duplicate column，吞掉即可）
        try:
            self.conn.execute("ALTER TABLE paper_concept ADD COLUMN claim TEXT DEFAULT ''")
        except Exception:
            pass
        self.conn.commit()

    # ---------- graph ----------
    def upsert_graph_node(
        self,
        node_type: str,
        canonical_name: str,
        display_name_zh: Optional[str] = None,
        display_name_en: Optional[str] = None,
        subtype: Optional[str] = None,
        source: Optional[str] = None,
        attrs_json: Optional[Dict[str, Any]] = None,
    ) -> int:
        cur = self.conn.cursor()
        cur.execute("""
            INSERT OR IGNORE INTO graph_node
            (node_type, canonical_name, display_name_zh, display_name_en, subtype, source, attrs_json)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            node_type, canonical_name, display_name_zh, display_name_en,
            subtype, source, self._json(attrs_json),
        ))
        cur.execute("""
            SELECT node_id FROM graph_node
            WHERE node_type = ? AND canonical_name = ?
        """, (node_type, canonical_name))
        return int(cur.fetchone()["node_id"])

    def upsert_node_alias(
        self,
        node_id: int,
        alias_text: str,
        norm_text: str,
        lang: Optional[str] = None,
        alias_type: Optional[str] = None,
        confidence: float = 1.0,
    ) -> None:
        cur = self.conn.cursor()
        cur.execute("""
            INSERT OR IGNORE INTO node_alias
            (node_id, alias_text, lang, norm_text, alias_type, confidence)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (node_id, alias_text, lang, norm_text, alias_type, confidence))

    def upsert_graph_edge(
        self,
        src_node_id: int,
        dst_node_id: int,
        relation_type: str,
        directed: bool,
        weight: float,
        corpus_support: float = 0.0,
        semantic_score: float = 0.0,
        llm_score: float = 0.0,
        citation_score: float = 0.0,
        temporal_score: float = 0.0,
        performance_score: float = 0.0,
        support_paper_count: int = 0,
        support_chunk_count: int = 0,
        attrs_json: Optional[Dict[str, Any]] = None,
    ) -> int:
        cur = self.conn.cursor()
        cur.execute("""
            INSERT INTO graph_edge
            (src_node_id, dst_node_id, relation_type, directed, weight,
             corpus_support, semantic_score, llm_score, citation_score,
             temporal_score, performance_score, support_paper_count,
             support_chunk_count, attrs_json)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(src_node_id, dst_node_id, relation_type, directed)
            DO UPDATE SET
                weight = excluded.weight,
                corpus_support = MAX(graph_edge.corpus_support, excluded.corpus_support),
                semantic_score = MAX(graph_edge.semantic_score, excluded.semantic_score),
                llm_score = MAX(graph_edge.llm_score, excluded.llm_score),
                citation_score = MAX(graph_edge.citation_score, excluded.citation_score),
                temporal_score = MAX(graph_edge.temporal_score, excluded.temporal_score),
                performance_score = MAX(graph_edge.performance_score, excluded.performance_score),
                support_paper_count = MAX(graph_edge.support_paper_count, excluded.support_paper_count),
                support_chunk_count = MAX(graph_edge.support_chunk_count, excluded.support_chunk_count),
                attrs_json = excluded.attrs_json
        """, (
            src_node_id, dst_node_id, relation_type, int(directed), float(weight),
            corpus_support, semantic_score, llm_score, citation_score,
            temporal_score, performance_score, support_paper_count,
            support_chunk_count, self._json(attrs_json),
        ))

        cur.execute("""
            SELECT edge_id FROM graph_edge
            WHERE src_node_id=? AND dst_node_id=? AND relation_type=? AND directed=?
        """, (src_node_id, dst_node_id, relation_type, int(directed)))
        return int(cur.fetchone()["edge_id"])

    # ---------- paper ----------
    def insert_paper(self, row: Dict[str, Any]) -> None:
        cur = self.conn.cursor()
        cur.execute("""
            INSERT OR REPLACE INTO paper
            (paper_id, paper_title, norm_title, year, doi, norm_doi, journal,
             citation_count, reference_count, openalex_id, s2_paper_id,
             authors_json, matched_sources_json, metadata_json)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            row["paper_id"], row["paper_title"], row.get("norm_title"), row.get("year"),
            row.get("doi"), row.get("norm_doi"), row.get("journal"),
            row.get("citation_count"), row.get("reference_count"),
            row.get("openalex_id"), row.get("s2_paper_id"),
            self._json(row.get("authors_json")),
            self._json(row.get("matched_sources_json")),
            self._json(row.get("metadata_json")),
        ))

    def insert_paper_link(self, row: Dict[str, Any]) -> None:
        cur = self.conn.cursor()
        cur.execute("""
            INSERT INTO paper_link
            (relation_kind, provider,
             src_paper_id, src_title, src_norm_title, src_doi, src_norm_doi, src_year,
             dst_paper_id, dst_title, dst_norm_title, dst_doi, dst_norm_doi, dst_year,
             match_confidence, match_method, attrs_json)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            row["relation_kind"], row.get("provider"),
            row.get("src_paper_id"), row.get("src_title"), row.get("src_norm_title"),
            row.get("src_doi"), row.get("src_norm_doi"), row.get("src_year"),
            row.get("dst_paper_id"), row.get("dst_title"), row.get("dst_norm_title"),
            row.get("dst_doi"), row.get("dst_norm_doi"), row.get("dst_year"),
            row.get("match_confidence", 0.0), row.get("match_method"),
            self._json(row.get("attrs_json")),
        ))

    def insert_chunk(self, row: Dict[str, Any]) -> None:
        cur = self.conn.cursor()
        cur.execute("""
            INSERT OR REPLACE INTO paper_chunk
            (chunk_id, paper_id, chunk_type, chunk_text, chunk_order, attrs_json)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (
            row["chunk_id"], row["paper_id"], row["chunk_type"],
            row["chunk_text"], row.get("chunk_order"), self._json(row.get("attrs_json")),
        ))

    def insert_fact(self, row: Dict[str, Any]) -> int:
        cur = self.conn.cursor()
        cur.execute("""
            INSERT INTO paper_fact
            (paper_id, chunk_id, field_name, field_node_id, value_type, value_raw,
             value_norm, num_value, range_low, range_high, unit, sign_label,
             prototype_node_id, bucket_node_id, confidence, attrs_json)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            row["paper_id"], row.get("chunk_id"), row["field_name"], row.get("field_node_id"),
            row["value_type"], row.get("value_raw"), row.get("value_norm"),
            row.get("num_value"), row.get("range_low"), row.get("range_high"),
            row.get("unit"), row.get("sign_label"),
            row.get("prototype_node_id"), row.get("bucket_node_id"),
            row.get("confidence", 1.0), self._json(row.get("attrs_json")),
        ))
        return int(cur.lastrowid)

    def update_fact_links(self, fact_id: int, prototype_node_id: Optional[int] = None, bucket_node_id: Optional[int] = None):
        cur = self.conn.cursor()
        cur.execute("""
            UPDATE paper_fact
            SET prototype_node_id = COALESCE(?, prototype_node_id),
                bucket_node_id = COALESCE(?, bucket_node_id)
            WHERE fact_id = ?
        """, (prototype_node_id, bucket_node_id, fact_id))

    def upsert_node_chunk_posting(self, node_id: int, chunk_id: str, paper_id: str, support_score: float, support_role: str):
        cur = self.conn.cursor()
        cur.execute("""
            INSERT INTO node_chunk_posting
            (node_id, chunk_id, paper_id, support_score, support_role)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(node_id, chunk_id)
            DO UPDATE SET
                support_score = MAX(node_chunk_posting.support_score, excluded.support_score),
                support_role = excluded.support_role
        """, (node_id, chunk_id, paper_id, support_score, support_role))

    def upsert_edge_chunk_evidence(
        self,
        edge_id: int,
        chunk_id: str,
        paper_id: str,
        evidence_score: float,
        evidence_role: str,
        snippet: Optional[str] = None,
    ):
        cur = self.conn.cursor()
        cur.execute("""
            INSERT INTO edge_chunk_evidence
            (edge_id, chunk_id, paper_id, evidence_score, evidence_role, snippet)
            VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT(edge_id, chunk_id)
            DO UPDATE SET
                evidence_score = MAX(edge_chunk_evidence.evidence_score, excluded.evidence_score),
                evidence_role = excluded.evidence_role,
                snippet = COALESCE(excluded.snippet, edge_chunk_evidence.snippet)
        """, (edge_id, chunk_id, paper_id, evidence_score, evidence_role, snippet))

    # ---------- getters ----------
    def get_graph_node(self, node_type: str, canonical_name: str) -> Optional[Dict[str, Any]]:
        cur = self.conn.cursor()
        cur.execute("""
            SELECT * FROM graph_node WHERE node_type = ? AND canonical_name = ?
        """, (node_type, canonical_name))
        row = cur.fetchone()
        return dict(row) if row else None

    def get_graph_node_by_id(self, node_id: int) -> Optional[Dict[str, Any]]:
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM graph_node WHERE node_id = ?", (node_id,))
        row = cur.fetchone()
        return dict(row) if row else None

    def get_graph_nodes_by_ids(self, node_ids: List[int]) -> Dict[int, Dict[str, Any]]:
        """批量查 node_id → node 字典，避免 N 次单查（每次 ~ms 在压力下放大）。"""
        if not node_ids:
            return {}
        cur = self.conn.cursor()
        # SQLite 单语句参数上限约 999，分批
        out: Dict[int, Dict[str, Any]] = {}
        BATCH = 500
        for i in range(0, len(node_ids), BATCH):
            batch = node_ids[i:i + BATCH]
            ph = ",".join("?" * len(batch))
            cur.execute(f"SELECT * FROM graph_node WHERE node_id IN ({ph})", batch)
            for r in cur.fetchall():
                d = dict(r)
                out[int(d["node_id"])] = d
        return out

    def lookup_node_by_alias(self, node_type: str, norm_text: str) -> Optional[Dict[str, Any]]:
        cur = self.conn.cursor()
        cur.execute("""
            SELECT gn.*
            FROM node_alias na
            JOIN graph_node gn ON gn.node_id = na.node_id
            WHERE gn.node_type = ? AND na.norm_text = ?
            LIMIT 1
        """, (node_type, norm_text))
        row = cur.fetchone()
        return dict(row) if row else None

    def list_nodes(self, node_type: Optional[str] = None) -> List[Dict[str, Any]]:
        cur = self.conn.cursor()
        if node_type:
            cur.execute("SELECT * FROM graph_node WHERE node_type = ?", (node_type,))
        else:
            cur.execute("SELECT * FROM graph_node")
        return [dict(r) for r in cur.fetchall()]

    def list_edges(self) -> List[Dict[str, Any]]:
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM graph_edge")
        return [dict(r) for r in cur.fetchall()]

    def iter_edges(self):
        """流式逐行返回 graph_edge 行，避免 fetchall() 一次性 33 万行的内存峰值。"""
        cur = self.conn.cursor()
        cur.execute("SELECT edge_id, src_node_id, dst_node_id, relation_type, weight, directed FROM graph_edge")
        cols = ("edge_id", "src_node_id", "dst_node_id", "relation_type", "weight", "directed")
        for row in cur:
            yield dict(zip(cols, row))

    def list_chunks(self) -> List[Dict[str, Any]]:
        cur = self.conn.cursor()
        cur.execute("""
            SELECT pc.*, p.paper_title, p.year, p.citation_count
            FROM paper_chunk pc
            JOIN paper p ON p.paper_id = pc.paper_id
        """)
        return [dict(r) for r in cur.fetchall()]

    def list_chunks_by_paper(self, paper_id: str) -> List[Dict[str, Any]]:
        cur = self.conn.cursor()
        cur.execute("""
            SELECT chunk_id, paper_id, chunk_type
            FROM paper_chunk
            WHERE paper_id = ?
        """, (paper_id,))
        return [dict(r) for r in cur.fetchall()]

    def list_facts(self) -> List[Dict[str, Any]]:
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM paper_fact")
        return [dict(r) for r in cur.fetchall()]

    def get_chunk(self, chunk_id: str) -> Optional[Dict[str, Any]]:
        cur = self.conn.cursor()
        cur.execute("""
            SELECT pc.*, p.paper_title, p.year, p.citation_count
            FROM paper_chunk pc
            JOIN paper p ON p.paper_id = pc.paper_id
            WHERE pc.chunk_id = ?
        """, (chunk_id,))
        row = cur.fetchone()
        return dict(row) if row else None

    def get_paper(self, paper_id: str) -> Optional[Dict[str, Any]]:
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM paper WHERE paper_id = ?", (paper_id,))
        row = cur.fetchone()
        return dict(row) if row else None

    def get_paper_facts(self, paper_id: str) -> List[Dict[str, Any]]:
        """所有 paper_fact 行（按 paper_id）。供 expert_weights 维度打分调用。"""
        cur = self.conn.cursor()
        cur.execute("""
            SELECT field_name, value_type, value_raw, value_norm, num_value,
                   range_low, range_high, unit, confidence
            FROM paper_fact WHERE paper_id = ?
        """, (paper_id,))
        return [dict(r) for r in cur.fetchall()]

    def get_paper_facts_by_fields(self, paper_id: str,
                                  field_names: List[str]) -> List[Dict[str, Any]]:
        """指定字段的 paper_fact 行（按 paper_id + field_name IN ...）。"""
        if not field_names:
            return []
        cur = self.conn.cursor()
        qmarks = ",".join(["?"] * len(field_names))
        params: List[Any] = [paper_id] + list(field_names)
        cur.execute(f"""
            SELECT field_name, value_type, value_raw, value_norm, num_value,
                   range_low, range_high, unit, confidence
            FROM paper_fact
            WHERE paper_id = ? AND field_name IN ({qmarks})
        """, params)
        return [dict(r) for r in cur.fetchall()]

    def list_schema_fields(self) -> List[Dict[str, Any]]:
        return self.list_nodes("SchemaField")

    def list_prototypes(self) -> List[Dict[str, Any]]:
        return self.list_nodes("Prototype")

    def list_concept_names(self) -> List[Dict[str, Any]]:
        """只返回 Concept 节点的 node_id + canonical_name，不加载其余字段。"""
        cur = self.conn.cursor()
        cur.execute("SELECT node_id, canonical_name FROM graph_node WHERE node_type='Concept'")
        return [{"node_id": r[0], "canonical_name": r[1]} for r in cur.fetchall()]

    def get_posting_chunk_ids(
        self,
        node_ids: List[int],
        chunk_types: Optional[List[str]] = None,
        year_range: Optional[Tuple[Optional[int], Optional[int]]] = None,
    ) -> List[str]:
        if not node_ids:
            return []

        cur = self.conn.cursor()
        qmarks = ",".join(["?"] * len(node_ids))
        params: List[Any] = list(node_ids)
        sql = f"""
            SELECT DISTINCT ncp.chunk_id
            FROM node_chunk_posting ncp
            JOIN paper_chunk pc ON pc.chunk_id = ncp.chunk_id
            JOIN paper p ON p.paper_id = pc.paper_id
            WHERE ncp.node_id IN ({qmarks})
        """

        if chunk_types:
            tq = ",".join(["?"] * len(chunk_types))
            sql += f" AND pc.chunk_type IN ({tq})"
            params.extend(chunk_types)

        if year_range:
            y0, y1 = year_range
            if y0 is not None:
                sql += " AND (p.year IS NULL OR p.year >= ?)"
                params.append(y0)
            if y1 is not None:
                sql += " AND (p.year IS NULL OR p.year <= ?)"
                params.append(y1)

        cur.execute(sql, params)
        return [r["chunk_id"] for r in cur.fetchall()]

    def get_chunk_node_ids(self, chunk_id: str) -> List[int]:
        cur = self.conn.cursor()
        cur.execute("""
            SELECT node_id FROM node_chunk_posting WHERE chunk_id = ?
        """, (chunk_id,))
        return [int(r["node_id"]) for r in cur.fetchall()]

    def set_node_online_walk(self, node_id: int, enabled: bool) -> None:
        cur = self.conn.cursor()
        cur.execute("UPDATE graph_node SET online_walk=? WHERE node_id=?",
                    (1 if enabled else 0, node_id))

    def list_resolved_links(self, min_confidence: float = 0.80) -> List[Dict[str, Any]]:
        cur = self.conn.cursor()
        cur.execute("""
            SELECT DISTINCT
                relation_kind, src_paper_id, dst_paper_id,
                src_year, dst_year, match_confidence, match_method
            FROM paper_link
            WHERE src_paper_id IS NOT NULL
              AND dst_paper_id IS NOT NULL
              AND match_confidence >= ?
        """, (min_confidence,))
        return [dict(r) for r in cur.fetchall()]

    def get_local_neighbors(self, paper_id: str, min_confidence: float = 0.80) -> Dict[str, List[Dict[str, Any]]]:
        cur = self.conn.cursor()

        cur.execute("""
            SELECT DISTINCT p.*
            FROM paper_link l
            JOIN paper p ON p.paper_id = l.dst_paper_id
            WHERE l.src_paper_id = ?
              AND l.dst_paper_id IS NOT NULL
              AND l.match_confidence >= ?
        """, (paper_id, min_confidence))
        refs = [dict(r) for r in cur.fetchall()]

        cur.execute("""
            SELECT DISTINCT p.*
            FROM paper_link l
            JOIN paper p ON p.paper_id = l.src_paper_id
            WHERE l.dst_paper_id = ?
              AND l.src_paper_id IS NOT NULL
              AND l.match_confidence >= ?
        """, (paper_id, min_confidence))
        cits = [dict(r) for r in cur.fetchall()]

        return {"references": refs, "citations": cits}

    def get_local_in_degree(self, paper_id: str, min_confidence: float = 0.80) -> int:
        cur = self.conn.cursor()
        cur.execute("""
            SELECT COUNT(DISTINCT src_paper_id) AS cnt
            FROM paper_link
            WHERE dst_paper_id = ?
              AND src_paper_id IS NOT NULL
              AND match_confidence >= ?
        """, (paper_id, min_confidence))
        row = cur.fetchone()
        return int(row["cnt"] or 0)

    def get_paper_authority(self, paper_id: str) -> float:
        p = self.get_paper(paper_id)
        if not p:
            return 0.0
        global_cit = float(p.get("citation_count") or 0)
        local_in = float(self.get_local_in_degree(paper_id))
        return min(1.0, global_cit / 150.0 + local_in / 30.0)

    def search_aliases(self, query_norm: str, min_score: int = 82) -> List[Dict[str, Any]]:
        from rapidfuzz import fuzz
        cur = self.conn.cursor()
        cur.execute("SELECT DISTINCT node_id, alias_text, norm_text FROM node_alias")
        rows = cur.fetchall()
        results = []
        seen_nodes = set()
        for r in rows:
            score = fuzz.partial_ratio(query_norm, r["norm_text"])
            if score >= min_score and r["node_id"] not in seen_nodes:
                seen_nodes.add(r["node_id"])
                results.append({"node_id": r["node_id"], "alias_text": r["alias_text"], "score": score})
        results.sort(key=lambda x: x["score"], reverse=True)
        return results[:10]

    def get_top_evolves_to_nodes(self, limit: int = 5) -> List[int]:
        cur = self.conn.cursor()
        cur.execute("""
            SELECT src_node_id, SUM(weight) as total_w
            FROM graph_edge
            WHERE relation_type = 'EVOLVES_TO'
            GROUP BY src_node_id
            ORDER BY total_w DESC
            LIMIT ?
        """, (limit,))
        return [int(r["src_node_id"]) for r in cur.fetchall()]

    def count_rows(self, table_name: str) -> int:
        cur = self.conn.cursor()
        cur.execute(f"SELECT COUNT(*) AS cnt FROM {table_name}")
        return int(cur.fetchone()["cnt"])

    # ── paper_concept（概念-论文直连）─────────────────────────────────────

    def upsert_paper_concept(self, paper_id: str, concept_id: int,
                             confidence: float = 1.0, chunk_types: str = "",
                             claim: str = "") -> None:
        """写入或更新 paper_concept。

        - confidence 取最大值（多次 upsert 时保留最高分）
        - chunk_types/claim 直接覆盖（最新一次的 LLM 调用）
        - claim 为空时不覆盖原值
        """
        if claim:
            self.conn.execute("""
                INSERT INTO paper_concept (paper_id, concept_id, confidence, chunk_types, claim)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(paper_id, concept_id)
                DO UPDATE SET
                    confidence  = MAX(paper_concept.confidence, excluded.confidence),
                    chunk_types = excluded.chunk_types,
                    claim       = excluded.claim
            """, (paper_id, concept_id, confidence, chunk_types, claim))
        else:
            # 不带 claim 时不覆盖原 claim
            self.conn.execute("""
                INSERT INTO paper_concept (paper_id, concept_id, confidence, chunk_types, claim)
                VALUES (?, ?, ?, ?, '')
                ON CONFLICT(paper_id, concept_id)
                DO UPDATE SET
                    confidence  = MAX(paper_concept.confidence, excluded.confidence),
                    chunk_types = excluded.chunk_types
            """, (paper_id, concept_id, confidence, chunk_types))

    def get_papers_by_concept(self, concept_id: int) -> List[Dict]:
        cur = self.conn.cursor()
        cur.execute("""
            SELECT pc.paper_id, pc.confidence, p.paper_title, p.year
            FROM paper_concept pc
            JOIN paper p ON p.paper_id = pc.paper_id
            WHERE pc.concept_id = ?
            ORDER BY pc.confidence DESC
        """, (concept_id,))
        return [dict(r) for r in cur.fetchall()]

    def get_papers_by_concepts(self, concept_ids: List[int]) -> List[Dict]:
        """获取一批 concept 对应的论文，按综合置信度聚合排序。"""
        if not concept_ids:
            return []
        ph = ",".join("?" * len(concept_ids))
        cur = self.conn.cursor()
        cur.execute(f"""
            SELECT pc.paper_id, MAX(pc.confidence) as max_conf,
                   COUNT(DISTINCT pc.concept_id) as hit_concepts,
                   p.paper_title, p.year
            FROM paper_concept pc
            JOIN paper p ON p.paper_id = pc.paper_id
            WHERE pc.concept_id IN ({ph})
            GROUP BY pc.paper_id
            ORDER BY hit_concepts DESC, max_conf DESC
        """, concept_ids)
        return [dict(r) for r in cur.fetchall()]

    def concept_paper_counts(self) -> Dict[int, int]:
        """一次性返回 {concept_id: 该 concept 关联的论文数}。

        用于计算节点 specificity（IDF），抑制 PPR/beam_search 收敛到超节点。
        """
        cur = self.conn.cursor()
        cur.execute(
            "SELECT concept_id, COUNT(DISTINCT paper_id) FROM paper_concept GROUP BY concept_id"
        )
        return {int(r[0]): int(r[1]) for r in cur.fetchall()}

    def total_paper_count(self) -> int:
        """语料中论文总数（用于 IDF 归一化分母）。"""
        cur = self.conn.cursor()
        cur.execute("SELECT COUNT(*) FROM paper")
        return int(cur.fetchone()[0])

    def get_concepts_by_paper(self, paper_id: str) -> List[Dict]:
        cur = self.conn.cursor()
        cur.execute("""
            SELECT pc.concept_id, pc.confidence, gn.canonical_name
            FROM paper_concept pc
            JOIN graph_node gn ON gn.node_id = pc.concept_id
            WHERE pc.paper_id = ?
            ORDER BY pc.confidence DESC
        """, (paper_id,))
        return [dict(r) for r in cur.fetchall()]

    # ── concept_embedding（语义向量）──────────────────────────────────────

    def upsert_concept_embedding(self, concept_id: int, vector_bytes: bytes,
                                  model: str = "bge-m3") -> None:
        self.conn.execute("""
            INSERT INTO concept_embedding (concept_id, vector, model)
            VALUES (?, ?, ?)
            ON CONFLICT(concept_id) DO UPDATE SET vector = excluded.vector
        """, (concept_id, vector_bytes, model))

    def get_all_concept_embeddings(self):
        """返回 (concept_ids: List[int], matrix: np.ndarray shape=(N,1024))。
        调用方负责 import numpy。"""
        import numpy as np
        cur = self.conn.cursor()
        cur.execute("SELECT concept_id, vector FROM concept_embedding")
        rows = cur.fetchall()
        if not rows:
            return [], np.zeros((0, 1024), dtype=np.float32)
        ids = [r["concept_id"] for r in rows]
        vecs = [np.frombuffer(r["vector"], dtype=np.float32) for r in rows]
        return ids, np.stack(vecs)

    def get_build_stats(self) -> Dict[str, int]:
        return {
            "papers": self.count_rows("paper"),
            "chunks": self.count_rows("paper_chunk"),
            "facts": self.count_rows("paper_fact"),
            "nodes": self.count_rows("graph_node"),
            "edges": self.count_rows("graph_edge"),
            "paper_links": self.count_rows("paper_link"),
            "node_chunk_postings": self.count_rows("node_chunk_posting"),
        }
