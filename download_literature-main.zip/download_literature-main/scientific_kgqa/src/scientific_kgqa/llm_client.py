from __future__ import annotations

import json
import re
import time
import urllib.error
import urllib.request
from typing import Dict, Optional


class LLMClientError(Exception):
    pass


class LLMClient:
    """Anthropic Messages API client (urllib, zero extra deps).

    Works with the Anthropic API and compatible proxy endpoints.
    """

    def __init__(
        self,
        api_key: str,
        model: str = "gpt-4o-mini",
        base_url: str = "https://api-zjlab.sohoyo.io",
        timeout: float = 60.0,
        max_retries: int = 3,
        retry_backoff: float = 2.0,
        max_tokens: int = 2048,
    ):
        self.api_key = api_key
        self.model = model
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries
        self.retry_backoff = retry_backoff
        self.max_tokens = max_tokens

    def chat_json(self, system: str, user: str, temperature: float = 0.1) -> Dict:
        """Send a Chat Completions API request and return the parsed JSON object.

        Uses OpenAI Chat Completions format (/v1/chat/completions).
        Falls back to Anthropic /v1/messages if the OpenAI endpoint returns 404.
        """
        url_oai = f"{self.base_url}/v1/chat/completions"
        url_anthropic = f"{self.base_url}/v1/messages"
        payload_oai = {
            "model": self.model,
            "max_tokens": self.max_tokens,
            "temperature": temperature,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
        }
        payload_anthropic = {
            "model": self.model,
            "max_tokens": self.max_tokens,
            "temperature": temperature,
            "system": system,
            "messages": [
                {"role": "user", "content": user},
            ],
        }
        headers_oai = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}",
            "User-Agent": "openai-python/1.0.0",
        }
        headers_anthropic = {
            "Content-Type": "application/json",
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01",
            "User-Agent": "anthropic-python/0.40.0",
        }

        last_err: Optional[Exception] = None
        for attempt in range(self.max_retries):
            # 先试 OpenAI 协议
            try:
                req = urllib.request.Request(
                    url_oai,
                    data=json.dumps(payload_oai).encode("utf-8"),
                    headers=headers_oai,
                    method="POST",
                )
                with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                    body = resp.read().decode("utf-8")
                if not body.strip():
                    raise ValueError("OAI: empty body")
                response = json.loads(body)
                content = response["choices"][0]["message"]["content"]
                if not content or not content.strip():
                    raise ValueError("OAI: empty content")
                return _loads_tolerant(content)
            except urllib.error.HTTPError as e:
                err_body = ""
                try:
                    err_body = e.read().decode("utf-8", errors="replace")[:300]
                except Exception:
                    pass
                last_err = e
                # 任何 4xx → 切到 Anthropic 协议尝试（sohoyo 只支持 /v1/messages）
                if 400 <= e.code < 500:
                    print(f"[LLMClient] OAI endpoint 404, trying Anthropic /v1/messages")
                    try:
                        req2 = urllib.request.Request(
                            url_anthropic,
                            data=json.dumps(payload_anthropic).encode("utf-8"),
                            headers=headers_anthropic,
                            method="POST",
                        )
                        with urllib.request.urlopen(req2, timeout=self.timeout) as resp:
                            body = resp.read().decode("utf-8")
                        response = json.loads(body)
                        content = response["content"][0]["text"]
                        return _loads_tolerant(content)
                    except Exception as e2:
                        last_err = e2
                        print(f"[LLMClient] Anthropic also failed: {e2}")
                else:
                    print(f"[LLMClient] HTTP {e.code} from OAI: {err_body}")
            except (urllib.error.URLError, TimeoutError, json.JSONDecodeError,
                    KeyError, IndexError, ValueError) as e:
                last_err = e
                print(f"[LLMClient] {type(e).__name__}: {e}")

            if attempt < self.max_retries - 1:
                time.sleep(self.retry_backoff * (attempt + 1))
        raise LLMClientError(
            f"LLM call failed after {self.max_retries} retries (model={self.model} "
            f"base_url={self.base_url}): {last_err}"
        )


def _strip_code_fence(text: str) -> str:
    """Remove optional ```json ... ``` wrapper that models sometimes add."""
    text = text.strip()
    m = re.match(r"^```(?:json)?\s*(.*?)\s*```$", text, re.DOTALL)
    if m:
        return m.group(1)
    return text


# 已知的「单字符串字段」键：模型答案文本里常含未转义的内层引号（如 "rasorber"），
# 严格 json.loads 会在中途报 Expecting ',' delimiter。这些键按「贪婪取到末尾引号」兜底。
_STRING_KEYS = ("answer", "summary", "text", "content", "result", "explanation", "reason", "comment")


def _loads_tolerant(content: str) -> Dict:
    """容错解析 LLM 返回的 JSON：严格失败时尽力修复/抽取，减少无谓重试。

    依次尝试：
      1. 严格 json.loads（去 code fence 后）；
      2. 截取最外层 {...} 再严格解析；
      3. 去掉尾随逗号后解析；
      4. 正则抽取 "key": "value" / "key": number 键值对；
         对已知单字符串字段额外做「贪婪取到结尾引号」兜底（容忍内层未转义引号）。
    全部失败才抛 JSONDecodeError（交由上层重试）。
    """
    s = _strip_code_fence(content)
    try:
        return json.loads(s)
    except json.JSONDecodeError:
        pass

    i, j = s.find("{"), s.rfind("}")
    if i != -1 and j != -1 and j > i:
        s = s[i:j + 1]
        try:
            return json.loads(s)
        except json.JSONDecodeError:
            pass
        # 去尾随逗号 {..,} / [..,]
        s2 = re.sub(r",\s*([}\]])", r"\1", s)
        try:
            return json.loads(s2)
        except json.JSONDecodeError:
            pass

    # 正则兜底抽取
    obj: Dict = {}
    for m in re.finditer(r'"([\w_]+)"\s*:\s*"((?:[^"\\]|\\.)*)"', s):
        obj[m.group(1)] = m.group(2)
    for m in re.finditer(r'"([\w_]+)"\s*:\s*(-?\d+(?:\.\d+)?)', s):
        key, num = m.group(1), m.group(2)
        if key not in obj:
            obj[key] = float(num) if ("." in num) else int(num)
    # 单字符串字段：贪婪取到最后一个引号，容忍内层未转义引号导致的截断
    for k in _STRING_KEYS:
        m = re.search(r'"' + k + r'"\s*:\s*"(.*)"\s*[},]', s, re.DOTALL)
        if m and len(m.group(1)) > len(str(obj.get(k, ""))):
            obj[k] = m.group(1)
    if obj:
        return obj

    raise json.JSONDecodeError("tolerant parse failed", s, 0)
