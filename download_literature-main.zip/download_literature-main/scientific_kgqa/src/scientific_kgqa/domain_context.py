"""domain_context.py — 领域偏好注入（KG 模块自包含版）。

步骤 ⑧ 建图时，把用户的 `domain_prefer/<project>.txt`（Subdomains / Keywords /
Queries 三段混合格式，与步骤 ⑥⑦ 同一份文件）解析成一段 LLM-ready 的领域上下文，
拼到 LLMExtractor / QAEngine 的 system prompt 前面，让通用引导词获得领域偏向。

设计为**自包含**：不依赖 schema_gen（建图子进程只注入了 scientific_kgqa/src 到
PYTHONPATH）。文件缺省 / 为空时 `build_domain_instruction` 返回空串，prompt 保持纯
通用形态。
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional


_HEADER_RE = re.compile(
    r"^\s*(?:#+\s*=*\s*)?(subdomains|keywords|queries)\s*[:：]?\s*=*\s*$",
    re.IGNORECASE,
)
_SINGLE_LINE_RE = re.compile(
    r"^\s*(subdomains|keywords|queries)\s*[:：]\s*(.+)$", re.IGNORECASE,
)


@dataclass
class DomainPrefer:
    subdomains: List[str] = field(default_factory=list)
    keywords_text: str = ""
    queries_text: str = ""

    @property
    def has_content(self) -> bool:
        return bool(self.subdomains or self.keywords_text or self.queries_text)


def parse_domain_prefer(path: str | Path) -> DomainPrefer:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"domain_prefer 文件不存在: {p}")

    sections: dict[str, List[str]] = {"subdomains": [], "keywords": [], "queries": []}
    current: Optional[str] = None
    for raw in p.read_text(encoding="utf-8").splitlines():
        line = raw.rstrip()
        if not line.strip():
            continue
        m = _HEADER_RE.match(line)
        if m:
            current = m.group(1).lower()
            continue
        if line.lstrip().startswith("#"):
            continue
        single = _SINGLE_LINE_RE.match(line)
        if single:
            sec = single.group(1).lower()
            sections[sec].append(single.group(2))
            current = sec
            continue
        if current:
            sections[current].append(line)

    return DomainPrefer(
        subdomains=_parse_subdomain_list("\n".join(sections["subdomains"])),
        keywords_text="\n".join(sections["keywords"]).strip(),
        queries_text="\n".join(sections["queries"]).strip(),
    )


def _parse_subdomain_list(s: str) -> List[str]:
    s = s.strip().strip("[]【】").strip()
    if not s:
        return []
    s = re.sub(r"\s*\n\s*", " ", s)
    parts = re.split(r"[;；,，]", s)
    out, seen = [], set()
    for p in parts:
        p = p.strip()
        if p and p not in seen:
            seen.add(p)
            out.append(p)
    return out


def build_domain_instruction(pref: Optional[DomainPrefer]) -> str:
    """把 DomainPrefer 拼成一段领域上下文前缀；无内容时返回空串。"""
    if pref is None or not pref.has_content:
        return ""

    parts: List[str] = ["# Domain context (injected — bias extraction toward this corpus's domain)"]
    if pref.subdomains:
        parts.append(
            "This literature corpus belongs to the following subdomains: "
            f"{', '.join(pref.subdomains)}."
        )
    if pref.keywords_text:
        parts.append(
            "It was retrieved using these keyword queries (treat the listed terms as the "
            "canonical vocabulary of the domain):\n"
            f"```\n{pref.keywords_text.strip()}\n```"
        )
    if pref.queries_text:
        parts.append(
            "The downstream knowledge base must help answer:\n"
            f"```\n{pref.queries_text.strip()}\n```"
        )
    parts.append(
        "Use the domain's own canonical technical terms (as an engineer in THIS field would "
        "name them). The generic examples in the instructions below are illustrative only — "
        "do not force this corpus's concepts into them."
    )
    return "\n\n".join(parts)


def load_domain_instruction(path: Optional[str | Path]) -> str:
    """便捷入口：路径为空 / 文件缺省 → 返回空串（不报错），否则解析并拼接。"""
    if not path:
        return ""
    try:
        return build_domain_instruction(parse_domain_prefer(path))
    except FileNotFoundError as e:
        print(f"[domain_context] {e} — 跳过领域注入，使用纯通用 prompt")
        return ""


# ──────────────────────────────────────────────────────────────────────────
# KG 引导词配置加载（prompts_em.yaml）
# ──────────────────────────────────────────────────────────────────────────

# 出货默认：scientific_kgqa/configs/prompts_em.yaml（EM 示例 = 默认）
DEFAULT_KG_PROMPTS_PATH = Path(__file__).resolve().parents[2] / "configs" / "prompts_em.yaml"


def load_kg_prompts(path: Optional[str | Path] = None) -> dict:
    """加载 KG 引导词配置（prompts_em.yaml 结构）。

    path 为空 → 用默认出货路径。文件缺省 / 解析失败 → 返回 {}（调用方回退中立模板）。
    """
    p = Path(path) if path else DEFAULT_KG_PROMPTS_PATH
    if not p.exists():
        if path:  # 用户显式指定却找不到，提示一下
            print(f"[domain_context] KG prompts 文件不存在: {p} — 回退内置中立模板")
        return {}
    try:
        import yaml
        data = yaml.safe_load(p.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception as e:
        print(f"[domain_context] 解析 KG prompts 失败 ({e}) — 回退内置中立模板")
        return {}


def prompt_or(prompts: Optional[dict], dotted_key: str, fallback: str) -> str:
    """从 prompts dict 按点路径（如 "qa.translate_system"）取值；缺失/空 → fallback。"""
    if not prompts:
        return fallback
    node = prompts
    for part in dotted_key.split("."):
        if not isinstance(node, dict) or part not in node:
            return fallback
        node = node[part]
    if isinstance(node, str) and node.strip():
        return node.strip()
    return fallback

