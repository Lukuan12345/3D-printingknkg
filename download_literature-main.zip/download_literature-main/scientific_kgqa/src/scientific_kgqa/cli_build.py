import argparse
import json
import os
from pathlib import Path

from .builder import GraphBuilder
from .config import DEFAULT_DB_PATH, DEFAULT_KB_PATH, DEFAULT_RETRIEVER_PATH, DEFAULT_SCHEMA_PATH
from .llm_client import LLMClient
from .llm_extractor import LLMExtractor
from .retriever import Retriever
from .storage import SQLiteStore


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--schema", default=str(DEFAULT_SCHEMA_PATH))
    parser.add_argument("--kb", default=str(DEFAULT_KB_PATH))
    parser.add_argument("--db", default=str(DEFAULT_DB_PATH))
    parser.add_argument("--retriever", default=str(DEFAULT_RETRIEVER_PATH))
    parser.add_argument("--reset", action="store_true", help="Drop old tables before build")
    parser.add_argument("--rebuild-graph-only", action="store_true",
                        help="Skip ingest_kb/ingest_links, only rebuild graph nodes/edges from existing data")
    parser.add_argument("--llm-api-key", default=None,
                        help="API key (or env ANTHROPIC_AUTH_TOKEN / LLM_API_KEY)")
    parser.add_argument("--llm-model", default=None,
                        help="Model name (default: gpt-4o-mini, or env LLM_MODEL)")
    parser.add_argument("--llm-base-url", default=None,
                        help="API base URL without path (default: https://api-zjlab.sohoyo.io, or env ANTHROPIC_BASE_URL / LLM_BASE_URL)")
    parser.add_argument("--llm-cache",
                        default=str(Path(DEFAULT_DB_PATH).parent / "llm_cache.json"),
                        help="JSON file for caching LLM extractions")
    parser.add_argument("--no-llm", action="store_true", help="Disable LLM extraction even if key is set")
    parser.add_argument("--llm-workers", type=int, default=1,
                        help="LLM extraction concurrency (default 1, increase if API allows)")
    parser.add_argument("--domain-prefer-file", default=None,
                        help="领域偏好文件（domain_prefer/<project>.txt）；注入 LLM 抽取 prompt 做领域偏向。"
                             "缺省则用纯通用 prompt")
    parser.add_argument("--kg-prompts", default=None,
                        help="KG 引导词配置 YAML（默认 configs/prompts_em.yaml = EM 示例）；"
                             "建图用其 concept_extraction.system 作抽取 system 基底，缺省/缺 key 回退内置中立模板")
    args = parser.parse_args()

    store = SQLiteStore(args.db)
    if args.reset:
        store.reset()

    # Resolve LLM config from CLI args with env fallbacks
    api_key = (args.llm_api_key
               or os.environ.get("ANTHROPIC_AUTH_TOKEN")
               or os.environ.get("LLM_API_KEY")
               or os.environ.get("OPENAI_API_KEY"))
    model = args.llm_model or os.environ.get("LLM_MODEL") or "claude-haiku-4-5-20251001"
    # LLM 网关默认 43.153（与 generate_keywords.py / build_kb_kg.py 一致）。
    # 注意不要回退到 embedding 服务地址（35.220:3888 是 BGE-M3，不是 LLM）。
    base_url = (args.llm_base_url
                or os.environ.get("ANTHROPIC_BASE_URL")
                or os.environ.get("LLM_BASE_URL")
                or "http://43.153.42.7:3001/v1")

    # 领域注入：解析 domain_prefer 文件 → 拼一段领域上下文前缀（缺省为空串）
    from .domain_context import load_domain_instruction, load_kg_prompts, prompt_or
    domain_instruction = load_domain_instruction(args.domain_prefer_file)
    if domain_instruction:
        print(f"[domain] 已注入领域偏好: {args.domain_prefer_file}")

    # KG 引导词配置：抽取 system 基底（缺省加载出货 prompts_em.yaml；缺 key 回退内置中立模板）
    kg_prompts = load_kg_prompts(args.kg_prompts)
    extraction_system = prompt_or(kg_prompts, "concept_extraction.system", "")

    llm_extractor = None
    if api_key and not args.no_llm:
        # Load schema fields up front so the extractor can validate LLM output.
        schema_field_names: list[str] = []
        try:
            schema_field_names = [r["canonical_name"] for r in store.list_schema_fields()]
        except Exception:
            pass  # schema not loaded yet on fresh reset; extractor refreshes later
        client = LLMClient(api_key=api_key, model=model, base_url=base_url)
        llm_extractor = LLMExtractor(
            client=client,
            schema_fields=schema_field_names,
            cache_path=Path(args.llm_cache),
            domain_instruction=domain_instruction,
            base_system_prompt=extraction_system or None,
        )
        print(f"[LLM] enabled model={model} base_url={base_url} cache={args.llm_cache}")
    else:
        print("[LLM] disabled (no API key provided or --no-llm set)")

    builder = GraphBuilder(store, llm_extractor=llm_extractor)
    builder.run(args.schema, args.kb, llm_workers=args.llm_workers,
                rebuild_graph_only=args.rebuild_graph_only)

    Retriever.build_from_store(store, args.retriever)

    stats = store.get_build_stats()
    print("[OK] build finished")
    print(json.dumps({
        "db": args.db,
        "retriever": args.retriever,
        "stats": stats,
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
