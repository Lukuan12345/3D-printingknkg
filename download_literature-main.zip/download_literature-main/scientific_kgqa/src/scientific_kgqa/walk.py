from __future__ import annotations

import math
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional


# ──────────────────────────────────────────────────────────────────────────
# 图谱游走配置（外部化到 expert_weights_em.yaml 的 graph_walk 段）
# 代码内默认值 = 现有硬编码值；配置未设/缺字段时回退，行为不变。
# ──────────────────────────────────────────────────────────────────────────

_DEFAULT_EDGE_QUERY_BONUS: Dict[str, Dict[str, float]] = {
    "FIELD_INSTANTIATES": {"mechanism": 3.0, "optimization": 3.0, "parameter_effect": 3.0},
    "CONCEPT_EVOLVES": {"evolution": 2.0, "mechanism": 2.0, "optimization": 2.0},
    "CONCEPT_COOCCUR": {"mechanism": 1.5, "optimization": 1.5, "parameter_effect": 1.5},
}
_DEFAULT_PREFERRED: Dict[str, List[str]] = {
    "mechanism": ["FIELD_INSTANTIATES", "CONCEPT_COOCCUR", "CONCEPT_EVOLVES"],
    "optimization": ["FIELD_INSTANTIATES", "CONCEPT_EVOLVES", "CONCEPT_COOCCUR"],
    "fabrication": ["CHUNK_FLOW", "FIELD_INSTANTIATES"],
    "evolution": ["CONCEPT_EVOLVES", "CONCEPT_COOCCUR", "FIELD_INSTANTIATES"],
    "parameter_effect": ["FIELD_INSTANTIATES", "CONCEPT_EVOLVES", "CONCEPT_COOCCUR"],
    "default": ["FIELD_INSTANTIATES", "CONCEPT_COOCCUR"],
}


@dataclass
class WalkConfig:
    edge_query_bonus: Dict[str, Dict[str, float]] = field(
        default_factory=lambda: {k: dict(v) for k, v in _DEFAULT_EDGE_QUERY_BONUS.items()})
    preferred_relation_bonus: float = 0.25
    preferred_relations_by_intent: Dict[str, List[str]] = field(
        default_factory=lambda: {k: list(v) for k, v in _DEFAULT_PREFERRED.items()})
    # path_score 系数
    ps_edge_weight: float = 0.50
    ps_intent_bonus: float = 0.30
    ps_dst_specificity: float = 0.20
    ps_intent_bonus_norm_div: float = 3.0
    # ppr
    ppr_alpha: float = 0.15
    ppr_steps: int = 10
    ppr_prune_top_n: int = 3000
    ppr_qsim_floor: float = 0.3
    # beam
    beam_width: int = 24
    beam_per_seed_width: int = 8
    beam_max_hops: int = 5
    beam_min_edges: int = 3

    @classmethod
    def from_dict(cls, d: Optional[dict]) -> "WalkConfig":
        """从 expert_weights_em.yaml 的 graph_walk 段构造；空/缺字段回退默认值。"""
        cfg = cls()
        if not d:
            return cfg
        if isinstance(d.get("edge_query_bonus"), dict):
            cfg.edge_query_bonus = {
                rel: {it: float(b) for it, b in (m or {}).items()}
                for rel, m in d["edge_query_bonus"].items()
            }
        if d.get("preferred_relation_bonus") is not None:
            cfg.preferred_relation_bonus = float(d["preferred_relation_bonus"])
        if isinstance(d.get("preferred_relations_by_intent"), dict):
            cfg.preferred_relations_by_intent = {
                k: list(v) for k, v in d["preferred_relations_by_intent"].items()
            }
        ps = d.get("path_score") or {}
        cfg.ps_edge_weight = float(ps.get("edge_weight", cfg.ps_edge_weight))
        cfg.ps_intent_bonus = float(ps.get("intent_bonus", cfg.ps_intent_bonus))
        cfg.ps_dst_specificity = float(ps.get("dst_specificity", cfg.ps_dst_specificity))
        cfg.ps_intent_bonus_norm_div = float(ps.get("intent_bonus_norm_div", cfg.ps_intent_bonus_norm_div))
        ppr = d.get("ppr") or {}
        cfg.ppr_alpha = float(ppr.get("alpha", cfg.ppr_alpha))
        cfg.ppr_steps = int(ppr.get("steps", cfg.ppr_steps))
        cfg.ppr_prune_top_n = int(ppr.get("prune_top_n", cfg.ppr_prune_top_n))
        cfg.ppr_qsim_floor = float(ppr.get("qsim_floor", cfg.ppr_qsim_floor))
        beam = d.get("beam") or {}
        cfg.beam_width = int(beam.get("beam_width", cfg.beam_width))
        cfg.beam_per_seed_width = int(beam.get("per_seed_width", cfg.beam_per_seed_width))
        cfg.beam_max_hops = int(beam.get("max_hops", cfg.beam_max_hops))
        cfg.beam_min_edges = int(beam.get("min_edges_for_candidate", cfg.beam_min_edges))
        return cfg


_ACTIVE: Optional[WalkConfig] = None


def get_active_walk_config() -> WalkConfig:
    global _ACTIVE
    if _ACTIVE is None:
        _ACTIVE = WalkConfig()
    return _ACTIVE


def set_active_walk_config(cfg: Optional[WalkConfig]) -> None:
    """设置活动 walk 配置；传 None 恢复代码内默认值。"""
    global _ACTIVE
    _ACTIVE = cfg


@dataclass
class EdgeView:
    edge_id: int
    src: int
    dst: int
    relation_type: str
    weight: float
    directed: bool


class OnlineGraph:
    def __init__(self, store):
        self.store = store
        self.adj: dict[int, list[EdgeView]] = defaultdict(list)
        # (src, dst) → 该方向上 weight 最高的边（用于 path_score O(1) 查找）
        self.best_edge: dict[tuple[int, int], EdgeView] = {}
        # 节点 specificity（IDF 风格，抑制超节点垄断 PPR/beam_search）
        self.node_paper_count: dict[int, int] = {}
        self.total_papers: int = 1
        self._load()
        self._load_specificity()

    def _load(self):
        # 流式读取避免 fetchall() 33 万行全部转 dict() 的内存峰值
        for e in self.store.iter_edges():
            ev = EdgeView(
                edge_id=e["edge_id"],
                src=e["src_node_id"],
                dst=e["dst_node_id"],
                relation_type=e["relation_type"],
                weight=float(e["weight"]),
                directed=bool(e["directed"]),
            )
            self.adj[ev.src].append(ev)
            self._update_best_edge(ev.src, ev.dst, ev)
            if not ev.directed:
                rev = EdgeView(
                    edge_id=ev.edge_id,
                    src=ev.dst,
                    dst=ev.src,
                    relation_type=ev.relation_type,
                    weight=ev.weight,
                    directed=ev.directed,
                )
                self.adj[rev.src].append(rev)
                self._update_best_edge(rev.src, rev.dst, rev)

    def _update_best_edge(self, src: int, dst: int, ev: "EdgeView"):
        key = (src, dst)
        prev = self.best_edge.get(key)
        if prev is None or ev.weight > prev.weight:
            self.best_edge[key] = ev

    def _load_specificity(self):
        """预加载每个 Concept 节点的 paper_count，用于 IDF 降权。"""
        try:
            self.node_paper_count = self.store.concept_paper_counts()
            self.total_papers = max(1, self.store.total_paper_count())
        except Exception:
            # 旧 store 没有这两个方法时降级为不做 specificity 调整
            self.node_paper_count = {}
            self.total_papers = 1

    def out_edges(self, node_id: int) -> List[EdgeView]:
        return self.adj.get(node_id, [])

    def node_specificity(self, node_id: int) -> float:
        """IDF 风格的节点信息量评分，范围 [0.5, 1.0]。

        用于抑制超节点（topology optimization 6204 篇）垄断 beam_search，
        但故意做得"温和"——避免 beam 反向偏到冷门但与 query 无关的节点。

        配方：specificity = max(0.5, (log(N/p)/log(N))^0.5)
        - 超节点（>4000 papers）→ 触底 0.5
        - 中热度（100-500 papers）→ 0.6-0.7
        - 罕见（1-10 papers）→ 0.85-1.0

        差距控制在 2× 以内，避免 beam 被纯冷门节点吸引。
        """
        pc = self.node_paper_count.get(node_id)
        if not pc or pc <= 1:
            return 1.0
        if self.total_papers <= 1:
            return 1.0
        idf = math.log(self.total_papers / pc) / math.log(self.total_papers)
        spec = idf ** 0.5
        return max(0.5, min(1.0, spec))


def preferred_relations_by_intent(intent: str, cfg: Optional[WalkConfig] = None) -> set[str]:
    cfg = cfg or get_active_walk_config()
    rels = cfg.preferred_relations_by_intent.get(intent)
    if rels is None:
        rels = cfg.preferred_relations_by_intent.get("default", [])
    return set(rels)


def edge_query_bonus(rel: str, intent: str, cfg: Optional[WalkConfig] = None) -> float:
    cfg = cfg or get_active_walk_config()
    rel_map = cfg.edge_query_bonus.get(rel)
    if rel_map and intent in rel_map:
        return float(rel_map[intent])
    bonus = 1.0
    if rel in preferred_relations_by_intent(intent, cfg):
        bonus += cfg.preferred_relation_bonus
    return bonus


def personalized_ppr(
    graph: OnlineGraph,
    seed_ids: List[int],
    intent: str,
    alpha: Optional[float] = None,
    steps: Optional[int] = None,
    query_sim_map: Optional[Dict[int, float]] = None,
    prune_top_n: Optional[int] = None,
    cfg: Optional[WalkConfig] = None,
) -> Dict[int, float]:
    """Personalized PageRank with optional query-aware transfer weights.

    alpha / steps / prune_top_n 为 None 时取 walk 配置（默认 0.15 / 10 / 3000）。

    query_sim_map: dict {node_id -> cosine sim with query embedding}, in [0, 1].
        若提供，每跳的转移概率额外乘以 max(qsim_floor, sim(dst))，让 mass 倾向流向
        与 query 语义相近的 concept，抑制流向无关共现领域。

    Perf:
    - steps=10（原 20）：alpha=0.15 时 10 跳已基本收敛
    - prune_top_n=3000：每跳后 mass 字典截到 top-N，避免完全扩散到 80k 节点。
    """
    if not seed_ids:
        return {}

    cfg = cfg or get_active_walk_config()
    alpha = cfg.ppr_alpha if alpha is None else alpha
    steps = cfg.ppr_steps if steps is None else steps
    prune_top_n = cfg.ppr_prune_top_n if prune_top_n is None else prune_top_n

    restart = {nid: 1.0 / len(seed_ids) for nid in seed_ids}
    score: Dict[int, float] = restart.copy()

    QSIM_FLOOR = cfg.ppr_qsim_floor

    for _ in range(steps):
        new_score = defaultdict(float)

        for u, mass in score.items():
            edges = graph.out_edges(u)
            if not edges:
                continue

            weighted = []
            total = 0.0
            for e in edges:
                w = max(1e-6, e.weight * edge_query_bonus(e.relation_type, intent, cfg))
                if query_sim_map is not None:
                    q_sim = query_sim_map.get(e.dst, QSIM_FLOOR)
                    w *= max(QSIM_FLOOR, min(1.0, q_sim))
                weighted.append((e.dst, w))
                total += w

            for v, w in weighted:
                new_score[v] += (1 - alpha) * mass * (w / total)

        for nid, p in restart.items():
            new_score[nid] += alpha * p

        # mass top-N pruning：保留 top-N 节点参与下一跳扩散
        # seed 节点永远保留（restart 每跳都注入），低 mass 节点丢弃
        if prune_top_n > 0 and len(new_score) > prune_top_n:
            top_items = sorted(new_score.items(), key=lambda x: x[1], reverse=True)
            score = dict(top_items[:prune_top_n])
        else:
            score = dict(new_score)

    return dict(sorted(score.items(), key=lambda x: x[1], reverse=True))


def path_score(graph: OnlineGraph, path: List[int], intent: str,
               cfg: Optional[WalkConfig] = None) -> float:
    """路径评分（归一化均值 + dst 节点 specificity 加权）。

    每条边得分 = ps_edge_weight×边权 + ps_intent_bonus×意图奖励 + ps_dst_specificity×dst_specificity
    路径得分 = 所有边得分的平均值。系数来自 walk 配置（默认 0.50/0.30/0.20）。
    """
    if len(path) <= 1:
        return 0.0

    cfg = cfg or get_active_walk_config()
    edge_scores = []
    best_edge_map = graph.best_edge
    for a, b in zip(path[:-1], path[1:]):
        best = best_edge_map.get((a, b))
        if best is None:
            continue
        w = max(0.0, min(1.0, best.weight))
        bonus_norm = min(1.0, edge_query_bonus(best.relation_type, intent, cfg) / cfg.ps_intent_bonus_norm_div)
        # dst 节点的信息量（超节点会被温和惩罚）
        dst_spec = graph.node_specificity(b)
        edge_scores.append(
            cfg.ps_edge_weight * w + cfg.ps_intent_bonus * bonus_norm + cfg.ps_dst_specificity * dst_spec
        )

    if not edge_scores:
        return 0.0
    return sum(edge_scores) / len(edge_scores)


def beam_search(
    graph: OnlineGraph,
    seed_ids: List[int],
    candidate_nodes: set[int],
    intent: str,
    beam_width: Optional[int] = None,
    max_hops: Optional[int] = None,
    cfg: Optional[WalkConfig] = None,
) -> List[List[int]]:
    """Per-seed beam search：每个 seed 独立 beam，避免单个高分主干垄断。

    beam_width / max_hops 为 None 时取 walk 配置（默认 24 / 5）。per_seed_width 与
    入候选最小边数也来自配置（默认 8 / 3）。

    返回所有 seed 的最佳路径合集（去重 + 全局按 path_score 排序）。
    """
    if not seed_ids:
        return []

    cfg = cfg or get_active_walk_config()
    max_hops = cfg.beam_max_hops if max_hops is None else max_hops
    # beam_width 当前保留为外部可覆盖项（全局 beam）；未传则用配置值
    _ = cfg.beam_width if beam_width is None else beam_width

    # 每个 seed 内部用一个适中的 beam，鼓励它探索深度而非广度
    per_seed_width = cfg.beam_per_seed_width
    min_edges = cfg.beam_min_edges

    best_per_seed: List[List[int]] = []

    for seed in seed_ids:
        beams: List[List[int]] = [[seed]]
        seed_candidates: List[tuple[float, List[int]]] = []

        for hop in range(max_hops):
            new_beams: List[tuple[float, List[int]]] = []
            for path in beams:
                last = path[-1]
                for e in graph.out_edges(last):
                    if e.dst not in candidate_nodes or e.dst in path:
                        continue
                    cand = path + [e.dst]
                    new_beams.append((path_score(graph, cand, intent, cfg), cand))

            if not new_beams:
                break
            new_beams.sort(key=lambda x: x[0], reverse=True)
            beams = [p for _, p in new_beams[:per_seed_width]]
            # 仅当跳数 >= min_edges（即节点数 >= min_edges+1）的路径才入候选
            if hop + 1 >= min_edges:
                seed_candidates.extend(new_beams[:per_seed_width])

        if not seed_candidates:
            continue
        # 该 seed 取分数最高的一条（最深路径优先：长度相同时 path_score 已经体现深度）
        seed_candidates.sort(key=lambda x: (len(x[1]), x[0]), reverse=True)
        best_per_seed.append(seed_candidates[0][1])

    # 去重 + 全局排序
    dedup: List[List[int]] = []
    seen: set = set()
    for p in best_per_seed:
        key = tuple(p)
        if key in seen:
            continue
        seen.add(key)
        dedup.append(p)

    dedup.sort(key=lambda p: path_score(graph, p, intent, cfg), reverse=True)
    return dedup
