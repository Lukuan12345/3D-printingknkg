"""expert_weights.py — task-aware 重排的领域配置加载 + 打分。

领域相关的全部配置（task 权重 / 功能类型关键词 / 维度→schema字段映射 / chunk 优先级）
已外部化到 YAML（默认 ``configs/expert_weights_em.yaml``）。换领域时复制该 YAML 改字段名，
通过 ``--expert-config`` 指定即可，代码无需改动。

自动降级（O4）：``ExpertConfig.is_applicable_to(schema_field_names)`` 检查本配置引用的
schema 字段是否在当前 schema 里存在；一个都不存在时 QA 会关闭 task-aware 重排、回退通用打分。

三个 task_type：
    1. heuristic_config   启发式构型（功能类型主导）
    2. param_optimization 参数寻优（结构/机理主导）
    3. process_library    工艺/标准库（结构/材料主导）

打分逻辑见 compute_expert_score()：基于 paper_fact 表里该 paper 是否抽取到对应字段
（存在=1.0，缺失=0.0），按维度加权累加。功能类型用关键词匹配。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

from .utils import normalize_text

# 默认领域配置：本模块同级 configs/expert_weights_em.yaml
_DEFAULT_CONFIG_PATH = Path(__file__).resolve().parents[2] / "configs" / "expert_weights_em.yaml"


# =============================================================================
# 配置对象
# =============================================================================

@dataclass
class ExpertConfig:
    """task-aware 重排的全部领域配置。从 YAML 加载，默认 EM 配置。"""
    task_weights: Dict[str, Dict] = field(default_factory=dict)
    task_type_keywords: Dict[str, List[str]] = field(default_factory=dict)
    task_type_priority: List[str] = field(default_factory=list)
    functional_type_keywords: Dict[str, List[str]] = field(default_factory=dict)
    functional_type_priority: List[str] = field(default_factory=list)
    emphasis_triggers: Dict[str, Dict[str, List[str]]] = field(default_factory=dict)
    performance_fields: Dict[str, List[str]] = field(default_factory=dict)
    material_fields: Dict[str, List[str]] = field(default_factory=dict)
    structure_fields: Dict[str, List[str]] = field(default_factory=dict)
    mechanism_fields: Dict[str, List[str]] = field(default_factory=dict)
    functional_type_value_patterns: Dict[str, List[str]] = field(default_factory=dict)
    functional_type_probe_fields: List[str] = field(default_factory=list)
    task_chunk_type_priority: Dict[str, List[str]] = field(default_factory=dict)
    gating_penalty: float = 1.0
    # 图谱游走参数（walk.py 消费；见 expert_weights_em.yaml 的 graph_walk 段）
    graph_walk: Dict = field(default_factory=dict)

    @classmethod
    def from_yaml(cls, path: str | Path) -> "ExpertConfig":
        import yaml
        data = yaml.safe_load(Path(path).read_text(encoding="utf-8")) or {}
        known = {f.name for f in cls.__dataclass_fields__.values()}  # type: ignore[attr-defined]
        return cls(**{k: v for k, v in data.items() if k in known})

    def all_referenced_fields(self) -> Set[str]:
        """本配置引用的全部 schema 字段名（用于自动降级判定）。"""
        out: Set[str] = set()
        for fmap in (self.performance_fields, self.material_fields,
                     self.structure_fields, self.mechanism_fields):
            for fields in fmap.values():
                out.update(fields)
        out.update(self.functional_type_probe_fields)
        return out

    def is_applicable_to(self, schema_field_names) -> bool:
        """本领域配置是否适用于给定 schema：引用字段与 schema 字段有交集才适用。"""
        referenced = self.all_referenced_fields()
        if not referenced:
            return False
        schema_set = {normalize_text(f).replace(" ", "_") for f in schema_field_names}
        # normalize_key 风格对齐：字段名都是 snake_case
        ref_norm = {normalize_text(f).replace(" ", "_") for f in referenced}
        return bool(ref_norm & schema_set)


# 模块级活动配置：默认加载 EM YAML。可通过 set_active_config() 替换。
_ACTIVE: Optional[ExpertConfig] = None


def load_expert_config(path: Optional[str | Path] = None) -> ExpertConfig:
    """加载领域配置。path 为空时用默认 EM 配置。"""
    return ExpertConfig.from_yaml(path or _DEFAULT_CONFIG_PATH)


def get_active_config() -> ExpertConfig:
    global _ACTIVE
    if _ACTIVE is None:
        _ACTIVE = load_expert_config()
    return _ACTIVE


def set_active_config(cfg: Optional[ExpertConfig]) -> None:
    """设置活动配置；传 None 恢复默认 EM 配置。"""
    global _ACTIVE
    _ACTIVE = cfg


def _cfg(config: Optional[ExpertConfig]) -> ExpertConfig:
    return config or get_active_config()


# =============================================================================
# Query 解析
# =============================================================================

def detect_task_type(query: str, config: Optional[ExpertConfig] = None) -> Optional[str]:
    """从 query 推断 task_type。三类都没命中则返回 None（走原有逻辑）。"""
    cfg = _cfg(config)
    if not query:
        return None
    q = normalize_text(query)
    counts: Dict[str, int] = {}
    for tt, kws in cfg.task_type_keywords.items():
        hits = sum(1 for k in kws if normalize_text(k) in q)
        if hits:
            counts[tt] = hits
    if not counts:
        return None
    best = max(counts.values())
    cands = [t for t, c in counts.items() if c == best]
    for t in cfg.task_type_priority:
        if t in cands:
            return t
    return cands[0]


def extract_functional_type(query: str, config: Optional[ExpertConfig] = None) -> Optional[str]:
    """从 query 抽功能类型。未命中返回 None。"""
    cfg = _cfg(config)
    if not query:
        return None
    q = normalize_text(query)
    for ft in cfg.functional_type_priority:
        for kw in cfg.functional_type_keywords.get(ft, []):
            if normalize_text(kw) in q:
                return ft
    return None


def extract_emphasis_words(query: str, task_type: Optional[str],
                           config: Optional[ExpertConfig] = None) -> Set[str]:
    """检测性能强调词，返回触发翻倍的子维度集合。"""
    cfg = _cfg(config)
    if not query or not task_type:
        return set()
    triggers = cfg.emphasis_triggers.get(task_type, {})
    if not triggers:
        return set()
    q = normalize_text(query)
    hit: Set[str] = set()
    for sub_dim, kws in triggers.items():
        for kw in kws:
            if normalize_text(kw) in q:
                hit.add(sub_dim)
                break
    return hit


def adjust_performance_sub_weights(
    base_sub: Dict[str, float],
    emphasis: Set[str],
) -> Dict[str, float]:
    """按 emphasis 翻倍触发的子维度权重，然后重新归一化。"""
    if not emphasis or not base_sub:
        return dict(base_sub)
    adjusted = {k: (v * 2.0 if k in emphasis else v) for k, v in base_sub.items()}
    total = sum(adjusted.values()) or 1.0
    return {k: v / total for k, v in adjusted.items()}


# =============================================================================
# 论文事实查询缓存（避免每次重算）
# =============================================================================

class _PaperFactsCache:
    """单次查询内复用的 paper_fact 缓存。"""

    def __init__(self, store):
        self.store = store
        self._cache: Dict[str, Dict[str, List[str]]] = {}

    def get_fields(self, paper_id: str) -> Dict[str, List[str]]:
        if paper_id in self._cache:
            return self._cache[paper_id]
        rows = self.store.get_paper_facts(paper_id)
        bucket: Dict[str, List[str]] = {}
        for r in rows:
            f = r.get("field_name")
            if not f:
                continue
            v = r.get("value_norm") or r.get("value_raw") or ""
            bucket.setdefault(f, []).append(normalize_text(v))
        self._cache[paper_id] = bucket
        return bucket

    def has_field(self, paper_id: str, field_name: str) -> bool:
        return bool(self.get_fields(paper_id).get(field_name))

    def field_values(self, paper_id: str, field_name: str) -> List[str]:
        return self.get_fields(paper_id).get(field_name, [])


# =============================================================================
# 维度打分
# =============================================================================

def _field_presence_score(cache: _PaperFactsCache, paper_id: str,
                          field_names: List[str]) -> float:
    """字段存在性打分：任一字段被抽取出来 → 1.0，否则 0.0。"""
    for f in field_names:
        if cache.has_field(paper_id, f):
            return 1.0
    return 0.0


def _sub_weighted_score(
    cache: _PaperFactsCache, paper_id: str,
    sub_weights: Dict[str, float],
    field_map: Dict[str, List[str]],
) -> float:
    """子维度加权求和：sub_weights * field_presence(field_map[sub])."""
    if not sub_weights:
        return 0.0
    score = 0.0
    for sub_key, w in sub_weights.items():
        if w <= 0:
            continue
        fields = field_map.get(sub_key, [])
        if not fields:
            continue
        score += w * _field_presence_score(cache, paper_id, fields)
    return score


def check_functional_type_match(
    cache: _PaperFactsCache, paper_id: str,
    functional_type: Optional[str],
    config: Optional[ExpertConfig] = None,
) -> Optional[bool]:
    """检查论文是否匹配指定功能类型。

    Returns:
        None — query 未指定功能类型 / 该 paper 无 probe 字段（不参与 gating）
        True — 命中
        False — 显式不匹配
    """
    cfg = _cfg(config)
    if not functional_type:
        return None
    patterns = cfg.functional_type_value_patterns.get(functional_type, [])
    if not patterns:
        return None
    norm_patterns = [normalize_text(p) for p in patterns]

    has_any_probe_field = False
    for f in cfg.functional_type_probe_fields:
        vals = cache.field_values(paper_id, f)
        if not vals:
            continue
        has_any_probe_field = True
        for v in vals:
            for pat in norm_patterns:
                if pat and pat in v:
                    return True
    if not has_any_probe_field:
        return None
    return False


def compute_expert_score(
    paper_id: str,
    task_type: str,
    functional_type: Optional[str],
    emphasis_words: Set[str],
    cache: _PaperFactsCache,
    config: Optional[ExpertConfig] = None,
) -> Tuple[float, Optional[bool]]:
    """计算 paper 的专家维度综合得分 ∈ [0, 1]，以及 functional_type 匹配标志。"""
    cfg = _cfg(config)
    weights = cfg.task_weights.get(task_type)
    if not weights:
        return 0.0, None

    score = 0.0

    # ---- 功能类型（binary）----
    ft_w = weights.get("functional_type", 0.0)
    ft_match = check_functional_type_match(cache, paper_id, functional_type, cfg)
    if ft_w > 0 and ft_match is True:
        score += ft_w

    # ---- 性能 ----
    perf = weights.get("performance", {}) or {}
    perf_total = perf.get("total", 0.0)
    if perf_total > 0:
        perf_sub = adjust_performance_sub_weights(perf.get("sub", {}), emphasis_words)
        score += perf_total * _sub_weighted_score(
            cache, paper_id, perf_sub, cfg.performance_fields
        )

    # ---- 材料 ----
    mat = weights.get("material", {}) or {}
    mat_total = mat.get("total", 0.0)
    if mat_total > 0:
        score += mat_total * _sub_weighted_score(
            cache, paper_id, mat.get("sub", {}), cfg.material_fields
        )

    # ---- 结构 ----
    struct = weights.get("structure", {}) or {}
    struct_total = struct.get("total", 0.0)
    if struct_total > 0:
        score += struct_total * _sub_weighted_score(
            cache, paper_id, struct.get("sub", {}), cfg.structure_fields
        )

    # ---- 机理 ----
    mech = weights.get("mechanism", {}) or {}
    mech_total = mech.get("total", 0.0)
    if mech_total > 0:
        score += mech_total * _sub_weighted_score(
            cache, paper_id, mech.get("sub", {}), cfg.mechanism_fields
        )

    return min(1.0, score), ft_match


def make_facts_cache(store) -> _PaperFactsCache:
    """工厂函数：创建一次查询内的论文事实缓存。"""
    return _PaperFactsCache(store)


# =============================================================================
# 任务相关的 chunk_type 优先级覆盖
# =============================================================================

def chunk_types_for_task(task_type: Optional[str],
                         config: Optional[ExpertConfig] = None) -> Optional[List[str]]:
    """返回 task_type 对应的 chunk_type 优先级；未识别返回 None。"""
    if not task_type:
        return None
    return _cfg(config).task_chunk_type_priority.get(task_type)
