"""pipeline.py — DomainPipeline：KG 游走 → KB 检索 → LLM 生成式收尾。

把 scientific_kgqa.qa_engine.QAEngine 的图游走结果作为上下文，
喂给 LLM 生成自然语言回答。

数据流：
    query
      ↓
    QAEngine.answer()  → {intent, reasoning_paths, evidence, evolution_context, plan}
      ↓
    prompt_builder.build_qa_prompt()  → (system, user)
      ↓
    LLMClient.chat_json()  → {"answer": "..."}
      ↓
    最终结果 dict（含 answer + 原 evidence/paths 供溯源）
"""
from __future__ import annotations

import logging
from typing import Any, Dict, Optional

from .llm_client import LLMClient, LLMClientError
from .prompt_builder import build_qa_prompt
from .qa_engine import QAEngine
from .retriever import Retriever
from .storage import SQLiteStore

logger = logging.getLogger(__name__)


class DomainPipeline:
    """三层链路协调器：KG 游走 + KB 检索 + LLM 生成式回答。"""

    def __init__(
        self,
        store: SQLiteStore,
        retriever: Retriever,
        llm_client: Optional[LLMClient] = None,
        max_evidence: int = 8,
        snippet_len: int = 600,
    ):
        self.store = store
        self.retriever = retriever
        self.qa_engine = QAEngine(store, retriever, llm_client=llm_client)
        self.llm_client = llm_client
        self.max_evidence = max_evidence
        self.snippet_len = snippet_len

    def answer(self, query: str, task_type: Optional[str] = None) -> Dict[str, Any]:
        """端到端 QA：返回 dict 包含 answer + 全部溯源信息。

        Args:
            query: 用户问题
            task_type: 可选，覆盖自动检测（"heuristic_config" / "param_optimization" / "process_library"）
        """
        # Step 1: KG 游走 + KB 检索
        qa_result = self.qa_engine.answer(query, task_type_override=task_type)

        # Step 2: 构建 LLM prompt（答案 system 与领域注入取自 QAEngine 的配置）
        system_prompt, user_prompt = build_qa_prompt(
            qa_result, query,
            max_evidence=self.max_evidence,
            snippet_len=self.snippet_len,
            domain_instruction=getattr(self.qa_engine, "domain_instruction", ""),
            system_prompt=getattr(self.qa_engine, "qa_answer_system", ""),
        )

        # Step 3: LLM 生成
        llm_answer = ""
        llm_error: Optional[str] = None

        if self.llm_client is None:
            llm_error = "LLMClient 未配置（仅返回检索结果，跳过生成）"
        else:
            try:
                response = self.llm_client.chat_json(system_prompt, user_prompt)
                if isinstance(response, dict):
                    llm_answer = response.get("answer", "") or ""
                if not llm_answer:
                    llm_error = f"LLM 返回格式异常: {type(response).__name__}"
            except LLMClientError as e:
                llm_error = f"LLM 调用失败: {e}"
                logger.warning("LLM 调用失败 query=%r: %s", query[:80], e)
            except Exception as e:
                llm_error = f"LLM 未知异常: {type(e).__name__}: {e}"
                logger.exception("LLM 未知异常")

        # Step 4: 组装最终回复
        result: Dict[str, Any] = {
            "query": query,
            "intent": qa_result.get("intent"),
            "answer": llm_answer,
            "summary": qa_result.get("summary", ""),  # QAEngine 自带的检索摘要
            "reasoning_paths": qa_result.get("reasoning_paths", []),
            "evidence": qa_result.get("evidence", [])[:self.max_evidence],
            "evolution_context": qa_result.get("evolution_context", []),
            "retrieval_plan": qa_result.get("retrieval_plan", {}),
            "confidence": qa_result.get("confidence", 0.0),
        }
        if llm_error:
            result["llm_error"] = llm_error

        return result
