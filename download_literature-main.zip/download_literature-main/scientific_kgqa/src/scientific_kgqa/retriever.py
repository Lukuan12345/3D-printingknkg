from __future__ import annotations

import pickle
from pathlib import Path
from typing import Dict, List, Optional

from rank_bm25 import BM25Okapi
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from .storage import SQLiteStore
from .utils import tokenize


class Retriever:
    def __init__(self, chunk_ids, paper_ids, chunk_types, texts, bm25, vectorizer, tfidf_matrix):
        self.chunk_ids = chunk_ids
        self.paper_ids = paper_ids
        self.chunk_types = chunk_types
        self.texts = texts
        self.bm25 = bm25
        self.vectorizer = vectorizer
        self.tfidf_matrix = tfidf_matrix
        self.id2idx = {cid: i for i, cid in enumerate(chunk_ids)}
        self._pkl_path: Optional[Path] = None   # set by lazy_load factory

    @classmethod
    def build_from_store(cls, store: SQLiteStore, output_path: str | Path):
        chunks = store.list_chunks()
        chunk_ids = [x["chunk_id"] for x in chunks]
        paper_ids = [x["paper_id"] for x in chunks]
        chunk_types = [x["chunk_type"] for x in chunks]
        texts = [x["chunk_text"] for x in chunks]

        tokenized = [tokenize(t) for t in texts]
        bm25 = BM25Okapi(tokenized)

        vectorizer = TfidfVectorizer(
            tokenizer=tokenize,
            token_pattern=None,
            lowercase=True,
            ngram_range=(1, 2),
            min_df=1,
        )
        tfidf_matrix = vectorizer.fit_transform(texts)

        obj = cls(chunk_ids, paper_ids, chunk_types, texts, bm25, vectorizer, tfidf_matrix)
        with open(output_path, "wb") as f:
            pickle.dump(obj, f)
        return obj

    @classmethod
    def load(cls, path: str | Path) -> "Retriever":
        """立即加载（保留旧行为，供 cli_build 等使用）。"""
        with open(path, "rb") as f:
            return pickle.load(f)

    @classmethod
    def lazy_load(cls, path: str | Path) -> "_LazyRetriever":
        """返回一个懒加载代理，只有第一次调用 search() 时才反序列化 pkl。

        KGPathAdapter 在 deep 管道里只需要 KG 节点/路径，KB 侧有独立的
        HybridSearcher 做 chunk 检索，所以 KG Retriever 的 1.2 GB pkl
        往往根本不需要加载，懒加载可以把 KGPathAdapter 初始化从 ~15 分降到 <1 分。
        """
        return _LazyRetriever(Path(path))

    def search(
        self,
        query: str,
        candidate_chunk_ids: Optional[List[str]] = None,
        chunk_types: Optional[List[str]] = None,
        topk: int = 60,
    ) -> List[Dict]:
        allowed = set(candidate_chunk_ids) if candidate_chunk_ids else None
        allowed_types = set(chunk_types) if chunk_types else None

        q_tokens = tokenize(query)
        bm25_scores = self.bm25.get_scores(q_tokens)

        q_vec = self.vectorizer.transform([query])
        vec_scores = cosine_similarity(q_vec, self.tfidf_matrix).reshape(-1)

        rows = []
        for i, cid in enumerate(self.chunk_ids):
            if allowed is not None and cid not in allowed:
                continue
            if allowed_types is not None and self.chunk_types[i] not in allowed_types:
                continue

            score = 0.55 * float(bm25_scores[i]) + 0.45 * float(vec_scores[i])
            rows.append({
                "chunk_id": cid,
                "paper_id": self.paper_ids[i],
                "chunk_type": self.chunk_types[i],
                "text": self.texts[i],
                "bm25_score": float(bm25_scores[i]),
                "vector_score": float(vec_scores[i]),
                "score": score,
            })

        rows.sort(key=lambda x: x["score"], reverse=True)
        return rows[:topk]


class _LazyRetriever:
    """Retriever 懒加载代理：__init__ 仅记路径，首次 search() 才 pickle.load。"""

    def __init__(self, path: Path):
        self._path = path
        self._inner: Optional[Retriever] = None

    def _load(self):
        if self._inner is None:
            import logging
            logging.getLogger(__name__).info(
                "LazyRetriever: loading %s on first use (%.0f MB)",
                self._path, self._path.stat().st_size / 1e6,
            )
            with open(self._path, "rb") as f:
                self._inner = pickle.load(f)

    def search(self, *args, **kwargs) -> List[Dict]:
        self._load()
        return self._inner.search(*args, **kwargs)

    # 透传其他属性（如 .bm25, .chunk_ids），在被直接访问时才 load
    def __getattr__(self, name: str):
        self._load()
        return getattr(self._inner, name)

