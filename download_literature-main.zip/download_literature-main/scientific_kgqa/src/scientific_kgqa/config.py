from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DATA_DIR = ROOT / "data"
ARTIFACT_DIR = ROOT / "artifacts"

DEFAULT_SCHEMA_PATH = DATA_DIR / "schema.csv"
DEFAULT_KB_PATH = DATA_DIR / "knowledge_base_new.json"
DEFAULT_DB_PATH = ARTIFACT_DIR / "kgqa.db"
DEFAULT_RETRIEVER_PATH = ARTIFACT_DIR / "retriever.pkl"

ARTIFACT_DIR.mkdir(parents=True, exist_ok=True)
