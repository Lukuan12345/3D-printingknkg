from __future__ import annotations

import json
import math
import re
from typing import Any, Dict, Iterable, List, Optional, Tuple

import jieba


CHUNK_TYPES = [
    "problem_context",
    "study_process_description",
    "design_optimization_logic",
    "physical_mechanism",
    "fabrication_process",
    "design_method",
    "influence_analysis",
]

PROTOTYPE_SOURCE_FIELDS = {
    # Mechanism-centric fields: the phrases extracted from these fact values
    # describe physical mechanisms or design principles, not geometric shapes.
    "dominant_mechanism",
    "causal_mechanism_summary",
    "impedance_matching_strategy",
    "equivalent_model",
    "optimization_method",
    "novelty",
    "contribution",
    "transmission_line_and_transfer_matrix_theory",
    "surface_impedance_or_admittance",
    # Removed (pure structural/geometric): shape_types, structure_type,
    # unit_cell_geometry, unit_cell_symmetry, layer_stack_description.
    # These produced noise like "jerusalem cross", "square patch" as Prototype
    # nodes, which don't describe mechanisms.
}

INTENT_KEYWORDS = {
    "mechanism": [
        "机理", "机制",
        "why", "reason",
        "mechanism", "mechanisms",
        "principle", "principles",
        "physical mechanism", "underlying", "enable", "enables",
    ],
    "optimization": [
        "优化", "提升", "权衡", "折中", "妥协",
        "improve", "improving", "improvement",
        "tradeoff", "trade-off", "trade off",
        "balance", "compromise",
        "optimize", "optimizing", "optimization",
        "design tradeoff", "design choice",
    ],
    "fabrication": [
        "工艺", "制造", "加工", "制备", "生产",
        # 用词干 fabricat 覆盖 fabricate / fabricated / fabricates / fabricating / fabrication
        "fabricat",
        "manufactur",  # manufacture / manufactured / manufacturing
        "process challenge", "processing", "produce", "produced",
        "deposition", "lithograph", "printing", "etching",
    ],
    "evolution": [
        "演化", "代际", "发展", "沿革", "改进", "被改进", "如何演进", "历史", "进步",
        # 用词干 evolv 覆盖 evolve / evolved / evolves / evolving / evolution
        "evolv",
        "evolution", "history", "historical",
        "improves upon", "improvement over",
        "citation", "reference", "引用",
        "from early", "to modern", "progression", "trajectory",
    ],
    "parameter_effect": [
        "参数", "影响", "敏感",
        "sensitivity", "effect of", "effects of",
        "depend", "dependence", "dependency",
        "affect", "affects", "affecting",
        "how does", "how do",  # "how does X affect Y" 模式
        "vary", "varying", "variation",
    ],
}

STOP_PHRASES = {
    "this paper",
    "paper",
    "study",
    "method",
    "result",
    "performance",
    "design",
    "analysis",
    "structure",
    "mechanism",
    "optimization",
    "current distribution",
    "equivalent circuit analysis",
}

# Regex patterns for phrases that should never become prototypes
import re as _re
_NOISE_PROTO_PATTERNS = [
    _re.compile(r"^step\s+\d+"),          # "step 1", "step 2"
    _re.compile(r"^layer\s+\d+"),          # "layer 1 rogers 5880"
    _re.compile(r"^figure\s+\d+"),
    _re.compile(r"^table\s+\d+"),
    _re.compile(r"^\d+[\.\d]*\s*(db|ghz|mhz|mm|cm|%|dB)"),  # "1 db insertion loss"
    _re.compile(r"^\["),                    # "[2100000000.0 ..."
    _re.compile(r"^\d+\.?\d*$"),           # pure number like "4.0", "1.0"
    _re.compile(r"^[-+]?\d+[\.,\d]*\s*(e[+-]\d+)?$"),  # scientific notation
    # JSON/dict fragment artifacts from knowledge base parsing
    _re.compile(r"[\[\]{}]"),              # any bracket → fragment like "7500000000.0]"
    _re.compile(r"^(value\s+num|unit|type|field)\s*:"),  # "value num: none", "unit: ω}"
    _re.compile(r"\bnum\s*:\s*(none|null|\d)"),  # "num: none", "num: 5"
]

METRIC_LIKE_HINTS = {
    "insertion_loss",
    "fractional_bandwidth",
    "angular_stability",
    "total_structure_thickness",
    "working_band_range",
    "absorptivity",
    "transmission",
    "reflection",
    "efficiency",
    "gain",
    "bandwidth",
    "thickness",
    "loss",
    "stability",
}

UNIT_ALIASES = {
    "ω": "ohm",
    "Ω": "ohm",
    "ohms": "ohm",
    "ohm": "ohm",
    "°": "deg",
    "degree": "deg",
    "degrees": "deg",
    "dimensionless": "dimensionless",
    "unitless": "dimensionless",
    "null": "",
    "none": "",
}

UNIT_SCALE = {
    # length -> mm
    "mm": ("length_mm", 1.0, "mm"),
    "cm": ("length_mm", 10.0, "mm"),
    "m": ("length_mm", 1000.0, "mm"),
    "um": ("length_mm", 0.001, "mm"),
    "μm": ("length_mm", 0.001, "mm"),
    "nm": ("length_mm", 1e-6, "mm"),
    # freq -> Hz
    "hz": ("freq_hz", 1.0, "Hz"),
    "khz": ("freq_hz", 1e3, "Hz"),
    "mhz": ("freq_hz", 1e6, "Hz"),
    "ghz": ("freq_hz", 1e9, "Hz"),
    # angle -> deg
    "deg": ("angle_deg", 1.0, "deg"),
    # resistance -> ohm
    "ohm": ("res_ohm", 1.0, "ohm"),
    # capacitance -> F
    "f": ("cap_f", 1.0, "F"),
    "mf": ("cap_f", 1e-3, "F"),
    "uf": ("cap_f", 1e-6, "F"),
    "μf": ("cap_f", 1e-6, "F"),
    "nf": ("cap_f", 1e-9, "F"),
    "pf": ("cap_f", 1e-12, "F"),
    "ff": ("cap_f", 1e-15, "F"),
    # inductance -> H
    "h": ("ind_h", 1.0, "H"),
    "mh": ("ind_h", 1e-3, "H"),
    "uh": ("ind_h", 1e-6, "H"),
    "μh": ("ind_h", 1e-6, "H"),
    "nh": ("ind_h", 1e-9, "H"),
    "ph": ("ind_h", 1e-12, "H"),
    # percentage
    "%": ("percent", 1.0, "%"),
    "percent": ("percent", 1.0, "%"),
    # dimensionless
    "dimensionless": ("dimensionless", 1.0, "dimensionless"),
    # wavelength-normalized
    "λ": ("lambda_norm", 1.0, "λ"),
}


def load_json(path: str) -> Any:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def contains_cjk(text: str) -> bool:
    return bool(re.search(r"[\u4e00-\u9fff]", text or ""))


def normalize_text(text: Any) -> str:
    if text is None:
        return ""
    s = str(text).strip().lower()
    s = s.replace("_", " ").replace("-", " ")
    s = re.sub(r"\s+", " ", s)
    s = re.sub(r"[“”\"'`]", "", s)
    return s.strip()


def normalize_key(text: Any) -> str:
    s = normalize_text(text)
    s = s.replace(" ", "_")
    s = re.sub(r"__+", "_", s)
    return s.strip("_")


def normalize_doi(doi: Any) -> Optional[str]:
    if doi is None:
        return None
    s = str(doi).strip().lower()
    s = s.replace("https://doi.org/", "").replace("http://doi.org/", "")
    s = s.replace("doi:", "").strip()
    return s or None


def normalize_title(title: Any) -> Optional[str]:
    if title is None:
        return None
    s = normalize_text(title)
    s = re.sub(r"&lt;.*?&gt;", " ", s)
    s = re.sub(r"[^a-z0-9\u4e00-\u9fff\s]", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s or None


def tokenize(text: str) -> List[str]:
    text = text or ""
    if contains_cjk(text):
        return [x.strip().lower() for x in jieba.lcut(text) if x.strip()]
    return re.findall(r"[a-zA-Z0-9_\.%°λΩ/]+", text.lower())


def infer_intent(query: str) -> str:
    q = (query or "").lower()
    counts = {}
    for intent, kws in INTENT_KEYWORDS.items():
        hits = sum(1 for k in kws if k.lower() in q)
        if hits > 0:
            counts[intent] = hits
    if not counts:
        return "mechanism"
    # evolution/fabrication/parameter_effect more specific — break ties favoring them
    # mechanism beats optimization to avoid false upgrades via generic words like 提升
    PRIORITY = ["evolution", "fabrication", "parameter_effect", "mechanism", "optimization"]
    best_count = max(counts.values())
    candidates = [i for i, c in counts.items() if c == best_count]
    for intent in PRIORITY:
        if intent in candidates:
            return intent
    return candidates[0]


def extract_year_range(query: str) -> Tuple[Optional[int], Optional[int]]:
    q = query or ""
    years = [int(x) for x in re.findall(r"(19\d{2}|20\d{2})", q)]
    if len(years) >= 2:
        return min(years), max(years)
    if len(years) == 1:
        y = years[0]
        if any(k in q.lower() for k in ["after", "since", "later than", "之后", "以后", "以来", ">="]):
            return y, None
        if any(k in q.lower() for k in ["before", "earlier than", "之前", "以前", "<="]):
            return None, y
    return None, None


def split_multi_value(text: Any) -> List[str]:
    if text is None:
        return []
    if isinstance(text, list):
        out = []
        for x in text:
            if isinstance(x, dict):
                raw = x.get("raw")
                if raw:
                    out.append(normalize_text(raw))
            else:
                s = normalize_text(x)
                if s:
                    out.append(s)
        return out
    s = str(text)
    parts = re.split(r"[;,/|]+|\band\b|\bor\b|、|，", s, flags=re.I)
    return [normalize_text(p) for p in parts if normalize_text(p)]


def safe_int(x: Any) -> Optional[int]:
    try:
        if x is None:
            return None
        return int(x)
    except Exception:
        return None


def best_count(value: Any) -> Optional[int]:
    if value is None:
        return None
    if isinstance(value, dict):
        vals = [safe_int(v) for v in value.values()]
        vals = [v for v in vals if v is not None]
        return max(vals) if vals else None
    return safe_int(value)


def infer_value_type(raw: Any) -> str:
    if raw is None:
        return "text"
    if isinstance(raw, (int, float)):
        return "numeric"
    if isinstance(raw, dict):
        if raw.get("value_num") is not None:
            return "numeric"
        return "text"
    if isinstance(raw, list):
        if raw and isinstance(raw[0], dict) and raw[0].get("value_num") is not None:
            return "numeric"
        return "categorical"

    s = str(raw).strip()
    if re.search(r"\d+\s*[-~—–]\s*\d+", s):
        return "range"
    if re.fullmatch(r"[-+]?\d+(\.\d+)?\s*[%a-zA-Z°λΩ/]*", s):
        return "numeric"
    if len(s) < 80:
        return "categorical"
    return "text"


def normalize_unit_token(unit: Any) -> Optional[str]:
    if unit is None:
        return None
    s = str(unit).strip()
    if not s:
        return None
    s = s.replace("Ω", "ohm").replace("ω", "ohm").replace("°", "deg")
    s = s.replace("μ", "μ")
    s = s.lower()
    s = UNIT_ALIASES.get(s, s)
    return s or None


def canonicalize_numeric_value(field_name: str, value: Optional[float], unit: Optional[str]) -> Tuple[Optional[float], Optional[str]]:
    if value is None:
        return None, normalize_unit_token(unit)

    unit = normalize_unit_token(unit)

    # heuristic: fractional_* fields often appear as 0.2216 or 22.16%
    f = normalize_key(field_name)
    if unit is None and "fractional" in f and 0 <= value <= 1.0:
        return value * 100.0, "%"

    if unit in UNIT_SCALE:
        _, scale, canonical_unit = UNIT_SCALE[unit]
        return value * scale, canonical_unit

    return value, unit


def parse_numeric(raw: Any, default_unit: Optional[str] = None, field_name: Optional[str] = None) -> Tuple[Optional[float], Optional[str]]:
    if raw is None:
        return None, normalize_unit_token(default_unit)

    if isinstance(raw, dict):
        if raw.get("value_num") is not None:
            v = float(raw["value_num"])
            u = raw.get("unit") or default_unit
            return canonicalize_numeric_value(field_name or "", v, u)
        raw = raw.get("raw")

    if isinstance(raw, (int, float)):
        return canonicalize_numeric_value(field_name or "", float(raw), default_unit)

    s = str(raw).strip()
    m = re.search(r"([-+]?\d+(\.\d+)?)\s*([%a-zA-Z°λΩ/μμ]+)?", s)
    if not m:
        return None, normalize_unit_token(default_unit)

    value = float(m.group(1))
    unit = m.group(3) if m.group(3) else default_unit
    return canonicalize_numeric_value(field_name or "", value, unit)


def parse_range(raw: Any, default_unit: Optional[str] = None, field_name: Optional[str] = None) -> Tuple[Optional[float], Optional[float], Optional[str]]:
    if raw is None:
        return None, None, normalize_unit_token(default_unit)

    if isinstance(raw, dict):
        if raw.get("value_num") is not None:
            v = float(raw["value_num"])
            u = raw.get("unit") or default_unit
            v2, u2 = canonicalize_numeric_value(field_name or "", v, u)
            return v2, v2, u2
        raw = raw.get("raw")

    s = str(raw).strip()
    m = re.search(r"([-+]?\d+(\.\d+)?)\s*[-~—–]\s*([-+]?\d+(\.\d+)?)\s*([%a-zA-Z°λΩ/μμ]+)?", s)
    if not m:
        v, u = parse_numeric(raw, default_unit, field_name)
        return v, v, u

    low = float(m.group(1))
    high = float(m.group(3))
    unit = m.group(5) if m.group(5) else default_unit
    low2, cu = canonicalize_numeric_value(field_name or "", low, unit)
    high2, _ = canonicalize_numeric_value(field_name or "", high, unit)
    return low2, high2, cu


def safe_mid(low: Optional[float], high: Optional[float]) -> Optional[float]:
    if low is None and high is None:
        return None
    if low is None:
        return high
    if high is None:
        return low
    return (low + high) / 2.0


def choose_source_chunk(field_name: str) -> Optional[str]:
    f = normalize_key(field_name)
    if any(k in f for k in ["mechanism", "causal"]):
        return "physical_mechanism"
    if any(k in f for k in ["optimization", "novelty", "contribution"]):
        return "design_optimization_logic"
    if any(k in f for k in ["fabrication", "process"]):
        return "fabrication_process"
    if any(k in f for k in ["influence", "sensitivity", "parameter"]):
        return "influence_analysis"
    if any(k in f for k in ["method", "strategy", "model", "shape", "structure", "symmetry"]):
        return "design_method"
    return "study_process_description"


def is_noise_prototype(phrase: str) -> bool:
    p = phrase.strip().lower()
    if any(pat.search(p) for pat in _NOISE_PROTO_PATTERNS):
        return True
    # reject if most tokens are digits/floats
    toks = p.split()
    if not toks:
        return True
    num_tokens = sum(1 for t in toks if re.fullmatch(r"[-+]?\d+[\.,\d]*(e[+-]\d+)?", t))
    if num_tokens / len(toks) > 0.5:
        return True
    return False


def extract_candidate_phrases(text: str, max_phrases: int = 8) -> List[str]:
    if not text:
        return []
    s = normalize_text(text)
    chunks = re.split(r"[.;:()\[\]\n]", s)
    phrases = []
    for c in chunks:
        toks = tokenize(c)
        if 2 <= len(toks) <= 10:
            phrase = " ".join(toks)
            if phrase not in STOP_PHRASES and len(phrase) >= 6 and not is_noise_prototype(phrase):
                phrases.append(phrase)
    seen = set()
    out = []
    for p in phrases:
        if p not in seen:
            seen.add(p)
            out.append(p)
    return out[:max_phrases]


def jaccard_text(a: str, b: str) -> float:
    ta = set(tokenize(a))
    tb = set(tokenize(b))
    if not ta or not tb:
        return 0.0
    return len(ta & tb) / len(ta | tb)


def prototype_signature(phrase: str) -> str:
    toks = [
        t for t in tokenize(phrase)
        if t not in STOP_PHRASES and len(t) >= 2 and not t.isdigit()
    ]
    toks = sorted(set(toks))
    return " ".join(toks[:6])


def log_squash(x: float) -> float:
    if x <= 0:
        return 0.0
    return min(1.0, math.log(1.0 + x) / math.log(10.0))


def iter_kb_records(kb_obj: Any) -> Iterable[Dict[str, Any]]:
    if isinstance(kb_obj, list):
        for item in kb_obj:
            if isinstance(item, dict):
                yield item
        return

    if isinstance(kb_obj, dict):
        for key, item in kb_obj.items():
            if not isinstance(item, dict):
                continue
            obj = dict(item)
            obj.setdefault("paper_id", key)
            yield obj
        return

    raise TypeError(f"Unsupported KB type: {type(kb_obj)}")


def extract_paper_meta(item: Dict[str, Any]) -> Dict[str, Any]:
    citation_info = item.get("citation_info") or {}
    merged = citation_info.get("merged") or {}
    sources = citation_info.get("sources") or {}
    openalex = sources.get("openalex") or {}
    s2 = sources.get("semanticscholar") or {}

    doi = normalize_doi(merged.get("doi") or item.get("doi"))
    year = safe_int(merged.get("year") or item.get("publication_year") or item.get("year"))

    return {
        "paper_id": str(item.get("paper_id")),
        "paper_title": item.get("paper_title") or str(item.get("paper_id")),
        "norm_title": normalize_title(item.get("paper_title")),
        "doi": doi,
        "norm_doi": doi,
        "year": year,
        "citation_count": best_count(merged.get("citations_count")),
        "reference_count": best_count(merged.get("references_count")),
        "openalex_id": openalex.get("id"),
        "s2_paper_id": s2.get("paperId"),
        "matched_sources_json": {
            "merged_matched_sources": merged.get("matched_sources", []),
            "openalex": {
                "matched": openalex.get("matched"),
                "lookup": openalex.get("lookup"),
            },
            "semanticscholar": {
                "matched": s2.get("matched"),
                "lookup": s2.get("lookup"),
            },
        },
    }


def extract_citation_links(item: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    统一输出：
    - relation_kind = reference: current_paper -> referenced_paper
    - relation_kind = citation: citing_paper -> current_paper
    """
    out: List[Dict[str, Any]] = []
    seen = set()

    paper_id = str(item.get("paper_id"))
    citation_info = item.get("citation_info") or {}
    merged = citation_info.get("merged") or {}
    sources = citation_info.get("sources") or {}

    current_doi = normalize_doi(merged.get("doi"))
    current_year = safe_int(merged.get("year"))
    current_title = item.get("paper_title")

    for provider, payload in sources.items():
        if not isinstance(payload, dict):
            continue

        for ref in payload.get("references") or []:
            dst_title = ref.get("title")
            dst_doi = normalize_doi(ref.get("doi"))
            dst_year = safe_int(ref.get("year"))

            dedup_key = ("reference", dst_doi or normalize_title(dst_title), dst_year)
            if dedup_key in seen:
                continue
            seen.add(dedup_key)

            out.append({
                "relation_kind": "reference",
                "provider": provider,
                "src_paper_id": paper_id,
                "src_title": current_title,
                "src_doi": current_doi,
                "src_year": current_year,
                "dst_title": dst_title,
                "dst_doi": dst_doi,
                "dst_year": dst_year,
            })

        for cit in payload.get("citations") or []:
            src_title = cit.get("title")
            src_doi = normalize_doi(cit.get("doi"))
            src_year = safe_int(cit.get("year"))

            dedup_key = ("citation", src_doi or normalize_title(src_title), src_year)
            if dedup_key in seen:
                continue
            seen.add(dedup_key)

            out.append({
                "relation_kind": "citation",
                "provider": provider,
                "src_paper_id": None,
                "src_title": src_title,
                "src_doi": src_doi,
                "src_year": src_year,
                "dst_paper_id": paper_id,
                "dst_title": current_title,
                "dst_doi": current_doi,
                "dst_year": current_year,
            })

    return out


def guess_opt_direction(field_name: str, schema_opt_direction: Optional[str] = None) -> str:
    if schema_opt_direction and str(schema_opt_direction).lower() in {"maximize", "minimize", "target", "none"}:
        return str(schema_opt_direction).lower()

    f = normalize_key(field_name)
    if any(k in f for k in ["loss", "thickness", "roughness", "reflection"]):
        return "minimize"
    if any(k in f for k in ["bandwidth", "stability", "absorptivity", "transmission", "efficiency", "gain"]):
        return "maximize"
    return "none"


def is_metric_like_field(field_name: str) -> bool:
    f = normalize_key(field_name)
    if f in METRIC_LIKE_HINTS:
        return True
    return any(k in f for k in METRIC_LIKE_HINTS)
