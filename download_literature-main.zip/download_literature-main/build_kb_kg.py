#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_kb_kg.py —— 步骤 ⑧：把步骤 ⑦ 产出的 knowledge_base.json + 步骤 ⑥ 产出的 schema CSV
喂给 KB（向量库 / kb_mvp）+ KG（知识图谱 / scientific_kgqa）双轨知识底座。

衔接关系：
    步骤 ⑥  schema_gen        →  refined_schema_*.csv
    步骤 ⑦  llm_extract       →  knowledge_base.json
                                      ↓
              ┌────────────────────────┴─────────────────────────┐
              ▼                                                  ▼
    KB / 向量检索（kb_mvp）                          KG / 图谱（scientific_kgqa）
      • 切 chunks（7 个叙述字段）                     • 实体 + 关系抽取
      • BGE-M3 embedding → FAISS                      • 子图存 SQLite
      • jieba BM25 倒排                               • 检索器 retriever.pkl
      • 输出：kb_mvp/data/kb.db + kb_mvp/index/
                                      ↓
              步骤 ⑨  retrieval_integration / _test_server.py / server.py
                          双轨检索 + RAG 生成式问答

凭据走 CLI（与 generate_keywords.py 一致），不需要预先 export：
  • Embedding（BAAI/bge-m3）：默认 `--embed-base-url http://35.220.164.252:3888`，
    `--embed-api-key` 缺省时从 `.env` 的 EMBED_API_KEY 读取。
  • LLM（与 generate_keywords.py / llm_extract 同一个网关）：默认
    `--llm-base-url http://43.153.42.7:3001/v1`，`--llm-api-key` 缺省读 LLM_API_KEY。
  • KG cli_build 内部读的 ANTHROPIC_BASE_URL / ANTHROPIC_AUTH_TOKEN 自动复用 LLM 同一对，
    不需要重复传。

用法：
    # 一键全量构建（KB + KG），凭据走 .env：
    python build_kb_kg.py \
        --kb-json   ./output/knowledge_base.json \
        --schema    ./schema_output/allylic_amination/refined_schema_allylic_amination.csv \
        --force

    # 凭据走 CLI（不依赖 .env）：
    python build_kb_kg.py \
        --kb-json   ./output/knowledge_base.json \
        --schema    ./schema_output/.../refined_schema.csv \
        --embed-api-key sk-xxx \
        --llm-api-key   sk-yyy \
        --llm-model     gemini-3.1-pro-preview \
        --force

    # 只建 KB / 只建 KG：
    python build_kb_kg.py --kb-json ... --skip-kg --force
    python build_kb_kg.py --kb-json ... --schema ... --skip-kb

    # 用 fast_ingest（本地 BGE-M3 模型）替代 kb_mvp.src.ingest：
    python build_kb_kg.py --kb-json ... --skip-kg --use-fast-ingest
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

from env_bootstrap import load_env
load_env()

PROJECT_ROOT = Path(__file__).resolve().parent

# ─── kb_mvp 默认期望的输入路径（kb_mvp/src/config.py 里硬编码） ───────────────
KB_MVP_KB_JSON_DEFAULT = PROJECT_ROOT / "scientific_kgqa" / "data" / "knowledge_base.json"
KB_MVP_SCHEMA_DEFAULT  = PROJECT_ROOT / "scientific_kgqa" / "data" / "schema.csv"

# ─── 可移植内容库：建库时把每篇 full.md + pdf 拷进来，按 paper_id 归档 ──────────
# 让查询期溯源（md 全文 / PDF 下载）不再依赖步骤④原始解析目录的绝对路径，
# 跨机部署 / 原目录被移走也照常可下。EvidenceResolver 查询期优先读这里。
CONTENT_STORE_DEFAULT  = PROJECT_ROOT / "scientific_kgqa" / "data" / "content_store"

# ─── scientific_kgqa 输出 ─────────────────────────────────────────────────────
KG_DEFAULT_DB        = PROJECT_ROOT / "scientific_kgqa" / "artifacts" / "kgqa.db"
KG_DEFAULT_RETRIEVER = PROJECT_ROOT / "scientific_kgqa" / "artifacts" / "retriever.pkl"

# ─── KG 引导词配置默认路径（航天电磁示例 = 默认；换领域复制改后用 --kg-prompts 覆盖）──
KG_DEFAULT_PROMPTS   = PROJECT_ROOT / "scientific_kgqa" / "configs" / "prompts_em.yaml"

# ─── 凭据默认值（与 generate_keywords.py / llm_extract 保持一致） ─────────────
DEFAULT_EMBED_BASE_URL = "http://35.220.164.252:3888"
DEFAULT_LLM_BASE_URL   = "http://43.153.42.7:3001/v1"
DEFAULT_LLM_MODEL      = "gemini-3.1-pro-preview"


def _stage_inputs(kb_json: Path, schema_csv: Path | None) -> None:
    """把用户指定的 KB JSON / Schema CSV 拷到 kb_mvp + scientific_kgqa 期望的默认位置。

    kb_mvp 没有 CLI 参数覆盖路径，所以必须把文件落到默认位置。
    重复路径自动跳过。
    """
    KB_MVP_KB_JSON_DEFAULT.parent.mkdir(parents=True, exist_ok=True)

    if kb_json.resolve() != KB_MVP_KB_JSON_DEFAULT.resolve():
        print(f"[stage] copy {kb_json}  →  {KB_MVP_KB_JSON_DEFAULT}")
        shutil.copy2(kb_json, KB_MVP_KB_JSON_DEFAULT)

    if schema_csv is not None:
        if schema_csv.resolve() != KB_MVP_SCHEMA_DEFAULT.resolve():
            print(f"[stage] copy {schema_csv}  →  {KB_MVP_SCHEMA_DEFAULT}")
            shutil.copy2(schema_csv, KB_MVP_SCHEMA_DEFAULT)


def _materialize_content_store(kb_json: Path, store_root: Path,
                               *, push_remote: bool = False,
                               prune_local: bool = False,
                               remote_base: str | None = None,
                               remote_prefix: str | None = None) -> None:
    """把每篇论文的 full.md + 同目录 PDF 拷进可移植内容库（按 paper_id 归档）。

    动机：knowledge_base.json 里的 `source.source_ref` 是步骤④解析目录的**绝对路径**，
    跨机部署或原目录被移走后查询期就定位不到源文。建库时（语料还在）把全文 + PDF
    复制进 `scientific_kgqa/data/content_store/<paper_id>/`，artifacts 自包含、可随部署
    一起搬走。查询期 EvidenceResolver 优先读这里，原始路径只作最后兜底。

    远程模式（代码放本地、大产物放远程对象存储）：
      • push_remote=True：物化到本地后 `rclone copy` 增量同步到远程 Ceph 桶
        （复用步骤⑤的 `xlc-hdd2:hangtian-kxfx`，零新依赖/凭据）。
      • prune_local=True：上传成功后删掉本地 full.md/pdf，只留目录骨架，省本地磁盘；
        查询期 server 按需从远程拉回缓存。仅在 push_remote 成功时才会删。

    幂等：目标已存在且非空则跳过；找不到源文件只 warn，不中断建库。
    """
    try:
        with open(kb_json, "r", encoding="utf-8") as f:
            kb = json.load(f)
    except Exception as e:
        print(f"[content_store][warn] 读 KB JSON 失败，跳过物化: {e}")
        return

    if not isinstance(kb, dict):
        print("[content_store][warn] KB JSON 不是 dict，跳过物化")
        return

    store_root.mkdir(parents=True, exist_ok=True)
    n_md, n_pdf, n_miss = 0, 0, 0
    for top_key, paper in kb.items():
        if not isinstance(paper, dict):
            continue
        paper_id = paper.get("paper_id") or top_key
        source = paper.get("source") or {}
        source_ref = source.get("source_ref", "") if isinstance(source, dict) else ""
        if not paper_id or not source_ref:
            continue

        src = Path(source_ref)
        # source_ref 既可能是目录（含 full.md + pdf），也可能是单个 .md 文件
        md_src, pdf_srcs = None, []
        try:
            if src.is_dir():
                cand = src / "full.md"
                md_src = cand if cand.exists() else None
                pdf_srcs = sorted(src.glob("*.pdf"))
            elif src.is_file() and src.suffix.lower() == ".md":
                md_src = src
                pdf_srcs = sorted(src.parent.glob("*.pdf"))
        except OSError:
            pass

        if md_src is None and not pdf_srcs:
            n_miss += 1
            continue

        dest_dir = store_root / paper_id
        dest_dir.mkdir(parents=True, exist_ok=True)
        manifest_md = False
        manifest_pdfs: list[str] = []
        if md_src is not None:
            dest_md = dest_dir / "full.md"
            manifest_md = True
            if not dest_md.exists():
                try:
                    shutil.copy2(md_src, dest_md)
                    n_md += 1
                except OSError as e:
                    print(f"[content_store][warn] 拷 md 失败 {paper_id}: {e}")
        for pdf in pdf_srcs:
            dest_pdf = dest_dir / pdf.name
            manifest_pdfs.append(pdf.name)
            if not dest_pdf.exists():
                try:
                    shutil.copy2(pdf, dest_pdf)
                    n_pdf += 1
                except OSError as e:
                    print(f"[content_store][warn] 拷 pdf 失败 {paper_id}: {e}")
        # 每篇写一份 _manifest.json（很小，prune 后仍保留）：记录这篇有哪些文件，
        # 查询期 resolver 据此知道远程有什么、不必每次 list 远端。
        try:
            (dest_dir / "_manifest.json").write_text(
                json.dumps({"md": manifest_md, "pdfs": manifest_pdfs},
                           ensure_ascii=False),
                encoding="utf-8",
            )
        except OSError:
            pass

    print(f"[content_store] 物化完成 → {store_root}")
    print(f"[content_store]   full.md: +{n_md}  pdf: +{n_pdf}  源文件缺失: {n_miss} 篇")
    if n_miss:
        print(f"[content_store][note] {n_miss} 篇找不到本地源文（source_ref 失效）；"
              "这些论文查询期仍有 doi/year/引用，只是缺源文全文/PDF。")

    # ── 远程上传（rclone → Ceph 桶）+ 可选清本地 ────────────────────────────────
    if not push_remote:
        return
    from content_store_remote import (
        push_store, DEFAULT_REMOTE_BASE, DEFAULT_REMOTE_PREFIX,
    )
    rb = remote_base or DEFAULT_REMOTE_BASE
    rp = remote_prefix or DEFAULT_REMOTE_PREFIX
    ok = push_store(store_root, remote_base=rb, remote_prefix=rp)
    if not ok:
        print("[content_store][warn] 远程上传未成功，保留本地内容库（不清理）。"
              "查询期仍可读本地；修好 rclone/远端后可加 --skip-kb --skip-kg 单独重跑上传。")
        return
    print(f"[content_store] 远程副本就绪 → {rb.rstrip('/')}/{rp.strip('/')}/<paper_id>/")
    if prune_local:
        n_del = 0
        for sub in store_root.iterdir():
            if not sub.is_dir():
                continue
            for f in list(sub.glob("full.md")) + list(sub.glob("*.pdf")):
                try:
                    f.unlink()
                    n_del += 1
                except OSError:
                    pass
        print(f"[content_store] 已清本地大文件 {n_del} 个（远程已留底，查询期按需拉回缓存）")


def _credential_env(args: argparse.Namespace) -> dict:
    """把 CLI 凭据折成环境变量字典，喂给 subprocess。

    kb_mvp/src/config.py 完全靠 os.environ 读凭据；scientific_kgqa.cli_build
    既能 CLI 覆盖也能 env 兜底。统一从这里下发，避免到处传。
    ANTHROPIC_BASE_URL / ANTHROPIC_AUTH_TOKEN 直接复用 LLM 那一对，不另开参数。
    """
    return {
        "EMBED_BASE_URL":     args.embed_base_url,
        "EMBED_API_KEY":      args.embed_api_key or "",
        "LLM_BASE_URL":       args.llm_base_url,
        "LLM_API_KEY":        args.llm_api_key or "",
        "LLM_MODEL":          args.llm_model,
        # KG cli_build 兜底读这两个；用同一对凭据
        "ANTHROPIC_BASE_URL": args.llm_base_url,
        "ANTHROPIC_AUTH_TOKEN": args.llm_api_key or "",
    }


def _run(cmd: list[str], *, cwd: Path = PROJECT_ROOT, extra_env: dict | None = None) -> None:
    env = os.environ.copy()
    if extra_env:
        env.update(extra_env)
    pretty = " ".join(repr(c) if " " in c else c for c in cmd)
    print(f"\n[exec] {pretty}\n[cwd]  {cwd}")
    proc = subprocess.run(cmd, cwd=str(cwd), env=env)
    if proc.returncode != 0:
        sys.exit(f"[FAIL] command exited with code {proc.returncode}: {pretty}")


def _push_build_artifacts(args: argparse.Namespace) -> bool:
    """建库完成后把向量索引、图谱 DB、知识库 DB 批量推到远程 Ceph 桶。

    远程布局（桶内）：
      <artifacts-prefix>/kb_index/   ← kb_mvp/index/*
      <artifacts-prefix>/kb_data/    ← kb_mvp/data/*
      <artifacts-prefix>/kgqa/       ← scientific_kgqa/artifacts/*
    """
    from content_store_remote import push_artifacts

    dirs: list[tuple[Path, str]] = []
    if not args.skip_kb:
        from kb_mvp.src import config as kb_cfg
        dirs.append((Path(kb_cfg.INDEX_DIR), "kb_index"))
        dirs.append((Path(kb_cfg.DATA_DIR),  "kb_data"))
    if not args.skip_kg:
        kg_artifact_dir = Path(args.kg_db).resolve().parent
        dirs.append((kg_artifact_dir, "kgqa"))

    if not dirs:
        print("[artifacts] 没有需要上传的产物目录，跳过")
        return True

    print("\n" + "=" * 70)
    print("[artifacts] 上传构建产物 → 远程 Ceph 桶")
    print(f"  桶:     {args.remote_base.rstrip('/')}/{args.artifacts_prefix.strip('/')}/")
    for ld, sd in dirs:
        print(f"  {ld}  →  {sd}/")
    print("=" * 70)

    ok = push_artifacts(
        dirs,
        remote_base=args.remote_base,
        remote_prefix=args.artifacts_prefix,
    )
    return ok


def _prune_build_artifacts(args: argparse.Namespace) -> None:
    """上传成功后删除本地大产物文件，省磁盘。

    删除（GB 级，可从远端还原）：
      faiss.index / bm25.pkl / embeddings.npy / kb.db / kgqa.db / retriever.pkl
    保留（供下次增量构建，数 MB~数十 MB，无需重算）：
      kb_mvp/index/embedding_cache.json    ← embedding 缓存
      kb_mvp/index/chunk_ids.json          ← chunk 映射（很小）
      scientific_kgqa/artifacts/llm_cache.json ← LLM 抽取缓存
    """
    from kb_mvp.src import config as kb_cfg

    to_delete: list[Path] = []
    if not args.skip_kb:
        to_delete += [
            Path(kb_cfg.FAISS_INDEX_PATH),
            Path(kb_cfg.BM25_INDEX_PATH),
            Path(kb_cfg.EMBEDDINGS_PATH),
            Path(kb_cfg.DB_PATH),
        ]
    if not args.skip_kg:
        to_delete += [
            Path(args.kg_db).resolve(),
            Path(args.kg_retriever).resolve(),
        ]

    print("\n[artifacts][prune] 清除本地大产物文件...")
    deleted, freed_mb = 0, 0.0
    for p in to_delete:
        if p.exists():
            size_mb = p.stat().st_size / 1_048_576
            try:
                p.unlink()
                print(f"  删除 {p.name}  ({size_mb:.0f} MB)")
                freed_mb += size_mb
                deleted += 1
            except OSError as e:
                print(f"  [warn] 删除失败 {p}: {e}")
    print(f"[artifacts][prune] 共删除 {deleted} 个文件，释放约 {freed_mb:.0f} MB")
    print("  保留: embedding_cache.json / chunk_ids.json / llm_cache.json（增量构建用）")


def build_kb(args: argparse.Namespace) -> None:
    """走 kb_mvp.src.ingest（或 fast_ingest.py）：建 SQLite + FAISS + BM25。"""
    print("\n" + "=" * 70)
    print("[KB] 向量检索库构建（kb_mvp）")
    print(f"     embed: {args.embed_base_url}")
    print("=" * 70)

    extra_env = _credential_env(args)

    if args.use_fast_ingest:
        cmd = [sys.executable, str(PROJECT_ROOT / "fast_ingest.py")]
        if args.force:
            cmd.append("--force")
        if args.incremental:
            cmd.append("--incremental")
        if args.kb_json:
            cmd += ["--kb-json", str(args.kb_json)]
        _run(cmd, extra_env=extra_env)
        return

    # 标准路径：python -m kb_mvp.src.ingest [--force | --incremental]
    cmd = [sys.executable, "-m", "kb_mvp.src.ingest"]
    if args.force:
        cmd.append("--force")
    if args.incremental:
        cmd.append("--incremental")
    _run(cmd, extra_env=extra_env)


def build_kg(args: argparse.Namespace) -> None:
    """走 scientific_kgqa.cli_build：建图 + 检索器。"""
    print("\n" + "=" * 70)
    print("[KG] 知识图谱构建（scientific_kgqa）")
    print(f"     llm:   {args.llm_base_url}  model={args.llm_model}")
    print("=" * 70)

    # scientific_kgqa 是 src/ layout，未安装时走 PYTHONPATH 注入
    extra_env = _credential_env(args)
    extra_env["PYTHONPATH"] = os.pathsep.join([
        str(PROJECT_ROOT / "scientific_kgqa" / "src"),
        os.environ.get("PYTHONPATH", ""),
    ]).rstrip(os.pathsep)

    cmd = [
        sys.executable, "-m", "scientific_kgqa.cli_build",
        "--kb",     str(args.kb_json),
        "--schema", str(args.schema),
        "--db",     str(args.kg_db),
        "--retriever", str(args.kg_retriever),
        "--llm-base-url", args.llm_base_url,
        "--llm-model",    args.llm_model,
    ]
    if args.llm_api_key:
        cmd += ["--llm-api-key", args.llm_api_key]
    if args.domain_prefer_file:
        cmd += ["--domain-prefer-file", str(args.domain_prefer_file)]
    # KG 引导词：始终显式下传（默认 = 出货 prompts_em.yaml）。
    # 文件不存在时不传，让 cli_build 回退内置中立模板而非报错。
    if args.kg_prompts:
        if Path(args.kg_prompts).exists():
            cmd += ["--kg-prompts", str(args.kg_prompts)]
        else:
            print(f"[warn] --kg-prompts 文件不存在，回退内置中立模板: {args.kg_prompts}")
    if args.kg_reset or args.force:
        cmd.append("--reset")
    if args.no_llm:
        cmd.append("--no-llm")
    if args.llm_workers:
        cmd += ["--llm-workers", str(args.llm_workers)]

    _run(cmd, extra_env=extra_env)


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="把 step⑦ 的 knowledge_base.json 同步到 KB(向量库) + KG(图谱) 双轨底座",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p.add_argument("--kb-json", type=Path, required=True,
                   help="step⑦ llm_extract 产出的 knowledge_base.json 路径")
    p.add_argument("--schema",  type=Path,
                   help="step⑥ schema_gen 产出的 refined_schema_*.csv（建 KG 必需，建 KB 可选）")
    p.add_argument("--domain-prefer-file", type=Path,
                   help="step⑥⑦ 用的 domain_prefer/<project>.txt；建 KG 时注入 LLM 抽取 prompt 做"
                        "领域偏向（缺省则用纯通用 prompt，结果仍可用）")
    p.add_argument("--kg-prompts", type=Path, default=KG_DEFAULT_PROMPTS,
                   help=f"KG 引导词配置 YAML（默认 {KG_DEFAULT_PROMPTS} = EM 示例）；"
                        "建图取其 concept_extraction.system 作抽取 system 基底。"
                        "换领域时复制改措辞后用此参数指定")

    # 范围控制
    p.add_argument("--skip-kb", action="store_true", help="跳过向量库构建（kb_mvp）")
    p.add_argument("--skip-kg", action="store_true", help="跳过知识图谱构建（scientific_kgqa）")
    p.add_argument("--force",   action="store_true", help="KB / KG 全量重建（清空旧库）")

    # 可移植内容库（源文全文 / PDF 物化）
    p.add_argument("--content-store", type=Path, default=CONTENT_STORE_DEFAULT,
                   help=f"可移植内容库输出目录，默认 {CONTENT_STORE_DEFAULT}；建库时把每篇 "
                        "full.md + pdf 按 paper_id 归档进来，查询期溯源不再依赖原始解析目录")
    p.add_argument("--skip-content-store", action="store_true",
                   help="不物化内容库（查询期溯源回退原始 source_ref 绝对路径，跨机可能失效）")
    # 远程后端（代码本地、大产物放远程对象存储；复用步骤⑤的 rclone 远端）
    p.add_argument("--content-store-remote", action="store_true",
                   help="物化后 rclone copy 增量上传到远程 Ceph 桶（复用步骤⑤远端，零新依赖/凭据）")
    p.add_argument("--prune-local", action="store_true",
                   help="配合 --content-store-remote：上传成功后删本地 full.md/pdf 省磁盘，"
                        "查询期 server 按需从远程拉回缓存（仅上传成功才清）")
    p.add_argument("--remote-base", default=os.environ.get("CONTENT_STORE_REMOTE",
                                                            "xlc-hdd2:hangtian-kxfx"),
                   help="rclone 远端:桶，默认 xlc-hdd2:hangtian-kxfx（或 CONTENT_STORE_REMOTE）；"
                        "content_store 与 artifacts 共用同一个桶，由 --remote-prefix / "
                        "--artifacts-prefix 在桶内隔离")
    p.add_argument("--remote-prefix", default=os.environ.get("CONTENT_STORE_REMOTE_PREFIX",
                                                             "content_store"),
                   help="远程桶内前缀，默认 content_store（或 CONTENT_STORE_REMOTE_PREFIX）；"
                        "完整路径 = <remote-base>/<remote-prefix>/<paper_id>/")
    p.add_argument("--push-artifacts", action="store_true",
                   help="建库/建图完成后把向量索引、图谱 DB、知识库 DB 等大产物推到远程 Ceph 桶"
                        "（复用 --remote-base 的桶，前缀由 --artifacts-prefix 控制）")
    p.add_argument("--prune-artifacts", action="store_true",
                   help="配合 --push-artifacts：上传成功后删除本地大产物文件"
                        "（faiss.index / bm25.pkl / embeddings.npy / kb.db / kgqa.db / retriever.pkl），"
                        "保留 llm_cache.json 和 embedding_cache.json 供下次增量构建；"
                        "server 启动时设 PULL_ARTIFACTS=1 自动从远端拉回")
    p.add_argument("--artifacts-prefix",
                   default=os.environ.get("ARTIFACTS_REMOTE_PREFIX", "artifacts"),
                   help="产物在桶内的前缀目录，默认 artifacts（或 ARTIFACTS_REMOTE_PREFIX）；"
                        "完整路径 = <remote-base>/artifacts/kb_index/faiss.index 等")

    # ─── 凭据：embedding（BAAI/bge-m3）─────────────────────────────────────────
    p.add_argument("--embed-base-url",
                   default=os.environ.get("EMBED_BASE_URL", DEFAULT_EMBED_BASE_URL),
                   help=f"BGE-M3 embedding 服务 URL（默认 {DEFAULT_EMBED_BASE_URL}，"
                        "或读 EMBED_BASE_URL 环境变量）")
    p.add_argument("--embed-api-key",
                   default=os.environ.get("EMBED_API_KEY", ""),
                   help="BGE-M3 embedding API Key（默认读 .env 的 EMBED_API_KEY）")

    # ─── 凭据：LLM（与 gen_key 其余脚本一致）──────────────────────────────────
    p.add_argument("--llm-base-url",
                   default=os.environ.get("LLM_BASE_URL", DEFAULT_LLM_BASE_URL),
                   help=f"LLM 服务 URL（默认 {DEFAULT_LLM_BASE_URL}，或读 LLM_BASE_URL）")
    p.add_argument("--llm-api-key",
                   default=os.environ.get("LLM_API_KEY", ""),
                   help="LLM API Key（默认读 LLM_API_KEY 环境变量；ANTHROPIC_BASE_URL / "
                        "ANTHROPIC_AUTH_TOKEN 自动复用同一对，不另开参数）")
    p.add_argument("--llm-model",
                   default=os.environ.get("LLM_MODEL", DEFAULT_LLM_MODEL),
                   help=f"LLM 模型名（默认 {DEFAULT_LLM_MODEL}，与 generate_keywords.py 一致）")

    # KB 选项
    p.add_argument("--use-fast-ingest", action="store_true",
                   help="用 fast_ingest.py（本地 BGE-M3 模型）替代 kb_mvp.src.ingest；"
                        "本地模型缺失时 sentence-transformers 会自动从 HuggingFace 拉 BAAI/bge-m3，"
                        "也可先 `huggingface-cli download BAAI/bge-m3 --local-dir retrieval_weights/models/bge-m3` 预下")
    p.add_argument("--incremental", action="store_true",
                   help="KB 增量：DB 已有的 chunk 跳过，只 embed 新增 chunk（旧向量走 embedding 缓存复用），"
                        "再用全量 chunks 重建 FAISS + BM25。远程 API 与 fast_ingest 两条路径都支持。与 --force 互斥")

    # KG 选项
    p.add_argument("--kg-db",        type=Path, default=KG_DEFAULT_DB,
                   help=f"KG SQLite 输出路径，默认 {KG_DEFAULT_DB}")
    p.add_argument("--kg-retriever", type=Path, default=KG_DEFAULT_RETRIEVER,
                   help=f"KG retriever pickle 输出路径，默认 {KG_DEFAULT_RETRIEVER}")
    p.add_argument("--kg-reset",     action="store_true", help="只重置 KG（独立于 --force）")
    p.add_argument("--no-llm",       action="store_true", help="KG 构建跳过 LLM 实体/关系抽取")
    p.add_argument("--llm-workers",  type=int, help="KG LLM 抽取并发数（默认 1）")

    return p.parse_args(argv)


def main() -> None:
    args = parse_args()

    if not args.kb_json.exists():
        sys.exit(f"[FAIL] knowledge_base.json 不存在: {args.kb_json}")

    if args.force and args.incremental:
        sys.exit("[FAIL] --force 与 --incremental 互斥：--force 全量重建，--incremental 只加新增")

    if not args.skip_kg and args.schema is None:
        sys.exit("[FAIL] 构建 KG 需要 --schema (refined_schema_*.csv)，或加 --skip-kg")

    if args.schema is not None and not args.schema.exists():
        sys.exit(f"[FAIL] schema CSV 不存在: {args.schema}")

    if not args.skip_kb and not args.embed_api_key:
        sys.exit("[FAIL] 缺 --embed-api-key（或 .env 的 EMBED_API_KEY）；建 KB 需要 BGE-M3 凭据")
    if not args.skip_kg and not args.llm_api_key and not args.no_llm:
        sys.exit("[FAIL] 缺 --llm-api-key（或 .env 的 LLM_API_KEY）；KG LLM 抽取需要凭据，"
                 "或加 --no-llm 跳过 LLM 抽取")

    # 把输入摆到 kb_mvp / scientific_kgqa 默认位置（kb_mvp 没法靠 CLI 覆盖）
    _stage_inputs(args.kb_json.resolve(), args.schema.resolve() if args.schema else None)

    # 物化可移植内容库（full.md + pdf），让查询期溯源不依赖原始解析目录路径
    if not args.skip_content_store:
        print("\n" + "=" * 70)
        print("[content_store] 物化源文全文 / PDF → 可移植内容库")
        if args.content_store_remote:
            print(f"     远程后端: {args.remote_base.rstrip('/')}/"
                  f"{args.remote_prefix.strip('/')}/  "
                  f"（{'上传后清本地' if args.prune_local else '上传+保留本地缓存'}）")
        print("=" * 70)
        _materialize_content_store(
            args.kb_json.resolve(), args.content_store.resolve(),
            push_remote=args.content_store_remote,
            prune_local=args.prune_local,
            remote_base=args.remote_base,
            remote_prefix=args.remote_prefix,
        )
    else:
        print("\n[skip] --skip-content-store：不物化内容库（查询期溯源将回退原始路径）")

    if not args.skip_kb:
        build_kb(args)
    else:
        print("\n[skip] --skip-kb：跳过向量库构建")

    if not args.skip_kg:
        build_kg(args)
    else:
        print("\n[skip] --skip-kg：跳过图谱构建")

    # ── 远程产物上传（可选）────────────────────────────────────────────────────
    if args.push_artifacts:
        ok = _push_build_artifacts(args)
        if ok and args.prune_artifacts:
            _prune_build_artifacts(args)
        elif args.prune_artifacts and not ok:
            print("[artifacts][warn] 上传未完全成功，跳过本地文件清除以防数据丢失")

    print("\n" + "=" * 70)
    print("[OK] KB + KG 双轨底座构建完成")
    if not args.skip_kb:
        if args.push_artifacts and args.prune_artifacts:
            print("  KB (向量库): 已上传至远程 Ceph，本地大文件已清除")
        else:
            print("  KB (向量库): kb_mvp/data/kb.db + kb_mvp/index/{faiss.index, bm25.pkl, ...}")
    if not args.skip_kg:
        if args.push_artifacts and args.prune_artifacts:
            print("  KG (图谱):  已上传至远程 Ceph，本地大文件已清除")
        else:
            print(f"  KG (图谱):  {args.kg_db}")
            print(f"             {args.kg_retriever}")
    if not args.skip_content_store:
        print(f"  内容库:     {args.content_store}（源文全文 + PDF，查询期溯源可移植）")
    if args.push_artifacts:
        rb = args.remote_base.rstrip("/")
        ap = args.artifacts_prefix.strip("/")
        print(f"  远程产物:   {rb}/{ap}/{{kb_index, kb_data, kgqa}}/")
    print("\n下一步：")
    if args.push_artifacts and args.prune_artifacts:
        print("  • server 端设 PULL_ARTIFACTS=1 后启服务，自动从 Ceph 拉取产物")
    print("  • 启 HTTP 服务:  python server.py   （或调试用 python _test_server.py）")
    print("  • 命令行问答:    python -m retrieval_integration.scripts.run_query \"你的问题\"")
    print("=" * 70)


if __name__ == "__main__":
    main()
