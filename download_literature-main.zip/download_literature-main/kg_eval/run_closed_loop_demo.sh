#!/usr/bin/env bash
# =============================================================================
# 步骤 ⑩ 真实数据闭环测试：出题 → 图谱问答 → 四维测评 → 出报告
#
# 领域：aerospace.supermaterial（真实图谱 kgqa.db，19934 篇 / 80839 概念）
# 你只需运行本脚本；它会逐步打印进度。失败处会停下并给出提示。
#
# 用法：
#   bash kg_eval/run_closed_loop_demo.sh                 # 默认小规模闭环（每领域1题）
#   NUM_PER_DOMAIN=2 HOPS=1,2,3,4 bash kg_eval/run_closed_loop_demo.sh
#   SKIP_GEN=1 bash kg_eval/run_closed_loop_demo.sh      # 跳过出题，复用已有题目直接测评
#   LIMIT=10 bash kg_eval/run_closed_loop_demo.sh        # 只测评前 10 题（省时）
# =============================================================================
set -euo pipefail

# ── 0. 定位仓库根（本脚本在 gen_key/kg_eval/ 下）─────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
GEN_KEY="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$GEN_KEY"
echo "[0] 仓库根: $GEN_KEY"

# 可调参数（均可用环境变量覆盖）
DB="${DB:-$GEN_KEY/scientific_kgqa/artifacts/kgqa.db}"
RETRIEVER="${RETRIEVER:-$GEN_KEY/scientific_kgqa/artifacts/retriever.pkl}"
EXTERN_DIR="${EXTERN_DIR:-$GEN_KEY/kg_eval/qag/extern_data_aerospace}"
QUESTIONS_DIR="${QUESTIONS_DIR:-$GEN_KEY/kg_eval/qag/output}"
OUT_DIR="${OUT_DIR:-$GEN_KEY/kg_eval/output}"
HOPS="${HOPS:-1,2,3}"
DOMAINS="${DOMAINS:-FABS,HCFG,MECH,POPT}"
NUM_PER_DOMAIN="${NUM_PER_DOMAIN:-1}"
PAPER_RANGE="${PAPER_RANGE:-2-3}"
LIMIT="${LIMIT:-}"
SKIP_GEN="${SKIP_GEN:-0}"

# ── 1. 载入 .env（LLM / KG_LLM / EMBED 凭据）────────────────────────────────
if [ -f "$GEN_KEY/.env" ]; then
  set -a; . "$GEN_KEY/.env"; set +a
  echo "[1] 已载入 .env"
else
  echo "[1][warn] 未找到 $GEN_KEY/.env —— LLM 相关步骤会降级。可从 .env.example 拷贝填写。"
fi

# QAG 出题脚本读 QAG_* 环境变量；把 .env 的 LLM_* 映射过去（base_url 补 /v1 给 OpenAI 客户端）
export QAG_API_KEY="${QAG_API_KEY:-${LLM_API_KEY:-}}"
_qag_base="${QAG_LLM_BASE_URL:-${LLM_BASE_URL:-}}"
case "$_qag_base" in
  */v1|*/v1/) : ;;                       # 已带 /v1
  "" ) : ;;
  * ) _qag_base="${_qag_base%/}/v1" ;;   # OpenAI 客户端需要 /v1
esac
export QAG_LLM_BASE_URL="$_qag_base"
export QAG_LLM_MODEL="${QAG_LLM_MODEL:-${LLM_MODEL:-claude-sonnet-4-6}}"

# ── 2. 依赖检查 ─────────────────────────────────────────────────────────────
echo "[2] 检查 scientific_kgqa 是否可导入..."
if ! python -c "import scientific_kgqa, sklearn, rapidfuzz, jieba" 2>/dev/null; then
  echo "    未就绪，安装 scientific_kgqa（editable）..."
  pip install -e "$GEN_KEY/scientific_kgqa" >/dev/null
  python -c "import scientific_kgqa, sklearn, rapidfuzz, jieba" \
    || { echo "[2][FAIL] scientific_kgqa 依赖装不全，请手动: pip install -e scientific_kgqa"; exit 1; }
fi
echo "    OK"

# ── 3. 图谱产物检查 ─────────────────────────────────────────────────────────
echo "[3] 检查图谱产物..."
[ -f "$DB" ]        || { echo "[3][FAIL] 缺图谱库: $DB"; exit 1; }
[ -f "$RETRIEVER" ] || { echo "[3][FAIL] 缺 retriever: $RETRIEVER"; exit 1; }
python - "$DB" <<'PY'
import sqlite3,sys
c=sqlite3.connect(sys.argv[1])
n=c.execute("SELECT COUNT(*) FROM graph_node").fetchone()[0]
e=c.execute("SELECT COUNT(*) FROM graph_edge").fetchone()[0]
p=c.execute("SELECT COUNT(*) FROM paper").fetchone()[0]
print(f"    图谱: {n} 节点 / {e} 边 / {p} 论文")
assert n>0, "图谱为空，请确认 kgqa.db 是真实图谱（应有 8万+ 节点）"
PY

# ── 4. 出题（可跳过）────────────────────────────────────────────────────────
if [ "$SKIP_GEN" = "1" ]; then
  echo "[4] SKIP_GEN=1，跳过出题，直接用已有题目: $QUESTIONS_DIR"
else
  echo "[4] 出题：每领域 $NUM_PER_DOMAIN 题，hops=$HOPS，源 PDF=$EXTERN_DIR"
  [ -d "$EXTERN_DIR" ] || { echo "[4][FAIL] 源 PDF 目录不存在: $EXTERN_DIR"; exit 1; }
  python "$GEN_KEY/kg_eval/qag/generate_questions.py" \
    --source external \
    --hops "$HOPS" \
    --paper-range "$PAPER_RANGE" \
    --domains "$DOMAINS" \
    --num-per-domain "$NUM_PER_DOMAIN" \
    --extern-dir "$EXTERN_DIR" \
    --output-dir "$QUESTIONS_DIR"
  echo "    出题完成 → $QUESTIONS_DIR"
fi

# ── 5. 图谱测评（出题→图谱问答→四维打分→诊断→报告）──────────────────────────
echo "[5] 图谱四维测评..."
LIMIT_ARG=()
[ -n "$LIMIT" ] && LIMIT_ARG=(--limit "$LIMIT")
python -m kg_eval.run_kg_eval \
  --db "$DB" \
  --retriever "$RETRIEVER" \
  --questions-dir "$QUESTIONS_DIR" \
  --out "$OUT_DIR" \
  "${LIMIT_ARG[@]}"

# ── 6. 结果 ─────────────────────────────────────────────────────────────────
echo
echo "============================================================"
echo "[6] 闭环完成。产物："
echo "    - 原始答案:   $OUT_DIR/answers.json"
echo "    - 机读报告:   $OUT_DIR/report.json"
echo "    - 人读报告:   $OUT_DIR/report.md"
echo "    用编辑器打开 report.md 查看四维分 + 最弱维诊断 + 优化建议。"
echo "============================================================"
