#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""QAG Web UI Server - 知识图谱问答出题 · 审查 · 图谱测评界面"""

from __future__ import annotations
import argparse
import io
import json
import os
import re
import subprocess
import sys
import threading
import time
import uuid
import zipfile
from datetime import datetime
from pathlib import Path
from flask import Flask, render_template_string, request, jsonify, send_file, session
from werkzeug.utils import secure_filename

# 确保本目录(qag/)在 sys.path 上，使 `import auth` 在脚本/模块/WSGI 各种启动方式下都可用
sys.path.insert(0, str(Path(__file__).resolve().parent))
import auth  # 同目录 qag/auth.py：账号鉴权 + 每用户工作区

QAG_DIR = Path(__file__).resolve().parent
REPO_ROOT = QAG_DIR.parent
GEN_KEY_ROOT = QAG_DIR.parent.parent          # .../gen_key（步骤 ⑩ kg_eval 包所在）
OUTPUT_DIR = QAG_DIR / "output"
REPORT_DIR = OUTPUT_DIR / "reports"
EXTERN_DIR = QAG_DIR / "extern_data"
SCRIPT_DIR = QAG_DIR / "script"
EVALUATOR = QAG_DIR / "pipline" / "evaluation.py"

# 步骤 ⑩ 图谱测评：默认图谱产物与报告目录
# 权重(kgqa.db/retriever.pkl)目录优先级：env KGQA_ARTIFACTS_DIR → 团队共享挂载 → 仓库内本地副本。
# 让所有能访问共享挂载的机器无需各自拷贝几个 G 的权重即可跑图谱测评。
_SHARED_ARTIFACTS = Path("/mnt/shared-storage-user/suyulin/literature_knowledge_extractor_new/scientific_kgqa/artifacts")
_LOCAL_ARTIFACTS = GEN_KEY_ROOT / "scientific_kgqa" / "artifacts"


def _resolve_artifacts_dir() -> Path:
    env = os.environ.get("KGQA_ARTIFACTS_DIR", "").strip()
    if env:
        return Path(env)
    return _SHARED_ARTIFACTS if _SHARED_ARTIFACTS.exists() else _LOCAL_ARTIFACTS


_ARTIFACTS = _resolve_artifacts_dir()
# 默认用航天版 kgqa_aerospace.db（共享盘上即此名）；本地副本可能叫 kgqa.db → 回退。
KG_DB_DEFAULT = (_ARTIFACTS / "kgqa_aerospace.db") if (_ARTIFACTS / "kgqa_aerospace.db").exists() else (_ARTIFACTS / "kgqa.db")
KG_RETRIEVER_DEFAULT = _ARTIFACTS / "retriever.pkl"
KG_EVAL_OUT = GEN_KEY_ROOT / "kg_eval" / "output"

app = Flask(__name__)
auth.init_db()                                   # 建 users.db（幂等）
app.config["SECRET_KEY"] = auth.load_secret_key()  # 持久化随机密钥（替代硬编码）
app.config["MAX_CONTENT_LENGTH"] = 300 * 1024 * 1024  # 上传上限 300MB
SERVER_PORT = 5000  # set by main() on startup
APP_VERSION = "v3-direct"  #直接调用 auto_generate_v3.py

# --- Task Manager ---
tasks = {}
tasks_lock = threading.Lock()

# Remembers the last review run so the expert panel / repair / apply endpoints
# all read & write the SAME report dir + prefix the user actually reviewed,
# instead of the hardcoded QAG-merged/output/reports.
LAST_REVIEW = {"output_dir": "", "report_dir": "", "prefix": ""}


def _clean_path(p: str) -> str:
    """Strip whitespace and stray surrounding quotes (pasted Windows paths)."""
    return (p or "").strip().strip('"').strip("'").strip()


def _config() -> dict:
    cfg_file = QAG_DIR / "config.json"
    if cfg_file.exists():
        try:
            return json.loads(cfg_file.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def _user_dirs() -> tuple[Path, Path, Path]:
    """当前登录用户的 (extern_dir, output_dir, report_dir) 工作区目录。

    目录由会话里的 uid 决定（服务器可信），实现用户间数据隔离。
    """
    uid = auth.current_uid()
    return auth.user_dirs(uid)


def _resolve_dirs(output_dir: str = "", report_dir: str = "") -> tuple[Path, Path]:
    """Resolve effective (output_dir, report_dir).

    Priority: explicit args → 当前用户工作区。
    显式传入（如上传后前端回填的工作区路径）优先；否则用登录用户的工作区。
    """
    _, u_out, u_rep = _user_dirs()
    out = _clean_path(output_dir) or str(u_out)
    rep = _clean_path(report_dir) or str(u_rep)
    out_norm = out.rstrip("\\/")
    rep_norm = rep.rstrip("\\/")
    if not rep or rep_norm == out_norm:
        rep = out_norm + "/reports"
    return Path(out), Path(rep)


def _review_ctx() -> tuple[Path, Path, str]:
    """(output_dir, report_dir, prefix) for panel/repair/apply.

    每用户隔离：固定用当前登录用户的工作区 output/reports（prefix 置空）。
    """
    _, out, rep = _user_dirs()
    return out, rep, ""


def _model_chain(kind: str, data: dict | None = None) -> str:
    """Return an ordered, comma-joined model fallback chain for `kind`.

    kind: 'gen' | 'judge' | 'reason'. Priority:
      request body ({kind}_models list) → config arrays →
      single {kind}_model/model → default.
    The backend scripts split this on commas and degrade left→right on failure.
    'reason' = KG 图谱问答推理用的 LLM（图谱测评时驱动查询翻译 + 抽种子 + 语义映射）。
    """
    data = data or {}
    cfg = _config()
    key = {"gen": "gen_models", "judge": "judge_models", "reason": "reason_models"}.get(kind, "gen_models")
    single = {"gen": "gen_model", "judge": "judge_model", "reason": "reason_model"}.get(kind, "gen_model")
    arr = data.get(key) or cfg.get(key) or []
    if isinstance(arr, str):
        arr = [arr]
    chain = [str(m).strip() for m in arr if str(m).strip()]
    if not chain:
        one = (data.get(single) or data.get("model")
               or cfg.get(single) or cfg.get("model")
               or os.environ.get("QAG_LLM_MODEL", "claude-sonnet-4-6"))
        chain = [str(one).strip()]
    return ",".join(chain)


def _now_str():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _load_json_safe(path) -> dict:
    """Read a JSON file, return {} on any error (missing / bad JSON)."""
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return {}


def _manifest_ids(out_dir) -> list[str]:
    """读 out_dir/generation_manifest.json 的 question_ids（最近一次出题生成的题号）。

    缺失 / 坏档 / 字段不存在均返回 []。用于「仅最新出的题」范围。
    """
    man = _load_json_safe(Path(out_dir) / "generation_manifest.json")
    ids = man.get("question_ids")
    return [str(x) for x in ids] if isinstance(ids, list) else []


# 非题目的 JSON（元数据/报告/列表），扫描题库时跳过。
_NON_QUESTION_JSON = {
    "generation_manifest.json", "question_quality_metrics.json",
    "reasoning_path_validation.json", "llm_judge_question_scores.json",
    "selfcheck_results.json", "llm_repair_log.json",
    "expert_feedback_apply_log.json", "expert_feedback.json",
    "usable_ids.json", "usable_question_ids.json",
    "final_questions.json", "review_data.json", "expert_accepted_ids.json",
}


def _is_question_file(jf: Path) -> bool:
    """该 JSON 是否为「题目」文件（排除元数据/报告/归档/临时过滤目录）。"""
    if jf.name in _NON_QUESTION_JSON:
        return False
    if any(p in ("reports", "rejected") or p.startswith("_idfilter_") for p in jf.parts):
        return False
    return True


def _count_questions(d: Path) -> int:
    """递归统计目录下「题目」JSON 数（去重 id）。"""
    seen: set[str] = set()
    n = 0
    if not Path(d).exists():
        return 0
    for jf in Path(d).rglob("*.json"):
        if not _is_question_file(jf):
            continue
        data = _load_json_safe(jf)
        if not isinstance(data, dict):
            continue
        qid = str(data.get("id") or "")
        if qid and qid in seen:
            continue
        if qid:
            seen.add(qid)
        n += 1
    return n


def _scan_question_ids(d: Path) -> set[str]:
    """递归收集目录下「题目」JSON 的 id 集合（用于批次↔题目目录配对）。"""
    ids: set[str] = set()
    if not Path(d).exists():
        return ids
    for jf in Path(d).rglob("*.json"):
        if not _is_question_file(jf):
            continue
        data = _load_json_safe(jf)
        if isinstance(data, dict) and data.get("id"):
            ids.add(str(data["id"]))
    return ids


def _discover_batches(out_dir: Path, rep_dir: Path) -> list[dict]:
    """发现「批次」：rep_dir 下每个含 review_data.json 的目录即一个批次。

    返回 [{id, label, report_dir, question_dir, total, risk_counts}]，按 default 优先 + id 排序。
    题目目录用 review_data 的 question_id 与 out_dir 各子目录的题 id 交集最大者配对，
    匹配不到则回退整个 out_dir。无任何 review_data 时回退单一 default 批次。
    """
    out_dir = Path(out_dir)
    rep_dir = Path(rep_dir)
    rd_paths = sorted(rep_dir.rglob("review_data.json")) if rep_dir.exists() else []

    # 预扫 out_dir 各子目录题 id（配对用，跳过 reports）
    child_ids: dict[Path, set[str]] = {}
    if out_dir.exists():
        for d in sorted(out_dir.iterdir()):
            if d.is_dir() and d.name != "reports":
                child_ids[d] = _scan_question_ids(d)

    batches: list[dict] = []
    for rd in rd_paths:
        rdir = rd.parent
        try:
            rel = rdir.relative_to(rep_dir)
            bid = "default" if str(rel) in (".", "") else str(rel).replace("\\", "/")
        except ValueError:
            bid = rdir.name
        data = _load_json_safe(rd)
        meta = data.get("meta") or {}
        qids = {str(q.get("question_id") or q.get("id"))
                for q in (data.get("questions") or [])
                if (q.get("question_id") or q.get("id"))}
        qdir = out_dir
        best = 0
        for d, ids in child_ids.items():
            inter = len(ids & qids) if qids else 0
            if inter > best:
                best, qdir = inter, d
        total = meta.get("total") or len(data.get("questions") or [])
        label = ("默认" if bid == "default" else bid) + f"（{total} 题）"
        batches.append({
            "id": bid, "label": label,
            "report_dir": str(rdir), "question_dir": str(qdir),
            "total": total, "risk_counts": meta.get("risk_counts") or {},
        })

    if not batches:
        batches.append({
            "id": "default", "label": "默认",
            "report_dir": str(rep_dir), "question_dir": str(out_dir),
            "total": 0, "risk_counts": {},
        })
    batches.sort(key=lambda b: (b["id"] != "default", b["id"]))
    return batches


def _batch_ctx(batch_id: str = "") -> tuple[Path, Path]:
    """专家操作用：返回所选批次的 (question_dir, report_dir)。

    batch_id 空 / 'default' / 未匹配 → 回退当前用户工作区 (out_dir, rep_dir)。
    """
    _, out_dir, rep_dir = _user_dirs()
    bid = (batch_id or "").strip()
    if not bid or bid == "default":
        return out_dir, rep_dir
    for b in _discover_batches(out_dir, rep_dir):
        if b["id"] == bid:
            return Path(b["question_dir"]), Path(b["report_dir"])
    return out_dir, rep_dir



def _add_log(task_id, msg):
    with tasks_lock:
        if task_id in tasks:
            tasks[task_id]["logs"].append(f"[{_now_str()}] {msg}")

def run_task(task_id, cmd, cwd):
    _add_log(task_id, f"执行命令: {' '.join(cmd)}")
    with tasks_lock:
        tasks[task_id]["status"] = "running"
    try:
        env = os.environ.copy()
        env.setdefault("PYTHONIOENCODING", "utf-8")
        env.setdefault("PYTHONUTF8", "1")
        env.setdefault("PYTHONUNBUFFERED", "1")
        # 注入 gen_key/.env（LLM_/KG_LLM_/EMBED_ 等），供 kg_eval 图谱测评子进程使用。
        # 已存在于环境的 key 不覆盖；这样网页起的子进程也能用到真实凭据。
        dotenv = GEN_KEY_ROOT / ".env"
        if dotenv.exists():
            try:
                for line in dotenv.read_text(encoding="utf-8").splitlines():
                    line = line.strip()
                    if not line or line.startswith("#") or "=" not in line:
                        continue
                    k, _, v = line.partition("=")
                    k = k.strip()
                    v = v.strip().strip('"').strip("'")
                    if k and not env.get(k):
                        env[k] = v
            except OSError:
                pass
        # Inject API credentials from config.json so子进程 pick them up。
        # 注意：这里用「直接赋值」覆盖上面 .env 注入的同名变量——配置页改了 URL/Key 必须生效。
        #   · 出题(auto_generate_v3) 读 QAG_*；
        #   · 图谱测评(kg_eval / scientific_kgqa) 读 LLM_* / KG_LLM_*（见 kg_eval/eval/config.py）。
        # 之前只写了 QAG_*，导致 kg_eval 子进程仍用 .env 里的旧 LLM_BASE_URL，配置页改了不生效。
        cfg_file = QAG_DIR / "config.json"
        if cfg_file.exists():
            cfg = json.loads(cfg_file.read_text(encoding="utf-8"))
            if cfg.get("api_key"):
                env["QAG_API_KEY"] = cfg["api_key"]
                env["LLM_API_KEY"] = cfg["api_key"]
                env["KG_LLM_API_KEY"] = cfg["api_key"]
            if cfg.get("api_base_url"):
                env["QAG_LLM_BASE_URL"] = cfg["api_base_url"]
                env["LLM_BASE_URL"] = cfg["api_base_url"]
                env["KG_LLM_BASE_URL"] = cfg["api_base_url"]
            if cfg.get("model"):
                env["QAG_LLM_MODEL"] = cfg["model"]
        # 流式执行：实时把子进程每行输出喂给日志，避免"长时间无输出像卡死"。
        # stderr 合并进 stdout，单线程 readline 读取，规避双管道死锁。
        try:
            proc = subprocess.Popen(
                cmd,
                cwd=str(cwd),
                env=env,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                bufsize=1,
            )
            with tasks_lock:
                tasks[task_id]["pid"] = proc.pid
            # 用 readline 逐行读：`for line in proc.stdout` 的文件迭代器有 read-ahead
            # 缓冲(约8KB)，会攒够一块才吐行，运行中看不到进度。readline 才是真实时。
            while True:
                line = proc.stdout.readline()
                if not line:
                    if proc.poll() is not None:
                        break
                    continue
                line = line.rstrip("\n").rstrip()
                if line:
                    _add_log(task_id, line)
            proc.wait()
            with tasks_lock:
                tasks[task_id]["exit_code"] = proc.returncode
                tasks[task_id]["end_time"] = time.time()
                tasks[task_id]["status"] = "done" if proc.returncode == 0 else "failed"
        except FileNotFoundError as e:
            _add_log(task_id, f"文件未找到: {e}")
            with tasks_lock:
                tasks[task_id]["exit_code"] = -1
                tasks[task_id]["end_time"] = time.time()
                tasks[task_id]["status"] = "failed"
        except Exception as e:
            _add_log(task_id, f"子进程异常: {type(e).__name__}: {e}")
            with tasks_lock:
                tasks[task_id]["exit_code"] = -1
                tasks[task_id]["end_time"] = time.time()
                tasks[task_id]["status"] = "failed"
        _add_log(task_id, f"进程结束，退出码: {tasks[task_id]['exit_code']}")
    except Exception as e:
        _add_log(task_id, f"错误: {e}")
        with tasks_lock:
            tasks[task_id]["status"] = "failed"


def run_task_seq(task_id, cmds, cwd):
    """Run a sequence of commands in order; stop on first failure.

    Used by the expert closed-loop endpoints: e.g. apply feedback → re-review.
    """
    for i, cmd in enumerate(cmds, 1):
        _add_log(task_id, f"步骤 {i}/{len(cmds)}")
        run_task(task_id, cmd, cwd)
        with tasks_lock:
            failed = tasks.get(task_id, {}).get("status") == "failed"
        if failed:
            _add_log(task_id, f"步骤 {i} 失败，终止后续步骤")
            return
    with tasks_lock:
        if task_id in tasks:
            tasks[task_id]["status"] = "done"
            tasks[task_id]["end_time"] = time.time()

# --- Routes ---

@app.route("/pdf/<path:filename>")
@auth.login_required
def serve_pdf(filename):
    """Serve a PDF from the current user's workspace extern_data (inline view)."""
    extern_dir, _, _ = _user_dirs()
    safe = secure_filename(filename)
    pdf_path = extern_dir / safe
    if pdf_path.exists():
        return send_file(str(pdf_path), mimetype="application/pdf")
    return jsonify({"error": "not found", "path": safe}), 404

@app.route("/")
def index():
    return render_template_string(
        HTML_TEMPLATE,
        kg_db_default=str(KG_DB_DEFAULT),
        kg_retriever_default=str(KG_RETRIEVER_DEFAULT),
    )


# ─── 鉴权端点 ────────────────────────────────────────────────────────────────
@app.route("/api/auth/register", methods=["POST"])
def auth_register():
    data = request.get_json() or {}
    ok, msg = auth.create_user(data.get("username", ""), data.get("password", ""))
    if not ok:
        return jsonify({"error": msg}), 400
    uid = auth.verify_user(data.get("username", ""), data.get("password", ""))
    session["uid"] = uid
    session.permanent = True
    return jsonify({"ok": True, "username": auth.get_username(uid)})


@app.route("/api/auth/login", methods=["POST"])
def auth_login():
    data = request.get_json() or {}
    uid = auth.verify_user(data.get("username", ""), data.get("password", ""))
    if uid is None:
        return jsonify({"error": "用户名或密码错误"}), 401
    session["uid"] = uid
    session.permanent = True
    return jsonify({"ok": True, "username": auth.get_username(uid)})


@app.route("/api/auth/logout", methods=["POST"])
def auth_logout():
    session.clear()
    return jsonify({"ok": True})


@app.route("/api/auth/me", methods=["GET"])
def auth_me():
    uid = auth.current_uid()
    if uid is None:
        return jsonify({"authenticated": False})
    return jsonify({"authenticated": True, "username": auth.get_username(uid)})


# ─── 上传 / 工作区端点 ───────────────────────────────────────────────────────
_ALLOWED_PDF = {".pdf"}
_ALLOWED_BUNDLE = {".json", ".md", ".zip"}


_EXTRACT_EXTS = (".json", ".md")
# 上传 zip 里允许去掉的冗余顶层目录名（应用自身的 output 外层）。
_WRAPPER_SEGS = {"output"}
# 路径段里禁止的字符：路径分隔符、控制字符、Windows 盘符冒号等。保留中文/unicode 字母。
_BAD_SEG_RE = re.compile(r'[\x00-\x1f<>:"/\\|?*]')


def _safe_seg(p: str) -> str:
    """Unicode 安全的单层路径段清洗：去控制/分隔/危险字符，保留中文。

    替代 werkzeug.secure_filename（后者会把非 ASCII 整段剥掉，导致中文目录名丢失）。
    """
    s = _BAD_SEG_RE.sub("_", (p or "").strip()).strip(". ")
    return s


def _normalize_zip_parts(name: str) -> list[str]:
    """把 zip 条目相对路径归一为干净的 segments：

    1) 过 _safe_seg，丢空 / "." / ".."；
    2) 剥前导冗余外层（连续的 "output"，处理 output/ 或 output/output/ 包装）；
    3) 合并相邻重复段（L1_x/L1_x → L1_x）。
    """
    raw = [seg for seg in Path(name).parts if seg not in ("", ".", "..", "/", "\\")]
    parts: list[str] = []
    for seg in raw:
        s = _safe_seg(seg)
        if s and s not in (".", ".."):
            parts.append(s)
    # 剥前导 wrapper（但保底留下文件名本身）
    while len(parts) > 1 and parts[0] in _WRAPPER_SEGS:
        parts = parts[1:]
    # 合并相邻重复目录段
    collapsed: list[str] = []
    for s in parts:
        if collapsed and collapsed[-1] == s:
            continue
        collapsed.append(s)
    return collapsed


def _safe_extract_zip(zf, dest: Path) -> dict:
    """防 zip-slip 解压：接受 .json/.md，路径归一（剥冗余外层+合并重复嵌套+中文安全）。

    返回 {"questions": n_json, "reports": n_md, "total": n}。
    """
    import zipfile  # noqa: F401  (调用方已 import，这里保持自洽)
    n_json = n_md = 0
    dest = dest.resolve()
    for info in zf.infolist():
        if info.is_dir():
            continue
        ext = Path(info.filename).suffix.lower()
        if ext not in _EXTRACT_EXTS:
            continue
        parts = _normalize_zip_parts(info.filename)
        if not parts:
            continue
        target = dest.joinpath(*parts).resolve()
        # zip-slip 防护：解析后仍须落在 dest 内
        if target != dest and dest not in target.parents:
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        with zf.open(info) as src, open(target, "wb") as out:
            out.write(src.read())
        if ext == ".json":
            n_json += 1
        else:
            n_md += 1
    return {"questions": n_json, "reports": n_md, "total": n_json + n_md}


@app.route("/api/upload/pdf", methods=["POST"])
@auth.login_required
def upload_pdf():
    """上传 PDF → 当前用户工作区 extern_data/。"""
    extern_dir, _, _ = _user_dirs()
    files = request.files.getlist("files")
    saved, skipped = [], []
    for f in files:
        name = secure_filename(f.filename or "")
        if not name or Path(name).suffix.lower() not in _ALLOWED_PDF:
            skipped.append(f.filename)
            continue
        # 统一规范化为小写 .pdf（Linux glob "*.pdf" 大小写敏感，否则管线找不到）
        name = Path(name).stem + ".pdf"
        extern_dir.mkdir(parents=True, exist_ok=True)
        f.save(str(extern_dir / name))
        saved.append(name)
    return jsonify({"saved": saved, "skipped": skipped,
                    "extern_dir": str(extern_dir), "count": len(saved)})


@app.route("/api/upload/bundle", methods=["POST"])
@auth.login_required
def upload_bundle():
    """上传题目/报告：.json → output/（report 名落 reports/）；.zip → 解压到 output/。"""
    _, out_dir, rep_dir = _user_dirs()
    files = request.files.getlist("files")
    saved, skipped = [], []
    import io, zipfile
    report_hint = ("review_data", "question_quality", "reasoning_path",
                   "llm_judge", "selfcheck", "usable_ids", "quality_report")
    for f in files:
        raw = f.filename or ""
        ext = Path(raw).suffix.lower()
        if ext not in _ALLOWED_BUNDLE:
            skipped.append(f.filename)
            continue
        if ext == ".zip":
            try:
                with zipfile.ZipFile(io.BytesIO(f.read())) as zf:
                    r = _safe_extract_zip(zf, out_dir)
                saved.append(f"{Path(raw).name} (解压 {r['questions']} json + {r['reports']} 报告)")
            except zipfile.BadZipFile:
                skipped.append(f.filename + " (坏 zip)")
        else:  # .json / .md
            name = _safe_seg(Path(raw).name)
            if not name:
                skipped.append(f.filename)
                continue
            dest = rep_dir if any(h in name for h in report_hint) else out_dir
            dest.mkdir(parents=True, exist_ok=True)
            f.save(str(dest / name))
            saved.append(name)
    return jsonify({"saved": saved, "skipped": skipped,
                    "output_dir": str(out_dir), "report_dir": str(rep_dir)})


@app.route("/api/workspace", methods=["GET"])
@auth.login_required
def get_workspace():
    """列当前用户工作区内容 + 三目录路径。"""
    extern_dir, out_dir, rep_dir = _user_dirs()
    pdfs = sorted(p.name for p in extern_dir.glob("*.pdf"))
    questions = sum(1 for _ in out_dir.rglob("*.json")
                    if "reports" not in _.parts)
    reports = sorted(p.name for p in rep_dir.glob("*.json"))
    return jsonify({
        "extern_dir": str(extern_dir), "output_dir": str(out_dir), "report_dir": str(rep_dir),
        "pdf_count": len(pdfs), "pdfs": pdfs[:200],
        "question_count": questions, "report_files": reports,
    })


@app.route("/api/workspace/clear", methods=["POST"])
@auth.login_required
def clear_workspace():
    """清空当前用户工作区（仅本人目录）。"""
    import shutil
    data = request.get_json() or {}
    extern_dir, out_dir, rep_dir = _user_dirs()
    targets = []
    if data.get("pdfs"):
        targets.append(extern_dir)
    if data.get("questions"):
        targets.append(out_dir)
    if not targets:  # 默认全清
        targets = [extern_dir, out_dir]
    for d in targets:
        if d.exists():
            shutil.rmtree(d, ignore_errors=True)
    _user_dirs()  # 重建空目录
    return jsonify({"ok": True})


# ─── 全局登录守卫：除登录页/鉴权端点外，所有 /api/* 与 /pdf/* 都需登录 ──────────
_PUBLIC_PATHS = {"/", "/api/auth/login", "/api/auth/register",
                 "/api/auth/me", "/api/auth/logout"}


@app.before_request
def _require_login():
    p = request.path
    if p in _PUBLIC_PATHS or p.startswith("/static"):
        return None
    if auth.current_uid() is None:
        return jsonify({"error": "unauthorized"}), 401
    return None


@app.route("/api/config", methods=["GET"])
def get_config():
    cfg = {}
    cfg_file = QAG_DIR / "config.json"
    if cfg_file.exists():
        cfg = json.loads(cfg_file.read_text(encoding="utf-8"))
    cfg.setdefault("api_base_url", os.environ.get("QAG_LLM_BASE_URL", "http://43.153.42.7:3001/v1"))
    cfg.setdefault("api_key", os.environ.get("QAG_API_KEY", ""))
    cfg.setdefault("model", os.environ.get("QAG_LLM_MODEL", "claude-sonnet-4-6"))
    cfg.setdefault("timeout", 120)
    # Always report the ACTUAL running port, not the (possibly stale) config value.
    cfg["server_port"] = SERVER_PORT
    cfg.setdefault("extern_dir", str(EXTERN_DIR))
    cfg.setdefault("output_dir", str(OUTPUT_DIR))
    cfg.setdefault("report_dir", str(REPORT_DIR))
    return jsonify(cfg)

@app.route("/api/config", methods=["POST"])
def save_config():
    data = request.get_json() or {}
    cfg_file = QAG_DIR / "config.json"
    cfg_file.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    # Update env vars for current process（同时写 QAG_* 与 LLM_*/KG_LLM_*，
    # 这样新起的子进程不论读哪套命名都拿到配置页最新值）
    if data.get("api_key"):
        os.environ["QAG_API_KEY"] = data["api_key"]
        os.environ["LLM_API_KEY"] = data["api_key"]
        os.environ["KG_LLM_API_KEY"] = data["api_key"]
    if data.get("api_base_url"):
        os.environ["QAG_LLM_BASE_URL"] = data["api_base_url"]
        os.environ["LLM_BASE_URL"] = data["api_base_url"]
        os.environ["KG_LLM_BASE_URL"] = data["api_base_url"]
    if data.get("model"):
        os.environ["QAG_LLM_MODEL"] = data["model"]
    return jsonify({"ok": True})

@app.route("/api/tasks", methods=["GET"])
def list_tasks():
    with tasks_lock:
        result = []
        for tid in sorted(tasks.keys(), reverse=True):
            t = tasks[tid]
            result.append({
                "id": tid,
                "type": t["type"],
                "status": t["status"],
                "created_at": t["created_at"],
                "elapsed": (t.get("end_time", time.time()) - t["start_time"]) if t["start_time"] else 0,
                "exit_code": t.get("exit_code"),
            })
        return jsonify(result[:50])

@app.route("/api/tasks/<task_id>", methods=["GET"])
def get_task(task_id):
    with tasks_lock:
        t = tasks.get(task_id)
        if not t:
            return jsonify({"error": "not found"}), 404
        return jsonify({
            "id": task_id,
            "type": t["type"],
            "status": t["status"],
            "created_at": t["created_at"],
            "elapsed": (time.time() - t["start_time"]) if t["start_time"] else 0,
            "exit_code": t.get("exit_code"),
            "logs": t["logs"][-200:],
        })

@app.route("/api/tasks/<task_id>/stop", methods=["POST"])
def stop_task(task_id):
    with tasks_lock:
        t = tasks.get(task_id)
        if not t:
            return jsonify({"error": "not found"}), 404
        pid = t.get("pid")
    if pid:
        try:
            os.kill(pid, 2)  # SIGINT
        except OSError:
            pass
    with tasks_lock:
        t["status"] = "stopped"
        t["logs"].append(f"[{_now_str()}] 用户手动终止")
    return jsonify({"ok": True})

@app.route("/api/generate", methods=["POST"])
def start_generate():
    data = request.get_json() or {}
    tid = str(uuid.uuid4())[:8]
    cfg = {}
    cfg_file = QAG_DIR / "config.json"
    if cfg_file.exists():
        cfg = json.loads(cfg_file.read_text(encoding="utf-8"))

    api_key = data.get("api_key") or cfg.get("api_key") or os.environ.get("QAG_API_KEY", "")
    base_url = data.get("api_base_url") or cfg.get("api_base_url") or os.environ.get("QAG_LLM_BASE_URL", "")
    model = _model_chain("gen", data)  # 有序降级链（逗号分隔）

    # 出题落到当前用户工作区：extern_data(上传的 PDF) + output。显式传入可覆盖。
    u_extern, u_out, _ = _user_dirs()
    extern_dir = _clean_path(data.get("extern_dir", "")) or str(u_extern)
    output_dir = _clean_path(data.get("output_dir", "")) or str(u_out)

    cmd = [
        sys.executable,
        str(QAG_DIR / "pipline" / "auto_generate_v3.py"),
        "--source", data.get("source", "external"),
        "--hops", data.get("hops", "1,2,3,4"),
        "--paper-range", data.get("paper_range", "1-3"),
        "--domains", data.get("domains", "FABS,HCFG,MECH,POPT"),
        "--num-per-domain", str(data.get("num_per_domain", 2)),
        "--extern-dir", extern_dir,
        "--output-dir", output_dir,
        "--start-index", "0",
    ]
    if data.get("dry_run"):
        cmd.append("--dry-run")
    if api_key:
        cmd += ["--api-key", api_key]
    if base_url:
        cmd += ["--llm-base-url", base_url]
    if model:
        cmd += ["--llm-model", model]

    with tasks_lock:
        tasks[tid] = {
            "type": "generate",
            "status": "pending",
            "created_at": _now_str(),
            "start_time": 0,
            "cmd": cmd,
            "logs": [],
            "pid": None,
            "exit_code": None,
        }

    _add_log(tid, "出题任务已创建")
    t = threading.Thread(target=run_task, args=(tid, cmd, str(REPO_ROOT)), daemon=True)
    with tasks_lock:
        tasks[tid]["start_time"] = time.time()
    t.start()
    return jsonify({"task_id": tid})

@app.route("/api/review", methods=["POST"])
def start_review():
    data = request.get_json() or {}
    tid = str(uuid.uuid4())[:8]

    # input_dir = question root; report_dir auto-resolved (+/reports if same).
    out_dir, rep_dir = _resolve_dirs(
        output_dir=data.get("input_dir", ""),
        report_dir=data.get("report_dir", ""),
    )
    input_dir = str(out_dir)
    report_dir = str(rep_dir)
    prefix = (data.get("report_prefix") or "").strip()

    # Remember this run so the expert panel / repair / apply read the SAME place.
    LAST_REVIEW["output_dir"] = input_dir
    LAST_REVIEW["report_dir"] = report_dir
    LAST_REVIEW["prefix"] = prefix

    cmd = [
        sys.executable,
        str(QAG_DIR / "review_questions.py"),
        "--input-dir", input_dir,
        "--report-dir", report_dir,
    ]
    if data.get("with_llm_judge"):
        judge_chain = data.get("llm_model") or _model_chain("judge", data)
        cmd += ["--with-llm-judge", "--model", judge_chain]
    if data.get("limit"):
        cmd += ["--limit", str(data["limit"])]
    if data.get("only_new"):
        cmd += ["--only-new"]
    if data.get("id_filter"):
        cmd += ["--id-filter", data["id_filter"]]
    if prefix:
        cmd += ["--report-prefix", prefix]

    with tasks_lock:
        tasks[tid] = {
            "type": "review",
            "status": "pending",
            "created_at": _now_str(),
            "start_time": 0,
            "cmd": cmd,
            "logs": [],
            "pid": None,
            "exit_code": None,
        }

    _add_log(tid, "审核任务已创建")
    t = threading.Thread(target=run_task, args=(tid, cmd, str(REPO_ROOT)), daemon=True)
    with tasks_lock:
        tasks[tid]["start_time"] = time.time()
    t.start()
    return jsonify({"task_id": tid})

@app.route("/api/pipeline", methods=["POST"])
def start_pipeline():
    """一键全流程：调用 run_qag_pipeline.py，真正串联 出题 → 审核（→可选 LLM Judge）。

    注意：auto_generate_v3.py 只会出题，不会审核，也不接受 --with-llm-judge /
    --skip-review，所以这里必须走 run_qag_pipeline.py。
    """
    data = request.get_json() or {}
    tid = str(uuid.uuid4())[:8]
    cfg = _config()

    out_dir, rep_dir = _resolve_dirs(
        output_dir=data.get("output_dir", ""),
        report_dir=data.get("report_dir", ""),
    )
    extern_dir = data.get("extern_dir") or cfg.get("extern_dir") or str(EXTERN_DIR)
    api_key = data.get("api_key") or cfg.get("api_key") or os.environ.get("QAG_API_KEY", "")
    base_url = data.get("api_base_url") or cfg.get("api_base_url") or os.environ.get("QAG_LLM_BASE_URL", "")
    model = data.get("llm_model") or _model_chain("judge", data)  # 审核环节用 judge 链

    cmd = [
        sys.executable,
        str(QAG_DIR / "run_qag_pipeline.py"),
        "--source", data.get("source", "external"),
        "--hops", data.get("hops", "1,2,3,4"),
        "--paper-range", data.get("paper_range", "1-3"),
        "--domains", data.get("domains", "FABS,HCFG,MECH,POPT"),
        "--num-per-domain", str(data.get("num_per_domain", 2)),
        "--extern-dir", extern_dir,
        "--output-dir", str(out_dir),
        "--report-dir", str(rep_dir),
        "--start-index", "0",
        "--model", model,
    ]
    if api_key:
        cmd += ["--api-key", api_key]
    if base_url:
        cmd += ["--base-url", base_url]
    if data.get("with_llm_judge"):
        cmd.append("--with-llm-judge")
    if data.get("dry_run"):
        cmd.append("--dry-run")

    # 「跳过审核」= 只出题：改用 generate_questions.py（run_qag_pipeline 总会审核）。
    if data.get("skip_review"):
        gen_model = _model_chain("gen", data)  # 纯出题用 gen 链
        cmd = [
            sys.executable, str(QAG_DIR / "generate_questions.py"),
            "--source", data.get("source", "external"),
            "--hops", data.get("hops", "1,2,3,4"),
            "--paper-range", data.get("paper_range", "1-3"),
            "--domains", data.get("domains", "FABS,HCFG,MECH,POPT"),
            "--num-per-domain", str(data.get("num_per_domain", 2)),
            "--extern-dir", extern_dir,
            "--output-dir", str(out_dir),
            "--start-index", "0",
        ]
        if data.get("dry_run"):
            cmd.append("--dry-run")
        if api_key:
            cmd += ["--api-key", api_key]
        if base_url:
            cmd += ["--llm-base-url", base_url]
        if gen_model:
            cmd += ["--llm-model", gen_model]

    # Remember dirs so the expert panel reads the SAME place after the run.
    LAST_REVIEW["output_dir"] = str(out_dir)
    LAST_REVIEW["report_dir"] = str(rep_dir)
    LAST_REVIEW["prefix"] = ""

    with tasks_lock:
        tasks[tid] = {
            "type": "pipeline",
            "status": "pending",
            "created_at": _now_str(),
            "start_time": 0,
            "cmd": cmd,
            "logs": [],
            "pid": None,
            "exit_code": None,
        }

    _add_log(tid, "全流程任务已创建")
    t = threading.Thread(target=run_task, args=(tid, cmd, str(REPO_ROOT)), daemon=True)
    with tasks_lock:
        tasks[tid]["start_time"] = time.time()
    t.start()
    return jsonify({"task_id": tid})

@app.route("/api/review_data", methods=["GET"])
def get_review_data():
    """Return the aggregated expert-review data (review_data.json) for the panel.

    支持多批次：?batch=<id> 选择某批次（= reports 下含 review_data.json 的子目录）。
    meta.batches 返回全部可选批次供前端下拉；无 batch 时默认第一个。
    """
    _, out_dir, rep_dir = _user_dirs()
    batches = _discover_batches(out_dir, rep_dir)
    batch_meta = [{"id": b["id"], "label": b["label"], "total": b["total"],
                   "risk_counts": b["risk_counts"]} for b in batches]
    bid = (request.args.get("batch") or "").strip()
    chosen = next((b for b in batches if b["id"] == bid), None) or batches[0]
    rdir = Path(chosen["report_dir"])
    path = rdir / "review_data.json"
    if not path.exists():
        candidates = sorted(
            rdir.glob("*review_data.json"),
            key=lambda p: p.stat().st_mtime, reverse=True,
        ) if rdir.exists() else []
        if candidates:
            path = candidates[0]
        else:
            return jsonify({"error": "no_review_data",
                            "meta": {"batches": batch_meta, "current_batch": chosen["id"]},
                            "questions": []}), 200
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as e:
        return jsonify({"error": str(e),
                        "meta": {"batches": batch_meta, "current_batch": chosen["id"]},
                        "questions": []}), 200
    data.setdefault("meta", {})
    data["meta"]["batches"] = batch_meta
    data["meta"]["current_batch"] = chosen["id"]
    return jsonify(data)


@app.route("/api/expert/apply", methods=["POST"])
def expert_apply():
    """Persist the expert's filled feedback JSON, then apply it and refresh review_data.json."""
    data = request.get_json() or {}
    feedback = data.get("feedback") or []
    if not feedback:
        return jsonify({"error": "empty feedback"}), 400

    out_dir, rep_dir = _batch_ctx(data.get("batch", ""))   # 批次：题目目录 + 报告目录
    prefix = ""
    rep_dir.mkdir(parents=True, exist_ok=True)
    fb_path = rep_dir / f"{prefix}expert_feedback.json"
    fb_path.write_text(
        json.dumps({"feedback": feedback}, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    model = data.get("model") or _model_chain("judge", data)  # 专家反馈 + 重审复用 judge 链
    apply_cmd = [
        sys.executable, str(SCRIPT_DIR / "apply_expert_feedback.py"),
        "--input-dir", str(out_dir),
        "--feedback", str(fb_path),
        "--report-dir", str(rep_dir),
        "--model", model,
        "--apply",
    ]
    # Re-review with the SAME prefix so the panel reads the refreshed data back.
    review_cmd = [
        sys.executable, str(EVALUATOR),
        "--input-dir", str(out_dir),
        "--report-dir", str(rep_dir),
        "--pdf-dir", str(EXTERN_DIR),
    ]
    if prefix:
        review_cmd += ["--report-prefix", prefix]
    if data.get("with_llm_judge"):
        review_cmd += ["--with-llm-judge", "--model", model]

    tid = str(uuid.uuid4())[:8]
    with tasks_lock:
        tasks[tid] = {
            "type": "expert_apply", "status": "pending", "created_at": _now_str(),
            "start_time": 0, "cmd": apply_cmd, "logs": [], "pid": None, "exit_code": None,
        }
    _add_log(tid, f"专家反馈应用任务已创建（{len(feedback)} 条）")
    t = threading.Thread(target=run_task_seq, args=(tid, [apply_cmd, review_cmd], str(REPO_ROOT)), daemon=True)
    with tasks_lock:
        tasks[tid]["start_time"] = time.time()
    t.start()
    return jsonify({"task_id": tid})


@app.route("/api/repair/preview", methods=["POST"])
def expert_repair_preview():
    """扫 input_dir 算"将自纠 N 道"——前端调这个先给用户看，不真正跑自纠。"""
    data = request.get_json() or {}
    only_new = bool(data.get("only_new", True))
    out_dir, rep_dir = _batch_ctx(data.get("batch", ""))   # 批次：题目目录 + 报告目录
    prefix = ""
    # 复用 llm_repair.py 的 needs_repair 触发逻辑（不调 LLM）
    quality = _load_json_safe(rep_dir / f"{prefix}question_quality_metrics.json")
    path_val = _load_json_safe(rep_dir / f"{prefix}reasoning_path_validation.json")
    judge = _load_json_safe(rep_dir / f"{prefix}llm_judge_question_scores.json")
    q_by_id = {q["id"]: q for q in (quality.get("questions") or []) if "id" in q}
    p_by_id = {q["id"]: q for q in (path_val.get("questions") or []) if "id" in q}
    j_by_id = {q["id"]: q for q in (judge.get("questions") or []) if "id" in q}

    # 「仅最新出的题」范围：generation_manifest 的 question_ids
    new_ids = set(_manifest_ids(out_dir))

    will_repair: list[dict] = []
    new_in_dir = 0  # 目录里确实存在的本批新题数（manifest ∩ 实际题号）
    for jf in sorted(Path(out_dir).rglob("*.json")):
        if jf.name in {"generation_manifest.json", "question_quality_metrics.json",
                       "reasoning_path_validation.json", "llm_judge_question_scores.json",
                       "selfcheck_results.json", "llm_repair_log.json",
                       "expert_feedback_apply_log.json", "expert_feedback.json",
                       "usable_ids.json", "usable_question_ids.json",
                       "final_questions.json", "expert_feedback.json"}:
            continue
        # 跳过 list 格式的 JSON（不是单题 dict）
        try:
            d = json.loads(jf.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            continue
        if not isinstance(d, dict):
            continue
        qid = d.get("id", "")
        if not qid:
            continue
        if qid in new_ids:
            new_in_dir += 1
        # only_new 时跳过非本批题
        if only_new and qid not in new_ids:
            continue
        # 复用 llm_repair.needs_repair
        try:
            from script.llm_repair import needs_repair
            need, reasons = needs_repair(q_by_id.get(qid, {}), p_by_id.get(qid, {}), j_by_id.get(qid, {}))
        except Exception:
            need, reasons = False, []
        if need:
            will_repair.append({"question_id": qid, "reasons": reasons, "file_path": str(jf)})

    return jsonify({
        "will_repair_count": len(will_repair),
        "will_repair": will_repair[:50],  # 最多返回 50 条预览
        "input_dir": str(out_dir),
        "total_in_dir": sum(1 for _ in Path(out_dir).rglob("*.json")),
        "new_count": new_in_dir,
        "only_new": only_new,
    })


@app.route("/api/repair", methods=["POST"])
def expert_repair():
    """Run LLM self-repair on flagged questions, then (optionally) refresh review_data.json."""
    data = request.get_json() or {}
    model = data.get("model") or _model_chain("judge", data)  # 自纠 + 重审复用 judge 链
    rounds = int(data.get("rounds", 1))
    with_review = bool(data.get("with_review", True))  # 默认 True 保持原行为
    only_new = bool(data.get("only_new", True))        # 默认只纠本批新题

    out_dir, rep_dir = _batch_ctx(data.get("batch", ""))   # 批次：题目目录 + 报告目录
    prefix = ""

    repair_cmd = [
        sys.executable, str(SCRIPT_DIR / "llm_repair.py"),
        "--input-dir", str(out_dir),
        "--report-dir", str(rep_dir),
        "--model", model,
        "--max-rounds", str(rounds),
        "--apply",
    ]
    if prefix:
        repair_cmd += ["--report-prefix", prefix]
    if only_new:
        repair_cmd += ["--only-new"]

    cmds = [repair_cmd]
    if with_review:
        review_cmd = [
            sys.executable, str(EVALUATOR),
            "--input-dir", str(out_dir),
            "--report-dir", str(rep_dir),
            "--pdf-dir", str(EXTERN_DIR),
        ]
        if prefix:
            review_cmd += ["--report-prefix", prefix]
        if data.get("with_llm_judge"):
            review_cmd += ["--with-llm-judge", "--model", model]
        cmds.append(review_cmd)

    tid = str(uuid.uuid4())[:8]
    with tasks_lock:
        tasks[tid] = {
            "type": "self_repair", "status": "pending", "created_at": _now_str(),
            "start_time": 0, "cmd": cmds[0] if len(cmds) == 1 else cmds, "logs": [], "pid": None, "exit_code": None,
        }
    suffix = f"（{rounds} 轮）"
    if not with_review:
        suffix += " — 不跑 review"
    _add_log(tid, f"LLM 自纠任务已创建{suffix}")
    t = threading.Thread(target=run_task_seq, args=(tid, cmds, str(REPO_ROOT)), daemon=True)
    with tasks_lock:
        tasks[tid]["start_time"] = time.time()
    t.start()
    return jsonify({"task_id": tid})


# ─── 统计看板：各题型(domain) / 各难度(L1-L4) 剩余题目数量 ──────────────────
@app.route("/api/stats", methods=["GET"])
def get_stats():
    """统计题库（output 目录下的题目文件）数量，按 domain / 难度 / 风险等级分组。

    数据源以「题目文件」为准（盘点题库真实库存），而非 review_data.json
    （那只是上次审核覆盖的子集）。风险等级best-effort从review_data.json按id补。
    ?only_new=1 时只统计本批新题（generation_manifest）。
    """
    only_new = request.args.get("only_new", "").lower() in ("1", "true", "yes")
    out_dir, rep_dir, prefix = _review_ctx()
    new_ids = set(_manifest_ids(out_dir))

    def _lvl(qid: str, explicit: str = "") -> str:
        if explicit:
            return explicit
        # 从 id 推断难度：DOMAIN-H<x>-NNN → L<x>
        m = re.search(r"-H(\d)-", qid or "")
        return f"L{m.group(1)}" if m else "?"

    # 风险等级查表（best-effort，从 review_data.json 按 id 补充）
    rd = _load_json_safe(rep_dir / f"{prefix}review_data.json")
    risk_by_id = {q.get("question_id", ""): q.get("risk_level", "?")
                  for q in (rd.get("questions") or [])}

    # 主数据源：扫 output 目录的「题目」文件（每题一个 dict JSON）
    skip = {"generation_manifest.json", "question_quality_metrics.json",
            "reasoning_path_validation.json", "llm_judge_question_scores.json",
            "selfcheck_results.json", "llm_repair_log.json",
            "expert_feedback_apply_log.json", "expert_feedback.json",
            "usable_ids.json", "usable_question_ids.json",
            "final_questions.json", "review_data.json"}
    rows: list[dict] = []
    seen: set[str] = set()
    for jf in sorted(Path(out_dir).rglob("*.json")):
        # 跳过 reports 子目录、rejected 归档、临时过滤目录、元数据/列表文件
        if jf.name in skip:
            continue
        if any(p in ("reports", "rejected") or p.startswith("_idfilter_")
               for p in jf.parts):
            continue
        d = _load_json_safe(jf)
        if not isinstance(d, dict):
            continue
        qid = d.get("id", "")
        if not qid or qid in seen:
            continue
        seen.add(qid)
        rows.append({
            "id": qid,
            "domain": d.get("domain", "?"),
            "difficulty": _lvl(qid, d.get("difficulty_level", "")),
            "risk": risk_by_id.get(qid, "?"),
        })

    if only_new:
        rows = [r for r in rows if r["id"] in new_ids]

    # pass 池 = 专家手动接受的题（expert_accepted_ids.json）；其余为待审。
    # 不用 usable_ids.json——那是自动审核导出的「自动通过」集，不代表专家已接受。
    usable = _load_json_safe(rep_dir / "expert_accepted_ids.json")
    usable_ids = set(usable) if isinstance(usable, list) else set()

    def _agg(rs: list[dict]) -> dict:
        bd: dict[str, int] = {}
        bf: dict[str, int] = {}
        for r in rs:
            bd[r["domain"]] = bd.get(r["domain"], 0) + 1
            bf[r["difficulty"]] = bf.get(r["difficulty"], 0) + 1
        return {"total": len(rs),
                "by_domain": dict(sorted(bd.items())),
                "by_difficulty": dict(sorted(bf.items()))}

    pass_rows = [r for r in rows if r["id"] in usable_ids]
    pending_rows = [r for r in rows if r["id"] not in usable_ids]

    by_risk: dict[str, int] = {}
    for r in rows:
        by_risk[r["risk"]] = by_risk.get(r["risk"], 0) + 1

    return jsonify({
        "total": len(rows),
        "scope": "new" if only_new else "all",
        "new_total": len(new_ids),
        "pass": _agg(pass_rows),       # 已接受/可用题（pass 池）
        "pending": _agg(pending_rows), # 待审题（题库 − pass）
        "by_risk": by_risk,
    })


# ─── Fast-path: single reject without full re-review ─────────────────────
# 专家点 reject 某条时，立即处理：移动题到 output/rejected/ + 从 review_data.json 删该条。
# 1-2 秒返回，**不**触发完整 4 关 + LLM Judge 重审。
# 设计目的：避免 reject 单条要等 30 分钟 review。
@app.route("/api/expert/reject-one", methods=["POST"])
def expert_reject_one():
    data = request.get_json() or {}
    qid = (data.get("question_id") or "").strip()
    if not qid:
        return jsonify({"error": "question_id required"}), 400

    out_dir, rep_dir = _batch_ctx(data.get("batch", ""))   # 批次：题目目录 + 报告目录
    prefix = ""
    cmd = [
        sys.executable,
        str(SCRIPT_DIR / "apply_expert_feedback.py"),
        "--input-dir", str(out_dir),
        "--report-dir", str(rep_dir),
        "--single-reject", qid,
        "--apply",
    ]
    if prefix:
        cmd += ["--report-prefix", prefix]
    try:
        completed = subprocess.run(
            cmd, cwd=str(REPO_ROOT), capture_output=True, text=True,
            encoding="utf-8", errors="replace", timeout=30,
        )
    except subprocess.TimeoutExpired:
        return jsonify({"error": "single-reject timeout (30s)"}), 504
    if completed.returncode != 0:
        return jsonify({
            "error": "single-reject failed",
            "stderr": (completed.stderr or "")[-500:],
        }), 500
    return jsonify({
        "ok": True,
        "question_id": qid,
        "log_tail": (completed.stdout or "")[-300:],
    })


# ─── Fast-path: single accept(pass) without full re-review ───────────────
# 专家点 pass 某条时：题留在题库、记入 usable_ids.json，从 review_data.json 删该条。
@app.route("/api/expert/accept-one", methods=["POST"])
def expert_accept_one():
    data = request.get_json() or {}
    qid = (data.get("question_id") or "").strip()
    if not qid:
        return jsonify({"error": "question_id required"}), 400

    out_dir, rep_dir = _batch_ctx(data.get("batch", ""))   # 批次：题目目录 + 报告目录
    prefix = ""
    cmd = [
        sys.executable,
        str(SCRIPT_DIR / "apply_expert_feedback.py"),
        "--input-dir", str(out_dir),
        "--report-dir", str(rep_dir),
        "--single-accept", qid,
        "--apply",
    ]
    if prefix:
        cmd += ["--report-prefix", prefix]
    try:
        completed = subprocess.run(
            cmd, cwd=str(REPO_ROOT), capture_output=True, text=True,
            encoding="utf-8", errors="replace", timeout=30,
        )
    except subprocess.TimeoutExpired:
        return jsonify({"error": "single-accept timeout (30s)"}), 504
    if completed.returncode != 0:
        return jsonify({
            "error": "single-accept failed",
            "stderr": (completed.stderr or "")[-500:],
        }), 500
    return jsonify({
        "ok": True,
        "question_id": qid,
        "log_tail": (completed.stdout or "")[-300:],
    })


# Known report base names produced by evaluation.py / llm_repair.py / apply_expert_feedback.py.
# A run may prefix these (e.g. "run_syl"); we strip the prefix to group versions.
_REPORT_BASENAMES = [
    "selfcheck_report.md", "selfcheck_results.json",
    "quality_report.md", "question_quality_metrics.json",
    "path_validation_report.md", "reasoning_path_validation.json",
    "llm_judge_report.md", "llm_judge_question_scores.json",
    "review_data.json", "usable_ids.json",
    "llm_repair_log.json", "llm_repair_summary.md",
    "expert_feedback_apply_log.json", "expert_feedback.json",
    "final_questions_for_review.md",
]


def _report_basename(name: str) -> str:
    """Map a (possibly prefixed) report file to its canonical type key.

    'run_sylllm_judge_report.md' → 'llm_judge_report.md'. Unknown files key on
    their own name so they are never collapsed away.
    """
    for base in _REPORT_BASENAMES:
        if name == base or name.endswith(base):
            return base
    return name


@app.route("/api/kg_eval", methods=["POST"])
def start_kg_eval():
    """步骤 ⑩：用当前题目反向测评图谱（四维打分 + 优化诊断）。

    复用现有后台任务机制（run_task），命令为 `python -m kg_eval.run_kg_eval ...`，
    工作目录为 gen_key 根（保证 kg_eval 包可 import）。出题逻辑完全不受影响。
    """
    data = request.get_json() or {}
    tid = str(uuid.uuid4())[:8]

    db = _clean_path(data.get("db", "")) or str(KG_DB_DEFAULT)
    retriever = _clean_path(data.get("retriever", "")) or str(KG_RETRIEVER_DEFAULT)
    # 题目目录 + 测评报告目录：默认落当前用户工作区（隔离）。显式入参可覆盖。
    _, u_out, _ = _user_dirs()
    kg_out_default = u_out.parent / "kg_eval_output"
    questions_dir = _clean_path(data.get("questions_dir", "")) or str(u_out)
    out_dir = _clean_path(data.get("out", "")) or str(kg_out_default)

    cmd = [
        sys.executable, "-m", "kg_eval.run_kg_eval",
        "--db", db,
        "--retriever", retriever,
        "--questions-dir", questions_dir,
        "--out", out_dir,
    ]
    if data.get("judge_model"):
        cmd += ["--judge-model", str(data["judge_model"])]
    elif _model_chain("judge", data):
        cmd += ["--judge-model", _model_chain("judge", data)]
    # 图谱推理 LLM：用「推理模型优先级」链（run_kg_eval 取链首；链供降级参考）
    reason_chain = _model_chain("reason", data)
    if reason_chain:
        cmd += ["--kg-llm-model", reason_chain]
    if data.get("no_judge"):
        cmd.append("--no-judge")
    if data.get("limit"):
        cmd += ["--limit", str(data["limit"])]
    if data.get("feed_backflow"):
        cmd.append("--feed-backflow")

    with tasks_lock:
        tasks[tid] = {
            "type": "kg_eval", "status": "pending", "created_at": _now_str(),
            "start_time": 0, "cmd": cmd, "logs": [], "pid": None, "exit_code": None,
        }
    _add_log(tid, "图谱测评任务已创建")
    # cwd = gen_key 根，让 `python -m kg_eval.run_kg_eval` 能找到包
    t = threading.Thread(target=run_task, args=(tid, cmd, str(GEN_KEY_ROOT)), daemon=True)
    with tasks_lock:
        tasks[tid]["start_time"] = time.time()
    t.start()
    return jsonify({"task_id": tid})


@app.route("/api/kg_eval/report", methods=["GET"])
def get_kg_eval_report():
    """读取最新的图谱测评 report.json 供前端渲染。"""
    _, u_out, _ = _user_dirs()
    out_dir = _clean_path(request.args.get("out", "")) or str(u_out.parent / "kg_eval_output")
    fp = Path(out_dir) / "report.json"
    if not fp.exists():
        return jsonify({"exists": False})
    try:
        return jsonify({"exists": True, "report": json.loads(fp.read_text(encoding="utf-8"))})
    except (json.JSONDecodeError, OSError) as e:
        return jsonify({"exists": False, "error": str(e)})


# 图谱测评产物：允许下载的文件名白名单（防路径穿越 + 限定范围）
_KG_EVAL_DOWNLOADABLE = {
    "report.md":    "text/markdown; charset=utf-8",
    "report.json":  "application/json",
    "answers.json": "application/json",
}


@app.route("/api/kg_eval/report/download", methods=["GET"])
def download_kg_eval_report():
    """下载图谱测评产物（report.md / report.json / answers.json）。

    file 缺省下载 report.md；其余两个文件经白名单校验后下载。
    out 目录默认与 get_kg_eval_report 一致（当前用户工作区 kg_eval_output）。
    """
    _, u_out, _ = _user_dirs()
    out_dir = _clean_path(request.args.get("out", "")) or str(u_out.parent / "kg_eval_output")
    fname = (request.args.get("file", "") or "report.md").strip()
    mimetype = _KG_EVAL_DOWNLOADABLE.get(fname)
    if mimetype is None:
        return jsonify({"error": "invalid file"}), 400
    fp = Path(out_dir) / fname
    if not fp.exists():
        return jsonify({"error": "not found"}), 404
    return send_file(str(fp), mimetype=mimetype, as_attachment=True, download_name=fname)


@app.route("/api/output", methods=["GET"])
def list_output():
    """列出 output / reports 目录内容。

    题目：递归统计每个分类目录的「题目」JSON（排除 manifest/报告等元数据）。
    报告：按所在子目录（批次）分组，每批次每类报告只取最新一版（按修改时间）。
    """
    out_dir, rep_dir = _resolve_dirs()
    result = {"questions": [], "reports": [], "reports_batches": [],
              "output_dir": str(out_dir), "report_dir": str(rep_dir)}

    # ── 题目：每个分类目录递归计数；根目录散题归入「(根)」组 ──
    if out_dir.exists():
        for d in sorted(out_dir.iterdir()):
            if d.is_dir() and d.name != "reports":
                files = [str(jf.relative_to(d)).replace("\\", "/")
                         for jf in sorted(d.rglob("*.json")) if _is_question_file(jf)]
                if files:
                    result["questions"].append({"dir": d.name, "count": len(files), "files": files})
        root_files = [jf.name for jf in sorted(out_dir.glob("*.json")) if _is_question_file(jf)]
        if root_files:
            result["questions"].append({"dir": "(根)", "count": len(root_files), "files": root_files})

    # ── 报告：按所在子目录分组（批次），每批每类取最新 ──
    if rep_dir.exists():
        bydir: dict[Path, list[Path]] = {}
        for f in rep_dir.rglob("*"):
            if f.is_file() and f.suffix in (".md", ".json"):
                bydir.setdefault(f.parent, []).append(f)
        batches = []
        for d, files in bydir.items():
            rel = d.relative_to(rep_dir)
            bid = "default" if str(rel) in (".", "") else str(rel).replace("\\", "/")
            latest: dict[str, Path] = {}
            for f in files:
                key = _report_basename(f.name)
                cur = latest.get(key)
                if cur is None or f.stat().st_mtime > cur.stat().st_mtime:
                    latest[key] = f
            flist = [{
                "name": f.name,
                "size": f.stat().st_size,
                "modified": datetime.fromtimestamp(f.stat().st_mtime).strftime("%Y-%m-%d %H:%M"),
            } for f in sorted(latest.values(), key=lambda p: p.name)]
            batches.append({"batch": bid, "dir": bid, "files": flist})
        batches.sort(key=lambda b: (b["batch"] != "default", b["batch"]))
        result["reports_batches"] = batches
        # 向后兼容：reports = 默认（扁平）批次的文件
        for b in batches:
            if b["batch"] == "default":
                result["reports"] = b["files"]
                break
    return jsonify(result)

@app.route("/api/output/questions/<path:dir_name>", methods=["GET"])
def get_questions(dir_name):
    out_dir, _ = _resolve_dirs()
    if dir_name == "(根)":
        dir_path = out_dir
        recursive = False
    else:
        dir_path = (out_dir / dir_name)
        recursive = True
    if not dir_path.exists():
        return jsonify({"error": "not found"}), 404
    files = sorted(dir_path.rglob("*.json")) if recursive else sorted(dir_path.glob("*.json"))
    questions = []
    for f in files:
        if not _is_question_file(f):
            continue
        try:
            q = json.loads(f.read_text(encoding="utf-8"))
            if isinstance(q, list):
                questions.extend(q)
            else:
                questions.append(q)
        except Exception:
            pass
    return jsonify(questions)


@app.route("/api/output/questions/<path:dir_name>/download", methods=["GET"])
def download_questions(dir_name):
    """把某一分类目录下的题目合并成一个 JSON 文件下载回本地。

    dir_name 为 list_output 给出的分类目录名（'(根)' 表示输出根目录散题）。
    """
    out_dir, _ = _resolve_dirs()
    if dir_name == "(根)":
        dir_path = out_dir
        recursive = False
    else:
        dir_path = (out_dir / dir_name)
        recursive = True
    if not dir_path.exists():
        return jsonify({"error": "not found"}), 404
    files = sorted(dir_path.rglob("*.json")) if recursive else sorted(dir_path.glob("*.json"))
    questions = []
    for f in files:
        if not _is_question_file(f):
            continue
        try:
            q = json.loads(f.read_text(encoding="utf-8"))
            questions.extend(q if isinstance(q, list) else [q])
        except (json.JSONDecodeError, OSError):
            pass
    payload = json.dumps(questions, ensure_ascii=False, indent=2).encode("utf-8")
    safe_name = (dir_name if dir_name != "(根)" else "root").replace("/", "_").replace("\\", "_")
    return send_file(
        io.BytesIO(payload),
        mimetype="application/json",
        as_attachment=True,
        download_name=f"questions_{safe_name}.json",
    )


@app.route("/api/output/questions_all/download", methods=["GET"])
def download_all_questions():
    """把当前工作区所有分类目录的题目打包成 ZIP 下载（每类一个 JSON）。"""
    out_dir, _ = _resolve_dirs()
    if not out_dir.exists():
        return jsonify({"error": "not found"}), 404
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        wrote = False
        for d in sorted(out_dir.iterdir()):
            if not d.is_dir() or d.name == "reports":
                continue
            qs = []
            for jf in sorted(d.rglob("*.json")):
                if not _is_question_file(jf):
                    continue
                try:
                    q = json.loads(jf.read_text(encoding="utf-8"))
                    qs.extend(q if isinstance(q, list) else [q])
                except (json.JSONDecodeError, OSError):
                    pass
            if qs:
                zf.writestr(f"{d.name}.json", json.dumps(qs, ensure_ascii=False, indent=2))
                wrote = True
        # 根目录散题
        root_qs = []
        for jf in sorted(out_dir.glob("*.json")):
            if not _is_question_file(jf):
                continue
            try:
                q = json.loads(jf.read_text(encoding="utf-8"))
                root_qs.extend(q if isinstance(q, list) else [q])
            except (json.JSONDecodeError, OSError):
                pass
        if root_qs:
            zf.writestr("root.json", json.dumps(root_qs, ensure_ascii=False, indent=2))
            wrote = True
        if not wrote:
            return jsonify({"error": "no questions"}), 404
    buf.seek(0)
    return send_file(buf, mimetype="application/zip",
                     as_attachment=True, download_name="all_questions.zip")
    """定位 rep_dir/<batch>/<file_name>，并校验未逃出 rep_dir（防越界）。"""
    base = rep_dir
    bid = (batch or "").strip()
    if bid and bid != "default":
        # batch 可能是多级相对目录，逐段清洗
        for seg in Path(bid).parts:
            s = _safe_seg(seg)
            if s and s not in (".", ".."):
                base = base / s
    fp = (base / _safe_seg(Path(file_name).name)).resolve()
    rep_res = rep_dir.resolve()
    if fp != rep_res and rep_res not in fp.parents:
        return None
    return fp

@app.route("/api/output/reports/<file_name>", methods=["GET"])
def get_report(file_name):
    _, rep_dir = _resolve_dirs()
    fp = _resolve_report_path(rep_dir, request.args.get("batch", ""), file_name)
    if fp is None or not fp.exists():
        return jsonify({"error": "not found"}), 404
    content = fp.read_text(encoding="utf-8", errors="replace")
    return jsonify({"name": fp.name, "content": content})

@app.route("/api/output/reports/<file_name>/download", methods=["GET"])
def download_report(file_name):
    """Download a report file."""
    _, rep_dir = _resolve_dirs()
    fp = _resolve_report_path(rep_dir, request.args.get("batch", ""), file_name)
    if fp is None or not fp.exists():
        return jsonify({"error": "not found"}), 404
    mimetype = "application/json" if fp.name.endswith(".json") else "text/markdown"
    return send_file(str(fp), mimetype=mimetype, as_attachment=True, download_name=fp.name)

@app.route("/api/extern", methods=["GET"])
def list_extern():
    """列出当前用户工作区 extern_data 的 PDF。"""
    pdfs = []
    extern_dir, _, _ = _user_dirs()
    if extern_dir.exists():
        for f in sorted(extern_dir.iterdir()):
            if f.suffix.lower() == ".pdf":
                pdfs.append({
                    "name": f.name,
                    "size": f.stat().st_size,
                    "modified": datetime.fromtimestamp(f.stat().st_mtime).strftime("%Y-%m-%d %H:%M"),
                })
    return jsonify(pdfs)

# --- HTML Template ---
HTML_TEMPLATE = r'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>QAG - 知识图谱出题与图谱测评平台</title>
<style>
:root {
  --primary: #6c3ce0;
  --primary-dark: #4a1eb8;
  --primary-light: #8b5cf6;
  --bg: #f5f3ff;
  --card-bg: #ffffff;
  --text: #1a1033;
  --text-secondary: #6b7280;
  --border: #e5e7eb;
  --success: #10b981;
  --danger: #ef4444;
  --warning: #f59e0b;
  --radius: 12px;
  --shadow: 0 1px 3px rgba(0,0,0,0.08), 0 1px 2px rgba(0,0,0,0.06);
  --shadow-lg: 0 10px 25px rgba(108,60,224,0.12);
}
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif; background: var(--bg); color: var(--text); min-height: 100vh; }
.header { background: linear-gradient(135deg, #4a1eb8 0%, #6c3ce0 40%, #8b5cf6 100%); color: #fff; padding: 28px 40px 20px; box-shadow: 0 4px 20px rgba(108,60,224,0.25); }
.header h1 { font-size: 24px; font-weight: 700; letter-spacing: 0.5px; }
.header p { font-size: 13px; opacity: 0.85; margin-top: 4px; }
.nav { display: flex; gap: 0; background: #fff; border-bottom: 1px solid var(--border); padding: 0 40px; overflow-x: auto; }
.nav button { padding: 14px 22px; border: none; background: none; cursor: pointer; font-size: 14px; color: var(--text-secondary); border-bottom: 2px solid transparent; transition: all 0.2s; white-space: nowrap; font-weight: 500; }
.nav button:hover { color: var(--primary); }
.nav button.active { color: var(--primary); border-bottom-color: var(--primary); font-weight: 600; }
.content { max-width: 1000px; margin: 24px auto; padding: 0 24px; }
.tab { display: none; }
.tab.active { display: block; }
.card { background: var(--card-bg); border-radius: var(--radius); box-shadow: var(--shadow); padding: 24px; margin-bottom: 20px; border: 1px solid var(--border); }
.card h3 { font-size: 16px; margin-bottom: 16px; color: var(--primary-dark); display: flex; align-items: center; gap: 8px; }
.card h3 .icon { width: 6px; height: 20px; background: linear-gradient(135deg, var(--primary), var(--primary-light)); border-radius: 3px; display: inline-block; }
.form-group { margin-bottom: 16px; }
.form-group label { display: block; font-size: 13px; font-weight: 600; color: var(--text-secondary); margin-bottom: 6px; }
.form-group input, .form-group select, .form-group textarea { width: 100%; padding: 10px 14px; border: 1px solid var(--border); border-radius: 8px; font-size: 14px; transition: border-color 0.2s; outline: none; background: #fafafa; }
.form-group input:focus, .form-group select:focus { border-color: var(--primary); background: #fff; box-shadow: 0 0 0 3px rgba(108,60,224,0.1); }
.form-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; }
.btn { display: inline-flex; align-items: center; gap: 6px; padding: 10px 22px; border: none; border-radius: 8px; font-size: 14px; font-weight: 600; cursor: pointer; transition: all 0.2s; }
.btn-primary { background: linear-gradient(135deg, var(--primary), var(--primary-light)); color: #fff; box-shadow: 0 2px 8px rgba(108,60,224,0.3); }
.btn-primary:hover { transform: translateY(-1px); box-shadow: 0 4px 14px rgba(108,60,224,0.4); }
.btn-success { background: var(--success); color: #fff; }
.btn-danger { background: var(--danger); color: #fff; }
.btn-outline { background: #fff; border: 1px solid var(--border); color: var(--text); }
.btn-outline:hover { border-color: var(--primary); color: var(--primary); }
.btn-sm { padding: 6px 14px; font-size: 12px; }
.btn:disabled { opacity: 0.6; cursor: not-allowed; transform: none; }
.task-list { max-height: 500px; overflow-y: auto; }
.task-item { padding: 12px 16px; border: 1px solid var(--border); border-radius: 8px; margin-bottom: 8px; display: flex; justify-content: space-between; align-items: center; transition: all 0.2s; }
.task-item:hover { background: #faf5ff; }
.task-info { display: flex; align-items: center; gap: 12px; }
.task-type { font-size: 11px; padding: 3px 10px; border-radius: 12px; font-weight: 600; }
.task-type.generate { background: #ede9fe; color: #6c3ce0; }
.task-type.review { background: #dbeafe; color: #2563eb; }
.task-type.pipeline { background: #fef3c7; color: #d97706; }
.task-type.expert_apply { background: #dcfce7; color: #15803d; }
.task-type.self_repair { background: #fae8ff; color: #a21caf; }
.status-dot { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; }
.status-dot.running { background: #f59e0b; animation: pulse 1.5s infinite; }
.status-dot.done { background: #10b981; }
.status-dot.failed { background: #ef4444; }
.status-dot.stopped { background: #6b7280; }
.status-dot.pending { background: #d1d5db; }
@keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.4; } }
.log-viewer { background: #1a1033; color: #a78bfa; padding: 16px; border-radius: 8px; font-family: "Cascadia Code", "Fira Code", Consolas, monospace; font-size: 12px; max-height: 400px; overflow-y: auto; white-space: pre-wrap; line-height: 1.6; }
.log-info { color: #c4b5fd; }
.log-error { color: #fca5a5; }
.log-success { color: #6ee7b7; }
.result-card { padding: 16px; border: 1px solid var(--border); border-radius: 8px; margin-bottom: 12px; }
.result-card.collapsed .result-body { display: none; }
.result-header { cursor: pointer; display: flex; justify-content: space-between; align-items: center; font-weight: 600; font-size: 14px; }
.result-body { margin-top: 12px; padding-top: 12px; border-top: 1px solid var(--border); }
.badge { display: inline-block; padding: 2px 10px; border-radius: 10px; font-size: 11px; font-weight: 600; }
.badge-l1 { background: #d1fae5; color: #065f46; }
.badge-l2 { background: #dbeafe; color: #1e40af; }
.badge-l3 { background: #fef3c7; color: #92400e; }
.badge-l4 { background: #fce7f3; color: #9d174d; }
.report-link { display: flex; align-items: center; gap: 8px; padding: 10px 14px; border: 1px solid var(--border); border-radius: 8px; margin-bottom: 8px; cursor: pointer; transition: all 0.2s; }
.report-link:hover { background: #faf5ff; border-color: var(--primary); }
.report-link .name { font-weight: 600; font-size: 14px; }
.report-link .meta { font-size: 12px; color: var(--text-secondary); margin-left: auto; }
.report-content { max-height: 600px; overflow-y: auto; background: #faf5ff; padding: 20px; border-radius: 8px; margin-top: 12px; font-size: 14px; line-height: 1.8; display: none; }
.report-content.show { display: block; }
.empty-state { text-align: center; padding: 60px 20px; color: var(--text-secondary); }
.empty-state .icon { font-size: 48px; margin-bottom: 12px; }
.toast { position: fixed; top: 20px; right: 20px; padding: 12px 20px; border-radius: 8px; color: #fff; font-size: 14px; font-weight: 500; z-index: 1000; animation: slideIn 0.3s ease; box-shadow: 0 4px 12px rgba(0,0,0,0.15); }
.toast.success { background: var(--success); }
.toast.error { background: var(--danger); }
@keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
.flex-between { display: flex; justify-content: space-between; align-items: center; }
.gap-8 { gap: 8px; }
.mt-12 { margin-top: 12px; }
.mt-16 { margin-top: 16px; }
.pdf-list { display: grid; gap: 6px; }
.pdf-item { display: flex; align-items: center; gap: 10px; padding: 8px 12px; background: #faf5ff; border-radius: 6px; font-size: 13px; }
.pdf-item .pdf-name { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.pdf-item .pdf-size { color: var(--text-secondary); font-size: 12px; flex-shrink: 0; }
.progress-bar { height: 6px; background: #e5e7eb; border-radius: 3px; margin-top: 12px; overflow: hidden; }
.progress-bar .fill { height: 100%; background: linear-gradient(90deg, var(--primary), var(--primary-light)); border-radius: 3px; transition: width 0.3s; width: 0%; }
.theme-toggle { position: fixed; bottom: 24px; right: 24px; width: 44px; height: 44px; border-radius: 50%; background: var(--card-bg); border: 1px solid var(--border); cursor: pointer; font-size: 20px; display: flex; align-items: center; justify-content: center; box-shadow: var(--shadow-lg); z-index: 100; transition: all 0.2s; }
.theme-toggle:hover { transform: scale(1.1); }
/* Dark theme */
body.dark { --bg: #0f0a1a; --card-bg: #1a1333; --text: #e5e0f7; --text-secondary: #9ca3af; --border: #2d2355; }
body.dark .nav { background: #1a1333; border-bottom-color: #2d2355; }
body.dark .form-group input, body.dark .form-group select { background: #0f0a1a; border-color: #2d2355; color: #e5e0f7; }
body.dark .form-group input:focus, body.dark .form-group select:focus { background: #1a1333; }
body.dark .task-item:hover { background: #1a1040; }
body.dark .btn-outline { background: #1a1333; }
body.dark .report-link:hover { background: #1a1040; }
body.dark .report-content { background: #1a1040; }
body.dark .pdf-item { background: #1a1040; }
/* Model priority list (fallback chain) */
.model-list { display: flex; flex-direction: column; gap: 6px; }
.model-row { display: flex; align-items: center; gap: 8px; padding: 7px 10px; background: #faf5ff; border: 1px solid var(--border); border-radius: 8px; font-size: 13px; }
.model-row.disabled { opacity: 0.5; background: #f3f4f6; }
.model-row .rank { width: 20px; text-align: center; font-weight: 700; color: var(--primary); flex-shrink: 0; }
.model-row .mname { flex: 1; font-weight: 500; }
.model-row .move { display: flex; gap: 2px; flex-shrink: 0; }
.model-row .move button { width: 24px; height: 24px; border: 1px solid var(--border); background: #fff; border-radius: 5px; cursor: pointer; font-size: 12px; line-height: 1; padding: 0; }
.model-row .move button:hover:not(:disabled) { border-color: var(--primary); color: var(--primary); }
.model-row .move button:disabled { opacity: 0.35; cursor: not-allowed; }
body.dark .model-row { background: #1a1040; }
body.dark .model-row.disabled { background: #15102e; }
body.dark .model-row .move button { background: #1a1333; }
</style>
</head>
<body>

<!-- ===== 登录遮罩（未登录时盖住整个应用）===== -->
<div id="auth-overlay" style="display:none;position:fixed;inset:0;z-index:9999;background:rgba(20,16,40,0.75);align-items:center;justify-content:center">
  <div style="background:var(--card-bg,#fff);padding:28px 32px;border-radius:14px;box-shadow:0 10px 40px rgba(0,0,0,.3);width:340px">
    <h2 id="auth-title" style="margin:0 0 4px">登录 QAG 平台</h2>
    <p style="margin:0 0 16px;font-size:13px;color:var(--text-secondary)">出题 · 审核 · 图谱测评（每个账号数据独立隔离）</p>
    <div class="form-group"><label>用户名</label><input type="text" id="auth-user" placeholder="3-32 位字母/数字/_.-" style="width:100%;padding:8px"></div>
    <div class="form-group" style="margin-top:8px"><label>密码</label><input type="password" id="auth-pass" placeholder="至少 6 位" style="width:100%;padding:8px" onkeydown="if(event.key==='Enter')doLogin()"></div>
    <div id="auth-msg" style="color:#ef4444;font-size:13px;min-height:18px;margin:8px 0"></div>
    <div style="display:flex;gap:10px">
      <button class="btn btn-primary" style="flex:1" onclick="doLogin()">登录</button>
      <button class="btn btn-outline" style="flex:1" onclick="doRegister()">注册</button>
    </div>
  </div>
</div>

<div class="header" style="display:flex;justify-content:space-between;align-items:center">
  <div>
    <h1>QAG - 知识图谱出题与图谱测评平台</h1>
    <p>领域文献知识图谱：自动出题 · 专家审查 · 四维图谱测评</p>
  </div>
  <div style="font-size:13px;white-space:nowrap">
    <span id="auth-username" style="font-weight:600"></span>
    <button class="btn btn-outline btn-sm" style="margin-left:8px" onclick="doLogout()">退出</button>
  </div>
</div>

<div class="nav">
  <button class="active" data-tab="config">配置</button>
  <button data-tab="generate">出题</button>
  <button data-tab="review">审核</button>
  <button data-tab="expert">专家审查</button>
  <button data-tab="tasks">任务</button>
  <button data-tab="results">结果</button>
  <button data-tab="reports">质量报告</button>
  <button data-tab="kgeval">图谱测评</button>
  <button data-tab="help">使用说明</button>
</div>

<div class="content">

  <!-- ===== 配置 Tab ===== -->
  <div id="tab-config" class="tab active">
    <div class="card">
      <h3><span class="icon"></span>LLM 配置</h3>
      <div class="form-group">
        <label>API Base URL</label>
        <input type="text" id="cfg-api-url" placeholder="http://43.153.42.7:3001/v1">
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>出题模型优先级 <span style="font-size:11px;color:var(--text-secondary)">（越靠上越优先，调用失败自动降到下一行；取消勾选=不参与）</span></label>
          <div class="model-list" id="cfg-gen-model-list"></div>
        </div>
        <div class="form-group">
          <label>Judge 模型优先级 <span style="font-size:11px;color:var(--text-secondary)">（同时用于审核 / LLM自纠 / 专家反馈）</span></label>
          <div class="model-list" id="cfg-judge-model-list"></div>
        </div>
        <div class="form-group">
          <label>推理模型优先级 <span style="font-size:11px;color:var(--text-secondary)">（图谱测评时：图谱检索后接 LLM 做问答推理 / 查询翻译 / 抽种子；越靠上越优先）</span></label>
          <div class="model-list" id="cfg-reason-model-list"></div>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group" style="display:none">
          <label>模型名称（内部）</label>
          <input type="text" id="cfg-model" placeholder="claude-sonnet-4-6">
        </div>
        <div class="form-group">
          <label>请求超时时间 (秒)</label>
          <input type="number" id="cfg-timeout" placeholder="120" min="10" max="3600">
        </div>
      </div>
      <div class="form-group">
        <label>API Key</label>
        <input type="password" id="cfg-api-key" placeholder="sk-xxx">
      </div>
    </div>

    <div class="card">
      <h3><span class="icon"></span>服务端口</h3>
      <div class="form-row">
        <div class="form-group">
          <label>前端访问后端的 API Base URL</label>
          <input type="text" id="cfg-app-api" value="http://localhost:5000" readonly>
        </div>
        <div class="form-group">
          <label>服务端口 <span style="font-size:11px;color:var(--text-secondary)">（启动时由 --port 决定，重启生效）</span></label>
          <input type="number" id="cfg-backend-port" placeholder="5000" min="1024" max="65535" readonly>
        </div>
        <div class="form-group">
          <label>前端端口</label>
          <input type="number" id="cfg-frontend-port" value="5000" readonly>
        </div>
      </div>
    </div>

    <div class="flex-between mt-16">
      <button class="btn btn-primary" onclick="saveConfig()">保存配置</button>
      <button class="btn btn-outline" onclick="loadConfig()">刷新</button>
    </div>
  </div>

  <!-- ===== 出题 Tab ===== -->
  <div id="tab-generate" class="tab">
    <div class="card">
      <h3><span class="icon"></span>出题参数</h3>
      <div class="form-row">
        <div class="form-group">
          <label>数据来源</label>
          <select id="gen-source">
            <option value="external">external - 专家 PDF</option>
            <option value="internal">internal - 内部 KB</option>
            <option value="mixed">mixed - KB+PDF 混合</option>
          </select>
        </div>
        <div class="form-group">
          <label>难度 / 跳数 (hops) <span style="font-size:11px;color:var(--text-secondary);font-weight:400">（按住 Ctrl 可多选）</span></label>
          <select id="gen-hops" multiple style="height:120px">
            <option value="1">L1 - 简单事实检索 (1-hop)</option>
            <option value="2">L2 - 多跳逻辑推理 (2-hop)</option>
            <option value="3">L3 - 主题概括类 (3-hop)</option>
            <option value="4">L4 - 创新发散题目 (4-hop)</option>
          </select>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>领域 (domains) <span style="font-size:11px;color:var(--text-secondary);font-weight:400">（按住 Ctrl 可多选）</span></label>
          <select id="gen-domains" multiple style="height:120px">
            <option value="FABS">FABS - 工艺制备</option>
            <option value="HCFG">HCFG - 形态构型</option>
            <option value="MECH">MECH - 物理机理</option>
            <option value="POPT">POPT - 参数优化</option>
          </select>
        </div>
        <div class="form-group">
          <label>每领域题数 (num_per_domain)</label>
          <input type="number" id="gen-num" value="2" min="1" max="20">
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>PDF 数量范围 (paper_range)</label>
          <input type="text" id="gen-paper-range" value="1-3" placeholder="1 / 1-3 / auto">
        </div>
        <div class="form-group"></div>
      </div>
    </div>

    <div class="card">
      <h3><span class="icon"></span>专家 PDF 列表 <span style="font-weight:400;font-size:12px;color:var(--text-secondary);margin-left:8px" id="pdf-count"></span></h3>
      <div style="margin-bottom:10px;padding:10px;background:var(--bg-secondary,#faf8ff);border-radius:8px">
        <label style="font-size:13px;font-weight:600">⬆️ 上传 PDF 到我的工作区（可多选）</label>
        <div style="display:flex;gap:8px;align-items:center;margin-top:6px;flex-wrap:wrap">
          <input type="file" id="pdf-upload-input" accept=".pdf" multiple>
          <button class="btn btn-primary btn-sm" onclick="uploadPdf()">上传</button>
          <span id="pdf-upload-msg" style="font-size:12px;color:var(--text-secondary)"></span>
        </div>
        <div style="font-size:11px;color:var(--text-secondary);margin-top:4px">上传后即作为出题的外部 PDF 源（你自己的工作区，不与他人共享）。</div>
      </div>
      <div class="pdf-list" id="pdf-list" style="max-height:200px;overflow-y:auto">加载中...</div>
    </div>

    <div class="flex-between mt-16">
      <div class="flex-between gap-8">
        <button class="btn btn-primary" onclick="startGenerate()">开始出题</button>
        <button class="btn btn-outline btn-sm" onclick="startGenerate(true)">Dry Run 预览</button>
        <button class="btn btn-outline btn-sm" onclick="quickPreset('L2')">仅出L2(多跳)</button>
        <button class="btn btn-outline btn-sm" onclick="quickPreset('L3')">仅出L3(概括)</button>
        <button class="btn btn-outline btn-sm" onclick="quickPreset('L4')">仅出L4(发散)</button>
      </div>
      <span style="font-size:13px;color:var(--text-secondary)">
        总题数 = 领域数 x hop数 x 每领域题数
      </span>
    </div>
  </div>

  <!-- ===== 审核 Tab ===== -->
  <div id="tab-review" class="tab">
    <div class="card">
      <h3><span class="icon"></span>审核流程 (5 步)</h3>
      <table style="width:100%;font-size:13px;border-collapse:collapse">
        <thead>
          <tr style="text-align:left;border-bottom:1px solid var(--border)">
            <th style="padding:8px">步骤</th><th style="padding:8px">脚本</th><th style="padding:8px">作用</th>
          </tr>
        </thead>
        <tbody>
          <tr><td style="padding:8px">1</td><td style="padding:8px">script/selfcheck.py</td><td style="padding:8px">结构自查</td></tr>
          <tr><td style="padding:8px">2</td><td style="padding:8px">script/check_quality.py</td><td style="padding:8px">本地质量检测（证据/数值/KP/查重）</td></tr>
          <tr><td style="padding:8px">3</td><td style="padding:8px">script/validate_paths.py</td><td style="padding:8px">推理链节点接地验证</td></tr>
          <tr><td style="padding:8px">4</td><td style="padding:8px">script/llm_judge.py</td><td style="padding:8px">LLM 八维语义打分（可选）</td></tr>
          <tr><td style="padding:8px">5</td><td style="padding:8px">script/export_final_questions.py</td><td style="padding:8px">汇总成审查稿</td></tr>
        </tbody>
      </table>
    </div>

    <div class="card">
      <h3><span class="icon"></span>审核参数</h3>
      <div style="margin-bottom:10px;padding:10px;background:var(--bg-secondary,#faf8ff);border-radius:8px">
        <label style="font-size:13px;font-weight:600">⬆️ 上传已有题目/质量报告（.zip 或多个 .json）</label>
        <div style="display:flex;gap:8px;align-items:center;margin-top:6px;flex-wrap:wrap">
          <input type="file" id="bundle-upload-input" accept=".zip,.json" multiple>
          <button class="btn btn-primary btn-sm" onclick="uploadBundle()">上传</button>
          <span id="bundle-upload-msg" style="font-size:12px;color:var(--text-secondary)"></span>
        </div>
        <div style="font-size:11px;color:var(--text-secondary);margin-top:4px">上传后存入你的工作区 output/；留空「输入目录」即用工作区。审核/图谱测评直接读取。</div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>输入目录 (input_dir) <span style="font-size:11px;color:var(--text-secondary)">— 留空=用我的工作区 output</span></label>
          <input type="text" id="rev-input-dir" value="" placeholder="留空即用我的工作区（上传的题目）">
        </div>
        <div class="form-group">
          <label>按 id 过滤 <span style="font-size:11px;color:var(--text-secondary)">— 高级：可精确定位某些题，留空=不限</span></label>
          <input type="text" id="rev-id-filter" placeholder="id 区间: HCFG-H3-188:HCFG-H3-192 ｜ id 列表: H3-188,H3-189 ｜ glob: *HCFG*">
        </div>
      </div>
      <div style="display:flex;gap:16px;align-items:center;margin-top:4px;flex-wrap:wrap">
        <label style="cursor:pointer;font-size:15px;font-weight:600">
          <input type="checkbox" id="rev-only-new" checked style="width:16px;height:16px;vertical-align:middle"> 仅审核最新出的题
          <span style="font-size:11px;font-weight:400;color:var(--text-secondary)">（读 generation_manifest.json；<strong>关闭=审核目录下全部题</strong>）</span>
        </label>
      </div>
      <div style="display:flex;gap:16px;align-items:center;margin-top:4px">
        <label style="cursor:pointer;font-size:15px;font-weight:600">
          <input type="checkbox" id="rev-llm-judge" checked style="width:16px;height:16px;vertical-align:middle"> 启用 LLM-as-a-Judge（<strong>八维</strong>语义打分，使用配置页 Judge 模型）
        </label>
      </div>
    </div>

    <button class="btn btn-primary mt-16" onclick="startReview()">开始审核</button>
  </div>

  <!-- ===== 专家审查 Tab ===== -->
  <div id="tab-expert" class="tab">
    <div class="card">
      <div class="flex-between" style="align-items:center;flex-wrap:wrap;gap:8px">
        <h3 style="margin:0">专家审查面板</h3>
        <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
          <button class="btn btn-outline btn-sm" onclick="loadReviewData()">刷新数据</button>
          <label style="font-size:12px;color:var(--text-secondary)" title="对有 CRITICAL/HIGH 风险的题目自动跑几轮 LLM 自纠">自纠轮数
            <input type="number" id="expert-repair-rounds" value="1" min="1" max="5" style="width:52px;padding:3px 6px">
          </label>
          <button class="btn btn-outline btn-sm" onclick="runRepair()" title="对有风险的题目跑 LLM 自纠并自动重审">&#129520; LLM 自纠</button>
          <label style="font-size:12px;color:var(--text-secondary)" title="取消勾选 = 自纠后不跑 review（节省 30 分钟）">
            <input type="checkbox" id="expert-repair-with-review" checked> 自纠后跑 review
          </label>
          <label style="font-size:12px;color:var(--text-secondary)" title="取消勾选 = 自纠目录下全部题（含旧批次）">
            <input type="checkbox" id="expert-repair-only-new" checked> 仅自纠最新出的题
          </label>
          <button class="btn btn-primary btn-sm" onclick="submitExpertFeedback()">提交专家意见并重审</button>
        </div>
      </div>
      <div id="expert-summary" style="margin-top:12px;font-size:13px;color:var(--text-secondary)">尚未加载。请先在「审核」页运行一次审核以生成 review_data.json。</div>
      <div id="stats-board" style="margin-top:12px"></div>
      <div style="margin-top:10px;display:flex;gap:12px;align-items:center;flex-wrap:wrap">
        <label id="expert-batch-label" style="font-size:13px;display:none">批次:
          <select id="expert-batch-select" onchange="loadReviewData(this.value)" style="padding:4px 8px"></select>
        </label>
        <label style="font-size:13px">风险筛选:
          <select id="expert-risk-filter" onchange="renderExpertCards()" style="padding:4px 8px">
            <option value="ALL">全部</option>
            <option value="FOCUS" selected>仅 HIGH + CRITICAL</option>
            <option value="CRITICAL">CRITICAL</option>
            <option value="HIGH">HIGH</option>
            <option value="MEDIUM">MEDIUM</option>
            <option value="LOW">LOW</option>
            <option value="PASS">PASS</option>
          </select>
        </label>
        <label style="font-size:15px;font-weight:600"><input type="checkbox" id="expert-judge-rerun" checked style="width:16px;height:16px;vertical-align:middle"> 重审时调用 LLM Judge</label>
        <label style="font-size:13px">专家姓名: <input type="text" id="expert-name" placeholder="必填" style="padding:4px 8px;width:120px"></label>
      </div>
    </div>
    <div id="expert-cards"></div>
  </div>

  <!-- ===== 任务 Tab ===== -->
  <div id="tab-tasks" class="tab">
    <div class="flex-between mt-16">
      <h3 style="margin-bottom:16px">任务列表 <span style="font-size:11px;color:var(--primary);font-weight:400" id="task-auto-refresh-badge">⏳ 自动刷新中</span></h3>
      <button class="btn btn-outline btn-sm" onclick="refreshTasks()">刷新 <span id="task-update-time"></span></button>
    </div>
    <div class="task-list" id="task-list">
      <div class="empty-state"><div class="icon">-</div>暂无任务</div>
    </div>
  </div>

  <!-- ===== 任务详情弹窗 ===== -->
  <div id="task-detail" style="display:none">
    <div class="card mt-16">
      <div class="flex-between">
        <h3>任务详情: <span id="task-detail-id"></span></h3>
        <button class="btn btn-outline btn-sm" onclick="closeTaskDetail()">关闭</button>
      </div>
      <div id="task-detail-meta" style="font-size:13px;color:var(--text-secondary);margin-bottom:12px"></div>
      <div class="log-viewer" id="task-log-viewer"></div>
      <div class="flex-between mt-12">
        <button class="btn btn-danger btn-sm" id="btn-stop-task" onclick="stopTask(currentDetailTask)">终止任务</button>
        <button class="btn btn-outline btn-sm" onclick="refreshTaskDetail(currentDetailTask)">刷新</button>
      </div>
    </div>
  </div>

  <!-- ===== 结果 Tab ===== -->
  <div id="tab-results" class="tab">
    <div class="flex-between mt-16">
      <h3 style="margin-bottom:16px">生成题目</h3>
      <div style="display:flex;gap:8px">
        <button class="btn btn-outline btn-sm" onclick="downloadAllQuestions()">打包下载全部(ZIP)</button>
        <button class="btn btn-outline btn-sm" onclick="loadResults()">刷新</button>
      </div>
    </div>
    <div id="results-container">
      <div class="empty-state"><div class="icon">-</div>暂无生成的题目</div>
    </div>
    <div id="questions-detail" style="display:none" class="mt-16"></div>
  </div>

  <!-- ===== 质量报告 Tab ===== -->
  <div id="tab-reports" class="tab">
    <div class="flex-between mt-16">
      <h3 style="margin-bottom:16px">质量报告</h3>
      <button class="btn btn-outline btn-sm" onclick="loadReports()">刷新</button>
    </div>
    <div id="reports-list">
      <div class="empty-state"><div class="icon">-</div>暂无报告</div>
    </div>
    <div id="report-viewer" class="report-content mt-16"></div>
  </div>

  <!-- ===== 图谱测评 Tab（步骤 ⑩）===== -->
  <div id="tab-kgeval" class="tab">
    <div class="card">
      <h3><span class="icon"></span>步骤 ⑩：图谱测评与优化</h3>
      <div style="font-size:13px;color:var(--text-secondary);margin-bottom:12px">
        用当前出好的题目反向测评知识图谱，按四维框架（KG / Retrieval / Reasoning / Answer）打分，
        指出图谱<strong>哪一维 / 哪个子项最需要优化</strong>。题目由上面的「出题」流程产生，本页只读、不出题。
      </div>
      <div class="form-group">
        <label>图谱 DB（kgqa.db，步骤 ⑧ 产物，留空用默认）</label>
        <input type="text" id="kge-db" placeholder="{{ kg_db_default }}">
      </div>
      <div class="form-group">
        <label>Retriever（retriever.pkl，留空用默认）</label>
        <input type="text" id="kge-retriever" placeholder="{{ kg_retriever_default }}">
      </div>
      <div class="form-group">
        <label>题目目录（留空用当前出题/审查目录）</label>
        <input type="text" id="kge-questions" placeholder="kg_eval/qag/output">
      </div>
      <div class="form-row">
        <div class="form-group" style="flex:0 0 160px">
          <label>只评前 N 题（调试）</label>
          <input type="number" id="kge-limit" placeholder="全部" min="1">
        </div>
        <div class="form-group" style="display:flex;align-items:flex-end;gap:16px">
          <label style="display:flex;align-items:center;gap:6px"><input type="checkbox" id="kge-judge" checked> 启用 LLM-Judge</label>
          <label style="display:flex;align-items:center;gap:6px"><input type="checkbox" id="kge-backflow"> 写入候选池</label>
        </div>
      </div>
      <button class="btn btn-primary" onclick="startKgEval()">开始测评</button>
      <button class="btn btn-outline" onclick="loadKgEvalReport()">刷新报告</button>
    </div>

    <div id="kge-result"></div>
  </div>

  <!-- ===== 使用说明 Tab ===== -->
  <div id="tab-help" class="tab">
    <div class="card">
      <h3><span class="icon"></span>使用流程 & 点击后哪些面板会变</h3>

      <div style="font-size:14px;line-height:1.7">
        <div style="font-weight:700;color:var(--primary-dark);margin:4px 0 8px">① 配置 → 出题 → 审核（首次生成）</div>
        <table style="width:100%;border-collapse:collapse;margin-bottom:6px">
          <thead><tr style="text-align:left;border-bottom:1px solid var(--border)">
            <th style="padding:6px">步骤</th><th style="padding:6px">做什么</th><th style="padding:6px">完成后变化</th></tr></thead>
          <tbody>
            <tr><td style="padding:6px"><strong>配置</strong></td><td style="padding:6px">填 API、模型优先级链、题目/报告目录</td><td style="padding:6px">保存配置</td></tr>
            <tr><td style="padding:6px"><strong>出题</strong></td><td style="padding:6px">选领域/难度/题数（<strong>难度、领域按住 Ctrl 可多选</strong>），开始出题</td><td style="padding:6px"><strong>「结果」栏</strong> 出现生成的题目</td></tr>
            <tr><td style="padding:6px"><strong>审核</strong></td><td style="padding:6px">对题目跑 5 步检测（可选 LLM Judge 八维）</td><td style="padding:6px"><strong>「质量报告」栏</strong> 出现各报告（含重点说明）；<strong>「专家审查」面板</strong> 出现带风险等级的题目</td></tr>
          </tbody>
        </table>
        <div style="font-size:13px;color:var(--text-secondary);margin-bottom:14px">
          结果 = 生成的题目；质量报告 = 检测产出（重点看：本地质量检测 / LLM 八维 / 推理链 / 结构自查 / 专家审查汇总）。
        </div>

        <div style="padding:10px 12px;background:#fff1f2;border:1px solid #fecdd3;border-radius:8px;margin:6px 0 14px;font-size:13px;color:#9f1239">
          ⭐ <strong>审核策略：建议专家只对中低风险（MEDIUM / LOW）题目审核修正；高风险（CRITICAL / HIGH）题目直接「拒绝(归档)」，不必逐字改写。</strong>
        </div>

        <div style="font-weight:700;color:var(--primary-dark);margin:4px 0 8px">② 专家审查 → 点「LLM 自纠」（机器自动修风险题）</div>
        <div style="padding:8px 10px;background:#faf5ff;border-radius:8px;margin-bottom:6px">
          系统自动挑出有风险（数值幻觉 / 证据接地不足 / 推理链断 / 八维未过）的题，调 LLM 在<strong>原证据范围内</strong>修改，
          改完<strong>自动重跑审核</strong>。点击后会顺序发生 3 处变化：
          <ol style="margin:6px 0 0 18px">
            <li><strong>「结果」栏题目被改写</strong>（原地覆盖，annotation_meta.repair_history 留痕）</li>
            <li><strong>「质量报告」栏全部重新生成并覆盖</strong>（同名最新版）</li>
            <li><strong>「专家审查」面板自动刷新</strong>（无需手动点刷新；风险等级可能下降）</li>
          </ol>
        </div>
        <div style="font-size:13px;color:var(--text-secondary);margin-bottom:14px">
          ⚠️ 自纠不能凭空造证据：若硬伤是「证据接地不足 / 推理链接地为 0」，改了题目文字后风险等级仍可能不降——这类题应直接<strong>拒绝</strong>或换证据重出。
        </div>

        <div style="font-weight:700;color:var(--primary-dark);margin:4px 0 8px">③ 专家审查 → 改「改题目 / 改答案」两个框 →「提交专家意见并重审」（人工修正）</div>
        <div style="padding:8px 10px;background:#faf5ff;border-radius:8px;margin-bottom:6px">
          每题只有<strong>两个输入框</strong>：<code>改题目</code>、<code>改答案</code>（预填当前内容）。专家填入<strong>修改后的完整题目与答案</strong>，
          只处理<strong>你改动过的题</strong>。提交后系统：<strong>原样采用你的题目</strong> → <strong>把答案自动拆成得分点(key_points)</strong> → <strong>重新质量评测</strong>。高风险题用每张卡片的 <code>🗑 拒绝(归档)</code> 按钮移到 output/rejected。同样 3 处变化：
          <ol style="margin:6px 0 0 18px">
            <li><strong>「结果」栏题目改变</strong>（采用你的题目/答案、key_points 为拆出的得分点；拒绝则移除）</li>
            <li><strong>「质量报告」栏重新生成并覆盖</strong></li>
            <li><strong>「专家审查」面板自动刷新</strong></li>
          </ol>
        </div>
        <div style="font-size:13px;color:var(--text-secondary)">
          专家直采<strong>不调 LLM</strong>：题目原样写回、答案按句末标点确定性拆成得分点，结果可预测、无幻觉；<strong>原地覆盖、无自动备份、不重新出题</strong>。
        </div>
      </div>
    </div>

    <div class="card">
      <h3><span class="icon"></span>命令行等效</h3>
      <div class="log-viewer" style="color:#c4b5fd;font-size:12px">
# 出题
python QAG-merged/generate_questions.py --source external --hops 1,2,3,4 --paper-range 2-3 --domains FABS,HCFG,MECH,POPT --num-per-domain 2

# 审核
python QAG-merged/review_questions.py --input-dir <题目目录> --report-dir <报告目录>

# 一键全流程（出题 + 审核）
python QAG-merged/run_qag_pipeline.py --source external --hops 1,2,3,4 --paper-range 2-3 --domains FABS,HCFG,MECH,POPT --num-per-domain 2

# 加 LLM 审查
python QAG-merged/run_qag_pipeline.py ... --with-llm-judge --model claude-sonnet-4-6
      </div>
    </div>

    <div class="card">
      <h3><span class="icon"></span>难度等级速查</h3>
      <table style="width:100%;font-size:14px;border-collapse:collapse">
        <thead>
          <tr style="text-align:left;border-bottom:1px solid var(--border)">
            <th style="padding:8px">难度</th><th style="padding:8px">题型</th><th style="padding:8px">hops</th><th style="padding:8px">paper_range</th><th style="padding:8px">说明</th>
          </tr>
        </thead>
        <tbody>
          <tr><td style="padding:8px"><span class="badge badge-l1">L1</span></td><td style="padding:8px">简单事实检索</td><td style="padding:8px">1</td><td style="padding:8px">1</td><td style="padding:8px">单一证据锚点</td></tr>
          <tr><td style="padding:8px"><span class="badge badge-l2">L2</span></td><td style="padding:8px">多跳逻辑推理</td><td style="padding:8px">2</td><td style="padding:8px">2-3</td><td style="padding:8px">串联2个知识节点</td></tr>
          <tr><td style="padding:8px"><span class="badge badge-l3">L3</span></td><td style="padding:8px">主题概括类</td><td style="padding:8px">3</td><td style="padding:8px">2-3</td><td style="padding:8px">归纳技术路线/趋势</td></tr>
          <tr><td style="padding:8px"><span class="badge badge-l4">L4</span></td><td style="padding:8px">创新发散题目</td><td style="padding:8px">4</td><td style="padding:8px">2</td><td style="padding:8px">开放工程约束/方案设计</td></tr>
        </tbody>
      </table>
    </div>

    <div class="card">
      <h3><span class="icon"></span>图谱测评（步骤 ⑩）——「用出题反向测评图谱」</h3>
      <div style="font-size:14px;line-height:1.7">
        <div style="padding:8px 10px;background:#faf5ff;border-radius:8px;margin-bottom:10px">
          切到顶部「<strong>图谱测评</strong>」标签页：用当前出好的题目去问知识图谱，按<strong>四维框架</strong>给图谱打分，
          并指出<strong>图谱哪一维 / 哪个子项最需要优化</strong>，给出针对性优化建议。出题流程不受任何影响。
        </div>
        <div style="font-weight:700;color:var(--primary-dark);margin:4px 0 6px">操作步骤</div>
        <ol style="margin:0 0 10px 18px">
          <li>先正常「出题」（或已有题目）；图谱测评只<strong>读题、不出题</strong>。</li>
          <li>切「图谱测评」页：填图谱 <code>DB</code> / <code>Retriever</code>（留空用默认，输入框灰字即当前默认绝对路径），可选「只评前 N 题」「启用 LLM-Judge」「写入候选池」。</li>
          <li>点「<strong>开始测评</strong>」→ 进度在「任务」页（类型 kg_eval）→ 跑完回本页点「<strong>刷新报告</strong>」。</li>
        </ol>
        <div style="font-weight:700;color:var(--primary-dark);margin:4px 0 6px">四维框架（均归一到 0–1）</div>
        <table style="width:100%;font-size:13px;border-collapse:collapse;margin-bottom:8px">
          <thead><tr style="text-align:left;border-bottom:1px solid var(--border)">
            <th style="padding:6px">维度</th><th style="padding:6px">权重构成</th></tr></thead>
          <tbody>
            <tr><td style="padding:6px"><strong>KG Quality</strong> 图谱质量</td><td style="padding:6px">0.35·L0 + 0.25·L1 + 0.25·L2 + 0.15·跨层跨域耦合</td></tr>
            <tr><td style="padding:6px"><strong>Retrieval</strong> 检索质量</td><td style="padding:6px">0.35·证据召回 + 0.25·路径召回 + 0.20·数值接地 + 0.20·可追溯</td></tr>
            <tr><td style="padding:6px"><strong>Reasoning</strong> 推理质量</td><td style="padding:6px">0.30·路径节点接地 + 0.25·跨层使用 + 0.25·多跳连贯 + 0.20·概念骨干</td></tr>
            <tr><td style="padding:6px"><strong>Answer</strong> 答案质量</td><td style="padding:6px">0.45·事实正确 + 0.25·语义覆盖 + 0.15·设计有效 + 0.15·创新（后两项仅 L3/L4）</td></tr>
          </tbody>
        </table>
        <div style="font-size:13px;color:var(--text-secondary)">
          报告含：四维分、🔴 最弱维与最弱子项、本图谱未实现的层（已从评分剔除、不计分，仅信息提示）、按维度排序、逐条优化建议（指明改哪个模块/边/字段）。
          产物落 <code>kg_eval/output/{report.md, report.json, answers.json}</code>。
          <br>「<strong>启用 LLM-Judge</strong>」：事实正确 / 语义覆盖 / 设计 / 创新这几项用大模型评；关掉则只跑确定性指标（更快）。
          <br>「<strong>写入候选池</strong>」：把优化建议写入 <code>retrieval_integration</code> 的知识回流候选池，接 schema 演化闭环（步骤 ⑦→⑧ 重建图谱）；不想动这套留空即可。
        </div>
      </div>
    </div>
  </div>

</div>

<button class="theme-toggle" onclick="toggleTheme()" title="切换主题">&#9728;</button>

<script>
// ===== 子路径代理适配：应用可能被挂在 .../vscode/proxy/8001/ 这类前缀下 =====
// BASE = 当前页面所在目录(以 / 结尾)。把应用内的绝对路径 "/api/..." 改写为 BASE+"api/..."，
// 这样无论直连(BASE="/")还是经平台端口代理子路径，请求都能命中。
const BASE = location.pathname.replace(/[^/]*$/, "");
function _u(p) { return (typeof p === "string" && p.charAt(0) === "/") ? BASE + p.slice(1) : p; }

// ===== Auth：登录遮罩 + 401 拦截 =====
// 全局拦截 401：任一受保护请求未登录 → 弹回登录遮罩。同时把绝对路径按 BASE 改写。
const _origFetch = window.fetch.bind(window);
window.fetch = async (input, init) => {
  const orig = (typeof input === "string") ? input : (input && input.url) || "";
  const r = await _origFetch(_u(input), init);
  try {
    if (r.status === 401 && !orig.includes("/api/auth/")) showAuth();
  } catch (e) {}
  return r;
};
function showAuth() { document.getElementById("auth-overlay").style.display = "flex"; }
function hideAuth() { document.getElementById("auth-overlay").style.display = "none"; }
function _authMsg(m) { document.getElementById("auth-msg").textContent = m || ""; }

async function checkAuth() {
  try {
    const r = await _origFetch(_u("/api/auth/me"));
    const j = await r.json();
    if (j.authenticated) { onLoggedIn(j.username); return true; }
  } catch (e) {}
  showAuth();
  return false;
}
function onLoggedIn(username) {
  hideAuth();
  document.getElementById("auth-username").textContent = "👤 " + username;
  if (!window._appInited) { window._appInited = true; loadConfig(); }
}
async function doLogin() {
  const username = document.getElementById("auth-user").value.trim();
  const password = document.getElementById("auth-pass").value;
  _authMsg("");
  const r = await _origFetch(_u("/api/auth/login"), {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, password }),
  });
  const j = await r.json();
  if (r.ok && j.ok) { document.getElementById("auth-pass").value = ""; onLoggedIn(j.username); }
  else _authMsg(j.error || "登录失败");
}
async function doRegister() {
  const username = document.getElementById("auth-user").value.trim();
  const password = document.getElementById("auth-pass").value;
  _authMsg("");
  const r = await _origFetch(_u("/api/auth/register"), {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, password }),
  });
  const j = await r.json();
  if (r.ok && j.ok) { document.getElementById("auth-pass").value = ""; onLoggedIn(j.username); }
  else _authMsg(j.error || "注册失败");
}
async function doLogout() {
  await _origFetch(_u("/api/auth/logout"), { method: "POST" });
  window._appInited = false;
  document.getElementById("auth-username").textContent = "";
  showAuth();
}

// ===== Navigation =====
document.querySelectorAll(".nav button").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".nav button").forEach(b => b.classList.remove("active"));
    document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
    btn.classList.add("active");
    const tabId = "tab-" + btn.dataset.tab;
    document.getElementById(tabId).classList.add("active");
    // Load data on tab switch
    if (btn.dataset.tab === "generate") { refreshGenerateTab(); }
    if (btn.dataset.tab === "tasks") { refreshTasks(); startTabPolling(); }
    else { stopTabPolling(); }
    if (btn.dataset.tab === "results") { loadResults(); }
    if (btn.dataset.tab === "reports") { loadReports(); }
    if (btn.dataset.tab === "kgeval") { loadKgEvalReport(); }
    if (btn.dataset.tab === "expert") { loadReviewData(); }
  });
});

// ===== Toast =====
function toast(msg, type) {
  const el = document.createElement("div");
  el.className = "toast " + (type || "success");
  el.textContent = msg;
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 3000);
}

// ===== 步骤 ⑩ 图谱测评 =====
async function startKgEval() {
  const body = {
    db: document.getElementById("kge-db").value,
    retriever: document.getElementById("kge-retriever").value,
    questions_dir: document.getElementById("kge-questions").value,
    no_judge: !document.getElementById("kge-judge").checked,
    feed_backflow: document.getElementById("kge-backflow").checked,
    // 带上当前 UI 的模型链（即使未保存配置也生效）
    judge_models: _chainNames(JUDGE_CHAIN),
    reason_models: _chainNames(REASON_CHAIN),
  };
  const lim = document.getElementById("kge-limit").value;
  if (lim) body.limit = parseInt(lim, 10);
  try {
    const r = await fetch("/api/kg_eval", {
      method: "POST", headers: {"Content-Type": "application/json"},
      body: JSON.stringify(body),
    });
    const d = await r.json();
    toast("图谱测评已开始（任务 " + d.task_id + "），完成后回本页点刷新报告");
    document.querySelector(".nav button[data-tab='tasks']").click();
  } catch (e) {
    toast("启动失败: " + e, "error");
  }
}

async function loadKgEvalReport() {
  const box = document.getElementById("kge-result");
  try {
    const r = await fetch("/api/kg_eval/report");
    const d = await r.json();
    if (!d.exists) {
      box.innerHTML = '<div class="empty-state"><div class="icon">-</div>暂无测评报告，点「开始测评」生成</div>';
      return;
    }
    renderKgEvalReport(d.report);
  } catch (e) {
    box.innerHTML = '<div class="empty-state">读取报告失败: ' + e + '</div>';
  }
}

function _fmtScore(v) { return (v === null || v === undefined) ? "—" : Number(v).toFixed(3); }

function downloadKgEval(fname) {
  _triggerDownload("/api/kg_eval/report/download?file=" + encodeURIComponent(fname));
}

const _DIM_ZH = {
  kg_quality: "KG Quality 图谱质量", retrieval_quality: "Retrieval 检索质量",
  reasoning_quality: "Reasoning 推理质量", answer_quality: "Answer 答案质量",
};

function renderKgEvalReport(rep) {
  const box = document.getElementById("kge-result");
  const dim = rep.dimension_scores || {};
  const diag = rep.diagnosis || {};
  const bd = rep.breakdown || {};
  let h = "";

  // 下载图谱测评产物
  h += '<div class="card" style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">';
  h += '<strong style="margin-right:4px">下载报告：</strong>';
  h += '<button class="btn btn-outline btn-sm" onclick="downloadKgEval(\'report.md\')">测评报告(MD)</button>';
  h += '<button class="btn btn-outline btn-sm" onclick="downloadKgEval(\'report.json\')">测评数据(JSON)</button>';
  h += '<button class="btn btn-outline btn-sm" onclick="downloadKgEval(\'answers.json\')">逐题答案(JSON)</button>';
  h += '</div>';

  h += '<div class="card"><h3><span class="icon"></span>综合 KGQA-Score：' + _fmtScore(rep.overall_kgqa_score) + '</h3>';
  h += '<table style="width:100%;font-size:14px;border-collapse:collapse"><thead><tr style="text-align:left;border-bottom:1px solid var(--border)"><th style="padding:8px">维度</th><th style="padding:8px">得分</th></tr></thead><tbody>';
  for (const k of ["kg_quality","retrieval_quality","reasoning_quality","answer_quality"]) {
    const weak = (k === diag.weakest_dimension);
    h += '<tr><td style="padding:8px">' + (_DIM_ZH[k]||k) + (weak ? ' 🔴' : '') + '</td><td style="padding:8px;font-weight:'+(weak?'700;color:var(--danger)':'500')+'">' + _fmtScore(dim[k]) + '</td></tr>';
  }
  h += '</tbody></table></div>';

  h += '<div class="card"><h3><span class="icon"></span>🔴 最需要优化</h3>';
  h += '<p>最弱维度：<strong style="color:var(--danger)">' + (_DIM_ZH[diag.weakest_dimension]||diag.weakest_dimension||"—") + '</strong>　最弱子项：<code>' + (diag.weakest_submetric||"—") + '</code></p>';
  if (diag.unimplemented_components && diag.unimplemented_components.length) {
    h += '<p>本图谱未实现的层（已从评分剔除，不计分）：<strong>' + diag.unimplemented_components.join("、") + '</strong>　—— KG Quality 仅按已构建的层计分。</p>';
  }
  if (diag.missing_layers && diag.missing_layers.length) {
    h += '<p style="font-size:12px;color:var(--text-secondary)">（细分未建子项，供参考：' + diag.missing_layers.join("、") + '）</p>';
  }
  h += '</div>';

  const sugg = diag.optimization_suggestions || [];
  if (sugg.length) {
    h += '<div class="card"><h3><span class="icon"></span>优化建议</h3>';
    sugg.forEach((s, i) => {
      h += '<div style="padding:10px 12px;background:#faf5ff;border-radius:8px;margin-bottom:8px">';
      h += '<div style="font-weight:700">' + (i+1) + '. [' + (s.target||"") + ']　<code>' + (s.submetric||"") + '</code></div>';
      h += '<div style="font-size:13px;margin-top:4px">动作：' + (s.action||"") + '</div>';
      h += '<div style="font-size:13px;color:var(--text-secondary)">原因：' + (s.why||"") + '</div>';
      if (s.fixes_submetric && s.fixes_submetric.length)
        h += '<div style="font-size:12px;color:var(--text-secondary)">连带改善：' + s.fixes_submetric.join("、") + '</div>';
      h += '</div>';
    });
    h += '</div>';
  }

  // 子项明细
  const degen = new Set((diag.degenerate_submetrics) || []);
  h += '<div class="card"><h3><span class="icon"></span>子项明细</h3>';
  if (degen.size) {
    h += '<div style="font-size:12px;color:var(--text-secondary);margin-bottom:6px">标 ⚠️ 的子项跨题方差≈0（结构性恒定、无区分度），已从该维度评分剔除并按剩余子项重归一。</div>';
  }
  for (const d of ["kg_quality","retrieval_quality","reasoning_quality","answer_quality"]) {
    h += '<div style="font-weight:600;margin:6px 0 2px">' + (_DIM_ZH[d]||d) + '</div><div style="font-size:13px;color:var(--text-secondary)">';
    const subs = bd[d] || {};
    h += Object.keys(subs).map(k => k + ": " + _fmtScore(subs[k]) + (degen.has(d+"."+k) ? " ⚠️" : "")).join("　|　") || "—";
    h += '</div>';
  }
  h += '</div>';
  box.innerHTML = h;
}


// ===== Config =====
// Known models (catalog). User reorders + enables/disables per role to form a
// fallback chain; backend degrades left→right (top→bottom) on call failure.
const MODEL_CATALOG = ["claude-sonnet-4-6","gemini-3.1-pro-preview","gpt-5.4","gpt-5.5"];
// State: ordered list of {name, enabled} for each role. Order = priority.
let GEN_CHAIN   = MODEL_CATALOG.map(m => ({name:m, enabled:true}));
let JUDGE_CHAIN = MODEL_CATALOG.map(m => ({name:m, enabled:true}));
let REASON_CHAIN = MODEL_CATALOG.map(m => ({name:m, enabled:true}));

// Build a role chain state from a saved ordered array of enabled names,
// appending any catalog models the user hadn't included (disabled, at the end).
function _buildChainState(savedNames) {
  const names = Array.isArray(savedNames) ? savedNames.filter(Boolean) : [];
  const seen = new Set(names);
  const state = names.map(n => ({name:n, enabled:true}));
  MODEL_CATALOG.forEach(m => { if (!seen.has(m)) state.push({name:m, enabled:false}); });
  return state.length ? state : MODEL_CATALOG.map(m => ({name:m, enabled:true}));
}

// Enabled names in priority order → what actually gets sent to the backend.
function _chainNames(state) { return state.filter(r => r.enabled).map(r => r.name); }

function _renderModelList(containerId, state, role) {
  const c = document.getElementById(containerId);
  if (!c) return;
  let rank = 0;
  c.innerHTML = state.map((row, i) => {
    const r = row.enabled ? `${++rank}` : "–";
    return `<div class="model-row ${row.enabled?'':'disabled'}">
      <span class="rank">${r}</span>
      <input type="checkbox" ${row.enabled?'checked':''} onchange="toggleModel('${role}',${i})" title="启用/禁用">
      <span class="mname">${row.name}</span>
      <span class="move">
        <button onclick="moveModel('${role}',${i},-1)" ${i===0?'disabled':''} title="上移">▲</button>
        <button onclick="moveModel('${role}',${i},1)" ${i===state.length-1?'disabled':''} title="下移">▼</button>
      </span>
    </div>`;
  }).join("");
}

function _renderAllModelLists() {
  _renderModelList("cfg-gen-model-list", GEN_CHAIN, "gen");
  _renderModelList("cfg-judge-model-list", JUDGE_CHAIN, "judge");
  _renderModelList("cfg-reason-model-list", REASON_CHAIN, "reason");
}

function _chainFor(role) {
  if (role === "gen") return GEN_CHAIN;
  if (role === "reason") return REASON_CHAIN;
  return JUDGE_CHAIN;
}

function moveModel(role, i, delta) {
  const state = _chainFor(role);
  const j = i + delta;
  if (j < 0 || j >= state.length) return;
  [state[i], state[j]] = [state[j], state[i]];
  _renderAllModelLists();
}

function toggleModel(role, i) {
  const state = _chainFor(role);
  state[i].enabled = !state[i].enabled;
  _renderAllModelLists();
}

async function loadConfig() {
  const resp = await fetch("/api/config");
  const cfg = await resp.json();
  document.getElementById("cfg-api-url").value = cfg.api_base_url || "";
  document.getElementById("cfg-model").value = cfg.model || "";
  document.getElementById("cfg-api-key").value = cfg.api_key || "";
  document.getElementById("cfg-timeout").value = cfg.timeout || 120;
  const port = cfg.server_port || 5000;
  document.getElementById("cfg-backend-port").value = port;
  document.getElementById("cfg-frontend-port").value = port;
  document.getElementById("cfg-app-api").value = "http://localhost:" + port;
  // Build model priority chains: prefer saved arrays, else single value, else default order.
  GEN_CHAIN   = _buildChainState(cfg.gen_models   || (cfg.gen_model   ? [cfg.gen_model]   : (cfg.model ? [cfg.model] : null)));
  JUDGE_CHAIN = _buildChainState(cfg.judge_models || (cfg.judge_model ? [cfg.judge_model] : (cfg.model ? [cfg.model] : null)));
  // 推理链默认跟随 Judge 链（同一套大模型），用户可单独调整
  REASON_CHAIN = _buildChainState(cfg.reason_models || (cfg.reason_model ? [cfg.reason_model] : (cfg.judge_models || (cfg.model ? [cfg.model] : null))));
  _renderAllModelLists();
  if (!cfg.api_key) { document.getElementById("cfg-api-key").type = "password"; }
}

async function saveConfig() {
  const genModels   = _chainNames(GEN_CHAIN);
  const judgeModels = _chainNames(JUDGE_CHAIN);
  const reasonModels = _chainNames(REASON_CHAIN);
  if (!genModels.length)   { toast("出题模型至少启用一个", "error"); return; }
  if (!judgeModels.length) { toast("Judge 模型至少启用一个", "error"); return; }
  if (!reasonModels.length) { toast("推理模型至少启用一个", "error"); return; }
  // chain heads kept as single-value fields for backward-compatible callers
  document.getElementById("cfg-model").value = genModels[0];
  const data = {
    api_base_url: document.getElementById("cfg-api-url").value,
    model:        genModels[0],
    gen_model:    genModels[0],
    judge_model:  judgeModels[0],
    reason_model: reasonModels[0],
    gen_models:   genModels,
    judge_models: judgeModels,
    reason_models: reasonModels,
    api_key:     document.getElementById("cfg-api-key").value,
    timeout:     parseInt(document.getElementById("cfg-timeout").value) || 120,
    server_port: parseInt(document.getElementById("cfg-backend-port").value) || 5000,
  };
  await fetch("/api/config", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  toast("配置已保存", "success");
}

// ===== 上传：PDF / 题目报告 bundle =====
async function uploadPdf() {
  const inp = document.getElementById("pdf-upload-input");
  const msg = document.getElementById("pdf-upload-msg");
  if (!inp.files.length) { msg.textContent = "请先选择 PDF"; return; }
  const fd = new FormData();
  for (const f of inp.files) fd.append("files", f);
  msg.textContent = "上传中…";
  try {
    const r = await fetch("/api/upload/pdf", { method: "POST", body: fd });
    const j = await r.json();
    if (r.ok) {
      msg.textContent = `已上传 ${j.count} 个${j.skipped.length ? "，跳过 " + j.skipped.length + " 个非PDF" : ""}`;
      inp.value = "";
      refreshGenerateTab();
    } else { msg.textContent = j.error || "上传失败"; }
  } catch (e) { msg.textContent = "上传出错: " + e; }
}

async function uploadBundle() {
  const inp = document.getElementById("bundle-upload-input");
  const msg = document.getElementById("bundle-upload-msg");
  if (!inp.files.length) { msg.textContent = "请先选择 .zip 或 .json"; return; }
  const fd = new FormData();
  for (const f of inp.files) fd.append("files", f);
  msg.textContent = "上传中…";
  try {
    const r = await fetch("/api/upload/bundle", { method: "POST", body: fd });
    const j = await r.json();
    if (r.ok) {
      msg.textContent = `已上传：${(j.saved || []).join("，") || "0"}${j.skipped.length ? "；跳过 " + j.skipped.length : ""}`;
      inp.value = "";
      // 上传后立即刷新各列表，让题目/报告/专家审查直接出现
      if (typeof loadStats === "function") loadStats();
      if (typeof loadResults === "function") loadResults();
      if (typeof loadReports === "function") loadReports();
      if (typeof loadReviewData === "function") loadReviewData("");
    } else { msg.textContent = j.error || "上传失败"; }
  } catch (e) { msg.textContent = "上传出错: " + e; }
}

async function refreshGenerateTab() {
  // Load PDF list
  const resp = await fetch("/api/extern");
  const pdfs = await resp.json();
  const container = document.getElementById("pdf-list");
  document.getElementById("pdf-count").textContent = `(共 ${pdfs.length} 个 PDF)`;
  if (pdfs.length === 0) {
    container.innerHTML = '<div style="color:var(--text-secondary);padding:12px">extern_data 目录下暂无 PDF 文件</div>';
  } else {
    container.innerHTML = pdfs.map(p => 
      `<div class="pdf-item"><span class="pdf-name" title="${p.name}">${p.name}</span><span class="pdf-size">${(p.size/1024).toFixed(0)} KB</span></div>`
    ).join("");
  }
  // Load config values
  const cfgResp = await fetch("/api/config");
  const cfg = await cfgResp.json();
}

// ===== Helpers =====
function getMultiSelect(id) {
  const sel = document.getElementById(id);
  const vals = [];
  for (const opt of sel.selectedOptions) vals.push(opt.value);
  return vals.join(",") || sel.options[0]?.value || "";
}

function getDefaultConfig() {
  const genModels   = _chainNames(GEN_CHAIN);
  const judgeModels = _chainNames(JUDGE_CHAIN);
  return {
    api_key:      document.getElementById("cfg-api-key")?.value || "",
    api_base_url: document.getElementById("cfg-api-url")?.value || "",
    model:        genModels[0] || document.getElementById("cfg-model")?.value || "",
    judge_model:  judgeModels[0] || document.getElementById("cfg-model")?.value || "",
    gen_models:   genModels,
    judge_models: judgeModels,
  };
}

// ===== Tasks =====
let currentDetailTask = null;
let taskPollInterval = null;
let tabPollInterval = null;

// ---- Auto-refresh: task list when tasks tab is active ----
function startTabPolling() {
  stopTabPolling();
  const badge = document.getElementById("task-auto-refresh-badge");
  if (badge) badge.style.display = "inline";
  tabPollInterval = setInterval(refreshTasks, 2000);
}
function stopTabPolling() {
  if (tabPollInterval) { clearInterval(tabPollInterval); tabPollInterval = null; }
  const badge = document.getElementById("task-auto-refresh-badge");
  if (badge) badge.style.display = "none";
}
function closeTaskDetail() {
  document.getElementById("task-detail").style.display = "none";
  currentDetailTask = null;
  if (taskPollInterval) { clearInterval(taskPollInterval); taskPollInterval = null; }
}

async function refreshTasks() {
  const resp = await fetch("/api/tasks");
  const tasks = await resp.json();
  const container = document.getElementById("task-list");
  if (tasks.length === 0) {
    container.innerHTML = '<div class="empty-state"><div class="icon">-</div>暂无任务</div>';
    return;
  }
  const typeNames = { generate: "出题", review: "审核", pipeline: "全流程", expert_apply: "专家反馈", self_repair: "LLM自纠" };
  const statusNames = { pending: "等待中", running: "运行中", done: "已完成", failed: "失败", stopped: "已终止" };
  container.innerHTML = tasks.map(t => {
    const elapsed = t.elapsed ? Math.floor(t.elapsed) : 0;
    const min = Math.floor(elapsed / 60);
    const sec = elapsed % 60;
    const timeStr = t.status === "running" ? `${min}m${sec}s ⏳` : (t.status === "pending" ? "--" : `${min}m${sec}s`);
    return `<div class="task-item" onclick="showTaskDetail('${t.id}')" style="cursor:pointer">
      <div class="task-info">
        <span class="status-dot ${t.status}"></span>
        <span class="task-type ${t.type}">${typeNames[t.type] || t.type}</span>
        <span style="font-size:13px">${t.id}</span>
        <span style="font-size:12px;color:var(--text-secondary)">${statusNames[t.status] || t.status} | ${timeStr}</span>
      </div>
      <span style="font-size:12px;color:var(--text-secondary)">${t.created_at}</span>
    </div>`;
  }).join("");
  // Update timestamp
  const metaEl = document.getElementById("task-update-time");
  if (metaEl) metaEl.textContent = new Date().toLocaleTimeString();
}

async function showTaskDetail(tid) {
  currentDetailTask = tid;
  document.getElementById("task-detail").style.display = "block";
  document.getElementById("task-detail-id").textContent = tid;
  await refreshTaskDetail(tid);
}

async function refreshTaskDetail(tid) {
  if (!tid) return;
  const resp = await fetch("/api/tasks/" + tid);
  const t = await resp.json();
  if (t.error) { toast("任务不存在", "error"); return; }
  const meta = document.getElementById("task-detail-meta");
  meta.textContent = `类型: ${t.type} | 状态: ${t.status} | 退出码: ${t.exit_code ?? "--"} | 耗时: ${Math.floor(t.elapsed)}s`;
  
  const viewer = document.getElementById("task-log-viewer");
  viewer.innerHTML = (t.logs || []).map(line => {
    let cls = "log-info";
    if (line.includes("错误") || line.includes("Error") || line.includes("FAIL")) cls = "log-error";
    if (line.includes("完成") || line.includes("成功") || line.includes("DONE")) cls = "log-success";
    return `<span class="${cls}">${escapeHtml(line)}</span>`;
  }).join("\n");

  const stopBtn = document.getElementById("btn-stop-task");
  stopBtn.style.display = (t.status === "running") ? "inline-flex" : "none";
  
  if (t.status === "running") {
    if (!taskPollInterval) {
      taskPollInterval = setInterval(() => {
        if (currentDetailTask) {
          refreshTaskDetail(currentDetailTask);
          refreshTasks();  // keep list in sync too
        }
      }, 2000);
    }
  } else {
    if (taskPollInterval) { clearInterval(taskPollInterval); taskPollInterval = null; }
    refreshTasks();
  }
}

async function stopTask(tid) {
  if (!tid) return;
  await fetch("/api/tasks/" + tid + "/stop", { method: "POST" });
  toast("已发送终止信号", "success");
  setTimeout(() => refreshTaskDetail(tid), 1000);
}

function escapeHtml(s) {
  return s.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
}

// ===== Generate =====
function quickPreset(level) {
  const presets = {
    'L2': {hops: '2', paper: '2-3', domains: 'FABS,HCFG,MECH,POPT', num: 7},
    'L3': {hops: '3', paper: '2-3', domains: 'FABS,HCFG,MECH,POPT', num: 5},
    'L4': {hops: '4', paper: '2',   domains: 'FABS,HCFG,MECH,POPT', num: 5},
  };
  const p = presets[level];
  if (!p) return;
  // Set hops multi-select
  const hopSel = document.getElementById("gen-hops");
  for (let o of hopSel.options) o.selected = (o.value === p.hops);
  document.getElementById("gen-paper-range").value = p.paper;
  document.getElementById("gen-num").value = p.num;
  // Set domains
  const domainSel = document.getElementById("gen-domains");
  const domainVals = p.domains.split(',');
  for (let o of domainSel.options) o.selected = domainVals.includes(o.value);
  toast(`已切换: ${level} 预设`, "success");
}
async function startGenerate(dryRun) {
  const cfg = getDefaultConfig();
  const hops = getMultiSelect("gen-hops") || "1,2,3,4";
  const domains = getMultiSelect("gen-domains") || "FABS,HCFG,MECH,POPT";
  const data = {
    source: document.getElementById("gen-source").value,
    hops: hops,
    domains: domains,
    num_per_domain: parseInt(document.getElementById("gen-num").value) || 2,
    paper_range: document.getElementById("gen-paper-range").value || "1-3",
    dry_run: !!dryRun,
    ...cfg,
  };
  try {
    const resp = await fetch("/api/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    const result = await resp.json();
    toast("出题任务已启动: " + result.task_id, "success");
    // Switch to tasks tab
    document.querySelector(".nav button[data-tab='tasks']").click();
    showTaskDetail(result.task_id);
  } catch (e) {
    toast("启动失败: " + e.message, "error");
  }
}

// ===== Review =====
async function startReview() {
  const cfg = getDefaultConfig();
  // report_dir: if user set report_dir == output_dir (UI only filled one dir),
  // auto-append '/reports' so reports land in a sub-folder, not the question dir.
  let reportDir = cfg.report_dir || "";
  const outDir = (cfg.output_dir || "").replace(/[\\/]+$/, "");
  const rdNorm = reportDir.replace(/[\\/]+$/, "");
  if (!reportDir || rdNorm === outDir) {
    reportDir = outDir ? outDir + "/reports" : "";
  }
  // Review 始终使用配置页的 Judge 模型降级链（整条逗号串）。
  const judgeChain = (cfg.judge_models && cfg.judge_models.length)
    ? cfg.judge_models.join(",")
    : (cfg.judge_model || "claude-sonnet-4-6");
  const data = {
    input_dir: document.getElementById("rev-input-dir").value || cfg.output_dir,
    report_dir: reportDir,
    with_llm_judge: document.getElementById("rev-llm-judge").checked,
    llm_model: judgeChain,
    limit: 0,
    only_new: document.getElementById("rev-only-new").checked,
    id_filter: document.getElementById("rev-id-filter").value || "",
    report_prefix: "",
  };
  try {
    const resp = await fetch("/api/review", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    const result = await resp.json();
    toast("审核任务已启动: " + result.task_id, "success");
    document.querySelector(".nav button[data-tab='tasks']").click();
    showTaskDetail(result.task_id);
  } catch (e) {
    toast("启动失败: " + e.message, "error");
  }
}

// ===== Results =====
async function loadResults() {
  const resp = await fetch("/api/output");
  const data = await resp.json();
  const container = document.getElementById("results-container");
  if (data.questions.length === 0) {
    container.innerHTML = '<div class="empty-state"><div class="icon">-</div>暂无生成的题目</div>';
    document.getElementById("questions-detail").style.display = "none";
    return;
  }
  container.innerHTML = data.questions.map(q => 
    `<div class="report-link" onclick="loadQuestions('${q.dir}')">
      <span>${q.dir}</span>
      <span class="meta">${q.count} 道题</span>
    </div>`
  ).join("");
}

// 触发浏览器下载（带上 BASE 前缀，兼容子路径反代）
function _triggerDownload(path) {
  const a = document.createElement("a");
  a.href = _u(path);
  a.style.display = "none";
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}

function downloadQuestions(dirName) {
  _triggerDownload("/api/output/questions/" + encodeURIComponent(dirName) + "/download");
}

function downloadAllQuestions() {
  _triggerDownload("/api/output/questions_all/download");
}

async function loadQuestions(dirName) {
  const resp = await fetch("/api/output/questions/" + encodeURIComponent(dirName));
  const questions = await resp.json();
  const detail = document.getElementById("questions-detail");
  detail.style.display = "block";
  
  let levelClass = "";
  if (dirName.includes("L1")) levelClass = "badge-l1";
  else if (dirName.includes("L2")) levelClass = "badge-l2";
  else if (dirName.includes("L3")) levelClass = "badge-l3";
  else if (dirName.includes("L4")) levelClass = "badge-l4";

  detail.innerHTML = `
    <div class="card">
      <div class="flex-between">
        <h3><span class="badge ${levelClass}">${dirName}</span> 共 ${questions.length} 道题</h3>
        <button class="btn btn-outline btn-sm" onclick="downloadQuestions('${dirName.replace(/'/g, "\\'")}')">下载本类题目(JSON)</button>
      </div>
      ${questions.map((q, i) => {
        const gt = q.ground_truth || {};
        const answer = gt.answer || q.answer || q.gold_answer || "";
        const keyPoints = gt.key_points || q.key_points || [];
        const evidence = q.gold_evidence || [];
        const papers = q.recommended_papers || [];
        const intent = q.intent || "";
        const meta = q.annotation_meta || {};
        const sourceFiles = meta.source_file_names || [];
        const sourceMode = meta.source_mode || "";
        return `
        <div class="result-card collapsed" onclick="this.classList.toggle('collapsed')">
          <div class="result-header">
            <span>#${i+1} ${escapeHtml(q.question || q.text || q.id || "")}</span>
            <span style="font-size:12px;color:var(--text-secondary)">展开</span>
          </div>
          <div class="result-body">
            <div style="margin-bottom:10px"><strong>答案:</strong> ${escapeHtml(answer)}</div>
            <div style="margin-bottom:10px"><strong>Key Points:</strong><ul style="margin:4px 0 0 16px;font-size:13px">${(Array.isArray(keyPoints) ? keyPoints : []).map(kp => `<li>${escapeHtml(typeof kp === 'string' ? kp : JSON.stringify(kp))}</li>`).join("")}</ul></div>
            <div style="margin-bottom:10px"><strong>领域:</strong> ${q.domain_name || q.domain || ""} (${q.difficulty_name || ""}) | <strong>hops:</strong> ${q.hop_count || ""} | <strong>意图:</strong> ${intent} | <strong>来源:</strong> ${sourceMode || "external"}</div>
            ${sourceFiles.length ? `<div style="margin-bottom:10px;color:var(--primary-dark);background:#ede9fe;padding:8px 12px;border-radius:6px;font-size:13px"><strong>&#128218; 来源文献 (${sourceFiles.length}篇):</strong><ul style="margin:6px 0 0 16px">${sourceFiles.map(f => `<li style="margin-bottom:2px"><a style="color:var(--primary)" href="${_u('/pdf/'+encodeURIComponent(f))}" target="_blank">${escapeHtml(f)}</a></li>`).join("")}</ul></div>` : ""}
            ${papers.length ? `<div style="margin-bottom:10px"><strong>期刊:</strong> ${papers.map(p => escapeHtml(p.title || p)).join(", ")}</div>` : ""}
            <div style="margin-bottom:10px"><strong>Gold Evidence:</strong><ul style="margin:4px 0 0 16px;font-size:13px">${(Array.isArray(evidence) ? evidence : []).map(ev => {
              if (typeof ev === 'string') return `<li>${escapeHtml(ev)}</li>`;
              if (ev && typeof ev === 'object') {
                const text = ev.text || ev.evidence || ev.content || JSON.stringify(ev);
                const src = ev.source || ev.ref || "";
                return `<li>${escapeHtml(text)}${src ? ` <span style="color:var(--text-secondary)">[${escapeHtml(src)}]</span>` : ""}</li>`;
              }
              return `<li>${escapeHtml(String(ev))}</li>`;
            }).join("")}</ul></div>
          </div>
        </div>
      `; }).join("")}
    </div>`;
}

// ===== Reports =====
// 报告含义标注：key = 去前缀后的基础名。star=是否重点看。
const REPORT_INFO = {
  "review_data.json":                {label:"专家审查汇总数据", star:true,  desc:"专家面板读取的聚合结果（风险等级/八维/证据），最终决策依据"},
  "llm_judge_report.md":             {label:"LLM 八维审查报告", star:true,  desc:"模型对每题打的八维分 + 评语建议（人读版）"},
  "quality_report.md":               {label:"本地质量检测报告", star:true,  desc:"证据接地 / 数值幻觉 / Key Points / 查重 的本地检测结论"},
  "path_validation_report.md":       {label:"推理链验证报告",   star:true,  desc:"推理链节点是否能接地到证据"},
  "selfcheck_report.md":             {label:"结构自查报告",     star:true,  desc:"题目 JSON 字段是否完整、结构是否合规"},
  "llm_judge_question_scores.json":  {label:"八维分数明细(JSON)", star:false, desc:"八个单维分的原始数据，llm_judge_report 的数据源"},
  "question_quality_metrics.json":   {label:"质量指标明细(JSON)", star:false, desc:"quality_report 的结构化数据源"},
  "reasoning_path_validation.json":  {label:"推理链验证明细(JSON)",star:false, desc:"path_validation_report 的结构化数据源"},
  "selfcheck_results.json":          {label:"结构自查明细(JSON)", star:false, desc:"selfcheck_report 的结构化数据源"},
  "usable_ids.json":                 {label:"可用题目 ID 清单",  star:false, desc:"通过审核、可纳入题库的题目 id 列表"},
  "llm_repair_summary.md":           {label:"LLM 自纠摘要",      star:false, desc:"上一轮自纠改了哪些题（人读版）"},
  "llm_repair_log.json":             {label:"LLM 自纠日志(JSON)", star:false, desc:"自纠每题的修改明细"},
  "expert_feedback.json":            {label:"专家反馈输入",      star:false, desc:"专家在面板提交的决策/指令原文"},
  "expert_feedback_apply_log.json":  {label:"专家反馈应用日志",  star:false, desc:"反馈应用结果：改写/归档/校验是否通过"},
  "final_questions_for_review.md":   {label:"审查稿(人读)",      star:false, desc:"汇总成便于人读的最终题目稿"},
};

function _reportInfo(name) {
  for (const base in REPORT_INFO) {
    if (name === base || name.endsWith(base)) return REPORT_INFO[base];
  }
  return {label:"其他报告", star:false, desc:""};
}

async function loadReports() {
  const resp = await fetch("/api/output");
  const data = await resp.json();
  const container = document.getElementById("reports-list");
  const batches = data.reports_batches || [];
  const totalFiles = batches.reduce((n, b) => n + (b.files || []).length, 0);
  if (!totalFiles) {
    container.innerHTML = '<div class="empty-state"><div class="icon">-</div>暂无报告</div>';
    return;
  }

  const row = (r, batch) => `
    <div class="report-link" style="display:flex;align-items:flex-start;gap:10px">
      <div style="flex:1;min-width:0">
        <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
          <span class="name" style="cursor:pointer;font-weight:600" onclick="loadReport('${r.name}','${batch}')">${r.info.label}</span>
          ${r.info.star ? '<span class="badge" style="background:#fef3c7;color:#92400e">重点</span>' : ''}
          <span style="font-size:11px;color:var(--text-secondary)">${r.name}</span>
        </div>
        ${r.info.desc ? `<div style="font-size:12px;color:var(--text-secondary);margin-top:3px">${r.info.desc}</div>` : ''}
      </div>
      <span class="meta" style="flex-shrink:0;white-space:nowrap">${(r.size/1024).toFixed(1)} KB | ${r.modified}</span>
      <button class="btn btn-outline btn-sm" onclick="event.stopPropagation();downloadReport('${r.name}','${batch}')" style="flex-shrink:0">下载</button>
    </div>`;

  const section = (title, hint, items, batch) => items.length
    ? `<div style="margin:8px 0 6px;font-size:13px;font-weight:700;color:var(--primary-dark)">${title}
         <span style="font-weight:400;font-size:11px;color:var(--text-secondary)">${hint}</span></div>
       ${items.map(r => row(r, batch)).join("")}`
    : "";

  const renderBatch = (b) => {
    const withInfo = (b.files || []).map(r => ({...r, info: _reportInfo(r.name)}));
    const stars = withInfo.filter(r => r.info.star);
    const rest  = withInfo.filter(r => !r.info.star);
    const body =
      section("⭐ 重点看", "（专家审查最该关注的结论性报告）", stars, b.batch) +
      section("📄 明细 / 输入 / 日志", "（上面报告的数据源或过程记录）", rest, b.batch);
    if (b.batch === "default" && batches.length === 1) return body;  // 单批次不加分组标题
    const title = b.batch === "default" ? "默认（根目录）" : b.batch;
    return `<details open style="margin-bottom:10px;border:1px solid var(--border);border-radius:8px;padding:8px">
      <summary style="cursor:pointer;font-weight:700;color:var(--primary-dark)">📁 ${escapeHtml(title)}
        <span style="font-weight:400;font-size:11px;color:var(--text-secondary)">（${withInfo.length} 个报告）</span></summary>
      <div style="margin-top:6px">${body}</div></details>`;
  };

  container.innerHTML = batches.map(renderBatch).join("");
}

async function loadReport(fileName, batch) {
  const q = batch ? ("?batch=" + encodeURIComponent(batch)) : "";
  const resp = await fetch("/api/output/reports/" + encodeURIComponent(fileName) + q);
  const data = await resp.json();
  if (data.error) { toast("报告不存在", "error"); return; }
  const viewer = document.getElementById("report-viewer");
  viewer.classList.add("show");
  // Simple markdown rendering
  viewer.innerHTML = data.content
    .split("\n")
    .map(line => {
      if (line.startsWith("# ")) return `<h2>${escapeHtml(line.slice(2))}</h2>`;
      if (line.startsWith("## ")) return `<h3>${escapeHtml(line.slice(3))}</h3>`;
      if (line.startsWith("- ")) return `<li>${escapeHtml(line.slice(2))}</li>`;
      if (line.trim() === "") return "<br>";
      return `<p>${escapeHtml(line)}</p>`;
    }).join("\n");
}

function downloadReport(fileName, batch) {
  const q = batch ? ("&batch=" + encodeURIComponent(batch)) : "";
  const a = document.createElement("a");
  a.href = _u("/api/output/reports/" + encodeURIComponent(fileName) + "/download?dl=1" + q);
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  toast("开始下载: " + fileName, "success");
}

// ===== Expert Review Panel =====
let _reviewData = { meta: {}, questions: [] };
let _currentBatch = "";   // 当前所选批次 id（多批次上传时用）
const RISK_COLOR = { CRITICAL:"#FF4444", HIGH:"#FFAA00", MEDIUM:"#E0B000", LOW:"#3FA34D", PASS:"#2E8B57" };
// 专家审查交互：每题只「改题目 + 改答案」两个框 + 一个「拒绝(归档)」按钮。
//   改题目/改答案被改动 → 提交后走 decision=rewrite 直采（原样采用题目，答案拆成得分点）。
//   拒绝            → decision=reject，移到 output/rejected/ 归档。

// 渲染批次下拉（多批次上传时显示）。meta.batches 来自 /api/review_data。
function _renderBatchSelector(meta) {
  const label = document.getElementById("expert-batch-label");
  const sel = document.getElementById("expert-batch-select");
  if (!label || !sel) return;
  const batches = (meta && meta.batches) || [];
  if (batches.length <= 1) { label.style.display = "none"; return; }
  label.style.display = "";
  const cur = (meta.current_batch != null ? meta.current_batch : (batches[0] && batches[0].id)) || "";
  _currentBatch = cur;
  sel.innerHTML = batches.map(b =>
    `<option value="${escapeHtml(b.id)}" ${b.id === cur ? "selected" : ""}>${escapeHtml(b.label || b.id)}</option>`
  ).join("");
}

async function loadReviewData(batch) {
  const summary = document.getElementById("expert-summary");
  summary.textContent = "加载中…";
  if (batch != null) _currentBatch = batch;
  const q = _currentBatch ? ("?batch=" + encodeURIComponent(_currentBatch)) : "";
  try {
    const resp = await fetch("/api/review_data" + q);
    const data = await resp.json();
    _renderBatchSelector(data.meta || {});
    if (data.error === "no_review_data") {
      _reviewData = { meta:(data.meta||{}), questions:[] };
      document.getElementById("expert-cards").innerHTML = '<div class="empty-state"><div class="icon">-</div>该批次尚无 review_data.json。请先在「审核」页运行一次审核，或选择其它批次。</div>';
      loadStats();   // 题库可能已有题（出题但未审核），仍展示统计
      return;
    }
    _reviewData = data;
    // 顶部汇总 + 统计看板统一由 loadStats() 按整个题库渲染
    renderExpertCards();
    loadStats();
  } catch (e) {
    summary.textContent = "加载失败: " + e;
  }
}

function _riskMatch(level, filter) {
  if (filter === "ALL") return true;
  if (filter === "FOCUS") return level === "HIGH" || level === "CRITICAL";
  return level === filter;
}

// 一个指标行：name + 值 + 状态色。status: ok/warn/bad
function _metricRow(name, valText, status) {
  const c = status === "bad" ? "#ef4444" : (status === "warn" ? "#d97706" : "#10b981");
  const dot = status === "bad" ? "●" : (status === "warn" ? "●" : "●");
  return `<div style="display:flex;justify-content:space-between;gap:8px;font-size:12px;padding:2px 0">
    <span style="color:var(--text-secondary)">${name}</span>
    <span style="font-weight:600;color:${c};white-space:nowrap">${dot} ${valText}</span></div>`;
}

// 本地检测（机械逐字核对，阈值同 compute_risk_level）——风险等级主要由它决定
function _localPanel(q) {
  const num = (v, d=2) => (v===""||v==null||isNaN(v)) ? "-" : Number(v).toFixed(d);
  const evS = q.evidence_grounding_score, nh = q.numeric_hallucination_count,
        kpS = q.kp_quality_score, pathS = q.path_grounding_score;
  const rows = [
    _metricRow("证据接地分", num(evS), evS==="" ? "warn" : (evS < 0.6 ? "bad" : (evS < 0.8 ? "warn" : "ok"))),
    _metricRow("数值幻觉数", (nh===""||nh==null)?"-":nh, (nh>=2)?"bad":(nh==1?"warn":"ok")),
    _metricRow("KP 质量分", num(kpS), kpS==="" ? "warn" : (kpS < 0.75 ? "warn" : "ok")),
    _metricRow("推理链接地分", num(pathS), pathS==="" ? "warn" : (pathS < 0.6 ? "bad" : (pathS < 0.8 ? "warn" : "ok"))),
  ].join("");
  return `<div style="flex:1;min-width:200px;border:1px solid var(--border);border-radius:8px;padding:8px">
    <div style="font-size:12px;font-weight:700;color:var(--primary-dark);margin-bottom:4px">🔬 本地质量检测 <span style="font-weight:400;color:var(--text-secondary)">（逐字核对·风险主要看这里）</span></div>
    ${rows}</div>`;
}

// LLM 八维（语义评判·辅助参考，不做事实逐字核对）
function _judgePanel(q) {
  const ov = q.judge_overall;
  const ovStatus = (ov===""||ov==null) ? "warn" : (ov < 3.5 ? "bad" : (ov < 3.8 ? "warn" : "ok"));
  const flags = (q.judge_flags||[]);
  const flagLine = flags.length
    ? `<div style="font-size:12px;margin-top:4px"><span style="color:var(--text-secondary)">风险标签:</span> ${flags.map(f=>`<span class="badge" style="background:#fee2e2;color:#991b1b;margin:1px">${escapeHtml(f)}</span>`).join("")}</div>`
    : `<div style="font-size:12px;margin-top:4px;color:#10b981">无风险标签</div>`;
  return `<div style="flex:1;min-width:200px;border:1px solid var(--border);border-radius:8px;padding:8px">
    <div style="font-size:12px;font-weight:700;color:var(--primary-dark);margin-bottom:4px">🤖 LLM 八维审查 <span style="font-weight:400;color:var(--text-secondary)">（语义评判·仅参考）</span></div>
    ${_metricRow("八维总分(overall)", (ov===""||ov==null)?"-":(ov+(q.judge_pass===false?" 未通过":" 通过")), ovStatus)}
    ${flagLine}
    ${q.judge_comments?`<div style="font-size:12px;margin-top:4px;color:var(--text-secondary)">评语: ${escapeHtml(q.judge_comments)}</div>`:""}</div>`;
}

function renderExpertCards() {
  const filter = document.getElementById("expert-risk-filter").value;
  const container = document.getElementById("expert-cards");
  const rows = (_reviewData.questions || []).filter(q => _riskMatch(q.risk_level, filter));
  if (!rows.length) { container.innerHTML = '<div class="empty-state"><div class="icon">✓</div>没有符合筛选条件的题目</div>'; return; }
  container.innerHTML = rows.map(q => {
    const color = RISK_COLOR[q.risk_level] || "#888";
    const evList = (q.evidence_items_full || []).map(ev => {
      const pdf = ev.source_file ? `<a style="color:var(--primary)" href="${_u('/pdf/'+encodeURIComponent(ev.source_file))}" target="_blank">${escapeHtml(ev.source_file)}${ev.page?(' p.'+ev.page):''}</a>` : escapeHtml(ev.source_uid||"");
      const found = ev.source_kind === "external_pdf" ? (ev.pdf_found ? "✅原文已定位" : "⚠️PDF未找到原文") : "";
      const eid = ev.evidence_id || "";
      const idChip = eid
        ? `<code class="ev-id" style="background:#ede9fe;padding:1px 5px;border-radius:4px">${escapeHtml(eid)}</code>`
        : "";
      return `<li style="margin-bottom:4px">${idChip} ${escapeHtml((ev.text||"").slice(0,160))} <span style="color:var(--text-secondary)">[${pdf}] ${found}</span></li>`;
    }).join("");
    const tags = (q.risk_tags||[]).map(t => `<span class="badge" style="background:${color};color:#fff;margin-right:4px">${escapeHtml(t)}</span>`).join("");
    const scoreLine = `证据接地 ${q.evidence_grounding_score} ｜ 数值幻觉 ${q.numeric_hallucination_count} ｜ KP质量 ${q.kp_quality_score} ｜ 推理链 ${q.path_grounding_score} ｜ Judge ${q.judge_overall||"-"}${q.judge_pass===false?" ❌":""}`;
    const judgeFlags = (q.judge_flags||[]).join(", ");
    const focus = (q.expert_focus||[]).map(f=>`<li>${escapeHtml(f)}</li>`).join("");
    const sugg = (q.judge_suggestions||[]).map(s=>`<li>${escapeHtml(s)}</li>`).join("");
    return `
    <div class="card" data-qid="${escapeHtml(q.question_id)}" style="border-left:5px solid ${color};margin-bottom:14px">
      <div class="flex-between" style="align-items:center">
        <div><span class="badge" style="background:${color};color:#fff">${q.risk_level}</span>
          <strong style="margin-left:8px">${escapeHtml(q.question_id)}</strong>
          <span style="color:var(--text-secondary);font-size:12px;margin-left:8px">${q.difficulty_level} ｜ ${q.domain} ｜ hop ${q.hop_count} ｜ ${escapeHtml(q.source_mode||"")}</span>
        </div>
      </div>
      <div style="margin:8px 0">${tags}</div>
      <div style="margin-bottom:8px"><strong>题目:</strong> ${escapeHtml(q.question)}</div>
      <div style="margin-bottom:8px"><strong>答案:</strong> ${escapeHtml(q.answer)}</div>
      <div style="margin-bottom:8px"><strong>Key Points:</strong><ul style="margin:4px 0 0 16px;font-size:13px">${(q.key_points||[]).map(k=>`<li>${escapeHtml(k)}</li>`).join("")}</ul></div>
      <div style="display:flex;gap:10px;flex-wrap:wrap;margin:10px 0">
        ${_localPanel(q)}
        ${_judgePanel(q)}
      </div>
      <div style="font-size:11px;color:var(--text-secondary);margin-bottom:8px;padding:6px 8px;background:#fffbeb;border-radius:6px">
        ⚖️ <strong>风险等级以本地检测为主</strong>：CRITICAL/HIGH 主要由「数值幻觉、证据接地、推理链接地、结构自查」这些<strong>逐字核对</strong>的硬指标决定；LLM 八维分高只代表语义层面好，<strong>不能覆盖</strong>本地检测的红灯（除非命中 SOURCE_MISMATCH/MECHANISM_MISMATCH/UNANSWERABLE 等八维专属标签才单独升级）。
      </div>
      <details style="margin-bottom:8px"><summary style="cursor:pointer;color:var(--primary)">证据 (${(q.evidence_items_full||[]).length}) ＋ 检测明细</summary>
        <div style="font-size:12px;color:var(--text-secondary);margin:6px 0">${scoreLine}</div>
        ${judgeFlags?`<div style="font-size:12px;margin-bottom:4px"><strong>Judge flags:</strong> ${escapeHtml(judgeFlags)}</div>`:""}
        ${q.judge_comments?`<div style="font-size:12px;margin-bottom:4px"><strong>Judge 评语:</strong> ${escapeHtml(q.judge_comments)}</div>`:""}
        ${sugg?`<div style="font-size:12px"><strong>建议:</strong><ul style="margin:2px 0 0 16px">${sugg}</ul></div>`:""}
        ${focus?`<div style="font-size:12px"><strong>专家关注点:</strong><ul style="margin:2px 0 0 16px">${focus}</ul></div>`:""}
        <ul style="margin:6px 0 0 16px;font-size:13px">${evList}</ul>
      </details>
      <div style="background:var(--bg-secondary,#faf8ff);padding:10px;border-radius:8px">
        <div style="font-size:12px;color:var(--text-secondary);margin-bottom:8px">
          直接填写<strong>修改后的完整题目与答案</strong> → 点顶部「提交专家意见并重审」：系统原样采用题目、把答案自动拆成得分点(key_points)并重新质量评测。<strong>建议只对中低风险题修正；高风险题直接「拒绝」。</strong>
        </div>
        <div style="margin-bottom:8px">
          <div style="font-size:12px;font-weight:600;color:var(--primary-dark);margin-bottom:4px">✏️ 改题目</div>
          <textarea class="exp-new-question" data-orig="${escapeHtml(q.question||'')}" style="width:100%;min-height:60px;padding:6px">${escapeHtml(q.question||'')}</textarea>
        </div>
        <div style="margin-bottom:8px">
          <div style="font-size:12px;font-weight:600;color:var(--primary-dark);margin-bottom:4px">📝 改答案 <span style="font-weight:400;color:var(--text-secondary)">（提交后自动拆成得分点）</span></div>
          <textarea class="exp-new-answer" data-orig="${escapeHtml(q.answer||'')}" style="width:100%;min-height:90px;padding:6px">${escapeHtml(q.answer||'')}</textarea>
        </div>
        <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
          <button class="btn btn-success btn-sm" onclick="acceptQuestion('${escapeHtml(q.question_id)}')" style="background:#10b981;color:#fff;border:none">✓ 接受(PASS)</button>
          <button class="btn btn-danger btn-sm" onclick="rejectQuestion('${escapeHtml(q.question_id)}')">🗑 拒绝(归档)</button>
          <span style="font-size:12px;color:var(--text-secondary)">接受 = 留在题库记为可用 ｜ 拒绝 = 移到 output/rejected 从题库移除</span>
        </div>
      </div>
    </div>`;
  }).join("");
}

function _collectFeedback() {
  const expertName = (document.getElementById("expert-name").value || "").trim();
  const fb = [];
  document.querySelectorAll("#expert-cards .card[data-qid]").forEach(card => {
    const qEl = card.querySelector(".exp-new-question");
    const aEl = card.querySelector(".exp-new-answer");
    if (!qEl || !aEl) return;
    const newQ = qEl.value.trim();
    const newA = aEl.value.trim();
    const origQ = (qEl.dataset.orig || "").trim();
    const origA = (aEl.dataset.orig || "").trim();
    if (newQ === origQ && newA === origA) return;  // 未改动，跳过
    if (!newQ || !newA) return;                     // 直采要求题目和答案都非空
    fb.push({
      question_id: card.dataset.qid,
      decision: "rewrite",
      expert_revised_question: newQ,
      expert_revised_answer: newA,
      expert_name: expertName,
    });
  });
  return { fb, expertName };
}

// 接受(PASS)：fast-path 模式。题留在题库、记入 usable_ids.json，从面板消失，不触发重审。
async function acceptQuestion(qid) {
  const expertName = (document.getElementById("expert-name").value || "").trim();
  if (!expertName) { toast("请先填写专家姓名", "error"); return; }
  if (!confirm("确认接受此题？将记为可用(usable)，题目保留在题库，仅从审核面板移除。")) return;
  const card = document.querySelector(`#expert-cards .card[data-qid="${CSS.escape(qid)}"]`);
  if (card) {
    card.style.opacity = "0.3";
    card.style.pointerEvents = "none";
    const btn = card.querySelector("button.btn-success");
    if (btn) btn.disabled = true;
  }
  try {
    const resp = await fetch("/api/expert/accept-one", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ question_id: qid, batch: _currentBatch }),
    });
    const r = await resp.json();
    if (resp.ok && r.ok) {
      if (card) {
        card.style.transition = "opacity 0.4s";
        card.style.opacity = "0";
        setTimeout(() => card.remove(), 1500);
      }
      toast("已接受: " + qid, "success");
      if (_reviewData && _reviewData.questions) {
        _reviewData.questions = _reviewData.questions.filter(x => x.question_id !== qid);
      }
      loadStats();
    } else {
      if (card) {
        card.style.opacity = "1";
        card.style.pointerEvents = "";
        const btn = card.querySelector("button.btn-success");
        if (btn) btn.disabled = false;
      }
      toast("接受失败: " + (r.error || "未知错误"), "error");
    }
  } catch (e) {
    if (card) {
      card.style.opacity = "1";
      card.style.pointerEvents = "";
      const btn = card.querySelector("button.btn-success");
      if (btn) btn.disabled = false;
    }
    toast("接受出错: " + e, "error");
  }
}

// 拒绝并归档：fast-path 模式。1-2 秒处理完，不触发完整 review。
async function rejectQuestion(qid) {
  const expertName = (document.getElementById("expert-name").value || "").trim();
  if (!expertName) { toast("请先填写专家姓名", "error"); return; }
  if (!confirm("确认拒绝并归档此题？将移到 output/rejected，从题库移除。")) return;
  // 找到对应 card，立即灰掉
  const card = document.querySelector(`#expert-cards .card[data-qid="${CSS.escape(qid)}"]`);
  if (card) {
    card.style.opacity = "0.3";
    card.style.pointerEvents = "none";
    const btn = card.querySelector("button.btn-danger");
    if (btn) btn.disabled = true;
  }
  try {
    const resp = await fetch("/api/expert/reject-one", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ question_id: qid, batch: _currentBatch }),
    });
    const r = await resp.json();
    if (resp.ok && r.ok) {
      // 成功：1.5 秒淡出后从 DOM 删除
      if (card) {
        card.style.transition = "opacity 0.4s";
        card.style.opacity = "0";
        setTimeout(() => card.remove(), 1500);
      }
      toast("已拒绝: " + qid, "success");
      // 从内存数据移除并刷新统计看板
      if (_reviewData && _reviewData.questions) {
        _reviewData.questions = _reviewData.questions.filter(x => x.question_id !== qid);
      }
      loadStats();
    } else {
      // 失败：恢复显示
      if (card) {
        card.style.opacity = "1";
        card.style.pointerEvents = "";
        const btn = card.querySelector("button.btn-danger");
        if (btn) btn.disabled = false;
      }
      toast("拒绝失败: " + (r.error || "未知错误"), "error");
    }
  } catch (e) {
    if (card) {
      card.style.opacity = "1";
      card.style.pointerEvents = "";
      const btn = card.querySelector("button.btn-danger");
      if (btn) btn.disabled = false;
    }
    toast("拒绝出错: " + e, "error");
  }
}

async function submitExpertFeedback() {
  const { fb, expertName } = _collectFeedback();
  if (!fb.length) { toast("没有改动过「改题目/改答案」的题目", "error"); return; }
  if (!expertName) { toast("请先填写专家姓名", "error"); return; }
  if (!confirm(`将提交 ${fb.length} 条专家意见并自动重审，确认？`)) return;
  try {
    const resp = await fetch("/api/expert/apply", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        feedback: fb,
        batch: _currentBatch,
        with_llm_judge: document.getElementById("expert-judge-rerun").checked,
        judge_models: _chainNames(JUDGE_CHAIN),
      }),
    });
    const r = await resp.json();
    if (r.task_id) {
      toast("已提交，任务: " + r.task_id + "，完成后专家面板会自动刷新", "success");
      _watchTaskThenReloadReview(r.task_id);
      // 不再跳到 tasks 页：留在 expert panel 继续审
    } else { toast("提交失败: " + (r.error||""), "error"); }
  } catch (e) { toast("提交失败: " + e, "error"); }
}

// Poll a backend task until it finishes, then auto-reload the expert panel
// (and reports) so the user doesn't have to manually click "刷新数据".
function _watchTaskThenReloadReview(taskId) {
  if (!taskId) return;
  const started = Date.now();
  const timer = setInterval(async () => {
    // give up after 20 min so we never poll forever
    if (Date.now() - started > 20 * 60 * 1000) { clearInterval(timer); return; }
    try {
      const t = await (await fetch("/api/tasks/" + taskId)).json();
      if (["done", "failed", "stopped"].includes(t.status)) {
        clearInterval(timer);
        if (t.status === "done") {
          await loadReviewData();
          if (typeof loadReports === "function") loadReports();
          toast("任务完成，专家面板已自动刷新", "success");
        } else {
          toast("任务" + (t.status === "failed" ? "失败" : "已终止") + "，未刷新数据", "error");
        }
      }
    } catch (e) { /* transient fetch error: keep polling */ }
  }, 3000);
}

async function runRepair() {
  const rounds = parseInt(document.getElementById("expert-repair-rounds").value) || 1;
  const withReviewEl = document.getElementById("expert-repair-with-review");
  const withReview = withReviewEl ? withReviewEl.checked : true;
  const onlyNewEl = document.getElementById("expert-repair-only-new");
  const onlyNew = onlyNewEl ? onlyNewEl.checked : true;
  // 1) 预览：扫 input_dir 算将自纠 N 道（按 only_new 范围）
  let previewN = "?";
  let totalInDir = "?";
  let newCount = "?";
  try {
    const pr = await fetch("/api/repair/preview", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ only_new: onlyNew, batch: _currentBatch }),
    });
    const pj = await pr.json();
    if (pr.ok) {
      previewN = pj.will_repair_count;
      totalInDir = pj.total_in_dir;
      newCount = pj.new_count;
    }
  } catch (e) { /* 预览失败不阻塞 */ }
  const scopeNote = onlyNew
    ? `范围：仅最新出的题（本批 ${newCount} 道）`
    : `范围：目录下全部题（共 ${totalInDir} 道）`;
  const reviewNote = withReview ? "自纠后跑完整 review（约 30 分钟）" : "自纠后不跑 review（几分钟）";
  if (!confirm(`将自纠 ${previewN} 道题\n${scopeNote}\n${rounds} 轮 LLM 自纠\n${reviewNote}\n确认？`)) return;
  try {
    const resp = await fetch("/api/repair", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        rounds: rounds,
        with_review: withReview,
        only_new: onlyNew,
        batch: _currentBatch,
        with_llm_judge: document.getElementById("expert-judge-rerun").checked,
        judge_models: _chainNames(JUDGE_CHAIN),
      }),
    });
    const r = await resp.json();
    if (r.task_id) {
      toast("自纠已启动: " + r.task_id, "success");
      _watchTaskThenReloadReview(r.task_id);
      // 不再跳到 tasks 页：留在 expert panel 继续审
    } else { toast("启动失败", "error"); }
  } catch (e) { toast("启动失败: " + e, "error"); }
}

// ===== 统计看板：顶部汇总(全题库) + 「已接受(PASS)」分布(按题型/难度) =====
async function loadStats() {
  const board = document.getElementById("stats-board");
  const summary = document.getElementById("expert-summary");
  try {
    const resp = await fetch("/api/stats?only_new=0");
    const s = await resp.json();
    if (!resp.ok) { if (board) board.innerHTML = ""; return; }
    // 顶部汇总：统计整个题库的所有题目（总数 + 风险分布）
    if (summary) {
      const br = s.by_risk || {};
      const riskTxt = ["CRITICAL","HIGH","MEDIUM","LOW","PASS"].map(r =>
        `<span style="color:${RISK_COLOR[r]||'#888'};font-weight:600">${r}: ${br[r]||0}</span>`).join(" ｜ ");
      const unrated = br["?"] || 0;
      summary.innerHTML = `题库共 <strong>${s.total}</strong> 题 ｜ ${riskTxt}` +
        (unrated ? ` ｜ <span style="color:#888">未评: ${unrated}</span>` : "") +
        ` ｜ ✅已接受: <strong style="color:#10b981">${(s.pass||{}).total||0}</strong>`;
    }
    if (!board) return;
    const mkTable = (title, obj) => {
      const keys = Object.keys(obj || {});
      if (!keys.length) return `<div style="margin-right:24px"><div style="font-size:12px;color:var(--text-secondary)">${title}</div><div style="font-size:13px;color:var(--text-secondary)">—</div></div>`;
      const cells = keys.map(k => `<td style="padding:4px 12px;text-align:center">${escapeHtml(k)}<br><strong style="font-size:16px">${obj[k]}</strong></td>`).join("");
      return `<div style="margin-right:24px"><div style="font-size:12px;color:var(--text-secondary);margin-bottom:2px">${title}</div><table style="border-collapse:collapse"><tr>${cells}</tr></table></div>`;
    };
    const pass = s.pass || {total:0,by_domain:{},by_difficulty:{}};
    board.innerHTML = `
      <div style="padding:8px 10px;background:var(--bg-secondary,#faf8ff);border-left:3px solid #10b981;border-radius:6px">
        <div style="font-size:13px;font-weight:600;margin-bottom:6px">✅ 已接受(PASS) <span style="font-weight:400;color:var(--text-secondary)">共 ${pass.total} 道（仅专家点击接受的题）</span></div>
        <div style="display:flex;flex-wrap:wrap;row-gap:8px">
          ${mkTable("按题型/领域", pass.by_domain)}
          ${mkTable("按难度", pass.by_difficulty)}
        </div>
      </div>`;
  } catch (e) { if (board) board.innerHTML = ""; }
}

// ===== Theme =====
function toggleTheme() {
  document.body.classList.toggle("dark");
  const btn = document.querySelector(".theme-toggle");
  btn.innerHTML = document.body.classList.contains("dark") ? "&#9790;" : "&#9728;";
}

// ===== Init =====
// 先校验登录态：已登录 → 进应用(checkAuth 内调 loadConfig)；未登录 → 弹遮罩。
checkAuth();
</script>

</body>
</html>
'''

def main():
    global SERVER_PORT
    parser = argparse.ArgumentParser(description="QAG Web UI Server")
    parser.add_argument("--port", type=int, default=5000, help="Server port (default 5000)")
    parser.add_argument("--host", default="127.0.0.1", help="Server host (default 127.0.0.1)")
    parser.add_argument("--debug", action="store_true", help="Enable debug mode")
    args = parser.parse_args()
    SERVER_PORT = args.port

    # Ensure output directories exist
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    for level_dir in ["L1_简单事实检索", "L2_多跳逻辑推理", "L3_主题概括类", "L4_创新发散题目"]:
        (OUTPUT_DIR / level_dir).mkdir(parents=True, exist_ok=True)

    print(f"""
╔══════════════════════════════════════════════════╗
║   QAG - 知识图谱出题与图谱测评平台 Web UI        ║
║                                                  ║
║  访问地址: http://{args.host}:{args.port}                   ║
║  项目目录: {QAG_DIR}      ║
║  PDF 目录: {EXTERN_DIR}    ║
║  输出目录: {OUTPUT_DIR}            ║
╚══════════════════════════════════════════════════╝
    """)

    app.run(host=args.host, port=args.port, debug=args.debug)

if __name__ == "__main__":
    main()
