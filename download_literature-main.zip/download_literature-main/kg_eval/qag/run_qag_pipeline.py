#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""QAG-merged one-command pipeline.

Combines v1 generation with v2 expert closed-loop:

  generate (v1) → review (8-dim) → [self-repair] → re-review → export review_data.json
                                                              ↘ [apply expert feedback] → re-review

Examples:
  # Generate + local review only
  python run_qag_pipeline.py --source external --hops 1,2,3,4 --domains FABS,HCFG,MECH,POPT

  # Full: generate + LLM judge + self-repair + export expert review data
  python run_qag_pipeline.py --source external --hops 1,2 --with-llm-judge --with-self-repair

  # Skip generation, just review existing questions
  python run_qag_pipeline.py --skip-generate --with-llm-judge

  # Apply expert feedback JSON (filled via Web UI), then re-review
  python run_qag_pipeline.py --skip-generate --apply-expert-feedback output/reports/expert_feedback.json --with-llm-judge
"""

from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path

QAG_DIR = Path(__file__).resolve().parent
REPO_ROOT = QAG_DIR.parent
GENERATE_SCRIPT = QAG_DIR / "generate_questions.py"
EVALUATOR = QAG_DIR / "pipline" / "evaluation.py"
SCRIPT_DIR = QAG_DIR / "script"
DEFAULT_EXTERN_DIR = QAG_DIR / "extern_data"
DEFAULT_OUTPUT_DIR = QAG_DIR / "output"
DEFAULT_REPORT_DIR = QAG_DIR / "output" / "reports"


def run_step(name: str, cmd: list[str], env: dict, required: bool = True) -> int:
    print(f"\n[QAG-PIPELINE] {name}")
    print("[QAG-PIPELINE] " + " ".join(cmd))
    result = subprocess.run(cmd, check=False, cwd=str(REPO_ROOT), env=env)
    if result.returncode != 0:
        if required:
            print(f"[QAG-PIPELINE] FATAL: {name} 失败 (exit={result.returncode})", file=sys.stderr)
            sys.exit(result.returncode)
        print(f"[QAG-PIPELINE] WARN: {name} exit={result.returncode}（非必需，继续）")
    return result.returncode


def build_review_cmd(args, prefix: str, with_llm_judge: bool) -> list[str]:
    cmd = [
        sys.executable, str(EVALUATOR),
        "--input-dir", args.output_dir,
        "--report-dir", args.report_dir,
        "--report-prefix", prefix,
        "--pdf-dir", args.extern_dir,
    ]
    if args.kb_db:
        cmd += ["--kb-db", args.kb_db]
    if args.no_kb_check:
        cmd.append("--no-kb-check")
    if with_llm_judge:
        cmd += ["--with-llm-judge", "--model", args.model]
        if args.limit:
            cmd += ["--limit", str(args.limit)]
    if args.api_key:
        cmd += ["--api-key", args.api_key]
    if args.base_url:
        cmd += ["--base-url", args.base_url]
    if args.export_markdown:
        cmd.append("--export-markdown")
    if args.export_expert_workbench:
        cmd.append("--export-expert-workbench")
    return cmd


def main() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    parser = argparse.ArgumentParser(description="QAG-merged 全流程：出题 + 审核 + 专家闭环。")
    # ── Generation ──
    parser.add_argument("--source", choices=["internal", "external", "mixed"], default="mixed")
    parser.add_argument("--paper-range", default="1-3")
    parser.add_argument("--hops", default="1,2,3")
    parser.add_argument("--domains", default="FABS,HCFG,MECH,POPT")
    parser.add_argument("--num-per-domain", type=int, default=2)
    parser.add_argument("--extern-dir", default=str(DEFAULT_EXTERN_DIR))
    parser.add_argument("--kb-db", default="")
    parser.add_argument("--output-dir", default=str(DEFAULT_OUTPUT_DIR))
    parser.add_argument("--start-index", type=int, default=0)
    parser.add_argument("--dry-run", action="store_true", help="只跑出题计划，不调用模型")
    parser.add_argument("--skip-generate", action="store_true", help="跳过出题，直接审核已有题目")
    # ── Review ──
    parser.add_argument("--report-dir", default=str(DEFAULT_REPORT_DIR))
    parser.add_argument("--no-kb-check", action="store_true")
    parser.add_argument("--with-llm-judge", action="store_true")
    parser.add_argument("--model", default="gpt5.5")
    parser.add_argument("--api-key", default="")
    parser.add_argument("--base-url", default="")
    parser.add_argument("--limit", type=int, default=0)
    parser.add_argument("--export-markdown", action="store_true")
    parser.add_argument("--export-expert-workbench", action="store_true")
    # ── Closed loop ──
    parser.add_argument("--with-self-repair", action="store_true", help="审核后 LLM 自纠")
    parser.add_argument("--repair-rounds", type=int, default=1)
    parser.add_argument("--apply-expert-feedback", default="",
                        help="专家反馈 JSON 路径（Web UI 导出）；指定则跳过出题，应用反馈后重审")
    args = parser.parse_args()

    env = os.environ.copy()
    env.setdefault("PYTHONIOENCODING", "utf-8")
    env.setdefault("PYTHONUTF8", "1")
    report_dir = Path(args.report_dir)
    report_dir.mkdir(parents=True, exist_ok=True)

    # ── Mode: apply expert feedback ───────────────────────────────────────────
    if args.apply_expert_feedback:
        apply_cmd = [
            sys.executable, str(SCRIPT_DIR / "apply_expert_feedback.py"),
            "--input-dir", args.output_dir,
            "--feedback", args.apply_expert_feedback,
            "--report-dir", args.report_dir,
            "--model", args.model,
            "--apply",
        ]
        if args.api_key:
            apply_cmd += ["--api-key", args.api_key]
        if args.base_url:
            apply_cmd += ["--base-url", args.base_url]
        run_step("应用专家反馈", apply_cmd, env, required=True)
        run_step("专家反馈后重审",
                 build_review_cmd(args, "after_expert_", args.with_llm_judge), env)
        print(f"\n[QAG-PIPELINE] 完成。报告目录：{report_dir}")
        return

    # ── Mode: normal pipeline ─────────────────────────────────────────────────
    if not args.skip_generate:
        generate_cmd = [
            sys.executable, str(GENERATE_SCRIPT),
            "--source", args.source,
            "--paper-range", args.paper_range,
            "--hops", args.hops,
            "--domains", args.domains,
            "--num-per-domain", str(args.num_per_domain),
            "--extern-dir", args.extern_dir,
            "--output-dir", args.output_dir,
            "--start-index", str(args.start_index),
        ]
        if args.kb_db:
            generate_cmd += ["--kb-db", args.kb_db]
        if args.dry_run:
            generate_cmd.append("--dry-run")
        if args.api_key:
            generate_cmd += ["--api-key", args.api_key]
        if args.base_url:
            generate_cmd += ["--llm-base-url", args.base_url]
        run_step("出题", generate_cmd, env)

    # Initial review (judge here only if not self-repairing — repair needs judge first anyway)
    run_step("初次审核",
             build_review_cmd(args, "", args.with_llm_judge and not args.with_self_repair), env)

    if args.with_self_repair:
        # judge before repair so llm_repair has scores to act on
        if args.with_llm_judge:
            judge_cmd = [
                sys.executable, str(SCRIPT_DIR / "llm_judge.py"),
                "--input-dir", args.output_dir,
                "--report-dir", args.report_dir,
                "--model", args.model, "--pdf-dir", args.extern_dir,
            ]
            if args.kb_db:
                judge_cmd += ["--kb-db", args.kb_db]
            if args.limit:
                judge_cmd += ["--limit", str(args.limit)]
            if args.api_key:
                judge_cmd += ["--api-key", args.api_key]
            if args.base_url:
                judge_cmd += ["--base-url", args.base_url]
            run_step("LLM Judge（自纠前）", judge_cmd, env, required=False)

        repair_cmd = [
            sys.executable, str(SCRIPT_DIR / "llm_repair.py"),
            "--input-dir", args.output_dir,
            "--report-dir", args.report_dir,
            "--model", args.model,
            "--max-rounds", str(args.repair_rounds),
            "--apply",
        ]
        if args.api_key:
            repair_cmd += ["--api-key", args.api_key]
        if args.base_url:
            repair_cmd += ["--base-url", args.base_url]
        run_step(f"LLM 自纠（最多 {args.repair_rounds} 轮）", repair_cmd, env, required=False)

        run_step("自纠后重审",
                 build_review_cmd(args, "after_repair_", args.with_llm_judge), env)

    print(f"\n[QAG-PIPELINE] 完成。题目目录：{args.output_dir}")
    print(f"[QAG-PIPELINE] 报告目录：{args.report_dir}")
    print(f"[QAG-PIPELINE] 专家审查数据：{report_dir / 'review_data.json'}（可在 Web UI 专家面板打开）")


if __name__ == "__main__":
    main()
