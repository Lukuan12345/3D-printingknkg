#!/usr/bin/env python3
"""Build lightweight SQLite knowledge base from external PDFs for evidence grounding checks."""

import sqlite3, json, re, sys
from pathlib import Path

QAG_DIR = Path(__file__).resolve().parent.parent
EXTERN_DIR = QAG_DIR / "extern_data"
KB_PATH = QAG_DIR / "intern_data" / "kb.db"

def extract_numbers(text: str) -> list[str]:
    return re.findall(r'\b\d+\.?\d*\b', text)

def build_kb() -> dict:
    """Return stats dict."""
    try:
        import fitz
    except ImportError:
        return {"error": "PyMuPDF (fitz) not installed"}

    KB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(KB_PATH))
    conn.execute("DROP TABLE IF EXISTS paper_chunks")
    conn.execute("""CREATE TABLE paper_chunks (
        paper_id TEXT, field_type TEXT, content TEXT,
        nums TEXT, title TEXT
    )""")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_paper_id ON paper_chunks(paper_id)")

    total_papers = 0
    total_chunks = 0
    total_nums = 0

    for pdf_file in sorted(EXTERN_DIR.glob("*.pdf")):
        try:
            data = pdf_file.read_bytes()
            if not data.startswith(b"%PDF"):
                continue
            doc = fitz.open(stream=data, filetype="pdf")
            full_text = ""
            for i in range(min(20, len(doc))):
                page_text = doc[i].get_text()
                if page_text:
                    full_text += page_text + "\n"
            doc.close()

            if not full_text.strip():
                continue

            # Extract structured chunks
            title = full_text.split("\n")[0][:200] if full_text else pdf_file.stem
            nums = " ".join(extract_numbers(full_text))

            # Split into paragraphs as chunks
            chunks = [c.strip() for c in full_text.split("\n\n") if len(c.strip()) > 50]
            for ci, chunk in enumerate(chunks):
                conn.execute(
                    "INSERT INTO paper_chunks VALUES (?, ?, ?, ?, ?)",
                    (pdf_file.name, f"para_{ci}", chunk,
                     " ".join(extract_numbers(chunk)), title)
                )
                total_chunks += 1

            total_papers += 1
            total_nums += len(extract_numbers(full_text))
            print(f"[OK] {pdf_file.name} ({len(chunks)} chunks)")

        except Exception as e:
            print(f"[SKIP] {pdf_file.name}: {e}")

    conn.commit()
    conn.execute("ANALYZE paper_chunks")
    conn.close()

    return {
        "kb_path": str(KB_PATH),
        "papers_indexed": total_papers,
        "chunks": total_chunks,
        "numbers_extracted": total_nums,
    }

if __name__ == "__main__":
    print("Building PDF-KB...")
    stats = build_kb()
    print(json.dumps(stats, ensure_ascii=False, indent=2))
    print("Done!")
