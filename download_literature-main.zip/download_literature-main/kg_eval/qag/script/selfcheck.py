#!/usr/bin/env python3
"""
script/selfcheck.py - Structural validation of generated question JSON files.

Outputs:
  selfcheck_results.json   - Structured data for workbench aggregation
  selfcheck_report.md      - Human-readable report
  usable_ids.json          - IDs of questions that pass structural checks
"""
from __future__ import annotations

import argparse
import json
import re
import sqlite3
import sys
from datetime import datetime
from pathlib import Path

# ─── Constants ────────────────────────────────────────────────────────────────

QAG_DIR = Path(__file__).resolve().parent.parent
DEFAULT_PDF_DIR = QAG_DIR / "extern_data"
DEFAULT_KB_CANDIDATES = [
    QAG_DIR / "intern_data" / "kb.db",
    QAG_DIR / "intern_data" / "kb_mvp" / "data" / "kb.db",
]

REQUIRED_TOP_FIELDS = [
    "id", "question", "difficulty_level", "hop_count",
    "recommended_papers", "gold_evidence", "expected_path_nodes", "ground_truth",
]

REQUIRED_GT_FIELDS = ["answer", "key_points"]

LEVEL_HOP_RANGE: dict[str, tuple[int, int]] = {
    "L1": (1, 2),
    "L2": (2, 3),
    "L3": (3, 4),
    "L4": (4, 6),
}

SKIP_FILENAMES = {
    "generation_manifest.json",
    "question_quality_metrics.json",
    "reasoning_path_validation.json",
    "llm_judge_question_scores.json",
    "usable_ids.json",
    "usable_question_ids.json",
    "final_questions.json",
    "selfcheck_results.json",
    "llm_repair_log.json",
    "expert_feedback_apply_log.json",
}

# ─── Helpers ──────────────────────────────────────────────────────────────────

def load_questions(input_dir: Path) -> list[dict]:
    questions: list[dict] = []
    for jf in sorted(input_dir.rglob("*.json")):
        if jf.name in SKIP_FILENAMES:
            continue
        if "reports" in jf.parts or "rejected" in jf.parts:
            continue
        try:
            data = json.loads(jf.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            continue
        if isinstance(data, dict) and "id" in data:
            data["_file_path"] = str(jf)
            questions.append(data)
        elif isinstance(data, list):
            continue  # QAG-v2 requires one-question-per-file
    return questions


def check_question(q: dict, known_sources: set[str] | None = None) -> dict:
    issues: list[str] = []
    warnings: list[str] = []

    # Required top-level fields
    for field in REQUIRED_TOP_FIELDS:
        val = q.get(field)
        if val is None:
            issues.append(f"缺少字段: {field}")
        elif isinstance(val, (str, list, dict)) and not val:
            if field in ("gold_evidence", "expected_path_nodes", "recommended_papers"):
                issues.append(f"字段为空: {field}")

    # ground_truth sub-fields
    gt: dict = q.get("ground_truth") or {}
    for field in REQUIRED_GT_FIELDS:
        val = gt.get(field)
        if not val:
            issues.append(f"ground_truth.{field} 为空")
        elif isinstance(val, str) and re.search(r"\[占位|TODO|PLACEHOLDER", val, re.I):
            issues.append(f"ground_truth.{field} 含占位符")
        elif isinstance(val, list) and len(val) == 0:
            issues.append(f"ground_truth.{field} 列表为空")

    # hop_count range
    level = q.get("difficulty_level", "")
    hop = q.get("hop_count")
    if level in LEVEL_HOP_RANGE and isinstance(hop, int):
        lo, hi = LEVEL_HOP_RANGE[level]
        if not (lo <= hop <= hi):
            warnings.append(f"hop_count={hop} 不在 {level} 允许范围 [{lo},{hi}]")

    # path_nodes count
    nodes = q.get("expected_path_nodes") or []
    if isinstance(hop, int) and isinstance(nodes, list):
        if len(nodes) < hop + 1:
            warnings.append(
                f"expected_path_nodes 数量({len(nodes)}) < hop_count+1({hop+1})"
            )

    # gold_evidence count
    gold = q.get("gold_evidence") or []
    if isinstance(hop, int) and isinstance(gold, list):
        required_ev = min(hop, 2)
        if len(gold) < required_ev:
            warnings.append(
                f"gold_evidence 数量({len(gold)}) < min(hop,2)={required_ev}"
            )

    # Source existence in KB / PDF (restored from v1; skipped when known_sources is None)
    if known_sources:
        meta = q.get("annotation_meta") or {}
        src_ids = [str(x) for x in (meta.get("source_file_names") or [])]
        src_ids += [str(x) for x in (meta.get("source_paper_uids") or [])]
        unmatched = [
            s for s in src_ids
            if s.lower() not in known_sources and Path(s).stem.lower() not in known_sources
        ]
        if src_ids and len(unmatched) == len(src_ids):
            warnings.append(
                f"来源文献未在 KB/PDF 库中找到: {unmatched[:3]}（可能影响接地校验）"
            )

    if issues:
        has_q = bool((q.get("question") or "").strip())
        has_a = bool((gt.get("answer") or "").strip())
        status = "partial" if (has_q or has_a) else "blank"
    elif warnings:
        status = "partial"
    else:
        status = "ok"

    return {
        "id": q.get("id", "UNKNOWN"),
        "file_path": q.get("_file_path", ""),
        "difficulty_level": q.get("difficulty_level", ""),
        "domain": q.get("domain", ""),
        "hop_count": hop,
        "status": status,
        "issues": issues,
        "warnings": warnings,
    }


# ─── Report builders ──────────────────────────────────────────────────────────

def build_markdown(results: list[dict], summary: dict) -> str:
    lines = [
        "# 结构自检报告 (QAG-v2)",
        f"> 生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        "",
        "## 汇总",
        f"| 项目 | 数量 |",
        f"|---|---|",
        f"| 题目总数 | {summary['total']} |",
        f"| 通过 (ok) | {summary['ok']} |",
        f"| 部分通过 (partial) | {summary['partial']} |",
        f"| 空白 (blank) | {summary['blank']} |",
        "",
        "## 明细",
    ]
    for r in results:
        status_icon = {"ok": "✅", "partial": "⚠️", "blank": "❌"}.get(r["status"], "?")
        lines.append(f"\n### {status_icon} {r['id']} ({r['status']})")
        lines.append(f"- 文件: `{r['file_path']}`")
        lines.append(f"- 难度: {r['difficulty_level']}  域: {r['domain']}  跳数: {r['hop_count']}")
        if r["issues"]:
            lines.append("- **问题:**")
            for iss in r["issues"]:
                lines.append(f"  - {iss}")
        if r["warnings"]:
            lines.append("- **警告:**")
            for w in r["warnings"]:
                lines.append(f"  - {w}")
    return "\n".join(lines)


# ─── KB / PDF known-source index (restored from v1) ──────────────────────────

def resolve_kb_path(arg_path: str | None) -> Path | None:
    if arg_path:
        p = Path(arg_path)
        return p if p.exists() else None
    return next((p for p in DEFAULT_KB_CANDIDATES if p.exists()), None)


def build_known_sources(kb_path: Path | None, pdf_dir: Path) -> set[str]:
    """Lowercased set of known paper_ids / PDF names / stems."""
    known: set[str] = set()
    if kb_path and kb_path.exists():
        try:
            conn = sqlite3.connect(str(kb_path))
            for (pid,) in conn.execute("SELECT DISTINCT paper_id FROM paper_chunks"):
                if pid:
                    known.add(str(pid).lower())
                    known.add(Path(str(pid)).stem.lower())
            conn.close()
        except sqlite3.Error:
            pass
    if pdf_dir.exists():
        for pdf in pdf_dir.glob("*.pdf"):
            known.add(pdf.name.lower())
            known.add(pdf.stem.lower())
    return known


# ─── Main ─────────────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(description="QAG-merged 结构自检")
    parser.add_argument("--input-dir", default="output", help="题目 JSON 根目录")
    parser.add_argument("--report-dir", default="output/reports", help="报告输出目录")
    parser.add_argument("--report-prefix", default="", help="报告文件前缀")
    parser.add_argument("--json-out", default="", help="selfcheck_results.json 输出路径（覆盖默认）")
    parser.add_argument("--pdf-dir", default=str(DEFAULT_PDF_DIR), help="专家 PDF 目录")
    parser.add_argument("--kb-db", default="", help="kb.db 路径；不填则自动查找")
    parser.add_argument("--no-kb-check", action="store_true", help="跳过来源文献存在性校验")
    args = parser.parse_args()

    input_dir = Path(args.input_dir)
    report_dir = Path(args.report_dir)
    report_dir.mkdir(parents=True, exist_ok=True)
    pfx = args.report_prefix

    questions = load_questions(input_dir)
    if not questions:
        print(f"[selfcheck] 未在 {input_dir} 找到题目 JSON", file=sys.stderr)
        sys.exit(1)

    known_sources: set[str] | None = None
    if not args.no_kb_check:
        known_sources = build_known_sources(resolve_kb_path(args.kb_db), Path(args.pdf_dir))
        if known_sources:
            print(f"[selfcheck] 已加载来源索引（{len(known_sources)} 条标识）用于存在性校验")

    results = [check_question(q, known_sources) for q in questions]

    summary = {
        "total": len(results),
        "ok": sum(1 for r in results if r["status"] == "ok"),
        "partial": sum(1 for r in results if r["status"] == "partial"),
        "blank": sum(1 for r in results if r["status"] == "blank"),
    }

    # Write selfcheck_results.json
    json_path = Path(args.json_out) if args.json_out else report_dir / f"{pfx}selfcheck_results.json"
    json_path.write_text(
        json.dumps({"summary": summary, "questions": results}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    # Write markdown report
    md_path = report_dir / f"{pfx}selfcheck_report.md"
    md_path.write_text(build_markdown(results, summary), encoding="utf-8")

    # Write usable IDs
    usable = [r["id"] for r in results if r["status"] in ("ok", "partial")]
    (report_dir / f"{pfx}usable_ids.json").write_text(
        json.dumps(usable, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    print(f"[selfcheck] 总计 {summary['total']} 题: "
          f"ok={summary['ok']}, partial={summary['partial']}, blank={summary['blank']}")
    print(f"[selfcheck] 报告 → {md_path}")
    print(f"[selfcheck] 结构化 → {json_path}")


if __name__ == "__main__":
    main()
