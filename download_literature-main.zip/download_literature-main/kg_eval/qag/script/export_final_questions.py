#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Export QAG generated questions into review-friendly artifacts."""

from __future__ import annotations

import json
import argparse
from collections import Counter
from pathlib import Path

QAG_DIR = Path(__file__).resolve().parent.parent
DEFAULT_INPUT_DIR = QAG_DIR / "output"
REPORT_DIR = QAG_DIR / "output" / "reports"
OUT_JSON = REPORT_DIR / "final_40_questions.json"
OUT_MD = REPORT_DIR / "final_40_questions_for_review.md"


def load_questions(input_dir: Path = DEFAULT_INPUT_DIR) -> list[dict]:
    items = []
    if not input_dir.exists():
        return items
    for fp in sorted(input_dir.rglob("*.json")):
        if fp.name == "generation_manifest.json":
            continue
        with fp.open(encoding="utf-8") as f:
            q = json.load(f)
        if isinstance(q, dict) and "id" in q and "question" in q:
            q["_file"] = str(fp)
            items.append(q)
    return items


def build_md(items: list[dict]) -> str:
    by_level = Counter(q.get("difficulty_level") for q in items)
    by_domain = Counter(q.get("domain") for q in items)
    by_intent = Counter(q.get("intent") for q in items)
    lines = [
        "# 最终40道题审查稿",
        "",
        "本文件由 `QAG/script/export_final_questions.py` 从 `QAG/output/` 自动汇总。",
        "",
        "## 分布概览",
        "",
        f"- 总题数：{len(items)}",
        "- 难度分布：" + "；".join(f"{k}={v}" for k, v in sorted(by_level.items())),
        "- 领域分布：" + "；".join(f"{k}={v}" for k, v in sorted(by_domain.items())),
        "- 意图分布：" + "；".join(f"{k}={v}" for k, v in sorted(by_intent.items())),
        "",
        "## 题目清单",
        "",
    ]
    for q in items:
        gt = q.get("ground_truth") or {}
        meta = q.get("annotation_meta") or {}
        lines += [
            f"### {q.get('id')}",
            "",
            f"- 难度：{q.get('difficulty_level')} / {q.get('difficulty_name')}",
            f"- 领域：{q.get('domain')} / {q.get('domain_name')}",
            f"- 意图：{q.get('intent')}",
            f"- 跳数：{q.get('hop_count')}",
            f"- 来源模式：{meta.get('source_mode', '')}",
            f"- 文件：`{q.get('_file')}`",
            "",
            "**题目**",
            "",
            q.get("question", ""),
            "",
            "**推荐文献**",
            "",
        ]
        for p in q.get("recommended_papers") or []:
            lines.append(f"- {p}")
        lines += [
            "",
            "**标准答案**",
            "",
            gt.get("answer", ""),
            "",
            "**Key Points**",
            "",
        ]
        for kp in gt.get("key_points") or []:
            lines.append(f"- {kp}")
        lines += [
            "",
            "**Gold Evidence**",
            "",
        ]
        for ev in q.get("gold_evidence") or []:
            text = ev.get("text", "") if isinstance(ev, dict) else str(ev)
            source = ev.get("source", "") if isinstance(ev, dict) else ""
            lines.append(f"- 来源：{source}  \n  证据：{text}")
        lines.append("")
    return "\n".join(lines) + "\n"


def apply_range(items: list, range_spec: str) -> list:
    spec = range_spec.strip()
    if not spec:
        return items
    if "-" in spec:
        lo_str, hi_str = spec.split("-", 1)
        lo = int(lo_str) if lo_str.strip() else 1
        hi = int(hi_str) if hi_str.strip() else len(items)
    else:
        lo = hi = int(spec)
    lo = max(1, lo)
    hi = min(len(items), hi)
    if lo > hi:
        return []
    return items[lo - 1: hi]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-dir", default=str(DEFAULT_INPUT_DIR))
    parser.add_argument("--out-json", default=str(OUT_JSON))
    parser.add_argument("--out-md", default=str(OUT_MD))
    parser.add_argument("--range", dest="range_spec", default="",
                        help='只导出指定区间的题目（1-based，包含两端），如 "2-3" 或 "5"。')
    parser.add_argument("--limit", type=int, default=0,
                        help="只导出前 N 道题；0 表示全部。与 --range 二选一。")
    args = parser.parse_args()

    items = load_questions(Path(args.input_dir))
    if args.range_spec:
        items = apply_range(items, args.range_spec)
    elif args.limit:
        items = items[: args.limit]
    out_json = Path(args.out_json)
    out_md = Path(args.out_md)
    out_json.parent.mkdir(parents=True, exist_ok=True)
    out_md.parent.mkdir(parents=True, exist_ok=True)
    out_json.write_text(json.dumps(items, ensure_ascii=False, indent=2), encoding="utf-8")
    out_md.write_text(build_md(items), encoding="utf-8")
    print(f"[OK] {out_json} ({len(items)} questions)")
    print(f"[OK] {out_md}")


if __name__ == "__main__":
    main()
