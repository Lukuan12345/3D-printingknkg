#!/usr/bin/env python3
"""
script/grounding_lang.py - Cross-lingual grounding helpers (QAG-merged).

Why this exists
---------------
本平台的题目/答案/推理链节点是**中文**，而外部证据多为**英文 PDF**原文。
旧的接地打分（check_quality / validate_paths）把中文逐字符 token 化后去和英文
原文求重合，中文字符天然不可能命中英文，分母又几乎全是中文字 → 证据接地分被
结构性压到 ~0.08、推理链接地分恒为 0，跨题几乎不变、与 LLM 语义判分严重背离。

这里提供「语言无关锚点」工具：在跨语种场景下，只比较两端共有、可对齐的技术锚点
（数字、单位/拉丁术语、缩写），从而得到有区分度、可解释的接地分。同语种场景
（中文证据 vs 中文答案）不受影响，仍由调用方走原全 token 逻辑。

被 check_quality.py 与 validate_paths.py 以 `import grounding_lang` 方式复用
（两者同目录，子进程 sys.path[0] 即本目录，import 安全）。
"""
from __future__ import annotations

import re

# 引用标记：[EV-001] / EV-001 / [11], [12] —— 先剔除，避免把编号当成数值/锚点。
_CITATION_RE = re.compile(r"\[?\bEV-\d+\b\]?|\[\d+(?:\s*,\s*\d+)*\]", re.I)

# 拉丁词锚点：连续字母，长度≥2，小写归一（GHz、FSR、CPCM、dB、roll…）。
_LATIN_RE = re.compile(r"[A-Za-z]{2,}")

# 数值锚点：整数或小数；范围（7.9–12.1 / 13~18.55 / 20-80）由调用处按分隔符二次拆分。
_NUMBER_RE = re.compile(r"\d+(?:\.\d+)?")

# CJK 统计用
_CJK_RE = re.compile(r"[一-鿿]")


def _strip_citations(text: str) -> str:
    return _CITATION_RE.sub(" ", text or "")


def cjk_ratio(text: str) -> float:
    """CJK 字符占 (CJK + 拉丁字母) 的比例；无字符时返回 0.0。"""
    if not text:
        return 0.0
    cjk = len(_CJK_RE.findall(text))
    latin = len(re.findall(r"[A-Za-z]", text))
    denom = cjk + latin
    return (cjk / denom) if denom else 0.0


def is_cjk_dominant(text: str, threshold: float = 0.5) -> bool:
    return cjk_ratio(text) >= threshold


def is_latin_dominant(text: str, threshold: float = 0.2) -> bool:
    """偏拉丁（英文）：CJK 占比很低。空串视为偏拉丁（无中文可对齐）。"""
    return cjk_ratio(text) <= threshold


def cross_lingual(a: str, b: str) -> bool:
    """a 偏中文且 b 偏拉丁（英文）即判跨语种。

    用于决定接地打分是否切到「仅比锚点」模式：典型即中文答案/节点(a) vs 英文证据(b)。
    """
    return is_cjk_dominant(a) and is_latin_dominant(b)


def numeric_values(text: str) -> set[str]:
    """规整后的数值集合（去引用标记、float 归一为字符串）。

    '7.9–12.1' 这类范围由 _NUMBER_RE 自然拆为 '7.9' 与 '12.1' 两个端点；
    '042' / '42.0' 归一为 '42'，避免格式差异造成的假阳性。
    """
    cleaned = _strip_citations(text)
    vals: set[str] = set()
    for m in _NUMBER_RE.findall(cleaned):
        try:
            f = float(m)
        except ValueError:
            continue
        # 整数去小数尾零；小数保留原值（float 归一）
        vals.add(str(int(f)) if f.is_integer() else repr(f))
    return vals


def anchor_tokens(text: str) -> set[str]:
    """语言无关锚点：小写拉丁词(≥2) + 规整数值。先剔除引用标记。"""
    cleaned = _strip_citations(text)
    tokens: set[str] = set()
    for w in _LATIN_RE.findall(cleaned):
        tokens.add(w.lower())
    tokens |= numeric_values(cleaned)
    return tokens


def anchor_recall(candidate: str, reference: str) -> float:
    """candidate 的锚点中，有多少出现在 reference 里；无锚点返回 0.0。"""
    cand = anchor_tokens(candidate)
    if not cand:
        return 0.0
    ref = anchor_tokens(reference)
    return len(cand & ref) / len(cand)


def has_anchors(text: str) -> bool:
    return bool(anchor_tokens(text))
