#!/usr/bin/env python3
"""
script/export_review_data.py - Export the single expert-review JSON (QAG-merged).

This is the PRIMARY review artifact, consumed by the Web UI expert panel.
It aggregates every quality signal (selfcheck / quality / paths / 8-dim judge)
plus PDF-located evidence and a 5-tier risk level into one JSON file:

  output/reports/{prefix}review_data.json

The Web panel renders this as a readable + fillable review table; the expert's
filled decisions are posted back as expert_feedback.json and applied by
apply_expert_feedback.py. No Excel round-trip.
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from review_core import build_rows, load_all_reports, load_questions, HAS_PYMUPDF  # noqa: E402

RISK_ORDER = ["CRITICAL", "HIGH", "MEDIUM", "LOW", "PASS"]


def main() -> None:
    parser = argparse.ArgumentParser(description="QAG-merged 导出专家审查 JSON")
    parser.add_argument("--input-dir", default="output")
    parser.add_argument("--report-dir", default="output/reports")
    parser.add_argument("--pdf-dir", default="extern_data")
    parser.add_argument("--report-prefix", default="")
    parser.add_argument("--out", default="", help="输出 JSON 路径（默认 {report_dir}/{prefix}review_data.json）")
    args = parser.parse_args()

    input_dir = Path(args.input_dir)
    report_dir = Path(args.report_dir)
    pdf_dir = Path(args.pdf_dir)
    report_dir.mkdir(parents=True, exist_ok=True)
    pfx = args.report_prefix
    out_path = Path(args.out) if args.out else report_dir / f"{pfx}review_data.json"

    print("[export_review_data] 加载题目 JSON ...")
    questions = load_questions(input_dir)
    if not questions:
        print("[export_review_data] 未找到题目 JSON", file=sys.stderr)
        sys.exit(1)

    quality_idx, path_idx, judge_idx, selfcheck_idx = load_all_reports(report_dir, pfx)
    if not HAS_PYMUPDF:
        print("[export_review_data] 警告: PyMuPDF 未安装，PDF 证据页码定位将跳过")

    print(f"[export_review_data] 聚合 {len(questions)} 题 ...")
    rows = build_rows(questions, quality_idx, path_idx, judge_idx, selfcheck_idx, pdf_dir)

    risk_counts = {r: sum(1 for x in rows if x["risk_level"] == r) for r in RISK_ORDER}
    payload = {
        "meta": {
            "generated_at": datetime.now().isoformat(),
            "total": len(rows),
            "risk_counts": risk_counts,
            "report_prefix": pfx,
            "decisions": ["accept", "revise", "rewrite", "downgrade", "reject", "regenerate"],
            "severities": ["CRITICAL", "HIGH", "MEDIUM", "LOW"],
        },
        "questions": rows,  # already sorted CRITICAL → PASS
    }

    out_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\n[export_review_data] DONE: {out_path}")
    print(f"  Total: {len(rows)} questions  " +
          "  ".join(f"{r}={risk_counts[r]}" for r in RISK_ORDER))


if __name__ == "__main__":
    main()
