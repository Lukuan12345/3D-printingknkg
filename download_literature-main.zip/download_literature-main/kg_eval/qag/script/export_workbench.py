#!/usr/bin/env python3
"""
script/export_workbench.py - Export the single expert review Excel workbench.

Aggregates all quality signals into one file:
  output/reports/expert_review_workbench.xlsx

Sheets:
  00_总览               - Summary dashboard
  01_专家审查主表        - Main review table (expert fills this)
  02_完整证据            - All evidence quotes per question
  03_风险解释            - Risk label dictionary
  04_填写说明            - Instructions for expert
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))
from review_core import (  # noqa: E402
    HAS_PYMUPDF, build_rows, compute_risk_level, find_evidence_in_pdf,
    index_report_by_id, is_pdf_name, load_questions, load_report,
)

try:
    import openpyxl
    from openpyxl.styles import (
        Alignment, Font, PatternFill, Border, Side, GradientFill
    )
    from openpyxl.utils import get_column_letter
    from openpyxl.worksheet.datavalidation import DataValidation
except ImportError:
    print("[export_workbench] 需要安装 openpyxl: pip install openpyxl", file=sys.stderr)
    sys.exit(1)

# ─── Constants ────────────────────────────────────────────────────────────────

# Color palettes (ARGB)
COLOR_RED = "FFFF4444"
COLOR_ORANGE = "FFFFAA00"
COLOR_YELLOW = "FFFFFF99"
COLOR_GREEN = "FF88CC44"
COLOR_BLUE_HEADER = "FF2C6FAC"
COLOR_LIGHT_BLUE = "FFD6E4F0"
COLOR_WHITE = "FFFFFFFF"
COLOR_GRAY = "FFD9D9D9"

RISK_COLORS: dict[str, str] = {
    "CRITICAL": COLOR_RED,
    "HIGH": COLOR_ORANGE,
    "MEDIUM": COLOR_YELLOW,
    "LOW": COLOR_GREEN,
    "PASS": "FF99DD77",
}

EXPERT_DECISIONS = ["accept", "revise", "rewrite", "downgrade", "reject", "regenerate"]


# ─── Excel styling helpers ────────────────────────────────────────────────────

def header_style(ws, row: int, cols: int, title: str, color: str = COLOR_BLUE_HEADER) -> None:
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=cols)
    cell = ws.cell(row=row, column=1)
    cell.value = title
    cell.font = Font(bold=True, color="FFFFFFFF", size=13)
    cell.fill = PatternFill("solid", fgColor=color)
    cell.alignment = Alignment(horizontal="center", vertical="center")


def set_header_row(ws, row: int, headers: list[str]) -> None:
    for col, h in enumerate(headers, 1):
        cell = ws.cell(row=row, column=col, value=h)
        cell.font = Font(bold=True, color="FFFFFFFF")
        cell.fill = PatternFill("solid", fgColor=COLOR_BLUE_HEADER)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)


def data_cell(ws, row: int, col: int, value: Any, wrap: bool = True, color: str = "") -> None:
    cell = ws.cell(row=row, column=col, value=value)
    cell.alignment = Alignment(vertical="top", wrap_text=wrap)
    if color:
        cell.fill = PatternFill("solid", fgColor=color)


def risk_fill(risk: str) -> str:
    return RISK_COLORS.get(risk, COLOR_WHITE)


def auto_col_width(ws, max_width: int = 50) -> None:
    for col in ws.columns:
        max_len = 0
        col_letter = get_column_letter(col[0].column)
        for cell in col:
            try:
                cell_len = len(str(cell.value or ""))
            except Exception:
                cell_len = 0
            max_len = max(max_len, cell_len)
        adjusted = min(max_len + 4, max_width)
        ws.column_dimensions[col_letter].width = adjusted


# ─── Sheet builders ───────────────────────────────────────────────────────────

def build_sheet_overview(ws, rows: list[dict], gen_time: str) -> None:
    """00_总览 sheet."""
    ws.freeze_panes = "A3"
    header_style(ws, 1, 4, "QAG-v2 专家审查包 — 总览", COLOR_BLUE_HEADER)

    total = len(rows)
    counts: dict[str, int] = {}
    for risk in ("CRITICAL", "HIGH", "MEDIUM", "LOW", "PASS"):
        counts[risk] = sum(1 for r in rows if r["risk_level"] == risk)

    def kv(ws, row, k, v, vc=""):
        cell_k = ws.cell(row=row, column=1, value=k)
        cell_k.font = Font(bold=True)
        cell_k.fill = PatternFill("solid", fgColor=COLOR_LIGHT_BLUE)
        cell_v = ws.cell(row=row, column=2, value=v)
        if vc:
            cell_v.fill = PatternFill("solid", fgColor=vc)

    kv(ws, 2, "生成时间", gen_time)
    kv(ws, 3, "题目总数", total)
    kv(ws, 4, "PASS", counts["PASS"], RISK_COLORS["PASS"])
    kv(ws, 5, "LOW", counts["LOW"], RISK_COLORS["LOW"])
    kv(ws, 6, "MEDIUM", counts["MEDIUM"], RISK_COLORS["MEDIUM"])
    kv(ws, 7, "HIGH", counts["HIGH"], RISK_COLORS["HIGH"])
    kv(ws, 8, "CRITICAL", counts["CRITICAL"], RISK_COLORS["CRITICAL"])

    need_review = [r["question_id"] for r in rows if r["risk_level"] in ("HIGH", "CRITICAL")]
    kv(ws, 9, "需重点审查题号", ", ".join(need_review) or "无")
    kv(ws, 10, "数值幻觉风险题数", sum(1 for r in rows if "NUMERIC_RISK" in r.get("risk_tags", [])))
    kv(ws, 11, "证据接地不足题数", sum(1 for r in rows if "LOW_EVIDENCE_GROUNDING" in r.get("risk_tags", [])))
    kv(ws, 12, "推理链警告题数", sum(1 for r in rows if r.get("path_warnings")))
    kv(ws, 13, "LLM Judge 未通过题数", sum(1 for r in rows if not r.get("judge_pass", True)))

    ws.column_dimensions["A"].width = 28
    ws.column_dimensions["B"].width = 80


def build_sheet_main(ws, rows: list[dict]) -> None:
    """01_专家审查主表 — the primary expert-facing sheet."""
    ws.freeze_panes = "A3"
    ws.auto_filter.ref = "A2:BZ2"

    headers = [
        # Basic info
        "question_id", "file_path", "difficulty_level", "hop_count", "domain",
        "intent", "source_mode", "risk_level", "must_review",
        # Question content
        "question", "answer", "key_points", "expected_path_nodes",
        "recommended_papers", "source_pdf_files",
        "pdf_quote_found", "pdf_not_found_evidence_ids",
        # Evidence
        "gold_evidence_summary", "evidence_ids",
        "evidence_quote_1", "evidence_source_1", "evidence_page_1",
        "evidence_quote_2", "evidence_source_2", "evidence_page_2",
        "evidence_quote_3", "evidence_source_3", "evidence_page_3",
        # Auto-detection
        "selfcheck_status", "selfcheck_issues",
        "evidence_grounding_score", "numeric_hallucination_count", "unsupported_numbers",
        "kp_quality_score", "kp_violations",
        "path_grounding_score", "path_warnings",
        "llm_judge_overall", "llm_judge_pass", "llm_judge_flags",
        "llm_judge_comments", "llm_judge_suggestions",
        "repair_priority", "expert_focus",
        # Expert columns (to fill)
        "expert_decision", "expert_severity", "expert_issue_types",
        "expert_instruction", "forbidden_claims", "required_evidence_ids",
        "remove_evidence_ids", "expert_revised_question", "expert_revised_answer",
        "expert_revised_key_points", "expert_notes", "expert_name", "review_time",
    ]

    header_style(ws, 1, len(headers), "01_专家审查主表 — 请在橙色列填写专家意见")
    set_header_row(ws, 2, headers)

    # Column indices (1-based) for expert fill columns
    expert_col_start = headers.index("expert_decision") + 1
    expert_col_end = len(headers)

    # DataValidation for expert_decision
    dv = DataValidation(
        type="list",
        formula1='"accept,revise,rewrite,downgrade,reject,regenerate"',
        allow_blank=True,
        showDropDown=False,
    )
    ws.add_data_validation(dv)

    for row_idx, r in enumerate(rows, 3):
        risk = r["risk_level"]
        row_color = risk_fill(risk)
        must_review = "YES" if risk in ("HIGH", "CRITICAL") else ""

        # Gather evidence items (up to 3 for inline display)
        ev_items = r.get("evidence_items") or []
        ev_ids = "; ".join(e.get("evidence_id", "") for e in ev_items)
        gold_summary = "; ".join(
            f"[{e.get('evidence_id','')}] {(e.get('text') or '')[:100]}" for e in ev_items[:3]
        )

        def ev_field(idx: int, field: str) -> str:
            if idx < len(ev_items):
                return str(ev_items[idx].get(field, "") or "")
            return ""

        values = [
            r["question_id"],
            r["file_path"],
            r["difficulty_level"],
            r["hop_count"],
            r["domain"],
            r["intent"],
            r["source_mode"],
            risk,
            must_review,
            # content
            r["question"],
            r["answer"],
            "\n".join(r.get("key_points") or []),
            "\n".join(r.get("expected_path_nodes") or []),
            "; ".join(r.get("recommended_papers") or []),
            "; ".join(r.get("source_pdf_files") or []),
            "YES" if r.get("pdf_quote_found") else "NO",
            "; ".join(r.get("pdf_not_found_evidence_ids") or []),
            # evidence
            gold_summary,
            ev_ids,
            ev_field(0, "text"),
            ev_field(0, "source_file"),
            str(ev_field(0, "page") or ""),
            ev_field(1, "text"),
            ev_field(1, "source_file"),
            str(ev_field(1, "page") or ""),
            ev_field(2, "text"),
            ev_field(2, "source_file"),
            str(ev_field(2, "page") or ""),
            # auto checks
            r.get("selfcheck_status", ""),
            "; ".join((r.get("selfcheck_issues") or []) + (r.get("selfcheck_warnings") or [])),
            r.get("evidence_grounding_score", ""),
            r.get("numeric_hallucination_count", ""),
            "; ".join(r.get("unsupported_numbers") or []),
            r.get("kp_quality_score", ""),
            "; ".join(r.get("kp_violations") or []),
            r.get("path_grounding_score", ""),
            "; ".join(r.get("path_warnings") or []),
            r.get("judge_overall", ""),
            "YES" if r.get("judge_pass") else "NO",
            "; ".join(r.get("judge_flags") or []),
            r.get("judge_comments", ""),
            "; ".join(r.get("judge_suggestions") or []),
            r.get("repair_priority", ""),
            "; ".join(r.get("expert_focus") or []),
            # expert fill - empty
            "", "", "", "", "", "", "", "", "", "", "", "", "",
        ]

        for col_idx, val in enumerate(values, 1):
            is_expert_col = col_idx >= expert_col_start
            cell_color = "FFFFF0D0" if is_expert_col else (row_color if col_idx == 8 else "")
            data_cell(ws, row_idx, col_idx, val, wrap=True, color=cell_color)

        # Add data validation to expert_decision column
        decision_col_letter = get_column_letter(expert_col_start)
        dv.add(f"{decision_col_letter}{row_idx}")

    # Set column widths
    narrow = 12
    medium = 25
    wide = 50
    for i, h in enumerate(headers, 1):
        ltr = get_column_letter(i)
        if h in ("question", "answer", "evidence_quote_1", "evidence_quote_2", "evidence_quote_3",
                 "gold_evidence_summary", "expert_instruction", "expert_revised_answer",
                 "expert_revised_question", "llm_judge_comments"):
            ws.column_dimensions[ltr].width = wide
        elif h in ("key_points", "expected_path_nodes", "kp_violations", "selfcheck_issues",
                   "llm_judge_suggestions", "expert_focus", "repair_hint"):
            ws.column_dimensions[ltr].width = medium
        else:
            ws.column_dimensions[ltr].width = narrow


def build_sheet_evidence(ws, rows: list[dict]) -> None:
    """02_完整证据 sheet."""
    ws.freeze_panes = "A3"
    headers = [
        "question_id", "evidence_id", "source_kind", "source_file",
        "source_uid", "page", "exact_quote", "surrounding_context",
        "pdf_found", "used_in_gold_evidence", "bound_path_node",
    ]
    header_style(ws, 1, len(headers), "02_完整证据")
    set_header_row(ws, 2, headers)

    row_idx = 3
    for r in rows:
        for ev in r.get("evidence_items_full") or []:
            values = [
                r["question_id"],
                ev.get("evidence_id", ""),
                ev.get("source_kind", ""),
                ev.get("source_file", ""),
                ev.get("source_uid", ""),
                str(ev.get("page", "") or ""),
                ev.get("text", ""),
                ev.get("surrounding_context", ""),
                "YES" if ev.get("pdf_found") else ("N/A" if ev.get("source_kind") != "external_pdf" else "NO"),
                "YES" if ev.get("used_in_gold") else "NO",
                ev.get("bound_node", ""),
            ]
            for col_idx, val in enumerate(values, 1):
                data_cell(ws, row_idx, col_idx, val)
            row_idx += 1

    for col, width in zip(["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K"],
                          [15, 12, 15, 25, 25, 8, 70, 80, 8, 8, 40]):
        ws.column_dimensions[col].width = width


def build_sheet_risk_dict(ws) -> None:
    """03_风险解释 sheet."""
    header_style(ws, 1, 3, "03_风险解释字典")
    set_header_row(ws, 2, ["风险标签", "含义", "专家建议"])
    entries = [
        ("NUMERIC_RISK", "答案中存在数值，未在证据原文中找到",
         "核对数值是否在 PDF 原文中出现；若无，删除或替换"),
        ("LOW_EVIDENCE_GROUNDING", "答案与证据文本相似度低于 60%",
         "检查答案是否基于 gold_evidence，避免凭印象作答"),
        ("EVIDENCE_RISK", "LLM Judge 认为答案与证据不完全匹配",
         "逐条核对 gold_evidence 与 answer 中的核心论断"),
        ("SOURCE_MISMATCH", "结论可能张冠李戴（属于 A 文献的结论误写入 B 文献）",
         "严格核查每条 gold_evidence 的 source_file 是否与答案对应"),
        ("UNANSWERABLE", "题目无法由给定证据确定性地回答",
         "修改题目，使其完全可由证据回答；或废弃"),
        ("SHALLOW_HOP", "实际推理深度低于 hop_count 要求",
         "降级（降低 L 级和 hop_count）或重写题目"),
        ("KP_RISK", "Key Points 含代词、连接词或多子句",
         "每个 KP 独立，主语明确，不含「它/该/因此」等"),
        ("LOW_PATH_NODE_GROUNDING", "推理链节点在证据文本中找不到支撑",
         "绑定节点到具体 evidence_id，或删除不支撑的节点"),
        ("NODE_COUNT_LT_HOP_PLUS_1", "expected_path_nodes 数量少于 hop_count+1",
         "补全节点或降低 hop_count"),
        ("MIXED_SOURCE_NOT_COVERED", "混合来源题未同时包含 internal_kb 和 external_pdf",
         "检查 gold_evidence 的 source_kind 是否同时覆盖两类来源"),
        ("DUPLICATE_RISK", "与其他题目问法高度相似",
         "改写题干方向或角度，确保题目多样性"),
        ("PDF_EXACT_QUOTE_NOT_FOUND", "PDF 原文中未找到该 evidence 的精确引文",
         "核实证据文本是否确实来自该 PDF；若有误，需纠正 source_file"),
    ]
    for row_idx, (tag, meaning, advice) in enumerate(entries, 3):
        ws.cell(row=row_idx, column=1, value=tag).font = Font(bold=True)
        ws.cell(row=row_idx, column=2, value=meaning)
        ws.cell(row=row_idx, column=3, value=advice)
    ws.column_dimensions["A"].width = 35
    ws.column_dimensions["B"].width = 50
    ws.column_dimensions["C"].width = 60


def build_sheet_instructions(ws) -> None:
    """04_填写说明 sheet."""
    header_style(ws, 1, 1, "04_专家填写说明")
    instructions = [
        "",
        "【操作步骤】",
        "1. 先看 00_总览 了解整体风险分布。",
        "2. 切换到 01_专家审查主表，用 risk_level 筛选 HIGH 和 CRITICAL。",
        "3. 优先逐题填写以下 4 列（必填）：",
        "   - expert_decision  （必填）",
        "   - expert_issue_types （如有问题）",
        "   - expert_instruction （如需修改）",
        "   - expert_name",
        "4. 其余列（forbidden_claims / required_evidence_ids / expert_revised_answer）按需填写。",
        "5. LOW/PASS 题可直接批量填 expert_decision = accept。",
        "6. 填完保存 Excel，发给开发者运行 apply_expert_feedback.py。",
        "",
        "【expert_decision 可选值】",
        "  accept      — 题目无问题，直接通过",
        "  revise      — 保留题目，按意见修改答案/KP/证据",
        "  rewrite     — 用同一批证据重写题目和答案",
        "  downgrade   — 降低难度等级和跳数",
        "  reject      — 废弃，移入 rejected/ 目录",
        "  regenerate  — 标记为需重新生成；当前版本不自动生成替代题，需手动处理",
        "",
        "【填写示例 1：数值幻觉】",
        "  expert_decision    = revise",
        "  expert_issue_types = NUMERIC_HALLUCINATION",
        "  expert_instruction = 删除答案中 8.2 GHz，该数值在证据中不存在；",
        "                       改为证据中实际出现的「约 7.6 GHz」。",
        "  forbidden_claims   = 8.2 GHz",
        "  required_evidence_ids = EV-001",
        "",
        "【填写示例 2：题目无法回答】",
        "  expert_decision    = rewrite",
        "  expert_instruction = 当前题目要求跨 3 篇文献整合，但证据只来自 1 篇，",
        "                       请重写为单文献可回答的 L2 题。",
        "",
        "【填写示例 3：降级】",
        "  expert_decision    = downgrade",
        "  expert_instruction = 降为 L2，只问证据中明确给出的结构-性能关系；",
        "                       去掉对比不同材料体系的要求。",
        "",
        "【注意事项】",
        "  - 修改后请务必填写 expert_name，以便追溯。",
        "  - 如果不确定，可在 expert_notes 写「待复核」，不要强行填 accept。",
        "  - 禁止在 evidence_quote 列手动修改引文，证据修改请通过 required/remove_evidence_ids。",
    ]
    for i, line in enumerate(instructions, 2):
        cell = ws.cell(row=i, column=1, value=line)
        if line.startswith("【"):
            cell.font = Font(bold=True)
    ws.column_dimensions["A"].width = 90
    for i in range(2, len(instructions) + 2):
        ws.row_dimensions[i].height = 18


# ─── Main ─────────────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(description="QAG-v2 导出专家唯一审查 Excel")
    parser.add_argument("--input-dir", default="output")
    parser.add_argument("--report-dir", default="output/reports")
    parser.add_argument("--pdf-dir", default="extern_data")
    parser.add_argument("--report-prefix", default="")
    parser.add_argument(
        "--out", default="output/reports/expert_review_workbench.xlsx",
        help="输出 Excel 文件路径"
    )
    args = parser.parse_args()

    input_dir = Path(args.input_dir)
    report_dir = Path(args.report_dir)
    pdf_dir = Path(args.pdf_dir)
    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    pfx = args.report_prefix

    print("[export_workbench] 加载题目 JSON ...")
    questions = load_questions(input_dir)
    if not questions:
        print("[export_workbench] 未找到题目 JSON", file=sys.stderr)
        sys.exit(1)

    print(f"[export_workbench] 加载质量报告 ...")
    quality_report = load_report(report_dir / f"{pfx}question_quality_metrics.json")
    path_report = load_report(report_dir / f"{pfx}reasoning_path_validation.json")
    judge_report = load_report(report_dir / f"{pfx}llm_judge_question_scores.json")
    selfcheck_report = load_report(report_dir / f"{pfx}selfcheck_results.json")

    quality_idx = index_report_by_id(quality_report)
    path_idx = index_report_by_id(path_report)
    judge_idx = index_report_by_id(judge_report)
    selfcheck_idx = index_report_by_id(selfcheck_report)

    if not HAS_PYMUPDF:
        print("[export_workbench] 警告: PyMuPDF 未安装，PDF 证据页码提取将跳过")

    print(f"[export_workbench] 构建 {len(questions)} 行数据 ...")
    gen_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    rows = build_rows(questions, quality_idx, path_idx, judge_idx, selfcheck_idx, pdf_dir)

    print(f"[export_workbench] 生成 Excel ...")
    wb = openpyxl.Workbook()

    # Create sheets
    ws_overview = wb.active
    ws_overview.title = "00_总览"
    ws_main = wb.create_sheet("01_专家审查主表")
    ws_evidence = wb.create_sheet("02_完整证据")
    ws_risk_dict = wb.create_sheet("03_风险解释")
    ws_instructions = wb.create_sheet("04_填写说明")

    build_sheet_overview(ws_overview, rows, gen_time)
    build_sheet_main(ws_main, rows)
    build_sheet_evidence(ws_evidence, rows)
    build_sheet_risk_dict(ws_risk_dict)
    build_sheet_instructions(ws_instructions)

    wb.save(str(out_path))

    risk_counts = {}
    for risk in ("CRITICAL", "HIGH", "MEDIUM", "LOW", "PASS"):
        risk_counts[risk] = sum(1 for r in rows if r["risk_level"] == risk)

    print(f"\n[export_workbench] DONE: {out_path}")
    print(f"  Total: {len(rows)} questions")
    for risk, count in risk_counts.items():
        print(f"  {risk}: {count}")


if __name__ == "__main__":
    main()
