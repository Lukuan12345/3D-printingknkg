#!/usr/bin/env python3
"""
script/validate_paths.py - Validate reasoning path node grounding in source materials.

Outputs:
  reasoning_path_validation.json  - Per-question path validation results
  path_validation_report.md       - Human-readable report
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from datetime import datetime
from pathlib import Path

import grounding_lang  # 跨语种锚点工具（同目录）

# ─── Constants ────────────────────────────────────────────────────────────────

SKIP_FILENAMES = {
    "generation_manifest.json", "question_quality_metrics.json",
    "reasoning_path_validation.json", "llm_judge_question_scores.json",
    "usable_ids.json", "usable_question_ids.json", "final_questions.json",
    "selfcheck_results.json", "llm_repair_log.json", "expert_feedback_apply_log.json",
}

NODE_GROUNDING_THRESHOLD = 0.45  # token-recall threshold for a node to be "grounded"
NODE_ANCHOR_THRESHOLD = 0.5      # 跨语种：锚点召回阈值（节点的技术锚点有半数被证据支持即接地）

# ─── Helpers ──────────────────────────────────────────────────────────────────

def load_questions(input_dir: Path) -> list[dict]:
    questions: list[dict] = []
    for jf in sorted(input_dir.rglob("*.json")):
        if jf.name in SKIP_FILENAMES or "reports" in jf.parts or "rejected" in jf.parts:
            continue
        try:
            data = json.loads(jf.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            continue
        if isinstance(data, dict) and "id" in data:
            data["_file_path"] = str(jf)
            questions.append(data)
        elif isinstance(data, list):
            continue  # QAG-v2 requires one-question-per-file
    return questions


def tokenize(text: str) -> set[str]:
    tokens: set[str] = set()
    for ch in re.findall(r"[一-鿿]", text):
        tokens.add(ch)
    for word in re.findall(r"[a-zA-Z0-9]+", text.lower()):
        if len(word) >= 2:
            tokens.add(word)
    return tokens


def jaccard(a: str, b: str) -> float:
    ta, tb = tokenize(a), tokenize(b)
    if not ta or not tb:
        return 0.0
    return len(ta & tb) / len(ta | tb)


def token_recall(candidate: str, reference: str) -> float:
    """Fraction of candidate tokens found in reference. Better than Jaccard for short nodes vs long texts."""
    cand = tokenize(candidate)
    ref = tokenize(reference)
    if not cand:
        return 0.0
    return len(cand & ref) / len(cand)


def best_match_score(node: str, text: str) -> float:
    """Substring check first (exact), then token recall."""
    if not node or not text:
        return 0.0
    if node.strip() in text:
        return 1.0
    return token_recall(node, text)


def get_all_source_texts(q: dict) -> list[tuple[str, str]]:
    """Return list of (source_kind, text) pairs from all available sources."""
    pairs: list[tuple[str, str]] = []
    for ev in q.get("gold_evidence") or []:
        t = ev.get("text") or ""
        kind = ev.get("source_kind") or "unknown"
        if t:
            pairs.append((kind, t))
    meta = q.get("annotation_meta") or {}
    for card in meta.get("evidence_cards") or []:
        t = card.get("text") or card.get("content") or ""
        kind = card.get("source_kind") or "unknown"
        if t:
            pairs.append((kind, t))
    return pairs


def check_mixed_coverage(source_pairs: list[tuple[str, str]]) -> bool:
    """Return True if both internal_kb and external_pdf are present."""
    kinds = {k for k, _ in source_pairs}
    return "internal_kb" in kinds and "external_pdf" in kinds


# ─── Per-question validation ───────────────────────────────────────────────────

def validate_question(q: dict) -> dict:
    qid = q.get("id", "UNKNOWN")
    nodes = q.get("expected_path_nodes") or []
    hop = q.get("hop_count") or 0
    source_mode = (q.get("annotation_meta") or {}).get("source_mode") or q.get("source_mode") or ""
    source_pairs = get_all_source_texts(q)
    combined_source = " ".join(t for _, t in source_pairs)

    warnings: list[str] = []
    repair_hint: list[str] = []
    node_results: list[dict] = []

    # Check node count
    if not nodes:
        warnings.append("NO_PATH_NODES")
        repair_hint.append("expected_path_nodes 为空，无法验证推理链，建议补全节点")
    else:
        if len(nodes) < hop + 1:
            warnings.append("NODE_COUNT_LT_HOP_PLUS_1")
            repair_hint.append(
                f"节点数量({len(nodes)}) < hop_count+1({hop+1})，建议补充节点或降低 hop_count"
            )

    # Check each node grounding
    #
    # 跨语种（中文节点 vs 英文证据）时，子串/逐字符 token_recall 永远不达阈值 → 全部误判
    # 未接地、path_score 恒为 0。改为：跨语种且节点含可对齐锚点 → 用锚点召回 + 锚点阈值判定；
    # 跨语种且节点**无锚点**（纯概念短标签，如「两类设计的功能演化对比」）→ 标记 groundable=False，
    # 从分母剔除（既不算接地也不算未接地）；同语种 → 保留原 best_match_score。
    ungrounded_nodes: list[str] = []
    cross = grounding_lang.is_latin_dominant(combined_source) if combined_source else False
    for node in nodes:
        node_cross = cross and grounding_lang.is_cjk_dominant(node)
        if node_cross and not grounding_lang.has_anchors(node):
            # 无可对齐锚点：本词法方法无法判定，排除出评分（不计入分母）
            node_results.append({
                "node": node,
                "best_similarity": None,
                "best_source_kind": "",
                "grounded": None,
                "groundable": False,
            })
            continue

        best_sim = 0.0
        best_src = ""
        threshold = NODE_ANCHOR_THRESHOLD if node_cross else NODE_GROUNDING_THRESHOLD
        for kind, text in source_pairs:
            sim = grounding_lang.anchor_recall(node, text) if node_cross else best_match_score(node, text)
            if sim > best_sim:
                best_sim = sim
                best_src = kind
        grounded = best_sim >= threshold
        node_results.append({
            "node": node,
            "best_similarity": round(best_sim, 4),
            "best_source_kind": best_src,
            "grounded": grounded,
            "groundable": True,
        })
        if not grounded:
            ungrounded_nodes.append(node)

    if ungrounded_nodes:
        warnings.append("LOW_PATH_NODE_GROUNDING")
        for n in ungrounded_nodes[:3]:
            repair_hint.append(
                f"节点 '{n[:40]}' 未在证据文本中找到匹配（阈值{NODE_GROUNDING_THRESHOLD}），"
                "建议绑定到具体 evidence_id 或删除该节点"
            )

    # Check mixed source coverage
    if "mixed" in source_mode:
        if not check_mixed_coverage(source_pairs):
            warnings.append("MIXED_SOURCE_NOT_COVERED")
            repair_hint.append("混合来源题未同时包含 internal_kb 和 external_pdf 证据")

    # path_grounding_score: fraction of grounded nodes among *groundable* ones.
    # 跨语种下无锚点的纯概念节点(groundable=False)不计入分母，避免被结构性判 0。
    gradable = [nr for nr in node_results if nr.get("groundable", True)]
    if gradable:
        grounded_count = sum(1 for nr in gradable if nr["grounded"])
        path_score = round(grounded_count / len(gradable), 4)
    else:
        path_score = 0.0

    # Check path_node_evidence binding
    path_node_evidence = q.get("path_node_evidence") or []
    bound_nodes = {pne.get("node") for pne in path_node_evidence if pne.get("node")}
    unbound = [n for n in nodes if n not in bound_nodes]
    if unbound and hop >= 3:
        warnings.append("PATH_NODE_EVIDENCE_UNBOUND")
        for n in unbound[:2]:
            repair_hint.append(f"节点 '{n[:40]}' 未绑定 evidence_id（H3/H4 必须绑定）")

    return {
        "id": qid,
        "file_path": q.get("_file_path", ""),
        "difficulty_level": q.get("difficulty_level", ""),
        "hop_count": hop,
        "source_mode": source_mode,
        "path_grounding_score": path_score,
        "node_results": node_results,
        "warnings": warnings,
        "repair_hint": repair_hint,
    }


# ─── Report ───────────────────────────────────────────────────────────────────

def build_markdown(results: list[dict]) -> str:
    lines = [
        "# 推理链验证报告 (QAG-v2)",
        f"> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        "",
        "## 汇总",
    ]
    warn_types: dict[str, int] = {}
    for r in results:
        for w in r["warnings"]:
            warn_types[w] = warn_types.get(w, 0) + 1
    lines.append(f"- 题目总数: {len(results)}")
    for wtype, count in sorted(warn_types.items()):
        lines.append(f"- {wtype}: {count} 题")
    lines.append("")
    lines.append("## 明细")
    for r in results:
        icon = "✅" if not r["warnings"] else "⚠️"
        lines.append(f"\n### {icon} {r['id']} [path_score={r['path_grounding_score']}]")
        lines.append(f"- 难度: {r['difficulty_level']}  跳数: {r['hop_count']}  模式: {r['source_mode']}")
        if r["warnings"]:
            lines.append(f"- 警告: {', '.join(r['warnings'])}")
        for hint in r["repair_hint"]:
            lines.append(f"  - ⚠️ {hint}")
        for nr in r["node_results"]:
            if nr.get("groundable", True) is False:
                lines.append(f"  - ➖ 节点(无可对齐锚点,不计分): {nr['node'][:50]}")
                continue
            g = "✅" if nr["grounded"] else "❌"
            lines.append(f"  - {g} 节点: {nr['node'][:50]}  sim={nr['best_similarity']}")
    return "\n".join(lines)


# ─── Main ─────────────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(description="QAG-v2 推理链验证")
    parser.add_argument("--input-dir", default="output")
    parser.add_argument("--report-dir", default="output/reports")
    parser.add_argument("--report-prefix", default="")
    args = parser.parse_args()

    input_dir = Path(args.input_dir)
    report_dir = Path(args.report_dir)
    report_dir.mkdir(parents=True, exist_ok=True)
    pfx = args.report_prefix

    questions = load_questions(input_dir)
    if not questions:
        print("[validate_paths] 未找到题目 JSON", file=sys.stderr)
        sys.exit(1)

    results = [validate_question(q) for q in questions]

    summary: dict[str, int] = {"total": len(results)}
    for wtype in ("NO_PATH_NODES", "NODE_COUNT_LT_HOP_PLUS_1", "LOW_PATH_NODE_GROUNDING",
                  "MIXED_SOURCE_NOT_COVERED", "PATH_NODE_EVIDENCE_UNBOUND"):
        summary[wtype.lower()] = sum(1 for r in results if wtype in r["warnings"])

    out_json = report_dir / f"{pfx}reasoning_path_validation.json"
    out_json.write_text(
        json.dumps({"summary": summary, "questions": results}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    out_md = report_dir / f"{pfx}path_validation_report.md"
    out_md.write_text(build_markdown(results), encoding="utf-8")

    print(f"[validate_paths] {len(results)} 题验证完成 → {out_json}")


if __name__ == "__main__":
    main()
