#!/usr/bin/env python3
"""
script/apply_expert_feedback.py - Apply expert review decisions to question JSON.

Primary input (QAG-merged): a feedback JSON posted by the Web expert panel
(--feedback). An Excel workbench (--workbook) is still accepted as a fallback.

Per question, by expert_decision:
  - accept     → marks question as reviewed (no content change)
  - reject     → moves JSON to output/rejected/
  - revise     → calls LLM to minimally revise per expert instruction
  - rewrite    → calls LLM to rewrite using same evidence cards
  - downgrade  → calls LLM to lower difficulty, then rewrites
  - regenerate → marks for regeneration (manual step)

Outputs:
  expert_feedback_apply_log.json   - Detailed log per question
"""
from __future__ import annotations

import argparse
import copy
import json
import os
import re
import shutil
import sys
import time
from datetime import datetime
from pathlib import Path

from openai import OpenAI

# ─── Configuration ────────────────────────────────────────────────────────────

LLM_BASE_URL = os.getenv("QAG_LLM_BASE_URL", "http://43.153.42.7:3001/v1")
API_KEY = os.getenv("QAG_API_KEY") or os.getenv("OPENAI_API_KEY", "sk-placeholder")
DEFAULT_MODEL = os.getenv("QAG_LLM_MODEL", "gpt5.5")

SKIP_FILENAMES = {
    "generation_manifest.json", "question_quality_metrics.json",
    "reasoning_path_validation.json", "llm_judge_question_scores.json",
    "usable_ids.json", "usable_question_ids.json", "final_questions.json",
    "selfcheck_results.json", "llm_repair_log.json", "expert_feedback_apply_log.json",
}

RETRY_TIMES = 2
RETRY_DELAY = 2

ALLOWED_DECISIONS = {"accept", "revise", "rewrite", "downgrade", "reject", "regenerate"}

# Fields the LLM is allowed to modify
MODIFIABLE_FIELDS = {
    "question", "difficulty_level", "difficulty_name", "hop_count", "question_type",
    "intent", "expected_path_nodes", "path_node_evidence", "reasoning_chain",
    "expected_key_relations", "gold_evidence", "ground_truth",
}

# Fields that must never change
IMMUTABLE_FIELDS = {"id", "task_type"}

# ─── Helpers ──────────────────────────────────────────────────────────────────

def load_questions(input_dir: Path) -> dict[str, dict]:
    questions: dict[str, dict] = {}
    for jf in sorted(input_dir.rglob("*.json")):
        if jf.name in SKIP_FILENAMES or "reports" in jf.parts or "rejected" in jf.parts:
            continue
        try:
            data = json.loads(jf.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            continue
        if isinstance(data, dict) and "id" in data:
            data["_file_path"] = str(jf)
            questions[data["id"]] = data
        elif isinstance(data, list):
            continue  # Skip list files: save_question writes single dict and would corrupt multi-question files
    return questions


def extract_json(text: str) -> dict:
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    m = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.DOTALL)
    if m:
        try:
            return json.loads(m.group(1))
        except json.JSONDecodeError:
            pass
    m2 = re.search(r"\{.*\}", text, re.DOTALL)
    if m2:
        try:
            return json.loads(m2.group(0))
        except json.JSONDecodeError:
            pass
    raise ValueError(f"Cannot extract JSON:\n{text[:300]}")


def str_or_empty(val) -> str:
    if val is None:
        return ""
    return str(val).strip()


def split_multi_value(text: str) -> list[str]:
    """Split a delimited string supporting ; ; , , and newlines (expert may use Chinese punctuation)."""
    return [x.strip() for x in re.split(r"[;；,，\n]+", text or "") if x.strip()]


# 句首连接词：拆分得分点时从句首剥离，避免触发 check_quality 的 KP_CONNECTOR 格式扣分。
_KP_LEAD_CONNECTOR_RE = re.compile(
    r"^(因此|所以|从而|由此|故|因而|并且|而且|另外|此外|同时|然而|不过|尽管|虽然|且|并|但)[，,、:：\s]*"
)


def split_answer_into_key_points(answer: str) -> list[str]:
    """把专家填写的完整答案确定性地拆成得分点（key_points）。

    规则：按句末标点 [。！？；!?;] 及换行切句；剥离句首连接词与残留标点；保留内联
    [EV-xxx] 引用；丢弃空串/过短碎片。纯确定性、无 LLM、无幻觉，结果可预测。
    """
    if not answer or not answer.strip():
        return []
    # 在句末标点后插入分隔符再切分（保留标点本身不必要，这里直接切）
    pieces = re.split(r"[。！？；!?;\n]+", answer)
    points: list[str] = []
    for p in pieces:
        s = p.strip()
        if not s:
            continue
        s = _KP_LEAD_CONNECTOR_RE.sub("", s).strip()
        s = s.lstrip("，,、:：;； ").strip()
        # 过短碎片（去掉引用标记后仍 <4 字）视为噪声丢弃
        bare = re.sub(r"\[?EV-\d+\]?", "", s).strip()
        if len(bare) < 4:
            continue
        points.append(s)
    return points


def as_list(val) -> list[str]:
    """Accept either a JSON list or a delimited string; return clean list of strings."""
    if isinstance(val, list):
        return [str(x).strip() for x in val if str(x).strip()]
    return split_multi_value(str_or_empty(val))


def normalize_feedback(raw: dict) -> dict:
    """Normalize one feedback record (from JSON or Excel row) into a uniform dict.

    Accepts both web-panel JSON (clean keys, list values) and Excel rows
    (expert_* prefixed keys, delimited-string values).
    """
    def pick(*keys: str):
        for k in keys:
            if k in raw and raw[k] not in (None, ""):
                return raw[k]
        return ""

    return {
        "question_id": str_or_empty(pick("question_id", "id")),
        "decision": str_or_empty(pick("decision", "expert_decision")).lower(),
        "severity": str_or_empty(pick("severity", "expert_severity")),
        "issue_types": as_list(pick("issue_types", "expert_issue_types")),
        "instruction": str_or_empty(pick("instruction", "expert_instruction")),
        "forbidden_claims": as_list(pick("forbidden_claims")),
        "required_evidence_ids": as_list(pick("required_evidence_ids")),
        "remove_evidence_ids": as_list(pick("remove_evidence_ids")),
        "expert_revised_question": str_or_empty(pick("expert_revised_question")),
        "expert_revised_answer": str_or_empty(pick("expert_revised_answer")),
        "expert_revised_key_points": as_list(pick("expert_revised_key_points")),
        "notes": str_or_empty(pick("notes", "expert_notes")),
        "expert_name": str_or_empty(pick("expert_name")),
        "review_time": str_or_empty(pick("review_time")) or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }


# ─── Feedback loading: JSON (primary) and Excel (fallback) ────────────────────

def parse_feedback_json(feedback_path: Path) -> list[dict]:
    """Load the Web panel's feedback JSON.

    Accepts either a top-level list, or {"feedback": [...]}, or {"questions": [...]}.
    """
    data = json.loads(feedback_path.read_text(encoding="utf-8"))
    if isinstance(data, dict):
        items = data.get("feedback") or data.get("questions") or []
    elif isinstance(data, list):
        items = data
    else:
        items = []
    return [normalize_feedback(x) for x in items if isinstance(x, dict)]


def parse_workbook(workbook_path: Path) -> list[dict]:
    """Parse Sheet '01_专家审查主表' from the Excel workbench (fallback path)."""
    try:
        import openpyxl
    except ImportError:
        print("[apply_expert_feedback] 读取 Excel 需要 openpyxl: pip install openpyxl", file=sys.stderr)
        sys.exit(1)

    wb = openpyxl.load_workbook(str(workbook_path), data_only=True)
    if "01_专家审查主表" not in wb.sheetnames:
        print(f"[apply_expert_feedback] 未找到 sheet '01_专家审查主表'", file=sys.stderr)
        return []

    ws = wb["01_专家审查主表"]
    headers: list[str] = []
    rows: list[dict] = []
    for row_idx, row in enumerate(ws.iter_rows(values_only=True)):
        if row_idx == 0:
            continue  # Title row
        if row_idx == 1:
            headers = [str_or_empty(c) for c in row]
            continue
        if not any(row):
            continue
        row_dict: dict = {}
        for col_idx, val in enumerate(row):
            if col_idx < len(headers):
                row_dict[headers[col_idx]] = str_or_empty(val)
        rows.append(normalize_feedback(row_dict))
    return rows


# ─── LLM apply prompts ────────────────────────────────────────────────────────

APPLY_PROMPT = """你是 QAG 题目修改执行器，根据专家审查意见对题目 JSON 进行精确修改。

## 原始题目 JSON
{question_json}

## 可用证据卡片（修改必须限于此范围）
{evidence_cards_json}

## 专家决策
{decision}

## 专家修改指令
{instruction}

## 禁止保留的表述
{forbidden_claims}

## 必须使用的 evidence_id
{required_evidence_ids}

## 必须删除的 evidence_id
{remove_evidence_ids}

## 专家预填的修订内容（如有，优先采用）
- 修订题干: {expert_revised_question}
- 修订答案: {expert_revised_answer}
- 修订 Key Points: {expert_revised_key_points}

## 执行规则（严格遵守）
1. 不允许引入 evidence_cards 之外的证据。
2. 不允许编造数值、作者、年份、性能指标。
3. 禁止保留的表述必须从 question/answer/key_points 中完全移除。
4. 必须使用的 evidence_id 必须保留在 gold_evidence 中。
5. 必须删除的 evidence_id 必须从 gold_evidence 中移除。
6. 如果专家提供了修订内容，直接使用，不要二次创作。
7. 保留原始 id，不允许修改。
8. 在 annotation_meta.expert_review 中写入审查记录。
9. 输出完整 JSON，不输出解释。

## 可修改字段
question, difficulty_level, difficulty_name, hop_count, question_type, intent,
expected_path_nodes, path_node_evidence, reasoning_chain, expected_key_relations,
gold_evidence, ground_truth.answer, ground_truth.key_points

## 禁止修改字段
id, annotation_meta.source_paper_uids, annotation_meta.source_file_names,
annotation_meta.evidence_cards（除非专家明确要求）"""


def build_apply_prompt(q: dict, feedback: dict) -> str:
    meta = q.get("annotation_meta") or {}
    evidence_cards = meta.get("evidence_cards") or []
    q_clean = {k: v for k, v in q.items() if not k.startswith("_")}

    return APPLY_PROMPT.format(
        question_json=json.dumps(q_clean, ensure_ascii=False, indent=2),
        evidence_cards_json=json.dumps(evidence_cards, ensure_ascii=False, indent=2),
        decision=feedback["decision"],
        instruction=feedback["instruction"] or "(无具体指令)",
        forbidden_claims="; ".join(feedback["forbidden_claims"]) or "无",
        required_evidence_ids="; ".join(feedback["required_evidence_ids"]) or "无",
        remove_evidence_ids="; ".join(feedback["remove_evidence_ids"]) or "无",
        expert_revised_question=feedback["expert_revised_question"] or "无",
        expert_revised_answer=feedback["expert_revised_answer"] or "无",
        expert_revised_key_points="\n".join(feedback["expert_revised_key_points"]) or "无",
    )


def _chat_with_fallback(client, model: str, **kwargs):
    """model 可为 'm1,m2,m3' 有序链；逐个尝试，抛错则降级到下一个模型。

    除 API 异常外，输出被 max_tokens 截断（finish_reason=='length'）也视为失败并降级——
    截断的 JSON 必然解析失败，换个不那么啰嗦的模型往往能完整输出。
    """
    chain = [m.strip() for m in str(model).split(",") if m.strip()] or [model]
    last_exc = None
    for m in chain:
        try:
            resp = client.chat.completions.create(model=m, **kwargs)
            fr = resp.choices[0].finish_reason if resp.choices else None
            if fr == "length":
                raise RuntimeError(f"输出被截断 (finish_reason=length)，疑似 max_tokens 不足")
            return resp
        except Exception as e:  # 模型不可用 / 鉴权 / 限流 / 超时 / 截断 → 降级
            last_exc = e
            print(f"  [FALLBACK] 模型 {m} 调用失败：{e}，尝试下一个", flush=True)
    raise last_exc


def call_llm_apply(client: OpenAI, prompt: str, model: str) -> dict:
    for attempt in range(RETRY_TIMES + 1):
        try:
            resp = _chat_with_fallback(
                client,
                model,
                messages=[
                    {"role": "system", "content": "你只输出一个合法 JSON 对象，不要 Markdown 围栏，不要任何解释文字。保持精简，避免冗长导致输出被截断。"},
                    {"role": "user", "content": prompt},
                ],
                temperature=0.1,
                max_tokens=8192,
            )
            raw = resp.choices[0].message.content or ""
            return extract_json(raw)
        except Exception as exc:
            if attempt < RETRY_TIMES:
                time.sleep(RETRY_DELAY)
            else:
                raise RuntimeError(f"LLM 调用失败: {exc}") from exc


def detect_changed_fields(original: dict, modified: dict) -> list[str]:
    changed: list[str] = []
    for field in MODIFIABLE_FIELDS:
        if field == "ground_truth":
            orig_gt = original.get("ground_truth") or {}
            mod_gt = modified.get("ground_truth") or {}
            for sub in ("answer", "key_points"):
                if orig_gt.get(sub) != mod_gt.get(sub):
                    changed.append(f"ground_truth.{sub}")
        else:
            if original.get(field) != modified.get(field):
                changed.append(field)
    return changed


def validate_immutable(original: dict, modified: dict) -> list[str]:
    violations: list[str] = []
    for field in IMMUTABLE_FIELDS:
        if original.get(field) != modified.get(field):
            violations.append(f"{field} 被修改（禁止）")
    return violations


def preserve_source_meta(original: dict, modified: dict) -> None:
    """Force-restore immutable source metadata the LLM must not change."""
    orig_meta = original.get("annotation_meta") or {}
    mod_meta = modified.setdefault("annotation_meta", {})
    for key in ("source_paper_uids", "source_file_names", "evidence_cards", "source_mode"):
        if key in orig_meta:
            mod_meta[key] = orig_meta[key]


def validate_expert_constraints(modified: dict, feedback: dict) -> list[str]:
    """Verify LLM honored expert's forbidden/required/remove_evidence_ids constraints."""
    violations: list[str] = []
    text_blob = json.dumps(
        {
            "question": modified.get("question", ""),
            "ground_truth": modified.get("ground_truth") or {},
            "expected_path_nodes": modified.get("expected_path_nodes") or [],
        },
        ensure_ascii=False,
    )
    for claim in feedback.get("forbidden_claims") or []:
        if claim and claim in text_blob:
            violations.append(f"forbidden_claim still present: {claim!r}")
    gold_ids = {
        str(ev.get("evidence_id", "")).strip()
        for ev in (modified.get("gold_evidence") or [])
        if isinstance(ev, dict)
    }
    for eid in feedback.get("required_evidence_ids") or []:
        if eid and eid not in gold_ids:
            violations.append(f"required_evidence_id missing from gold_evidence: {eid}")
    for eid in feedback.get("remove_evidence_ids") or []:
        if eid and eid in gold_ids:
            violations.append(f"remove_evidence_id still in gold_evidence: {eid}")
    return violations


def merge_expert_review(modified: dict, feedback: dict, model: str, changed_fields: list[str]) -> None:
    meta = modified.setdefault("annotation_meta", {})
    meta["expert_review"] = {
        "decision": feedback["decision"],
        "severity": feedback["severity"],
        "issue_types": feedback["issue_types"],
        "expert_instruction": feedback["instruction"],
        "expert_name": feedback["expert_name"],
        "review_time": feedback["review_time"],
        "applied_by_model": model,
        "apply_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "changed_fields": changed_fields,
    }


def save_question(q: dict) -> None:
    fp = q.get("_file_path")
    if not fp:
        return
    clean = {k: v for k, v in q.items() if not k.startswith("_")}
    Path(fp).write_text(json.dumps(clean, ensure_ascii=False, indent=2), encoding="utf-8")


def reject_question(q: dict, rejected_dir: Path) -> str:
    fp = q.get("_file_path")
    if not fp:
        return ""
    src = Path(fp)
    rejected_dir.mkdir(parents=True, exist_ok=True)
    dst = rejected_dir / src.name
    # Avoid overwriting if name collision
    if dst.exists():
        stem = dst.stem
        dst = dst.with_stem(f"{stem}_{q.get('id', 'unk')}")
    shutil.move(str(src), str(dst))
    return str(dst)


# ─── Main ─────────────────────────────────────────────────────────────────────

def main() -> None:
    # Windows 控制台/管道默认 gbk，会让含 emoji 的 print 崩溃（UnicodeEncodeError）。
    # 统一切到 utf-8，避免 fast-path 打印 ✅ 时非零退出导致接口误报失败。
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    parser = argparse.ArgumentParser(description="QAG-merged 专家反馈应用")
    parser.add_argument("--input-dir", default="output")
    parser.add_argument("--feedback", default="",
                        help="Web 专家面板导出的反馈 JSON 路径（主路径）")
    parser.add_argument("--workbook", default="",
                        help="专家填写后的 Excel 路径（回退路径；需 openpyxl）")
    parser.add_argument("--report-dir", default="output/reports")
    parser.add_argument("--model", default=DEFAULT_MODEL)
    parser.add_argument("--apply", action="store_true", help="实际写回 JSON（否则只模拟）")
    parser.add_argument("--api-key", default="")
    parser.add_argument("--base-url", default="")
    parser.add_argument("--single-reject", default="",
                        help="快速单条 reject：直接移动题到 rejected/ 并从 review_data.json 删除，"
                             "不调 LLM 不跑 review。用法：--single-reject <question_id>")
    parser.add_argument("--single-accept", default="",
                        help="快速单条 accept：题留在题库、记入 usable_ids.json，并从 review_data.json 删除，"
                             "不调 LLM 不跑 review。用法：--single-accept <question_id>")
    args = parser.parse_args()

    input_dir = Path(args.input_dir)
    report_dir = Path(args.report_dir)
    rejected_dir = input_dir / "rejected"
    report_dir.mkdir(parents=True, exist_ok=True)

    api_key = args.api_key or API_KEY
    base_url = args.base_url or LLM_BASE_URL
    client = OpenAI(api_key=api_key, base_url=base_url)

    # ─── Fast path: --single-reject <qid> ─────────────────────────────────
    # 跳过 LLM、跳过完整 review，直接移动题 + 删 review_data.json 中这条。
    # 用于 Web 专家面板"单条 reject 即时反馈"场景。
    if args.single_reject:
        qid = args.single_reject
        print(f"[apply_expert_feedback] fast-path: 单条 reject {qid}")
        questions = load_questions(input_dir)
        q = questions.get(qid)
        if q is None:
            print(f"  ❌ 题目未找到: {qid}", file=sys.stderr)
            sys.exit(2)
        rejected_dir = input_dir / "rejected"
        if args.apply:
            dst = reject_question(q, rejected_dir)
        else:
            dst = f"(dry-run) → {rejected_dir / Path(q.get('_file_path', 'unknown')).name}"
        # 从 review_data.json 删除该题
        rd_path = report_dir / "review_data.json"
        removed_from_review = False
        if rd_path.exists():
            try:
                rd = json.loads(rd_path.read_text(encoding="utf-8"))
                before = len(rd.get("questions") or [])
                rd["questions"] = [x for x in (rd.get("questions") or []) if x.get("question_id") != qid]
                removed_from_review = len(rd["questions"]) < before
                # 同步更新 risk_counts
                if "meta" in rd and "risk_counts" in rd["meta"]:
                    from collections import Counter
                    rd["meta"]["risk_counts"] = dict(Counter(q.get("risk_level", "?") for q in rd["questions"]))
                    rd["meta"]["total"] = len(rd["questions"])
                rd_path.write_text(json.dumps(rd, ensure_ascii=False, indent=2), encoding="utf-8")
            except Exception as exc:
                print(f"  ⚠️  review_data.json 更新失败: {exc}", file=sys.stderr)
        print(f"  ✅ moved → {dst}")
        print(f"  ✅ review_data.json: {'已删除该条' if removed_from_review else '无需更新'}")
        sys.exit(0)

    # ─── Fast path: --single-accept <qid> ─────────────────────────────────
    # 跳过 LLM、跳过完整 review：题留在题库（不移动文件），记入 usable_ids.json，
    # 并从 review_data.json 删除该条。用于 Web 专家面板"单条 pass 即时接受"场景。
    if args.single_accept:
        qid = args.single_accept
        print(f"[apply_expert_feedback] fast-path: 单条 accept(pass) {qid}")
        questions = load_questions(input_dir)
        q = questions.get(qid)
        if q is None:
            print(f"  ❌ 题目未找到: {qid}", file=sys.stderr)
            sys.exit(2)
        # 记入 expert_accepted_ids.json（专家手动接受池），去重。
        # 注意：不用 usable_ids.json——那是自动审核导出步骤写的（自动通过≠专家接受），
        # 且会被重新审核覆盖。用独立文件保证「已接受」只反映专家显式点的 pass。
        added_to_usable = False
        if args.apply:
            usable_path = report_dir / "expert_accepted_ids.json"
            try:
                usable = json.loads(usable_path.read_text(encoding="utf-8")) if usable_path.exists() else []
                if not isinstance(usable, list):
                    usable = []
            except (json.JSONDecodeError, OSError):
                usable = []
            if qid not in usable:
                usable.append(qid)
                added_to_usable = True
            usable_path.write_text(json.dumps(usable, ensure_ascii=False, indent=2), encoding="utf-8")
        # 从 review_data.json 删除该题
        rd_path = report_dir / "review_data.json"
        removed_from_review = False
        if rd_path.exists():
            try:
                rd = json.loads(rd_path.read_text(encoding="utf-8"))
                before = len(rd.get("questions") or [])
                rd["questions"] = [x for x in (rd.get("questions") or []) if x.get("question_id") != qid]
                removed_from_review = len(rd["questions"]) < before
                if "meta" in rd and "risk_counts" in rd["meta"]:
                    from collections import Counter
                    rd["meta"]["risk_counts"] = dict(Counter(x.get("risk_level", "?") for x in rd["questions"]))
                    rd["meta"]["total"] = len(rd["questions"])
                rd_path.write_text(json.dumps(rd, ensure_ascii=False, indent=2), encoding="utf-8")
            except Exception as exc:
                print(f"  ⚠️  review_data.json 更新失败: {exc}", file=sys.stderr)
        print(f"  ✅ expert_accepted_ids.json: {'已加入' if added_to_usable else '已存在/dry-run'}")
        print(f"  ✅ review_data.json: {'已删除该条' if removed_from_review else '无需更新'}")
        print(f"  ✅ 题目保留在题库（未移动文件）")
        sys.exit(0)

    print(f"[apply_expert_feedback] 加载题目 JSON ...")
    questions = load_questions(input_dir)

    # Load feedback: JSON (primary) or Excel (fallback)
    if args.feedback:
        fb_path = Path(args.feedback)
        if not fb_path.exists():
            print(f"[apply_expert_feedback] 找不到反馈 JSON: {fb_path}", file=sys.stderr)
            sys.exit(1)
        print(f"[apply_expert_feedback] 解析反馈 JSON: {fb_path}")
        feedback_items = parse_feedback_json(fb_path)
    elif args.workbook:
        wb_path = Path(args.workbook)
        if not wb_path.exists():
            print(f"[apply_expert_feedback] 找不到 workbook: {wb_path}", file=sys.stderr)
            sys.exit(1)
        print(f"[apply_expert_feedback] 解析 Excel: {wb_path}")
        feedback_items = parse_workbook(wb_path)
    else:
        print("[apply_expert_feedback] 必须提供 --feedback (JSON) 或 --workbook (Excel)", file=sys.stderr)
        sys.exit(1)
    print(f"  找到 {len(feedback_items)} 条反馈")

    apply_log: list[dict] = []
    processed = skipped = errors = 0

    for feedback in feedback_items:
        qid = feedback["question_id"]
        decision = feedback["decision"]

        if not qid or not decision:
            continue
        if decision not in ALLOWED_DECISIONS:
            print(f"  [SKIP] {qid}: 未知 decision '{decision}'")
            skipped += 1
            continue

        q = questions.get(qid)
        if q is None:
            print(f"  [SKIP] {qid}: 题目 JSON 未找到")
            apply_log.append({
                "question_id": qid,
                "decision": decision,
                "status": "not_found",
                "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            })
            skipped += 1
            continue

        print(f"  [{decision.upper()}] {qid} ...", end=" ", flush=True)

        if decision == "accept":
            # Just mark as reviewed
            merge_expert_review(q, feedback, "none", [])
            if args.apply:
                save_question(q)
            apply_log.append({
                "question_id": qid,
                "decision": decision,
                "changed_file": q.get("_file_path", ""),
                "changed_fields": [],
                "expert_instruction": feedback["instruction"],
                "status": "applied" if args.apply else "dry_run",
                "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            })
            print("✅ accepted")
            processed += 1
            continue

        if decision == "reject":
            if args.apply:
                dst = reject_question(q, rejected_dir)
                status = "rejected"
            else:
                dst = f"(dry-run) → {rejected_dir / Path(q.get('_file_path', 'unknown')).name}"
                status = "dry_run"
            apply_log.append({
                "question_id": qid,
                "decision": decision,
                "moved_to": dst,
                "expert_instruction": feedback["instruction"],
                "status": status,
                "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            })
            print(f"🗑️ rejected → {dst}")
            processed += 1
            continue

        if decision == "regenerate":
            apply_log.append({
                "question_id": qid,
                "decision": decision,
                "expert_instruction": feedback["instruction"],
                "status": "pending_regenerate",
                "note": "需手动重新生成",
                "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            })
            print("🔄 regenerate (待手动处理)")
            processed += 1
            continue

        # 专家两框直采快路径：专家已填完整「改题目 + 改答案」→ 不调 LLM，原样采用题目，
        # 把答案确定性拆成得分点(key_points)，再保存。证据/路径节点不动。
        if (decision in ("rewrite", "revise")
                and feedback["expert_revised_question"]
                and feedback["expert_revised_answer"]):
            modified = copy.deepcopy({k: v for k, v in q.items() if not k.startswith("_")})
            modified["question"] = feedback["expert_revised_question"]
            gt = modified.setdefault("ground_truth", {})
            gt["answer"] = feedback["expert_revised_answer"]
            gt["key_points"] = (feedback["expert_revised_key_points"]
                                or split_answer_into_key_points(feedback["expert_revised_answer"]))
            changed_fields = detect_changed_fields(q, modified)
            modified["_file_path"] = q.get("_file_path", "")
            preserve_source_meta(q, modified)
            merge_expert_review(modified, feedback, "expert_direct", changed_fields)
            if args.apply:
                save_question(modified)
                status = "applied"
            else:
                status = "dry_run"
            apply_log.append({
                "question_id": qid,
                "decision": decision,
                "changed_file": modified.get("_file_path", ""),
                "changed_fields": changed_fields,
                "expert_instruction": "(专家直采：改题目+改答案，答案自动拆得分点)",
                "status": status,
                "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            })
            print(f"✅ {status} [专家直采 {len(gt['key_points'])} 个得分点]")
            processed += 1
            continue

        # revise / rewrite / downgrade → call LLM
        try:
            prompt = build_apply_prompt(q, feedback)
            modified = call_llm_apply(client, prompt, args.model)
        except RuntimeError as exc:
            apply_log.append({
                "question_id": qid,
                "decision": decision,
                "status": "error",
                "error": str(exc),
                "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            })
            print(f"❌ LLM 错误: {exc}")
            errors += 1
            continue

        # Validate immutable fields
        violations = validate_immutable(q, modified)
        violations += validate_expert_constraints(modified, feedback)

        if violations:
            apply_log.append({
                "question_id": qid,
                "decision": decision,
                "status": "validation_failed",
                "violations": violations,
                "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            })
            print(f"❌ 验证失败: {violations}")
            errors += 1
            continue

        changed_fields = detect_changed_fields(q, modified)
        modified["_file_path"] = q.get("_file_path", "")
        preserve_source_meta(q, modified)
        merge_expert_review(modified, feedback, args.model, changed_fields)

        if args.apply:
            save_question(modified)
            status = "applied"
        else:
            status = "dry_run"

        apply_log.append({
            "question_id": qid,
            "decision": decision,
            "changed_file": modified.get("_file_path", ""),
            "changed_fields": changed_fields,
            "expert_instruction": feedback["instruction"],
            "status": status,
            "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        })
        print(f"✅ {status} [{', '.join(changed_fields[:4])}]")
        processed += 1

    # Write log
    log_path = report_dir / "expert_feedback_apply_log.json"
    log_path.write_text(
        json.dumps({
            "summary": {
                "processed": processed,
                "skipped": skipped,
                "errors": errors,
                "model": args.model,
                "applied": args.apply,
                "timestamp": datetime.now().isoformat(),
            },
            "log": apply_log,
        }, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    print(f"\n[apply_expert_feedback] 完成: 处理={processed}, 跳过={skipped}, 错误={errors}")
    print(f"  日志 → {log_path}")


if __name__ == "__main__":
    main()
