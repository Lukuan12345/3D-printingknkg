#!/usr/bin/env python3
"""
script/llm_judge.py - LLM-as-Judge 8-dimensional scoring with repair guidance.

Merged (QAG-merged):
  - v2 base: repair_priority / repair_actions / expert_focus, structured JSON output,
    one-question-per-file loader with _file_path tracking.
  - v1 restored: 8th dimension `mechanism_consistency` + MECHANISM_MISMATCH flag,
    domain-aware system prompt, and local source-material grounding (KB + PDF excerpts).

Outputs:
  {prefix}llm_judge_question_scores.json  - Per-question scores + repair guidance
  {prefix}llm_judge_report.md             - Human-readable report
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sqlite3
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any

from openai import OpenAI

# ─── Configuration ────────────────────────────────────────────────────────────

QAG_DIR = Path(__file__).resolve().parent.parent
DEFAULT_PDF_DIR = QAG_DIR / "extern_data"
DEFAULT_KB_CANDIDATES = [
    QAG_DIR / "intern_data" / "kb.db",
    QAG_DIR / "intern_data" / "kb_mvp" / "data" / "kb.db",
]

LLM_BASE_URL = os.getenv("QAG_LLM_BASE_URL", "http://43.153.42.7:3001/v1")
API_KEY = os.getenv("QAG_API_KEY") or os.getenv("OPENAI_API_KEY", "sk-placeholder")
DEFAULT_JUDGE_MODEL = os.getenv("QAG_JUDGE_MODEL") or os.getenv("QAG_LLM_MODEL", "claude-sonnet-4-6")

SKIP_FILENAMES = {
    "generation_manifest.json", "question_quality_metrics.json",
    "reasoning_path_validation.json", "llm_judge_question_scores.json",
    "usable_ids.json", "usable_question_ids.json", "final_questions.json",
    "selfcheck_results.json", "llm_repair_log.json", "expert_feedback_apply_log.json",
    "review_data.json", "expert_feedback.json",
}

PASS_THRESHOLD = 3.5
RETRY_TIMES = 2
RETRY_DELAY = 2

# ─── Helpers ──────────────────────────────────────────────────────────────────

def load_questions(input_dir: Path) -> list[dict]:
    questions: list[dict] = []
    for jf in sorted(input_dir.rglob("*.json")):
        if jf.name in SKIP_FILENAMES or "reports" in jf.parts or "rejected" in jf.parts:
            continue
        try:
            data = json.loads(jf.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            continue
        if isinstance(data, dict) and "id" in data:
            data["_file_path"] = str(jf)
            questions.append(data)
        elif isinstance(data, list):
            continue  # one-question-per-file
    return questions


def extract_json(text: str) -> dict:
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    m = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.DOTALL)
    if m:
        try:
            return json.loads(m.group(1))
        except json.JSONDecodeError:
            pass
    m2 = re.search(r"\{.*\}", text, re.DOTALL)
    if m2:
        try:
            return json.loads(m2.group(0))
        except json.JSONDecodeError:
            pass
    raise ValueError(f"Cannot extract JSON from response:\n{text[:500]}")


# ─── Local source-material grounding (restored from v1) ───────────────────────

def resolve_kb_path(arg_path: str | None) -> Path | None:
    if arg_path:
        p = Path(arg_path)
        return p if p.exists() else None
    return next((p for p in DEFAULT_KB_CANDIDATES if p.exists()), None)


def load_kb_texts(kb_path: Path | None, uids: set[str]) -> dict[str, str]:
    if not kb_path or not kb_path.exists() or not uids:
        return {}
    conn = sqlite3.connect(str(kb_path))
    try:
        out: dict[str, str] = {}
        for uid in sorted(uids):
            rows = conn.execute(
                "SELECT field_type, content FROM paper_chunks WHERE paper_id=?",
                (uid,),
            ).fetchall()
            if rows:
                out[uid.lower()] = "\n".join(f"[{r[0]}] {r[1]}" for r in rows if r[1])
        return out
    except sqlite3.Error:
        return {}
    finally:
        conn.close()


def load_pdf_texts(pdf_dir: Path) -> tuple[dict[str, str], dict[str, str]]:
    by_name: dict[str, str] = {}
    by_stem: dict[str, str] = {}
    try:
        import fitz
    except Exception:
        return by_name, by_stem
    if not pdf_dir.exists():
        return by_name, by_stem
    for pdf in sorted(pdf_dir.glob("*.pdf")):
        try:
            data = pdf.read_bytes()
            if not data.startswith(b"%PDF"):
                continue
            doc = fitz.open(stream=data, filetype="pdf")
            text = "\n".join(doc[i].get_text() for i in range(min(12, len(doc))))
            doc.close()
            by_name[pdf.name.lower()] = text
            by_stem[pdf.stem.lower()] = text
        except Exception:
            continue
    return by_name, by_stem


def source_excerpt_for_question(
    q: dict[str, Any],
    kb_texts: dict[str, str],
    pdf_by_name: dict[str, str],
    pdf_by_stem: dict[str, str],
    max_chars_per_source: int = 1800,
) -> str:
    meta = q.get("annotation_meta") or {}
    parts: list[str] = []
    uids = meta.get("source_paper_uids") or []
    files = meta.get("source_file_names") or []
    for uid in list(uids) + list(files):
        key = str(uid).lower()
        source_kind, text = "", ""
        if key in kb_texts:
            source_kind, text = "internal_kb", kb_texts[key]
        elif key in pdf_by_name:
            source_kind, text = "external_pdf", pdf_by_name[key]
        else:
            stem = Path(str(uid)).stem.lower()
            if stem in pdf_by_stem:
                source_kind, text = "external_pdf", pdf_by_stem[stem]
        if text:
            parts.append(f"【{source_kind} | {uid}】\n{text[:max_chars_per_source]}")
    return "\n\n--- 来源分隔 ---\n\n".join(parts)[:9000]


# ─── Judge prompt (8 dimensions) ──────────────────────────────────────────────

JUDGE_SYSTEM = """你是电磁超材料 / 频率选择表面 / 吸波器领域的 benchmark 题目审查专家。
你的任务是审查题目质量，不是回答题目。你必须严格、可解释、可复现地打分。
请特别区分：
1. internal_kb / mixed 题：证据和数值应能从给定材料或清晰计算式中支撑；
2. external_pdf_only 专家题：它们不要求命中内部 KB，但仍需要库外 PDF 证据或专家推导链条合理。

【输出纪律】只输出一个合法 JSON 对象，不要 Markdown 围栏、不要任何解释文字。
comments 一句话即可（≤60 字），suggestions/expert_focus 各最多 2 条短句，避免长篇大论导致输出超长被截断。"""

JUDGE_PROMPT = """请审查以下 KGQA 题目，按 1-5 分评分，并输出严格 JSON。

## 题目信息
{question_json}

## 本地来源材料节选
{source_excerpt}

## 评审维度（1-5分，5分最好）
1. relevance: 题目是否紧扣材料核心内容？
2. answerability: 能否从提供的证据确定性地回答题目？
3. reasoning_depth: 推理深度是否符合 hop_count 要求？
4. evidence_traceability: 关键论断是否可追溯到具体 evidence_id？external_pdf_only 可接受专家推导，但要说明。
5. anti_routine: 题目是否需要专业知识，不是常识题？
6. numeric_grounding: 答案中所有数值是否来自证据或有效计算？
7. key_point_quality: Key Points 是否独立、具体、无代词无连接词？
8. mechanism_consistency: 物理机制是否有跨文献张冠李戴（A论文的偶极子共振不宜解释B论文的FSS结构）；若存在跨文献引用，机制是否确实在两篇论文中都有描述？

## 风险标签（可多选）
LOW_RELEVANCE, UNANSWERABLE, SHALLOW_HOP, EVIDENCE_RISK, NUMERIC_RISK, KP_RISK, DUPLICATE_RISK, SOURCE_MISMATCH, MECHANISM_MISMATCH

## 修复优先级
none|low|medium|high|critical

## 输出要求
仅输出 JSON，格式如下：

```json
{{
  "scores": {{
    "relevance": 4,
    "answerability": 4,
    "reasoning_depth": 3,
    "evidence_traceability": 4,
    "anti_routine": 4,
    "numeric_grounding": 2,
    "key_point_quality": 4,
    "mechanism_consistency": 4
  }},
  "overall": 3.62,
  "pass": false,
  "flags": ["NUMERIC_RISK"],
  "comments": "题目整体质量良好，但答案中数值 X 无法在给定证据中找到来源。",
  "suggestions": ["删除无证据数值 X，或替换为证据中出现的数值 Y。"],
  "repair_priority": "high",
  "repair_actions": [
    {{
      "field": "ground_truth.answer",
      "action": "remove unsupported numeric claim",
      "reason": "数值 X 未在任何 evidence 原文中出现"
    }}
  ],
  "expert_focus": [
    "请核实证据原文中是否有该数值",
    "请确认来源文献是否与答案结论对应"
  ]
}}
```

注意：overall = 8 个维度的平均值，保留 2 位小数。pass = overall >= 3.5。"""


def build_judge_input(q: dict) -> str:
    """Concise representation of the question for the judge."""
    ev_summary = []
    for ev in (q.get("gold_evidence") or [])[:5]:
        ev_summary.append({
            "evidence_id": ev.get("evidence_id"),
            "source_kind": ev.get("source_kind"),
            "source": ev.get("source"),
            "text_preview": (ev.get("text") or "")[:200],
        })
    concise = {
        "id": q.get("id"),
        "difficulty_level": q.get("difficulty_level"),
        "hop_count": q.get("hop_count"),
        "domain": q.get("domain"),
        "intent": q.get("intent"),
        "question_type": q.get("question_type"),
        "question": q.get("question"),
        "expected_path_nodes": q.get("expected_path_nodes"),
        "ground_truth": q.get("ground_truth"),
        "recommended_papers": q.get("recommended_papers"),
        "source_mode": (q.get("annotation_meta") or {}).get("source_mode"),
        "gold_evidence_summary": ev_summary,
    }
    return json.dumps(concise, ensure_ascii=False, indent=2)


def _chat_with_fallback(client, model: str, **kwargs):
    """model 可为 'm1,m2,m3' 有序链；逐个尝试，抛错则降级到下一个模型。

    除 API 异常外，输出被 max_tokens 截断（finish_reason=='length'）也视为失败并降级——
    截断的 JSON 必然解析失败，换个不那么啰嗦的模型往往能完整输出。
    """
    chain = [m.strip() for m in str(model).split(",") if m.strip()] or [model]
    last_exc = None
    for m in chain:
        try:
            resp = client.chat.completions.create(model=m, **kwargs)
            fr = resp.choices[0].finish_reason if resp.choices else None
            if fr == "length":
                raise RuntimeError(f"输出被截断 (finish_reason=length)，疑似 max_tokens 不足")
            return resp
        except Exception as e:  # 模型不可用 / 鉴权 / 限流 / 超时 / 截断 → 降级
            last_exc = e
            print(f"  [FALLBACK] 模型 {m} 调用失败：{e}，尝试下一个", flush=True)
    raise last_exc


def call_judge(client: OpenAI, q: dict, model: str, source_excerpt: str) -> dict:
    prompt = JUDGE_PROMPT.format(
        question_json=build_judge_input(q),
        source_excerpt=source_excerpt or "未找到本地来源材料；请基于题目 JSON 中的 evidence/source_mode 审查。",
    )
    for attempt in range(RETRY_TIMES + 1):
        try:
            resp = _chat_with_fallback(
                client,
                model,
                messages=[
                    {"role": "system", "content": JUDGE_SYSTEM},
                    {"role": "user", "content": prompt},
                ],
                temperature=0.1,
                max_tokens=4096,
            )
            raw = resp.choices[0].message.content or ""
            result = extract_json(raw)
            # overall = average of all dimension scores (now 8 if model returns 8)
            scores = result.get("scores") or {}
            vals = [v for v in scores.values() if isinstance(v, (int, float))]
            overall = round(sum(vals) / len(vals), 2) if vals else 0.0
            result["overall"] = overall
            result["pass"] = overall >= PASS_THRESHOLD
            result.setdefault("flags", [])
            result.setdefault("comments", "")
            result.setdefault("suggestions", [])
            result.setdefault("repair_priority", "none")
            result.setdefault("repair_actions", [])
            result.setdefault("expert_focus", [])
            return result
        except Exception as exc:
            if attempt < RETRY_TIMES:
                time.sleep(RETRY_DELAY)
            else:
                return {
                    "scores": {},
                    "overall": 0.0,
                    "pass": False,
                    "flags": ["JUDGE_ERROR"],
                    "comments": f"评审失败: {exc}",
                    "suggestions": [],
                    "repair_priority": "medium",
                    "repair_actions": [],
                    "expert_focus": ["评审失败，建议人工复核"],
                    "error": str(exc),
                }


# ─── Report ───────────────────────────────────────────────────────────────────

def build_markdown(scored: list[dict]) -> str:
    lines = [
        "# LLM Judge 评审报告 (QAG-merged, 8 维)",
        f"> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        "",
        "## 汇总",
    ]
    passed = sum(1 for s in scored if s.get("judge", {}).get("pass"))
    lines += [
        f"- 总题数: {len(scored)}",
        f"- 通过: {passed}",
        f"- 未通过: {len(scored) - passed}",
        "",
        "## 明细",
    ]
    for s in scored:
        j = s.get("judge") or {}
        icon = "✅" if j.get("pass") else "❌"
        lines.append(f"\n### {icon} {s['id']} [overall={j.get('overall', 0):.2f}]")
        lines.append(f"- 难度: {s.get('difficulty_level')}  跳数: {s.get('hop_count')}")
        if j.get("flags"):
            lines.append(f"- 风险: {', '.join(j['flags'])}")
        if j.get("repair_priority", "none") != "none":
            lines.append(f"- 修复优先级: **{j['repair_priority']}**")
        if j.get("comments"):
            lines.append(f"- 评语: {j['comments']}")
        for sug in j.get("suggestions") or []:
            lines.append(f"  - 💡 {sug}")
        for ef in j.get("expert_focus") or []:
            lines.append(f"  - 👁 {ef}")
    return "\n".join(lines)


# ─── Main ─────────────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(description="QAG-merged LLM Judge 评审 (8 维)")
    parser.add_argument("--input-dir", default="output")
    parser.add_argument("--report-dir", default="output/reports")
    parser.add_argument("--report-prefix", default="")
    parser.add_argument("--model", default=DEFAULT_JUDGE_MODEL)
    parser.add_argument("--limit", type=int, default=0, help="只评审前 N 题")
    parser.add_argument("--start", type=int, default=0, help="从第 N 题开始评审（0-indexed，配合 --limit 实现范围）")
    parser.add_argument("--api-key", default="")
    parser.add_argument("--base-url", default="")
    parser.add_argument("--pdf-dir", default=str(DEFAULT_PDF_DIR), help="专家 PDF 目录，用于来源材料接地")
    parser.add_argument("--kb-db", default="", help="kb.db 路径；不填则自动查找 intern_data/kb.db")
    args = parser.parse_args()

    input_dir = Path(args.input_dir)
    report_dir = Path(args.report_dir)
    report_dir.mkdir(parents=True, exist_ok=True)
    pfx = args.report_prefix

    api_key = args.api_key or API_KEY
    base_url = args.base_url or LLM_BASE_URL
    client = OpenAI(api_key=api_key, base_url=base_url)

    questions = load_questions(input_dir)
    if args.start > 0:
        questions = questions[args.start:]
    if args.limit > 0:
        questions = questions[: args.limit]

    if not questions:
        print("[llm_judge] 未找到题目 JSON", file=sys.stderr)
        sys.exit(1)

    # Local source grounding (KB + PDF), restored from v1.
    uids = {
        str(uid).lower()
        for q in questions
        for uid in (q.get("annotation_meta") or {}).get("source_paper_uids", [])
        if re.fullmatch(r"[0-9a-f]{16,40}", str(uid).lower())
    }
    kb_texts = load_kb_texts(resolve_kb_path(args.kb_db), uids)
    pdf_by_name, pdf_by_stem = load_pdf_texts(Path(args.pdf_dir))

    print(f"[llm_judge] 开始评审 {len(questions)} 题，模型: {args.model} "
          f"(KB papers={len(kb_texts)}, PDFs={len(pdf_by_name)})")
    scored: list[dict] = []
    for i, q in enumerate(questions, 1):
        print(f"  [{i}/{len(questions)}] {q.get('id', '?')} ...", end=" ", flush=True)
        excerpt = source_excerpt_for_question(q, kb_texts, pdf_by_name, pdf_by_stem)
        judge_result = call_judge(client, q, args.model, excerpt)
        row = {
            "id": q.get("id", "UNKNOWN"),
            "file_path": q.get("_file_path", ""),
            "difficulty_level": q.get("difficulty_level", ""),
            "domain": q.get("domain", ""),
            "hop_count": q.get("hop_count"),
            "judge": judge_result,
        }
        scored.append(row)
        status = "✅" if judge_result.get("pass") else "❌"
        print(f"{status} overall={judge_result.get('overall', 0):.2f}")

    summary = {
        "total": len(scored),
        "passed": sum(1 for s in scored if s.get("judge", {}).get("pass")),
        "failed": sum(1 for s in scored if not s.get("judge", {}).get("pass")),
        "model": args.model,
        "timestamp": datetime.now().isoformat(),
    }

    out_json = report_dir / f"{pfx}llm_judge_question_scores.json"
    out_json.write_text(
        json.dumps({"summary": summary, "questions": scored}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    out_md = report_dir / f"{pfx}llm_judge_report.md"
    out_md.write_text(build_markdown(scored), encoding="utf-8")

    print(f"\n[llm_judge] 通过 {summary['passed']}/{summary['total']} → {out_json}")


if __name__ == "__main__":
    main()
