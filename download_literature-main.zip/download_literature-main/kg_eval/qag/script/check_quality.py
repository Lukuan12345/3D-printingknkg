#!/usr/bin/env python3
"""
script/check_quality.py - Local evidence/numeric/key-point quality checks.

Outputs:
  question_quality_metrics.json   - Per-question metrics + risk_tags + repair_hint
  quality_report.md               - Human-readable report
"""
from __future__ import annotations

import argparse
import json
import re
import sqlite3
import sys
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any

import grounding_lang  # 跨语种锚点工具（同目录）

# ─── Constants ────────────────────────────────────────────────────────────────

QAG_DIR = Path(__file__).resolve().parent.parent
DEFAULT_PDF_DIR = QAG_DIR / "extern_data"
DEFAULT_KB_CANDIDATES = [
    QAG_DIR / "intern_data" / "kb.db",
    QAG_DIR / "intern_data" / "kb_mvp" / "data" / "kb.db",
]

SKIP_FILENAMES = {
    "generation_manifest.json", "question_quality_metrics.json",
    "reasoning_path_validation.json", "llm_judge_question_scores.json",
    "usable_ids.json", "usable_question_ids.json", "final_questions.json",
    "selfcheck_results.json", "llm_repair_log.json", "expert_feedback_apply_log.json",
}

# Numeric pattern: integers ≥2 digits OR decimals, with optional range and unit
NUMERIC_RE = re.compile(
    r"(?<![A-Za-z0-9])[-+]?(?:\d+\.\d+|\d{2,})"
    r"(?:\s*[–\-~至到]\s*[-+]?(?:\d+\.\d+|\d{2,}))?"
    r"\s*(?:GHz|MHz|kHz|Hz|nm|μm|um|mm|cm|m|dB|dBi|%|K|°C|W|A|V|Ω|ps|ns|μs|us|ms|kg|g|mg)?"
    r"(?![A-Za-z0-9])",
    re.I,
)

# KP pronouns and connector prefixes
KP_PRONOUN_RE = re.compile(r"^(它|该|这|其|此|他们|她们|它们|那)")
KP_CONNECTOR_RE = re.compile(r"^(因此|所以|从而|由此|故|因而|且|并且|而且|另外|此外|同时|但|然而|不过|尽管|虽然)")
KP_MULTI_CLAUSE_RE = re.compile(r"[；;]|，且|，并|，从而|，因此|，所以")

# Similarity threshold (Jaccard)
SIMILARITY_THRESHOLD = 0.6

# ─── Helpers ──────────────────────────────────────────────────────────────────

def load_questions(input_dir: Path) -> list[dict]:
    questions: list[dict] = []
    for jf in sorted(input_dir.rglob("*.json")):
        if jf.name in SKIP_FILENAMES or "reports" in jf.parts or "rejected" in jf.parts:
            continue
        try:
            data = json.loads(jf.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            continue
        if isinstance(data, dict) and "id" in data:
            data["_file_path"] = str(jf)
            questions.append(data)
        elif isinstance(data, list):
            continue  # QAG-v2 requires one-question-per-file
    return questions


def get_source_texts(q: dict) -> list[str]:
    """Collect all available source texts for this question."""
    texts: list[str] = []
    # gold_evidence texts
    for ev in q.get("gold_evidence") or []:
        t = ev.get("text") or ""
        if t:
            texts.append(t)
    # evidence_cards texts
    meta = q.get("annotation_meta") or {}
    for card in meta.get("evidence_cards") or []:
        t = card.get("text") or card.get("content") or ""
        if t:
            texts.append(t)
    return texts


# ─── KB / PDF source grounding (restored from v1) ─────────────────────────────

def resolve_kb_path(arg_path: str | None) -> Path | None:
    if arg_path:
        p = Path(arg_path)
        return p if p.exists() else None
    return next((p for p in DEFAULT_KB_CANDIDATES if p.exists()), None)


def load_kb_pool(kb_path: Path | None) -> dict[str, str]:
    """Map lowercased paper_id -> concatenated chunk content from kb.db."""
    if not kb_path or not kb_path.exists():
        return {}
    pool: dict[str, list[str]] = {}
    try:
        conn = sqlite3.connect(str(kb_path))
        for paper_id, content in conn.execute(
            "SELECT paper_id, content FROM paper_chunks"
        ):
            if content:
                pool.setdefault(str(paper_id).lower(), []).append(str(content))
        conn.close()
    except sqlite3.Error:
        return {}
    return {k: "\n".join(v) for k, v in pool.items()}


def load_pdf_pool(pdf_dir: Path) -> dict[str, str]:
    """Map lowercased pdf name AND stem -> first-pages text."""
    pool: dict[str, str] = {}
    try:
        import fitz
    except Exception:
        return pool
    if not pdf_dir.exists():
        return pool
    for pdf in sorted(pdf_dir.glob("*.pdf")):
        try:
            data = pdf.read_bytes()
            if not data.startswith(b"%PDF"):
                continue
            doc = fitz.open(stream=data, filetype="pdf")
            text = "\n".join(doc[i].get_text() for i in range(min(20, len(doc))))
            doc.close()
            pool[pdf.name.lower()] = text
            pool[pdf.stem.lower()] = text
        except Exception:
            continue
    return pool


def source_keys_for_question(q: dict) -> list[str]:
    """All identifiers that may match a KB paper_id or PDF file name."""
    meta = q.get("annotation_meta") or {}
    keys: list[str] = []
    keys += [str(x) for x in (meta.get("source_paper_uids") or [])]
    keys += [str(x) for x in (meta.get("source_file_names") or [])]
    keys += [str(x) for x in (q.get("recommended_papers") or [])]
    for ev in q.get("gold_evidence") or []:
        for f in (ev.get("source_file"), ev.get("source_uid")):
            if f:
                keys.append(str(f))
    return keys


def grounding_texts_for_question(
    q: dict, kb_pool: dict[str, str], pdf_pool: dict[str, str]
) -> list[str]:
    """KB/PDF texts of this question's source papers (for numeric grounding)."""
    extra: list[str] = []
    seen: set[str] = set()
    for key in source_keys_for_question(q):
        k = key.lower()
        stem = Path(key).stem.lower()
        for cand in (k, stem):
            if cand in seen:
                continue
            if cand in kb_pool:
                extra.append(kb_pool[cand]); seen.add(cand)
            elif cand in pdf_pool:
                extra.append(pdf_pool[cand]); seen.add(cand)
    return extra


def tokenize(text: str) -> set[str]:
    """Simple CJK + ASCII tokenization."""
    tokens: set[str] = set()
    # CJK: each character is a token
    for ch in re.findall(r"[一-鿿]", text):
        tokens.add(ch)
    # ASCII words (case-insensitive)
    for word in re.findall(r"[a-zA-Z0-9]+", text.lower()):
        if len(word) >= 2:
            tokens.add(word)
    return tokens


def evidence_grounding_score(answer: str, source_texts: list[str]) -> float:
    """Fraction of answer tokens that appear in any source text.

    跨语种（中文答案 vs 英文证据）时，逐字符 token 重合无意义——分母几乎全是中文字、
    永不命中英文 → 分被结构性压到 ~0.08。此时改为只比「语言无关锚点」（数字 + 单位/
    缩写/拉丁术语）的召回：答案里这些技术锚点有多少被证据支持，才是真正可衡量的接地。
    同语种（中文证据）或答案无锚点时，仍走原全 token 召回，行为不变、不虚高。
    """
    if not answer or not source_texts:
        return 0.0
    combined_source = "\n".join(source_texts)
    # 跨语种且答案含可对齐锚点 → 锚点召回
    if grounding_lang.cross_lingual(answer, combined_source) and grounding_lang.has_anchors(answer):
        return round(grounding_lang.anchor_recall(answer, combined_source), 4)
    answer_tokens = tokenize(answer)
    if not answer_tokens:
        return 1.0
    source_tokens: set[str] = set()
    for t in source_texts:
        source_tokens |= tokenize(t)
    overlap = answer_tokens & source_tokens
    return round(len(overlap) / len(answer_tokens), 4)


def find_numeric_hallucinations(answer: str, source_texts: list[str]) -> tuple[int, list[str]]:
    """Return (count, list_of_unsupported_numbers) in the answer.

    基于规整后的数值集合比对（去 [EV-xxx]/[11] 引用、范围拆端点、float 归一），
    避免旧逻辑「7.9–12.1（破折号）vs 7.9 to 12.1（原文）」整段子串匹配失败造成的假阳性。
    """
    combined_source = " ".join(source_texts)
    source_vals = grounding_lang.numeric_values(combined_source)
    # 保留答案中数值的原始书写（用于报告展示），同时按规整值判定是否被支持
    cleaned_answer = grounding_lang._strip_citations(answer)
    unsupported: list[str] = []
    seen: set[str] = set()
    for m in grounding_lang._NUMBER_RE.findall(cleaned_answer):
        try:
            f = float(m)
        except ValueError:
            continue
        norm = str(int(f)) if f.is_integer() else repr(f)
        if norm in source_vals or norm in seen:
            continue
        seen.add(norm)
        unsupported.append(m)
    return len(unsupported), unsupported


def check_key_points(key_points: list[str]) -> tuple[float, list[str]]:
    """Return (score 0-1, list_of_violations)."""
    if not key_points:
        return 0.0, ["key_points 为空"]
    violations: list[str] = []
    for i, kp in enumerate(key_points, 1):
        if not kp or not kp.strip():
            violations.append(f"KP{i}: 空白")
            continue
        if KP_PRONOUN_RE.search(kp):
            violations.append(f"KP{i}: 以代词开头 — {kp[:20]}")
        if KP_CONNECTOR_RE.search(kp):
            violations.append(f"KP{i}: 以连接词开头 — {kp[:20]}")
        if KP_MULTI_CLAUSE_RE.search(kp):
            violations.append(f"KP{i}: 含多子句分号/连接 — {kp[:40]}")
    score = round(max(0.0, 1.0 - len(violations) / len(key_points)), 4)
    return score, violations


def jaccard(a: str, b: str) -> float:
    ta, tb = tokenize(a), tokenize(b)
    if not ta or not tb:
        return 0.0
    return len(ta & tb) / len(ta | tb)


def detect_similar_pairs(questions: list[dict]) -> dict[str, list[str]]:
    """Return {qid: [similar_qids]} for questions with Jaccard similarity ≥ threshold."""
    by_level: dict[str, list[dict]] = {}
    for q in questions:
        lv = q.get("difficulty_level", "?")
        by_level.setdefault(lv, []).append(q)
    similar_map: dict[str, list[str]] = {}
    for level_qs in by_level.values():
        for i, qa in enumerate(level_qs):
            for qb in level_qs[i + 1:]:
                sim = jaccard(qa.get("question", ""), qb.get("question", ""))
                if sim >= SIMILARITY_THRESHOLD:
                    similar_map.setdefault(qa["id"], []).append(qb["id"])
                    similar_map.setdefault(qb["id"], []).append(qa["id"])
    return similar_map


# ─── Per-question metric ──────────────────────────────────────────────────────

def analyse_question(q: dict, similar_ids: list[str], kb_extra: list[str] | None = None) -> dict:
    answer = (q.get("ground_truth") or {}).get("answer") or ""
    key_points = (q.get("ground_truth") or {}).get("key_points") or []
    evidence_texts = get_source_texts(q)
    # KB/PDF source text augments grounding so numbers present in the source
    # paper (but not copied into the evidence card) are not flagged as hallucinations.
    kb_extra = kb_extra or []
    source_texts = evidence_texts + kb_extra

    eg_score = evidence_grounding_score(answer, source_texts)
    num_count, unsupported = find_numeric_hallucinations(answer, source_texts)
    kp_score, kp_violations = check_key_points(key_points)
    has_similarity_risk = bool(similar_ids)

    risk_tags: list[str] = []
    repair_hint: list[str] = []

    if eg_score < 0.6:
        risk_tags.append("LOW_EVIDENCE_GROUNDING")
        repair_hint.append(
            f"答案与证据文本重合度仅 {eg_score:.0%}，建议核对答案是否基于 gold_evidence"
        )
    if num_count > 0:
        risk_tags.append("NUMERIC_RISK")
        for n in unsupported:
            repair_hint.append(f"数值 '{n}' 未在证据原文中找到，建议删除或替换为证据中实际出现的数值")
    if kp_score < 0.75:
        risk_tags.append("KP_QUALITY_RISK")
        for v in kp_violations[:3]:
            repair_hint.append(f"Key Points 问题: {v}")
    if has_similarity_risk:
        risk_tags.append("DUPLICATE_RISK")
        repair_hint.append(f"与题目 {similar_ids[:3]} 相似度过高，建议检查是否重复出题")

    return {
        "id": q.get("id", "UNKNOWN"),
        "file_path": q.get("_file_path", ""),
        "difficulty_level": q.get("difficulty_level", ""),
        "domain": q.get("domain", ""),
        "hop_count": q.get("hop_count"),
        "evidence_grounding_score": eg_score,
        "numeric_hallucination_count": num_count,
        "unsupported_numbers": unsupported,
        "kp_quality_score": kp_score,
        "kp_violations": kp_violations,
        "similar_question_ids": similar_ids,
        "risk_tags": risk_tags,
        "repair_hint": repair_hint,
        "kb_grounded": bool(kb_extra),
    }


# ─── Report ───────────────────────────────────────────────────────────────────

def build_markdown(metrics: list[dict]) -> str:
    lines = [
        "# 题目质量检测报告 (QAG-v2)",
        f"> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        "",
        "## 汇总",
    ]
    numeric_risk = sum(1 for m in metrics if "NUMERIC_RISK" in m["risk_tags"])
    ev_risk = sum(1 for m in metrics if "LOW_EVIDENCE_GROUNDING" in m["risk_tags"])
    kp_risk = sum(1 for m in metrics if "KP_QUALITY_RISK" in m["risk_tags"])
    dup_risk = sum(1 for m in metrics if "DUPLICATE_RISK" in m["risk_tags"])
    lines += [
        f"- 总题数: {len(metrics)}",
        f"- 数值幻觉风险: {numeric_risk}",
        f"- 证据接地不足: {ev_risk}",
        f"- Key Points 质量问题: {kp_risk}",
        f"- 相似度风险: {dup_risk}",
        "",
        "## 明细",
    ]
    for m in metrics:
        tags_str = ", ".join(m["risk_tags"]) or "无"
        lines.append(f"\n### {m['id']} [{m['difficulty_level']} {m['domain']}]")
        lines.append(f"- 证据接地得分: {m['evidence_grounding_score']}")
        lines.append(f"- 数值幻觉数量: {m['numeric_hallucination_count']}")
        lines.append(f"- KP 质量得分: {m['kp_quality_score']}")
        lines.append(f"- 风险标签: {tags_str}")
        for hint in m["repair_hint"]:
            lines.append(f"  - ⚠️ {hint}")
    return "\n".join(lines)


# ─── Main ─────────────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(description="QAG-merged 题目质量检测")
    parser.add_argument("--input-dir", default="output")
    parser.add_argument("--report-dir", default="output/reports")
    parser.add_argument("--report-prefix", default="")
    parser.add_argument("--pdf-dir", default=str(DEFAULT_PDF_DIR),
                        help="专家 PDF 目录，用于数值/证据接地（v1 强项）")
    parser.add_argument("--kb-db", default="",
                        help="kb.db 路径；不填则自动查找 intern_data/kb.db")
    parser.add_argument("--no-kb-check", action="store_true",
                        help="跳过 KB/PDF 接地，仅用 JSON 内 gold_evidence/evidence_cards")
    args = parser.parse_args()

    input_dir = Path(args.input_dir)
    report_dir = Path(args.report_dir)
    report_dir.mkdir(parents=True, exist_ok=True)
    pfx = args.report_prefix

    questions = load_questions(input_dir)
    if not questions:
        print(f"[check_quality] 未找到题目 JSON", file=sys.stderr)
        sys.exit(1)

    # Build KB/PDF grounding pools (restored from v1).
    kb_pool: dict[str, str] = {}
    pdf_pool: dict[str, str] = {}
    if not args.no_kb_check:
        kb_pool = load_kb_pool(resolve_kb_path(args.kb_db))
        pdf_pool = load_pdf_pool(Path(args.pdf_dir))
        print(f"[check_quality] 接地源: KB papers={len(kb_pool)}, PDFs={len(pdf_pool)//2}")

    similar_map = detect_similar_pairs(questions)
    metrics = [
        analyse_question(
            q,
            similar_map.get(q.get("id", ""), []),
            grounding_texts_for_question(q, kb_pool, pdf_pool),
        )
        for q in questions
    ]

    summary = {
        "total": len(metrics),
        "numeric_risk_count": sum(1 for m in metrics if "NUMERIC_RISK" in m["risk_tags"]),
        "low_ev_grounding_count": sum(1 for m in metrics if "LOW_EVIDENCE_GROUNDING" in m["risk_tags"]),
        "kp_risk_count": sum(1 for m in metrics if "KP_QUALITY_RISK" in m["risk_tags"]),
        "duplicate_risk_count": sum(1 for m in metrics if "DUPLICATE_RISK" in m["risk_tags"]),
    }

    out_json = report_dir / f"{pfx}question_quality_metrics.json"
    out_json.write_text(
        json.dumps({"summary": summary, "questions": metrics}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    out_md = report_dir / f"{pfx}quality_report.md"
    out_md.write_text(build_markdown(metrics), encoding="utf-8")

    print(f"[check_quality] {len(metrics)} 题分析完成")
    print(f"  数值幻觉风险: {summary['numeric_risk_count']}")
    print(f"  证据接地不足: {summary['low_ev_grounding_count']}")
    print(f"  KP 质量问题: {summary['kp_risk_count']}")
    print(f"  → {out_json}")


if __name__ == "__main__":
    main()
