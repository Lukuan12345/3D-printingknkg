#!/usr/bin/env python3
"""
script/llm_repair.py - LLM-driven self-repair for quality issues before expert review.

Reads quality metrics and LLM judge scores, then calls LLM to repair problematic questions.
Writes repaired JSONs back to their original files and records a repair log.

Outputs:
  llm_repair_log.json      - Detailed repair actions per question
  llm_repair_summary.md    - Human-readable summary
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time
from datetime import datetime
from pathlib import Path

from openai import OpenAI

# ─── Configuration ────────────────────────────────────────────────────────────

LLM_BASE_URL = os.getenv("QAG_LLM_BASE_URL", "http://43.153.42.7:3001/v1")
API_KEY = os.getenv("QAG_API_KEY") or os.getenv("OPENAI_API_KEY", "sk-placeholder")
DEFAULT_MODEL = os.getenv("QAG_LLM_MODEL", "claude-sonnet-4-6")

SKIP_FILENAMES = {
    "generation_manifest.json", "question_quality_metrics.json",
    "reasoning_path_validation.json", "llm_judge_question_scores.json",
    "usable_ids.json", "usable_question_ids.json", "final_questions.json",
    "selfcheck_results.json", "llm_repair_log.json", "expert_feedback_apply_log.json",
}

RETRY_TIMES = 2
RETRY_DELAY = 2

# ─── Helpers ──────────────────────────────────────────────────────────────────

def load_questions(input_dir: Path) -> dict[str, dict]:
    """Return {question_id: question_dict} with _file_path populated."""
    questions: dict[str, dict] = {}
    for jf in sorted(input_dir.rglob("*.json")):
        if jf.name in SKIP_FILENAMES or "reports" in jf.parts or "rejected" in jf.parts:
            continue
        try:
            data = json.loads(jf.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            continue
        if isinstance(data, dict) and "id" in data:
            data["_file_path"] = str(jf)
            questions[data["id"]] = data
        elif isinstance(data, list):
            continue  # Skip list files: save_question writes single dict and would corrupt multi-question files
    return questions


def load_json_report(path: Path) -> dict:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}


def extract_json(text: str) -> dict:
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    m = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.DOTALL)
    if m:
        try:
            return json.loads(m.group(1))
        except json.JSONDecodeError:
            pass
    m2 = re.search(r"\{.*\}", text, re.DOTALL)
    if m2:
        try:
            return json.loads(m2.group(0))
        except json.JSONDecodeError:
            pass
    raise ValueError(f"Cannot extract JSON:\n{text[:300]}")


# ─── Repair trigger logic ──────────────────────────────────────────────────────

def needs_repair(
    quality: dict,
    path_val: dict,
    judge: dict,
) -> tuple[bool, list[str]]:
    """Return (should_repair, list_of_reasons)."""
    reasons: list[str] = []

    if quality.get("numeric_hallucination_count", 0) > 0:
        reasons.append("NUMERIC_RISK")
    if quality.get("evidence_grounding_score", 1.0) < 0.6:
        reasons.append("LOW_EVIDENCE_GROUNDING")
    if quality.get("kp_quality_score", 1.0) < 0.75:
        reasons.append("KP_QUALITY_RISK")

    judge_data = judge.get("judge") or {}
    if not judge_data.get("pass", True):
        reasons.append("JUDGE_FAILED")
    for flag in judge_data.get("flags") or []:
        if flag in ("EVIDENCE_RISK", "NUMERIC_RISK", "SOURCE_MISMATCH", "UNANSWERABLE", "KP_RISK"):
            if flag not in reasons:
                reasons.append(flag)

    if path_val.get("warnings"):
        for w in path_val["warnings"]:
            if w in ("LOW_PATH_NODE_GROUNDING", "NO_PATH_NODES", "MIXED_SOURCE_NOT_COVERED"):
                if w not in reasons:
                    reasons.append(w)

    return bool(reasons), reasons


# ─── Repair prompt ────────────────────────────────────────────────────────────

REPAIR_PROMPT = """你是 QAG 题目修复器，不是自由出题器。

## 任务
根据质量检测报告，对下面的题目 JSON 进行最小必要修改，使其通过质量检测。

## 原始题目 JSON
{question_json}

## 可用证据卡片（修改必须限于此范围）
{evidence_cards_json}

## 检测到的问题
{issues_text}

## 质量检测报告摘要
{quality_summary}

## LLM Judge 反馈
{judge_feedback}

## 修复规则（严格遵守）
1. 不允许引入 evidence_cards 之外的证据。
2. 不允许编造数值、作者、年份、性能指标。
3. ground_truth.answer 中每个具体数值必须能在 gold_evidence 的 text 字段中找到。
4. 如果证据不足以支撑当前难度，优先降低 hop_count 而非编造新证据。
5. expected_path_nodes 数量必须 = hop_count + 1。
6. ground_truth.key_points 每条独立，不含代词（它/该/这/其），不以连接词开头。
7. 必须保留原始 id。
8. 修改后在 annotation_meta.repair_history 中追加本次修复记录。
9. 禁止张冠李戴：不得把 A 论文结论写入 B 论文答案。

## 输出
仅输出修复后的完整 JSON，不输出任何解释文字。"""


def build_repair_context(
    q: dict,
    reasons: list[str],
    quality: dict,
    judge: dict,
) -> str:
    meta = q.get("annotation_meta") or {}
    evidence_cards = meta.get("evidence_cards") or []

    judge_data = judge.get("judge") or {}
    judge_feedback = {
        "overall": judge_data.get("overall"),
        "flags": judge_data.get("flags"),
        "comments": judge_data.get("comments"),
        "suggestions": judge_data.get("suggestions"),
        "repair_actions": judge_data.get("repair_actions"),
    }

    quality_summary = {
        "evidence_grounding_score": quality.get("evidence_grounding_score"),
        "numeric_hallucination_count": quality.get("numeric_hallucination_count"),
        "unsupported_numbers": quality.get("unsupported_numbers"),
        "kp_quality_score": quality.get("kp_quality_score"),
        "kp_violations": quality.get("kp_violations"),
        "repair_hint": quality.get("repair_hint"),
    }

    # Build a clean copy of the question without internal tracking fields
    q_clean = {k: v for k, v in q.items() if not k.startswith("_")}

    return REPAIR_PROMPT.format(
        question_json=json.dumps(q_clean, ensure_ascii=False, indent=2),
        evidence_cards_json=json.dumps(evidence_cards, ensure_ascii=False, indent=2),
        issues_text="\n".join(f"- {r}" for r in reasons),
        quality_summary=json.dumps(quality_summary, ensure_ascii=False, indent=2),
        judge_feedback=json.dumps(judge_feedback, ensure_ascii=False, indent=2),
    )


def _chat_with_fallback(client, model: str, **kwargs):
    """model 可为 'm1,m2,m3' 有序链；逐个尝试，抛错则降级到下一个模型。

    除 API 异常外，输出被 max_tokens 截断（finish_reason=='length'）也视为失败并降级——
    截断的 JSON 必然解析失败，换个不那么啰嗦的模型往往能完整输出。
    """
    chain = [m.strip() for m in str(model).split(",") if m.strip()] or [model]
    last_exc = None
    for m in chain:
        try:
            resp = client.chat.completions.create(model=m, **kwargs)
            fr = resp.choices[0].finish_reason if resp.choices else None
            if fr == "length":
                raise RuntimeError(f"输出被截断 (finish_reason=length)，疑似 max_tokens 不足")
            return resp
        except Exception as e:  # 模型不可用 / 鉴权 / 限流 / 超时 / 截断 → 降级
            last_exc = e
            print(f"  [FALLBACK] 模型 {m} 调用失败：{e}，尝试下一个", flush=True)
    raise last_exc


def call_repair(client: OpenAI, prompt: str, model: str) -> dict:
    for attempt in range(RETRY_TIMES + 1):
        try:
            resp = _chat_with_fallback(
                client,
                model,
                messages=[
                    {"role": "system", "content": "你只输出一个合法 JSON 对象，不要 Markdown 围栏，不要任何解释文字。保持精简，避免冗长导致输出被截断。"},
                    {"role": "user", "content": prompt},
                ],
                temperature=0.2,
                max_tokens=8192,
            )
            raw = resp.choices[0].message.content or ""
            return extract_json(raw)
        except Exception as exc:
            if attempt < RETRY_TIMES:
                time.sleep(RETRY_DELAY)
            else:
                raise RuntimeError(f"修复调用失败: {exc}") from exc


def validate_repaired(original: dict, repaired: dict) -> list[str]:
    """Basic validation of repaired question. Returns list of violations."""
    violations: list[str] = []
    if repaired.get("id") != original.get("id"):
        violations.append("id 不允许改变")
    if not repaired.get("question"):
        violations.append("question 为空")
    gt = repaired.get("ground_truth") or {}
    if not gt.get("answer"):
        violations.append("ground_truth.answer 为空")
    if not gt.get("key_points"):
        violations.append("ground_truth.key_points 为空")
    nodes = repaired.get("expected_path_nodes") or []
    hop = repaired.get("hop_count") or 0
    if isinstance(hop, int) and len(nodes) < hop + 1:
        violations.append(f"expected_path_nodes 数量 < hop_count+1")
    return violations


def preserve_source_meta(original: dict, modified: dict) -> None:
    """Force-restore immutable source metadata the LLM must not change."""
    orig_meta = original.get("annotation_meta") or {}
    mod_meta = modified.setdefault("annotation_meta", {})
    for key in ("source_paper_uids", "source_file_names", "evidence_cards", "source_mode"):
        if key in orig_meta:
            mod_meta[key] = orig_meta[key]


def apply_repair(original: dict, repaired: dict, reasons: list[str], model: str, round_num: int) -> dict:
    """Merge repaired data back, preserving annotation_meta correctly."""
    repaired["_file_path"] = original.get("_file_path", "")
    preserve_source_meta(original, repaired)

    # Update repair_history in annotation_meta
    meta = repaired.setdefault("annotation_meta", {})
    history = meta.setdefault("repair_history", [])
    history.append({
        "round": round_num,
        "repair_reasons": reasons,
        "repair_model": model,
        "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    })
    meta["repair_status"] = "repaired"
    meta["repair_round"] = round_num
    meta["repair_model"] = model

    return repaired


def save_question(q: dict) -> None:
    file_path = q.get("_file_path")
    if not file_path:
        return
    clean = {k: v for k, v in q.items() if not k.startswith("_")}
    Path(file_path).write_text(
        json.dumps(clean, ensure_ascii=False, indent=2), encoding="utf-8"
    )


# ─── Main ─────────────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(description="QAG-v2 LLM 自纠")
    parser.add_argument("--input-dir", default="output")
    parser.add_argument("--report-dir", default="output/reports")
    parser.add_argument("--report-prefix", default="", help="报告文件名前缀，须与审核时一致")
    parser.add_argument("--model", default=DEFAULT_MODEL)
    parser.add_argument("--max-rounds", type=int, default=1)
    parser.add_argument("--apply", action="store_true", help="实际写回 JSON（否则只模拟）")
    parser.add_argument("--only-new", action="store_true",
                        help="仅自纠最新出的题：读 input-dir/generation_manifest.json 的 question_ids 过滤。")
    parser.add_argument("--api-key", default="")
    parser.add_argument("--base-url", default="")
    args = parser.parse_args()

    input_dir = Path(args.input_dir)
    report_dir = Path(args.report_dir)
    report_dir.mkdir(parents=True, exist_ok=True)

    api_key = args.api_key or API_KEY
    base_url = args.base_url or LLM_BASE_URL
    client = OpenAI(api_key=api_key, base_url=base_url)

    questions = load_questions(input_dir)
    pfx = args.report_prefix

    # 仅最新出的题：用 generation_manifest.json 的 question_ids 过滤
    if args.only_new:
        man_path = input_dir / "generation_manifest.json"
        new_ids: set[str] = set()
        try:
            man = json.loads(man_path.read_text(encoding="utf-8"))
            new_ids = {str(x) for x in (man.get("question_ids") or [])}
        except (json.JSONDecodeError, OSError, FileNotFoundError):
            print(f"[llm_repair] ⚠️  --only-new 但未找到/无法读取 {man_path}，回退为不限批次。")
        if new_ids:
            before = len(questions)
            questions = {qid: q for qid, q in questions.items() if qid in new_ids}
            print(f"[llm_repair] only-new：本批 {len(questions)} 题（目录共 {before} 题）")
    quality_report = load_json_report(report_dir / f"{pfx}question_quality_metrics.json")
    path_report = load_json_report(report_dir / f"{pfx}reasoning_path_validation.json")
    judge_report = load_json_report(report_dir / f"{pfx}llm_judge_question_scores.json")

    # Build lookup dicts by question id
    quality_by_id: dict[str, dict] = {
        q["id"]: q for q in (quality_report.get("questions") or []) if "id" in q
    }
    path_by_id: dict[str, dict] = {
        q["id"]: q for q in (path_report.get("questions") or []) if "id" in q
    }
    judge_by_id: dict[str, dict] = {
        q["id"]: q for q in (judge_report.get("questions") or []) if "id" in q
    }

    repair_log: list[dict] = []
    repaired_count = 0

    for round_num in range(1, args.max_rounds + 1):
        print(f"\n[llm_repair] === 第 {round_num} 轮自纠 ===")
        round_repaired = 0

        for qid, q in list(questions.items()):
            quality = quality_by_id.get(qid, {})
            path_val = path_by_id.get(qid, {})
            judge = judge_by_id.get(qid, {})

            should_repair, reasons = needs_repair(quality, path_val, judge)
            if not should_repair:
                continue

            print(f"  修复 {qid}: {', '.join(reasons)}")
            prompt = build_repair_context(q, reasons, quality, judge)

            try:
                repaired = call_repair(client, prompt, args.model)
            except RuntimeError as exc:
                repair_log.append({
                    "question_id": qid,
                    "round": round_num,
                    "reasons": reasons,
                    "status": "error",
                    "error": str(exc),
                    "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                })
                print(f"    ❌ 修复失败: {exc}")
                continue

            violations = validate_repaired(q, repaired)
            if violations:
                repair_log.append({
                    "question_id": qid,
                    "round": round_num,
                    "reasons": reasons,
                    "status": "validation_failed",
                    "violations": violations,
                    "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                })
                print(f"    ❌ 验证失败: {violations}")
                continue

            repaired = apply_repair(q, repaired, reasons, args.model, round_num)
            questions[qid] = repaired

            if args.apply:
                save_question(repaired)
                print(f"    ✅ 已写回")
            else:
                print(f"    ✅ (dry-run, 未写回)")

            repair_log.append({
                "question_id": qid,
                "round": round_num,
                "reasons": reasons,
                "changed_file": repaired.get("_file_path", ""),
                "status": "applied" if args.apply else "dry_run",
                "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            })
            round_repaired += 1
            repaired_count += 1

        print(f"[llm_repair] 第 {round_num} 轮: 修复 {round_repaired} 题")
        if round_repaired == 0:
            print("[llm_repair] 无需继续修复，提前停止")
            break

    # Write log
    log_path = report_dir / f"{pfx}llm_repair_log.json"
    log_path.write_text(
        json.dumps({
            "summary": {
                "total_repaired": repaired_count,
                "rounds": args.max_rounds,
                "model": args.model,
                "applied": args.apply,
                "timestamp": datetime.now().isoformat(),
            },
            "repairs": repair_log,
        }, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    # Write markdown summary
    lines = [
        "# LLM 自纠报告 (QAG-v2)",
        f"> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        "",
        f"- 修复总数: {repaired_count}",
        f"- 轮数: {args.max_rounds}",
        f"- 模式: {'写回' if args.apply else 'dry-run'}",
        "",
        "## 修复明细",
    ]
    for entry in repair_log:
        icon = "✅" if entry["status"] in ("applied", "dry_run") else "❌"
        lines.append(
            f"- {icon} {entry['question_id']} 第{entry['round']}轮  "
            f"[{entry['status']}]  原因: {', '.join(entry.get('reasons', []))}"
        )
    (report_dir / f"{pfx}llm_repair_summary.md").write_text("\n".join(lines), encoding="utf-8")

    print(f"\n[llm_repair] 完成，共修复 {repaired_count} 题 → {log_path}")


if __name__ == "__main__":
    main()
