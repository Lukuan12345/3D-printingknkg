#!/usr/bin/env python3
"""
script/review_core.py - Format-agnostic review aggregation (QAG-merged).

Shared by:
  - export_review_data.py  → review_data.json (primary; Web expert panel)
  - export_workbench.py    → expert_review_workbench.xlsx (optional offline backup)

Holds: question loading, report indexing, PDF evidence location, 5-tier risk
scoring, and per-question row aggregation. No Excel / openpyxl dependency here.
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

try:
    import fitz  # PyMuPDF
    HAS_PYMUPDF = True
except ImportError:
    HAS_PYMUPDF = False

try:
    from rapidfuzz import fuzz
    HAS_RAPIDFUZZ = True
except ImportError:
    HAS_RAPIDFUZZ = False

SKIP_FILENAMES = {
    "generation_manifest.json", "question_quality_metrics.json",
    "reasoning_path_validation.json", "llm_judge_question_scores.json",
    "usable_ids.json", "usable_question_ids.json", "final_questions.json",
    "selfcheck_results.json", "llm_repair_log.json", "expert_feedback_apply_log.json",
    "review_data.json", "expert_feedback.json",
}


# ─── Data loading ─────────────────────────────────────────────────────────────

def load_questions(input_dir: Path) -> list[dict]:
    questions: list[dict] = []
    for jf in sorted(input_dir.rglob("*.json")):
        if jf.name in SKIP_FILENAMES or "reports" in jf.parts or "rejected" in jf.parts:
            continue
        try:
            data = json.loads(jf.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            continue
        if isinstance(data, dict) and "id" in data:
            data["_file_path"] = str(jf)
            questions.append(data)
        elif isinstance(data, list):
            continue  # one-question-per-file
    return questions


def load_report(path: Path) -> dict:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}


def index_report_by_id(report) -> dict[str, dict]:
    """Index a report by question id.

    Accepts both the merged dict-form ({"questions": [...]}) and the legacy
    v1 list-form (top-level list of result dicts).
    """
    if isinstance(report, dict):
        items = report.get("questions") or []
    elif isinstance(report, list):
        items = report
    else:
        items = []
    return {q["id"]: q for q in items if isinstance(q, dict) and "id" in q}


# ─── PDF evidence extraction ──────────────────────────────────────────────────

_pdf_cache: dict[str, Any] = {}

def get_pdf_doc(pdf_dir: Path, filename: str) -> Any:
    if not HAS_PYMUPDF:
        return None
    if filename in _pdf_cache:
        return _pdf_cache[filename]
    candidates = list(pdf_dir.rglob(filename))
    if not candidates:
        _pdf_cache[filename] = None
        return None
    try:
        doc = fitz.open(str(candidates[0]))
        _pdf_cache[filename] = doc
        return doc
    except Exception:
        _pdf_cache[filename] = None
        return None


_DASHES = "–—‐‑‒―−﹘﹣－"  # unicode 破折号/连字符
_DASH_RE = re.compile("[" + re.escape(_DASHES) + "]")


def _norm(s: str) -> str:
    """匹配用归一化：统一破折号、修复 PDF 换行断词、压缩空白、小写。"""
    s = s or ""
    s = _DASH_RE.sub("-", s)
    s = re.sub(r"-\s*\n\s*", "", s)   # 断词换行：metasur-\nface -> metasurface
    s = re.sub(r"\s+", " ", s)
    return s.strip().lower()


def _squeeze(s: str) -> str:
    """极简化：只保留字母/数字/中日韩字，消除所有空格/标点/破折号差异。"""
    return re.sub(r"[^0-9a-z一-鿿]", "", _norm(s))


def is_pdf_name(s: str) -> bool:
    return bool(s) and str(s).lower().endswith(".pdf")


def find_evidence_in_pdf(pdf_dir: Path, source_file: str, evidence_text: str) -> dict:
    """Locate evidence text in a PDF. Returns {page, surrounding_context, found}.

    三级匹配，逐级放宽，消除"语义/数值正确但逐字匹配失败"的假 HIGH：
      1) 归一化(破折号/断词/空白)后取前缀子串匹配；
      2) 去掉全部空格与标点后的子串包含——消除空格/换行/破折号/断词差异；
      3) rapidfuzz 模糊比对(partial_ratio >= 90)——容忍 LLM 轻微改写/格式漂移。
    任一命中即视为找到。中文证据 vs 英文 PDF 等真正不匹配仍会 not found。
    """
    if not evidence_text or not source_file:
        return {"page": "", "surrounding_context": "", "found": False}
    doc = get_pdf_doc(pdf_dir, source_file)
    if doc is None:
        return {"page": "", "surrounding_context": "", "found": False}
    ev_norm = _norm(evidence_text)
    ev_sq = _squeeze(evidence_text)
    ev_probe = ev_norm[:200]
    for page_num in range(len(doc)):
        page = doc[page_num]
        page_text = page.get_text("text")
        page_norm = _norm(page_text)
        hit = False
        for length in (120, 80, 50, 30):
            key = ev_norm[:length]
            if key and key in page_norm:
                hit = True
                break
        if not hit and len(ev_sq) >= 24 and ev_sq[:120] in _squeeze(page_text):
            hit = True
        if not hit and HAS_RAPIDFUZZ and len(ev_probe) >= 20:
            if fuzz.partial_ratio(ev_probe, page_norm) >= 90:
                hit = True
        if hit:
            idx = page_text.find(evidence_text[:30].strip())
            if idx == -1:
                idx = 0
            start = max(0, idx - 200)
            end = min(len(page_text), idx + 500)
            context = page_text[start:end].replace("\n", " ").strip()
            return {"page": page_num + 1, "surrounding_context": context[:800], "found": True}
    return {"page": "", "surrounding_context": "", "found": False}


# ─── Risk level calculation (5-tier) ──────────────────────────────────────────

def compute_risk_level(q: dict, quality: dict, path_val: dict, judge: dict, selfcheck: dict) -> str:
    num_hall = quality.get("numeric_hallucination_count", 0)
    ev_score = quality.get("evidence_grounding_score", 1.0)
    kp_score = quality.get("kp_quality_score", 1.0)
    path_score = path_val.get("path_grounding_score", 1.0)
    path_warnings = path_val.get("warnings") or []
    judge_pass = judge.get("pass", True)
    judge_flags = judge.get("flags") or []
    judge_overall = judge.get("overall", 5.0)
    hop = q.get("hop_count") or 0
    gold_ev = q.get("gold_evidence") or []
    answer = (q.get("ground_truth") or {}).get("answer") or ""
    selfcheck_issues = selfcheck.get("issues") or []

    # CRITICAL
    if not gold_ev or not answer:
        return "CRITICAL"
    if "UNANSWERABLE" in judge_flags and not judge_pass:
        return "CRITICAL"
    if "SOURCE_MISMATCH" in judge_flags:
        return "CRITICAL"
    if "MECHANISM_MISMATCH" in judge_flags:
        return "CRITICAL"
    if num_hall >= 2:
        return "CRITICAL"
    if "LOW_PATH_NODE_GROUNDING" in path_warnings and hop >= 3:
        return "CRITICAL"
    if selfcheck_issues:
        return "CRITICAL"

    # HIGH
    if num_hall == 1:
        return "HIGH"
    if ev_score < 0.6:
        return "HIGH"
    if "EVIDENCE_RISK" in judge_flags:
        return "HIGH"
    if "NUMERIC_RISK" in judge_flags:
        return "HIGH"
    if path_score < 0.6 and path_warnings:
        return "HIGH"

    # MEDIUM
    if kp_score < 0.75:
        return "MEDIUM"
    if judge_overall < 3.8:
        return "MEDIUM"
    if "KP_RISK" in judge_flags:
        return "MEDIUM"
    if "DUPLICATE_RISK" in judge_flags:
        return "MEDIUM"

    # LOW
    if judge_flags:
        return "LOW"
    if path_warnings:
        return "LOW"

    return "PASS"


# ─── Per-question row aggregation ─────────────────────────────────────────────

def build_rows(
    questions: list[dict],
    quality_idx: dict[str, dict],
    path_idx: dict[str, dict],
    judge_idx: dict[str, dict],
    selfcheck_idx: dict[str, dict],
    pdf_dir: Path,
) -> list[dict]:
    rows: list[dict] = []
    for q in questions:
        qid = q.get("id", "UNKNOWN")
        meta = q.get("annotation_meta") or {}
        quality = quality_idx.get(qid, {})
        path_val = path_idx.get(qid, {})
        judge = judge_idx.get(qid, {})
        selfcheck = selfcheck_idx.get(qid, {})
        judge_data = judge.get("judge") or {}

        risk_level = compute_risk_level(q, quality, path_val, judge_data, selfcheck)

        ev_items_full: list[dict] = []
        node_evidence_map: dict[str, str] = {}
        for pne in (q.get("path_node_evidence") or []):
            for eid in (pne.get("evidence_ids") or []):
                node_evidence_map[eid] = pne.get("node", "")

        for ev in q.get("gold_evidence") or []:
            source_file = ev.get("source_file") or (
                ev.get("source_uid") if is_pdf_name(ev.get("source_uid", "")) else ""
            )
            ev_text = ev.get("text") or ""
            pdf_info = {"page": "", "surrounding_context": "", "found": False}
            if source_file and pdf_dir.exists():
                pdf_info = find_evidence_in_pdf(pdf_dir, source_file, ev_text)
            eid = ev.get("evidence_id") or ""
            ev_items_full.append({
                "evidence_id": eid,
                "source_kind": ev.get("source_kind") or "",
                "source_file": source_file,
                "source_uid": ev.get("source_uid") or "",
                "text": ev_text,
                "page": pdf_info["page"],
                "surrounding_context": pdf_info["surrounding_context"],
                "pdf_found": pdf_info["found"],
                "used_in_gold": True,
                "bound_node": node_evidence_map.get(eid, ""),
            })

        gold_ev_ids = {e["evidence_id"] for e in ev_items_full}
        for card in meta.get("evidence_cards") or []:
            eid = card.get("evidence_id") or ""
            if eid not in gold_ev_ids:
                ev_items_full.append({
                    "evidence_id": eid,
                    "source_kind": card.get("source_kind") or "",
                    "source_file": card.get("source_file") or "",
                    "source_uid": card.get("source_uid") or "",
                    "text": card.get("text") or card.get("content") or "",
                    "page": "",
                    "surrounding_context": "",
                    "pdf_found": False,
                    "used_in_gold": False,
                    "bound_node": node_evidence_map.get(eid, ""),
                })

        pdf_not_found_ids = [
            ev["evidence_id"] for ev in ev_items_full
            if ev.get("source_kind") == "external_pdf"
            and ev.get("used_in_gold")
            and not ev.get("pdf_found")
            and ev.get("evidence_id")
        ]
        pdf_not_found = bool(pdf_not_found_ids)
        if pdf_not_found and risk_level in ("PASS", "LOW", "MEDIUM"):
            risk_level = "HIGH"

        row: dict = {
            "question_id": qid,
            "file_path": q.get("_file_path", ""),
            "difficulty_level": q.get("difficulty_level", ""),
            "hop_count": q.get("hop_count"),
            "domain": q.get("domain", ""),
            "intent": q.get("intent", ""),
            "source_mode": meta.get("source_mode") or q.get("source_mode") or "",
            "risk_level": risk_level,
            "risk_tags": list({
                *quality.get("risk_tags", []),
                *judge_data.get("flags", []),
                *(["PDF_EXACT_QUOTE_NOT_FOUND"] if pdf_not_found else []),
            }),
            "question": q.get("question", ""),
            "answer": (q.get("ground_truth") or {}).get("answer", ""),
            "key_points": (q.get("ground_truth") or {}).get("key_points") or [],
            "expected_path_nodes": q.get("expected_path_nodes") or [],
            "recommended_papers": q.get("recommended_papers") or [],
            "source_pdf_files": list({
                e.get("source_file") or (e.get("source_uid") if is_pdf_name(e.get("source_uid", "")) else "")
                for e in (q.get("gold_evidence") or [])
                if e.get("source_file") or is_pdf_name(e.get("source_uid", ""))
            }),
            "pdf_quote_found": not pdf_not_found,
            "pdf_not_found_evidence_ids": pdf_not_found_ids,
            "selfcheck_status": selfcheck.get("status", ""),
            "selfcheck_issues": selfcheck.get("issues") or [],
            "selfcheck_warnings": selfcheck.get("warnings") or [],
            "evidence_grounding_score": quality.get("evidence_grounding_score", ""),
            "numeric_hallucination_count": quality.get("numeric_hallucination_count", ""),
            "unsupported_numbers": quality.get("unsupported_numbers") or [],
            "kp_quality_score": quality.get("kp_quality_score", ""),
            "kp_violations": quality.get("kp_violations") or [],
            "path_grounding_score": path_val.get("path_grounding_score", ""),
            "path_warnings": path_val.get("warnings") or [],
            "judge_overall": judge_data.get("overall", ""),
            "judge_pass": judge_data.get("pass", True),
            "judge_flags": judge_data.get("flags") or [],
            "judge_comments": judge_data.get("comments", ""),
            "judge_suggestions": judge_data.get("suggestions") or [],
            "repair_priority": judge_data.get("repair_priority", ""),
            "expert_focus": judge_data.get("expert_focus") or [],
            "evidence_items": ev_items_full[:3],
            "evidence_items_full": ev_items_full,
        }
        rows.append(row)

    order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "PASS": 4}
    rows.sort(key=lambda r: order.get(r["risk_level"], 5))
    return rows


def load_all_reports(report_dir: Path, pfx: str) -> tuple[dict, dict, dict, dict]:
    """Return (quality_idx, path_idx, judge_idx, selfcheck_idx)."""
    quality_idx = index_report_by_id(load_report(report_dir / f"{pfx}question_quality_metrics.json"))
    path_idx = index_report_by_id(load_report(report_dir / f"{pfx}reasoning_path_validation.json"))
    judge_idx = index_report_by_id(load_report(report_dir / f"{pfx}llm_judge_question_scores.json"))
    selfcheck_idx = index_report_by_id(load_report(report_dir / f"{pfx}selfcheck_results.json"))
    return quality_idx, path_idx, judge_idx, selfcheck_idx
