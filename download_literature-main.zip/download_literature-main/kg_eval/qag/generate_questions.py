#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""QAG root-level question generation entry.

This is a thin, user-friendly wrapper around pipline/auto_generate_v3.py.
Experts usually only need to put PDFs into QAG/extern_data and run this file.
"""

from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path

QAG_DIR = Path(__file__).resolve().parent
REPO_ROOT = QAG_DIR.parent
GENERATOR = QAG_DIR / "pipline" / "auto_generate_v3.py"
DEFAULT_EXTERN_DIR = QAG_DIR / "extern_data"
DEFAULT_OUTPUT_DIR = QAG_DIR / "output"


def main() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    parser = argparse.ArgumentParser(
        description="QAG 出题脚本：读取内部 KB / 外部 PDF / 混合来源，生成标准 JSON 题目。"
    )
    parser.add_argument("--source", choices=["internal", "external", "mixed"], default="mixed",
                        help="数据来源：internal=内部KB，external=专家PDF，mixed=KB+PDF混合。")
    parser.add_argument("--paper-range", default="1-3",
                        help="每道题读取的文章数量，例如 1、2、2-3、auto。")
    parser.add_argument("--hops", default="1,2,3",
                        help="跳数长度，例如 1、2、3、4、1,2,3。")
    parser.add_argument("--question-types", default="",
                        help="Question type independent from hops: factual,multi_hop,synthesis,creative or L1,L2,L3,L4.")
    parser.add_argument("--domains", default="FABS,HCFG,MECH,POPT",
                        help="出题领域，逗号分隔：FABS,HCFG,MECH,POPT。")
    parser.add_argument("--num-per-domain", type=int, default=2,
                        help="每个领域、每个 hop 生成几道题。")
    parser.add_argument("--extern-dir", default=str(DEFAULT_EXTERN_DIR),
                        help="专家 PDF 目录，默认 QAG/extern_data。")
    parser.add_argument("--kb-db", default=None,
                        help="内部 kb.db 路径；不填则自动查找 QAG/intern_data 或项目默认 KB。")
    parser.add_argument("--output-dir", default=str(DEFAULT_OUTPUT_DIR),
                        help="题目输出目录，默认 QAG/output。")
    parser.add_argument("--start-index", type=int, default=0,
                        help="题号起始序号；0 表示自动接在现有题目之后。")
    parser.add_argument("--dry-run", action="store_true",
                        help="只查看选文与参数计划，不调用模型、不生成题目。")
    parser.add_argument("--api-key", default=None,
                        help="LLM API key（覆盖环境变量 QAG_API_KEY / OPENAI_API_KEY）。")
    parser.add_argument("--llm-base-url", default=None,
                        help="LLM base URL，例如 http://43.153.42.7:3001/v1。")
    parser.add_argument("--llm-model", default=None,
                        help="LLM 模型名称，例如 claude-sonnet-4-6。")
    args, passthrough = parser.parse_known_args()

    cmd = [
        sys.executable,
        str(GENERATOR),
        "--source", args.source,
        "--paper-range", args.paper_range,
        "--hops", args.hops,
        "--question-types", args.question_types,
        "--domains", args.domains,
        "--num-per-domain", str(args.num_per_domain),
        "--extern-dir", args.extern_dir,
        "--output-dir", args.output_dir,
        "--start-index", str(args.start_index),
    ]
    if args.kb_db:
        cmd += ["--kb-db", args.kb_db]
    if args.dry_run:
        cmd.append("--dry-run")
    if args.api_key:
        cmd += ["--api-key", args.api_key]
    if args.llm_base_url:
        cmd += ["--llm-base-url", args.llm_base_url]
    if args.llm_model:
        cmd += ["--llm-model", args.llm_model]
    cmd += passthrough

    print("[QAG-GENERATE] " + " ".join(cmd))
    env = os.environ.copy()
    env.setdefault("PYTHONIOENCODING", "utf-8")
    env.setdefault("PYTHONUTF8", "1")
    subprocess.run(cmd, check=True, cwd=str(REPO_ROOT), env=env)


if __name__ == "__main__":
    main()
