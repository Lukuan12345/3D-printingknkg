#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""QAG root-level question review entry.

This is a friendly wrapper around pipline/evaluation.py. By default it runs all
local checks and export steps. Add --with-llm-judge to call GPT5.5 for review.
"""

from __future__ import annotations

import argparse
import fnmatch
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

QAG_DIR = Path(__file__).resolve().parent
REPO_ROOT = QAG_DIR.parent
EVALUATOR = QAG_DIR / "pipline" / "evaluation.py"
DEFAULT_INPUT_DIR = QAG_DIR / "output"
DEFAULT_REPORT_DIR = QAG_DIR / "output" / "reports"


def main() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    parser = argparse.ArgumentParser(
        description="QAG 审核脚本：结构自查、质量检测、推理链验证、可选 GPT5.5 审查、导出审查版。"
    )
    parser.add_argument("--input-dir", default=str(DEFAULT_INPUT_DIR),
                        help="待审核题目目录，默认 QAG/output。")
    parser.add_argument("--report-dir", default=str(DEFAULT_REPORT_DIR),
                        help="报告输出目录，默认 QAG/output/reports。")
    parser.add_argument("--no-kb-check", action="store_true",
                        help="结构自检/质量检测时跳过 KB/PDF 接地校验。")
    parser.add_argument("--pdf-dir", default="",
                        help="专家 PDF 目录；不填则用默认 QAG/extern_data。")
    parser.add_argument("--kb-db", default="",
                        help="kb.db 路径；不填则自动查找 QAG/intern_data/kb.db。")
    parser.add_argument("--with-llm-judge", action="store_true",
                        help="调用模型做 8 维 LLM-as-a-Judge 审查。")
    parser.add_argument("--model", default="claude-sonnet-4-6",
                        help="LLM 审查模型，默认 claude-sonnet-4-6。")
    parser.add_argument("--api-key", default="", help="LLM API key（覆盖环境变量）。")
    parser.add_argument("--base-url", default="", help="LLM base url（覆盖环境变量）。")
    parser.add_argument("--limit", type=int, default=0,
                        help="只让 LLM judge 审查前 N 道题；0 表示全部。")
    parser.add_argument("--range", dest="range_spec", default="",
                        help="题目范围，格式 'start-end'（如 20-30）或单整数（如 5，表示前5题）。"
                             "解析后转为 --start + --limit 传给 evaluation.py。")
    parser.add_argument("--id-filter", default="",
                        help="按 id 过滤题。3 种格式：\n"
                             "  - id 区间: 'HCFG-H3-188:HCFG-H3-192'\n"
                             "  - id 列表: 'HCFG-H3-188,HCFG-H3-189'\n"
                             "  - glob: '*HCFG*' 或 'HCFG-H3-1*'\n"
                             "匹配题复制到临时子目录后跑 evaluation.py，跑完删除。")
    parser.add_argument("--only-new", action="store_true",
                        help="仅审核最新出的题：读 input-dir/generation_manifest.json 的 "
                             "question_ids 作为过滤集。与 --id-filter 同给时取交集。")
    parser.add_argument("--report-prefix", default="",
                        help="报告文件名前缀，如 'run1_'。")
    parser.add_argument("--export-markdown", action="store_true",
                        help="额外导出 final_questions_for_review.md（人读友好）。")
    parser.add_argument("--export-expert-workbench", action="store_true",
                        help="额外导出离线 Excel 备份。")
    parser.add_argument("--no-export-review", action="store_true",
                        help="不导出 review_data.json（默认导出，供 Web 专家面板）。")
    args, passthrough = parser.parse_known_args()

    # 解析 --range: "20-30" → start=20, limit=10；"5" → start=0, limit=5
    range_start: int = 0
    range_limit: int = args.limit  # 默认沿用 --limit
    if args.range_spec:
        spec = args.range_spec.strip()
        if "-" in spec:
            parts = spec.split("-", 1)
            try:
                s, e = int(parts[0]), int(parts[1])
                range_start = max(0, s)
                range_limit = max(1, e - s + 1) if e >= s else 1
            except ValueError:
                print(f"[QAG-REVIEW] 警告: --range '{spec}' 格式无法解析，已忽略。", file=sys.stderr)
        else:
            try:
                range_limit = int(spec)
                range_start = 0
            except ValueError:
                print(f"[QAG-REVIEW] 警告: --range '{spec}' 格式无法解析，已忽略。", file=sys.stderr)

    # 解析 --id-filter / --only-new: 创建临时子目录，复制匹配题
    temp_filter_dir: Path | None = None
    actual_input_dir = args.input_dir
    if args.id_filter or args.only_new:
        fspec = args.id_filter.strip()
        # 扫所有题
        all_qids: list[str] = []
        for jf in sorted(Path(args.input_dir).rglob("*.json")):
            if jf.name in {"generation_manifest.json", "question_quality_metrics.json",
                           "reasoning_path_validation.json", "llm_judge_question_scores.json",
                           "selfcheck_results.json", "llm_repair_log.json",
                           "expert_feedback_apply_log.json", "expert_feedback.json",
                           "usable_ids.json", "usable_question_ids.json",
                           "final_questions.json", "review_data.json"}:
                continue
            try:
                d = json.loads(jf.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                continue
            # 跳过非单题 dict（report/列表格式 JSON，如 reports/ 下的产物）
            if not isinstance(d, dict):
                continue
            qid = d.get("id", "")
            if qid:
                all_qids.append(qid)

        # 1) 先按 --id-filter 匹配（未指定则视为全部）
        if fspec:
            matched: list[str] = []
            if ":" in fspec and "," not in fspec:
                # id 区间
                try:
                    start_id, end_id = fspec.split(":", 1)
                    # 用字母序比较（id 形如 DOMAIN-Lx-NNN）
                    for qid in all_qids:
                        if start_id <= qid <= end_id:
                            matched.append(qid)
                except ValueError:
                    pass
            elif "," in fspec:
                # id 列表
                wanted = {s.strip() for s in fspec.split(",") if s.strip()}
                matched = [qid for qid in all_qids if qid in wanted]
            else:
                # glob
                matched = [qid for qid in all_qids if fnmatch.fnmatch(qid, fspec)]
        else:
            matched = list(all_qids)

        # 2) 再按 --only-new 取交集（读 generation_manifest.json）
        if args.only_new:
            man_path = Path(args.input_dir) / "generation_manifest.json"
            new_ids: set[str] = set()
            try:
                man = json.loads(man_path.read_text(encoding="utf-8"))
                new_ids = {str(x) for x in (man.get("question_ids") or [])}
            except (json.JSONDecodeError, OSError, FileNotFoundError):
                print(f"[QAG-REVIEW] ⚠️  --only-new 但未找到/无法读取 {man_path}，"
                      f"回退为不限批次。", file=sys.stderr)
            if new_ids:
                matched = [qid for qid in matched if qid in new_ids]

        desc = []
        if fspec:
            desc.append(f"id-filter '{fspec}'")
        if args.only_new:
            desc.append("only-new")
        desc_str = " + ".join(desc) or "filter"

        if not matched:
            print(f"[QAG-REVIEW] ❌ {desc_str} 没匹配到任何题", file=sys.stderr)
            sys.exit(2)

        # 创建临时子目录复制匹配题
        import time
        temp_filter_dir = Path(args.input_dir) / f"_idfilter_{int(time.time())}"
        temp_filter_dir.mkdir(exist_ok=True)
        for qid in matched:
            src = next((jf for jf in Path(args.input_dir).rglob(f"{qid}.json")
                        if jf.is_file() and not jf.name.startswith("_")), None)
            if src:
                shutil.copy2(src, temp_filter_dir / src.name)
        actual_input_dir = str(temp_filter_dir)
        print(f"[QAG-REVIEW] {desc_str} 匹配 {len(matched)} 题，复制到 {temp_filter_dir}")

    cmd = [
        sys.executable,
        str(EVALUATOR),
        "--input-dir", actual_input_dir,
        "--report-dir", args.report_dir,
    ]
    if args.no_kb_check:
        cmd.append("--no-kb-check")
    if args.pdf_dir:
        cmd += ["--pdf-dir", args.pdf_dir]
    if args.kb_db:
        cmd += ["--kb-db", args.kb_db]
    if args.with_llm_judge:
        cmd += ["--with-llm-judge", "--model", args.model]
    if args.api_key:
        cmd += ["--api-key", args.api_key]
    if args.base_url:
        cmd += ["--base-url", args.base_url]
    if range_start:
        cmd += ["--start", str(range_start)]
    if range_limit:
        cmd += ["--limit", str(range_limit)]
    if args.report_prefix:
        cmd += ["--report-prefix", args.report_prefix]
    if args.export_markdown:
        cmd.append("--export-markdown")
    if args.export_expert_workbench:
        cmd.append("--export-expert-workbench")
    if args.no_export_review:
        cmd.append("--no-export-review")
    cmd += passthrough

    print("[QAG-REVIEW] " + " ".join(cmd))
    env = os.environ.copy()
    env.setdefault("PYTHONIOENCODING", "utf-8")
    env.setdefault("PYTHONUTF8", "1")
    try:
        subprocess.run(cmd, check=True, cwd=str(REPO_ROOT), env=env)
    finally:
        # 清理 id-filter 临时目录
        if temp_filter_dir and temp_filter_dir.exists():
            shutil.rmtree(temp_filter_dir, ignore_errors=True)
            print(f"[QAG-REVIEW] 已清理临时目录 {temp_filter_dir}")


if __name__ == "__main__":
    main()
