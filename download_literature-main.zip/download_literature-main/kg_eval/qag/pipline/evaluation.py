#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Merged QAG review/evaluation pipeline (QAG-merged).

Base: QAG-v2 evaluate.py (calls v2-style audit scripts).
Restored from v1: KB/PDF grounding flags, 8-dim LLM judge, optional Markdown export.
Primary review artifact: review_data.json (consumed by the Web UI expert panel).

Stages:
  1. selfcheck        → {pfx}selfcheck_results.json + {pfx}selfcheck_report.md
  2. check_quality    → {pfx}question_quality_metrics.json + {pfx}quality_report.md
  3. validate_paths   → {pfx}reasoning_path_validation.json + {pfx}path_validation_report.md
  4. llm_judge (opt)  → {pfx}llm_judge_question_scores.json + {pfx}llm_judge_report.md   (8 维)
  5. export review    → {pfx}review_data.json            (Web 专家面板数据，默认开启)
  6. export markdown  → {pfx}final_questions_for_review.md (可选，人读)
  7. export workbench → {pfx}expert_review_workbench.xlsx  (可选，离线 Excel 备份)
"""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

QAG_DIR = Path(__file__).resolve().parent.parent
SCRIPT_DIR = QAG_DIR / "script"
DEFAULT_INPUT_DIR = QAG_DIR / "output"
DEFAULT_REPORT_DIR = QAG_DIR / "output" / "reports"
DEFAULT_PDF_DIR = QAG_DIR / "extern_data"


def run_step(name: str, args: list[str], required: bool = True) -> int:
    print(f"\n[QAG-EVAL] {name}")
    print("[QAG-EVAL] " + " ".join(args))
    result = subprocess.run(args, check=False, cwd=str(QAG_DIR.parent))
    if result.returncode != 0:
        if required:
            print(f"[QAG-EVAL] FATAL: {name} 失败 (exit={result.returncode})", file=sys.stderr)
            sys.exit(result.returncode)
        print(f"[QAG-EVAL] WARN: {name} exit={result.returncode}（非必需，继续）")
    return result.returncode


def main() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    parser = argparse.ArgumentParser(description="QAG-merged 评审流水线")
    parser.add_argument("--input-dir", default=str(DEFAULT_INPUT_DIR), help="题目目录，默认 QAG/output")
    parser.add_argument("--report-dir", default=str(DEFAULT_REPORT_DIR), help="报告输出目录")
    parser.add_argument("--report-prefix", default="", help="报告文件名前缀")
    parser.add_argument("--pdf-dir", default=str(DEFAULT_PDF_DIR), help="专家 PDF 目录（接地 + 证据定位）")
    parser.add_argument("--kb-db", default="", help="kb.db 路径；不填则自动查找 intern_data/kb.db")
    parser.add_argument("--no-kb-check", action="store_true", help="跳过 KB/PDF 接地与来源存在性校验")
    parser.add_argument("--with-llm-judge", action="store_true", help="运行 8 维 LLM-as-a-Judge 审查")
    parser.add_argument("--model", default="claude-sonnet-4-6", help="LLM judge 模型名")
    parser.add_argument("--api-key", default="", help="LLM API key（覆盖环境变量）")
    parser.add_argument("--base-url", default="", help="LLM base url（覆盖环境变量）")
    parser.add_argument("--limit", type=int, default=0, help="只让 LLM judge 审查前 N 道题；0 表示全部")
    parser.add_argument("--start", type=int, default=0, help="LLM judge 从第 N 题开始（0-indexed，配合 --limit 实现范围审查）")
    # Export options
    parser.add_argument("--no-export-review", action="store_true",
                        help="不导出 review_data.json（默认会导出，供 Web 专家面板使用）")
    parser.add_argument("--export-markdown", action="store_true",
                        help="额外导出 final_questions_for_review.md（人读友好）")
    parser.add_argument("--export-expert-workbench", action="store_true",
                        help="额外导出离线 Excel 备份 expert_review_workbench.xlsx")
    parser.add_argument("--workbench-out", default="", help="Excel 输出路径（覆盖默认）")
    args = parser.parse_args()

    input_dir = Path(args.input_dir)
    report_dir = Path(args.report_dir)
    report_dir.mkdir(parents=True, exist_ok=True)
    pfx = args.report_prefix
    py = sys.executable

    base_flags = [
        "--input-dir", str(input_dir),
        "--report-dir", str(report_dir),
        "--report-prefix", pfx,
    ]
    kb_flags = ["--pdf-dir", args.pdf_dir]
    if args.kb_db:
        kb_flags += ["--kb-db", args.kb_db]
    if args.no_kb_check:
        kb_flags += ["--no-kb-check"]

    # Stage 1: selfcheck (uses KB/PDF source-existence check)
    run_step("结构自检", [py, str(SCRIPT_DIR / "selfcheck.py")] + base_flags + kb_flags)

    # Stage 2: check_quality (KB/PDF numeric + evidence grounding)
    run_step("本地质量检测", [py, str(SCRIPT_DIR / "check_quality.py")] + base_flags + kb_flags)

    # Stage 3: validate_paths
    run_step("推理链显式验证", [py, str(SCRIPT_DIR / "validate_paths.py")] + base_flags)

    # Stage 4: LLM judge (optional, non-fatal)
    if args.with_llm_judge:
        judge_cmd = [py, str(SCRIPT_DIR / "llm_judge.py")] + base_flags + [
            "--model", args.model, "--pdf-dir", args.pdf_dir,
        ]
        if args.kb_db:
            judge_cmd += ["--kb-db", args.kb_db]
        if args.limit:
            judge_cmd += ["--limit", str(args.limit)]
        if args.start:
            judge_cmd += ["--start", str(args.start)]
        if args.api_key:
            judge_cmd += ["--api-key", args.api_key]
        if args.base_url:
            judge_cmd += ["--base-url", args.base_url]
        run_step("LLM Judge 八维审查", judge_cmd, required=False)
    else:
        print("\n[QAG-EVAL] 跳过 LLM judge：加 --with-llm-judge 才会调用远程模型")

    # Stage 5: export review_data.json (primary artifact for Web expert panel)
    if not args.no_export_review:
        review_cmd = [py, str(SCRIPT_DIR / "export_review_data.py")] + base_flags + [
            "--pdf-dir", args.pdf_dir,
        ]
        run_step("导出专家审查数据 (review_data.json)", review_cmd, required=False)

    # Stage 6: optional human-readable Markdown
    if args.export_markdown:
        run_step("导出 Markdown 审查稿", [
            py, str(SCRIPT_DIR / "export_final_questions.py"),
            "--input-dir", str(input_dir),
            "--out-json", str(report_dir / f"{pfx}final_questions.json"),
            "--out-md", str(report_dir / f"{pfx}final_questions_for_review.md"),
        ], required=False)

    # Stage 7: optional offline Excel backup
    if args.export_expert_workbench:
        wb_out = args.workbench_out or str(report_dir / f"{pfx}expert_review_workbench.xlsx")
        run_step("导出离线 Excel 备份", [
            py, str(SCRIPT_DIR / "export_workbench.py")] + base_flags + [
            "--pdf-dir", args.pdf_dir, "--out", wb_out,
        ], required=False)

    print(f"\n[QAG-EVAL] 完成。报告目录：{report_dir}")


if __name__ == "__main__":
    main()
