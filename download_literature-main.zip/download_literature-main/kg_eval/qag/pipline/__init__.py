"""Standalone QAG question generation pipeline."""

__version__ = "2.0.0"
