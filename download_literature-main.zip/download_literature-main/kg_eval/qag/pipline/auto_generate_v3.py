#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
QAG end-to-end question generation pipeline.

This is the public entry for automatic question generation. Experts only need
to put PDFs into QAG/extern_data. Internal papers are read from kb.db when the
source mode requires the internal knowledge base.

Examples:
  # External PDF only, expert provides PDFs, generate 2 questions per domain.
  python QAG/pipline/auto_generate_v3.py --source external --hops 4 --domains FABS,HCFG,MECH,POPT --num-per-domain 2

  # Internal KB only, 1-hop factual questions.
  python QAG/pipline/auto_generate_v3.py --source internal --hops 1 --paper-range 1 --num-per-domain 2

  # Mixed KB + external PDFs, 3-hop synthesis questions.
  python QAG/pipline/auto_generate_v3.py --source mixed --hops 3 --paper-range 2-3 --num-per-domain 3

  # Plan only, no LLM call.
  python QAG/pipline/auto_generate_v3.py --source mixed --hops 1,2,3 --dry-run
"""

from __future__ import annotations

import argparse
import json
import os
import random
import re
import sqlite3
import sys
import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

QAG_DIR = Path(__file__).resolve().parent.parent
PROJECT_ROOT = QAG_DIR.parent
EXTERN_DATA_DIR = QAG_DIR / "extern_data"
INTERN_DATA_DIR = QAG_DIR / "intern_data"
OUTPUT_DIR = QAG_DIR / "output"

DEFAULT_KB_CANDIDATES = [
    INTERN_DATA_DIR / "kb.db",
    INTERN_DATA_DIR / "kb_mvp" / "data" / "kb.db",
    PROJECT_ROOT / "literature_knowledge_extractor_new(1)" / "literature_knowledge_extractor_new" / "kb_mvp" / "data" / "kb.db",
    PROJECT_ROOT / "literature_knowledge_extractor_new" / "kb_mvp" / "data" / "kb.db",
    PROJECT_ROOT / "kb_mvp" / "data" / "kb.db",
]

# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------

DEFAULT_LLM_URL = os.environ.get("QAG_LLM_BASE_URL", "http://43.153.42.7:3001/v1")
DEFAULT_LLM_MODEL = os.environ.get("QAG_LLM_MODEL", "claude-sonnet-4-6")
DEFAULT_API_KEY = os.environ.get("QAG_API_KEY") or os.environ.get("OPENAI_API_KEY") or "EMPTY"

DOMAIN_NAME = {
    "FABS": "工艺制备",
    "HCFG": "形态构型",
    "MECH": "物理机理",
    "POPT": "参数优化",
}
DOMAINS = list(DOMAIN_NAME)

DOMAIN_CLASSIFY_KWS: dict[str, list[str]] = {
    "FABS": ["fabricat", "print", "lithograph", "deposit", "screen",
             "inkjet", "etch", "pvd", "sputt", "chemical vapor", "electroplat"],
    "HCFG": ["radome", "conformal", "flexible", "wearable", "curved",
             "low-rcs", "low rcs", "windshield", "stealth", "aircraft", "shape"],
    "MECH": ["mechanism", "resonan", "circuit model", "absorption band",
             "physic", "bic", "bound state", "equivalent circuit", "lumped",
             "loss mechanism"],
    "POPT": ["tunable", "reconfigurable", "optim", "polarization", "phase",
             "parameter", "active", "dynamic", "switchable", "programmable"],
}

TOPIC_KWS = [
    "frequency selective surface", "frequency-selective surface",
    "rasorber", "metamaterial absorber", "fss",
    "metasurface absorb", "absorptive transmissive",
    "electromagnetic absorb", "microwave absorb",
]

QUESTION_TYPE_BY_HOP = {
    1: "factual",
    2: "multi_hop",
    3: "synthesis",
    4: "creative",
}

QUESTION_TYPE_NAME = {
    "factual": "简单事实检索",
    "multi_hop": "多跳逻辑推理",
    "synthesis": "主题概括类",
    "creative": "创新发散题目",
}

QUESTION_TYPE_TO_LEVEL = {
    "factual": "L1",
    "multi_hop": "L2",
    "synthesis": "L3",
    "creative": "L4",
}

QUESTION_TYPE_ALIASES = {
    "factual": "factual",
    "fact": "factual",
    "L1": "factual",
    "l1": "factual",
    "multi_hop": "multi_hop",
    "multihop": "multi_hop",
    "reasoning": "multi_hop",
    "L2": "multi_hop",
    "l2": "multi_hop",
    "synthesis": "synthesis",
    "summary": "synthesis",
    "theme": "synthesis",
    "L3": "synthesis",
    "l3": "synthesis",
    "creative": "creative",
    "innovation": "creative",
    "divergent": "creative",
    "L4": "creative",
    "l4": "creative",
}

DEFAULT_INTENTS = [
    "mechanism",
    "optimization",
    "parameter_effect",
    "fabrication",
    "evolution_summary",
]

SOURCE_ALIASES = {
    "internal": "internal",
    "intern": "internal",
    "内部": "internal",
    "kb": "internal",
    "external": "external",
    "extern": "external",
    "外部": "external",
    "pdf": "external",
    "mixed": "mixed",
    "mix": "mixed",
    "混合": "mixed",
}


@dataclass
class Paper:
    uid: str
    title: str
    text: str
    source_kind: str
    domain: str
    file_name: str = ""


@dataclass
class EvidenceCard:
    evidence_id: str
    source_uid: str
    source_kind: str
    source_title: str
    source_file: str
    exact_quote: str


def banner(title: str) -> None:
    print("\n" + "=" * 78)
    print(f"  {title}")
    print("=" * 78)


def parse_csv(value: str, allowed: set[str] | None = None) -> list[str]:
    items = [x.strip() for x in re.split(r"[,，]", value or "") if x.strip()]
    if allowed:
        bad = [x for x in items if x not in allowed]
        if bad:
            raise ValueError(f"Unsupported values: {bad}; allowed={sorted(allowed)}")
    return items


def parse_hops(value: str) -> list[int]:
    hops = []
    for item in parse_csv(value):
        h = int(item)
        if h < 1:
            raise ValueError("hop length must be >= 1")
        hops.append(h)
    return hops


def parse_question_types(value: str) -> list[str]:
    if not value:
        return []
    out: list[str] = []
    for item in parse_csv(value):
        qtype = QUESTION_TYPE_ALIASES.get(item, item)
        if qtype not in QUESTION_TYPE_TO_LEVEL:
            allowed = sorted(set(QUESTION_TYPE_ALIASES) | set(QUESTION_TYPE_TO_LEVEL))
            raise ValueError(f"Unsupported question type: {item}; allowed={allowed}")
        out.append(qtype)
    return out


def parse_range(value: str, hop: int) -> tuple[int, int]:
    if not value or value.lower() == "auto":
        if hop == 1:
            return 1, 1
        if hop == 2:
            return 2, 3
        return 3, 3
    value = value.replace("~", "-").replace("至", "-").replace("到", "-")
    if "-" in value:
        a, b = [int(x.strip()) for x in value.split("-", 1)]
    else:
        a = b = int(value)
    if a < 1 or b < a:
        raise ValueError(f"Invalid paper range: {value}")
    return a, b


def resolve_kb_path(arg_path: str | None) -> Path | None:
    if arg_path:
        p = Path(arg_path).expanduser()
        return p.resolve() if p.exists() else p
    env_path = os.environ.get("QAG_KB_DB")
    if env_path:
        p = Path(env_path).expanduser()
        return p.resolve() if p.exists() else p
    return next((p for p in DEFAULT_KB_CANDIDATES if p.exists()), None)


def classify_domain(text: str) -> str | None:
    t = (text or "").lower()
    best_domain, best_score = None, 0
    for domain, kws in DOMAIN_CLASSIFY_KWS.items():
        score = sum(1 for kw in kws if kw in t)
        if score > best_score:
            best_domain, best_score = domain, score
    return best_domain if best_score > 0 else None


def build_llm(api_key: str, base_url: str, timeout: float = 180):
    from openai import OpenAI
    return OpenAI(api_key=api_key, base_url=base_url, timeout=timeout)


def fix_json(raw: str) -> str:
    out, in_str, esc = [], False, False
    for ch in raw:
        if esc:
            out.append(ch)
            esc = False
            continue
        if ch == "\\":
            out.append(ch)
            esc = True
            continue
        if ch == '"':
            in_str = not in_str
            out.append(ch)
            continue
        if in_str and ch == "\n":
            out.append("\\n")
            continue
        if in_str and ch == "\r":
            out.append("\\r")
            continue
        if in_str and ch == "\t":
            out.append("\\t")
            continue
        out.append(ch)
    return "".join(out)


def _chat_with_fallback(client, model: str, **kwargs):
    """model 可为 'm1,m2,m3' 有序链；逐个尝试，抛错则降级到下一个模型。

    除 API 异常外，输出被 max_tokens 截断（finish_reason=='length'）也视为失败并降级——
    截断的 JSON 必然解析失败，换个不那么啰嗦的模型往往能完整输出。
    """
    chain = [m.strip() for m in str(model).split(",") if m.strip()] or [model]
    last_exc = None
    for m in chain:
        try:
            resp = client.chat.completions.create(model=m, **kwargs)
            fr = resp.choices[0].finish_reason if resp.choices else None
            if fr == "length":
                raise RuntimeError(f"输出被截断 (finish_reason=length)，疑似 max_tokens 不足")
            return resp
        except Exception as e:  # 模型不可用 / 鉴权 / 限流 / 超时 / 截断 → 降级
            last_exc = e
            print(f"  [FALLBACK] 模型 {m} 调用失败：{e}，尝试下一个", flush=True)
    raise last_exc


def llm_call_json(llm, model: str, system: str, user: str, max_tokens: int = 5000) -> dict:
    prompt = (
        user
        + "\n\n【严格格式要求】只输出一个合法 JSON 对象，不含 Markdown 围栏或说明文字。"
          "字符串内双引号必须转义，JSON 必须完整闭合。"
    )
    for attempt in range(3):
        resp = _chat_with_fallback(
            llm,
            model,
            messages=[{"role": "system", "content": system}, {"role": "user", "content": prompt}],
            temperature=0.25 + 0.1 * attempt,
            max_tokens=max_tokens,
        )
        raw = (resp.choices[0].message.content or "").strip()
        raw = re.sub(r"^```(?:json)?\s*", "", raw)
        raw = re.sub(r"\s*```$", "", raw)
        m = re.search(r"\{[\s\S]*\}", raw)
        if m:
            raw = m.group(0)
        for candidate in (raw, fix_json(raw)):
            try:
                return json.loads(candidate)
            except json.JSONDecodeError:
                pass
        print(f"  [RETRY] JSON parse failed ({attempt + 1}/3)")
    return {}


# ---------------------------------------------------------------------------
# Internal KB loading
# ---------------------------------------------------------------------------

def get_paper_summary(conn: sqlite3.Connection, paper_id: str, title: str, max_chars: int = 2400) -> str:
    rows = conn.execute(
        "SELECT field_type, content FROM paper_chunks WHERE paper_id=?",
        (paper_id,),
    ).fetchall()
    chunks = {r[0]: r[1] for r in rows}
    parts = [f"【标题】{title}"]
    for field, label in [
        ("problem_context", "问题背景"),
        ("physical_mechanism", "物理机理"),
        ("design_method", "设计方法"),
        ("influence_analysis", "参数影响"),
        ("fabrication_process", "工艺过程"),
        ("design_optimization_logic", "优化逻辑"),
    ]:
        text = (chunks.get(field) or "").strip()
        if text:
            parts.append(f"[{label}] {text[:500]}")
    return "\n".join(parts)[:max_chars]


def load_internal_pool(kb_path: Path | None) -> tuple[sqlite3.Connection | None, dict[str, list[Paper]], list[Paper]]:
    if not kb_path or not kb_path.exists():
        return None, {d: [] for d in DOMAINS}, []

    conn = sqlite3.connect(str(kb_path))
    conn.row_factory = sqlite3.Row
    rows = conn.execute(
        "SELECT paper_id, title FROM papers_metadata WHERE domains LIKE '%PJLab%'"
    ).fetchall()
    topic_rows = [
        (r["paper_id"], r["title"] or "")
        for r in rows
        if any(kw in (r["title"] or "").lower() for kw in TOPIC_KWS)
    ]

    groups: dict[str, list[Paper]] = {d: [] for d in DOMAINS}
    fallback: list[Paper] = []
    for pid, title in topic_rows:
        domain = classify_domain(title)
        paper = Paper(
            uid=pid,
            title=title,
            text=get_paper_summary(conn, pid, title),
            source_kind="internal_kb",
            domain=domain or "MECH",
        )
        if domain:
            groups[domain].append(paper)
        else:
            fallback.append(paper)
    random.Random(999).shuffle(fallback)
    return conn, groups, fallback


# ---------------------------------------------------------------------------
# External PDF loading
# ---------------------------------------------------------------------------

def load_external_pdfs(pdf_dir: Path) -> dict[str, list[Paper]]:
    groups: dict[str, list[Paper]] = {d: [] for d in DOMAINS}
    try:
        import fitz
    except Exception as exc:
        print(f"  [WARN] PyMuPDF unavailable, external PDFs cannot be read: {exc}")
        return groups

    if not pdf_dir.exists():
        print(f"  [WARN] external PDF dir not found: {pdf_dir}")
        return groups

    for pdf in sorted(pdf_dir.glob("*.pdf")):
        try:
            data = pdf.read_bytes()
            if not data.startswith(b"%PDF"):
                continue
            doc = fitz.open(stream=data, filetype="pdf")
            text = "\n".join(doc[i].get_text() for i in range(min(10, len(doc))))
            doc.close()
            title = ""
            for line in [x.strip() for x in text.splitlines()[:40] if x.strip()]:
                if len(line) > 18 and not line.lower().startswith(("abstract", "doi", "author", "ieee")):
                    title = line[:220]
                    break
            title = title or pdf.stem
            domain = classify_domain(title) or classify_domain(pdf.stem) or "MECH"
            groups[domain].append(Paper(
                uid=pdf.name,
                title=title,
                text=f"【PDF文件】{pdf.name}\n【标题】{title}\n{text[:5000]}",
                source_kind="external_pdf",
                domain=domain,
                file_name=pdf.name,
            ))
        except Exception as exc:
            print(f"  [SKIP] {pdf.name}: {exc}")

    all_papers = [p for ps in groups.values() for p in ps]
    for domain in DOMAINS:
        if not groups[domain] and all_papers:
            groups[domain] = list(all_papers)
    return groups


def choose(pool: list[Paper], n: int, rng: random.Random, used: set[str], allow_reuse: bool = True) -> list[Paper]:
    candidates = [p for p in pool if p.uid not in used]
    if len(candidates) < n and allow_reuse:
        candidates = list(pool)
    if not candidates:
        return []
    picked = rng.sample(candidates, min(n, len(candidates)))
    used.update(p.uid for p in picked)
    return picked


# ---------------------------------------------------------------------------
# Evidence card extraction
# ---------------------------------------------------------------------------

UNIT_RE = re.compile(
    r"\d+(?:\.\d+)?\s*(?:GHz|MHz|kHz|Hz|dB|dBi|mm|cm|nm|um|%|degree|deg|rad)",
    re.I,
)

EVIDENCE_TERMS = [
    "frequency selective surface", "frequency-selective surface", "fss",
    "rasorber", "absorber", "metasurface", "transmission", "absorption",
    "reflection", "polarization", "bandwidth", "passband", "stopband",
    "switchable", "reconfigurable", "tunable", "graphene", "pin diode",
    "varactor", "equivalent circuit", "fabrication", "measurement",
    "simulation", "rcs", "incidence", "stability", "loss", "mechanism",
]


def compact_text(text: str, max_chars: int = 760) -> str:
    text = re.sub(r"\s+", " ", text or "").strip()
    if len(text) <= max_chars:
        return text
    return text[:max_chars].rsplit(" ", 1)[0].strip()


def split_evidence_windows(text: str) -> list[str]:
    parts = [
        p.strip()
        for p in re.split(r"[\r\n]+|(?<=[.!?;\u3002\uff1b\uff01\uff1f])\s+", text or "")
        if p.strip()
    ]
    windows: list[str] = []
    buf: list[str] = []
    for part in parts:
        if len(part) < 30:
            continue
        if len(part) > 900:
            for i in range(0, len(part), 650):
                piece = compact_text(part[i:i + 760])
                if len(piece) >= 80:
                    windows.append(piece)
            continue
        buf.append(part)
        joined = " ".join(buf)
        if len(joined) >= 260:
            windows.append(compact_text(joined))
            buf = []
    if buf:
        joined = compact_text(" ".join(buf))
        if len(joined) >= 80:
            windows.append(joined)
    return windows


def evidence_score(text: str, domain: str, intent: str) -> int:
    low = text.lower()
    score = 0
    score += min(len(UNIT_RE.findall(text)), 6) * 5
    score += sum(2 for term in EVIDENCE_TERMS if term in low)
    score += sum(3 for term in DOMAIN_CLASSIFY_KWS.get(domain, []) if term in low)
    score += 4 if intent and intent.lower() in low else 0
    score += 3 if re.search(r"\b(because|therefore|indicat|result|show|achiev|due to|whereas)\b", low) else 0
    score += 2 if 140 <= len(text) <= 620 else 0
    return score


def build_evidence_cards(
    papers: list[Paper],
    domain: str,
    intent: str,
    *,
    max_cards_per_paper: int = 6,
    max_cards_total: int = 18,
) -> list[EvidenceCard]:
    candidates: list[tuple[int, int, Paper, str]] = []
    for paper_idx, paper in enumerate(papers):
        windows = split_evidence_windows(paper.text)
        scored = [
            (evidence_score(win, domain, intent), win)
            for win in windows
            if len(win) >= 80
        ]
        scored.sort(key=lambda x: x[0], reverse=True)
        selected = scored[:max_cards_per_paper]
        if len(selected) < max_cards_per_paper:
            selected += scored[max_cards_per_paper:max_cards_per_paper + (max_cards_per_paper - len(selected))]
        for local_rank, (score, win) in enumerate(selected):
            candidates.append((score, paper_idx * 100 + local_rank, paper, win))

    candidates.sort(key=lambda x: (x[0], -x[1]), reverse=True)
    cards: list[EvidenceCard] = []
    seen: set[str] = set()
    for _, _, paper, quote in candidates:
        key = compact_text(quote, 180).lower()
        if key in seen:
            continue
        seen.add(key)
        cards.append(EvidenceCard(
            evidence_id=f"EV-{len(cards) + 1:03d}",
            source_uid=paper.uid,
            source_kind=paper.source_kind,
            source_title=paper.title,
            source_file=paper.file_name,
            quote=compact_text(quote),
        ))
        if len(cards) >= max_cards_total:
            break
    return cards


def render_evidence_cards(cards: list[EvidenceCard]) -> str:
    if not cards:
        return "(no evidence cards extracted)"
    lines = []
    for c in cards:
        lines.append(
            f"{c.evidence_id} | {c.source_kind} | {c.source_uid} | "
            f"{c.source_title[:120]}\nQUOTE: {c.quote}"
        )
    return "\n\n".join(lines)


def normalize_path_nodes(raw_nodes: Any) -> tuple[list[str], list[dict[str, Any]]]:
    nodes: list[str] = []
    links: list[dict[str, Any]] = []
    if not isinstance(raw_nodes, list):
        return nodes, links
    for item in raw_nodes:
        if isinstance(item, dict):
            node = str(item.get("node") or item.get("name") or "").strip()
            evidence_ids = item.get("evidence_ids") or item.get("evidence_id") or []
            if isinstance(evidence_ids, str):
                evidence_ids = [evidence_ids]
            evidence_ids = [str(x).strip() for x in evidence_ids if str(x).strip()]
        else:
            node = str(item).strip()
            evidence_ids = []
        if node:
            nodes.append(node)
            links.append({"node": node, "evidence_ids": evidence_ids})
    return nodes, links


def normalize_evidence_ids(value: Any) -> list[str]:
    if isinstance(value, str):
        return [value.strip()] if value.strip() else []
    if isinstance(value, list):
        return [str(x).strip() for x in value if str(x).strip()]
    return []


# ---------------------------------------------------------------------------
# Prompting and output
# ---------------------------------------------------------------------------

def level_from_hop(hop: int) -> str:
    return f"L{min(hop, 4)}"


def level_from_question_type(qtype: str, hop: int) -> str:
    return QUESTION_TYPE_TO_LEVEL.get(qtype, level_from_hop(hop))


def question_type_from_hop(hop: int) -> str:
    return QUESTION_TYPE_BY_HOP.get(hop, "creative")


def source_mode(source: str) -> str:
    return {"internal": "internal_kb", "external": "external_pdf_only", "mixed": "mixed_kb_pdf"}[source]


NUMERIC_ANCHOR_RE = re.compile(
    r"[-+]?\d+(?:\.\d+)?(?:\s*[-~]\s*[-+]?\d+(?:\.\d+)?)?\s*"
    r"(?:GHz|MHz|kHz|Hz|dB|dBi|mm|cm|m|nm|um|K|%|rad|deg)?",
    re.I,
)

EVIDENCE_SHARED_KWS = [
    "frequency", "selective", "surface", "fss", "rasorber", "absorber",
    "metasurface", "transmission", "absorption", "reflection", "polarization",
    "bandwidth", "passband", "stopband", "unit cell", "equivalent circuit",
    "switchable", "tunable", "reconfigurable", "rcs", "radome",
]


def compact_text(text: str, max_chars: int = 700) -> str:
    text = re.sub(r"\s+", " ", text or "").strip()
    return text[:max_chars].rstrip()


def split_evidence_units(text: str, max_units: int = 260) -> list[str]:
    raw_parts = re.split(r"[\r\n]+|(?<=[.!?;])\s+", text or "")
    units: list[str] = []
    for part in raw_parts:
        part = compact_text(part, 900)
        if len(part) < 45:
            continue
        if len(part) <= 650:
            units.append(part)
        else:
            for i in range(0, len(part), 520):
                chunk = compact_text(part[i:i + 650], 650)
                if len(chunk) >= 45:
                    units.append(chunk)
        if len(units) >= max_units:
            break
    return units


def evidence_score(text: str, domain: str, intent: str) -> float:
    low = text.lower()
    kws = EVIDENCE_SHARED_KWS + DOMAIN_CLASSIFY_KWS.get(domain, []) + [intent.replace("_", " ")]
    score = sum(1.0 for kw in kws if kw and kw.lower() in low)
    score += min(len(NUMERIC_ANCHOR_RE.findall(text)), 4) * 1.2
    if any(kw in low for kw in ("result", "measured", "simulated", "design", "proposed", "shows")):
        score += 1.0
    return score


def build_evidence_cards(
    papers: list[Paper],
    *,
    domain: str,
    intent: str,
    hop: int,
    max_cards: int | None = None,
) -> list[EvidenceCard]:
    max_cards = max_cards or (8 if hop <= 2 else 12)
    candidates: list[tuple[float, int, int, Paper, str]] = []
    for p_idx, paper in enumerate(papers):
        units = split_evidence_units(paper.text)
        for u_idx, unit in enumerate(units):
            windows = [unit]
            if u_idx + 1 < len(units):
                windows.append(compact_text(unit + " " + units[u_idx + 1], 750))
            for window in windows:
                if len(window) < 65:
                    continue
                score = evidence_score(window, domain, intent)
                if score <= 0:
                    continue
                candidates.append((score, p_idx, u_idx, paper, window))

    selected: list[tuple[float, int, int, Paper, str]] = []
    seen_quotes: set[str] = set()
    seen_sources: set[str] = set()

    for candidate in sorted(candidates, key=lambda x: x[0], reverse=True):
        _, _, _, paper, quote = candidate
        key = compact_text(quote, 160).lower()
        if key in seen_quotes:
            continue
        if paper.uid not in seen_sources:
            selected.append(candidate)
            seen_quotes.add(key)
            seen_sources.add(paper.uid)
        if len(selected) >= min(len(papers), max_cards):
            break

    for candidate in sorted(candidates, key=lambda x: x[0], reverse=True):
        _, _, _, _, quote = candidate
        key = compact_text(quote, 160).lower()
        if key in seen_quotes:
            continue
        selected.append(candidate)
        seen_quotes.add(key)
        if len(selected) >= max_cards:
            break

    cards: list[EvidenceCard] = []
    for idx, (_, _, _, paper, quote) in enumerate(selected, start=1):
        cards.append(EvidenceCard(
            evidence_id=f"EV-{idx:03d}",
            source_uid=paper.uid,
            source_kind=paper.source_kind,
            source_title=paper.title,
            source_file=paper.file_name,
            exact_quote=compact_text(quote, 760),
        ))
    return cards


def evidence_card_to_dict(card: EvidenceCard) -> dict[str, str]:
    return {
        "evidence_id": card.evidence_id,
        "source_uid": card.source_uid,
        "source_kind": card.source_kind,
        "source": card.source_title,
        "source_file": card.source_file,
        "text": card.exact_quote,
        "chunk_type": "evidence_card",
    }


def render_evidence_cards(cards: list[EvidenceCard]) -> str:
    if not cards:
        return "(no evidence cards extracted)"
    lines = []
    for card in cards:
        title = compact_text(card.source_title, 160)
        lines.append(
            f"[{card.evidence_id}] source_kind={card.source_kind}; "
            f"source_uid={card.source_uid}; title={title}\n"
            f"quote: {card.exact_quote}"
        )
    return "\n\n".join(lines)


def as_string_list(value: Any) -> list[str]:
    if not value:
        return []
    if isinstance(value, str):
        return [value]
    if isinstance(value, list):
        return [str(x).strip() for x in value if str(x).strip()]
    return [str(value).strip()] if str(value).strip() else []


def normalize_path_nodes(llm_result: dict[str, Any]) -> tuple[list[str], list[dict[str, Any]]]:
    nodes: list[str] = []
    bindings: list[dict[str, Any]] = []
    raw_nodes = llm_result.get("expected_path_nodes") or []
    if not isinstance(raw_nodes, list):
        raw_nodes = [raw_nodes]
    for item in raw_nodes:
        if isinstance(item, dict):
            node = str(item.get("node") or item.get("name") or item.get("text") or "").strip()
            evidence_ids = as_string_list(item.get("evidence_ids") or item.get("gold_evidence_ids"))
        else:
            node = str(item).strip()
            evidence_ids = []
        if node:
            nodes.append(node)
            bindings.append({"node": node, "evidence_ids": evidence_ids})

    extra = llm_result.get("path_node_evidence") or []
    if isinstance(extra, list):
        by_node = {b["node"]: b for b in bindings}
        for item in extra:
            if not isinstance(item, dict):
                continue
            node = str(item.get("node") or item.get("name") or "").strip()
            evidence_ids = as_string_list(item.get("evidence_ids"))
            if not node:
                continue
            if node not in by_node:
                nodes.append(node)
                by_node[node] = {"node": node, "evidence_ids": []}
                bindings.append(by_node[node])
            existing = by_node[node]["evidence_ids"]
            by_node[node]["evidence_ids"] = list(dict.fromkeys(existing + evidence_ids))
    return nodes, bindings


def build_prompt(
    *,
    source: str,
    domain: str,
    hop: int,
    question_type: str | None = None,
    intent: str,
    papers: list[Paper],
) -> tuple[str, str, list[EvidenceCard]]:
    qtype = question_type or question_type_from_hop(hop)
    qtype_name = QUESTION_TYPE_NAME[qtype]
    source_text = "\n\n--- 材料分隔 ---\n\n".join(p.text for p in papers)
    source_desc = {
        "internal": "只允许使用内部知识库文献。",
        "external": "只允许使用专家提供的外部 PDF。专家题不要求命中内部 KB。",
        "mixed": "必须同时使用内部知识库文献和专家外部 PDF。",
    }[source]

    system = (
        "你是电磁超材料、频率选择表面、吸波器和频率选择吸波体领域的 benchmark 出题专家。"
        "你必须生成可评测、证据可追溯、难度与跳数一致的 KGQA 题目。"
    )

    user = f"""【任务】
为 {domain}（{DOMAIN_NAME[domain]}）领域生成 1 道 {qtype_name}。

【出题参数】
- 数据来源：{source}（{source_desc}）
- 推理跳数：{hop}
- 题型：{qtype_name}
- 意图：{intent}
- 使用材料数：{len(papers)}

【材料】
{source_text}

【题型要求】
1. 简单事实检索：答案应由单个证据锚点直接支持，适合 hop=1。
2. 多跳逻辑推理：答案必须串联多个材料或多个知识节点，适合 hop=2。
3. 主题概括类：答案要归纳技术路线、趋势、局限或演化逻辑，适合 hop=3。
4. 创新发散题目：题目应设置真实工程约束，要求提出方案、识别悖论并做边界分析，适合 hop>=4。

【证据与数值铁律】
1. gold_evidence_texts 必须尽量使用材料中的逐字原文短句；如果是专家外部 PDF 的开放推导题，可写“原文证据 + 推导说明”，但不得伪装成内部 KB 证据。
2. 标准答案中的每个具体数值必须来自证据，或在答案中给出清晰计算式。
3. expected_path_nodes 的长度应约等于 hop+1，节点必须来自材料中的概念或由材料直接支持。
4. key_points 遵循“三不原则”：不用代词开头、不用连接词开头、不写多从句长句。
5. mixed 模式下，答案必须同时引用 internal_kb 与 external_pdf 的信息。

【输出 JSON Schema】
{{
  "question": "完整题目",
  "intent": "{intent}",
  "hop_count": {hop},
  "question_type": "{qtype}",
  "expected_path_nodes": ["节点1", "节点2"],
  "evidence_schema": [
    {{"evidence_id": "EV-001", "entity": "对象/结构", "attribute": "参数/现象/约束", "value_or_finding": "原文支持的发现", "role": "problem|method|parameter|mechanism|result|limitation|design_constraint"}}
  ],
  "reasoning_chain": [
    {{"step": 1, "operation": "extract|compare|aggregate|infer|design", "input_evidence_ids": ["EV-001"], "conclusion": "本步推理结论"}}
  ],
  "expected_key_relations": ["FIELD_RELATED", "MECHANISM_EXPLAINS"],
  "ground_truth_answer": "标准答案",
  "key_points": ["要点1", "要点2", "要点3"],
  "gold_evidence_texts": ["证据1", "证据2"]
}}"""
    return system, user


def build_prompt(
    *,
    source: str,
    domain: str,
    hop: int,
    question_type: str | None = None,
    intent: str,
    papers: list[Paper],
) -> tuple[str, str, list[EvidenceCard]]:
    qtype = question_type or question_type_from_hop(hop)
    qtype_name = QUESTION_TYPE_NAME[qtype]
    evidence_cards = build_evidence_cards(papers, domain=domain, intent=intent, hop=hop)
    source_overview = "\n".join(
        f"- {p.source_kind}: {p.uid} | {compact_text(p.title, 160)}"
        for p in papers
    )
    source_desc = {
        "internal": "Use only internal KB evidence cards.",
        "external": "Use only expert-provided external PDF evidence cards; do not require internal-KB hits.",
        "mixed": "Use both internal KB and external PDF evidence cards in the answer.",
    }[source]
    mixed_rule = (
        "Because source=mixed, gold_evidence_ids and path_node_evidence must include at least "
        "one internal_kb card and one external_pdf card."
        if source == "mixed"
        else "No mixed-source requirement for this source mode."
    )

    system = (
        "You are a benchmark question writer for electromagnetic metamaterials, "
        "frequency selective surfaces, absorbers, rasorbers, and related microwave devices. "
        "Write the question, answer, evidence schema, and reasoning chain in Chinese. "
        "Every factual claim must be traceable to the provided evidence-card IDs. "
        "First structure the PDF evidence into schema slots, then build the logic chain, "
        "then create the question and answer from that chain."
    )

    user = f"""Task: Generate 1 {qtype_name} benchmark question for domain {domain}.

Generation parameters:
- source: {source}; {source_desc}
- hop_count: {hop}
- question_type: {qtype}
- intent: {intent}
- number_of_selected_materials: {len(papers)}

Selected materials:
{source_overview}

Evidence cards:
{render_evidence_cards(evidence_cards)}

Required workflow:
1. Extract a structured evidence_schema from the evidence cards.
2. Link schema items into a reasoning_chain.
3. Generate the question from the reasoning_chain.
4. Build the answer by following the chain order.

Rules:
1. Use only the evidence cards above as factual sources. Do not invent citations.
2. The answer may infer or synthesize, but every numeric value must either appear in one selected evidence card or be derived with a clear formula in the answer.
3. expected_path_nodes must contain about hop_count+1 nodes. Each node must include evidence_ids that support it.
4. For L3 synthesis questions, ask for a theme, technical route, trend, limitation, or cross-paper comparison.
5. For L4 creative questions, set a concrete engineering constraint, ask for a design proposal, and require risk/boundary analysis.
6. {mixed_rule}
7. key_points must be short standalone Chinese phrases or sentences. Avoid vague pronouns and long multi-clause wording.
8. Use gold_evidence_ids, not free-form copied evidence. The program will fill exact evidence text from card IDs.
9. Build evidence_schema before writing the answer. Each schema item must extract entity, attribute, value_or_finding, role, and evidence_id from one card.
10. Build reasoning_chain after evidence_schema. Each step must name its operation, input evidence IDs, and conclusion.
11. The final answer must explicitly follow the reasoning_chain order: evidence observation -> comparison/synthesis -> conclusion/proposal.

Output JSON Schema:
{{
  "question": "完整中文题目",
  "intent": "{intent}",
  "hop_count": {hop},
  "question_type": "{qtype}",
  "evidence_schema": [
    {{"evidence_id": "EV-001", "entity": "对象/结构", "attribute": "参数/现象/约束", "value_or_finding": "原文支持的发现", "role": "problem|method|parameter|mechanism|result|limitation|design_constraint"}}
  ],
  "reasoning_chain": [
    {{"step": 1, "operation": "extract|compare|aggregate|infer|design", "input_evidence_ids": ["EV-001"], "conclusion": "本步推理结论"}}
  ],
  "expected_path_nodes": [
    {{"node": "节点1", "evidence_ids": ["EV-001"]}},
    {{"node": "节点2", "evidence_ids": ["EV-002"]}}
  ],
  "path_node_evidence": [
    {{"node": "节点1", "evidence_ids": ["EV-001"]}},
    {{"node": "节点2", "evidence_ids": ["EV-002"]}}
  ],
  "expected_key_relations": ["FIELD_RELATED", "MECHANISM_EXPLAINS"],
  "ground_truth_answer": "中文标准答案（每个数值标注来源EV-XXX）",
  "key_points": ["要点1", "要点2", "要点3"],
  "gold_evidence_ids": ["EV-001", "EV-002"],
  "mechanism_notes": {{"primary_mechanism": "核心物理机制(如偶极子共振)","source_paper_uid": "论文文件名","cross_reference_warning": "若不适配跨文献引用请注明原因"}}
}}"""
    return system, user, evidence_cards


def assemble_question(
    *,
    qid: str,
    source: str,
    domain: str,
    hop: int,
    intent: str,
    papers: list[Paper],
    model: str,
    llm_result: dict[str, Any],
) -> dict[str, Any]:
    qtype = llm_result.get("question_type") or question_type_from_hop(hop)
    level = level_from_question_type(qtype, hop)
    return {
        "id": qid,
        "task_type": "kgqa_question_generation",
        "domain": domain,
        "domain_name": DOMAIN_NAME[domain],
        "difficulty_level": level,
        "difficulty_name": f"{level}-{QUESTION_TYPE_NAME.get(qtype, qtype)}",
        "difficulty": {"L1": "easy", "L2": "medium", "L3": "hard", "L4": "expert"}[level],
        "intent": llm_result.get("intent", intent),
        "hop_count": int(llm_result.get("hop_count", hop)),
        "question_type": qtype,
        "question": llm_result.get("question", ""),
        "recommended_papers": [p.title for p in papers],
        "expected_path_nodes": llm_result.get("expected_path_nodes", []),
        "expected_key_relations": llm_result.get("expected_key_relations", []),
        "gold_evidence": [
            {
                "text": text,
                "source": papers[min(i, len(papers) - 1)].title if papers else "",
                "source_kind": papers[min(i, len(papers) - 1)].source_kind if papers else "",
                "chunk_type": "paragraph",
            }
            for i, text in enumerate(llm_result.get("gold_evidence_texts", []))
        ],
        "ground_truth": {
            "answer": llm_result.get("ground_truth_answer", ""),
            "key_points": llm_result.get("key_points", []),
            "acceptable_variants": [],
        },
        "annotation_meta": {
            "generated_by": "QAG/pipline/auto_generate_v3.py",
            "model": model,
            "timestamp": datetime.now().isoformat(timespec="seconds"),
            "source": source,
            "source_mode": source_mode(source),
            "source_paper_uids": [p.uid for p in papers],
            "source_file_names": [p.file_name for p in papers if p.file_name],
            "annotation_notes": "Generated by standalone QAG pipeline.",
        },
    }


def assemble_question(
    *,
    qid: str,
    source: str,
    domain: str,
    hop: int,
    intent: str,
    papers: list[Paper],
    model: str,
    llm_result: dict[str, Any],
    evidence_cards: list[EvidenceCard] | None = None,
) -> dict[str, Any]:
    qtype = llm_result.get("question_type") or question_type_from_hop(hop)
    level = level_from_question_type(qtype, hop)
    path_nodes, path_node_evidence = normalize_path_nodes(llm_result)
    evidence_cards = evidence_cards or []
    card_map = {c.evidence_id: c for c in evidence_cards}
    valid_ids = set(card_map)

    for binding in path_node_evidence:
        binding["evidence_ids"] = [eid for eid in binding.get("evidence_ids", []) if eid in valid_ids]

    gold_ids = as_string_list(llm_result.get("gold_evidence_ids"))
    if not gold_ids:
        for binding in path_node_evidence:
            gold_ids.extend(binding.get("evidence_ids", []))
    gold_ids = list(dict.fromkeys(eid for eid in gold_ids if eid in valid_ids))

    gold_evidence = [evidence_card_to_dict(card_map[eid]) for eid in gold_ids]
    if not gold_evidence:
        for i, text in enumerate(llm_result.get("gold_evidence_texts", [])):
            gold_evidence.append({
                "text": text,
                "source": papers[min(i, len(papers) - 1)].title if papers else "",
                "source_kind": papers[min(i, len(papers) - 1)].source_kind if papers else "",
                "chunk_type": "paragraph",
            })

    return {
        "id": qid,
        "task_type": "kgqa_question_generation",
        "domain": domain,
        "domain_name": DOMAIN_NAME[domain],
        "difficulty_level": level,
        "difficulty_name": f"{level}-{QUESTION_TYPE_NAME.get(qtype, qtype)}",
        "difficulty": {"L1": "easy", "L2": "medium", "L3": "hard", "L4": "expert"}[level],
        "intent": llm_result.get("intent", intent),
        "hop_count": int(llm_result.get("hop_count", hop)),
        "question_type": qtype,
        "question": llm_result.get("question", ""),
        "recommended_papers": [p.title for p in papers],
        "expected_path_nodes": path_nodes,
        "path_node_evidence": path_node_evidence,
        "evidence_schema": llm_result.get("evidence_schema", []),
        "reasoning_chain": llm_result.get("reasoning_chain", []),
        "expected_key_relations": llm_result.get("expected_key_relations", []),
        "gold_evidence": gold_evidence,
        "ground_truth": {
            "answer": llm_result.get("ground_truth_answer", ""),
            "key_points": llm_result.get("key_points", []),
            "acceptable_variants": [],
        },
        "annotation_meta": {
            "generated_by": "QAG/pipline/auto_generate_v3.py",
            "model": model,
            "timestamp": datetime.now().isoformat(timespec="seconds"),
            "source": source,
            "source_mode": source_mode(source),
            "source_paper_uids": [p.uid for p in papers],
            "source_file_names": [p.file_name for p in papers if p.file_name],
            "evidence_cards": [evidence_card_to_dict(c) for c in evidence_cards],
            "annotation_notes": "Generated by standalone QAG pipeline with evidence-card grounding.",
        },
    }


def build_prompt(
    *,
    source: str,
    domain: str,
    hop: int,
    question_type: str | None = None,
    intent: str,
    papers: list[Paper],
) -> tuple[str, str, list[EvidenceCard]]:
    qtype = question_type or question_type_from_hop(hop)
    evidence_cards = build_evidence_cards(papers, domain=domain, intent=intent, hop=hop, max_cards=8)
    source_desc = {
        "internal": "Only use internal KB evidence cards.",
        "external": "Only use expert PDF evidence cards. Internal KB coverage is not required.",
        "mixed": "Use both internal KB and expert PDF evidence cards.",
    }[source]
    mixed_rule = (
        "For mixed source, select at least one internal_kb evidence ID and one external_pdf evidence ID."
        if source == "mixed"
        else "No mixed-source coverage requirement."
    )
    source_overview = "\n".join(
        f"- {p.source_kind}: {p.uid} | {compact_text(p.title, 140)}"
        for p in papers
    )
    system = (
        "You write Chinese KGQA benchmark questions for electromagnetic metamaterials, "
        "frequency selective surfaces, absorbers, rasorbers, and microwave devices. "
        "Return one compact valid JSON object only. Do not use markdown.\n"
        "CRITICAL: You MUST ground every answer to specific evidence-card IDs. "
        "Every number in the answer MUST be traceable to an evidence card.\n"
        "CRITICAL: Mechanism consistency -- a physical mechanism from paper A (e.g. dipole resonance) "
        "must NOT be misapplied to paper B's structure (e.g. FSS array) unless both papers "
        "describe the SAME physical phenomenon. Check domain/context before cross-referencing."
    )
    user = f"""Generate one Chinese benchmark question.

Parameters:
- domain: {domain}
- source: {source}; {source_desc}
- hop_count: {hop}
- question_type: {qtype}
- intent: {intent}

Selected materials:
{source_overview}

Evidence cards:
{render_evidence_cards(evidence_cards)}

Hard rules:
1. Use only evidence IDs from the evidence cards above. Never fabricate evidence.
2. Do not copy or invent long evidence text. Only return evidence IDs.
3. expected_path_nodes must have exactly hop_count + 1 nodes (L1=2, L2=3, L3=4, L4=5).
4. Each path node MUST be linked to evidence_ids.
5. {mixed_rule}
6. EVERY numeric value in ground_truth_answer MUST be tagged with its source evidence-card ID like [EV-003].
7. For L2 multi-hop (hop_count=2): expected_path_nodes MUST have at least 3 nodes bridging at least 2 different source_uid papers.
8. For synthesis questions (hop_count>=3), ask for trend/route/comparison/limitation summary.
9. For creative questions (hop_count>=4), ask for a design proposal under concrete constraints plus risk analysis.
10. MECHANISM CONSISTENCY RULE: physical mechanisms (e.g. dipole resonance, LC resonance, phase cancellation) must only be cited from papers that actually describe them. Do not apply mechanism from paper A to paper B's structure unless both study the same physical phenomenon.

Return exactly this JSON shape:
{{
  "question": "中文题目",
  "intent": "{intent}",
  "hop_count": {hop},
  "question_type": "{qtype}",
  "expected_path_nodes": [
    {{"node": "节点1", "evidence_ids": ["EV-001"]}},
    {{"node": "节点2", "evidence_ids": ["EV-002"]}}
  ],
  "path_node_evidence": [
    {{"node": "节点1", "evidence_ids": ["EV-001"]}},
    {{"node": "节点2", "evidence_ids": ["EV-002"]}}
  ],
  "expected_key_relations": ["FIELD_RELATED", "MECHANISM_EXPLAINS"],
  "ground_truth_answer": "中文标准答案（每个数值标注来源EV-XXX）",
  "key_points": ["要点1", "要点2", "要点3"],
  "gold_evidence_ids": ["EV-001", "EV-002"],
  "mechanism_notes": {{"primary_mechanism": "核心物理机制(如偶极子共振)","source_paper_uid": "论文文件名","cross_reference_warning": "若不适配跨文献引用请注明原因"}}
}}"""
    return system, user, evidence_cards


def _validate_question(q: dict[str, Any]) -> tuple[bool, list[str]]:
    """Validate question quality before saving. Returns (is_valid, warnings)."""
    import re
    warnings = []
    gt = q.get("ground_truth_answer", "") or ""
    evidence_ids = q.get("gold_evidence_ids", [])
    evidence_texts = " ".join(str(e) for e in q.get("gold_evidence", []))
    hop = q.get("hop_count", 1)
    nodes = q.get("expected_path_nodes", [])

    # Rule 1: L2 must have >= 3 path nodes
    if hop == 2 and len(nodes) < 3:
        warnings.append(f"L2_expected_path_nodes只有{len(nodes)}个，应>=3")

    # Rule 2: Every number in answer must reference an EV-ID
    nums = re.findall(r'\b\d+\.?\d*\b', gt)
    ev_ids_found = set(re.findall(r'EV-\d+', gt))
    for n in nums:
        in_evidence = any(n in str(e) for e in evidence_texts)
        if not in_evidence and n not in ev_ids_found:
            warnings.append(f"数值{n}无EV-ID来源且不在evidence中")
            break  # One warning is enough

    # Rule 3: Mechanism consistency - cross-paper mechanisms must reference shared papers
    mech = q.get("mechanism_notes", {})
    if isinstance(mech, dict) and mech.get("cross_reference_warning"):
        warnings.append(f"机制跨文献风险: {mech['cross_reference_warning'][:80]}")

    return len(warnings) == 0 or hop > 1, warnings  # L1 tolerant, L2+ strict

def save_question(q: dict[str, Any], output_dir: Path) -> Path:
    level = q["difficulty_level"]
    qtype = q.get("question_type", "")
    subdir = output_dir / f"{level}_{QUESTION_TYPE_NAME.get(qtype, qtype)}"
    subdir.mkdir(parents=True, exist_ok=True)
    out = subdir / f"{q['id']}.json"
    
    # Run validation
    valid, warnings = _validate_question(q)
    q["_validation_passed"] = valid
    q["_validation_warnings"] = warnings if not valid else []
    
    out.write_text(json.dumps(q, ensure_ascii=False, indent=2), encoding="utf-8")
    return out


def write_manifest(output_dir: Path, records: list[dict[str, Any]], args: argparse.Namespace) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    safe_args = vars(args).copy()
    if "api_key" in safe_args:
        safe_args["api_key"] = "[REDACTED]"
    manifest = {
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "args": safe_args,
        "count": len(records),
        "question_ids": [r["id"] for r in records],
    }
    (output_dir / "generation_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def next_question_index(output_dir: Path) -> int:
    max_idx = 0
    if not output_dir.exists():
        return 1
    for fp in output_dir.rglob("*.json"):
        lowered_parts = {part.lower() for part in fp.parts}
        if fp.name == "generation_manifest.json" or "reports" in fp.parts or any("backup" in part for part in lowered_parts):
            continue
        match = re.search(r"-(\d{3,})\.json$", fp.name)
        if match:
            max_idx = max(max_idx, int(match.group(1)))
    return max_idx + 1


def generate(args: argparse.Namespace) -> list[dict[str, Any]]:
    source = SOURCE_ALIASES[args.source]
    domains = parse_csv(args.domains, set(DOMAINS))
    hops = parse_hops(args.hops)
    explicit_question_types = parse_question_types(args.question_types)
    intents = parse_csv(args.intents) if args.intents else DEFAULT_INTENTS
    output_dir = Path(args.output_dir).resolve() if args.output_dir else OUTPUT_DIR

    kb_path = resolve_kb_path(args.kb_db)

    banner("QAG pipeline configuration")
    print(f"  QAG root:      {QAG_DIR}")
    print(f"  source:        {source}")
    print(f"  domains:       {domains}")
    print(f"  hops:          {hops}")
    print(f"  qtypes:        {explicit_question_types or '(auto by hop, legacy mode)'}")
    print(f"  paper range:   {args.paper_range}")
    print(f"  num/domain:    {args.num_per_domain}")
    print(f"  external PDFs: {args.extern_dir}")
    print(f"  kb.db:         {kb_path if kb_path else '(not used/found)'}")
    print(f"  output:        {output_dir}")
    if args.dry_run:
        print("  dry run:       yes")

    internal_conn = None
    internal_groups = {d: [] for d in DOMAINS}
    fallback_internal: list[Paper] = []
    if source in {"internal", "mixed"}:
        internal_conn, internal_groups, fallback_internal = load_internal_pool(kb_path)
        if not internal_conn:
            raise FileNotFoundError(
                "Internal source requested but kb.db was not found. "
                "Pass --kb-db or set QAG_KB_DB, or copy kb.db into QAG/intern_data/."
            )
        for d in DOMAINS:
            print(f"  internal {d}: {len(internal_groups[d])} papers")

    external_groups = {d: [] for d in DOMAINS}
    if source in {"external", "mixed"}:
        external_groups = load_external_pdfs(Path(args.extern_dir))
        for d in DOMAINS:
            print(f"  external {d}: {len(external_groups[d])} PDFs")

    llm = None if args.dry_run else build_llm(args.api_key, args.llm_base_url, args.timeout)
    rng = random.Random(args.seed)
    used_internal: set[str] = set()
    used_external: set[str] = set()
    records: list[dict[str, Any]] = []
    q_index = args.start_index if args.start_index > 0 else next_question_index(output_dir)

    for hop in hops:
        low, high = parse_range(args.paper_range, hop)
        question_types_for_hop = explicit_question_types or [question_type_from_hop(hop)]
        for domain in domains:
            for local_idx in range(1, args.num_per_domain + 1):
                n_docs = rng.randint(low, high)
                papers: list[Paper] = []
                if source == "internal":
                    pool = internal_groups[domain] or fallback_internal
                    papers = choose(pool, n_docs, rng, used_internal)
                elif source == "external":
                    pool = external_groups[domain]
                    papers = choose(pool, n_docs, rng, used_external)
                else:
                    n_pdf = max(1, min(args.external_per_question, n_docs - 1))
                    n_kb = max(1, n_docs - n_pdf)
                    kb_pool = internal_groups[domain] or fallback_internal
                    pdf_pool = external_groups[domain]
                    papers = (
                        choose(kb_pool, n_kb, rng, used_internal)
                        + choose(pdf_pool, n_pdf, rng, used_external)
                    )
                if not papers:
                    print(f"  [SKIP] {domain} hop={hop}: no usable source material")
                    continue

                qtype = question_types_for_hop[(len(records)) % len(question_types_for_hop)]
                intent = intents[(len(records)) % len(intents)]
                qid = f"{domain}-H{hop}-{q_index:03d}"
                print(f"  [PLAN] {qid} source={source} domain={domain} hop={hop} qtype={qtype} docs={len(papers)} intent={intent}")
                for p in papers:
                    print(f"         - {p.source_kind}: {p.uid} | {p.title[:90]}")
                if args.dry_run:
                    q_index += 1
                    continue

                system, prompt, evidence_cards = build_prompt(
                    source=source,
                    domain=domain,
                    hop=hop,
                    question_type=qtype,
                    intent=intent,
                    papers=papers,
                )
                t0 = time.time()
                result = llm_call_json(llm, args.llm_model, system, prompt)
                if not result or not result.get("question"):
                    print(f"  [WARN] {qid}: LLM returned empty/invalid JSON")
                    continue
                result["question_type"] = qtype
                result["hop_count"] = hop
                q = assemble_question(
                    qid=qid,
                    source=source,
                    domain=domain,
                    hop=hop,
                    intent=intent,
                    papers=papers,
                    model=args.llm_model,
                    llm_result=result,
                    evidence_cards=evidence_cards,
                )
                out = save_question(q, output_dir)
                records.append(q)
                q_index += 1
                print(f"  [SAVE] {out} ({time.time() - t0:.1f}s)")

    if not args.dry_run:
        write_manifest(output_dir, records, args)
    if internal_conn:
        internal_conn.close()
    return records


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Standalone QAG question generation pipeline")
    parser.add_argument(
        "--source",
        default="mixed",
        choices=sorted(SOURCE_ALIASES),
        help="数据来源：internal/内部、external/外部、mixed/混合",
    )
    parser.add_argument("--hops", default="1,2,3", help="跳数长度，如 1 或 1,2,3 或 4")
    parser.add_argument("--paper-range", default="auto", help="每题读取文章/PDF数量，如 1、2-3、auto")
    parser.add_argument("--external-per-question", type=int, default=1, help="mixed 模式下每题至少使用几个外部 PDF")
    parser.add_argument("--domains", default="FABS,HCFG,MECH,POPT", help="出题领域，逗号分隔")
    parser.add_argument("--num-per-domain", type=int, default=1, help="每个领域、每个 hop 生成几题")
    parser.add_argument("--intents", default="", help="意图序列，默认自动轮转")
    parser.add_argument("--extern-dir", default=str(EXTERN_DATA_DIR), help="专家 PDF 目录")
    parser.add_argument("--kb-db", default="", help="内部 kb.db 路径；默认自动查找 QAG/intern_data 或项目 KB")
    parser.add_argument("--output-dir", default=str(OUTPUT_DIR), help="题目输出目录")
    parser.add_argument("--start-index", type=int, default=0, help="题号起始序号；0 表示自动接在现有题目之后")
    parser.add_argument("--question-types", default="", help="Question type is independent from hops: factual,multi_hop,synthesis,creative or L1,L2,L3,L4. Empty keeps legacy auto mapping.")
    parser.add_argument("--seed", type=int, default=20260527)
    parser.add_argument("--api-key", default=DEFAULT_API_KEY)
    parser.add_argument("--llm-base-url", default=DEFAULT_LLM_URL)
    parser.add_argument("--llm-model", default=DEFAULT_LLM_MODEL)
    parser.add_argument("--timeout", type=float, default=180)
    parser.add_argument("--dry-run", action="store_true", help="只打印选文计划，不调用 LLM")
    return parser


def main() -> None:
    parser = build_arg_parser()
    args = parser.parse_args()
    args.source = SOURCE_ALIASES[args.source]
    generate(args)


if __name__ == "__main__":
    main()
