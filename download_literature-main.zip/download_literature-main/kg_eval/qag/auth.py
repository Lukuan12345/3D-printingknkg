#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""auth.py —— QAG Web 服务的账号鉴权 + 每用户工作区。

- 用户库：SQLite <DATA_DIR>/users.db（每次操作开一条连接，线程安全）。
- 密码：werkzeug PBKDF2 哈希（Flask 自带，无新依赖）。
- 会话：Flask 签名 cookie（session["uid"]）。SECRET_KEY 持久化到 <DATA_DIR>/secret_key。
- 工作区：每用户 <WORKSPACE_ROOT>/<uid>/{extern_data, output, output/reports}。

DATA_DIR / WORKSPACE_ROOT 都在服务器本地（非共享盘），保存用户密钥与各自上传数据。
"""

from __future__ import annotations

import os
import re
import sqlite3
from functools import wraps
from pathlib import Path

from flask import jsonify, session
from werkzeug.security import check_password_hash, generate_password_hash

# ── 路径：本地、非共享 ────────────────────────────────────────────────────────
_QAG_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("QAG_DATA_DIR", "").strip() or (_QAG_DIR / ".data"))
WORKSPACE_ROOT = Path(os.environ.get("QAG_WORKSPACE_ROOT", "").strip() or (_QAG_DIR / "workspaces"))
DB_PATH = DATA_DIR / "users.db"
SECRET_KEY_PATH = DATA_DIR / "secret_key"

_USERNAME_RE = re.compile(r"^[A-Za-z0-9_.\-]{3,32}$")


# ── 初始化（幂等）────────────────────────────────────────────────────────────
def _ensure_dirs() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    WORKSPACE_ROOT.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(DATA_DIR, 0o700)
    except OSError:
        pass


def init_db() -> None:
    """建表（幂等）。部署脚本和服务启动都会调用。"""
    _ensure_dirs()
    con = sqlite3.connect(DB_PATH)
    try:
        con.execute(
            "CREATE TABLE IF NOT EXISTS users ("
            " id INTEGER PRIMARY KEY AUTOINCREMENT,"
            " username TEXT UNIQUE NOT NULL,"
            " pw_hash TEXT NOT NULL,"
            " created_at TEXT NOT NULL DEFAULT (datetime('now')))"
        )
        con.commit()
    finally:
        con.close()


def load_secret_key() -> str:
    """读取/生成持久化 SECRET_KEY（缺则生成 32B 随机并 chmod 600）。"""
    _ensure_dirs()
    if SECRET_KEY_PATH.exists():
        val = SECRET_KEY_PATH.read_text(encoding="utf-8").strip()
        if val:
            return val
    val = os.urandom(32).hex()
    SECRET_KEY_PATH.write_text(val, encoding="utf-8")
    try:
        os.chmod(SECRET_KEY_PATH, 0o600)
    except OSError:
        pass
    return val


# ── 用户操作 ──────────────────────────────────────────────────────────────────
def _conn() -> sqlite3.Connection:
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


def create_user(username: str, password: str) -> tuple[bool, str]:
    """返回 (ok, msg)。用户名/密码不合规或重名 → ok=False。"""
    username = (username or "").strip()
    if not _USERNAME_RE.match(username):
        return False, "用户名须为 3-32 位字母/数字/_.-"
    if not password or len(password) < 6:
        return False, "密码至少 6 位"
    init_db()
    con = _conn()
    try:
        con.execute(
            "INSERT INTO users (username, pw_hash) VALUES (?, ?)",
            (username, generate_password_hash(password)),
        )
        con.commit()
        return True, "ok"
    except sqlite3.IntegrityError:
        return False, "用户名已存在"
    finally:
        con.close()


def verify_user(username: str, password: str) -> int | None:
    """校验通过返回 uid，否则 None。"""
    init_db()
    con = _conn()
    try:
        row = con.execute(
            "SELECT id, pw_hash FROM users WHERE username = ?", ((username or "").strip(),)
        ).fetchone()
    finally:
        con.close()
    if row and check_password_hash(row["pw_hash"], password or ""):
        return int(row["id"])
    return None


def get_username(uid: int) -> str:
    con = _conn()
    try:
        row = con.execute("SELECT username FROM users WHERE id = ?", (uid,)).fetchone()
    finally:
        con.close()
    return row["username"] if row else ""


# ── 会话 / 装饰器 ─────────────────────────────────────────────────────────────
def current_uid() -> int | None:
    uid = session.get("uid")
    return int(uid) if uid is not None else None


def login_required(fn):
    @wraps(fn)
    def _wrap(*args, **kwargs):
        if current_uid() is None:
            return jsonify({"error": "unauthorized"}), 401
        return fn(*args, **kwargs)
    return _wrap


# ── 每用户工作区 ──────────────────────────────────────────────────────────────
def user_dirs(uid: int) -> tuple[Path, Path, Path]:
    """返回 (extern_dir, output_dir, report_dir)，惰性创建。uid 来自会话，服务器可信。"""
    base = WORKSPACE_ROOT / str(int(uid))
    extern = base / "extern_data"
    output = base / "output"
    report = output / "reports"
    for d in (extern, output, report):
        d.mkdir(parents=True, exist_ok=True)
    return extern, output, report
