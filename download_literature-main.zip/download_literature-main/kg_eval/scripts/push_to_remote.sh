#!/usr/bin/env bash
# push_to_remote.sh — 在【本地 Windows git-bash】运行：打包 gen_key 代码 → scp 到远程开发机 → 解压。
# 不含权重(走共享盘)、不含 PDF、不含 .env(密钥单独传)。
#
# 用法：
#   bash kg_eval/scripts/push_to_remote.sh            # 打包 + 推送 + 解压
#   bash kg_eval/scripts/push_to_remote.sh --with-env # 额外把本地 .env 传到远程并 chmod 600
#
set -euo pipefail

# ── 配置（按需改）────────────────────────────────────────────────────────────
LOCAL_GENKEY="C:/Users/suyulin/Desktop/search/gen_key"     # 本地规范副本
SSH_TARGET="suyulin-dev.suyulin.ailab-ai4cmp.ws@h.pjlab.org.cn"
REMOTE_BASE="/mnt/shared-storage-user/suyulin"             # 远程部署父目录
REMOTE_GENKEY="${REMOTE_BASE}/gen_key"
TGZ="C:/Users/suyulin/AppData/Local/Temp/gen_key_code.tgz"
SSH_OPTS="-o BatchMode=yes -o ConnectTimeout=20"

WITH_ENV=0
[[ "${1:-}" == "--with-env" ]] && WITH_ENV=1

SRC_PARENT="$(dirname "${LOCAL_GENKEY}")"
GENKEY_NAME="$(basename "${LOCAL_GENKEY}")"

# ── 1. 打代码包（排除权重/PDF/.env/缓存）──────────────────────────────────────
echo "[push] 1/4 打包代码（排除 artifacts/PDF/.env/缓存）..."
rm -f "${TGZ}"
tar --force-local -C "${SRC_PARENT}" \
  --exclude="${GENKEY_NAME}/scientific_kgqa/artifacts" \
  --exclude="${GENKEY_NAME}/kg_eval/qag/extern_data" \
  --exclude="${GENKEY_NAME}/kg_eval/qag/extern_data_aerospace" \
  --exclude="${GENKEY_NAME}/kg_eval/_backup_before_sync" \
  --exclude="${GENKEY_NAME}/.env" \
  --exclude="${GENKEY_NAME}/kb_mvp/index" \
  --exclude='*/__pycache__' --exclude='*.pyc' \
  --exclude='*/.venv' --exclude='*/.git' --exclude='*/workspaces' --exclude='*/.data' \
  -czf "${TGZ}" "${GENKEY_NAME}"
echo "[push] 包大小: $(ls -lh "${TGZ}" | awk '{print $5}')"

# ── 2. scp 上传 ──────────────────────────────────────────────────────────────
echo "[push] 2/4 上传到 ${SSH_TARGET}:${REMOTE_BASE}/ ..."
scp ${SSH_OPTS} "${TGZ}" "${SSH_TARGET}:${REMOTE_BASE}/gen_key_code.tgz"

# ── 3. 远程解压 ──────────────────────────────────────────────────────────────
echo "[push] 3/4 远程解压到 ${REMOTE_GENKEY} ..."
ssh ${SSH_OPTS} "${SSH_TARGET}" "
  set -e
  cd '${REMOTE_BASE}'
  mkdir -p gen_key
  tar -xzf gen_key_code.tgz
  rm -f gen_key_code.tgz
  echo '  已解压。顶层:'; ls '${REMOTE_GENKEY}' | head
"

# ── 4. （可选）传 .env 并 chmod 600 ──────────────────────────────────────────
if [[ "${WITH_ENV}" == "1" && -f "${LOCAL_GENKEY}/.env" ]]; then
  echo "[push] 4/4 上传 .env 并 chmod 600 ..."
  scp ${SSH_OPTS} "${LOCAL_GENKEY}/.env" "${SSH_TARGET}:${REMOTE_GENKEY}/.env"
  ssh ${SSH_OPTS} "${SSH_TARGET}" "chmod 600 '${REMOTE_GENKEY}/.env' && echo '  .env 已设 600(仅本人可读)'"
else
  echo "[push] 4/4 跳过 .env（用 --with-env 传，或登录远程手动创建并 chmod 600）"
fi

echo "[push] 完成。下一步登录远程跑部署："
echo "  ssh ${SSH_TARGET}"
echo "  cd ${REMOTE_GENKEY} && bash kg_eval/scripts/bootstrap_deploy.sh --start"
