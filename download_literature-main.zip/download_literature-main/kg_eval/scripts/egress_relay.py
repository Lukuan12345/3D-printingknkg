#!/usr/bin/env python3
"""egress_relay.py —— 开发机上的多线程出网中转代理。

部署容器网络隔离：连不上公网 LLM 网关，也连不上集群代理 httpproxy-headless。
本服务跑在开发机(内网可达)，把部署容器的 HTTP/HTTPS 请求经集群上游代理转出公网。

为什么不用 pproxy：pproxy 单进程异步，出题的持续大 prompt 会把它阻塞，
导致后续连接超时(表现为 httpcore.ConnectTimeout at http_proxy.py)。
这里用 ThreadingHTTPServer，每连接独立线程，互不阻塞。

转发策略：
- CONNECT(HTTPS 隧道)：先连上游代理，转发 CONNECT，然后双向盲转字节流。
- 普通 HTTP：把整条请求原样转给上游代理(上游是标准 forward proxy，认绝对 URI)。

上游集群代理地址由 setup_proxy.sh 注入的 http_proxy 决定，可用 UPSTREAM_PROXY 覆盖。
监听 0.0.0.0:8080，可用 RELAY_PORT 覆盖。
"""
from __future__ import annotations

import os
import select
import socket
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit


def _upstream() -> tuple[str, int]:
    raw = (os.environ.get("UPSTREAM_PROXY")
           or os.environ.get("http_proxy")
           or os.environ.get("HTTP_PROXY")
           or "http://httpproxy-headless.kubebrain.svc.pjlab.local:3128")
    p = urlsplit(raw if "://" in raw else "http://" + raw)
    return p.hostname, p.port or 3128


UP_HOST, UP_PORT = _upstream()
LISTEN_PORT = int(os.environ.get("RELAY_PORT", "8080"))
BUFSIZE = 65536
CONNECT_TIMEOUT = 30
IO_TIMEOUT = 300


def _pipe(a: socket.socket, b: socket.socket) -> None:
    """双向盲转，任一端关闭即结束。"""
    socks = [a, b]
    try:
        while True:
            r, _, x = select.select(socks, [], socks, IO_TIMEOUT)
            if x or not r:
                break
            for s in r:
                try:
                    data = s.recv(BUFSIZE)
                except OSError:
                    return
                if not data:
                    return
                dst = b if s is a else a
                try:
                    dst.sendall(data)
                except OSError:
                    return
    finally:
        for s in socks:
            try:
                s.close()
            except OSError:
                pass


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "egress-relay/1.0"

    def log_message(self, fmt, *args):  # 静默，避免日志爆量
        pass

    def _connect_upstream(self) -> socket.socket | None:
        try:
            s = socket.create_connection((UP_HOST, UP_PORT), timeout=CONNECT_TIMEOUT)
            s.settimeout(IO_TIMEOUT)
            return s
        except OSError:
            return None

    def do_CONNECT(self):
        up = self._connect_upstream()
        if up is None:
            self.send_error(502, "upstream proxy unreachable")
            return
        # 把 CONNECT 原样转给上游代理，由它建立到目标的隧道
        req = (f"CONNECT {self.path} HTTP/1.1\r\n"
               f"Host: {self.path}\r\n\r\n").encode()
        try:
            up.sendall(req)
            resp = up.recv(BUFSIZE)
        except OSError:
            self.send_error(502, "upstream CONNECT failed")
            up.close()
            return
        if b" 200 " not in resp.split(b"\r\n", 1)[0]:
            try:
                self.connection.sendall(resp)
            except OSError:
                pass
            up.close()
            return
        # 告诉客户端隧道已建立，然后双向盲转
        try:
            self.connection.sendall(b"HTTP/1.1 200 Connection Established\r\n\r\n")
        except OSError:
            up.close()
            return
        self.connection.settimeout(IO_TIMEOUT)
        _pipe(self.connection, up)

    def _do_plain(self):
        up = self._connect_upstream()
        if up is None:
            self.send_error(502, "upstream proxy unreachable")
            return
        # 普通 HTTP：转发绝对 URI 给上游 forward proxy
        body_len = int(self.headers.get("Content-Length", 0) or 0)
        body = self.rfile.read(body_len) if body_len else b""
        lines = [f"{self.command} {self.path} {self.request_version}"]
        for k, v in self.headers.items():
            lines.append(f"{k}: {v}")
        head = ("\r\n".join(lines) + "\r\n\r\n").encode()
        try:
            up.sendall(head + body)
        except OSError:
            self.send_error(502, "upstream send failed")
            up.close()
            return
        # 把上游响应原样回传，直到上游关闭
        self.connection.settimeout(IO_TIMEOUT)
        try:
            while True:
                chunk = up.recv(BUFSIZE)
                if not chunk:
                    break
                self.connection.sendall(chunk)
        except OSError:
            pass
        finally:
            up.close()
        self.close_connection = True

    do_GET = _do_plain
    do_POST = _do_plain
    do_PUT = _do_plain
    do_DELETE = _do_plain
    do_HEAD = _do_plain
    do_PATCH = _do_plain
    do_OPTIONS = _do_plain


def main():
    srv = ThreadingHTTPServer(("0.0.0.0", LISTEN_PORT), Handler)
    srv.daemon_threads = True
    print(f"[egress-relay] listening 0.0.0.0:{LISTEN_PORT} -> upstream {UP_HOST}:{UP_PORT}",
          flush=True)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
