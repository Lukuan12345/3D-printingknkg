#!/usr/bin/env bash
# bootstrap_deploy.sh — idempotent deploy-time setup for the QAG / kg_eval web service.
#                       （出题 · 审核 · 专家审查 · 图谱测评 一体 Flask 服务）
#
# Usage:
#   bash kg_eval/scripts/bootstrap_deploy.sh              # 只做环境准备（装依赖/建目录/校验）
#   bash kg_eval/scripts/bootstrap_deploy.sh --start      # 准备 + 后台 nohup 启动
#   sudo bash kg_eval/scripts/bootstrap_deploy.sh --systemd  # 准备 + 装 systemd 常驻服务（推荐生产）
#
# What it does (all steps are idempotent):
#   1. 创建/复用 Python venv，安装运行依赖（Flask/openai + scientific_kgqa 运行依赖）。
#   2. 校验图谱权重 artifacts 是否可达（共享挂载 → 本地，遵循 eval/config 解析逻辑）。
#   3. 检查 gen_key/.env（LLM / EMBED 凭据）是否就位。
#   4. 创建产物目录 kg_eval/output、kg_eval/qag/output。
#   5. 冒烟校验关键依赖可 import、配置可加载。
#   6. 按需安装 systemd 常驻服务（--systemd），或后台启动（--start），绑定 ${HOST}:${PORT}。
#   7. 打印访问地址 + 防火墙/安全组放行提示。
#
# 单进程约束：服务用进程内全局状态（任务字典 + 后台线程），必须**单进程**运行
#            （Flask app.run threaded=True 单进程多线程），切勿用多 worker 的 gunicorn/uvicorn。
#
# Environment variables (inherit from calling shell or .env):
#   HOST                 default: 0.0.0.0       （监听所有网卡；勿绑内网 IP）
#   PORT                 default: 8000
#   PYTHON               default: python3        （未用 venv 时的解释器）
#   USE_VENV             default: 1              （0 = 用现有/系统解释器，不建 venv）
#   VENV_DIR             default: <gen_key>/.venv
#   KGQA_ARTIFACTS_DIR   optional               （覆盖图谱权重目录；不设则走共享挂载→本地）
#   QAG_DATA_DIR         default: qag/.data      （用户库 users.db + secret_key，本地、非共享）
#   QAG_WORKSPACE_ROOT   default: qag/workspaces （各用户上传/产物工作区，本地、非共享）
#   SERVICE_NAME         default: qag-ui         （systemd 单元名）
#   SERVICE_USER         default: 当前用户        （systemd 运行用户）
#   INTRANET_IP          default: 172.31.54.240  （仅用于打印内网访问地址）

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
KG_EVAL_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"     # .../gen_key/kg_eval
GEN_KEY_ROOT="$(cd "${KG_EVAL_ROOT}/.." && pwd)"   # .../gen_key
SERVER_PY="${KG_EVAL_ROOT}/qag/qag_ui_server.py"

# --------------------------------------------------------------------------
# Help
# --------------------------------------------------------------------------
if [[ "${1:-}" == "-h" || "${1:-}" == "--help" ]]; then
    sed -n '2,/^set -/p' "$0" | grep '^#' | sed 's/^# \{0,1\}//'
    exit 0
fi

MODE="setup"
case "${1:-}" in
    --start)   MODE="start" ;;
    --systemd) MODE="systemd" ;;
    "")        MODE="setup" ;;
    *) echo "[bootstrap_deploy] 未知参数: ${1}（用 -h 看帮助）" >&2; exit 2 ;;
esac

HOST="${HOST:-0.0.0.0}"
PORT="${PORT:-8000}"
PYTHON="${PYTHON:-python3}"
USE_VENV="${USE_VENV:-1}"
VENV_DIR="${VENV_DIR:-${GEN_KEY_ROOT}/.venv}"
SERVICE_NAME="${SERVICE_NAME:-qag-ui}"
SERVICE_USER="${SERVICE_USER:-$(id -un)}"
INTRANET_IP="${INTRANET_IP:-172.31.54.240}"

echo "[bootstrap_deploy] gen_key root : ${GEN_KEY_ROOT}"
echo "[bootstrap_deploy] mode         : ${MODE}"
echo "[bootstrap_deploy] bind         : ${HOST}:${PORT}"

if [[ ! -f "${SERVER_PY}" ]]; then
    echo "[bootstrap_deploy] ERROR: 找不到服务入口 ${SERVER_PY}" >&2
    exit 1
fi

# --------------------------------------------------------------------------
# Step 1: Python venv + 运行依赖
# --------------------------------------------------------------------------
echo "[bootstrap_deploy] Step 1: 准备 Python 环境与依赖..."

if [[ "${USE_VENV}" == "1" ]]; then
    if [[ ! -x "${VENV_DIR}/bin/python" ]]; then
        echo "  创建 venv: ${VENV_DIR}"
        "${PYTHON}" -m venv "${VENV_DIR}"
    else
        echo "  复用已有 venv: ${VENV_DIR}"
    fi
    PY="${VENV_DIR}/bin/python"
else
    PY="$(command -v "${PYTHON}")"
    echo "  使用现有解释器: ${PY}"
fi

"${PY}" -m pip install --upgrade pip >/dev/null

# kg_eval/qag 前端服务依赖
if [[ -f "${KG_EVAL_ROOT}/qag/requirements.txt" ]]; then
    "${PY}" -m pip install -r "${KG_EVAL_ROOT}/qag/requirements.txt"
fi
# scientific_kgqa 运行依赖（图谱问答引擎 + 检索）+ requests（embedding API）
"${PY}" -m pip install \
    pandas numpy scikit-learn rank-bm25 jieba rapidfuzz tqdm pyyaml requests
echo "[bootstrap_deploy] Step 1: 依赖安装完成。"
echo "  注：本地 BGE-M3 embedding 为可选（默认走 EMBED_* API）。如需离线本地模型，"
echo "      另装 'sentence-transformers torch' 并放置/软链 bge-m3 权重。"

# --------------------------------------------------------------------------
# Step 2: 校验图谱权重 artifacts 可达（warn，不致命）
# --------------------------------------------------------------------------
echo "[bootstrap_deploy] Step 2: 校验图谱权重路径..."
export KGQA_ARTIFACTS_DIR="${KGQA_ARTIFACTS_DIR:-}"
ART_OK=0
if cd "${GEN_KEY_ROOT}" && PYTHONPATH="${GEN_KEY_ROOT}" "${PY}" - <<'PYCODE'
import sys
sys.path.insert(0, ".")
from kg_eval.eval import config as c
db, rt = c.DEFAULT_DB_PATH, c.DEFAULT_RETRIEVER_PATH
print(f"  ARTIFACTS_DIR = {c.ARTIFACTS_DIR}")
print(f"  DB        = {db}  exists={db.exists()}")
print(f"  RETRIEVER = {rt}  exists={rt.exists()}")
sys.exit(0 if (db.exists() and rt.exists()) else 3)
PYCODE
then
    ART_OK=1
    echo "[bootstrap_deploy] Step 2: 权重可达。"
else
    echo "[bootstrap_deploy] Step 2: ⚠️ 权重不可达。请确认已挂载共享盘，或设 KGQA_ARTIFACTS_DIR，"
    echo "                    或在网页「图谱测评」页手动填 DB/Retriever 路径。（不阻断部署）"
fi

# --------------------------------------------------------------------------
# Step 3: 检查 .env
# --------------------------------------------------------------------------
echo "[bootstrap_deploy] Step 3: 检查 ${GEN_KEY_ROOT}/.env ..."
if [[ -f "${GEN_KEY_ROOT}/.env" ]]; then
    echo "  .env 存在。"
else
    echo "  ⚠️ 未找到 .env。LLM/审核/图谱测评需要凭据，请创建并至少填："
    echo "     LLM_API_KEY= / LLM_BASE_URL= / LLM_MODEL= （图谱测评/审核）"
    echo "     EMBED_BASE_URL= / EMBED_API_KEY= （可选：跨语言语义匹配）"
fi

# --------------------------------------------------------------------------
# Step 4: 创建产物目录
# --------------------------------------------------------------------------
echo "[bootstrap_deploy] Step 4: 创建产物目录..."
install -d "${KG_EVAL_ROOT}/output"
install -d "${KG_EVAL_ROOT}/qag/output"
echo "[bootstrap_deploy] Step 4: OK。"

# --------------------------------------------------------------------------
# Step 4b: 初始化用户库 + 持久化 SECRET_KEY（幂等；仿示例 init_db/load_jwt_keys）
# --------------------------------------------------------------------------
echo "[bootstrap_deploy] Step 4b: 初始化 users.db + secret_key..."
(
  cd "${KG_EVAL_ROOT}/qag"

  if [[ -n "${QAG_DATA_DIR:-}" ]]; then
    export QAG_DATA_DIR
  fi

  if [[ -n "${QAG_WORKSPACE_ROOT:-}" ]]; then
    export QAG_WORKSPACE_ROOT
  fi

  "${PY}" -c "import auth; auth.init_db(); auth.load_secret_key(); print('  users.db + secret_key OK ->', auth.DATA_DIR)"
)

# --------------------------------------------------------------------------
# Step 5: 冒烟校验
# --------------------------------------------------------------------------
echo "[bootstrap_deploy] Step 5: 冒烟校验依赖与配置..."
"${PY}" -c "import flask, openai, openpyxl, fitz, pandas, sklearn, rank_bm25, jieba, rapidfuzz, requests; print('  关键依赖 import OK')"
echo "[bootstrap_deploy] Step 5: OK。"

START_CMD=( "${PY}" "${SERVER_PY}" --host "${HOST}" --port "${PORT}" )

# --------------------------------------------------------------------------
# Step 6: 启动方式
# --------------------------------------------------------------------------
if [[ "${MODE}" == "systemd" ]]; then
    echo "[bootstrap_deploy] Step 6: 安装 systemd 服务 ${SERVICE_NAME}.service ..."
    if ! command -v systemctl >/dev/null 2>&1; then
        echo "[bootstrap_deploy] ERROR: 无 systemctl，改用 '--start' 后台启动。" >&2
        exit 1
    fi
    UNIT_PATH="/etc/systemd/system/${SERVICE_NAME}.service"
    UNIT_TMP="$(mktemp)"
    ENV_LINE=""
    [[ -n "${KGQA_ARTIFACTS_DIR}" ]]  && ENV_LINE+=$'\n'"Environment=KGQA_ARTIFACTS_DIR=${KGQA_ARTIFACTS_DIR}"
    [[ -n "${QAG_DATA_DIR:-}" ]]      && ENV_LINE+=$'\n'"Environment=QAG_DATA_DIR=${QAG_DATA_DIR}"
    [[ -n "${QAG_WORKSPACE_ROOT:-}" ]] && ENV_LINE+=$'\n'"Environment=QAG_WORKSPACE_ROOT=${QAG_WORKSPACE_ROOT}"
    cat > "${UNIT_TMP}" <<UNIT
[Unit]
Description=QAG / kg_eval web service (出题·审核·图谱测评)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=${SERVICE_USER}
WorkingDirectory=${GEN_KEY_ROOT}
${ENV_LINE}
ExecStart=${PY} ${SERVER_PY} --host ${HOST} --port ${PORT}
Restart=on-failure
RestartSec=3
# 单进程：勿改成多 worker（任务状态在进程内存）

[Install]
WantedBy=multi-user.target
UNIT
    # 幂等：内容无变化则不重写
    if [[ -f "${UNIT_PATH}" ]] && cmp -s "${UNIT_TMP}" "${UNIT_PATH}"; then
        echo "  单元文件无变化。"
        rm -f "${UNIT_TMP}"
    else
        install -m 0644 "${UNIT_TMP}" "${UNIT_PATH}"
        rm -f "${UNIT_TMP}"
        systemctl daemon-reload
        echo "  已写入 ${UNIT_PATH}。"
    fi
    systemctl enable "${SERVICE_NAME}" >/dev/null 2>&1 || true
    systemctl restart "${SERVICE_NAME}"
    sleep 2
    systemctl --no-pager --full status "${SERVICE_NAME}" | head -n 12 || true
    echo "[bootstrap_deploy] Step 6: 服务已启动（开机自启）。日志: journalctl -u ${SERVICE_NAME} -f"

elif [[ "${MODE}" == "start" ]]; then
    echo "[bootstrap_deploy] Step 6: 后台启动（nohup）..."
    PID_FILE="${KG_EVAL_ROOT}/qag/.qag_ui.pid"
    LOG_FILE="${KG_EVAL_ROOT}/qag/qag_ui.log"
    if [[ -f "${PID_FILE}" ]] && kill -0 "$(cat "${PID_FILE}")" 2>/dev/null; then
        echo "  已在运行 (PID $(cat "${PID_FILE}"))，先停掉旧进程。"
        kill "$(cat "${PID_FILE}")" 2>/dev/null || true
        sleep 1
    fi
    ( cd "${GEN_KEY_ROOT}" && nohup "${START_CMD[@]}" >"${LOG_FILE}" 2>&1 & echo $! > "${PID_FILE}" )
    sleep 2
    echo "  PID=$(cat "${PID_FILE}")  日志: ${LOG_FILE}"
    echo "[bootstrap_deploy] Step 6: 已后台启动。停止: kill \$(cat ${PID_FILE})"
else
    echo "[bootstrap_deploy] Step 6: 仅环境准备（未启动）。手动启动："
    echo "    cd ${GEN_KEY_ROOT} && ${START_CMD[*]}"
fi

# --------------------------------------------------------------------------
# Done — 访问与放行提示
# --------------------------------------------------------------------------
cat <<DONE

[bootstrap_deploy] 全部完成。
  内网访问（同 VPC 机器自测）：  http://${INTRANET_IP}:${PORT}
  本机自测：                     http://127.0.0.1:${PORT}

  公网访问需要（脚本之外的手工步骤）：
   1) 主机防火墙放行端口：     sudo ufw allow ${PORT}/tcp   （或 iptables）
   2) 火山引擎安全组入方向放行 ${PORT}（内网），并申请公网入口（EIP 或端口映射）
      → 映射目标填内网 ${INTRANET_IP}:${PORT}
   3) 对外公布的是火山给的【公网 IP:端口】（可能与 ${INTRANET_IP}:${PORT} 不同）
  确认监听：  ss -ltnp | grep ":${PORT}"
DONE
