# 步骤 ⑩ 真实数据闭环测试 —— 使用步骤（aerospace 领域）

本说明配套一键脚本 [`run_closed_loop_demo.sh`](run_closed_loop_demo.sh)。
真实图谱已就绪（你本机 `gen_key/scientific_kgqa/artifacts/` 下）：

| 产物 | 大小 | 内容 |
|---|---|---|
| `kgqa.db` | 3.2 GB | 真实图谱：**19,934 篇论文 / 80,839 概念 / 332,754 边** |
| `retriever.pkl` | 1.2 GB | 与上面图谱配套的 BM25/TF-IDF 检索器 |
| `kg_eval/qag/extern_data_aerospace/` | 211 MB | 50 篇 aerospace 源 PDF（供出题）|
| `.env` | — | 已含 `LLM_* / KG_LLM_* / EMBED_*` 真实凭据（已 gitignore，不会推送）|

> 领域是 **aerospace.supermaterial**（超材料 / 雷达罩 / 隐身材料等），和图谱完全对齐。
> 原空库 `kgqa.db`（21 MB，0 节点）已被覆盖，`artifacts/` 目录下只剩这一个 3.2 GB 的真实图谱，所有默认路径直接指向它。

---

## 一、环境准备（首次一次性）

```bash
cd C:/Users/suyulin/Desktop/search/gen_key

# 1) 安装 KG 引擎（带 sklearn/rapidfuzz/jieba 等依赖）
pip install -e scientific_kgqa

# 2) 安装步骤⑩ + QAG 网页依赖（flask/openpyxl 等；多数已装）
pip install -r requirements.txt
```

`.env` 已就位，无需再配密钥。脚本会自动 `source .env` 并把 `LLM_*` 映射成 QAG 出题用的 `QAG_*`。

---

## 二、一键闭环（推荐先跑小规模验证）

```bash
# 默认：每领域 1 题、hops=1,2,3 —— 先验证整条链路通
bash kg_eval/run_closed_loop_demo.sh
```

脚本依次执行：
1. 载入 `.env` → 检查 `scientific_kgqa` 可导入（缺则自动 `pip install -e`）
2. 校验图谱产物（打印节点/边/论文数）
3. **出题**：调 `kg_eval/qag/generate_questions.py` 用 aerospace PDF 出题 → `kg_eval/qag/output/L*/`
4. **图谱问答 + 四维测评**：`python -m kg_eval.run_kg_eval`（默认带 KG 引擎 LLM：查询翻译 + LLM 抽种子 + embedding 语义映射）
5. 产出报告

**产物**：
- `kg_eval/output/report.md` —— 人读：四维分 + 🔴 最弱维诊断 + 优化建议 + 子项明细 + 难度分层
- `kg_eval/output/report.json` —— 机读
- `kg_eval/output/answers.json` —— 每题图谱原始回答（可离线重打分）

---

## 三、常用参数（环境变量覆盖）

```bash
# 出更多题、覆盖 L1–L4 四个难度
NUM_PER_DOMAIN=2 HOPS=1,2,3,4 bash kg_eval/run_closed_loop_demo.sh

# 已经出过题，只想重跑测评（跳过出题，省 LLM 调用）
SKIP_GEN=1 bash kg_eval/run_closed_loop_demo.sh

# 题很多时只测评前 N 题，先看链路
SKIP_GEN=1 LIMIT=10 bash kg_eval/run_closed_loop_demo.sh

# 指定别的图谱库 / 题目目录 / 输出目录
DB=/path/kgqa.db RETRIEVER=/path/retriever.pkl OUT_DIR=/tmp/out bash kg_eval/run_closed_loop_demo.sh
```

| 变量 | 默认 | 含义 |
|---|---|---|
| `NUM_PER_DOMAIN` | 1 | 每领域题数 |
| `HOPS` | 1,2,3 | 难度/跳数（L1–L4 对应 1,2,3,4）|
| `DOMAINS` | FABS,HCFG,MECH,POPT | 出题领域 |
| `PAPER_RANGE` | 2-3 | 每题引用论文数范围 |
| `SKIP_GEN` | 0 | =1 跳过出题，复用 `kg_eval/qag/output` |
| `LIMIT` | 全部 | 只测评前 N 题 |
| `DB` / `RETRIEVER` / `QUESTIONS_DIR` / `OUT_DIR` | 见脚本 | 覆盖路径 |

---

## 四、分步手动跑（等价于脚本，便于调试）

```bash
cd C:/Users/suyulin/Desktop/search/gen_key
set -a; . ./.env; set +a
export QAG_API_KEY="$LLM_API_KEY" QAG_LLM_BASE_URL="$LLM_BASE_URL/v1" QAG_LLM_MODEL="$LLM_MODEL"

# (1) 出题
python kg_eval/qag/generate_questions.py --source external \
  --hops 1,2,3 --paper-range 2-3 --domains FABS,HCFG,MECH,POPT --num-per-domain 1 \
  --extern-dir kg_eval/qag/extern_data_aerospace \
  --output-dir kg_eval/qag/output

# (2) 图谱测评
python -m kg_eval.run_kg_eval \
  --db scientific_kgqa/artifacts/kgqa.db \
  --retriever scientific_kgqa/artifacts/retriever.pkl \
  --questions-dir kg_eval/qag/output \
  --out kg_eval/output

# (3) 看报告
cat kg_eval/output/report.md
```

---

## 五、用网页跑（出题 + 测评同一界面）

```bash
cd C:/Users/suyulin/Desktop/search/gen_key
set -a; . ./.env; set +a
python kg_eval/qag/qag_ui_server.py          # http://127.0.0.1:5000
```
在「配置」填好模型 → 「出题」选 aerospace PDF 目录出题 → 切「**图谱测评**」标签页（DB/Retriever 留空则自动用 `scientific_kgqa/artifacts/kgqa.db`）→「开始测评」→「刷新报告」看四维分与诊断。

> 注：网页「出题」默认读 `kg_eval/qag/extern_data`，aerospace PDF 在 `extern_data_aerospace`，网页里把「源 PDF 目录」改成该路径，或 CLI 出题后用 `SKIP_GEN=1` 走脚本测评。

---

## 六、常见问题
- **`No module named scientific_kgqa`** → `pip install -e scientific_kgqa`（脚本会自动尝试）。
- **KG 引擎 LLM/embedding 报错** → 不致命，引擎自动降级为纯检索；想强制纯检索加 `--no-kg-llm`。想关 LLM-Judge 加 `--no-judge`（仅确定性指标）。
- **首轮慢** → 3.2 GB 库首次打开 + 1.2 GB retriever 反序列化较慢，属正常；`concept_embedding` 懒加载一次。
- **不想动远程仓库** → 已更新 `.gitignore`：图谱库 / retriever / `.env` / aerospace PDF / 测评产物全部不入库（`git add -n .` 已验证不会暂存任何 `.db/.pkl/.pdf/.env`）。
