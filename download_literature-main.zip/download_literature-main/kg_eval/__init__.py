# -*- coding: utf-8 -*-
"""kg_eval —— 步骤 ⑩：图谱测评与优化。

用 QAG 前端网页出好的题目（gold）反向测评 scientific_kgqa 构建的知识图谱，
按固定四维框架（KG / Retrieval / Reasoning / Answer）打分，并诊断
"图谱哪一维 / 哪个子项最需要优化"。
"""
