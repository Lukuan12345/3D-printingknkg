#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""步骤 ⑩ CLI —— 用 QAG 网页出好的题反向测评图谱，四维打分 + 优化诊断。

用法：
    python -m kg_eval.run_kg_eval \
        --db scientific_kgqa/artifacts/kgqa.db \
        --retriever scientific_kgqa/artifacts/retriever.pkl \
        --questions-dir kg_eval/qag/output \
        --out kg_eval/output

题目由 QAG 前端网页（kg_eval/qag/qag_ui_server.py）出好，本脚本只读、不出题。
"""

from __future__ import annotations

import argparse
import os
import sys
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

# 让 `python kg_eval/run_kg_eval.py` 直接跑也能 import 到 kg_eval 包
_GEN_KEY_ROOT = Path(__file__).resolve().parents[1]
if str(_GEN_KEY_ROOT) not in sys.path:
    sys.path.insert(0, str(_GEN_KEY_ROOT))

# scientific_kgqa 是 src 布局：把 src 插到最前，避免 cwd 下同名目录被当成命名空间包
# （否则 `import scientific_kgqa` 解析到目录本身，找不到 .storage/.qa_engine 等子模块）
_KGQA_SRC = _GEN_KEY_ROOT / "scientific_kgqa" / "src"
if _KGQA_SRC.is_dir() and str(_KGQA_SRC) not in sys.path:
    sys.path.insert(0, str(_KGQA_SRC))

# 加载 .env（LLM_API_KEY / LLM_BASE_URL / LLM_MODEL）
try:
    from env_bootstrap import load_env
    load_env()
except Exception:
    pass

from kg_eval.eval import config, gold_loader, qa_runner, judge as judge_mod
from kg_eval.eval import kg_inspector as kgi
from kg_eval.eval import scorer, diagnose, report
from kg_eval.eval.semantic import SemanticMatcher


def parse_args(argv=None) -> config.EvalConfig:
    p = argparse.ArgumentParser(description="步骤 ⑩：图谱测评与优化")
    p.add_argument("--db", default=str(config.DEFAULT_DB_PATH), help="kgqa.db 路径")
    p.add_argument("--retriever", default=str(config.DEFAULT_RETRIEVER_PATH), help="retriever.pkl 路径")
    p.add_argument("--questions-dir", default=str(config.DEFAULT_QUESTIONS_DIR),
                   help="QAG 网页出题产物目录（只读）")
    p.add_argument("--out", default=str(config.DEFAULT_OUT_DIR), help="报告输出目录")
    p.add_argument("--judge-model", default="", help="LLM-Judge 模型（默认取 env LLM_MODEL）")
    p.add_argument("--no-judge", action="store_true", help="关闭 LLM-Judge，仅跑确定性指标")
    p.add_argument("--no-kg-llm", action="store_true",
                   help="关闭 KG 引擎 LLM（默认开启：查询翻译 + LLM 抽种子 + embedding 语义映射）")
    p.add_argument("--kg-llm-model", default="", help="KG 引擎 LLM 模型（默认取 env KG_LLM_MODEL/LLM_MODEL）")
    p.add_argument("--no-triple-check", action="store_true", help="关闭 KG 三元组抽样事实核查")
    p.add_argument("--strict-layers", action="store_true",
                   help="严格模式：未实现的层按缺口计 0 拖分（默认关闭，只对已构建的层计分）")
    p.add_argument("--mode", choices=["fast", "deep"], default="deep",
                   help="检索深度：fast=知识库检索+LLM推理（绕过图谱游走）；deep（默认）=知识图谱+知识库检索+LLM推理")
    p.add_argument("--no-graph", action="store_true",
                   help="w/o 图谱检索消融：不接图谱，纯 LLM 直接答题作 baseline")
    p.add_argument("--no-semantic-match", action="store_true",
                   help="关闭跨语言节点语义匹配（默认开启：用 BGE-M3 让中文 gold 节点匹配英文 pred 节点）")
    p.add_argument("--keep-degenerate", action="store_true",
                   help="保留无区分度子项（默认剔除跨题方差≈0 的子项后重归一；需≥3题才判定）")
    p.add_argument("--limit", type=int, default=None, help="只评前 N 题（调试）")
    p.add_argument("--domain-prefer", default="", help="领域上下文文件（注入 judge）")
    p.add_argument("--feed-backflow", action="store_true",
                   help="把优化建议写入 retrieval_integration 候选池")
    p.add_argument("--concurrency", type=int, default=None,
                   help="逐题并发线程数（默认取 env KG_EVAL_WORKERS，否则 4；1=串行）")
    a = p.parse_args(argv)

    # mode 表「检索深度」（fast=KB-only / deep=KG+KB），两者都接 LLM 推理+judge。
    # LLM 推理 / judge 为正交开关，只由 --no-kg-llm / --no-judge 控制。
    use_kg_llm = not a.no_kg_llm
    use_judge = not a.no_judge

    # 并发线程数：显式 --concurrency 优先，否则 env KG_EVAL_WORKERS，再否则 4。
    if a.concurrency is not None:
        workers = a.concurrency
    else:
        try:
            workers = int(os.environ.get("KG_EVAL_WORKERS", "4"))
        except ValueError:
            workers = 4
    workers = max(1, workers)

    cfg = config.EvalConfig(
        db_path=Path(a.db), retriever_path=Path(a.retriever),
        questions_dir=Path(a.questions_dir), out_dir=Path(a.out),
        llm_model=a.judge_model, use_judge=use_judge,
        judge_sample_triples=use_judge and not a.no_triple_check,
        use_kg_llm=use_kg_llm, kg_llm_model=a.kg_llm_model,
        mode=a.mode, use_graph=not a.no_graph,
        semantic_match=not a.no_semantic_match,
        drop_degenerate=not a.keep_degenerate,
        limit=a.limit, feed_backflow=a.feed_backflow,
        score_only_present_layers=not a.strict_layers,
        domain_prefer_file=Path(a.domain_prefer) if a.domain_prefer else None,
        concurrency=workers,
    ).resolve_llm()
    return cfg


def _make_kg_llm(cfg: config.EvalConfig):
    """为 KG 引擎构造 LLMClient；失败/未配置 → None（引擎自动降级）。

    kg_llm_model 可能是「优先级链」(逗号分隔)；LLMClient 是单模型，取链首。
    """
    if not cfg.use_kg_llm or not cfg.kg_llm_api_key:
        return None
    model = (cfg.kg_llm_model or "").split(",")[0].strip() or cfg.kg_llm_model
    try:
        from scientific_kgqa.llm_client import LLMClient
        return LLMClient(api_key=cfg.kg_llm_api_key, model=model,
                         base_url=cfg.kg_llm_base_url)
    except Exception:
        return None


def _feed_backflow(cfg: config.EvalConfig, diagnosis: dict) -> str:
    """把建议写入候选池（best-effort）。返回写入路径或空串。"""
    import json
    from datetime import datetime
    pool = config.GEN_KEY_ROOT / "retrieval_integration" / "data" / "candidate_pool"
    target_dir = pool if pool.exists() else cfg.out_dir
    target_dir.mkdir(parents=True, exist_ok=True)
    fp = target_dir / f"kg_eval_suggestions_{datetime.now():%Y%m%d_%H%M%S}.json"
    try:
        fp.write_text(json.dumps({
            "source": "kg_eval/step10",
            "weakest_dimension": diagnosis.get("weakest_dimension"),
            "missing_layers": diagnosis.get("missing_layers"),
            "suggestions": diagnosis.get("optimization_suggestions"),
        }, ensure_ascii=False, indent=2), encoding="utf-8")
        return str(fp)
    except OSError:
        return ""


def _print_summary(agg: dict, diag: dict, out) -> None:
    """控制台测评摘要。"""
    print("\n================ 步骤 ⑩ 测评摘要 ================")
    print(f"综合 KGQA-Score：{agg['overall_kgqa_score']}")
    for k, v in agg["dimension_scores"].items():
        print(f"  {k:18s}: {v}")
    print(f"最弱维度：{diag['weakest_dimension']}　最弱子项：{diag['weakest_submetric']}")
    if diag.get("unimplemented_components"):
        print(f"未实现(不计分)：{', '.join(diag['unimplemented_components'])}")
    print(f"报告：{out / 'report.md'}")


def main(argv=None) -> int:
    cfg = parse_args(argv)

    # ① 读题（gold）
    golds = gold_loader.load_gold(cfg.questions_dir, limit=cfg.limit)
    if not golds:
        print(f"[kg_eval] 题目目录无可用题目：{cfg.questions_dir}", file=sys.stderr)
        return 2
    print(f"[kg_eval] 载入 {len(golds)} 道题")

    # LLM（judge + 三元组核查）
    llm = judge_mod.make_llm(cfg) if cfg.use_judge else None

    # 跨语言节点语义匹配器（中文 gold 节点 ↔ 英文 pred Concept）
    matcher = SemanticMatcher() if cfg.semantic_match else None
    if matcher is not None and matcher.enabled():
        print("[kg_eval] 跨语言节点匹配：开启（BGE-M3 语义兜底）")
    elif cfg.semantic_match:
        print("[kg_eval] 跨语言节点匹配：embedding 不可用，回退纯 token 匹配")
        matcher = None

    print(f"[kg_eval] 模式：{cfg.mode}　图谱检索：{'关闭(w/o-graph 纯 LLM baseline)' if not cfg.use_graph else '开启'}"
          f"　LLM-Judge：{'开' if cfg.use_judge else '关'}")

    if not cfg.use_graph:
        # ── w/o 图谱检索消融：纯 LLM 直接答题 ──────────────────────────────
        kg_llm = _make_kg_llm(cfg) or llm
        if kg_llm is None:
            print("[kg_eval] no-graph 需要可用 LLM（配 LLM_API_KEY/KG_LLM_API_KEY）", file=sys.stderr)
        domain_instr = ""
        if cfg.domain_prefer_file and cfg.domain_prefer_file.exists():
            domain_instr = cfg.domain_prefer_file.read_text(encoding="utf-8")[:1500]
        scored = []
        answers = []
        for i, g in enumerate(golds, 1):
            rec = qa_runner.answer_without_graph(kg_llm, g, domain_instr)
            answers.append(rec)
            jr = judge_mod.judge_question(llm, g, rec) if cfg.use_judge else None
            qs = scorer.score_question(g, rec, jr)
            scored.append((g, rec, qs))
            print(f"[kg_eval] ({i}/{len(golds)}) {g.qid} [no-graph] "
                  f"A={qs.dimension_scores['answer_quality']}")
        question_scores = [qs for _g, _r, qs in scored]
        # 无图谱 → KG Quality 不适用（None，聚合时自动从综合分剔除）
        kg_quality = {"score": None, "submetrics": {}, "scored_components": [],
                      "unimplemented_components": [], "missing_layers": [],
                      "note": "w/o 图谱检索 baseline：未使用图谱，KG Quality 不适用"}
        agg = scorer.aggregate(question_scores, kg_quality, drop_degenerate=cfg.drop_degenerate)
        diag = diagnose.diagnose(agg)
        rep = report.build_report(cfg, agg, diag, question_scores, answers)
        out = cfg.out_dir
        report.write_answers(out / "answers.json", answers)
        report.write_json(out / "report.json", rep)
        report.write_markdown(out / "report.md", rep)
        _print_summary(agg, diag, out)
        return 0

    # ② 加载检索栈：fast=只 load store+retriever；deep=建 QAEngine（KG 游走）
    kg_llm = _make_kg_llm(cfg)
    _kg_model = (cfg.kg_llm_model or "").split(",")[0].strip()
    is_fast = (cfg.mode == "fast")
    print(f"[kg_eval] 检索深度：{'fast = 知识库检索（KB-only，绕过图谱游走）' if is_fast else 'deep = 知识图谱 + 知识库检索'}")
    print(f"[kg_eval] 推理 LLM：{'启用 ' + _kg_model if kg_llm else '关闭（--no-kg-llm，答案退化为检索摘要）'}")
    try:
        if is_fast:
            store, retriever = qa_runner.load_kb(str(cfg.db_path), str(cfg.retriever_path))
            engine = None
        else:
            engine, store = qa_runner.build_engine(str(cfg.db_path), str(cfg.retriever_path), llm_client=kg_llm)
            retriever = None
    except ModuleNotFoundError as exc:
        miss = getattr(exc, "name", "") or str(exc)
        print(f"[kg_eval] 缺少依赖：{exc}", file=sys.stderr)
        print(f"[kg_eval] 当前 Python：{sys.executable}", file=sys.stderr)
        print(f"[kg_eval] 该解释器未装齐 scientific_kgqa 的运行依赖（{miss} 等）。", file=sys.stderr)
        print(f"[kg_eval] 请用同一个解释器安装：", file=sys.stderr)
        print(f'           "{sys.executable}" -m pip install -e "{_KGQA_SRC.parent}"', file=sys.stderr)
        return 4
    except FileNotFoundError as exc:
        print(f"[kg_eval] 图谱产物不存在：{exc}", file=sys.stderr)
        print("[kg_eval] 请先用步骤 ⑧ build_kb_kg.py 构建 kgqa.db / retriever.pkl", file=sys.stderr)
        return 3
    except Exception as exc:  # noqa: BLE001
        print(f"[kg_eval] 无法加载检索栈（{cfg.db_path}）：{type(exc).__name__}: {exc}", file=sys.stderr)
        return 3

    # ③ per-DB 结构层 KG-Quality + 抽样事实核查（图谱质量评 DB 本身，与检索路径无关）
    inspector = kgi.KGInspector(store)
    structural = inspector.structural_breakdown()
    triple_fc = None
    if cfg.use_judge and cfg.judge_sample_triples and llm is not None:
        triple_fc = judge_mod.factcheck_triples(llm, inspector.sample_triples(config.TRIPLE_SAMPLE_N))

    # ④ 逐题：检索 → LLM 综合答案 → judge → 打分
    synth_llm = kg_llm or llm                          # fast/deep 都用同一个 LLM 做 RAG 答案
    synth = synth_llm is not None
    # 综合答案的备用模型链（推理链去掉链首后的尾部，主模型空响应时降级重试）
    synth_fallbacks = [m.strip() for m in (cfg.kg_llm_model or "").split(",")[1:] if m.strip()]
    if synth:
        print("[kg_eval] 答案生成：检索证据 → LLM 综合答案（RAG）"
              + (f"；备用模型 {synth_fallbacks}" if synth_fallbacks else ""))
    else:
        print("[kg_eval] 答案生成：检索摘要（未接 LLM 生成；--no-kg-llm）")

    workers = max(1, int(getattr(cfg, "concurrency", 1) or 1))
    total = len(golds)
    print(f"[kg_eval] 逐题并发：{workers} 线程" if workers > 1 else "[kg_eval] 逐题串行（concurrency=1）")

    # 预热引擎的惰性 Concept embedding 矩阵，避免多线程首调时的初始化竞争。
    if engine is not None and hasattr(engine, "_ensure_concept_embeddings"):
        try:
            engine._ensure_concept_embeddings()
        except Exception:
            pass

    _print_lock = threading.Lock()
    _done = [0]

    def _eval_one(idx: int, g):
        """单题：检索 → 综合答案 → 预热语义匹配 → judge → 打分。返回 (g, rec, qs)。"""
        rec = qa_runner.answer_kb_only(store, retriever, g) if is_fast else qa_runner.run_question(engine, g)
        if synth and not rec.error:
            rec.answer = qa_runner.synthesize_answer(synth_llm, g, rec, fallback_models=synth_fallbacks)
        if matcher is not None:   # 预热：把本题 gold 节点 + pred 路径节点一次性嵌入
            matcher.warm([n.lower() for n in g.expected_path_nodes]
                         + [name.lower() for path in rec.path_typed_nodes for _t, name in path])
        jr = judge_mod.judge_question(llm, g, rec) if cfg.use_judge else None
        qs = scorer.score_question(g, rec, jr, matcher=matcher)
        with _print_lock:
            _done[0] += 1
            print(f"[kg_eval] ({_done[0]}/{total}) {g.qid} "
                  f"R={qs.dimension_scores['retrieval_quality']} "
                  f"Re={qs.dimension_scores['reasoning_quality']} "
                  f"A={qs.dimension_scores['answer_quality']}"
                  + (f" judge={'ok' if qs.judge_ok else 'off/fail'}")
                  + ("  ⚠️答案生成失败(不计分)" if rec.answer_failed else ""))
        return (g, rec, qs)

    results: list = [None] * total
    if workers > 1:
        with ThreadPoolExecutor(max_workers=workers) as ex:
            fut2idx = {ex.submit(_eval_one, i, g): i for i, g in enumerate(golds)}
            for fut in as_completed(fut2idx):
                idx = fut2idx[fut]
                results[idx] = fut.result()   # 异常向上抛（与串行行为一致）
    else:
        for i, g in enumerate(golds):
            results[i] = _eval_one(i, g)

    # 保持与题目输入一致的顺序（与原串行实现一致）
    scored = list(results)
    answers = [rec for _g, rec, _qs in scored]

    n_answer_failed = sum(1 for _g, r, _q in scored if r.answer_failed)
    if n_answer_failed:
        print(f"[kg_eval] ⚠️ {n_answer_failed} 题 LLM 综合答案生成失败（空响应等），其 Answer 维度已从均值剔除")

    question_scores = [qs for _g, _r, qs in scored]

    # ⑤ KG-Quality 融合（结构层 + 跨题 macro 命中 + 抽样核查）
    macro_hit = scorer.question_macro_node_hit(scored)
    kg_quality = scorer.combine_kg_quality(structural, macro_hit, triple_fc,
                                           score_only_present=cfg.score_only_present_layers)

    # ⑥ 聚合 + 诊断
    agg = scorer.aggregate(question_scores, kg_quality, drop_degenerate=cfg.drop_degenerate)
    diag = diagnose.diagnose(agg)

    # ⑦ 报告
    rep = report.build_report(cfg, agg, diag, question_scores, answers)
    out = cfg.out_dir
    report.write_answers(out / "answers.json", answers)
    report.write_json(out / "report.json", rep)
    report.write_markdown(out / "report.md", rep)

    backflow_path = _feed_backflow(cfg, diag) if cfg.feed_backflow else ""

    _print_summary(agg, diag, out)
    if backflow_path:
        print(f"建议已写入候选池：{backflow_path}")

    try:
        store.close()
    except Exception:
        pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
