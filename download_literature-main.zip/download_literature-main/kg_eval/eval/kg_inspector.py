# -*- coding: utf-8 -*-
"""kg_inspector.py —— per-DB 结构层 KG-Quality（题目无关那部分）。

直接读 scientific_kgqa 的 SQLite（graph_node / graph_edge / paper_fact / paper_concept ...），
统计节点/边规模与质量，并判定 spec 框架要求的层是否存在。
缺失的层 → 覆盖缺口（低分 + 缺口标记），交给 diagnose 产出"该建这一层"的建议。

L0_Quality   ≈ 基础实体（SchemaField / Prototype / MetricBucket）规模 + 属性完整度
L1_Quality   ≈ SchemaField 质量；Narrative / Measurement / Discovery 多半缺失 → 缺口
L2_Quality   ≈ Concept 节点质量 + Concept 关系质量；Global Registry 缺失 → 缺口
Coupling     ≈ FIELD_INSTANTIATES / PAPER_EVIDENCE 跨层耦合；跨域边缺失 → 缺口

注：这里只给"结构层"分数；与跨题聚合的 macro-F1（expected_path_nodes 对图谱命中）
在 scorer 中按 60/40 融合，详见 scorer.combine_kg_quality。
"""

from __future__ import annotations

from typing import Any, Dict, List


def _clip01(x: float) -> float:
    return max(0.0, min(1.0, x))


class KGInspector:
    """对一张 kgqa.db 做结构层质量统计。"""

    def __init__(self, store):
        self.store = store
        self.conn = store.conn
        self._node_counts = self._count("graph_node", "node_type")
        self._edge_counts = self._count("graph_edge", "relation_type")

    # ── 基础统计 ──────────────────────────────────────────────────────────────
    def _count(self, table: str, col: str) -> Dict[str, int]:
        try:
            rows = self.conn.execute(
                f"SELECT {col} AS k, COUNT(*) AS c FROM {table} GROUP BY {col}"
            ).fetchall()
            return {r["k"]: r["c"] for r in rows}
        except Exception:
            return {}

    def _scalar(self, sql: str, default: float = 0.0) -> float:
        try:
            row = self.conn.execute(sql).fetchone()
            v = row[0] if row else None
            return float(v) if v is not None else default
        except Exception:
            return default

    def node_count(self, node_type: str) -> int:
        return int(self._node_counts.get(node_type, 0))

    def edge_count(self, rel: str) -> int:
        return int(self._edge_counts.get(rel, 0))

    # ── 属性完整度（attrs_json 非空 / display name 齐全的比例）──────────────────
    def _attr_completeness(self, node_type: str) -> float:
        total = self.node_count(node_type)
        if total == 0:
            return 0.0
        return _clip01(self._count_filled(node_type) / total)

    def _count_filled(self, node_type: str) -> float:
        try:
            row = self.conn.execute(
                "SELECT COUNT(*) FROM graph_node WHERE node_type=? "
                "AND attrs_json IS NOT NULL AND attrs_json NOT IN ('', '{}')",
                (node_type,),
            ).fetchone()
            return float(row[0]) if row else 0.0
        except Exception:
            return 0.0

    # ── 边质量（llm_score / citation_score / support_paper_count 的归一均值）───
    def _edge_quality(self, rel: str) -> float:
        n = self.edge_count(rel)
        if n == 0:
            return 0.0
        avg_llm = self._scalar(
            f"SELECT AVG(llm_score) FROM graph_edge WHERE relation_type='{rel}'", 0.0)
        avg_cite = self._scalar(
            f"SELECT AVG(citation_score) FROM graph_edge WHERE relation_type='{rel}'", 0.0)
        avg_support = self._scalar(
            f"SELECT AVG(MIN(support_paper_count,3)/3.0) FROM graph_edge WHERE relation_type='{rel}'", 0.0)
        # 任一信号为 0 不致命：取存在信号的均值，再保底 support 规模分
        signals = [s for s in (avg_llm, avg_cite) if s > 0]
        sig = sum(signals) / len(signals) if signals else 0.0
        return _clip01(0.6 * sig + 0.4 * avg_support)

    # ── 层存在性 ──────────────────────────────────────────────────────────────
    def layer_presence(self) -> Dict[str, Any]:
        """返回各 spec 层的存在性与缺口列表。"""
        has_measurement_facts = self._scalar(
            "SELECT COUNT(*) FROM paper_fact WHERE num_value IS NOT NULL "
            "OR range_low IS NOT NULL", 0.0) > 0
        has_domain_attr = self._scalar(
            "SELECT COUNT(*) FROM graph_node WHERE attrs_json LIKE '%domain%'", 0.0) > 0

        present = {
            "L0.base_entities": self.node_count("SchemaField") + self.node_count("Prototype") + self.node_count("MetricBucket") > 0,
            "L1.SchemaField": self.node_count("SchemaField") > 0,
            "L1.Narrative": False,                       # 真实 KG 无独立节点
            "L1.Measurement": False,                     # 仅 paper_fact 字段级（见下 partial）
            "L1.Measurement_fact_level": has_measurement_facts,
            "L1.Discovery": False,
            "L2.Concept": self.node_count("Concept") > 0,
            "L2.ConceptRelations": self.edge_count("CONCEPT_COOCCUR") + self.edge_count("CONCEPT_EVOLVES") > 0,
            "L2.GlobalConceptRegistry": False,
            "Coupling.cross_layer": self.edge_count("FIELD_INSTANTIATES") + self.edge_count("PAPER_EVIDENCE") > 0,
            "Coupling.cross_domain": has_domain_attr,
        }
        missing: List[str] = []
        if not present["L1.Narrative"]:
            missing.append("L1.Narrative")
        if not present["L1.Measurement"]:
            missing.append("L1.Measurement")
        if not present["L1.Discovery"]:
            missing.append("L1.Discovery")
        if not present["L2.GlobalConceptRegistry"]:
            missing.append("L2.GlobalConceptRegistry")
        if not present["Coupling.cross_domain"]:
            missing.append("Coupling.cross_domain")

        # 四个 KG-Quality 一级分量"是否有底层数据支撑"（决定是否纳入计分）：
        #   L0       —— 任一基础实体节点存在
        #   L1       —— SchemaField 或 Narrative/Measurement/Discovery 节点存在
        #   L2       —— Concept 节点存在
        #   Coupling —— 跨层耦合边或跨域标注存在
        supported = {
            "L0": present["L0.base_entities"],
            "L1": present["L1.SchemaField"] or present["L1.Narrative"]
                  or present["L1.Measurement"] or present["L1.Discovery"],
            "L2": present["L2.Concept"],
            "Coupling": present["Coupling.cross_layer"] or present["Coupling.cross_domain"],
        }
        unimplemented_components = [k for k, v in supported.items() if not v]
        return {
            "present": present,
            "missing_layers": missing,
            "supported": supported,
            "unimplemented_components": unimplemented_components,
        }

    # ── 四个层的结构层分数 ────────────────────────────────────────────────────
    def l0_structural(self) -> float:
        """基础实体规模（log 饱和）× 属性完整度。"""
        n = self.node_count("SchemaField") + self.node_count("Prototype") + self.node_count("MetricBucket")
        scale = _clip01((n and (1.0 if n >= 80 else n / 80.0)) or 0.0)
        attr = (
            self._attr_completeness("SchemaField") * 0.5
            + self._attr_completeness("Prototype") * 0.3
            + self._attr_completeness("MetricBucket") * 0.2
        )
        return _clip01(0.6 * scale + 0.4 * attr)

    def l1_structural(self) -> Dict[str, float]:
        """L1 四类子项；缺失子项计 0。Measurement 给 fact-level 部分分。"""
        pres = self.layer_presence()["present"]
        schemafield = _clip01(
            (1.0 if self.node_count("SchemaField") >= 30 else self.node_count("SchemaField") / 30.0)
            * (0.5 + 0.5 * self._attr_completeness("SchemaField"))
        )
        measurement = 0.4 if pres["L1.Measurement_fact_level"] else 0.0   # 字段级存在但未成节点 → 部分分
        narrative = 0.0
        discovery = 0.0
        # L1 综合 = 四类等权
        score = (schemafield + measurement + narrative + discovery) / 4.0
        return {
            "score": round(_clip01(score), 4),
            "SchemaField": round(schemafield, 4),
            "Measurement": round(measurement, 4),
            "Narrative": narrative,
            "Discovery": discovery,
        }

    def l2_structural(self) -> Dict[str, float]:
        """L2：Concept 节点质量 + Concept 关系质量（+ Global Registry，存在才计入）。

        只对真实存在的子项取平均（缺失子项不进分母，避免无端拉低 L2）。
        """
        concept_n = self.node_count("Concept")
        concept_node_q = _clip01(
            (1.0 if concept_n >= 100 else concept_n / 100.0)
            * (0.5 + 0.5 * self._attr_completeness("Concept"))
        )
        rel_present = self.edge_count("CONCEPT_COOCCUR") + self.edge_count("CONCEPT_EVOLVES") > 0
        rel_q = 0.5 * self._edge_quality("CONCEPT_COOCCUR") + 0.5 * self._edge_quality("CONCEPT_EVOLVES")
        registry_present = self.layer_presence()["present"]["L2.GlobalConceptRegistry"]

        parts = {}
        if concept_n > 0:
            parts["ConceptNode"] = round(concept_node_q, 4)
        if rel_present:
            parts["ConceptRelation"] = round(_clip01(rel_q), 4)
        if registry_present:
            parts["GlobalRegistry"] = 0.5   # 占位：存在时给中性分，可后续细化
        score = sum(parts.values()) / len(parts) if parts else 0.0
        detail = {"score": round(_clip01(score), 4)}
        # 明细：存在子项给分，不存在子项标 None（不计分）
        detail["ConceptNode"] = parts.get("ConceptNode")
        detail["ConceptRelation"] = parts.get("ConceptRelation")
        detail["GlobalRegistry"] = parts.get("GlobalRegistry")  # None = 未实现，不计分
        return detail

    def coupling_structural(self) -> Dict[str, float]:
        """跨层耦合（真实） + 跨域耦合（缺失计 0）。"""
        cross_layer = 0.6 * self._edge_quality("FIELD_INSTANTIATES") + 0.4 * self._edge_quality("PAPER_EVIDENCE")
        cross_domain = 0.0 if not self.layer_presence()["present"]["Coupling.cross_domain"] else 0.5
        score = (cross_layer + cross_domain) / 2.0
        return {
            "score": round(_clip01(score), 4),
            "CrossLayer": round(_clip01(cross_layer), 4),
            "CrossDomain": cross_domain,
        }

    # ── 抽样三元组（供 judge 做 LLM 事实核查）────────────────────────────────
    def sample_triples(self, n: int = 30) -> List[Dict[str, str]]:
        """随机取 n 条带名字的三元组 (src, relation, dst)。"""
        try:
            rows = self.conn.execute(
                """
                SELECT s.canonical_name AS src, e.relation_type AS rel,
                       d.canonical_name AS dst, s.node_type AS src_type, d.node_type AS dst_type
                FROM graph_edge e
                JOIN graph_node s ON s.node_id = e.src_node_id
                JOIN graph_node d ON d.node_id = e.dst_node_id
                WHERE e.relation_type IN ('FIELD_INSTANTIATES','CONCEPT_COOCCUR','CONCEPT_EVOLVES','PAPER_EVIDENCE')
                ORDER BY RANDOM() LIMIT ?
                """,
                (n,),
            ).fetchall()
            return [
                {"src": r["src"], "relation": r["rel"], "dst": r["dst"],
                 "src_type": r["src_type"], "dst_type": r["dst_type"]}
                for r in rows
            ]
        except Exception:
            return []

    # ── 汇总 ──────────────────────────────────────────────────────────────────
    def structural_breakdown(self) -> Dict[str, Any]:
        l1 = self.l1_structural()
        l2 = self.l2_structural()
        cp = self.coupling_structural()
        presence = self.layer_presence()
        return {
            "L0": round(self.l0_structural(), 4),
            "L1": l1["score"], "L1_detail": l1,
            "L2": l2["score"], "L2_detail": l2,
            "Coupling": cp["score"], "Coupling_detail": cp,
            "missing_layers": presence["missing_layers"],
            "supported": presence["supported"],
            "unimplemented_components": presence["unimplemented_components"],
            "node_counts": self._node_counts,
            "edge_counts": self._edge_counts,
        }
