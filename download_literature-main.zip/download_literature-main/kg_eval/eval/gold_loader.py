# -*- coding: utf-8 -*-
"""gold_loader.py —— 读取 QAG 前端网页出好的题目 JSON，作为测评 gold（只读，不出题）。

题目由 kg_eval/qag 下的网页/CLI 产出，落在 output/L1_*/、L2_*/ ... 各难度子目录。
本模块只负责把它们读进来、规整成统一的 GoldQuestion，绝不触发出题。
"""

from __future__ import annotations

import glob
import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from . import config


@dataclass
class GoldQuestion:
    qid: str
    domain: str
    difficulty_level: str               # L1 / L2 / L3 / L4
    hop_count: int
    intent: str
    question: str
    expected_path_nodes: List[str]
    expected_key_relations: List[str]
    gold_evidence: List[Dict[str, Any]]
    gold_answer: str
    key_points: List[str]
    acceptable_variants: List[str]
    raw: Dict[str, Any] = field(default_factory=dict)

    @property
    def gold_source_texts(self) -> List[str]:
        """gold_evidence 的原文集合（数值/事实接地参照）。"""
        out = []
        for ev in self.gold_evidence:
            if isinstance(ev, dict):
                t = ev.get("text") or ev.get("exact_quote") or ""
            else:
                t = str(ev)
            if t:
                out.append(t)
        return out


def _level_from(d: Dict[str, Any]) -> str:
    lvl = (d.get("difficulty_level") or "").strip().upper()
    if lvl in config.HOP_BY_LEVEL:
        return lvl
    hop = int(d.get("hop_count") or 0)
    return {1: "L1", 2: "L2", 3: "L3", 4: "L4"}.get(hop, "L1")


def _parse_one(d: Dict[str, Any]) -> Optional[GoldQuestion]:
    if not d.get("question"):
        return None
    gt = d.get("ground_truth") or {}
    level = _level_from(d)
    return GoldQuestion(
        qid=str(d.get("id") or d.get("qid") or ""),
        domain=str(d.get("domain") or ""),
        difficulty_level=level,
        hop_count=int(d.get("hop_count") or config.HOP_BY_LEVEL.get(level, 1)),
        intent=str(d.get("intent") or ""),
        question=str(d.get("question") or ""),
        expected_path_nodes=list(d.get("expected_path_nodes") or []),
        expected_key_relations=list(d.get("expected_key_relations") or []),
        gold_evidence=list(d.get("gold_evidence") or []),
        gold_answer=str(gt.get("answer") or ""),
        key_points=list(gt.get("key_points") or []),
        acceptable_variants=list(gt.get("acceptable_variants") or []),
        raw=d,
    )


def load_gold(questions_dir: str | Path, limit: Optional[int] = None) -> List[GoldQuestion]:
    """递归扫 questions_dir 下所有题目 JSON（跳过 reports/ 与 manifest），返回 GoldQuestion 列表。"""
    root = Path(questions_dir)
    if not root.exists():
        raise FileNotFoundError(f"题目目录不存在：{root}（请先在 QAG 网页出题）")

    files = sorted(glob.glob(str(root / "**" / "*.json"), recursive=True))
    out: List[GoldQuestion] = []
    for f in files:
        fp = Path(f)
        # 跳过报告 / 清单 / 被拒题目
        parts = {p.lower() for p in fp.parts}
        if "reports" in parts or "rejected" in parts:
            continue
        if fp.name in ("generation_manifest.json", "config.json", "review_data.json",
                       "expert_feedback.json", "usable_ids.json"):
            continue
        try:
            d = json.loads(fp.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            continue
        if not isinstance(d, dict):
            continue
        gq = _parse_one(d)
        if gq:
            out.append(gq)
        if limit and len(out) >= limit:
            break
    return out
