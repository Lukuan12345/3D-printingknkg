# -*- coding: utf-8 -*-
"""config.py —— 四维测评框架的权重、阈值、默认路径与 LLM 配置。

权重严格照搬步骤 ⑩ 规范：

  KG Quality       = 0.35·L0 + 0.25·L1 + 0.25·L2 + 0.15·Coupling
  Retrieval Quality= 0.35·EvidenceRecall + 0.25·PathRecall + 0.20·NumericGrounding + 0.20·Traceability
  Reasoning Quality= 0.30·PathNodeGrounding + 0.25·CrossLayerUse + 0.25·MultiHopCoherence + 0.20·ConceptBackboneUse
  Answer Quality   = 0.45·FactualCorrectness + 0.25·SemanticCoverage + 0.15·DesignUsefulness + 0.15·InnovationScore
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Optional

# ── 仓库内默认路径 ────────────────────────────────────────────────────────────
GEN_KEY_ROOT = Path(__file__).resolve().parents[2]          # .../gen_key
KG_EVAL_ROOT = Path(__file__).resolve().parents[1]          # .../gen_key/kg_eval
# ── 图谱权重（kgqa.db / retriever.pkl）目录解析 ───────────────────────────────
# 优先级：env KGQA_ARTIFACTS_DIR → 团队共享挂载 → 仓库内本地副本。
# 目的：共享挂载上已有一份权重，所有能访问该挂载的机器都能直接跑图谱测评，
#       无需各自把几个 G 的 kgqa.db / retriever.pkl 拷到本地。
_SHARED_ARTIFACTS = Path(
    "/mnt/shared-storage-user/suyulin/literature_knowledge_extractor_new/scientific_kgqa/artifacts"
)
_LOCAL_ARTIFACTS = GEN_KEY_ROOT / "scientific_kgqa" / "artifacts"


def _resolve_artifacts_dir() -> Path:
    env = os.environ.get("KGQA_ARTIFACTS_DIR", "").strip()
    if env:
        return Path(env)
    if _SHARED_ARTIFACTS.exists():          # 集群/开发机挂了共享盘 → 用共享权重（零拷贝）
        return _SHARED_ARTIFACTS
    return _LOCAL_ARTIFACTS                  # 无挂载（如本地 Windows）→ 回退仓库内副本


ARTIFACTS_DIR = _resolve_artifacts_dir()


def _resolve_db_path(art_dir: Path) -> Path:
    # 默认用航天版图谱 kgqa_aerospace.db；共享盘上即此名。
    # 本地副本可能就叫 kgqa.db（内容即航天版）→ 回退，保证本地也能跑。
    aero = art_dir / "kgqa_aerospace.db"
    return aero if aero.exists() else art_dir / "kgqa.db"


DEFAULT_DB_PATH = _resolve_db_path(ARTIFACTS_DIR)
DEFAULT_RETRIEVER_PATH = ARTIFACTS_DIR / "retriever.pkl"
DEFAULT_QUESTIONS_DIR = KG_EVAL_ROOT / "qag" / "output"
DEFAULT_OUT_DIR = KG_EVAL_ROOT / "output"

# ── 四维一级权重（综合 KGQA-Score 用，等权展示；规范未给一级权重，默认等权）──
DIMENSION_WEIGHTS: Dict[str, float] = {
    "kg_quality": 0.25,
    "retrieval_quality": 0.25,
    "reasoning_quality": 0.25,
    "answer_quality": 0.25,
}

# ── 各维度子项权重 ────────────────────────────────────────────────────────────
KG_W = {"L0": 0.35, "L1": 0.25, "L2": 0.25, "Coupling": 0.15}
RET_W = {"evidence_recall": 0.35, "path_recall": 0.25, "numeric_grounding": 0.20, "traceability": 0.20}
REASON_W = {"path_node_grounding": 0.30, "cross_layer_use": 0.25, "multihop_coherence": 0.25, "concept_backbone_use": 0.20}
ANS_W = {"factual_correctness": 0.45, "semantic_coverage": 0.25, "design_usefulness": 0.15, "innovation": 0.15}

# ── 阈值 ──────────────────────────────────────────────────────────────────────
EVIDENCE_TOPK = 5                  # Top-K 证据命中
EVIDENCE_REL_THRESHOLD = 0.4       # 证据 token-recall 相关阈值（对齐 bench）
FUZZY_NODE_THRESHOLD = 0.5         # 节点模糊匹配阈值（对齐 bench）
COVERAGE_SUCCESS_THRESHOLD = 0.6   # 路径成功覆盖阈值
TRIPLE_SAMPLE_N = 30               # KG 抽样事实核查三元组数

# 难度 → 期望跳数（与 QAG 出题一致）
HOP_BY_LEVEL = {"L1": 1, "L2": 2, "L3": 3, "L4": 4}
# 设计/创新子项仅在这些难度有效
DESIGN_LEVELS = {"L3", "L4"}
INNOVATION_LEVELS = {"L3", "L4"}


@dataclass
class EvalConfig:
    """一次测评运行的全部配置。"""
    db_path: Path = DEFAULT_DB_PATH
    retriever_path: Path = DEFAULT_RETRIEVER_PATH
    questions_dir: Path = DEFAULT_QUESTIONS_DIR
    out_dir: Path = DEFAULT_OUT_DIR

    # LLM-Judge（复用 scientific_kgqa.llm_client 的同款 env）
    llm_api_key: str = ""
    llm_base_url: str = ""
    llm_model: str = ""
    use_judge: bool = True
    judge_sample_triples: bool = True   # 是否对 KG 三元组做抽样 LLM 事实核查

    # KG 问答引擎 LLM（驱动查询翻译 + LLM 抽种子 + embedding 语义映射）。
    # 真实闭环建议开启：80k 概念图谱靠它做高质量 seed 映射。
    use_kg_llm: bool = True
    kg_llm_api_key: str = ""
    kg_llm_base_url: str = ""
    kg_llm_model: str = ""

    # 消融实验开关
    mode: str = "deep"          # 检索深度：fast=知识库检索+LLM推理（绕过图谱游走）；deep=知识图谱+知识库检索+LLM推理
    use_graph: bool = True      # False=w/o 图谱检索消融：纯 LLM 直接答题（无证据/无路径）作 baseline
    semantic_match: bool = True # 跨语言节点语义匹配（BGE-M3）：中文 gold 节点 ↔ 英文 pred 节点
    drop_degenerate: bool = True # 默认剔除"结构性恒定、无区分度"（跨题方差≈0）的子项后重归一

    limit: Optional[int] = None         # 只评前 N 题（调试用）
    feed_backflow: bool = False         # 把优化建议写回 knowledge_backflow 候选池

    # 只对"图谱真实存在底层数据"的 KG 子项计分（权重在存在子项间重归一）。
    # True（默认）：纯概念图谱不会因没建 L0/L1/Coupling 而被判 0 拖分；
    #               未实现的层仅作"未实现（不计分）"信息列出，不进评分/不生成建议。
    # False：回到"缺失层即缺口、计 0"的严格模式（spec 原始语义）。
    score_only_present_layers: bool = True

    domain_prefer_file: Optional[Path] = None  # 领域上下文（注入 judge system）

    # 逐题并发线程数（LLM/embedding 均为 I/O 密集，多线程显著提速）。
    # 默认读环境变量 KG_EVAL_WORKERS（部署脚本里设 4）；1 = 串行（旧行为）。
    concurrency: int = 1

    def resolve_llm(self) -> "EvalConfig":
        """从 env 补全 LLM 配置（与 scientific_kgqa / .env 对齐）。"""
        self.llm_api_key = (
            self.llm_api_key
            or os.environ.get("LLM_API_KEY", "")
            or os.environ.get("ANTHROPIC_AUTH_TOKEN", "")
            or os.environ.get("OPENAI_API_KEY", "")
        )
        self.llm_base_url = (
            self.llm_base_url
            or os.environ.get("LLM_BASE_URL", "")
            or os.environ.get("ANTHROPIC_BASE_URL", "")
            or "http://43.153.42.7:3001/v1"
        )
        self.llm_model = (
            self.llm_model
            or os.environ.get("LLM_MODEL", "")
            or "claude-haiku-4-5-20251001"
        )
        # KG 引擎 LLM：优先 KG_LLM_*，回退到 judge 的 LLM_* 同一套
        self.kg_llm_api_key = (
            self.kg_llm_api_key or os.environ.get("KG_LLM_API_KEY", "") or self.llm_api_key
        )
        self.kg_llm_base_url = (
            self.kg_llm_base_url or os.environ.get("KG_LLM_BASE_URL", "") or self.llm_base_url
        )
        self.kg_llm_model = (
            self.kg_llm_model or os.environ.get("KG_LLM_MODEL", "") or self.llm_model
        )
        return self


# ── 真实 KG 节点 / 关系类型（来自 scientific_kgqa.builder / storage）──────────
REAL_NODE_TYPES = {"Cluster", "SchemaField", "ChunkType", "Concept", "Prototype", "MetricBucket", "Paper"}
REAL_RELATION_TYPES = {
    "HAS_FIELD", "EXPECTED_IN", "CHUNK_FLOW",
    "FIELD_INSTANTIATES", "CONCEPT_COOCCUR", "CONCEPT_EVOLVES", "PAPER_EVIDENCE",
}

# spec 框架要求、但真实 KG 尚不存在的层 / 节点 / 边（→ 覆盖缺口信号）
SPEC_GAPS = {
    "L1.Narrative": "L1 无 Narrative 叙事节点",
    "L1.Measurement": "L1 无独立 Measurement 测量节点（数值仅存于 paper_fact 字段级）",
    "L1.Discovery": "L1 无 Discovery 发现/结论节点",
    "L2.GlobalConceptRegistry": "L2 无 Global Concept Registry（跨论文概念归一表）",
    "Coupling.cross_domain": "无显式跨域耦合边（节点无 domain 标注）",
}
