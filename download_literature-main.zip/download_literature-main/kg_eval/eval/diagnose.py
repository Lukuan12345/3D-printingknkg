# -*- coding: utf-8 -*-
"""diagnose.py —— 由四维聚合结果排出"最该优化"的维度/子项，并映射到具体 KG 修复动作。

输出回答步骤 ⑩ 的核心诉求：体现图谱哪方面最需要优化。
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

# 子项 → 修复动作映射（target / action / why / 连带修复的子项）
FIX_MAP: Dict[str, Dict[str, Any]] = {
    # KG Quality
    "kg_quality.L0": {
        "target": "KG/L0 基础实体",
        "action": "在 llm_extractor / schema_gen 增补基础实体抽取（Module A–E 分模块），提升 SchemaField/Prototype/MetricBucket 覆盖与属性完整度",
        "why": "L0 基础实体规模或属性不足，题目要的实体在图谱中定位不到",
    },
    "kg_quality.L1": {
        "target": "KG/L1 (Measurement/Discovery/Narrative)",
        "action": "改 scientific_kgqa/llm_extractor.py：把 paper_fact 里的数值/单位/条件提升为独立 Measurement 节点，并新增 Discovery(结论) 与 Narrative(叙事) 节点类型",
        "why": "L1 仅有 SchemaField，数值/结论/叙事未成节点，数值类检索与可追溯性无依托",
        "fixes_submetric": ["retrieval_quality.numeric_grounding", "retrieval_quality.traceability"],
    },
    "kg_quality.L2": {
        "target": "KG/L2 (Concept + Global Registry)",
        "action": "对 Concept embedding 做跨论文聚类，建立 Global Concept Registry 做实体归一；并强化 builder._build_concept_evolves_edges / _build_concept_cooccur_edges 的边权质量",
        "why": "L2 缺 Global Concept Registry，概念跨论文未归一，概念骨干推理弱",
        "fixes_submetric": ["reasoning_quality.concept_backbone_use"],
    },
    "kg_quality.Coupling": {
        "target": "KG/Coupling 跨层·跨域边",
        "action": "在 builder.py 给节点补 domain 标注并构建跨域 CONCEPT_COOCCUR/耦合边；补全跨层 FIELD_INSTANTIATES/PAPER_EVIDENCE 的证据支撑",
        "why": "无显式跨域耦合边，跨域知识无法连通",
        "fixes_submetric": ["reasoning_quality.cross_layer_use"],
    },
    # Retrieval
    "retrieval_quality.evidence_recall": {
        "target": "检索/证据召回",
        "action": "调 qa_engine rerank 权重与 posting 召回（get_posting_chunk_ids / retriever.search topk），扩大候选 chunk_types",
        "why": "Top-K 证据命中率低，关键证据未被召回",
    },
    "retrieval_quality.path_recall": {
        "target": "检索/路径召回",
        "action": "提升种子映射(map_seeds)与 PPR/beam 召回，使标准推理路径上的关键节点/边被命中",
        "why": "标准推理路径的关键节点/关系召回不足",
    },
    "retrieval_quality.numeric_grounding": {
        "target": "检索/数值接地",
        "action": "把 Measurement(数值/单位/条件) 抽成节点并入检索；答案生成强约束引用证据中的数值",
        "why": "答案数值无法在证据中接地（疑似数值幻觉）",
        "fixes_submetric": ["kg_quality.L1"],
    },
    "retrieval_quality.traceability": {
        "target": "检索/可追溯性",
        "action": "保证每条证据带 paper_id/chunk_id 可回溯到 Paper/Measurement/Discovery；完善 content_store 溯源",
        "why": "答案引用证据无法追溯到论文/段落",
    },
    # Reasoning
    "reasoning_quality.path_node_grounding": {
        "target": "推理/路径节点接地",
        "action": "保证 compose_answer 输出的路径节点均来自 graph_node；补全 soft_node 描述",
        "why": "推理链节点无法在图谱中定位",
    },
    "reasoning_quality.cross_layer_use": {
        "target": "推理/跨层使用",
        "action": "构建并暴露跨层边，使推理同时用到 L0/L1/L2 至少两层信息",
        "why": "推理未跨层，仅在单一节点类型内游走",
        "fixes_submetric": ["kg_quality.Coupling"],
    },
    "reasoning_quality.multihop_coherence": {
        "target": "推理/多跳连贯",
        "action": "优化 beam_search 路径打分(path_score)与方向约束，提升多跳链逻辑连续性",
        "why": "多跳推理链方向/长度与标准路径偏差大",
    },
    "reasoning_quality.concept_backbone_use": {
        "target": "推理/概念骨干",
        "action": "强化 Concept / CONCEPT_EVOLVES / CONCEPT_COOCCUR 构建与召回，让推理走概念中介",
        "why": "未有效利用 Concept 骨干做中介推理",
        "fixes_submetric": ["kg_quality.L2"],
    },
    # Answer
    "answer_quality.factual_correctness": {
        "target": "答案/事实正确性",
        "action": "提升证据召回与答案生成约束；对数值/引用做事实校验",
        "why": "答案事实/数值/引用与标准答案不一致",
    },
    "answer_quality.semantic_coverage": {
        "target": "答案/语义覆盖",
        "action": "扩大检索覆盖并在生成时对齐专家参考要点(key_points)",
        "why": "答案未覆盖专家参考答案的关键要点",
    },
    "answer_quality.design_usefulness": {
        "target": "答案/设计有效性 (L3-L4)",
        "action": "在 schema 发散扩展与 qa prompt 中强化研发路线/参数优化/性能边界的结构化输出",
        "why": "对研发决策的实际帮助不足",
    },
    "answer_quality.innovation": {
        "target": "答案/创新性 (L3-L4)",
        "action": "引导 L3/L4 题在概念演化(CONCEPT_EVOLVES)基础上提出新构型/新假设",
        "why": "缺乏合理的新构型/新假设/新设计框架",
    },
}


def _weakest_submetric(dim: str, sub: Dict[str, Optional[float]], skip=None) -> Optional[str]:
    vals = {k: v for k, v in (sub or {}).items()
            if v is not None and not (skip and skip(f"{dim}.{k}"))}
    if not vals:
        return None
    k = min(vals, key=lambda x: vals[x])
    return f"{dim}.{k}"


def diagnose(aggregate_result: Dict[str, Any]) -> Dict[str, Any]:
    dim = aggregate_result["dimension_scores"]
    breakdown = aggregate_result["breakdown"]
    kgq = aggregate_result["kg_quality_detail"]
    missing = kgq.get("missing_layers", [])
    # 未实现且已从评分剔除的 KG 一级分量（L0/L1/Coupling 等）：不再当缺口、不生成建议
    unimplemented = set(kgq.get("unimplemented_components", []))
    # 无区分度（结构性恒定）被剔除的子项：不当最弱、不生成建议（形如 "reasoning_quality.cross_layer_use"）
    degenerate_map = aggregate_result.get("degenerate_submetrics", {}) or {}
    degenerate_full = {f"{d}.{k}" for d, ks in degenerate_map.items() for k in ks}

    def _is_unimplemented_key(key: str) -> bool:
        # key 形如 "kg_quality.L1" / "kg_quality.Coupling" → 取分量名比对
        if not key or not key.startswith("kg_quality."):
            return False
        return key.split(".", 1)[1] in unimplemented

    def _is_skip_key(key: str) -> bool:
        return _is_unimplemented_key(key) or key in degenerate_full

    ranked = sorted(
        [(k, v) for k, v in dim.items() if v is not None],
        key=lambda kv: kv[1],
    )
    weakest_dim = ranked[0][0] if ranked else None

    # 最弱维度内的最弱子项（跳过未实现 / 无区分度子项）
    weakest_sub = _weakest_submetric(weakest_dim, breakdown.get(weakest_dim, {}), skip=_is_skip_key) if weakest_dim else None

    # 收集建议：最弱维最弱子项 + 所有缺失层 + 全局明显低分子项(<0.5)
    suggestions: List[Dict[str, Any]] = []
    seen = set()

    def add(key: str, extra_why: str = ""):
        if not key or key in seen:
            return
        if _is_skip_key(key):   # 未实现层 / 无区分度子项已剔除评分 → 不生成建议
            return
        fix = FIX_MAP.get(key)
        if not fix:
            return
        seen.add(key)
        item = dict(fix)
        item["submetric"] = key
        if extra_why:
            item["why"] = fix["why"] + "；" + extra_why
        suggestions.append(item)

    if weakest_sub:
        add(weakest_sub, "（当前最弱子项，建议优先处理）")

    # 缺失层 → 对应 KG 子项建议（仅对"已纳入计分但偏弱"的层；未实现层已剔除，不建议）
    gap_to_sub = {
        "L1.Narrative": "kg_quality.L1", "L1.Measurement": "kg_quality.L1", "L1.Discovery": "kg_quality.L1",
        "L2.GlobalConceptRegistry": "kg_quality.L2", "Coupling.cross_domain": "kg_quality.Coupling",
    }
    for g in missing:
        sub = gap_to_sub.get(g, "")
        if sub and not _is_unimplemented_key(sub):
            add(sub, f"缺失子项：{g}")

    # 全局低分子项兜底
    for d, subs in breakdown.items():
        for k, v in (subs or {}).items():
            if v is not None and v < 0.5:
                add(f"{d}.{k}")

    return {
        "weakest_dimension": weakest_dim,
        "weakest_submetric": weakest_sub,
        "ranked_dimensions": [{"dimension": k, "score": v} for k, v in ranked],
        "missing_layers": missing,
        "unimplemented_components": sorted(unimplemented),   # 未实现、已从评分剔除
        "degenerate_submetrics": sorted(degenerate_full),    # 无区分度、已从评分剔除
        "optimization_suggestions": suggestions,
    }
