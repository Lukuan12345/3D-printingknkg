# -*- coding: utf-8 -*-
"""metrics.py —— 纯确定性指标（无 LLM / 无 DB），移植自 bench/metrics 与 QAG check_quality。

保持与 `Desktop/bench/metrics/{utils,retrieval_quality,reasoning_quality}.py`
以及 `QAG/script/check_quality.py: find_numeric_hallucinations` 完全等价，
以便步骤 ⑩ 自包含、不跨仓库 import。
"""

from __future__ import annotations

import math
import re
import string
from collections import Counter
from typing import List, Optional, Tuple

# ── 文本工具（移植 bench/metrics/utils.py）────────────────────────────────────


def tokenize(text: str) -> List[str]:
    """自适应分词：中文按字符、英文按单词。"""
    text = text or ""
    zh_ratio = len(re.findall(r"[一-鿿]", text)) / max(len(text), 1)
    if zh_ratio > 0.2:
        text = re.sub(r"[^一-鿿\w]", " ", text)
        return [c for c in text if c.strip()]
    text = text.lower().translate(str.maketrans("", "", string.punctuation))
    return text.split()


def normalize(text: str) -> str:
    return " ".join(tokenize(text))


def token_f1(pred: str, ref: str) -> float:
    p_tokens = tokenize(pred)
    r_tokens = tokenize(ref)
    if not p_tokens and not r_tokens:
        return 1.0
    if not p_tokens or not r_tokens:
        return 0.0
    common = Counter(p_tokens) & Counter(r_tokens)
    n = sum(common.values())
    if n == 0:
        return 0.0
    precision = n / len(p_tokens)
    recall = n / len(r_tokens)
    return 2 * precision * recall / (precision + recall)


def exact_match(pred: str, ref: str) -> float:
    return float(normalize(pred) == normalize(ref))


def best_score(pred: str, refs: List[str], fn) -> float:
    if not refs:
        return 0.0
    return max(fn(pred, r) for r in refs)


def token_recall(candidate: str, reference: str) -> float:
    """candidate 的 token 在 reference 中出现的比例（按 reference 为分母的反向用法见下）。"""
    c = set(tokenize(candidate))
    r = set(tokenize(reference))
    if not c:
        return 0.0
    return len(c & r) / len(c)


def fuzzy_node_match(node_name: str, candidate: str, threshold: float = 0.5) -> bool:
    """node_name 是否近似匹配 candidate（基于 token recall）。"""
    n_tokens = set(tokenize(node_name))
    c_tokens = set(tokenize(candidate))
    if not n_tokens or not c_tokens:
        return False
    overlap = len(n_tokens & c_tokens) / len(n_tokens)
    return overlap >= threshold


# ── 证据 / 检索（移植 bench/metrics/retrieval_quality.py）──────────────────────


def _text_token_recall(pred_text: str, ref_text: str) -> float:
    ref_tokens = set(tokenize((ref_text or "").lower()))
    pred_tokens = set(tokenize((pred_text or "").lower()))
    if not ref_tokens:
        return 1.0
    return len(pred_tokens & ref_tokens) / len(ref_tokens)


def _ev_text(ev) -> str:
    return ev.get("text", "") if isinstance(ev, dict) else str(ev)


def _ev_source(ev) -> str:
    if not isinstance(ev, dict):
        return ""
    for k in ("paper_title", "source", "title", "doc_id"):
        v = ev.get(k)
        if v:
            return str(v).strip().lower()
    return ""


def _is_relevant(pred_text: str, gold_evidences: list, threshold: float) -> bool:
    for g in gold_evidences:
        if _text_token_recall(pred_text, _ev_text(g)) >= threshold:
            return True
    return False


def _is_gold_hit(gold_text: str, pred_top: list, threshold: float) -> bool:
    for p in pred_top:
        if _text_token_recall(_ev_text(p), gold_text) >= threshold:
            return True
    return False


def compute_retrieval_quality(
    pred_evidence: list,
    gold_evidence: list,
    k: int = 10,
    threshold: float = 0.4,
) -> dict:
    """证据检索质量：source_recall / mrr / ndcg@k / precision@k / recall@k(主) / f1@k。"""
    n_gold = len(gold_evidence)
    n_pred = len(pred_evidence)

    if n_gold == 0:
        return {
            "source_recall": 1.0, "mrr": 1.0, "ndcg_at_k": 1.0,
            "evidence_precision_at_k": 1.0, "evidence_recall_at_k": 1.0,
            "evidence_f1_at_k": 1.0, "n_gold": 0, "n_pred": n_pred, "k": k,
        }
    if n_pred == 0:
        return {
            "source_recall": 0.0, "mrr": 0.0, "ndcg_at_k": 0.0,
            "evidence_precision_at_k": 0.0, "evidence_recall_at_k": 0.0,
            "evidence_f1_at_k": 0.0, "n_gold": n_gold, "n_pred": 0, "k": k,
        }

    top_k = pred_evidence[:k]

    gold_sources = {_ev_source(g) for g in gold_evidence if _ev_source(g)}
    if gold_sources:
        pred_sources = {_ev_source(p) for p in pred_evidence if _ev_source(p)}
        source_recall = len(gold_sources & pred_sources) / len(gold_sources)
    else:
        source_recall = None

    rr = 0.0
    for i, p in enumerate(pred_evidence, start=1):
        if _is_relevant(_ev_text(p), gold_evidence, threshold):
            rr = 1.0 / i
            break

    rels = [1.0 if _is_relevant(_ev_text(p), gold_evidence, threshold) else 0.0 for p in top_k]
    dcg = sum(r / math.log2(i + 2) for i, r in enumerate(rels))
    ideal_hits = min(len(rels), n_gold)
    idcg = sum(1.0 / math.log2(i + 2) for i in range(ideal_hits))
    ndcg = dcg / idcg if idcg > 0 else 0.0

    hit_gold = sum(1 for g in gold_evidence if _is_gold_hit(_ev_text(g), top_k, threshold))
    relevant_in_topk = sum(rels)
    precision_at_k = relevant_in_topk / len(top_k) if top_k else 0.0
    recall_at_k = hit_gold / n_gold
    f1_at_k = (
        2 * precision_at_k * recall_at_k / (precision_at_k + recall_at_k)
        if (precision_at_k + recall_at_k) > 0 else 0.0
    )

    return {
        "source_recall": round(source_recall, 4) if source_recall is not None else None,
        "mrr": round(rr, 4),
        "ndcg_at_k": round(ndcg, 4),
        "evidence_precision_at_k": round(precision_at_k, 4),
        "evidence_recall_at_k": round(recall_at_k, 4),
        "evidence_f1_at_k": round(f1_at_k, 4),
        "n_gold": n_gold, "n_pred": n_pred, "k": k,
    }


# ── 推理路径（移植 bench/metrics/reasoning_quality.py）─────────────────────────


def _parse_path(path) -> Tuple[List[str], List[str]]:
    """提取 (nodes, relations)，nodes 顺序保留。兼容 dict / 纯字符串 / {path:[...]}。"""
    nodes: List[str] = []
    relations: List[str] = []
    text = ""

    if isinstance(path, dict):
        for n in path.get("nodes", []) or []:
            name = n.get("canonical_name", "") if isinstance(n, dict) else str(n)
            if name:
                nodes.append(name.lower())
        for r in path.get("relations", []) or []:
            relations.append(str(r).upper())
        text = path.get("text", "")
        if not nodes and not text:
            raw_path = path.get("path", [])
            if raw_path:
                for i, item in enumerate(raw_path):
                    (nodes if i % 2 == 0 else relations).append(
                        str(item).lower() if i % 2 == 0 else str(item).upper()
                    )
    elif isinstance(path, str):
        text = path
    else:
        return [], []

    if not nodes and text:
        for part in re.split(r"\s*->\s*", text):
            part = re.sub(r"^(Prototype|SchemaField|MetricBucket|Concept|Cluster|ChunkType|Paper):", "", part).strip()
            if part:
                nodes.append(part.lower())

    if not relations and text:
        for m in re.findall(r"--\s*([A-Z_]+)\s*-->", text):
            relations.append(m.upper())

    return nodes, relations


def _longest_subsequence_ratio(pred_nodes: List[str], gold_nodes: List[str], threshold: float,
                               matcher=None) -> float:
    if not gold_nodes:
        return 1.0
    if not pred_nodes:
        return 0.0
    seq = []
    for p in pred_nodes:
        idx = None
        for i, g in enumerate(gold_nodes):
            if fuzzy_node_match(g, p, threshold) or (matcher is not None and matcher.matches(g, p)):
                idx = i
                break
        if idx is not None:
            seq.append(idx)
    if not seq:
        return 0.0
    tails: List[int] = []
    for x in seq:
        lo, hi = 0, len(tails)
        while lo < hi:
            mid = (lo + hi) // 2
            if tails[mid] < x:
                lo = mid + 1
            else:
                hi = mid
        if lo == len(tails):
            tails.append(x)
        else:
            tails[lo] = x
    return len(tails) / len(gold_nodes)


def compute_reasoning_quality(
    reasoning_paths: list,
    expected_path_nodes: List[str],
    expected_hop_count: int,
    expected_key_relations: Optional[List[str]] = None,
    fuzzy_threshold: float = 0.5,
    coverage_success_threshold: float = 0.6,
    matcher=None,
) -> dict:
    """推理路径质量：key_node_hit / path_length / relation_hit / direction_acc / hop_success(主)。

    matcher（可选 SemanticMatcher）：token 匹配失败时用 BGE-M3 跨语言语义相似度兜底，
    解决 gold 中文节点 vs pred 英文 Concept 匹配不上的问题。
    """
    if not reasoning_paths:
        return {
            "key_node_hit_rate": 0.0, "path_length_score": 0.0,
            "relation_hit_rate": None if not expected_key_relations else 0.0,
            "direction_accuracy": 0.0, "hop_success_rate": 0.0,
            "best_path_coverage": 0.0, "n_paths_found": 0,
            "hit_nodes": [], "miss_nodes": list(expected_path_nodes),
        }

    parsed = [_parse_path(p) for p in reasoning_paths]
    all_nodes = list({n for ns, _ in parsed for n in ns})
    all_rels = [r for _, rs in parsed for r in rs]

    def _hit(exp_lower: str, cand: str) -> bool:
        """exp 命中 cand：先 token 模糊，失败则语义（跨语言）兜底。"""
        if fuzzy_node_match(exp_lower, cand, fuzzy_threshold):
            return True
        return matcher is not None and matcher.matches(exp_lower, cand)

    hit_nodes, miss_nodes = [], []
    for exp in expected_path_nodes:
        if any(_hit(exp.lower(), n) for n in all_nodes):
            hit_nodes.append(exp)
        else:
            miss_nodes.append(exp)
    key_node_hit = len(hit_nodes) / len(expected_path_nodes) if expected_path_nodes else 1.0

    path_lens = [max(0, len(ns) - 1) for ns, _ in parsed if len(ns) > 1]
    if path_lens:
        best_len = min(path_lens, key=lambda l: abs(l - expected_hop_count))
        delta = abs(best_len - expected_hop_count)
        path_length_score = max(0.0, 1.0 - delta / max(expected_hop_count, 1))
    else:
        path_length_score = 0.0

    if expected_key_relations:
        gold_rels = {r.upper() for r in expected_key_relations}
        relation_hit = (sum(1 for r in all_rels if r in gold_rels) / len(all_rels)) if all_rels else 0.0
    else:
        relation_hit = None

    if expected_path_nodes:
        gold_lower = [n.lower() for n in expected_path_nodes]
        direction_acc = max(
            (_longest_subsequence_ratio(ns, gold_lower, fuzzy_threshold, matcher) for ns, _ in parsed),
            default=0.0,
        )
    else:
        direction_acc = 1.0

    if expected_path_nodes:
        best_path_coverage = 0.0
        for ns, _ in parsed:
            cov = sum(
                1 for exp in expected_path_nodes
                if any(_hit(exp.lower(), n) for n in ns)
            ) / len(expected_path_nodes)
            best_path_coverage = max(best_path_coverage, cov)
    else:
        best_path_coverage = 1.0

    success = 0
    for ns, _ in parsed:
        if len(ns) < 2 or not expected_path_nodes:
            continue
        cov = sum(
            1 for exp in expected_path_nodes
            if any(_hit(exp.lower(), n) for n in ns)
        ) / len(expected_path_nodes)
        if cov >= coverage_success_threshold and abs((len(ns) - 1) - expected_hop_count) <= 1:
            success = 1
            break

    return {
        "key_node_hit_rate": round(key_node_hit, 4),
        "path_length_score": round(path_length_score, 4),
        "relation_hit_rate": round(relation_hit, 4) if relation_hit is not None else None,
        "direction_accuracy": round(direction_acc, 4),
        "hop_success_rate": float(success),
        "best_path_coverage": round(best_path_coverage, 4),
        "n_paths_found": len(parsed),
        "hit_nodes": hit_nodes, "miss_nodes": miss_nodes,
    }


# ── 数值幻觉（移植 QAG/script/check_quality.py: find_numeric_hallucinations）───

NUMERIC_RE = re.compile(
    r"(?<![A-Za-z0-9])[-+]?(?:\d+\.\d+|\d{2,})"
    r"(?:\s*[–\-~至到]\s*[-+]?(?:\d+\.\d+|\d{2,}))?"
    r"\s*(?:GHz|MHz|kHz|Hz|nm|μm|um|mm|cm|m|dB|dBi|%|K|°C|W|A|V|Ω|ps|ns|μs|us|ms|kg|g|mg)?"
    r"(?![A-Za-z0-9])",
    re.I,
)


def find_numeric_hallucinations(answer: str, source_texts: List[str]) -> Tuple[int, List[str]]:
    """返回 (幻觉数, 去重后的未支撑数值列表)。"""
    numbers_in_answer = NUMERIC_RE.findall(answer or "")
    combined_source = " ".join(source_texts or [])
    unsupported: List[str] = []
    for num_str in numbers_in_answer:
        core = re.sub(r"[a-zA-Z°%\s]+$", "", num_str).strip()
        if core and core not in combined_source:
            unsupported.append(num_str.strip())
    return len(unsupported), list(dict.fromkeys(unsupported))


def numeric_grounding_score(answer: str, source_texts: List[str]) -> Tuple[float, List[str]]:
    """NumericGrounding = 1 - 幻觉数 / 答案中数值总数。无数值则记 1.0。"""
    total = len(NUMERIC_RE.findall(answer or ""))
    n_bad, bad = find_numeric_hallucinations(answer, source_texts)
    if total == 0:
        return 1.0, []
    return round(max(0.0, 1.0 - n_bad / total), 4), bad
