# -*- coding: utf-8 -*-
"""judge.py —— LLM-Judge：每题一次 chat_json，产出全部语义子分。

复用 scientific_kgqa.llm_client.LLMClient.chat_json(system, user, temperature)。
任何异常 → 返回全 None 的 JudgeResult，scorer 走确定性指标并在报告标注降级。

输出子分（均 0~1，design/innovation 仅 L3/L4 有效，否则 None）：
    factual_correctness, contradiction_rate, key_point_coverage,
    design_usefulness, innovation, multihop_coherence, cross_layer_use(0/1 评判)
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from . import config


@dataclass
class JudgeResult:
    factual_correctness: Optional[float] = None
    contradiction_rate: Optional[float] = None
    key_point_coverage: Optional[float] = None
    design_usefulness: Optional[float] = None
    innovation: Optional[float] = None
    multihop_coherence: Optional[float] = None
    cross_layer_use: Optional[float] = None
    comments: str = ""
    ok: bool = False

    def as_dict(self) -> Dict[str, Any]:
        return {
            "factual_correctness": self.factual_correctness,
            "contradiction_rate": self.contradiction_rate,
            "key_point_coverage": self.key_point_coverage,
            "design_usefulness": self.design_usefulness,
            "innovation": self.innovation,
            "multihop_coherence": self.multihop_coherence,
            "cross_layer_use": self.cross_layer_use,
            "comments": self.comments,
            "ok": self.ok,
        }


_SYSTEM = """\
你是科学知识图谱问答的资深评测专家（电磁超材料 / 频率选择表面等领域）。
给定一道题的【标准答案/要点/证据】与【被测图谱系统的答案/推理路径/检索证据】，
请就以下子项各打 0~1 的分（1 最好），并只输出 JSON，不要多余文字：

{
  "factual_correctness": 0~1,   // 系统答案的事实、数值、引用是否与标准答案/证据一致
  "contradiction_rate":  0~1,   // 系统答案中与标准答案直接矛盾的陈述占比（越低越好）
  "key_point_coverage":  0~1,   // 覆盖了多少 gold key_points（覆盖数/总数）
  "design_usefulness":   0~1|null, // 对研发路线/参数优化/性能边界判断的实际帮助；仅 L3/L4 评，否则 null
  "innovation":          0~1|null, // 是否提出合理的新构型/新假设/新设计框架；仅 L3/L4 评，否则 null
  "multihop_coherence":  0~1,   // 多跳推理链是否逻辑连续、方向正确
  "cross_layer_use":     0~1,   // 是否综合使用了不同层次（基础实体/字段/概念）的信息完成推理
  "comments":            "一句话点评，指出最薄弱处"
}

评分要克制、有区分度；证据不足/答非所问应给低分。难度非 L3/L4 时 design_usefulness 与 innovation 必须为 null。
"""


def _trunc(s: str, n: int) -> str:
    s = s or ""
    return s if len(s) <= n else s[:n] + " …"


def _build_user(gold, answer_record) -> str:
    ev_lines = []
    for e in (answer_record.evidence or [])[:5]:
        ev_lines.append(f"- [{e.get('paper_title','?')}] {_trunc(e.get('text',''), 300)}")
    paths = "\n".join(f"- {p}" for p in (answer_record.reasoning_paths or [])[:8]) or "(无推理路径)"
    kps = "\n".join(f"- {k}" for k in (gold.key_points or [])) or "(无)"
    return f"""\
难度等级: {gold.difficulty_level}（hop={gold.hop_count}）  领域: {gold.domain}  意图: {gold.intent}

【题目】
{gold.question}

【标准答案】
{_trunc(gold.gold_answer, 1500)}

【标准答案 key_points】
{kps}

【被测系统答案】
{_trunc(answer_record.answer, 1500)}

【被测系统推理路径】
{paths}

【被测系统检索到的证据】
{chr(10).join(ev_lines) or "(无证据)"}
"""


def make_llm(cfg: config.EvalConfig):
    """构造 LLMClient；失败返回 None。

    cfg.llm_model 可能是「优先级链」(逗号分隔)；LLMClient 是单模型，取链首
    （否则整条 "a,b" 会被当成一个模型名，网关报 model_not_found / 503）。
    """
    try:
        from scientific_kgqa.llm_client import LLMClient
        model = (cfg.llm_model or "").split(",")[0].strip() or cfg.llm_model
        return LLMClient(
            api_key=cfg.llm_api_key,
            model=model,
            base_url=cfg.llm_base_url,
        )
    except Exception:
        return None


def _coerce(v) -> Optional[float]:
    if v is None:
        return None
    try:
        return max(0.0, min(1.0, float(v)))
    except (TypeError, ValueError):
        return None


def judge_question(llm, gold, answer_record) -> JudgeResult:
    """一次 chat_json 评一题。llm 为 None 或异常 → 全 None 结果。"""
    if llm is None:
        return JudgeResult()
    try:
        raw = llm.chat_json(_SYSTEM, _build_user(gold, answer_record), temperature=0.1)
    except Exception as exc:  # noqa: BLE001
        return JudgeResult(comments=f"judge error: {type(exc).__name__}")
    if not isinstance(raw, dict):
        return JudgeResult(comments="judge returned non-dict")

    is_design = gold.difficulty_level in config.DESIGN_LEVELS
    res = JudgeResult(
        factual_correctness=_coerce(raw.get("factual_correctness")),
        contradiction_rate=_coerce(raw.get("contradiction_rate")),
        key_point_coverage=_coerce(raw.get("key_point_coverage")),
        design_usefulness=_coerce(raw.get("design_usefulness")) if is_design else None,
        innovation=_coerce(raw.get("innovation")) if is_design else None,
        multihop_coherence=_coerce(raw.get("multihop_coherence")),
        cross_layer_use=_coerce(raw.get("cross_layer_use")),
        comments=str(raw.get("comments") or ""),
        ok=True,
    )
    return res


# ── KG 三元组抽样事实核查 ─────────────────────────────────────────────────────

_TRIPLE_SYS = """\
你是科学知识图谱质检专家。下面给出若干从图谱中抽取的三元组 (头实体, 关系, 尾实体)。
请判断每条是否"在该科学领域中是合理/可信的关系"。只输出 JSON：
{"results": [{"i": 0, "plausible": true/false}, ...], "plausible_ratio": 0~1}
"""


def factcheck_triples(llm, triples: List[Dict[str, str]]) -> Optional[float]:
    """返回三元组可信比例 [0,1]；llm 不可用或无三元组 → None。"""
    if llm is None or not triples:
        return None
    lines = [
        f'{i}. ({t["src"]}) --{t["relation"]}--> ({t["dst"]})'
        for i, t in enumerate(triples)
    ]
    user = "三元组列表：\n" + "\n".join(lines)
    try:
        raw = llm.chat_json(_TRIPLE_SYS, user, temperature=0.0)
    except Exception:
        return None
    if not isinstance(raw, dict):
        return None
    if raw.get("plausible_ratio") is not None:
        return _coerce(raw.get("plausible_ratio"))
    results = raw.get("results") or []
    if not results:
        return None
    good = sum(1 for r in results if isinstance(r, dict) and r.get("plausible"))
    return round(good / len(results), 4)
