# -*- coding: utf-8 -*-
"""kg_eval.eval —— 四维图谱测评的核心实现。"""
