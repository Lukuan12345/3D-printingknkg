# -*- coding: utf-8 -*-
"""scorer.py —— 把确定性指标 + LLM-Judge 合成四维分，并聚合 + 并入 KG-Quality。

四维公式（权重见 config）：
  KG Quality       = 0.35·L0 + 0.25·L1 + 0.25·L2 + 0.15·Coupling          （per-DB + 跨题聚合）
  Retrieval Quality= 0.35·EvidenceRecall + 0.25·PathRecall + 0.20·NumericGrounding + 0.20·Traceability
  Reasoning Quality= 0.30·PathNodeGrounding + 0.25·CrossLayerUse + 0.25·MultiHopCoherence + 0.20·ConceptBackboneUse
  Answer Quality   = 0.45·FactualCorrectness + 0.25·SemanticCoverage + 0.15·DesignUsefulness + 0.15·InnovationScore

子项为 None（无法测/不适用）时，按"权重重归一"——只在有效子项间按原比例分配权重。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from . import config, metrics


# ── 加权（支持 None 子项重归一）──────────────────────────────────────────────
def weighted(parts: Dict[str, Optional[float]], weights: Dict[str, float]) -> Optional[float]:
    num = 0.0
    den = 0.0
    for k, w in weights.items():
        v = parts.get(k)
        if v is None:
            continue
        num += w * v
        den += w
    if den == 0:
        return None
    return round(num / den, 4)


@dataclass
class QuestionScore:
    qid: str
    difficulty_level: str
    domain: str
    retrieval: Dict[str, Any] = field(default_factory=dict)
    reasoning: Dict[str, Any] = field(default_factory=dict)
    answer: Dict[str, Any] = field(default_factory=dict)
    dimension_scores: Dict[str, Optional[float]] = field(default_factory=dict)
    judge_ok: bool = False
    error: str = ""


# ── 单题：Retrieval / Reasoning / Answer ─────────────────────────────────────
def _path_node_grounding(answer_record) -> float:
    """pred 路径节点能否在图谱（soft_nodes 名集合）定位 → 比例。"""
    soft_names = {
        (n.get("canonical_name") or n.get("name") or "").strip().lower()
        for n in (answer_record.soft_nodes or []) if isinstance(n, dict)
    }
    soft_names.discard("")
    all_nodes = [(t, name) for path in answer_record.path_typed_nodes for t, name in path]
    if not all_nodes:
        return 0.0
    grounded = 0
    for _t, name in all_nodes:
        nl = name.strip().lower()
        # 带类型前缀解析出来的节点本就来自图谱；再核对 soft_nodes 命中更稳
        if _t or (soft_names and any(metrics.fuzzy_node_match(nl, s) for s in soft_names)):
            grounded += 1
    return round(grounded / len(all_nodes), 4)


def score_retrieval(gold, answer_record, matcher=None) -> Dict[str, Any]:
    rq = metrics.compute_retrieval_quality(
        answer_record.evidence, gold.gold_evidence,
        k=config.EVIDENCE_TOPK, threshold=config.EVIDENCE_REL_THRESHOLD,
    )
    reason = metrics.compute_reasoning_quality(
        answer_record.reasoning_paths, gold.expected_path_nodes,
        gold.hop_count, gold.expected_key_relations,
        fuzzy_threshold=config.FUZZY_NODE_THRESHOLD,
        coverage_success_threshold=config.COVERAGE_SUCCESS_THRESHOLD,
        matcher=matcher,
    )
    # PathRecall = mean(key_node_hit, relation_hit)（relation_hit 为 None 时只用 key_node）
    rel_hit = reason["relation_hit_rate"]
    path_recall = reason["key_node_hit_rate"] if rel_hit is None else round(
        (reason["key_node_hit_rate"] + rel_hit) / 2.0, 4)
    # NumericGrounding（pred 答案+证据 的数值 vs gold/source 原文）
    src = gold.gold_source_texts + answer_record.pred_source_texts
    numeric, bad = metrics.numeric_grounding_score(answer_record.answer, src)
    # Traceability：pred 每条 evidence 的 paper_id 是否非空可溯
    evs = answer_record.evidence or []
    traceable = sum(1 for e in evs if isinstance(e, dict) and (e.get("paper_id") or e.get("paper_title")))
    traceability = round(traceable / len(evs), 4) if evs else 0.0

    parts = {
        "evidence_recall": rq["evidence_recall_at_k"],
        "path_recall": path_recall,
        "numeric_grounding": numeric,
        "traceability": traceability,
    }
    return {
        "score": weighted(parts, config.RET_W),
        "submetrics": parts,
        "detail": {"retrieval_quality": rq, "reasoning_metrics": reason,
                   "unsupported_numbers": bad},
    }


def score_reasoning(gold, answer_record, reasoning_metrics, judge) -> Dict[str, Any]:
    path_node_grounding = _path_node_grounding(answer_record)
    # CrossLayerUse：路径跨 ≥2 个 node_type → 1.0；恰 1 个 → 0.5；无 → 0
    n_types = len(answer_record.used_node_types)
    cross_layer = 1.0 if n_types >= 2 else (0.5 if n_types == 1 else 0.0)
    if judge and judge.cross_layer_use is not None:   # 有 LLM 判断则取两者均值
        cross_layer = round((cross_layer + judge.cross_layer_use) / 2.0, 4)
    # MultiHopCoherence：0.5·direction + 0.5·path_length，L3/L4 叠加 LLM
    base_coh = 0.5 * reasoning_metrics["direction_accuracy"] + 0.5 * reasoning_metrics["path_length_score"]
    if judge and judge.multihop_coherence is not None:
        multihop = round((base_coh + judge.multihop_coherence) / 2.0, 4)
    else:
        multihop = round(base_coh, 4)
    # ConceptBackboneUse：用到 Concept 节点 / CONCEPT_* 关系
    backbone = 1.0 if answer_record.uses_concept_backbone else 0.0
    parts = {
        "path_node_grounding": path_node_grounding,
        "cross_layer_use": cross_layer,
        "multihop_coherence": multihop,
        "concept_backbone_use": backbone,
    }
    return {"score": weighted(parts, config.REASON_W), "submetrics": parts}


def score_answer(gold, answer_record, judge) -> Dict[str, Any]:
    # 文本指标（无 LLM 也有）
    tf1 = metrics.token_f1(answer_record.answer, gold.gold_answer)
    best_f1 = metrics.best_score(
        answer_record.answer, [gold.gold_answer] + (gold.acceptable_variants or []), metrics.token_f1)

    if getattr(answer_record, "answer_failed", False):
        # LLM 综合答案生成失败（空响应等基础设施故障）→ Answer 维度全 None，从均值剔除
        factual = semantic = design = innovation = None
    elif judge and judge.ok:
        factual = judge.factual_correctness
        if factual is not None and judge.contradiction_rate is not None:
            factual = round(max(0.0, factual * (1.0 - judge.contradiction_rate)), 4)
        semantic = judge.key_point_coverage
        design = judge.design_usefulness
        innovation = judge.innovation
    else:
        # 降级：用文本 F1 近似 factual / semantic，design/innovation 置 None
        factual = round(best_f1, 4)
        semantic = round(tf1, 4)
        design = None
        innovation = None

    parts = {
        "factual_correctness": factual,
        "semantic_coverage": semantic,
        "design_usefulness": design,
        "innovation": innovation,
    }
    return {
        "score": weighted(parts, config.ANS_W),
        "submetrics": parts,
        "detail": {"token_f1": round(tf1, 4), "best_variant_f1": round(best_f1, 4),
                   "judge": judge.as_dict() if judge else None},
    }


def score_question(gold, answer_record, judge, matcher=None) -> QuestionScore:
    ret = score_retrieval(gold, answer_record, matcher=matcher)
    rea = score_reasoning(gold, answer_record, ret["detail"]["reasoning_metrics"], judge)
    ans = score_answer(gold, answer_record, judge)
    qs = QuestionScore(
        qid=gold.qid, difficulty_level=gold.difficulty_level, domain=gold.domain,
        retrieval=ret, reasoning=rea, answer=ans,
        dimension_scores={
            "retrieval_quality": ret["score"],
            "reasoning_quality": rea["score"],
            "answer_quality": ans["score"],
        },
        judge_ok=bool(judge and judge.ok),
        error=answer_record.error,
    )
    return qs


# ── KG-Quality：结构层 + 跨题 macro-F1 融合 ──────────────────────────────────
def question_macro_node_hit(scores_with_records: List) -> float:
    """跨所有题：expected_path_nodes 在 pred 路径中的平均命中率（≈ 图谱节点覆盖能力）。"""
    hits = []
    for _gold, _rec, qs in scores_with_records:
        km = qs.retrieval["detail"]["reasoning_metrics"]["key_node_hit_rate"]
        if km is not None:
            hits.append(km)
    return round(sum(hits) / len(hits), 4) if hits else 0.0


def combine_kg_quality(structural: Dict[str, Any], macro_node_hit: float,
                       triple_factcheck: Optional[float],
                       score_only_present: bool = True) -> Dict[str, Any]:
    """L0/L1/L2/Coupling 结构层 + 跨题 macro-F1 + 抽样事实核查 → KG Quality。

    score_only_present=True 时：只对图谱里有底层数据的分量计分，权重在这些分量间
    重新归一；未实现的分量（unimplemented_components）移出评分，仅作信息列出。
    """
    supported = structural.get("supported", {"L0": True, "L1": True, "L2": True, "Coupling": True})
    unimplemented = structural.get("unimplemented_components", [])

    comp = {"L0": structural["L0"], "L1": structural["L1"],
            "L2": structural["L2"], "Coupling": structural["Coupling"]}
    # L0 存在时混入跨题节点命中（图谱能否覆盖题目要的实体）
    if supported.get("L0"):
        comp["L0"] = round(0.6 * structural["L0"] + 0.4 * macro_node_hit, 4)
    # 抽样事实核查命中率作为可信度乘子（缺失则不影响）
    if triple_factcheck is not None:
        factor = 0.7 + 0.3 * triple_factcheck
        for k in ("L0", "L2", "Coupling"):
            comp[k] = round(comp[k] * factor, 4)

    if score_only_present:
        weights = {k: w for k, w in config.KG_W.items() if supported.get(k)}
    else:
        weights = dict(config.KG_W)

    score = weighted(comp, weights) if weights else None
    scored_keys = list(weights.keys())
    return {
        "score": score,
        "submetrics": {k: comp[k] for k in scored_keys},   # 只列入计分的分量
        "scored_components": scored_keys,
        "unimplemented_components": unimplemented,           # 未实现 → 不计分
        "macro_node_hit": macro_node_hit,
        "triple_factcheck": triple_factcheck,
        "missing_layers": structural.get("missing_layers", []),
        "all_components": comp,                              # 全量（含未计分），供查看
        "structural": structural,
    }


# ── 全局聚合 ──────────────────────────────────────────────────────────────────
def _avg(vals: List[Optional[float]]) -> Optional[float]:
    xs = [v for v in vals if v is not None]
    return round(sum(xs) / len(xs), 4) if xs else None


def _variance(vals: List[Optional[float]]) -> float:
    xs = [v for v in vals if v is not None]
    if len(xs) < 2:
        return 0.0
    m = sum(xs) / len(xs)
    return sum((x - m) ** 2 for x in xs) / len(xs)


# 维度 → (子项权重, 取子项的 getter)
_DIM_SUBWEIGHTS = {
    "retrieval_quality": config.RET_W,
    "reasoning_quality": config.REASON_W,
    "answer_quality": config.ANS_W,
}
_DIM_GETTER = {
    "retrieval_quality": lambda q: q.retrieval["submetrics"],
    "reasoning_quality": lambda q: q.reasoning["submetrics"],
    "answer_quality": lambda q: q.answer["submetrics"],
}
DEGENERATE_MIN_N = 3        # 至少 N 题才判区分度（样本太少不可靠）
DEGENERATE_VAR_THRESHOLD = 1e-6


def _detect_degenerate(question_scores: List[QuestionScore], dim_key: str) -> List[str]:
    """跨题集找方差≈0（结构性恒定、无区分度）的子项。

    样本 < DEGENERATE_MIN_N → 返回空（不判定，避免单题误剔）。
    design/innovation 这类大量 None 的不计入（present 不足也不判）。
    """
    n = len(question_scores)
    if n < DEGENERATE_MIN_N:
        return []
    getter = _DIM_GETTER[dim_key]
    keys = list(getter(question_scores[0]).keys()) if question_scores else []
    deg = []
    for k in keys:
        present = [getter(q).get(k) for q in question_scores if getter(q).get(k) is not None]
        if len(present) >= DEGENERATE_MIN_N and _variance(present) < DEGENERATE_VAR_THRESHOLD:
            deg.append(k)
    return deg


def aggregate(question_scores: List[QuestionScore], kg_quality: Dict[str, Any],
              drop_degenerate: bool = True) -> Dict[str, Any]:
    # ① 退化子项检测 + 有效权重（剔除退化子项后在剩余子项间重归一）
    degenerate: Dict[str, List[str]] = {}
    eff_weights: Dict[str, Dict[str, float]] = {}
    for dimk in ("retrieval_quality", "reasoning_quality", "answer_quality"):
        deg = _detect_degenerate(question_scores, dimk) if drop_degenerate else []
        eff = {k: w for k, w in _DIM_SUBWEIGHTS[dimk].items() if k not in deg}
        # 保护：若全部子项都被判退化 → 不剔除、保留全权重（避免整个维度凭空消失）
        if not eff:
            deg = []
            eff = dict(_DIM_SUBWEIGHTS[dimk])
        degenerate[dimk] = deg
        eff_weights[dimk] = eff

    # ② 用有效权重重算每题三维分（写回 dimension_scores，保证报告/排序一致）
    for q in question_scores:
        for dimk in ("retrieval_quality", "reasoning_quality", "answer_quality"):
            q.dimension_scores[dimk] = weighted(_DIM_GETTER[dimk](q), eff_weights[dimk])

    dim = {
        "kg_quality": kg_quality["score"],
        "retrieval_quality": _avg([q.dimension_scores["retrieval_quality"] for q in question_scores]),
        "reasoning_quality": _avg([q.dimension_scores["reasoning_quality"] for q in question_scores]),
        "answer_quality": _avg([q.dimension_scores["answer_quality"] for q in question_scores]),
    }
    overall = weighted(dim, config.DIMENSION_WEIGHTS)

    by_diff: Dict[str, Any] = {}
    for lvl in ("L1", "L2", "L3", "L4"):
        sub = [q for q in question_scores if q.difficulty_level == lvl]
        if not sub:
            continue
        by_diff[lvl] = {
            "n": len(sub),
            "retrieval_quality": _avg([q.dimension_scores["retrieval_quality"] for q in sub]),
            "reasoning_quality": _avg([q.dimension_scores["reasoning_quality"] for q in sub]),
            "answer_quality": _avg([q.dimension_scores["answer_quality"] for q in sub]),
        }

    # 各维子项均值（供诊断定位最弱子项；保留全部子项含退化的，附 degenerate 标记）
    def sub_avg(getter) -> Dict[str, Optional[float]]:
        keys = getter(question_scores[0]) if question_scores else {}
        return {k: _avg([getter(q).get(k) for q in question_scores]) for k in keys}

    breakdown = {
        "kg_quality": kg_quality["submetrics"],
        "retrieval_quality": sub_avg(lambda q: q.retrieval["submetrics"]) if question_scores else {},
        "reasoning_quality": sub_avg(lambda q: q.reasoning["submetrics"]) if question_scores else {},
        "answer_quality": sub_avg(lambda q: q.answer["submetrics"]) if question_scores else {},
    }

    return {
        "overall_kgqa_score": overall,
        "dimension_scores": dim,
        "breakdown": breakdown,
        "degenerate_submetrics": degenerate,        # 各维被剔除（无区分度）的子项
        "drop_degenerate": drop_degenerate,
        "degenerate_min_n": DEGENERATE_MIN_N,
        "by_difficulty": by_diff,
        "kg_quality_detail": kg_quality,
        "n_questions": len(question_scores),
        "n_judge_ok": sum(1 for q in question_scores if q.judge_ok),
    }
