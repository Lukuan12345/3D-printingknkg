# -*- coding: utf-8 -*-
"""report.py —— 落 report.json + report.md（含四维分、子项明细、最弱维诊断、优化建议）。"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List


def _fmt(v) -> str:
    return "—" if v is None else f"{v:.3f}"


def build_report(cfg, aggregate_result: Dict[str, Any], diagnosis: Dict[str, Any],
                 question_scores: List, answers: List) -> Dict[str, Any]:
    return {
        "meta": {
            "db": str(cfg.db_path),
            "questions_dir": str(cfg.questions_dir),
            "n_questions": aggregate_result["n_questions"],
            "n_judge_ok": aggregate_result["n_judge_ok"],
            "n_answer_failed": sum(1 for a in answers if getattr(a, "answer_failed", False)),
            "judge_model": cfg.llm_model if cfg.use_judge else None,
            "judge_enabled": cfg.use_judge,
            "timestamp": datetime.now().isoformat(timespec="seconds"),
        },
        "overall_kgqa_score": aggregate_result["overall_kgqa_score"],
        "dimension_scores": aggregate_result["dimension_scores"],
        "breakdown": aggregate_result["breakdown"],
        "degenerate_submetrics": aggregate_result.get("degenerate_submetrics", {}),
        "kg_quality_detail": aggregate_result["kg_quality_detail"],
        "by_difficulty": aggregate_result["by_difficulty"],
        "diagnosis": diagnosis,
        "per_question": [
            {
                "id": q.qid,
                "difficulty": q.difficulty_level,
                "domain": q.domain,
                "dimension_scores": q.dimension_scores,
                "retrieval_submetrics": q.retrieval.get("submetrics"),
                "reasoning_submetrics": q.reasoning.get("submetrics"),
                "answer_submetrics": q.answer.get("submetrics"),
                "judge_ok": q.judge_ok,
                "error": q.error,
            }
            for q in question_scores
        ],
    }


def write_json(path: Path, report: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")


def write_answers(path: Path, answers: List) -> None:
    """落原始答案，便于离线重打分。"""
    path.parent.mkdir(parents=True, exist_ok=True)
    data = [
        {
            "qid": a.qid, "query": a.query, "intent": a.intent,
            "answer": a.answer, "reasoning_paths": a.reasoning_paths,
            "evidence": a.evidence, "retrieval_plan": a.retrieval_plan,
            "confidence": a.confidence, "error": a.error,
        }
        for a in answers
    ]
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


_DIM_ZH = {
    "kg_quality": "KG Quality 图谱质量",
    "retrieval_quality": "Retrieval Quality 检索质量",
    "reasoning_quality": "Reasoning Quality 推理质量",
    "answer_quality": "Answer Quality 答案质量",
}


def write_markdown(path: Path, report: Dict[str, Any]) -> None:
    m = report["meta"]
    dim = report["dimension_scores"]
    diag = report["diagnosis"]
    bd = report["breakdown"]
    lines: List[str] = []
    lines.append("# 步骤 ⑩ 图谱测评报告\n")
    lines.append(f"- 图谱库：`{m['db']}`")
    lines.append(f"- 题目目录：`{m['questions_dir']}`")
    lines.append(f"- 题目数：{m['n_questions']}　LLM-Judge：{'开启' if m['judge_enabled'] else '关闭'}"
                 f"（成功 {m['n_judge_ok']} 题，模型 {m['judge_model']}）")
    lines.append(f"- 生成时间：{m['timestamp']}\n")

    lines.append(f"## 综合 KGQA-Score：**{_fmt(report['overall_kgqa_score'])}**\n")

    lines.append("## 四维得分\n")
    lines.append("| 维度 | 得分 |")
    lines.append("|---|---|")
    for k, v in dim.items():
        lines.append(f"| {_DIM_ZH.get(k, k)} | {_fmt(v)} |")
    lines.append("")

    # 诊断（最弱维红字）
    wd = diag.get("weakest_dimension")
    ws = diag.get("weakest_submetric")
    lines.append("## 🔴 最需要优化\n")
    lines.append(f"**最弱维度：{_DIM_ZH.get(wd, wd)}**　最弱子项：`{ws}`\n")
    if diag.get("unimplemented_components"):
        lines.append(f"**本图谱未实现的层（已从评分剔除，不计分）**：{', '.join(diag['unimplemented_components'])}"
                     f"　——　KG Quality 仅按已构建的层计分。\n")
    if diag.get("missing_layers"):
        lines.append(f"<small>（细分未建子项，供参考：{', '.join(diag['missing_layers'])}）</small>\n")

    lines.append("### 维度排序（由弱到强）\n")
    for r in diag.get("ranked_dimensions", []):
        lines.append(f"- {_DIM_ZH.get(r['dimension'], r['dimension'])}：{_fmt(r['score'])}")
    lines.append("")

    lines.append("## 优化建议\n")
    for i, s in enumerate(diag.get("optimization_suggestions", []), 1):
        lines.append(f"**{i}. [{s.get('target')}]**（子项 `{s.get('submetric')}`）")
        lines.append(f"- 动作：{s.get('action')}")
        lines.append(f"- 原因：{s.get('why')}")
        if s.get("fixes_submetric"):
            lines.append(f"- 连带改善：{', '.join(s['fixes_submetric'])}")
        lines.append("")

    # 子项明细
    degen = set(report.get("diagnosis", {}).get("degenerate_submetrics", []))
    lines.append("## 子项明细\n")
    if degen:
        lines.append(f"> 标 ⚠️ 的子项跨题方差≈0（结构性恒定、无区分度），**已从该维度评分中剔除并按剩余子项重归一**（仍展示其值供参考）。\n")
    for d in ("kg_quality", "retrieval_quality", "reasoning_quality", "answer_quality"):
        lines.append(f"### {_DIM_ZH.get(d, d)}")
        for k, v in (bd.get(d) or {}).items():
            tag = " ⚠️(无区分度，不计分)" if f"{d}.{k}" in degen else ""
            lines.append(f"- {k}: {_fmt(v)}{tag}")
        lines.append("")

    # 难度分层
    if report.get("by_difficulty"):
        lines.append("## 按难度分层\n")
        lines.append("| 难度 | N | Retrieval | Reasoning | Answer |")
        lines.append("|---|---|---|---|---|")
        for lvl, v in report["by_difficulty"].items():
            lines.append(f"| {lvl} | {v['n']} | {_fmt(v['retrieval_quality'])} | "
                         f"{_fmt(v['reasoning_quality'])} | {_fmt(v['answer_quality'])} |")
        lines.append("")

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")
