# -*- coding: utf-8 -*-
"""semantic.py —— 跨语言节点语义匹配。

gold 期望节点常是中文长句、pred 路径节点是英文 Concept 名，token 重叠≈0，
导致 path_recall / multihop_coherence / key_node_hit 被严重低估。这里复用
QAEngine 同款 BGE-M3（多语言）embedding，按余弦相似度做跨语言匹配，
作为 token 匹配失败时的兜底。

embedding 客户端不可用（无网/无模型）时自动禁用，回退纯 token 匹配，不报错。
"""

from __future__ import annotations

import threading
from typing import Dict, List, Optional


class SemanticMatcher:
    """惰性加载 embedding 客户端，缓存向量，按需算两段文本的余弦相似度。

    线程安全：图谱测评可并发逐题打分，缓存读写与惰性加载用一把锁保护。
    """

    def __init__(self, threshold: float = 0.55):
        self.threshold = threshold
        self._client = None
        self._cache: Dict[str, "object"] = {}
        self._ok: Optional[bool] = None   # None=未尝试, True/False=可用性
        self._lock = threading.Lock()

    # ── 可用性 ────────────────────────────────────────────────────────────────
    def _ensure(self) -> bool:
        if self._ok is None:
            with self._lock:
                if self._ok is None:   # double-checked，避免并发重复初始化
                    try:
                        from kb_mvp.src.embedding import get_client
                        self._client = get_client()
                        self._ok = True
                    except Exception:
                        self._ok = False
        return bool(self._ok)

    def enabled(self) -> bool:
        return self._ensure()

    # ── 批量嵌入（带缓存）────────────────────────────────────────────────────
    def _embed_missing(self, texts: List[str]) -> None:
        with self._lock:
            todo = [t for t in dict.fromkeys(texts) if t and t not in self._cache]
        if not todo or not self._ensure():
            return
        try:
            import numpy as np
            vecs = np.asarray(self._client.embed(todo), dtype=np.float32)
            norms = np.linalg.norm(vecs, axis=1, keepdims=True)
            norms = np.where(norms == 0, 1.0, norms)
            vecs = vecs / norms
            with self._lock:
                for t, v in zip(todo, vecs):
                    self._cache[t] = v
        except Exception:
            # 单次嵌入失败：标记不可用，后续回退 token
            self._ok = False

    def warm(self, texts: List[str]) -> None:
        """预热：一次性批量嵌入（每题把 gold 节点 + pred 节点一起喂进来更省。）"""
        self._embed_missing([t for t in texts if t])

    # ── 相似度 / 匹配 ─────────────────────────────────────────────────────────
    def sim(self, a: str, b: str) -> float:
        if not a or not b or not self._ensure():
            return 0.0
        self._embed_missing([a, b])
        va, vb = self._cache.get(a), self._cache.get(b)
        if va is None or vb is None:
            return 0.0
        try:
            import numpy as np
            return float(np.dot(va, vb))
        except Exception:
            return 0.0

    def matches(self, a: str, b: str) -> bool:
        return self.sim(a, b) >= self.threshold
