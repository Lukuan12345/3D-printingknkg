# -*- coding: utf-8 -*-
"""qa_runner.py —— 用 scientific_kgqa 的 QAEngine 回答每道题，并把返回规整为评测输入。

复用（不重写）图谱查询：
    from scientific_kgqa.storage import SQLiteStore
    from scientific_kgqa.retriever import Retriever
    from scientific_kgqa.qa_engine import QAEngine

QAEngine.answer(query) 返回：
    {query, intent, summary(=答案文本), reasoning_paths(["Type:name -> Type:name", ...]),
     evidence([{paper_id,paper_title,year,chunk_type,score,text,...}]),
     retrieval_plan{seed_ids, seed_nodes, soft_node_ids, soft_nodes, posting_node_ids, ...},
     confidence}
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Tuple


@dataclass
class AnswerRecord:
    qid: str
    query: str
    intent: str
    answer: str                          # = QAEngine summary
    reasoning_paths: List[str]           # 原始 "Type:name -> Type:name" 字符串
    path_typed_nodes: List[List[Tuple[str, str]]]  # 每条路径解析成 [(type, name), ...]
    evidence: List[Dict[str, Any]]
    soft_nodes: List[Dict[str, Any]]     # retrieval_plan.soft_nodes（含 type+name）
    retrieval_plan: Dict[str, Any]
    confidence: float
    raw: Dict[str, Any] = field(default_factory=dict)
    error: str = ""
    answer_failed: bool = False          # LLM 综合答案生成失败（空响应等）→ Answer 维度不计分

    @property
    def pred_source_texts(self) -> List[str]:
        return [e.get("text", "") for e in self.evidence if isinstance(e, dict) and e.get("text")]

    @property
    def used_node_types(self) -> set:
        """pred 路径里出现过的所有 node_type（用于 CrossLayerUse）。"""
        types = set()
        for path in self.path_typed_nodes:
            for t, _ in path:
                if t:
                    types.add(t)
        return types

    @property
    def uses_concept_backbone(self) -> bool:
        """路径是否用到 Concept 节点（ConceptBackboneUse 的结构信号之一）。"""
        return any(t == "Concept" for path in self.path_typed_nodes for t, _ in path)


_PATH_NODE_RE = re.compile(
    r"^(SchemaField|Concept|Prototype|MetricBucket|Cluster|ChunkType|Paper)\s*:\s*(.+)$"
)


def _parse_typed_path(path_str: str) -> List[Tuple[str, str]]:
    """把 "Concept:foo -> SchemaField:bar" 解析成 [("Concept","foo"),("SchemaField","bar")]。"""
    out: List[Tuple[str, str]] = []
    for part in re.split(r"\s*->\s*", path_str or ""):
        part = part.strip()
        if not part:
            continue
        m = _PATH_NODE_RE.match(part)
        if m:
            out.append((m.group(1), m.group(2).strip()))
        else:
            out.append(("", part))
    return out


def build_engine(db_path: str, retriever_path: str, llm_client=None):
    """构造 QAEngine（延迟 import，避免无依赖环境下导入失败）。

    llm_client 非空时传入引擎，启用查询翻译 + LLM 抽种子 + embedding 语义映射
    （真实闭环建议开启，对 80k 概念图谱的 seed 映射质量影响很大）。
    """
    from scientific_kgqa.storage import SQLiteStore
    from scientific_kgqa.retriever import Retriever
    from scientific_kgqa.qa_engine import QAEngine

    store = SQLiteStore(db_path)
    retriever = Retriever.load(retriever_path)
    engine = QAEngine(store, retriever, llm_client=llm_client)
    return engine, store


def load_kb(db_path: str, retriever_path: str):
    """只加载 store + retriever（不建 QAEngine）——给 fast(KB-only) 检索用。"""
    from scientific_kgqa.storage import SQLiteStore
    from scientific_kgqa.retriever import Retriever
    store = SQLiteStore(db_path)
    retriever = Retriever.load(retriever_path)
    return store, retriever


def answer_kb_only(store, retriever, gold, topk: int = 60, max_evidence: int = 5) -> AnswerRecord:
    """fast 模式：纯知识库检索（绕过 KG 图谱游走）——retriever 对全库 chunk 做 BM25+TF-IDF。

    不产生图谱推理路径（reasoning_paths 空）——这正反映"没用图谱推理"，
    与 deep(KG+KB) 对比即可量化图谱检索/推理的增益。答案随后由 synthesize_answer 接 LLM 生成。
    """
    try:
        hits = retriever.search(gold.question, candidate_chunk_ids=None, topk=topk)
    except Exception as exc:  # noqa: BLE001
        return AnswerRecord(
            qid=gold.qid, query=gold.question, intent="", answer="",
            reasoning_paths=[], path_typed_nodes=[], evidence=[], soft_nodes=[],
            retrieval_plan={"mode": "kb_only"}, confidence=0.0,
            error=f"kb_search: {type(exc).__name__}: {exc}",
        )
    evidence = []
    for h in (hits or [])[:max_evidence]:
        title = h.get("paper_id", "")
        try:
            chunk = store.get_chunk(h["chunk_id"])
            if chunk and chunk.get("paper_title"):
                title = chunk["paper_title"]
        except Exception:
            pass
        evidence.append({
            "paper_id": h.get("paper_id"),
            "paper_title": title,
            "chunk_type": h.get("chunk_type"),
            "score": round(float(h.get("score", 0.0)), 4),
            "text": h.get("text", ""),
        })
    return AnswerRecord(
        qid=gold.qid, query=gold.question, intent="", answer="",
        reasoning_paths=[], path_typed_nodes=[], evidence=evidence, soft_nodes=[],
        retrieval_plan={"mode": "kb_only", "n_hits": len(hits or [])}, confidence=0.4,
    )


def run_question(engine, gold) -> AnswerRecord:
    """对单题调 engine.answer，规整成 AnswerRecord；异常不致命，记 error。"""
    try:
        res = engine.answer(gold.question)
    except Exception as exc:  # noqa: BLE001
        return AnswerRecord(
            qid=gold.qid, query=gold.question, intent="", answer="",
            reasoning_paths=[], path_typed_nodes=[], evidence=[], soft_nodes=[],
            retrieval_plan={}, confidence=0.0, error=f"{type(exc).__name__}: {exc}",
        )

    paths = list(res.get("reasoning_paths") or [])
    plan = res.get("retrieval_plan") or {}
    return AnswerRecord(
        qid=gold.qid,
        query=res.get("query", gold.question),
        intent=res.get("intent", ""),
        answer=res.get("summary", ""),
        reasoning_paths=paths,
        path_typed_nodes=[_parse_typed_path(p) for p in paths],
        evidence=list(res.get("evidence") or []),
        soft_nodes=list(plan.get("soft_nodes") or []),
        retrieval_plan=plan,
        confidence=float(res.get("confidence") or 0.0),
        raw=res,
    )


_NO_GRAPH_SYS = (
    "你是某科学领域的资深专家。仅凭你自身知识回答下面的问题，"
    "不依赖任何外部检索或知识图谱。直接给出准确、简洁的答案。只输出答案正文。"
)


_SYNTH_SYS = (
    "你是某科学领域的资深专家。下面给出一个问题，以及图谱检索到的证据片段与推理路径。"
    "请**严格基于这些证据**综合出准确、可追溯的答案：数值/结论必须来自证据，不要编造；"
    "若证据不足以回答，明确指出缺哪类信息。只输出 JSON：{\"answer\": \"...\"}"
)


def synthesize_answer(llm, gold, rec: "AnswerRecord", fallback_models=None) -> str:
    """图谱检索之后接 LLM 推理：基于检索到的证据 + 路径生成真正的答案（RAG 式）。

    这一步弥补 QAEngine.summary 只是模板摘要、不调 LLM 生成答案的缺口。
    deep 模式专用。

    fallback_models：备用模型名列表（如推理链第二项）。主模型空响应/异常时依次重试，
    仍全部失败 → 设 rec.answer_failed=True 并保持原摘要（评分阶段该题 Answer 维度不计分，
    避免基础设施空响应被当真实低分污染均值）。
    """
    if llm is None:
        return rec.answer
    ev_lines = []
    for e in (rec.evidence or [])[:6]:
        if isinstance(e, dict) and e.get("text"):
            ev_lines.append(f"- [{e.get('paper_title','?')}] {e['text'][:400]}")
    paths = "\n".join(f"- {p}" for p in (rec.reasoning_paths or [])[:6]) or "(无)"
    user = (
        f"问题：{gold.question}\n\n"
        f"图谱检索到的证据：\n{chr(10).join(ev_lines) or '(无证据)'}\n\n"
        f"图谱推理路径：\n{paths}\n\n"
        '请只输出 JSON：{"answer": "..."}'
    )

    def _try(client) -> str:
        res = client.chat_json(_SYNTH_SYS, user, temperature=0.1)
        ans = (res.get("answer") if isinstance(res, dict) else None) or ""
        if not ans and isinstance(res, dict):
            ans = next((v for v in res.values() if isinstance(v, str) and v.strip()), "")
        return str(ans).strip()

    # 主模型
    try:
        ans = _try(llm)
        if ans:
            return ans
    except Exception:
        pass

    # 备用模型链降级（空响应/异常时）
    for m in (fallback_models or []):
        try:
            from scientific_kgqa.llm_client import LLMClient
            alt = LLMClient(api_key=getattr(llm, "api_key", ""), model=m,
                            base_url=getattr(llm, "base_url", ""))
            ans = _try(alt)
            if ans:
                return ans
        except Exception:
            continue

    # 全部失败 → 标记，保持原摘要（评分阶段 Answer 维度记 None，不污染均值）
    rec.answer_failed = True
    return rec.answer


def answer_without_graph(llm, gold, domain_instruction: str = "") -> AnswerRecord:
    """w/o 图谱检索消融：不接图谱，纯 LLM 直接答题（无证据 / 无路径）作 baseline。

    llm 为 scientific_kgqa.llm_client.LLMClient（chat_json）；为 None 或异常 → 空答案。
    """
    if llm is None:
        return AnswerRecord(
            qid=gold.qid, query=gold.question, intent="", answer="",
            reasoning_paths=[], path_typed_nodes=[], evidence=[], soft_nodes=[],
            retrieval_plan={}, confidence=0.0, error="no-graph 需要 LLM，但未配置可用 LLM",
        )
    sys_prompt = (_NO_GRAPH_SYS + ("\n领域背景：" + domain_instruction if domain_instruction else ""))
    user = f'问题：{gold.question}\n请只输出 JSON：{{"answer": "..."}}'
    try:
        res = llm.chat_json(sys_prompt, user, temperature=0.1)
        ans = (res.get("answer") if isinstance(res, dict) else None) or ""
        if not ans and isinstance(res, dict):
            # 模型未按 JSON 输出时兜底取任意字符串字段
            ans = next((v for v in res.values() if isinstance(v, str) and v.strip()), "")
    except Exception as exc:  # noqa: BLE001
        return AnswerRecord(
            qid=gold.qid, query=gold.question, intent="", answer="",
            reasoning_paths=[], path_typed_nodes=[], evidence=[], soft_nodes=[],
            retrieval_plan={}, confidence=0.0, error=f"no-graph LLM error: {type(exc).__name__}",
        )
    return AnswerRecord(
        qid=gold.qid, query=gold.question, intent="", answer=str(ans),
        reasoning_paths=[], path_typed_nodes=[], evidence=[], soft_nodes=[],
        retrieval_plan={"baseline": "no_graph"}, confidence=0.3,
    )
