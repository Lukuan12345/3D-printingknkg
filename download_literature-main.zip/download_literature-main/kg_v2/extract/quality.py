#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""quality.py —— Observation Pattern 质检：实测值是否绑定了应有的实验条件。

用 P1 的 bind_by_field（field → "material_system;material_state;test_condition"）核对每个
Measurement 的 bound{}，产出 quality_flags + condition_binding_rate（核心 KPI）。
"""
from __future__ import annotations

from typing import Dict, List, Tuple


def _required_keys(field: str, bind_by_field: Dict[str, str]) -> List[str]:
    return [k.strip() for k in (bind_by_field.get(field, "") or "").split(";") if k.strip()]


def quality_flags(measurements: List[dict], bind_by_field: Dict[str, str]) -> List[dict]:
    flags: List[dict] = []
    for i, m in enumerate(measurements or []):
        field = (m.get("field") or "").lstrip("_")
        required = _required_keys(field, bind_by_field)
        if not required:
            continue  # 该字段无强制绑定要求
        bound = m.get("bound") or {}
        missing = [k for k in required if not str(bound.get(k, "")).strip()]
        if missing:
            flags.append({"index": i, "field": m.get("field", ""),
                          "issue": "missing required binding: " + ", ".join(missing)})
    return flags


def binding_rate(measurements: List[dict], bind_by_field: Dict[str, str]) -> Tuple[int, int, float]:
    """返回 (已绑定, 应绑定, 比率)。仅统计 schema 要求绑定的观测类测量。"""
    total = bound_ok = 0
    for m in measurements or []:
        field = (m.get("field") or "").lstrip("_")
        required = _required_keys(field, bind_by_field)
        if not required:
            continue
        total += 1
        b = m.get("bound") or {}
        if all(str(b.get(k, "")).strip() for k in required):
            bound_ok += 1
    return bound_ok, total, (bound_ok / total if total else 0.0)
