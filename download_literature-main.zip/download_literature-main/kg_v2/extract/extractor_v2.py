#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""extractor_v2.py —— 单篇单次 Haiku 调用的分层抽取核心。

复用 gen_key 的 AsyncLLMClient（Haiku + JSON 截断救援 + 退避重试），
一次调用产出六键 JSON，并附上 Observation 质检结果。
"""
from __future__ import annotations

import time
from typing import Dict, List, Optional

from llm_extract.core.llm_client import AsyncLLMClient  # 复用 gen_key 的 Haiku 客户端

try:
    from ..schema.layered_schema import LayeredSchema
    from .prompts import build_extract_prompt, SYSTEM_PROMPT
    from .quality import quality_flags, binding_rate
except ImportError:  # pragma: no cover
    from kg_v2.schema.layered_schema import LayeredSchema  # type: ignore
    from kg_v2.extract.prompts import build_extract_prompt, SYSTEM_PROMPT  # type: ignore
    from kg_v2.extract.quality import quality_flags, binding_rate  # type: ignore

_KEYS = ["Narrative", "Measurements", "TableRecords", "Discoveries", "Concepts", "Reference", "Relations"]


def prepare_paper_text(paper_id: str, md_text: str, body_char_cap: int = 90000) -> str:
    body = md_text or ""
    if len(body) > body_char_cap:
        body = body[:body_char_cap] + "\n...[truncated]"
    return f"# Paper ID: {paper_id}\n\n{body}"


def _normalize(obj) -> Dict:
    """把模型输出规整成六键 dict（容忍各种包装/缺键）。"""
    if not isinstance(obj, dict):
        obj = {}
    # 容忍单数/大小写别名
    alias = {"measurements": "Measurements", "discoveries": "Discoveries",
             "concepts": "Concepts", "relations": "Relations",
             "reference": "Reference", "references": "Reference", "narrative": "Narrative",
             "tablerecords": "TableRecords", "table_records": "TableRecords", "tables": "TableRecords"}
    for k, v in list(obj.items()):
        if k in alias and alias[k] not in obj:
            obj[alias[k]] = v
    out = {k: obj.get(k) for k in _KEYS}
    out["Narrative"] = out["Narrative"] or {}
    out["Reference"] = out["Reference"] or {}
    for k in ("Measurements", "TableRecords", "Discoveries", "Concepts", "Relations"):
        out[k] = out[k] if isinstance(out[k], list) else []
    return out


async def extract_paper(
    client: AsyncLLMClient,
    model: str,
    schema: LayeredSchema,
    paper_id: str,
    md_text: str,
    paper_domains: Optional[List[str]] = None,
    max_tokens: int = 60000,
) -> Dict:
    t0 = time.time()
    prompt = build_extract_prompt(schema, prepare_paper_text(paper_id, md_text), paper_domains)
    raw = await client.call_json(
        prompt, model, system_prompt=SYSTEM_PROMPT, temperature=0.0, max_tokens=max_tokens)
    layered = _normalize(raw)

    bound_ok, bound_total, rate = binding_rate(layered["Measurements"], schema.bind_by_field)
    flags = quality_flags(layered["Measurements"], schema.bind_by_field)
    return {
        "paper_id": paper_id,
        "model": model,
        "domains": paper_domains or [],
        "layered": layered,
        "_quality": {
            "n_measurements": len(layered["Measurements"]),
            "n_table_records": len(layered["TableRecords"]),
            "n_discoveries": len(layered["Discoveries"]),
            "n_concepts": len(layered["Concepts"]),
            "n_relations": len(layered["Relations"]),
            "obs_bound": bound_ok, "obs_total": bound_total,
            "condition_binding_rate": round(rate, 4),
            "flags": flags,
        },
        "elapsed_ms": int((time.time() - t0) * 1000),
    }
