#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""prompts.py —— P2 单调用分层抽取的 prompt 组装。

一个 prompt 注入三块领域 schema（Narrative / Measurement / Discovery），
要求 Haiku 一次性输出六键 JSON：
  {Narrative, Measurements[], Discoveries[], Concepts[], Reference{}, Relations[]}
核心是 Observation Pattern：每个测量值都必须带 bound{} 实验条件。
"""
from __future__ import annotations

from typing import List, Optional

try:
    from ..schema.layered_schema import LayeredSchema
except ImportError:  # pragma: no cover
    from kg_v2.schema.layered_schema import LayeredSchema  # type: ignore

SYSTEM_PROMPT = "You are a meticulous materials-science knowledge-graph extractor. Output ONLY one raw JSON object, no prose, no code fences."

# bound 的固定键集合（领域无关，覆盖 Mg/Ti/Al/增材）
BOUND_KEYS = ["material_system", "material_state", "process_state",
              "test_condition", "specimen_source", "orientation", "temperature"]

_TEMPLATE = """# Task
Extract a layered knowledge graph from ONE alloy / materials-science paper for reverse (retrosynthesis) analysis.
Read the paper text at the end. Produce ONE JSON object with EXACTLY these keys:
{{"Narrative": {{...}}, "Measurements": [...], "TableRecords": [...], "Discoveries": [...], "Concepts": [...], "Reference": {{...}}, "Relations": [...]}}

Use the field names from the schema blocks below where applicable. If a value exists but no schema field fits,
use a field name prefixed with "_". Never invent values not supported by the text. Leave unknowns as "".

# (A) Narrative schema — paper-level problem / requirements / context
{NARRATIVE_SCHEMA}

# (B) Measurement schema — concrete measured/parameter values
{MEASUREMENT_SCHEMA}

# (C) Discovery schema — mechanism / causal chain / optimization / design rules
{DISCOVERY_SCHEMA}

# Output specification
{{
  "Narrative": {{
    "problem_statement": "one sentence: the core metallurgical/design problem",
    "design_object": "alloy/material/process under study",
    "application_scenario": ["..."],
    "requirements": [
      {{"metric": "<field e.g. ultimate_tensile_strength>", "operator": ">=|<=|=|~",
       "threshold": "350", "unit": "MPa", "constraint_type": "hard|soft|target",
       "evidence": "original sentence"}}
    ],
    "domain_fields": {{"<narrative schema field>": ["value", ...]}}
  }},

  "Measurements": [
    {{
      "field": "<MUST be a Measurement-schema field, or _custom>",
      "role": "observation|variable|condition",
      "value_raw": "1100 MPa", "value_num": 1100, "value_high": null,
      "unit": "MPa", "value_type": "number_with_unit|range|categorical|list|string",
      "bound": {{ {BOUND_KEYS_JSON} }},
      "evidence": "original sentence or table cell", "section": "results|methods|table|abstract",
      "table_id": "table/figure number if from one, else \\"\\""
    }}
  ],

  "TableRecords": [
    {{
      "record_type": "binary_alloy_parameter|alloy_grade_composition|property_table_row|generic_table_row",
      "solvent": "Ni", "solute": "Ba", "binary_system": "Ni-Ba",
      "material_name": "alloy grade if this row is a named alloy, else \\"\\"",
      "parameters": {{ "radius_ratio": 1.7859, "energy_ratio": 0.4163, "mott_number": 7.994,
                       "hildebrand_factor": 181876, "electronegativity_difference": 0.99 }},
      "parameter_basis": "calculated|measured|nominal",
      "source": {{ "table_id": "TABLE III-47", "row_label": "BARIUM",
                   "column_labels": ["radius_ratio","energy_ratio","mott_number","hildebrand_factor","electronegativity_difference"] }}
    }}
  ],

  "Discoveries": [
    {{
      "field": "<Discovery-schema field if any, else _custom>",
      "mechanism_type": "strengthening|defect_formation|phase_transformation|solidification|tradeoff|design_rule|other",
      "statement": "concise mechanism / rule statement",
      "causal_chain": ["cause", "intermediate", "...", "effect"],
      "polarity": "increase|decrease|enable|inhibit|tradeoff|n/a",
      "recommended_window": "e.g. solution 870C/1h + aging 500C/8h (if stated, else \\"\\")",
      "evidence": "original sentence", "section": "discussion|results|table",
      "claim_source": "explicit|inferred|general_domain_knowledge",
      "confidence": "high|medium|low"
    }}
  ],

  "Concepts": [
    {{"atoms": ["1-4 word noun phrases"], "claim": "8-20 words: what THIS paper does with these atoms",
      "kind": "material|structure|mechanism|technique|property", "related_fields": ["schema field"],
      "confidence": "high|medium|low"}}
  ],

  "Reference": {{
    "<reference title>": {{"authors": ["..."], "pub_time": 2019, "source": "journal/publisher",
                            "cite_identifier": "[12]", "cite_strength": 1}}
  }},

  "Relations": [
    {{"head": "entity", "head_type": "Measurement|Discovery|Concept|MaterialSystem|Process|Property|Condition",
      "relation": "CAUSES|ENABLES|INHIBITS|MODULATES|CONTROLS|TRADEOFF_WITH|IMPROVES|ACHIEVES|EXPLAINS|UNDER_CONDITION|FOR_MATERIAL",
      "tail": "entity", "tail_type": "...", "evidence": "original sentence",
      "category": "controlled|open", "confidence": "high|medium|low"}}
  ]
}}

# Rules (CRITICAL)
1. OBSERVATION PATTERN — every Measurement MUST carry `bound`. For any performance / property / defect
   observation you MUST fill `material_system`, `material_state` (process/heat-treat state), and `test_condition`
   (temperature, direction, standard…). If genuinely absent, use "" — never invent.
2. Emit ONE Measurement per (field, condition) combination. Extract from EVERY relevant table row.
3. requirements: capture each target/threshold the paper sets (e.g. "UTS >= 350 MPa"); pair metric with threshold+unit.
4. causal_chain: ordered short steps (process/structure → property). Discoveries explain mechanisms/optimization.
5. Concepts: 4-8 items, atoms are 1-4 English words, lowercase except acronyms (LPBF, VAR, HIP, TiAl).
6. Reference: parse the references list; cite_strength 1(peripheral)..5(foundational) by how central each cited work
   is to THIS paper. If no references section, return {{}}.
7. Relations: prefer controlled triples between entities you extracted in A/B/C; open mechanistic triples
   (new short entities) are allowed for causal links. Deduplicate.
   Use CAUSES/CONTROLS ONLY when the text states an experimental/physical mechanism. For a descriptor that merely
   predicts or correlates with a property (radius ratio, electronegativity, Hildebrand factor, Mott number, etc.),
   use PREDICTS or CORRELATES_WITH, not CAUSES/CONTROLS.
8. TABLE EXTRACTION (CRITICAL for data-handbook / parameter-compilation pages):
   When the text contains a data table where each ROW is a distinct entity (a solute element under a solvent header,
   or a named alloy grade), emit ONE TableRecords entry PER ROW — do NOT summarize as "varies by pair" or a single range.
   - The solvent usually comes from the section header (e.g. "SOLVENT-NICKEL"); the solute is the row's first column.
   - Put each numeric column into `parameters` keyed by a normalized field name; keep the table number in `source.table_id`.
   - OCR may be noisy (e.g. "RAT10"→ratio, "M011"→mott, "0:4163"→0.4163); recover the intended value when unambiguous, else "".
   - For composition tables, set record_type=alloy_grade_composition, material_name=<grade>, parameters={{element: value}}.
   Plain prose values still go to Measurements; TableRecords is ONLY for genuine row-wise tables.
9. claim_source on each Discovery: "explicit" if the paper states it directly; "inferred" if you derived it from the
   paper's data/trends; "general_domain_knowledge" if it is a textbook heuristic not specific to this text.
   Use "general_domain_knowledge" + confidence=low/medium for generic metallurgical rules of thumb.
10. evidence locator: when a value/claim comes from a table or figure, set `table_id` / `section` so it can be traced.
11. Output ONLY the JSON object.

# Paper
{PAPER_TEXT}
"""


def build_extract_prompt(schema: LayeredSchema, paper_text: str,
                         paper_domains: Optional[List[str]] = None) -> str:
    bound_json = ", ".join(f'"{k}": ""' for k in BOUND_KEYS)
    return (_TEMPLATE
            .replace("{NARRATIVE_SCHEMA}", schema.render_block("Narrative", paper_domains) or "(none)")
            .replace("{MEASUREMENT_SCHEMA}", schema.render_block("Measurement", paper_domains) or "(none)")
            .replace("{DISCOVERY_SCHEMA}", schema.render_block("Discovery", paper_domains) or "(none)")
            .replace("{BOUND_KEYS_JSON}", bound_json)
            .replace("{PAPER_TEXT}", paper_text))
