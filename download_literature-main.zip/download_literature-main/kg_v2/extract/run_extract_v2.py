#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""run_extract_v2.py —— P2 批量入口：对 content_store 的论文做单调用分层抽取。

复用 gen_key 的 Haiku 客户端与 .env 凭据（LLM_BASE_URL / LLM_API_KEY / LLM_MODEL）。
输出每篇一份 kb_v2/<paper_id>.json，并打印语料级 condition_binding_rate。

用法:
    python -m kg_v2.extract.run_extract_v2 \
        --layered kg_v2/meta_schema/layered_schema.json \
        --content-store scientific_kgqa/data/content_store \
        --out kg_v2/kb_v2 \
        [--limit 20] [--concurrency 8] [--model claude-haiku-4-5-20251001]
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
from pathlib import Path
from typing import Dict, List, Optional

from env_bootstrap import load_env
load_env()

from llm_extract.core.llm_client import AsyncLLMClient  # noqa: E402

try:
    from ..schema.layered_schema import LayeredSchema
    from .extractor_v2 import extract_paper
except ImportError:  # pragma: no cover
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
    from kg_v2.schema.layered_schema import LayeredSchema  # type: ignore
    from kg_v2.extract.extractor_v2 import extract_paper  # type: ignore

DEFAULT_MODEL = os.environ.get("LLM_MODEL", "claude-haiku-4-5-20251001")
_HERE = Path(__file__).resolve().parents[2]  # gen_key/


def _scan_papers(content_store: Path) -> List[Dict]:
    """content_store/<paper_id>/full.md → [{paper_id, md_path}]"""
    papers = []
    if not content_store.exists():
        return papers
    for sub in sorted(content_store.iterdir()):
        if not sub.is_dir():
            continue
        md = sub / "full.md"
        if md.exists():
            papers.append({"paper_id": sub.name, "md_path": md})
    return papers


def _load_domains_map(kb_json: Optional[Path]) -> Dict[str, List[str]]:
    """可选：从 knowledge_base.json 取 paper_id → domains（用于按领域裁剪 schema）。"""
    if not kb_json or not kb_json.exists():
        return {}
    try:
        data = json.loads(kb_json.read_text(encoding="utf-8"))
    except Exception:
        return {}
    out: Dict[str, List[str]] = {}
    papers = data.get("papers") if isinstance(data, dict) else data
    for p in (papers or []):
        pid = p.get("paper_id") or p.get("paper_uid")
        if pid:
            out[str(pid)] = p.get("domains") or []
    return out


async def _worker(client, model, schema, paper, domains, out_dir, sem, max_tokens):
    pid = paper["paper_id"]
    out_path = out_dir / f"{pid}.json"
    if out_path.exists():  # resume
        return ("skip", pid, None)
    async with sem:
        try:
            md = Path(paper["md_path"]).read_text(encoding="utf-8", errors="ignore")
            rec = await extract_paper(client, model, schema, pid, md,
                                      paper_domains=domains.get(pid), max_tokens=max_tokens)
            # 4.2 确定性表格解析：穷举 HTML 表行，覆盖 LLM 采样的 binary_alloy_parameter
            try:
                from .table_extract import merge_into_record
            except ImportError:
                from kg_v2.extract.table_extract import merge_into_record  # type: ignore
            merge_into_record(rec, md, replace=True)
            out_path.write_text(json.dumps(rec, ensure_ascii=False, indent=2), encoding="utf-8")
            q = rec["_quality"]
            return ("ok", pid, q)
        except Exception as e:  # noqa: BLE001
            return ("fail", pid, repr(e)[:200])


async def run(args) -> int:
    base_url = os.environ.get("LLM_BASE_URL", "")
    api_key = os.environ.get("LLM_API_KEY", "")
    if not base_url or not api_key:
        print("[ERROR] 需要 .env 里的 LLM_BASE_URL / LLM_API_KEY"); return 1

    schema = LayeredSchema(args.layered)
    out_dir = Path(args.out); out_dir.mkdir(parents=True, exist_ok=True)
    papers = _scan_papers(Path(args.content_store))
    if args.limit > 0:
        papers = papers[: args.limit]
    if not papers:
        print(f"[ERROR] {args.content_store} 下没有 <paper_id>/full.md"); return 1
    domains = _load_domains_map(Path(args.kb_json) if args.kb_json else None)

    print(f"[v2-extract] {len(papers)} 篇  model={args.model}  concurrency={args.concurrency}")
    print(f"  schema: Narrative={len(schema.by_node_type.get('Narrative',[]))} "
          f"Measurement={len(schema.by_node_type.get('Measurement',[]))} "
          f"Discovery={len(schema.by_node_type.get('Discovery',[]))} "
          f"| binding-fields={len(schema.bind_by_field)}")

    sem = asyncio.Semaphore(args.concurrency)
    async with AsyncLLMClient(base_url=base_url, api_key=api_key) as client:
        tasks = [_worker(client, args.model, schema, p, domains, out_dir, sem, args.max_tokens)
                 for p in papers]
        ok = skip = fail = 0
        agg_bound = agg_total = 0
        done = 0
        for fut in asyncio.as_completed(tasks):
            status, pid, info = await fut
            done += 1
            if status == "ok":
                ok += 1; agg_bound += info["obs_bound"]; agg_total += info["obs_total"]
                print(f"  [{done}/{len(papers)}] OK   {pid}  "
                      f"M={info['n_measurements']} D={info['n_discoveries']} "
                      f"C={info['n_concepts']} R={info['n_relations']} "
                      f"bind={info['condition_binding_rate']}")
            elif status == "skip":
                skip += 1
            else:
                fail += 1; print(f"  [{done}/{len(papers)}] FAIL {pid}: {info}")

    rate = (agg_bound / agg_total) if agg_total else 0.0
    print("=" * 60)
    print(f"[v2-extract] done  ok={ok} skip={skip} fail={fail}")
    print(f"  corpus condition_binding_rate = {agg_bound}/{agg_total} = {rate:.3f}")
    print(f"  -> {out_dir}")
    print("=" * 60)
    return 0


def main():
    ap = argparse.ArgumentParser(description="P2 单调用分层抽取（Haiku）")
    ap.add_argument("--layered", default=str(_HERE / "kg_v2" / "meta_schema" / "layered_schema.json"))
    ap.add_argument("--content-store", default=str(_HERE / "scientific_kgqa" / "data" / "content_store"))
    ap.add_argument("--kb-json", default="", help="可选 knowledge_base.json（取 paper→domains）")
    ap.add_argument("--out", default=str(_HERE / "kg_v2" / "kb_v2"))
    ap.add_argument("--model", default=DEFAULT_MODEL)
    ap.add_argument("--limit", type=int, default=0, help="只跑前 N 篇（0=全部）")
    ap.add_argument("--concurrency", type=int, default=8)
    ap.add_argument("--max-tokens", type=int, default=60000)
    args = ap.parse_args()
    raise SystemExit(asyncio.run(run(args)))


if __name__ == "__main__":
    main()
