#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""elements.py —— 元素名归一化（修 OCR：Bariua→Barium/Ba, GER MANI UM→Germanium/Ge）。

策略：去 OCR 噪声（空格/点/数字0↔O/1↔l）→ 精确匹配元素名/符号 → 编辑距离模糊匹配。
保留化合价后缀（Cerium+3）。返回 (canonical_name, symbol, confidence)。
"""
from __future__ import annotations

import re
from typing import Optional, Tuple

# 元素名 → 符号（覆盖到锕系，够这批合金手册用）
_ELEMENTS = {
    "hydrogen": "H", "helium": "He", "lithium": "Li", "beryllium": "Be", "boron": "B",
    "carbon": "C", "nitrogen": "N", "oxygen": "O", "fluorine": "F", "neon": "Ne",
    "sodium": "Na", "magnesium": "Mg", "aluminium": "Al", "aluminum": "Al",
    "silicon": "Si", "phosphorus": "P", "phosphorous": "P", "sulfur": "S", "sulphur": "S",
    "chlorine": "Cl", "argon": "Ar", "potassium": "K", "calcium": "Ca", "scandium": "Sc",
    "titanium": "Ti", "vanadium": "V", "chromium": "Cr", "manganese": "Mn", "iron": "Fe",
    "cobalt": "Co", "nickel": "Ni", "copper": "Cu", "zinc": "Zn", "gallium": "Ga",
    "germanium": "Ge", "arsenic": "As", "selenium": "Se", "bromine": "Br", "krypton": "Kr",
    "rubidium": "Rb", "strontium": "Sr", "yttrium": "Y", "zirconium": "Zr", "niobium": "Nb",
    "molybdenum": "Mo", "technetium": "Tc", "ruthenium": "Ru", "rhodium": "Rh",
    "palladium": "Pd", "silver": "Ag", "cadmium": "Cd", "indium": "In", "tin": "Sn",
    "antimony": "Sb", "tellurium": "Te", "iodine": "I", "xenon": "Xe", "cesium": "Cs",
    "caesium": "Cs", "barium": "Ba", "lanthanum": "La", "cerium": "Ce",
    "praseodymium": "Pr", "neodymium": "Nd", "promethium": "Pm", "samarium": "Sm",
    "europium": "Eu", "gadolinium": "Gd", "terbium": "Tb", "dysprosium": "Dy",
    "holmium": "Ho", "erbium": "Er", "thulium": "Tm", "ytterbium": "Yb", "lutetium": "Lu",
    "hafnium": "Hf", "tantalum": "Ta", "tungsten": "W", "wolfram": "W", "rhenium": "Re",
    "osmium": "Os", "iridium": "Ir", "platinum": "Pt", "gold": "Au", "mercury": "Hg",
    "thallium": "Tl", "lead": "Pb", "bismuth": "Bi", "polonium": "Po", "astatine": "At",
    "radon": "Rn", "francium": "Fr", "radium": "Ra", "actinium": "Ac", "thorium": "Th",
    "protactinium": "Pa", "uranium": "U", "neptunium": "Np", "plutonium": "Pu",
    "americium": "Am", "curium": "Cm",
}
_NAMES = list(_ELEMENTS.keys())
_SYMBOLS = {v.lower(): v for v in _ELEMENTS.values()}
_SYM_TO_NAME = {}
for _n, _s in _ELEMENTS.items():
    _SYM_TO_NAME.setdefault(_s.lower(), _n)


def _denoise(s: str) -> Tuple[str, str]:
    """去 OCR 噪声，返回 (核心字母串, 化合价后缀如 '+3')。"""
    s = (s or "").strip()
    m = re.search(r"([+-]\s*\d)\s*$", s)
    valence = re.sub(r"\s+", "", m.group(1)) if m else ""
    core = s[: m.start()] if m else s
    core = core.lower()
    core = re.sub(r"[\s.\-_:]+", "", core)     # 去空格/点/连字符
    core = re.sub(r"0", "o", core)             # 数字0→o（OCR）
    core = re.sub(r"1", "l", core)             # 数字1→l
    core = re.sub(r"[^a-z]", "", core)
    return core, valence


def _edit_distance(a: str, b: str, cap: int = 3) -> int:
    if abs(len(a) - len(b)) > cap:
        return cap + 1
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[-1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


def normalize_element(raw: str) -> Optional[Tuple[str, str, float]]:
    """raw → (canonical_name(+valence), symbol, confidence)；无法识别返回 None。"""
    if not raw or not raw.strip():
        return None
    core, valence = _denoise(raw)
    if not core or len(core) < 2:
        # 可能是符号
        sym = re.sub(r"[^a-zA-Z]", "", raw).strip()
        if sym.lower() in _SYMBOLS:
            s = _SYMBOLS[sym.lower()]
            return (_SYM_TO_NAME[s.lower()].title() + valence, s, 1.0)
        return None
    # 1) 精确符号
    if core in _SYMBOLS:
        s = _SYMBOLS[core]
        return (_SYM_TO_NAME[core].title() + valence, s, 1.0)
    # 2) 精确名
    if core in _ELEMENTS:
        return (core.title() + valence, _ELEMENTS[core], 1.0)
    # 3) 前缀/包含（GER MANI UM→germanium 去噪后 'germanium'）
    for n in _NAMES:
        if core == n.replace(" ", ""):
            return (n.title() + valence, _ELEMENTS[n], 1.0)
    # 4) 模糊（编辑距离）—— 修 bariua/ceriun/lanthanun
    best, bestd = None, 99
    for n in _NAMES:
        d = _edit_distance(core, n)
        if d < bestd:
            bestd, best = d, n
    if best is not None:
        tol = 1 if len(best) <= 5 else 2  # 短名严，长名松
        if bestd <= tol:
            conf = round(1 - bestd / max(len(best), 1), 2)
            return (best.title() + valence, _ELEMENTS[best], conf)
    return None
