"""kg_v2.extract —— P2 单调用分层抽取（Haiku）。"""
