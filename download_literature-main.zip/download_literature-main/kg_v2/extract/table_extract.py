#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""table_extract.py —— 4.2 确定性 HTML 表格解析（穷举行，不抽样，不调 LLM）。

数据手册/参数汇编类页面是高密度 HTML 表格（mineru 解析输出），
单次语义 LLM 调用只会采样几行（实测 914 行只抽 5 行）。本模块直接解析
`<table><tr><td>` 结构，逐行产出 TableRecords，与 LLM 语义抽取合流。

适配的表型（按 solvent 分节、solute 为行）:
  ## SOLVENT-NICKEL
  <table>
    <tr><td>SOLUTE</td><td>RADIUS RATIO</td><td>MOTT NUMBER</td>...</tr>
    <tr><td>BARIUM</td><td>1.7551</td><td>8.011</td>...</tr>
  ...
→ {record_type, solvent, solute, binary_system, parameters{col:val}, source{table_id,row_label}}

列名经 OCR 噪声归一化（RADIUS RAT10→radius_ratio, M011→mott_number…）；
数值清洗（:0.4250→0.4250, 164425.→164425, 1,234→1234）。无法识别的列保留原名。
通用回退：任何 <table> 都按"首列=行标签，其余=参数"解析为 generic_table_row。
"""
from __future__ import annotations

import re
from typing import Dict, List, Optional, Tuple

# ── 列名归一化（OCR 噪声 → 规范字段名）────────────────────────────────────
_COL_CANON = [
    (r"ra[cd].{0,3}us.{0,3}rat|rad.{0,3}rat|^rati?0?$|^ra[cd]ius$|^racius", "radius_ratio"),
    (r"en[fe]rgy.{0,3}rat|^enfrgy|^en[fe]rgy", "energy_ratio"),
    (r"m0?[o0]?[i1l]{0,2}.{0,3}num|mott|^mo[i1l]{1,2}$|^number$", "mott_number"),
    (r"h[i1].{0,4}l.{0,4}[do].{0,4}br.{0,4}n|hildebrand|^hi_?l[do]|^hi_ld", "hildebrand_factor"),
    (r"e.{0,2}lectr.{0,3}neg.{0,4}diff|electroneg|f_?lectroneg", "electronegativity_difference"),
    (r"at.{0,3}m.{0,3}c.{0,3}rad|atomic.{0,3}radi|^at_?om", "atomic_radius"),
    (r"at.{0,3}m.{0,3}c.{0,3}vol|atomic.{0,3}vol", "atomic_volume"),
    (r"heat.{0,3}c?f?.{0,3}sublim|sublimation|^heat_cf", "heat_of_sublimation"),
    (r"melt.{0,3}point|melting", "melting_point"),
    (r"valenc", "valence"),
    (r"gordy", "gordy_thomas_electronegativity"),
]


# 参数汇编表的固定列序（当表头 OCR 损坏、但列数匹配时按位赋名）
_FIXED_5COL = ["radius_ratio", "energy_ratio", "mott_number",
               "hildebrand_factor", "electronegativity_difference"]


def _canon_col(raw: str) -> str:
    s = re.sub(r"\s+", " ", (raw or "").strip().lower())
    for pat, name in _COL_CANON:
        if re.search(pat, s):
            return name
    n = re.sub(r"[^a-z0-9]+", "_", s).strip("_")
    return n or "col"


def _resolve_columns(col_names: List[str], n_value_cols: int) -> List[str]:
    """决定每个数值列的字段名。

    表头 OCR 常损坏（'RADIUS RAT10' 被拆成多格、错位）。策略：
    - 若归一化后命中的规范列 < 半数，且数值列数 == 5 → 用固定列序兜底；
    - 否则用归一化表头，缺位补 col_i。
    """
    canon_hits = sum(1 for c in col_names if c in
                     {n for _, n in _COL_CANON} | set(_FIXED_5COL))
    # 5 值列且至少 1 个规范命中 → 判定为参数汇编表，列序固定，直接按位赋名
    # （该手册所有 5 列参数表列序不变；OCR 表头错位时这是最稳的）
    if n_value_cols == 5 and canon_hits >= 1:
        return list(_FIXED_5COL)
    out = []
    for i in range(n_value_cols):
        out.append(col_names[i] if i < len(col_names) and col_names[i] not in ("col", "")
                   else (_FIXED_5COL[i] if n_value_cols == 5 and i < 5 else f"col_{i+1}"))
    return out


# ── 数值清洗 ──────────────────────────────────────────────────────────────
def _clean_num(raw: str) -> Tuple[Optional[float], str]:
    """返回 (清洗后的数值 or None, 原始文本)。OCR 容错有限，宁可留 None 不瞎猜。"""
    s = (raw or "").strip()
    if not s:
        return None, s
    # 常见 OCR：前导冒号、千分位逗号、尾点、字母 O/l 混入数字
    t = s.replace(",", "").lstrip(":").rstrip(".")
    t = re.sub(r"(?<=\d)[oO](?=\d)", "0", t)   # 数字间的 O→0
    t = re.sub(r"(?<=\d)[lI](?=\d)", "1", t)   # 数字间的 l/I→1
    m = re.match(r"^[+-]?\d+(?:\.\d+)?$", t)
    if m:
        try:
            return float(t), s
        except ValueError:
            return None, s
    return None, s   # 多值/范围/含字母 → 不强转，保留原文交给后处理


_SYMBOL = {  # 元素名 → 符号（仅常用；用于 binary_system 拼接，缺失则原名）
    "nickel": "Ni", "cobalt": "Co", "copper": "Cu", "iron": "Fe", "aluminum": "Al",
    "aluminium": "Al", "magnesium": "Mg", "titanium": "Ti", "barium": "Ba",
    "lanthanum": "La", "cerium": "Ce", "germanium": "Ge", "arsenic": "As",
    "strontium": "Sr", "yttrium": "Y", "zinc": "Zn", "silver": "Ag", "gold": "Au",
}

try:
    from .elements import normalize_element
except ImportError:  # pragma: no cover
    from kg_v2.extract.elements import normalize_element  # type: ignore


def _sym(name: str) -> str:
    n = re.sub(r"[^a-z]", "", (name or "").lower())
    return _SYMBOL.get(n, name.strip().title() if name else "")


# ── 表型分类（4.4：别把标准表/成分表都塞进 binary_alloy_parameter）──────────
_BINARY_COLS = {"radius_ratio", "energy_ratio", "mott_number",
                "hildebrand_factor", "electronegativity_difference",
                "atomic_radius", "atomic_volume", "heat_of_sublimation"}
_STD_SIGNAL = re.compile(r"standard|astm|afnor|\bcen\b|designation|title|\bpart\b|\bnf\b|\bbs\b|\bdin\b", re.I)
_MECH_SIGNAL = re.compile(r"\brm\b|rp0|rp_0|yield|tensile|elongation|\ba%|hardness|proof", re.I)
_COMP_SIGNAL = re.compile(r"composition|wt\.?%|\bsi\b|\bfe\b|\bcu\b|\bmn\b|\bmg\b|\bzn\b|element", re.I)
# 元素基础属性表（part_001 Table I：At.No./Element/Valence/Radius/Electronegativity/Atomic Volume/Melting）
_ELEM_PROP_COLS = {"valence", "electronegativity", "atomic_radius", "atomic_volume",
                   "melting_point", "radius_cn_12", "electro_negativity"}
_POTENTIAL_SIGNAL = re.compile(r"potential|electrode|\bemf\b|\bv\b.*reaction|reaction.*\bv\b", re.I)


def classify_table(col_names, solute_samples) -> str:
    cols = " ".join(col_names).lower()
    canon = sum(1 for c in col_names if c in _BINARY_COLS)
    elem_prop = sum(1 for c in col_names if c in _ELEM_PROP_COLS or
                    re.search(r"valenc|electroneg|atomic|melting", c, re.I))
    # solute 列大多是元素名 → 强信号 binary
    elem_hits = sum(1 for s in solute_samples if normalize_element(s))
    elem_rate = elem_hits / max(1, len(solute_samples))
    if canon >= 2 and elem_rate >= 0.5:
        return "binary_alloy_parameter"
    # 元素基础属性表：含 valence/electronegativity/atomic 等列且首列多为序号/元素
    if elem_prop >= 2:
        return "element_property_table"
    if _STD_SIGNAL.search(cols):
        return "standard_specification_table"
    if _POTENTIAL_SIGNAL.search(cols):
        return "electrode_potential_table"
    if _MECH_SIGNAL.search(cols):
        return "mechanical_property_table"
    if _COMP_SIGNAL.search(cols):
        return "alloy_composition_table"
    if canon >= 2:
        return "binary_alloy_parameter"
    return "generic_table_row"


# ── 表格解析 ──────────────────────────────────────────────────────────────
_TABLE_RE = re.compile(r"<table>(.*?)</table>", re.S | re.I)
_TR_RE = re.compile(r"<tr>(.*?)</tr>", re.S | re.I)
_TD_RE = re.compile(r"<td>(.*?)</td>", re.S | re.I)
# solvent 头 OCR 变体很多：'SOLVENT-NICKEL', 'SOL VEN T-GER MANI UM', 'SOLVENI-RUTHENI.UM', 'SOLVEN.I- S-TRONTIUM'
_SOLVENT_HDR = re.compile(r"#{1,4}[^\n]*?S\s*O\s*L\s*V\s*E?\s*N\s*[TI][ .:\-]+([A-Za-z][A-Za-z0-9 .\-+]*)", re.I)
# 表号：'TABLE III-47' / 'TaBle-li1- 47' / 'TABL E-111- 85'(空格断裂) 等 OCR 变体
_TABLE_NUM = re.compile(r"#{0,4}[^\n]*?T\s*[Aa]\s*[Bb]\s*[Ll]\s*[Ee][ .\-:]*([IVXivx0-9li][IVXivxLl0-9 .\-]*\d)", re.I)


def _cells(tr: str) -> List[str]:
    return [re.sub(r"<.*?>", "", c).strip() for c in _TD_RE.findall(tr)]


def _nearest_before(pos: int, marks: List[Tuple[int, str]]) -> str:
    best = ""
    for off, val in marks:
        if off <= pos:
            best = val
        else:
            break
    return best


def extract_tables(md: str) -> List[dict]:
    """从一篇 md 解析所有 HTML 表格 → TableRecords 列表（逐行）。"""
    solvent_marks = [(m.start(), re.sub(r"\s+", " ", m.group(1)).strip().title())
                     for m in _SOLVENT_HDR.finditer(md)]
    table_marks = [(m.start(), re.sub(r"\s+", "", m.group(1)).strip())
                   for m in _TABLE_NUM.finditer(md)]

    records: List[dict] = []
    for tm in _TABLE_RE.finditer(md):
        tpos = tm.start()
        body = tm.group(1)
        rows = [_cells(tr) for tr in _TR_RE.findall(body)]
        rows = [r for r in rows if r]
        if len(rows) < 2:
            continue
        solvent = _nearest_before(tpos, solvent_marks)
        table_id = _nearest_before(tpos, table_marks)
        table_id = f"TABLE-{table_id}" if table_id else ""

        # 找表头行：含字母多、数字少的第一行
        header = None
        data_start = 0
        for i, r in enumerate(rows[:4]):
            alpha = sum(1 for c in r if re.search(r"[A-Za-z]", c))
            num = sum(1 for c in r if re.search(r"^\s*[:.]?\d", c))
            if alpha >= 2 and num == 0:
                header = r
                data_start = i + 1
                break
        # 列名（跳过首列=solute 标签列）
        raw_cols = [_canon_col(c) for c in header[1:]] if header else []
        # 以数据行的众数列数决定数值列数（表头常错位）。
        # 用「非空 cell 数」而非原始 cell 数：OCR 常在行尾/行中插入空 <td></td>，
        # 若按原始数 6 取众数会令 n_val=6，触发 _resolve_columns 放弃固定 5 列方案，
        # 导致整表 5 个真值散落错列（QC 发现的列错位主因，main 层 581/2475）。
        widths = [len([c for c in r[1:] if c.strip() != ""]) for r in rows[data_start:] if len(r) >= 2]
        n_val = max(set(widths), key=widths.count) if widths else len(raw_cols)
        col_names = _resolve_columns(raw_cols, n_val)

        # 4.2 solvent 头归一化（修 GER MANI UM→Germanium）
        sv_norm = normalize_element(solvent) if solvent else None
        solvent_name = sv_norm[0] if sv_norm else (solvent.title() if solvent else "")
        solvent_sym = sv_norm[1] if sv_norm else ""

        # 4.4 表型分类：先取前若干 solute 样本判定
        solute_samples = [r[0].strip() for r in rows[data_start:data_start + 12] if r and r[0].strip()]
        rec_type = classify_table(col_names, solute_samples)

        for r in rows[data_start:]:
            if len(r) < 2:
                continue
            solute_raw = r[0].strip()
            vals = r[1:]
            if not solute_raw or not any(re.search(r"\d", v) for v in vals):
                continue
            # 修列错位：行内有多余空 cell（行尾/行中），剔空后若恰好等于本表数值列数
            # 且全为干净数值，则用剔空版按位赋名（救回 QC 发现的尾随/嵌入空 cell 列错位）。
            # 仅在「原始列数≠n_val」时介入，且要求剔空后全数值——避免把真实缺值(blank_merged)
            # 误压实成错位（如只剩 1 个值的残行 len≠n_val，不满足，保持原状）。
            if len(vals) != n_val:
                nonempty = [v for v in vals if v.strip() != ""]
                if len(nonempty) == n_val and all(_clean_num(v)[0] is not None for v in nonempty):
                    vals = nonempty
            params: Dict[str, object] = {}
            for idx, v in enumerate(vals):
                col = col_names[idx] if idx < len(col_names) else f"col_{idx+1}"
                num, raw = _clean_num(v)
                params[col] = num if num is not None else (raw or None)
            params = {k: v for k, v in params.items() if v is not None and v != ""}
            if not params:
                continue

            # 4.3 solute 归一化 —— 仅对元素型表（binary / element_property）按元素处理
            elem_types = ("binary_alloy_parameter", "element_property_table")
            if rec_type in elem_types:
                st_norm = normalize_element(solute_raw)
                solute_name = st_norm[0] if st_norm else solute_raw.strip(" .")
                solute_sym = st_norm[1] if st_norm else ""
                conf = st_norm[2] if st_norm else 0.0
                sv2 = solvent_sym or _sym(solvent_name)
                st2 = solute_sym or _sym(solute_name)
                binary = f"{sv2}-{st2}" if (sv2 and st2 and rec_type == "binary_alloy_parameter") else ""
                rec = {
                    "record_type": rec_type,
                    "solvent": solvent_name if rec_type == "binary_alloy_parameter" else "",
                    "solvent_symbol": solvent_sym if rec_type == "binary_alloy_parameter" else "",
                    "solute": solute_name, "solute_raw": solute_raw, "solute_symbol": solute_sym,
                    "binary_system": binary, "material_name": "", "row_label": solute_raw,
                    "parameters": params, "parameter_basis": "calculated",
                    "source": {"table_id": table_id,
                               "table_caption": solvent and f"SOLVENT-{solvent}",
                               "row_label": solute_raw, "column_labels": col_names},
                    "_extractor": "deterministic_html", "_entity_confidence": conf,
                }
            else:
                # 非元素表（标准/成分/电极/通用）：行标签放 row_label/material_name，不套 solute/binary
                rec = {
                    "record_type": rec_type,
                    "solvent": "", "solute": "", "binary_system": "",
                    "material_name": solute_raw, "row_label": solute_raw,
                    "parameters": params, "parameter_basis": "measured",
                    "source": {"table_id": table_id, "row_label": solute_raw, "column_labels": col_names},
                    "_extractor": "deterministic_html", "_entity_confidence": 0.0,
                }
            records.append(rec)
    return records


def merge_into_record(rec: dict, md: str, replace: bool = True) -> dict:
    """把确定性表格解析结果合并进抽取记录的 TableRecords。

    replace=True：确定性结果覆盖 LLM 采样的 TableRecords（穷举 > 采样）；
                  但保留 LLM 抽的非 binary_alloy_parameter（如成分表行）。
    """
    det = extract_tables(md)
    L = rec.setdefault("layered", {})
    llm_trs = L.get("TableRecords") or []
    if replace and det:
        keep = [t for t in llm_trs if t.get("record_type") != "binary_alloy_parameter"]
        L["TableRecords"] = det + keep
    else:
        L["TableRecords"] = llm_trs + det
    q = rec.setdefault("_quality", {})
    q["n_table_records"] = len(L["TableRecords"])
    q["n_table_records_deterministic"] = len(det)
    return rec
