# kg_v2 —— gen_key 知识图谱升级子包

以 **gen_key 为骨架**、吸收 Scholar_KG_v2 设计、保留 **Haiku 单调用** 抽取方式的并行升级包。
不改动现有 `llm_extract/` 与 `scientific_kgqa/` 产线，验证后再切换。

## 目标能力（P1–P4）
1. **两层 Schema 注入**：稳定 Meta 骨架（12 模块）× 领域 schema（schema_gen 产出）→ 每字段带
   `node_type / module / role / value_type / unit / bind_keys / quality_check`。
2. **四类语义节点**：Narrative（叙事/需求）、Measurement（测量）、Discovery（机理/优化）、Concept（概念原子）。
3. **Observation Pattern**：实测值强绑定实验条件（material_system/material_state/test_condition…）+ 质检 + `condition_binding_rate`。
4. **引用层 + 机理因果链**：CITES(strength 1-5)；Discovery.causal_chain → Entity 链 + CAUSES/ENABLES/… 关系边。

## 目录
```
kg_v2/
  meta_schema/
    meta_schema.csv         # Layer1：12 模块通用骨架（跨领域不变）
    cluster_to_module.yaml  # 可选显式覆盖（聚类→模块/节点）
    layered_schema.json     # ← P1 产物（构建生成）
    domain_fieldspec.csv    # ← 字段级 FieldSpec 审计表（enrich 生成）
  schema/                   # ★ P1：两层 Schema 注入
    cluster_router.py       # 聚类名关键词 + 层级 + 字段名 → (module,node_type,role)
    enrich_fieldspec.py     # 派生 value_type/unit/cardinality/bind_keys（合金域调优）
    build_layered_schema.py # 组装 meta×领域 → layered_schema.json
    layered_schema.py       # LayeredSchema：按 node_type 渲染 prompt 注入块
  extract/                  # ★ P2：单调用分层抽取（Haiku）+ 观测质检
    prompts.py              # 注入 Narrative/Measurement/Discovery 三块 schema → 六键 JSON
    quality.py              # quality_flags + condition_binding_rate（观测绑定 KPI）
    extractor_v2.py         # 单篇单次 Haiku 调用（复用 llm_extract.AsyncLLMClient）
    run_extract_v2.py       # 批量异步入口 → kb_v2/<paper_id>.json
  graph/                    # ★ P3：图谱组装（自包含 JSON 图）
    build_graph_v2.py       # kb_v2/*.json → graph_v2.json + STATS.md（4类节点+观测/因果/引用/关系）
    to_scientific_kgqa.py   # ★ P4：graph_v2.json → scientific_kgqa SQLite（切换/落库）
  build_kg_v2.py            # ★ 一键编排 P1→P2→P3→P4
```

## 一键编排
```bash
python -m kg_v2.build_kg_v2 \
    --domain <refined_schema_*.csv> \
    --content-store scientific_kgqa/data/content_store \
    [--limit 20] [--concurrency 8] \
    [--skip-schema|--skip-extract|--skip-graph|--skip-db]
# P1 layered_schema.json → P2 kb_v2/*.json(Haiku) → P3 graph_out/graph_v2.json → P4 artifacts/kgqa_v2.db
```

## P4 落库说明
`to_scientific_kgqa.py` 双写以兼容现有 `server.py` 检索栈：
- 全部节点→`graph_node`、全部边→`graph_edge`（CITES 边写 `citation_score=strength/5`）
- Narrative→`paper`；Measurement→`paper_fact`（field/value/unit + bound 存 attrs_json）；CITES→`paper_link`
独立库 `kgqa_v2.db`，不覆盖现有 `kgqa.db`，验证满意后再切。

## P2 用法
```bash
# 复用 .env 的 LLM_BASE_URL / LLM_API_KEY；模型默认 claude-haiku-4-5-20251001
python -m kg_v2.extract.run_extract_v2 \
    --layered kg_v2/meta_schema/layered_schema.json \
    --content-store scientific_kgqa/data/content_store \
    --out kg_v2/kb_v2 [--limit 20] [--concurrency 8]
# 产出每篇 kb_v2/<paper_id>.json：{layered:{Narrative,Measurements,Discoveries,Concepts,Reference,Relations}, _quality:{condition_binding_rate,...}}
```

## P1 用法
```bash
cd gen_key
# 1) （可选）先看字段级路由审计，按需在 cluster_to_module.yaml 钉死判错的聚类
python -m kg_v2.schema.enrich_fieldspec --domain <refined_schema_*.csv>

# 2) 构建两层 schema
python -m kg_v2.schema.build_layered_schema --domain <refined_schema_*.csv>
# -> kg_v2/meta_schema/layered_schema.json
```

## 路由说明
gen_key 的领域 schema 聚类 ID 跨 schema 不稳定，故 `cluster_router` 按**聚类英文/中文名关键词**
推断基线，再用**层级 + 字段名模式**逐字段精修（Level 4 / 机理名→Discovery；性能名→Measurement-observation；
测试条件名→condition）。判错时在 `cluster_to_module.yaml` 按 cluster_id 或精确聚类名显式覆盖（优先级最高）。
`enrich_fieldspec.py` 的 `derived_by` 列用于审计单位派生命中情况。
