#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""build_graph_v2.py —— P3/P4 图谱组装器。

读 kb_v2/<paper_id>.json（P2 产出）→ 装配成自包含图（nodes/links/stats）。
节点类型：
  Narrative / Requirement / Measurement / Condition / MaterialSystem
  / Discovery / Concept / Entity / Reference
边类型：
  HAS_REQUIREMENT, HAS_MEASUREMENT, UNDER_CONDITION, FOR_MATERIAL,
  HAS_DISCOVERY, EXPLAINS, MENTIONS_CONCEPT, CONCEPT_COOCCUR, CITES(strength),
  CAUSES/ENABLES/INHIBITS/...（来自 Discovery.causal_chain 展开 + Relations 三元组）

核心 KPI：condition_binding_rate（观测值绑定实验条件的比例）。
输出 graph_v2.json + STATS.md。验证 OK 后，再写 adapter 落库 scientific_kgqa（P4 切换步）。

用法:
    python -m kg_v2.graph.build_graph_v2 --kb kg_v2/kb_v2 --out kg_v2/graph_out
"""
from __future__ import annotations

import argparse
import glob
import hashlib
import json
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Dict, List, Optional

_HERE = Path(__file__).resolve().parents[2]  # gen_key/

# 来自 Discovery.causal_chain / Relations 的开放关系词（用于因果链相邻步连边）
_CAUSAL_DEFAULT = "CAUSES"


def _slug(s: str, n: int = 48) -> str:
    s = re.sub(r"\s+", "_", (s or "").strip().lower())
    s = re.sub(r"[^a-z0-9_一-鿿\-]", "", s)
    return (s or "x")[:n]


def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", (s or "").strip().lower())


def _hash(s: str, n: int = 10) -> str:
    return hashlib.sha1(_norm(s).encode("utf-8")).hexdigest()[:n]


class GraphV2:
    def __init__(self, bind_by_field: Optional[Dict[str, str]] = None):
        self.nodes: Dict[str, dict] = {}
        self.links: List[dict] = []
        self.bind_by_field = bind_by_field or {}
        self.concept_id: Dict[str, str] = {}
        self.paper_concepts: Dict[str, set] = defaultdict(set)
        self.obs_total = 0
        self.obs_bound = 0
        self.table_records = 0
        self._edge_seen: set = set()

    def add_node(self, nid: str, ntype: str, label: str, **attrs):
        if nid in self.nodes:
            # 合并 attrs（保留已有非空）
            for k, v in attrs.items():
                if v and not self.nodes[nid]["attrs"].get(k):
                    self.nodes[nid]["attrs"][k] = v
            return nid
        self.nodes[nid] = {"id": nid, "type": ntype, "label": (label or nid)[:140],
                           "attrs": {k: v for k, v in attrs.items() if v}}
        return nid

    def add_edge(self, src: str, dst: str, relation: str, directed: bool = True, **attrs):
        if not src or not dst or src not in self.nodes or dst not in self.nodes:
            return
        key = (src, dst, relation) if directed else tuple(sorted((src, dst)) + [relation])
        if key in self._edge_seen:
            return
        self._edge_seen.add(key)
        self.links.append({"source": src, "target": dst, "relation": relation,
                           "directed": directed, "attrs": {k: v for k, v in attrs.items() if v}})

    # ── 单篇入图 ──────────────────────────────────────────────────────────
    def ingest(self, rec: dict):
        pid = str(rec.get("paper_id") or "")
        L = rec.get("layered") or {}
        nar = L.get("Narrative") or {}

        n_nar = f"Narrative::{pid}"
        self.add_node(n_nar, "Narrative", nar.get("problem_statement") or pid,
                      paper_id=pid, design_object=nar.get("design_object"),
                      problem_statement=nar.get("problem_statement"))

        # Requirement
        for j, r in enumerate(nar.get("requirements") or []):
            metric = r.get("metric") or f"req{j}"
            rid = f"Requirement::{pid}::{_slug(metric)}_{j}"
            self.add_node(rid, "Requirement",
                          f"{metric} {r.get('operator','')} {r.get('threshold','')}{r.get('unit','')}",
                          metric=metric, operator=r.get("operator"), threshold=r.get("threshold"),
                          unit=r.get("unit"), constraint_type=r.get("constraint_type"), paper_id=pid)
            self.add_edge(n_nar, rid, "HAS_REQUIREMENT")

        # Measurement + Condition + MaterialSystem（Observation Pattern）
        for j, m in enumerate(L.get("Measurements") or []):
            field = m.get("field") or f"m{j}"
            mid = f"Measurement::{pid}::{_slug(field)}_{j}"
            self.add_node(mid, "Measurement", f"{field}={m.get('value_raw') or m.get('value_num')}",
                          field=field, role=m.get("role"), value_num=m.get("value_num"),
                          value_raw=m.get("value_raw"), unit=m.get("unit"),
                          evidence=m.get("evidence"), paper_id=pid)
            self.add_edge(n_nar, mid, "HAS_MEASUREMENT")

            bound = m.get("bound") or {}
            mat = bound.get("material_system")
            if mat:
                matid = f"MaterialSystem::{_slug(_norm(mat))}"
                self.add_node(matid, "MaterialSystem", mat, name=mat)
                self.add_edge(mid, matid, "FOR_MATERIAL")
            ms, tc = bound.get("material_state") or "", bound.get("test_condition") or ""
            if ms or tc:
                cid = f"Condition::{_hash(ms + '||' + tc)}"
                self.add_node(cid, "Condition", (ms + " | " + tc)[:140],
                              material_state=ms, test_condition=tc,
                              orientation=bound.get("orientation"), temperature=bound.get("temperature"))
                self.add_edge(mid, cid, "UNDER_CONDITION")

            # KPI：该字段是否要求绑定 + 是否绑全
            req = [k.strip() for k in (self.bind_by_field.get(field.lstrip("_"), "") or "").split(";") if k.strip()]
            if req:
                self.obs_total += 1
                if all(str(bound.get(k, "")).strip() for k in req):
                    self.obs_bound += 1

        # TableRecords —— 表格行级记录（4.2）：每行一个 record 节点，保留 parameters{}
        for j, tr in enumerate(L.get("TableRecords") or []):
            if tr.get("_tier") == "reject":   # 5.x 质量门控：reject 不入图，避免污染
                continue
            params = tr.get("parameters") or {}
            solvent = tr.get("solvent") or ""
            solute = tr.get("solute") or ""
            binary = tr.get("binary_system") or (f"{solvent}-{solute}" if solvent and solute else "")
            mat_name = tr.get("material_name") or binary or \
                (f"{solvent}-{solute}" if (solvent or solute) else "") or f"row{j}"
            src = tr.get("source") or {}
            rec_kind = tr.get("record_type") or "generic_table_row"
            ntype = "BinaryRecord" if rec_kind == "binary_alloy_parameter" else \
                    ("AlloyGradeRecord" if rec_kind == "alloy_grade_composition" else "TableRecord")
            rid = f"{ntype}::{pid}::{_slug(mat_name)}_{j}"
            self.add_node(rid, ntype, mat_name, paper_id=pid, record_type=rec_kind,
                          solvent=solvent, solute=solute, binary_system=binary,
                          parameters=params, parameter_basis=tr.get("parameter_basis"),
                          tier=tr.get("_tier"),
                          table_id=src.get("table_id"), row_label=src.get("row_label"))
            self.add_edge(n_nar, rid, "HAS_TABLE_RECORD")
            # 绑到共享 MaterialSystem（binary_system / grade）
            if binary or mat_name:
                key = _norm(binary or mat_name)
                matid = f"MaterialSystem::{_slug(key)}"
                self.add_node(matid, "MaterialSystem", binary or mat_name, name=binary or mat_name)
                self.add_edge(rid, matid, "FOR_MATERIAL")
            # 绑到来源表
            if src.get("table_id"):
                tid = f"SourceTable::{pid}::{_slug(src['table_id'])}"
                self.add_node(tid, "SourceTable", src["table_id"], paper_id=pid, table_id=src["table_id"])
                self.add_edge(rid, tid, "FROM_TABLE")
            self.table_records += 1

        # Discovery + 因果链展开
        for j, d in enumerate(L.get("Discoveries") or []):
            did = f"Discovery::{pid}::{j}"
            self.add_node(did, "Discovery", d.get("statement") or f"discovery{j}",
                          mechanism_type=d.get("mechanism_type"), polarity=d.get("polarity"),
                          recommended_window=d.get("recommended_window"),
                          claim_source=d.get("claim_source"),
                          confidence=d.get("confidence"), paper_id=pid)
            self.add_edge(n_nar, did, "HAS_DISCOVERY")
            chain = [c for c in (d.get("causal_chain") or []) if str(c).strip()]
            prev = None
            # causal_chain 是有序步骤序列 → 用 NEXT_STEP（顺序），不是 CAUSES（因果）。
            # 真因果与否交给 attrs(polarity/claim_source) + relation_tier，由查询层决定是否当因果用。
            claim_src = d.get("claim_source") or ""
            for step in chain:
                eid = f"Entity::{pid}::{_slug(step)}"
                self.add_node(eid, "Entity", step, paper_id=pid)
                self.add_edge(did, eid, "HAS_CHAIN_STEP")
                if prev:
                    self.add_edge(prev, eid, "NEXT_STEP", source_discovery=did,
                                  polarity=d.get("polarity"), claim_source=claim_src)
                prev = eid

        # Concept（跨篇去重）
        for c in L.get("Concepts") or []:
            atoms = [a for a in (c.get("atoms") or []) if str(a).strip()]
            if not atoms:
                continue
            key = _norm(" ".join(atoms))
            cid = self.concept_id.get(key)
            if not cid:
                cid = f"Concept::{_slug(key)}"
                self.concept_id[key] = cid
                self.add_node(cid, "Concept", ", ".join(atoms), atoms=atoms, kind=c.get("kind"))
            self.add_edge(n_nar, cid, "MENTIONS_CONCEPT", claim=c.get("claim"))
            self.paper_concepts[pid].add(cid)

        # Reference → CITES(strength)
        for title, meta in (L.get("Reference") or {}).items():
            if not str(title).strip():
                continue
            rid = f"Reference::{_slug(title)}"
            self.add_node(rid, "Reference", title, is_reference=True,
                          authors=(meta or {}).get("authors"), pub_time=(meta or {}).get("pub_time"),
                          source=(meta or {}).get("source"))
            self.add_edge(n_nar, rid, "CITES", strength=(meta or {}).get("cite_strength"),
                          identifier=(meta or {}).get("cite_identifier"))

        # Relations 三元组（已由 relation_gov 归一谓词 + 评级 relation_tier）
        for rel in L.get("Relations") or []:
            head, tail = rel.get("head"), rel.get("tail")
            relation = (rel.get("relation") or "ASSOCIATED_WITH").upper()
            if not head or not tail:
                continue
            hid = f"Entity::{pid}::{_slug(head)}"
            tid = f"Entity::{pid}::{_slug(tail)}"
            self.add_node(hid, "Entity", head, paper_id=pid, entity_type=rel.get("head_type"))
            self.add_node(tid, "Entity", tail, paper_id=pid, entity_type=rel.get("tail_type"))
            self.add_edge(hid, tid, relation,
                          relation_tier=rel.get("relation_tier") or "semantic",
                          category=rel.get("category"),
                          confidence=rel.get("confidence"), evidence=rel.get("evidence"),
                          downgraded=rel.get("_downgraded"))

    def finalize_concept_cooccur(self):
        for pid, cset in self.paper_concepts.items():
            cs = sorted(cset)
            for i in range(len(cs)):
                for k in range(i + 1, len(cs)):
                    self.add_edge(cs[i], cs[k], "CONCEPT_COOCCUR", directed=False)

    def to_dict(self) -> dict:
        rate = (self.obs_bound / self.obs_total) if self.obs_total else 0.0
        return {
            "nodes": list(self.nodes.values()),
            "links": self.links,
            "stats": {
                "nodes_total": len(self.nodes),
                "links_total": len(self.links),
                "node_types": dict(Counter(n["type"] for n in self.nodes.values())),
                "edge_types": dict(Counter(l["relation"] for l in self.links)),
                "observation_total": self.obs_total,
                "observation_bound": self.obs_bound,
                "table_records": self.table_records,
                "condition_binding_rate": round(rate, 4),
            },
        }


def build(kb_dir: str, bind_by_field: Optional[Dict[str, str]] = None) -> dict:
    g = GraphV2(bind_by_field)
    files = sorted(glob.glob(str(Path(kb_dir) / "*.json")))
    for fp in files:
        try:
            rec = json.loads(Path(fp).read_text(encoding="utf-8"))
        except Exception:
            continue
        g.ingest(rec)
    g.finalize_concept_cooccur()
    out = g.to_dict()
    out["stats"]["papers"] = len(files)
    return out


def _stats_md(stats: dict) -> str:
    lines = ["# kg_v2 graph stats", "",
             f"- papers: {stats.get('papers')}",
             f"- nodes: {stats['nodes_total']}  | links: {stats['links_total']}",
             f"- **condition_binding_rate: {stats['condition_binding_rate']}** "
             f"({stats['observation_bound']}/{stats['observation_total']})", "",
             "## node types"]
    for k, v in sorted(stats["node_types"].items(), key=lambda x: -x[1]):
        lines.append(f"- {k}: {v}")
    lines.append("\n## edge types")
    for k, v in sorted(stats["edge_types"].items(), key=lambda x: -x[1]):
        lines.append(f"- {k}: {v}")
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser(description="P3 图谱组装：kb_v2/*.json -> graph_v2.json")
    ap.add_argument("--kb", default=str(_HERE / "kg_v2" / "kb_v2"))
    ap.add_argument("--layered", default=str(_HERE / "kg_v2" / "meta_schema" / "layered_schema.json"),
                    help="取 bind_by_field 用于 KPI")
    ap.add_argument("--out", default=str(_HERE / "kg_v2" / "graph_out"))
    args = ap.parse_args()

    bind = {}
    lp = Path(args.layered)
    if lp.exists():
        bind = json.loads(lp.read_text(encoding="utf-8")).get("bind_by_field", {})

    result = build(args.kb, bind)
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    (out / "graph_v2.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "STATS.md").write_text(_stats_md(result["stats"]), encoding="utf-8")

    s = result["stats"]
    print("=" * 60)
    print(f"graph built: papers={s.get('papers')} nodes={s['nodes_total']} links={s['links_total']}")
    print(f"  node_types: {s['node_types']}")
    print(f"  edge_types: {s['edge_types']}")
    print(f"  condition_binding_rate = {s['observation_bound']}/{s['observation_total']} = {s['condition_binding_rate']}")
    print(f"  -> {out}/graph_v2.json , STATS.md")
    print("=" * 60)


if __name__ == "__main__":
    main()
