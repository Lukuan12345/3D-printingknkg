"""kg_v2.graph —— P3 图谱组装（自包含 JSON 图，验证后再适配 scientific_kgqa）。"""
