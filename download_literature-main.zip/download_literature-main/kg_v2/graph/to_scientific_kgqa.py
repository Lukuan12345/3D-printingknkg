#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""to_scientific_kgqa.py —— P4 切换适配器：graph_v2.json → scientific_kgqa SQLite。

把自包含图灌进现有 scientific_kgqa 存储，让现有 server.py 检索栈能消费：
  - 所有节点 → graph_node（canonical_name = 我们的全局唯一 node id）
  - 所有边   → graph_edge（CITES 额外写 citation_score = strength/5）
  - Narrative 节点 → paper 表（paper-centric 查询）
  - Measurement 节点 → paper_fact 表（field/value/unit + bound 存 attrs_json）
  - CITES 边 → paper_link 表（relation_kind=reference）

用法:
    python -m kg_v2.graph.to_scientific_kgqa \
        --graph kg_v2/graph_out/graph_v2.json \
        --db scientific_kgqa/artifacts/general_alloy_v2/kgqa.db
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Dict

_HERE = Path(__file__).resolve().parents[2]  # gen_key/
sys.path.insert(0, str(_HERE / "scientific_kgqa" / "src"))
from scientific_kgqa.storage import SQLiteStore  # noqa: E402


def _num(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


# ── chunk 文本构造（供 BM25/TF-IDF 检索；chunk_type 取 scientific_kgqa.utils.CHUNK_TYPES 子集）──
_PARAM_ORDER = ["radius_ratio", "energy_ratio", "mott_number",
                "hildebrand_factor", "electronegativity_difference"]


def _chunk_for_node(node: dict, attrs: dict):
    """按节点类型生成 (chunk_type, chunk_text)；不可检索则返回 None。"""
    t = node["type"]
    label = (node.get("label") or "").strip()
    if t == "Narrative":
        ps = (attrs.get("problem_statement") or "").strip()
        do = (attrs.get("design_object") or "").strip()
        text = ". ".join(x for x in (ps, f"Design object: {do}" if do else "") if x)
        return ("problem_context", text or label) if (text or label) else None
    if t == "Discovery":
        extra = ", ".join(x for x in (
            f"mechanism: {attrs.get('mechanism_type')}" if attrs.get("mechanism_type") else "",
            f"effect: {attrs.get('polarity')}" if attrs.get("polarity") else "") if x)
        text = f"{label} ({extra})" if extra else label
        return ("physical_mechanism", text) if label else None
    if t == "BinaryRecord":
        p = attrs.get("parameters") or {}
        params = ", ".join(f"{k}={p[k]}" for k in _PARAM_ORDER if k in p and p[k] not in (None, ""))
        sv, su, bs = attrs.get("solvent"), attrs.get("solute"), attrs.get("binary_system")
        text = (f"Binary alloy system {bs}: solvent {sv}, solute {su}. {params}. "
                f"(parameter_basis={attrs.get('parameter_basis')}, tier={attrs.get('tier')})")
        return ("influence_analysis", text) if (bs and params) else None
    return None


def load_graph_into_store(graph_json: str, db_path: str) -> dict:
    data = json.loads(Path(graph_json).read_text(encoding="utf-8"))
    nodes = data.get("nodes", [])
    links = data.get("links", [])

    store = SQLiteStore(db_path)
    id_map: Dict[str, int] = {}     # 我们的 node id 字符串 → sqlite int node_id
    counts = {"nodes": 0, "edges": 0, "papers": 0, "facts": 0, "paper_links": 0, "chunks": 0}

    # 1) 节点
    for n in nodes:
        nid_str = n["id"]
        attrs = dict(n.get("attrs") or {})
        sqlite_id = store.upsert_graph_node(
            node_type=n["type"],
            canonical_name=nid_str,
            display_name_en=n.get("label"),
            subtype=attrs.get("role") or attrs.get("field") or attrs.get("mechanism_type"),
            source="kg_v2",
            attrs_json=attrs,
        )
        id_map[nid_str] = sqlite_id
        counts["nodes"] += 1

        # 1b) 检索 chunk：文本丰富的节点 → paper_chunk + node_chunk_posting（供 retriever/图走查）
        ck = _chunk_for_node(n, attrs)
        if ck:
            ctype, ctext = ck
            cpid = attrs.get("paper_id") or (nid_str.split("::", 1)[-1] if n["type"] == "Narrative" else "")
            if cpid and ctext.strip():
                cid = f"{nid_str}::chunk"
                store.insert_chunk({
                    "chunk_id": cid, "paper_id": cpid, "chunk_type": ctype,
                    "chunk_text": ctext, "chunk_order": counts["chunks"],
                    "attrs_json": {"node_id": nid_str, "node_type": n["type"]},
                })
                store.upsert_node_chunk_posting(sqlite_id, cid, cpid, 1.0, n["type"])
                counts["chunks"] += 1

        # Narrative → paper 表
        if n["type"] == "Narrative":
            pid = attrs.get("paper_id") or nid_str.split("::", 1)[-1]
            store.insert_paper({
                "paper_id": pid,
                "paper_title": n.get("label") or attrs.get("problem_statement") or pid,
                "metadata_json": attrs,
            })
            counts["papers"] += 1

        # Measurement → paper_fact 表（带 bound 上下文）
        if n["type"] == "Measurement":
            pid = attrs.get("paper_id") or ""
            if pid:
                store.insert_fact({
                    "paper_id": pid,
                    "field_name": attrs.get("field") or n.get("label") or "unknown",
                    "value_type": "number_with_unit" if _num(attrs.get("value_num")) is not None else "string",
                    "value_raw": attrs.get("value_raw"),
                    "num_value": _num(attrs.get("value_num")),
                    "unit": attrs.get("unit"),
                    "confidence": 1.0,
                    "attrs_json": {"role": attrs.get("role"), "evidence": attrs.get("evidence"),
                                   "node_id": nid_str},
                })
                counts["facts"] += 1

    # 2) 边
    for e in links:
        src = id_map.get(e["source"]); dst = id_map.get(e["target"])
        if src is None or dst is None:
            continue
        rel = e["relation"]
        eattrs = dict(e.get("attrs") or {})
        cite = 0.0
        if rel == "CITES":
            cite = (_num(eattrs.get("strength")) or 0.0) / 5.0
        store.upsert_graph_edge(
            src_node_id=src, dst_node_id=dst, relation_type=rel,
            directed=bool(e.get("directed", True)), weight=1.0,
            citation_score=cite, attrs_json=eattrs,
        )
        counts["edges"] += 1

        # CITES → paper_link
        if rel == "CITES":
            src_node = next((n for n in nodes if n["id"] == e["source"]), {})
            dst_node = next((n for n in nodes if n["id"] == e["target"]), {})
            store.insert_paper_link({
                "relation_kind": "reference",
                "src_paper_id": (src_node.get("attrs") or {}).get("paper_id"),
                "dst_title": dst_node.get("label"),
                "match_confidence": cite,
                "match_method": "kg_v2_llm",
                "attrs_json": eattrs,
            })
            counts["paper_links"] += 1

    store.commit()
    store.close()
    return counts


def main():
    ap = argparse.ArgumentParser(description="把 graph_v2.json 灌入 scientific_kgqa SQLite")
    ap.add_argument("--graph", default=str(_HERE / "kg_v2" / "graph_out" / "graph_v2.json"))
    ap.add_argument("--db", default=str(_HERE / "scientific_kgqa" / "artifacts" / "general_alloy_v2" / "kgqa.db"))
    args = ap.parse_args()
    Path(args.db).parent.mkdir(parents=True, exist_ok=True)
    counts = load_graph_into_store(args.graph, args.db)
    print("=" * 56)
    print("loaded graph_v2 into scientific_kgqa SQLite")
    for k, v in counts.items():
        print(f"  {k:12s}: {v}")
    print(f"  -> {args.db}")
    print("=" * 56)


if __name__ == "__main__":
    main()
