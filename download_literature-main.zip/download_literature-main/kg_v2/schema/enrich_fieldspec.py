#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""enrich_fieldspec.py —— 给领域 schema 每个字段自动派生 FieldSpec（合金域调优）。

输入: gen_key 的 refined_schema_*.csv（schema_gen 产出，列名见下）
输出: kg_v2/meta_schema/domain_fieldspec.csv
      追加列: module / node_type / role / value_type / unit / cardinality /
              bind_keys / quality_check / derived_by

派生靠规则（字段英文名/中文名/描述里的关键词），不调用 LLM。
节点路由委托 cluster_router.resolve()。单位规则针对合金/材料/增材调优。

用法:
    python -m kg_v2.schema.enrich_fieldspec --domain <refined_schema.csv> \
        [--overrides kg_v2/meta_schema/cluster_to_module.yaml] \
        [--out kg_v2/meta_schema/domain_fieldspec.csv]
"""
from __future__ import annotations

import argparse
import csv
import re
from collections import Counter
from pathlib import Path
from typing import Dict, List, Tuple

try:  # 支持 `python -m kg_v2.schema.enrich_fieldspec` 和直接运行
    from .cluster_router import resolve, load_overrides, _level_key
except ImportError:  # pragma: no cover
    import sys
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from cluster_router import resolve, load_overrides, _level_key  # type: ignore

_HERE = Path(__file__).resolve().parent
_META_DIR = _HERE.parent / "meta_schema"

# ── gen_key 领域 CSV 列名（utf-8-sig）──────────────────────────────────────
_C_EN = "字段名（英文）"
_C_CN = "字段名（中文）"
_C_DESC = "完整描述"
_C_LEVEL = "层级"
_C_CID = "聚类ID"
_C_CNAME = "聚类名称"
_C_CNAME_EN = "聚类名称（英文）"

# ── 单位派生规则（合金/材料/增材调优；顺序敏感，命中即停）────────────────────
# (正则 over "英文名 + 中文名"[+描述兜底], 单位, value_type)
UNIT_RULES: List[Tuple[str, str, str]] = [
    # 力学性能
    (r"yield_strength|屈服强度|tensile_strength|抗拉强度|ultimate.*strength|flow_stress|流动应力|"
     r"applied_stress|外加应力|residual_stress|残余应力|creep_stress|蠕变应力|\bstress\b|应力|\bstrength\b|强度",
     "MPa", "number_with_unit"),
    (r"elastic_modulus|弹性模量|杨氏模量|young|\bmodulus\b|模量", "GPa", "number_with_unit"),
    (r"fracture_toughness|断裂韧性|\bkic\b|韧性", "MPa·m^0.5", "number_with_unit"),
    (r"elongation|延伸率|伸长率|reduction_in_area|断面收缩|strain(?!_rate)|应变(?!速)", "%", "number_with_unit"),
    (r"hardness|硬度|\bhv\b", "HV", "number_with_unit"),
    (r"fatigue_life|疲劳寿命|cycles|循环|runout|rupture_life|断裂寿命", "cycles", "number_with_unit"),
    # 热
    (r"thermal_conductivity|导热率|热导率", "W/(m·K)", "number_with_unit"),
    (r"thermal_gradient|温度梯度", "K/mm", "number_with_unit"),
    (r"cooling_rate|冷却速率|heating_rate|升温速率|加温速率", "K/s", "number_with_unit"),
    (r"transus|转变温度|liquidus|液相线|solidus|固相线|solvus|固溶线|incipient_melting|初熔|"
     r"ms_temperature|mf_temperature|transformation_temperature|相变温度|"
     r"preheat|预热|interpass|层间.*温度|aging_temperature|时效温度|solution.*temperature|固溶.*温度|"
     r"annealing_temperature|退火温度|stress_relief_temperature|test_temperature|测试温度|"
     r"deformation_temperature|变形温度|hip_temperature|creep_temperature|melting_temperature|"
     r"casting_temperature|浇注温度|peak_temperature|峰值温度|\btemperature\b|温度", "°C", "number_with_unit"),
    # 工艺（增材 / 变形 / 熔炼）
    (r"laser_power|激光功率|\bpower\b|功率", "W", "number_with_unit"),
    (r"beam_current|束流|arc_current|电弧电流|var_current|电流|\bcurrent\b", "A", "number_with_unit"),
    (r"voltage|电压|arc_voltage|弧压", "V", "number_with_unit"),
    (r"scan_speed|扫描速度|travel_speed|行进速度|withdrawal|抽拉|pulling|melt_rate|熔化速率|deposition_rate|沉积",
     "mm/s", "number_with_unit"),
    (r"volumetric_energy_density|体能量密度|line_energy|线能量|energy_density|能量密度", "J/mm^3", "number_with_unit"),
    (r"strain_rate|应变速率|应变率|loading_rate|加载速率", "s^-1", "number_with_unit"),
    (r"frequency|频率|stirring_frequency|搅拌频率|pulse_frequency", "Hz", "number_with_unit"),
    (r"magnetic_field|磁场|flux_density", "T", "number_with_unit"),
    (r"hip_pressure|压力|pressure|气压", "MPa", "number_with_unit"),
    (r"vacuum_level|真空度", "Pa", "number_with_unit"),
    (r"hatch_spacing|搭接|层厚|layer_thickness|wall_thickness|壁厚|lamella_thickness|片层厚|"
     r"lamellar_spacing|片层间距|arm_spacing|臂间距|\bpdas\b|\bsdas\b|grain_size|晶粒尺寸|"
     r"colony_size|群落尺寸|pore_size|孔径|cell_spacing|胞间距|spacing|间距|thickness|厚度|"
     r"diameter|直径|grain_morphology", "μm", "number_with_unit"),
    (r"time|时间|duration|时长|dwell|保温|soaking|holding|\bhour|\bhr\b|aging_time|solution_time", "h", "number_with_unit"),
    # 成分 / 分数 / 比例
    (r"_content|含量|composition|成分|equivalent|当量|interstitial|间隙", "wt.%", "number_with_unit"),
    (r"fraction|分数|porosity|孔隙率|density(?!.*function)|致密度|efficiency|效率|"
     r"globularization|球化|recrystalliz|再结晶.*分数|severity|严重|index$|指数", "%", "number_with_unit"),
    (r"cooling_time|t8.?5", "s", "number_with_unit"),
    # 性能/质量观测（补：腐蚀速率/粗糙度）
    (r"corrosion_rate|腐蚀速率|腐蚀率|degradation_rate|降解速率", "mm/year", "number_with_unit"),
    (r"surface_roughness|表面粗糙度|roughness|粗糙度", "μm", "number_with_unit"),
    # 计数（无量纲整数）
    (r"_count$|count$|数量|个数|层数|道次|pass_count|remelting_pass|element_count|cycles_count|reuse_cycles|复用次数|replicate|"
     r"network_depth|training_dataset_size|训练数据", "count", "number_with_unit"),
    (r"dimension$|维度", "count", "number_with_unit"),
]

# 强类别信号（即便含 strength/温度等词也判类别/文本）
CATEGORICAL_HINTS = re.compile(
    r"_type$|_type_|类型$|策略|strategy|方式|mode$|模式|family|大类|class$|_class|"
    r"designation|牌号|_material$|material_|材料$|材料形|构型|configuration|architecture|拓扑|topology|"
    r"mechanism|机理|原理|principle|理论|theory|方程|equation|定律|law|假设|assumption|"
    r"method$|方法$|算法|algorithm|准则|criterion|criteria|描述$|description|summary$|总结|"
    r"symmetry|对称|shape|形状$|profile|外形|scenario|场景|platform|平台|regime|工况|"
    r"_name$|名称|schedule|制度|方案|framework|框架|software|工具|tool|atmosphere|气氛|"
    r"route$|路线|sequence|顺序|condition$|状态$|state$|descriptor|表征符|stability|稳定性|"
    r"morphology|形貌|pathway|路径|relationship|关系|effect|影响|trend|趋势|rule|规则|"
    r"medium|介质|environment|环境|orientation|取向|方向|direction|location|位置|presence|"
    r"system$|体系|database|数据库|standard|标准|model_type|模型类型|approach|途径|"
    r"basis|基准|notes?$|说明|status|状态",
    re.I)
_LIST_NAME = re.compile(r"variables$|变量$|components|组成|constituents|keywords|关键词|aliases|别名|"
                        r"elements$|元素|sequence|序列|set$|集|systems$|techniques|技术|list|列表", re.I)
_COUNT_NAME = re.compile(r"_count$|count$|数量$|个数|层数|道次$|reuse_cycles|replicate", re.I)
_NOUNIT_NUMBER = re.compile(r"response_metric|目标响应|objective|目标函数|metric$|判据", re.I)
MATERIAL_NAME_FIELDS = re.compile(
    r"alloy_designation|alloy_name|alloy_system|alloy_aliases|牌号|_material$|^material_|"
    r"mold_or_die_material|substrate_material|quench_medium|淬火介质", re.I)
LIST_HINTS = _LIST_NAME
RANGE_HINTS = re.compile(r"range$|范围|区间|sweep|区段|window$|窗口", re.I)


def _read_rows(path: str) -> List[dict]:
    with open(path, encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def derive_unit(text: str) -> Tuple[str, str, str]:
    for pat, unit, vtype in UNIT_RULES:
        if re.search(pat, text, re.I):
            return unit, vtype, pat[:24]
    return "", "", ""


def derive_value_type(name: str, unit_vtype: str, unit: str) -> str:
    if unit:
        return unit_vtype or "number_with_unit"
    if CATEGORICAL_HINTS.search(name):
        return "categorical"
    return "string"


def derive_binding(node_type: str, module: str, role: str, value_type: str) -> Tuple[str, str]:
    """数值/观测类字段才需要绑定上下文。返回 (bind_keys, quality_check)。"""
    numeric = value_type in ("number_with_unit", "range", "number")
    if role == "condition" or not numeric:
        return "", ""
    if module == "M8_Property" or role == "observation":
        return ("material_system;material_state;test_condition",
                "observation value MUST bind material_state and test_condition")
    if module == "M9_Defect":
        return ("material_system;process_state", "defect metric SHOULD bind process_state")
    if module == "M3_Composition":
        return ("material_system", "composition value SHOULD bind material_system")
    if module == "M4_Structure":
        return ("material_system;material_state", "structure feature SHOULD bind material_state")
    if module == "M5_Process":
        return ("material_system;process_state", "process parameter SHOULD bind process_route/step")
    if module == "M7_Modeling":
        return ("model_setup", "model parameter SHOULD bind the model/analysis it belongs to")
    return "", ""


def derive_cardinality(value_type: str, role: str, module: str) -> str:
    if value_type == "list":
        return "list"
    if role == "observation" or module in ("M8_Property", "M9_Defect", "M3_Composition",
                                           "M4_Structure", "M5_Process"):
        return "multiple_by_condition"
    return "single"


def enrich(domain_csv: str, overrides: Dict[str, dict] | None = None) -> List[dict]:
    overrides = overrides or {}
    out = []
    for r in _read_rows(domain_csv):
        en = (r.get(_C_EN) or "").strip()
        if not en:
            continue
        cn = (r.get(_C_CN) or "").strip()
        desc = (r.get(_C_DESC) or "").strip()
        cid = (r.get(_C_CID) or "").strip()
        cname = (r.get(_C_CNAME) or "").strip()
        cname_en = (r.get(_C_CNAME_EN) or "").strip()
        level = _level_key(r.get(_C_LEVEL) or "")

        route = resolve(en, cn, level, cid, cname_en, cname, overrides)
        node_type, module, role = route["node_type"], route["module"], route.get("role", "")

        name = f"{en} {cn}"
        text = f"{en} {cn} {desc}"

        if _COUNT_NAME.search(name):
            unit, value_type, rule = "count", "number_with_unit", "count_name"
        elif _NOUNIT_NUMBER.search(name):
            unit, value_type, rule = "", "number", "no_unit_number"
        elif re.search(r"cost_per_kg|成本|单价|price|价格", name, re.I) and re.search(r"per_kg|_cost|价|price", name, re.I):
            unit, value_type, rule = "CNY/kg", "number_with_unit", "cost_rule"
        elif MATERIAL_NAME_FIELDS.search(en) or CATEGORICAL_HINTS.search(name):
            unit, value_type, rule = "", "categorical", "categorical_name"
        elif _LIST_NAME.search(name):
            unit, value_type, rule = "", "list", "list_name"
        else:
            unit, unit_vtype, rule = derive_unit(name)
            allow_desc = (module in ("M8_Property", "M9_Defect")) or role == "observation"
            if not unit and allow_desc:
                unit, unit_vtype, rule = derive_unit(text)
            value_type = derive_value_type(name, unit_vtype, unit)

        if rule not in ("count_name", "no_unit_number"):
            if LIST_HINTS.search(name):
                value_type = "list"
            elif RANGE_HINTS.search(name) and unit:
                value_type = "range"

        # Discovery/Concept 里的“数值”实为定性陈述 → 降级 string，不绑定
        if (node_type in ("Discovery", "Concept")
                and value_type in ("number_with_unit", "range", "number")
                and rule != "count_name"):
            value_type, unit = "string", ""

        bind_keys, qc = derive_binding(node_type, module, role, value_type)
        cardinality = derive_cardinality(value_type, role, module)

        out.append({
            "field_en": en, "field_cn": cn, "cluster_id": cid, "level": level,
            "module": module, "node_type": node_type, "role": role,
            "value_type": value_type, "unit": unit, "cardinality": cardinality,
            "bind_keys": bind_keys, "quality_check": qc, "derived_by": rule or "none",
        })
    return out


def report(rows: List[dict]) -> str:
    n = max(1, len(rows))
    with_unit = sum(1 for r in rows if r["unit"])
    vt = Counter(r["value_type"] for r in rows)
    nt = Counter(r["node_type"] for r in rows)
    bound = sum(1 for r in rows if r["bind_keys"])
    obs = sum(1 for r in rows if r["role"] == "observation")
    return "\n".join([
        "=" * 64,
        f"FieldSpec enrichment ({len(rows)} fields)",
        "=" * 64,
        f"  node_type   : {dict(nt)}",
        f"  value_type  : {dict(vt)}",
        f"  observation : {obs}   with binding: {bound}",
        f"  with unit   : {with_unit}/{len(rows)} ({with_unit*100//n}%)",
        "  审计建议：抽查 derived_by='none' 的行(多为类别/文本)，",
        "            以及 node_type 是否符合预期；可在 cluster_to_module.yaml 显式覆盖。",
        "=" * 64,
    ])


def main():
    ap = argparse.ArgumentParser(description="派生领域 schema 的 FieldSpec（合金域）")
    ap.add_argument("--domain", required=True, help="refined_schema_*.csv")
    ap.add_argument("--overrides", default=str(_META_DIR / "cluster_to_module.yaml"))
    ap.add_argument("--out", default=str(_META_DIR / "domain_fieldspec.csv"))
    args = ap.parse_args()

    ov = load_overrides(args.overrides)
    rows = enrich(args.domain, ov)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    cols = ["field_en", "field_cn", "cluster_id", "level", "module", "node_type", "role",
            "value_type", "unit", "cardinality", "bind_keys", "quality_check", "derived_by"]
    with open(out, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        w.writerows(rows)
    print(report(rows))
    print(f"  overrides: {len(ov)} 条  ->  {out}")


if __name__ == "__main__":
    main()
