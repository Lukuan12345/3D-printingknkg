"""kg_v2.schema —— P1 两层 Schema 注入。"""
