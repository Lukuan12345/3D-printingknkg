#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""cluster_router.py —— 把领域 schema 的聚类 / 字段路由到 Meta 模块 + 节点类型。

为什么不直接用 cluster_id 映射（Scholar_KG_v2 的做法）？
  gen_key 的领域 schema 由 schema_gen 在线聚类产出，cluster_id 跨 schema 不稳定
  （钛合金的 cluster_4 = 凝固/VAR，超材料的 cluster_4 = 材料体系）。所以这里改成：

  1) 先按「聚类英文/中文名的关键词」推断一个基线 (module, node_type, role)；
  2) 再按「字段层级 + 字段名模式」做逐字段精修（解决一个聚类里混了
     性能(Measurement) 和 机理/优化(Discovery) 的情况，例如钛合金 cluster_8
     “Properties, Validation & Higher-Order Knowledge Synthesis”）；
  3) 可选：cluster_to_module.yaml 的显式覆盖（按 cluster_id 或精确聚类名）优先级最高。

node_type ∈ {Narrative, Measurement, Discovery}。
Concept 不在此路由——它由抽取阶段自由产出（atoms/claim），与 schema 字段解耦。
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Dict, Optional, Tuple

Route = Dict[str, str]  # {module, node_type, role}

# ── 1) 聚类名关键词规则（顺序敏感，首次命中即用作基线）────────────────────────
# 作用对象：聚类英文名 + 中文名（小写后拼接）。
CLUSTER_RULES = [
    # 性能 / 响应 / 结果（观测）—— 放在 mechanism 之前，保证“Properties...”聚类先落 Measurement
    (r"propert|performance|response variable|response outcome|outcome|性能|响应结果",
     {"module": "M8_Property", "node_type": "Measurement", "role": "observation"}),
    # 缺陷 / 失效 / 质量
    (r"defect|failure|limit state|缺陷|失效|质量结果",
     {"module": "M9_Defect", "node_type": "Measurement", "role": "observation"}),
    # 机理 / 因果 / 解释 / 调控
    (r"mechanism|causal|interpretation|response.?control|relationship|机理|因果|解释|调控",
     {"module": "M10_Mechanism", "node_type": "Discovery", "role": "mechanism"}),
    # 优化 / 设计空间 / 需求 / 知识沉淀 / 贡献
    (r"optimization|design space|requirement|knowledge synthesis|higher.?order|novelty|"
     r"contribution|technical approach|tradeoff|优化|设计空间|约束要求|知识|贡献|创新|权衡",
     {"module": "M11_Optimization", "node_type": "Discovery", "role": "mechanism"}),
    # 工艺 / 形变 / 加工 / 载荷 / 后处理
    (r"process|toolpath|post.?processing|thermo.?mechanical|deformation|workability|loading|"
     r"工艺|加工|变形|载荷|热机械|后处理|成形参数|凝固.*工艺",
     {"module": "M5_Process", "node_type": "Measurement", "role": "variable"}),
    # 成分 / 材料体系 / 原料
    (r"composition|material system|feedstock|material identity|phase.?stability|alloy system|"
     r"成分|体系|原料|相稳定|合金体系|材料身份",
     {"module": "M3_Composition", "node_type": "Measurement", "role": "variable"}),
    # 组织 / 织构 / 相变 / 凝固 / 熔池 / 几何 / 热历史
    (r"structur|geometr|microstructure|texture|crystallograph|phase fraction|transformation|"
     r"melt pool|solidification|interfacial|thermal history|dendrite|组织|织构|晶体|相变|相分数|"
     r"凝固|熔池|界面|热历史|几何|构型|微观",
     {"module": "M4_Structure", "node_type": "Measurement", "role": "variable"}),
    # 表征 / 测试条件 / 监测 / 验证 / 试样装置
    (r"testing condition|measurement protocol|characteriz|monitoring|validation|specimen|setup|"
     r"表征|测试条件|监测|验证|试样|装置",
     {"module": "M6_Characterization", "node_type": "Measurement", "role": "condition"}),
    # 建模 / 数值 / 理论 / 相场 / 学习架构
    (r"\bmodel|numerical|computational|governing physics|theory|learning architecture|phase.?field|"
     r"建模|数值|计算模型|理论|物理.*学习|相场",
     {"module": "M7_Modeling", "node_type": "Measurement", "role": "variable"}),
    # 叙事：应用 / 对象 / 运行工况 / 研究框架/设计 / 证据 / 文献元数据
    (r"application context|artifact identity|functional role|operating|integration environment|"
     r"study fram|study design|evidence provenance|bibliographic|metadata|content overview|"
     r"应用|对象|功能定位|运行|工况|集成|研究框架|研究设计|证据来源|文献|元数据",
     {"module": "M2_Identity", "node_type": "Narrative", "role": "context"}),
]

# 兜底：聚类名一个都没命中时，按层级猜（Scholar 同款）
LEVEL_FALLBACK: Dict[str, Route] = {
    "Level 1": {"module": "M2_Identity",   "node_type": "Narrative",   "role": "context"},
    "Level 2": {"module": "M5_Process",    "node_type": "Measurement", "role": "variable"},
    "Level 3": {"module": "M8_Property",   "node_type": "Measurement", "role": "observation"},
    "Level 4": {"module": "M10_Mechanism", "node_type": "Discovery",   "role": "mechanism"},
}
_DEFAULT: Route = {"module": "M8_Property", "node_type": "Measurement", "role": "observation"}

# ── 2) 逐字段精修：字段名/层级模式（优先级高于聚类基线）──────────────────────
# Discovery 信号：机理 / 因果 / 关系 / 趋势 / 优化 / 推荐 / 权衡 / 敏感性 / 主导 ...
FIELD_DISCOVERY = re.compile(
    r"mechanism|causal|relationship|_trend|observed_trend|tradeoff|optimization|optimal|"
    r"recommended|sensitivity|dominant|effect_summary|strateg|_window|design_rule|"
    r"improvement|validation_status|contribution|novelty|key_conclusion|"
    r"机理|因果|关系|趋势|权衡|优化|推荐|敏感|主导|设计结论|创新", re.I)
# 观测信号：具体可测性能/指标（用于把混合聚类里的性能字段救回 Measurement-observation）
FIELD_OBSERVATION = re.compile(
    r"strength|elongation|toughness|hardness|fatigue_life|fatigue_strength|creep|modulus|"
    r"conductivity|relative_density|porosity|_rate$|corrosion_rate|yield|\buts\b|ductility|"
    r"_fraction|grain_size|spacing|_error|life_cycles|强度|延伸|伸长|硬度|韧性|疲劳|孔隙|"
    r"晶粒|分数|寿命|误差", re.I)
# 条件信号：测试/工艺条件（不作观测值，本身就是 condition）
FIELD_CONDITION = re.compile(
    r"test_temperature|test_orientation|loading_mode|loading_path|strain_rate|"
    r"specimen_geometry|specimen_source|gauge|atmosphere|测试温度|加载|试样|气氛", re.I)

_MECH_MODULE = re.compile(r"optimization|optimal|recommended|tradeoff|sensitivity|requirement|"
                          r"contribution|novelty|window|improvement|conclusion|优化|推荐|权衡|敏感|贡献|创新", re.I)


def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", (s or "").strip().lower())


def route_cluster(cluster_name_en: str, cluster_name_cn: str = "") -> Optional[Route]:
    """按聚类名关键词推断基线 route；都没命中返回 None。"""
    text = f"{_norm(cluster_name_en)} {_norm(cluster_name_cn)}"
    for pat, route in CLUSTER_RULES:
        if re.search(pat, text, re.I):
            return dict(route)
    return None


def route_field(field_en: str, field_cn: str, level: str, base: Route) -> Route:
    """在聚类基线之上做逐字段精修。"""
    name = f"{field_en} {field_cn}".lower()
    lv = _level_key(level)

    # (a) 机理/优化字段名，或 Level 4 → Discovery（Level4 在各 schema 都是机理/优化）
    if FIELD_DISCOVERY.search(name) or lv == "Level 4":
        module = "M11_Optimization" if _MECH_MODULE.search(name) else "M10_Mechanism"
        return {"module": module, "node_type": "Discovery", "role": "mechanism"}

    # (b) 聚类基线是 Discovery，但本字段是 L1-L3 且不像机理 → 降级为 Measurement
    #     （救回 “Properties...Higher-Order” 这类混合聚类里的性能/数据字段）
    if base.get("node_type") == "Discovery":
        if FIELD_OBSERVATION.search(name):
            return {"module": "M8_Property", "node_type": "Measurement", "role": "observation"}
        if FIELD_CONDITION.search(name):
            return {"module": "M6_Characterization", "node_type": "Measurement", "role": "condition"}
        return {"module": "M5_Process", "node_type": "Measurement", "role": "variable"}

    # (c) 聚类基线是 Measurement：精修 role（观测/条件）
    if base.get("node_type") == "Measurement":
        if FIELD_CONDITION.search(name):
            return {"module": "M6_Characterization", "node_type": "Measurement", "role": "condition"}
        if FIELD_OBSERVATION.search(name) and base.get("role") != "observation":
            return {"module": "M8_Property", "node_type": "Measurement", "role": "observation"}

    return base


def _level_key(level: str) -> str:
    for lv in ("Level 1", "Level 2", "Level 3", "Level 4"):
        if lv in (level or ""):
            return lv
    return ""


# ── 3) 显式覆盖（可选）：cluster_to_module.yaml ──────────────────────────────
def load_overrides(yaml_path: str | Path) -> Dict[str, Route]:
    """读取显式覆盖。键可以是 cluster_id（如 cluster_8）或精确聚类英文名。
    解析极简（避免引入 pyyaml 依赖）：只认 `key: {module: .., node_type: .., role: ..}` 行。"""
    p = Path(yaml_path)
    if not p.exists():
        return {}
    overrides: Dict[str, Route] = {}
    line_re = re.compile(r'^\s*["\']?([^:"\']+?)["\']?\s*:\s*\{(.+)\}\s*$')
    kv_re = re.compile(r'(module|node_type|role)\s*:\s*([A-Za-z0-9_]+)')
    for raw in p.read_text(encoding="utf-8").splitlines():
        s = raw.strip()
        if not s or s.startswith("#"):
            continue
        m = line_re.match(s)
        if not m:
            continue
        key = m.group(1).strip()
        kv = dict(kv_re.findall(m.group(2)))
        if "module" in kv and "node_type" in kv:
            overrides[key] = {"module": kv["module"], "node_type": kv["node_type"],
                              "role": kv.get("role", "")}
    return overrides


def resolve(field_en: str, field_cn: str, level: str,
            cluster_id: str, cluster_name_en: str, cluster_name_cn: str = "",
            overrides: Optional[Dict[str, Route]] = None) -> Route:
    """主入口：返回某字段最终的 (module, node_type, role)。

    优先级：显式覆盖(cluster_id / 聚类名) > 聚类关键词基线 + 逐字段精修 > 层级兜底。
    """
    overrides = overrides or {}
    # 显式覆盖（聚类级）——仍允许逐字段精修在其上微调？这里选择：覆盖即定，不再精修。
    if cluster_id and cluster_id in overrides:
        return dict(overrides[cluster_id])
    if cluster_name_en and cluster_name_en in overrides:
        return dict(overrides[cluster_name_en])

    base = route_cluster(cluster_name_en, cluster_name_cn) \
        or LEVEL_FALLBACK.get(_level_key(level)) or dict(_DEFAULT)
    return route_field(field_en, field_cn, level, base)
