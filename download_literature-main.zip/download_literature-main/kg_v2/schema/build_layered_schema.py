#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""build_layered_schema.py —— 两层 Schema 组装器（gen_key/kg_v2）。

Layer 1 (META) : kg_v2/meta_schema/meta_schema.csv —— 12 模块通用骨架，跨领域不变。
Layer 2 (DOMAIN): schema_gen 产出的 refined_schema_*.csv —— 经 cluster_router 路由到
                  Meta 模块 + node_type，再经 enrich_fieldspec 派生 unit/value_type/bind_keys。

产出 kg_v2/meta_schema/layered_schema.json：
    {
      "meta": [...],                       # 12 模块骨架原样
      "domain_fields": [ {field_en, field_cn, desc, hint, level, cluster_id, cluster_name,
                          module, node_type, role, applicable_domains,
                          value_type, unit, cardinality, bind_keys, quality_check} ],
      "by_node_type": {Narrative:[...], Measurement:[...], Discovery:[...]},
      "by_stage":     {A:[...], B:[...], C:[...]},   # 单调用抽取时用于渲染分块
      "bind_by_field":{field_en: "material_state;test_condition", ...},  # 观测绑定规则
      "stats": {...}
    }

用法:
    python -m kg_v2.schema.build_layered_schema --domain <refined_schema.csv>
"""
from __future__ import annotations

import argparse
import csv
import json
import re
from pathlib import Path
from typing import Dict, List

try:
    from .cluster_router import resolve, load_overrides, _level_key
    from .enrich_fieldspec import enrich
except ImportError:  # pragma: no cover
    import sys
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from cluster_router import resolve, load_overrides, _level_key  # type: ignore
    from enrich_fieldspec import enrich  # type: ignore

_HERE = Path(__file__).resolve().parent
_META_DIR = _HERE.parent / "meta_schema"

_C_EN = "字段名（英文）"; _C_CN = "字段名（中文）"; _C_DESC = "完整描述"
_C_HINT = "提取提示"; _C_LEVEL = "层级"; _C_CID = "聚类ID"
_C_CNAME = "聚类名称"; _C_CNAME_EN = "聚类名称（英文）"; _C_DOM = "适用领域"

STAGE_BY_NODE_TYPE = {"Narrative": "A", "Measurement": "B", "Discovery": "C", "Concept": "C"}


def _read_csv(path: str) -> List[dict]:
    with open(path, encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def build(meta_csv: str, domain_csv: str, overrides: Dict[str, dict] | None = None) -> dict:
    overrides = overrides or {}
    meta_rows = _read_csv(meta_csv)

    # FieldSpec（unit/value_type/cardinality/bind_keys/quality_check）按 field_en 索引
    spec_by_field = {s["field_en"]: s for s in enrich(domain_csv, overrides)}

    domain_fields: List[dict] = []
    bind_by_field: Dict[str, str] = {}
    for r in _read_csv(domain_csv):
        en = (r.get(_C_EN) or "").strip()
        if not en:
            continue
        cn = (r.get(_C_CN) or "").strip()
        level = _level_key(r.get(_C_LEVEL) or "")
        cid = (r.get(_C_CID) or "").strip()
        cname = (r.get(_C_CNAME) or "").strip()
        cname_en = (r.get(_C_CNAME_EN) or "").strip()
        route = resolve(en, cn, level, cid, cname_en, cname, overrides)
        spec = spec_by_field.get(en, {})
        dom_str = (r.get(_C_DOM) or "").strip()
        applicable = [d.strip() for d in re.split(r"[,，;；]+", dom_str)
                      if d.strip() and d.strip().lower() != "nan"]
        fld = {
            "field_en": en, "field_cn": cn,
            "desc": (r.get(_C_DESC) or "").strip(),
            "hint": (r.get(_C_HINT) or "").strip(),
            "level": level, "cluster_id": cid, "cluster_name": cname_en or cname,
            "module": route["module"], "node_type": route["node_type"], "role": route.get("role", ""),
            "applicable_domains": applicable,
            "value_type": spec.get("value_type", ""), "unit": spec.get("unit", ""),
            "cardinality": spec.get("cardinality", ""), "bind_keys": spec.get("bind_keys", ""),
            "quality_check": spec.get("quality_check", ""),
        }
        domain_fields.append(fld)
        if spec.get("bind_keys"):
            bind_by_field[en] = spec["bind_keys"]

    by_node_type: Dict[str, list] = {"Narrative": [], "Measurement": [], "Discovery": [], "Concept": []}
    by_stage: Dict[str, list] = {"A": [], "B": [], "C": []}
    for f in domain_fields:
        by_node_type.setdefault(f["node_type"], []).append(f)
        by_stage[STAGE_BY_NODE_TYPE.get(f["node_type"], "C")].append(f)

    return {
        "meta": meta_rows,
        "domain_fields": domain_fields,
        "by_node_type": by_node_type,
        "by_stage": by_stage,
        "bind_by_field": bind_by_field,
        "stats": {
            "meta_fields": len(meta_rows),
            "domain_fields": len(domain_fields),
            "by_node_type": {k: len(v) for k, v in by_node_type.items()},
            "by_stage": {k: len(v) for k, v in by_stage.items()},
            "observation_fields": sum(1 for f in domain_fields if f["role"] == "observation"),
            "fields_with_unit": sum(1 for f in domain_fields if f["unit"]),
            "fields_with_binding": len(bind_by_field),
        },
    }


def main():
    ap = argparse.ArgumentParser(description="构建两层(meta+领域) schema -> layered_schema.json")
    ap.add_argument("--meta", default=str(_META_DIR / "meta_schema.csv"))
    ap.add_argument("--domain", required=True, help="refined_schema_*.csv (schema_gen 产出)")
    ap.add_argument("--overrides", default=str(_META_DIR / "cluster_to_module.yaml"))
    ap.add_argument("--out", default=str(_META_DIR / "layered_schema.json"))
    args = ap.parse_args()

    ov = load_overrides(args.overrides)
    result = build(args.meta, args.domain, ov)
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")

    s = result["stats"]
    print("=" * 64)
    print("Layered schema built")
    print(f"  meta fields        : {s['meta_fields']}")
    print(f"  domain fields      : {s['domain_fields']}")
    print(f"  by node_type       : {s['by_node_type']}")
    print(f"  by stage (A/B/C)   : {s['by_stage']}")
    print(f"  observation fields : {s['observation_fields']}  (binding rules: {s['fields_with_binding']})")
    print(f"  fields with unit   : {s['fields_with_unit']}")
    print(f"  overrides applied  : {len(ov)}")
    print(f"  -> {args.out}")
    print("=" * 64)


if __name__ == "__main__":
    main()
