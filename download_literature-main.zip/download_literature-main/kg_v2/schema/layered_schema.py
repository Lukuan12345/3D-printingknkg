#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""layered_schema.py —— 载入 layered_schema.json，按 node_type 渲染 prompt 注入块。

P2 的单调用抽取器用它把「分层 schema」注入一个 Haiku prompt：
  - render_block(node_type, paper_domains): 渲染该类型字段为 markdown（按 Level 分段）
  - bind_by_field: 观测字段 → 应绑定的条件键（喂给质检 quality_flags）
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List, Optional


class LayeredSchema:
    def __init__(self, layered_json_path: str | Path):
        data = json.loads(Path(layered_json_path).read_text(encoding="utf-8"))
        self.meta: List[dict] = data.get("meta", [])
        self.domain_fields: List[dict] = data.get("domain_fields", [])
        self.by_node_type: Dict[str, List[dict]] = data.get("by_node_type", {})
        self.by_stage: Dict[str, List[dict]] = data.get("by_stage", {})
        self.bind_by_field: Dict[str, str] = data.get("bind_by_field", {})

    # ── 按 node_type 取字段（可按论文领域过滤）─────────────────────────────
    def fields_for(self, node_type: str, paper_domains: Optional[List[str]] = None) -> List[dict]:
        fields = self.by_node_type.get(node_type, [])
        if not paper_domains:
            return fields
        pset = {d.strip().lower() for d in paper_domains if d.strip()}
        out = [f for f in fields
               if not f.get("applicable_domains")
               or ({d.lower() for d in f["applicable_domains"]} & pset)]
        return out or fields  # 不返回空集

    def render_block(self, node_type: str, paper_domains: Optional[List[str]] = None) -> str:
        return self._render(self.fields_for(node_type, paper_domains))

    @staticmethod
    def _render(fields: List[dict]) -> str:
        by_level: Dict[str, list] = {}
        for f in fields:
            by_level.setdefault(f.get("level") or "Level ?", []).append(f)
        out = []
        for lv in ("Level 1", "Level 2", "Level 3", "Level 4", "Level ?"):
            rows = by_level.get(lv)
            if not rows:
                continue
            out.append(f"### {lv} ({len(rows)} fields)")
            for f in rows:
                line = f"- **{f['field_en']}** ({f.get('field_cn','')}): {f.get('desc','')}"
                if f.get("unit"):
                    line += f" [unit: {f['unit']}]"
                if f.get("quality_check"):
                    line += f" [check: {f['quality_check']}]"
                elif f.get("hint"):
                    line += f" [hint: {f['hint']}]"
                out.append(line)
        return "\n".join(out)
