#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""stats_report.py —— 全量分类型诊断报告（审查 §5 规格）。

读 kb_v2_clean/*.json 的 per-paper _quality，汇总成语料级分桶报告：
  - 按 record_type（total / tier 分布 / table_id率 / entity归一率 / non_material_solute）
  - binary_alloy_parameter 专项（solvent/binary_system/table_id/main_tier 率）
  - 按来源体裁（文件名 '__part' 前缀，如 Compilation / Corrosion）
  - top-bad-files（reject率 / 缺solvent / 缺table_id / 强因果率 / field-unit错配）
输出 STATS_FULL.md + stats_full.json。用于全量后的规模化诊断，不改任何抽取逻辑。

用法: python -m kg_v2.postprocess.stats_report --kb kg_v2/kb_v2_clean --out kg_v2/graph_out
"""
from __future__ import annotations

import argparse
import glob
import json
import os
from collections import Counter, defaultdict
from pathlib import Path

_HERE = Path(__file__).resolve().parents[2]


def _genre(paper_id: str) -> str:
    base = paper_id.split("__", 1)[0]
    return base[:42]


def aggregate(kb_dir: str) -> dict:
    files = [f for f in sorted(glob.glob(str(Path(kb_dir) / "*.json")))
             if not os.path.basename(f).startswith("_")]
    # 按类型累加（加权率 = sum(rate*total)/sum(total)）
    type_tot = Counter()
    type_w = defaultdict(lambda: defaultdict(float))   # type -> metric -> sum(rate*total)
    type_tier = defaultdict(Counter)
    tier_all = Counter()
    genre_tier = defaultdict(Counter)
    genre_tot = Counter()
    bad = []  # per-file diagnostics

    for fp in files:
        d = json.loads(Path(fp).read_text(encoding="utf-8"))
        pid = d.get("paper_id", os.path.basename(fp))
        q = d.get("_quality", {})
        g = _genre(pid)
        bt = q.get("table_record_by_type") or {}
        tier = q.get("table_record_tier") or {}
        for t, c in tier.items():
            tier_all[t] += c
            genre_tier[g][t] += c
        for rt, m in bt.items():
            tot = m.get("total", 0)
            type_tot[rt] += tot
            genre_tot[g] += tot
            for mk in ("with_table_id_rate", "with_solvent_rate",
                       "with_binary_system_rate", "entity_normalized_rate"):
                if m.get(mk) is not None:
                    type_w[rt][mk] += m[mk] * tot
            type_w[rt]["_non_material_solute"] += m.get("non_material_solute_count", 0)
        # per-type tier 需要从记录级别算（_quality 没存 type×tier），用 layered 兜底
        for tr in (d.get("layered", {}).get("TableRecords") or []):
            type_tier[tr.get("record_type")][tr.get("_tier") or "?"] += 1

        # bad-file 诊断
        bin_m = bt.get("binary_alloy_parameter", {})
        tr_total = q.get("table_record_total", 0)
        rej = tier.get("reject", 0)
        bad.append({
            "paper_id": pid,
            "reject_rate": round(rej / tr_total, 3) if tr_total else 0.0,
            "missing_solvent": round(1 - (bin_m.get("with_solvent_rate") or 0), 3) if bin_m else None,
            "missing_table_id": round(1 - (bin_m.get("with_table_id_rate") or 0), 3) if bin_m else None,
            "strong_causal_rate": round((q.get("relation_strong_causal", 0) /
                                         max(1, q.get("relation_total", 0))), 3),
            "field_unit_mismatch": q.get("field_unit_mismatch_fixed", 0),
            "n_table_records": tr_total,
        })

    def rates(rt):
        tot = type_tot[rt] or 1
        return {k: round(v / tot, 3) for k, v in type_w[rt].items() if not k.startswith("_")}

    return {
        "papers": len(files),
        "tier_overall": dict(tier_all),
        "by_record_type": {rt: {"total": type_tot[rt], "tier": dict(type_tier.get(rt, {})),
                                **rates(rt),
                                "non_material_solute_count": int(type_w[rt]["_non_material_solute"])}
                           for rt in sorted(type_tot, key=lambda x: -type_tot[x])},
        "by_genre": {g: {"table_records": genre_tot[g], "tier": dict(genre_tier[g])}
                     for g in sorted(genre_tot, key=lambda x: -genre_tot[x])},
        "top_bad": {
            "by_reject_rate": sorted(bad, key=lambda x: -x["reject_rate"])[:20],
            "by_missing_solvent": sorted([b for b in bad if b["missing_solvent"] is not None],
                                         key=lambda x: -x["missing_solvent"])[:20],
            "by_missing_table_id": sorted([b for b in bad if b["missing_table_id"] is not None],
                                          key=lambda x: -x["missing_table_id"])[:20],
            "by_strong_causal": sorted(bad, key=lambda x: -x["strong_causal_rate"])[:20],
        },
    }


def to_md(s: dict) -> str:
    L = ["# kg_v2 全量分类型诊断 (STATS_FULL)", "",
         f"- papers: {s['papers']}", f"- TableRecord tier 总分布: {s['tier_overall']}", "",
         "## 按 record_type"]
    for rt, m in s["by_record_type"].items():
        L.append(f"### {rt}  (total={m['total']})")
        L.append(f"  - tier: {m.get('tier')}")
        extra = {k: v for k, v in m.items() if k not in ("total", "tier")}
        L.append(f"  - {extra}")
    L.append("\n## binary_alloy_parameter 专项")
    bin_m = s["by_record_type"].get("binary_alloy_parameter", {})
    L.append(f"  {bin_m}")
    L.append("\n## 按来源体裁")
    for g, m in s["by_genre"].items():
        L.append(f"  - {g}: {m}")
    L.append("\n## Top bad files (reject_rate)")
    for b in s["top_bad"]["by_reject_rate"][:10]:
        L.append(f"  - {b['paper_id'][:46]}  reject={b['reject_rate']} miss_solvent={b['missing_solvent']} "
                 f"miss_tid={b['missing_table_id']} strong_causal={b['strong_causal_rate']}")
    return "\n".join(L)


def main():
    ap = argparse.ArgumentParser(description="全量分类型诊断报告")
    ap.add_argument("--kb", default=str(_HERE / "kg_v2" / "kb_v2_clean"))
    ap.add_argument("--out", default=str(_HERE / "kg_v2" / "graph_out"))
    args = ap.parse_args()
    s = aggregate(args.kb)
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    (out / "stats_full.json").write_text(json.dumps(s, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "STATS_FULL.md").write_text(to_md(s), encoding="utf-8")
    print(to_md(s))
    print(f"\n-> {out}/STATS_FULL.md , stats_full.json")


if __name__ == "__main__":
    main()
