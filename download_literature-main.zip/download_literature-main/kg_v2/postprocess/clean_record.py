#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""clean_record.py —— P5 后处理：清洗 kb_v2/<paper_id>.json（纯规则，不调 LLM）。

修复审查发现的问题（4.1/4.3/4.4/4.5/4.7/4.10）：
  - 字段名规范化：去 `_` 前缀、小写、空格转下划线、同义合并（4.3）
  - 单位 mojibake 修复 + 归一化（4.4）
  - 范围值 "a to b" → value_low/value_high/value_type=range（4.5）
  - 关系类型降级：弱证据的 CONTROLS/CAUSES → CORRELATES_WITH/PREDICTS（4.7）
  - 顶层 domains 从 concepts + subdomain_tags 轻量映射（4.1，无额外 LLM）
  - 细粒度 _quality 指标（4.10）

幂等：可重复跑；原值保留在 *_raw。
用法:
    python -m kg_v2.postprocess.clean_record --kb kg_v2/kb_v2 --out kg_v2/kb_v2_clean
"""
from __future__ import annotations

import argparse
import glob
import json
import re
from collections import Counter
from pathlib import Path
from typing import Dict, List, Optional, Tuple

_HERE = Path(__file__).resolve().parents[2]

# ── 4.4 单位 mojibake 修复 ────────────────────────────────────────────────
# 字符丢失型（latin-1 往返救不回）→ 直接查表替换
_MOJIBAKE_MAP = {
    "Ã…": "Å", "Ã": "Å",            # angstrom（常见两种坏法）
    "Â³": "³", "Â²": "²", "Â°": "°", "Âµ": "µ", "Â±": "±", "Â": "",
    "â\x80\x93": "–", "â\x80\x94": "—", "â\x88\x92": "−", "â": "–",
    "Î¼": "μ", "Âµm": "µm",
}
_UNIT_NORM = {  # 单位归一化别名
    "cm3/mol": "cm³/mol", "cm^3/mol": "cm³/mol",
    "kcal/mole": "kcal/mol", "j/mole": "J/mol",
    "degc": "°C", "deg c": "°C", "k.": "K",
    "angstrom": "Å", "angstroms": "Å", "a": "Å",  # 注意：仅当原 unit 文本=='angstrom'类时
}


def _fix_mojibake(s: str) -> str:
    if not s:
        return s
    # 1) latin-1 往返（修 cmÂ³ / Â± 这类可逆型）
    try:
        if any(c in s for c in ("Â", "Ã", "â", "Î")):
            s2 = s.encode("latin-1", "ignore").decode("utf-8", "ignore")
            if s2 and "�" not in s2:
                s = s2
    except (UnicodeError, ValueError):
        pass
    # 2) 残留查表
    for bad, good in _MOJIBAKE_MAP.items():
        if bad in s:
            s = s.replace(bad, good)
    return s


def normalize_unit(u: Optional[str]) -> str:
    if not u:
        return ""
    u = _fix_mojibake(str(u)).strip()
    return _UNIT_NORM.get(u.lower(), u)


# ── 4.3 字段名规范化 ──────────────────────────────────────────────────────
_FIELD_SYNONYM = {
    "mott_bonding_number": "mott_number",
    "gordy_thomas_electronegativity": "gordy_thomas_electronegativity",
    "electronegativity_diff": "electronegativity_difference",
    "elongation_to_failure": "elongation",
    "uts": "ultimate_tensile_strength",
    "ys": "yield_strength",
}


def normalize_field(name: Optional[str]) -> str:
    if not name:
        return ""
    n = str(name).strip().lstrip("_")           # 去内部占位符前缀
    n = re.sub(r"\s+", "_", n).lower()
    n = re.sub(r"[^a-z0-9_]+", "_", n).strip("_")
    n = re.sub(r"_+", "_", n)
    return _FIELD_SYNONYM.get(n, n)


# ── A1：table_id 标准化（罗马数字 OCR：111/l1l/1II → III）────────────────────
# 模式化：TABLE-<中段>-<数字>，中段全由 I/l/1/i/L 组成 → 按长度还原罗马数字
_ROMAN_LEN = {1: "I", 2: "II", 3: "III", 4: "IV"}  # 该手册表号到 III/IV 段为止
_ILchars = "Il1iL."  # 可能混入的 OCR 字符（含异常点号）


def normalize_table_id(raw: str):
    """返回 (normalized, rule, confidence)。模式化归一中段罗马数字，不覆盖原值。"""
    s = (raw or "").strip()
    if not s:
        return "", "", 0.0
    m = re.match(r"^(TABLE)[\s\-_.]*([A-Za-z0-9.]+?)[\s\-_.]+(\d+)\.?$", s, re.I)
    if not m:
        return s, "asis", 1.0
    mid = m.group(2)
    num = m.group(3)
    core = re.sub(r"[.\s]", "", mid)   # 去异常点号/空格
    # 中段若全由 I/l/1/i 组成（OCR 罗马数字）→ 按字符数还原
    if core and all(c in "Il1i" for c in core):
        roman = _ROMAN_LEN.get(len(core), "I" * len(core))
        conf = 0.95 if len(core) <= 4 else 0.7
        return f"TABLE-{roman}-{num}", "roman_ocr", conf
    # 已是合法罗马数字
    if re.fullmatch(r"[IVXLC]+", core, re.I):
        return f"TABLE-{core.upper()}-{num}", "asis", 1.0
    return f"TABLE-{mid}-{num}", "asis", 0.85


# ── A3：严格 numeric token 校验 ────────────────────────────────────────────
_STRICT_FLOAT = re.compile(r"^[+-]?(\d+(\.\d*)?|\.\d+)([eE][+-]?\d+)?$")


def _is_scalar_number(v) -> bool:
    if isinstance(v, (int, float)):
        return True
    return bool(_STRICT_FLOAT.match(str(v).strip()))


# ── A2：物理边界门控（main 不可含物理不可能值/列错位）──────────────────────
def physical_demotion_reason(tr: dict):
    """返回 demotion_reason（应降级）或 None。仅对 binary/元素属性这类数值表生效。"""
    p = tr.get("parameters") or {}
    def num(k):
        v = p.get(k)
        return v if isinstance(v, (int, float)) else None
    # 全参数空 → 无数值价值（防御性硬规则）
    if not any(isinstance(v, (int, float)) for v in p.values()):
        return "no_numeric_parameter"
    ed = num("electronegativity_difference")
    if ed is not None and abs(ed) > 4:           # Pauling 电负性差 ≤ ~3.3
        return "electroneg_diff_impossible"
    rr = num("radius_ratio")
    if rr is not None and not (0 < rr <= 5):     # 半径比物理范围
        return "radius_ratio_out_of_range"
    hf = num("hildebrand_factor")
    if hf is not None and hf < 0:
        return "hildebrand_negative"
    er = num("energy_ratio")
    if er is not None and er < 0:                # 能量比为比值，负值不合理
        return "energy_ratio_negative"
    # 非标 numeric token：参数里出现非纯数字字符串
    nonscalar = [k for k, v in p.items() if v not in (None, "") and not _is_scalar_number(v)]
    if nonscalar:
        return "non_scalar_numeric_token"
    return None


def _solvent_valid(tr: dict) -> bool:
    """solvent 必须能归一到合法元素符号（修 _entity_confidence 只看 solute 的 bug）。"""
    return bool(str(tr.get("solvent_symbol") or "").strip())


# binary 参数表的规范参数列；main 必须至少有一个规范列是数值
_BINARY_CANON = {"radius_ratio", "energy_ratio", "mott_number",
                 "hildebrand_factor", "electronegativity_difference"}


def _has_canonical_numeric(tr: dict) -> bool:
    p = tr.get("parameters") or {}
    return any(isinstance(p.get(k), (int, float)) for k in _BINARY_CANON)


def _n_canonical_numeric(tr: dict) -> int:
    p = tr.get("parameters") or {}
    return sum(1 for k in _BINARY_CANON if isinstance(p.get(k), (int, float)))


# ── 5.2/5.3 TableRecord 入库质量门控（main / staging / reject）──────────────
def tier_for_record(tr: dict) -> str:
    rt = tr.get("record_type")
    params = tr.get("parameters") or {}
    has_numeric = any(isinstance(v, (int, float)) for v in params.values())
    if not has_numeric:
        return "reject"
    # A2/A3：物理不可能 / 列错位 / 非标 token → 最高也只能 staging（不进 main）
    demote = physical_demotion_reason(tr)
    if demote:
        tr["_demotion_reason"] = demote
    if rt == "binary_alloy_parameter":
        n_canon = _n_canonical_numeric(tr)
        # base_ok：进入 main/staging 检索的基本条件（与原 main 门一致，但规范列只要求 ≥1）
        base_ok = (str(tr.get("solvent") or "").strip() and str(tr.get("solute") or "").strip()
                   and str(tr.get("binary_system") or "").strip()
                   and _solvent_valid(tr)                       # solvent 必须是合法元素
                   and n_canon >= 1
                   and (tr.get("_entity_confidence") or 0) >= 0.9)
        main_ok = base_ok and n_canon == 5                      # 硬门：5 个规范参数列必须全为数值
        if not _solvent_valid(tr) and not tr.get("_demotion_reason"):
            tr["_demotion_reason"] = "invalid_or_unnormalized_solvent"
        if n_canon == 0 and not tr.get("_demotion_reason"):
            tr["_demotion_reason"] = "no_canonical_numeric_param"
        # 5.4：规范列不全（<5）多由源行 OCR 列错位/缺值/单元格合并导致 → 不进 main
        elif n_canon < 5 and not tr.get("_demotion_reason"):
            tr["_demotion_reason"] = "incomplete_canonical_params(<5)"
        if base_ok and str((tr.get("source") or {}).get("table_id") or "").strip():
            return "main" if (main_ok and not demote) else "staging"
        if base_ok:
            return "staging"          # 缺 table_id：可低置信检索，不进 ML
        return "reject"               # 缺 solvent/binary 的二元参数不可用
    if rt == "element_property_table":
        if demote:
            return "staging"
        return "main" if (tr.get("_entity_confidence") or 0) >= 0.9 else "staging"
    # 非二元表：有 row_label + 数值即可进 staging（不强求 binary 上下文）
    return "staging" if str(tr.get("row_label") or "").strip() else "reject"



# 非材料 solute（数字/公式/标准号/乱码）检测，用于 wrong_type/misfit 统计
_NON_MATERIAL = re.compile(r"^\d+$|longleftrightarrow|mathrm|\\|^[^a-zA-Z]*$")


# ── 4.5 field-unit 一致性校正（电极电位被误标为转变温度等）──────────────────
_FIELD_UNIT_FIX = [
    # (字段名匹配, 单位匹配, 纠正后字段, 说明)
    (re.compile(r"transformation_temp|转变温度|critical.*temp", re.I), re.compile(r"^m?v$", re.I),
     "standard_electrode_potential", "mV/V 不是温度→电极电位"),
    (re.compile(r"temperature|温度", re.I), re.compile(r"^m?v$", re.I),
     "standard_electrode_potential", "电压单位不应是温度字段"),
]

# 4.6 无量纲参数（这些字段单位应为 dimensionless 而非空）
_DIMENSIONLESS = re.compile(
    r"radius_ratio|energy_ratio|mott_number|electronegativity_difference|"
    r"ratio$|_factor$|valence|partition_coefficient|stress_ratio|taylor_factor|schmid", re.I)


def fix_field_unit(m: dict) -> dict:
    field = str(m.get("field") or "")
    unit = str(m.get("unit") or "").strip()
    for fpat, upat, newf, why in _FIELD_UNIT_FIX:
        if fpat.search(field) and upat.search(unit):
            m["_field_raw"] = m.get("_field_raw") or field
            m["field"] = newf
            m["_field_unit_fixed"] = why
            return m
    # 4.6 补无量纲单位
    if not unit and _DIMENSIONLESS.search(field) and m.get("value_num") is not None:
        m["unit"] = "dimensionless"
    return m
_RANGE_RE = re.compile(
    r"^\s*([+-]?\d+(?:\.\d+)?)\s*(?:to|–|-|~|—|±)\s*([+-]?\d+(?:\.\d+)?)\s*(.*)$", re.I)
_NUM_RE = re.compile(r"[+-]?\d+(?:\.\d+)?")


def parse_value(value_raw, value_num, value_high) -> Tuple[Optional[float], Optional[float], Optional[float], str]:
    """→ (value_num, value_low, value_high, value_type)。"""
    raw = "" if value_raw is None else str(value_raw)
    m = _RANGE_RE.match(raw)
    if m:
        lo, hi = float(m.group(1)), float(m.group(2))
        if lo > hi:
            lo, hi = hi, lo
        return None, lo, hi, "range"
    # 单值
    if value_num is not None:
        try:
            return float(value_num), None, None, "number_with_unit"
        except (TypeError, ValueError):
            pass
    nums = _NUM_RE.findall(raw)
    if len(nums) == 1:
        return float(nums[0]), None, None, "number_with_unit"
    if value_high is not None:  # 只有上限的残缺范围
        try:
            return None, None, float(value_high), "range"
        except (TypeError, ValueError):
            pass
    return None, None, None, "string"


# ── 4.7 关系类型降级 ──────────────────────────────────────────────────────
# 强因果词，证据不足时降级为相关/预测
_STRONG_REL = {"CONTROLS", "CAUSES"}
# 经验描述符（这些"控制"性质多为统计相关/预测，非实验机理）
_DESCRIPTOR = re.compile(
    r"radius[_ ]?ratio|electronegativit|hildebrand|mott|energy[_ ]?ratio|"
    r"atomic[_ ]?(radius|volume|size)|heat[_ ]?of[_ ]?sublimation|valenc|"
    r"size[_ ]?factor|gordy|半径比|电负性|原子半径", re.I)
# 真机理/实验证据信号（出现则保留强因果）
_MECH_EVID = re.compile(
    r"experiment|measured|observ|micrograph|tem |sem |in[_ ]?situ|mechanism|"
    r"because|due to|dislocation|precipitat|nucleat|实验|观察|机理|位错", re.I)
# 弱/经验证据信号
_WEAK_EVID = re.compile(
    r"table|tabl|comprehensive|collectively|predict|calculat|correlat|"
    r"\bif\b|when|tend|favorab|criteri|rule|guideline|empiric|trend|"
    r"表|计算|预测|经验|准则", re.I)


def soften_relation(rel: dict) -> dict:
    relation = (rel.get("relation") or "").upper()
    if relation not in _STRONG_REL:
        return rel
    head = str(rel.get("head") or "")
    tail = str(rel.get("tail") or "")
    ev = str(rel.get("evidence") or "")
    conf = (rel.get("confidence") or "").lower()

    has_mech = bool(_MECH_EVID.search(ev))
    is_descriptor = bool(_DESCRIPTOR.search(head) or _DESCRIPTOR.search(tail))
    weak = bool(_WEAK_EVID.search(ev)) or conf in ("medium", "low")

    # 描述符→性质，且无明确实验机理 → 几乎必为统计预测/相关，降级
    # 或：通用强因果但证据偏弱/置信不高 → 降级
    if (is_descriptor and not has_mech) or (weak and not has_mech):
        rel = dict(rel)
        is_pred = ("predict" in ev.lower()) or is_descriptor
        rel["relation"] = "PREDICTS" if is_pred else "CORRELATES_WITH"
        rel["_relation_original"] = relation
        rel["_downgraded"] = True
    return rel


# ── 4.1 顶层领域分类（轻量，无 LLM）───────────────────────────────────────
_DOMAIN_RULES = [
    ("aluminium alloy", r"alumin|al alloy|\b[27]\d{3}\b|\b5\d{3}\b"),
    ("corrosion", r"corros|pitting|passiv|oxide film|electrochem|scc|chloride"),
    ("magnesium alloy", r"\bmg\b|magnesium|mg-re|lpso|az\d|we43"),
    ("titanium alloy", r"titanium|\bti-6al|\bti alloy|tial|beta titanium|var\b"),
    ("additive manufacturing", r"lpbf|slm|ebm|\bded\b|waam|additive|melt pool|build direction"),
    ("thermodynamics", r"thermodynam|gibbs|enthalp|hildebrand|sublimation|calphad|free energy"),
    ("phase diagram", r"phase diagram|binary system|solvus|liquidus|solidus|eutectic|peritectic"),
    ("alloy design", r"alloy design|solid solution|radius ratio|electronegativit|mott|solute|solvent"),
    ("heat treatment", r"aging|solution treat|quench|anneal|temper|precipitat"),
    ("phase transformation", r"martensit|transformation|recrystalli|dynamic recrystall"),
    ("mechanical properties", r"tensile|yield strength|elongation|fatigue|fracture|hardness|toughness"),
    ("texture & crystallography", r"texture|ebsd|crystal plasticity|cpfe|slip system|twinning"),
]


def classify_domains(layered: dict, subdomain_tags: Optional[List[str]] = None) -> dict:
    """4.1：分级领域。primary=标题/对象/高频命中；secondary=次要命中；
    mentioned_materials=仅作为 solvent/solute 出现的材料名（不升级为领域）。"""
    nar = layered.get("Narrative") or {}
    # 主信号：问题陈述 + 设计对象 + subdomain_tags（作者意图）
    primary_blob = " ".join([str(nar.get("problem_statement") or ""),
                             str(nar.get("design_object") or "")] + (subdomain_tags or [])).lower()
    # 次信号：concepts + 测量字段（正文涉及，但未必是主题）
    sec_parts = []
    for c in (layered.get("Concepts") or []):
        sec_parts.extend(c.get("atoms") or []); sec_parts.append(c.get("claim") or "")
    for m in (layered.get("Measurements") or [])[:80]:
        sec_parts.append(m.get("field") or "")
    sec_blob = " ".join(sec_parts).lower()

    primary, secondary = [], []
    for d, pat in _DOMAIN_RULES:
        in_p = re.search(pat, primary_blob, re.I)
        in_s = re.search(pat, sec_blob, re.I)
        if in_p:
            primary.append(d)
        elif in_s:
            secondary.append(d)

    # mentioned_materials：来自 TableRecords 的 solvent/solute 符号（不作领域）
    trs = layered.get("TableRecords") or []
    mats = set()
    for tr in trs:
        for k in ("solvent_symbol", "solute_symbol"):
            if tr.get(k):
                mats.add(tr[k])
    # 参数汇编型文档（大量 binary/element 表）：材料族领域一律不作 primary/secondary，降到 mentioned
    n_param_tables = sum(1 for tr in trs if tr.get("record_type") in
                         ("binary_alloy_parameter", "element_property_table"))
    is_compilation = n_param_tables >= 20
    material_domain = {"aluminium alloy": ("Al", "alumin"), "magnesium alloy": ("Mg", "magnes"),
                       "titanium alloy": ("Ti", "titan")}

    def _is_real_material_topic(dom: str) -> bool:
        """材料族领域只有在标题/对象里明确以'X alloy'出现时才算真主题。"""
        if dom not in material_domain:
            return True
        sym, stem = material_domain[dom]
        return bool(re.search(stem + r"[a-z]*\s*(alloy|alloys)?", primary_blob, re.I)) and not is_compilation

    primary = [d for d in primary if _is_real_material_topic(d)]
    secondary = [d for d in secondary if _is_real_material_topic(d)
                 or (d in material_domain and not is_compilation
                     and material_domain[d][0] not in mats)]
    secondary = [d for d in secondary if d not in primary]
    return {
        "primary_domains": primary or (secondary[:2] if secondary else []),
        "secondary_domains": [d for d in secondary if d not in primary],
        "mentioned_materials": sorted(mats),
    }


# ── 4.10 细粒度质量指标 ───────────────────────────────────────────────────
def fine_quality(layered: dict, prev_quality: dict) -> dict:
    ms = layered.get("Measurements") or []
    n = len(ms)
    numeric = sum(1 for m in ms if m.get("value_num") is not None
                  or m.get("value_low") is not None or m.get("value_high") is not None)
    ranges = [m for m in ms if m.get("value_type") == "range"]
    range_parsed = sum(1 for m in ranges if m.get("value_low") is not None and m.get("value_high") is not None)
    with_unit = sum(1 for m in ms if str(m.get("unit") or "").strip())
    enc_err = sum(1 for m in ms if any(c in str(m.get("unit") or "") for c in ("Ã", "Â", "â", "�")))
    rels = layered.get("Relations") or []
    downgraded = sum(1 for r in rels if r.get("_downgraded"))
    strong_rel = sum(1 for r in rels if (r.get("relation") or "").upper() in ("CAUSES", "CONTROLS", "DETERMINES"))
    # 4.8：可追溯=evidence含table/page 或 有独立 table_id 字段
    evid_trace = sum(1 for m in ms if m.get("table_id")
                     or re.search(r"table|page|tabl|p\.\s*\d|图|表", str(m.get("evidence") or ""), re.I))
    fu_mismatch = sum(1 for m in ms if m.get("_field_unit_fixed"))
    # 4.7：TableRecords 专项指标（按 record_type 分桶，避免非二元表被 solvent/binary 误伤）
    trs = layered.get("TableRecords") or []
    tn = len(trs)
    by_type: dict = {}
    tier_counts = Counter()
    for t in trs:
        rt = t.get("record_type") or "unknown"
        b = by_type.setdefault(rt, {"total": 0, "table_id": 0, "solvent": 0, "binary": 0, "norm": 0,
                                    "non_material_solute": 0})
        b["total"] += 1
        if str((t.get("source") or {}).get("table_id") or "").strip():
            b["table_id"] += 1
        if str(t.get("solvent") or "").strip():
            b["solvent"] += 1
        if str(t.get("binary_system") or "").strip():
            b["binary"] += 1
        if (t.get("_entity_confidence") or 0) >= 0.9:
            b["norm"] += 1
        if rt == "binary_alloy_parameter" and _NON_MATERIAL.search(str(t.get("solute") or "")):
            b["non_material_solute"] += 1
        tier_counts[t.get("_tier") or "?"] += 1
    type_metrics = {rt: {
        "total": b["total"],
        "with_table_id_rate": round(b["table_id"] / b["total"], 3),
        **({"with_solvent_rate": round(b["solvent"] / b["total"], 3),
            "with_binary_system_rate": round(b["binary"] / b["total"], 3),
            "entity_normalized_rate": round(b["norm"] / b["total"], 3),
            "non_material_solute_count": b["non_material_solute"]}
           if rt in ("binary_alloy_parameter", "element_property_table") else {})
    } for rt, b in by_type.items()}

    q = dict(prev_quality or {})
    q.update({
        "measurement_total": n,
        "numeric_measurement_total": numeric,
        "numeric_parse_rate": round(numeric / n, 3) if n else 0.0,
        "range_total": len(ranges),
        "range_parse_rate": round(range_parsed / len(ranges), 3) if ranges else None,
        "unit_present_rate": round(with_unit / n, 3) if n else 0.0,
        "encoding_error_count": enc_err,
        "evidence_table_or_page_rate": round(evid_trace / n, 3) if n else 0.0,
        "field_unit_mismatch_fixed": fu_mismatch,
        "relation_total": len(rels),
        "relation_strong_causal": strong_rel,
        "relation_downgraded_count": downgraded,
        "table_record_total": tn,
        "table_record_by_type": type_metrics,        # 4.2：按类型分桶
        "table_record_tier": dict(tier_counts),       # 5.x：main/staging/reject 分布
    })
    return q


# ── 单篇清洗 ──────────────────────────────────────────────────────────────
def clean_record(rec: dict) -> dict:
    L = rec.get("layered") or {}
    nar = L.get("Narrative") or {}
    subdomain_tags = []
    df = nar.get("domain_fields") or {}
    for k in ("subdomain_tags", "subdomain", "domain"):
        v = df.get(k)
        if isinstance(v, list):
            subdomain_tags.extend(v)
        elif isinstance(v, str):
            subdomain_tags.append(v)

    # Measurements: 字段名/单位/范围
    for m in L.get("Measurements") or []:
        orig_field = m.get("field")
        nf = normalize_field(orig_field)
        if nf != orig_field:
            m["_field_raw"] = orig_field
            m["field"] = nf
        ou = m.get("unit")
        nu = normalize_unit(ou)
        if nu != ou:
            m["_unit_raw"] = ou
            m["unit"] = nu
        vn, vlo, vhi, vt = parse_value(m.get("value_raw"), m.get("value_num"), m.get("value_high"))
        m["value_num"] = vn
        m["value_low"] = vlo
        m["value_high"] = vhi
        if vt:
            m["value_type"] = vt
        fix_field_unit(m)   # 4.5 field-unit 校正 + 4.6 无量纲单位

    # Relations: 谓词归一 + relation_tier 分层 + 无证据强因果降级（relation_gov）
    try:
        from .relation_gov import govern_relation
    except ImportError:
        from kg_v2.postprocess.relation_gov import govern_relation  # type: ignore
    seen_rel = set()
    governed = []
    for r in (L.get("Relations") or []):
        gr = govern_relation(soften_relation(r))
        key = (str(gr.get("head", "")).lower(), gr.get("relation"), str(gr.get("tail", "")).lower())
        if key in seen_rel:   # 去重（同 head/relation/tail）
            continue
        seen_rel.add(key)
        governed.append(gr)
    L["Relations"] = governed

    # TableRecords: 规范化 parameters 字段名 + 修乱码 + 打入库分级 tier（4.2/4.3/4.4/5.x）
    for tr in L.get("TableRecords") or []:
        params = tr.get("parameters") or {}
        if isinstance(params, dict):
            newp = {}
            for k, v in params.items():
                nk = normalize_field(k)
                if isinstance(v, str):
                    v = _fix_mojibake(v)
                newp[nk] = v
            tr["parameters"] = newp
        # A1：table_id 标准化（保留 raw，不覆盖）
        src = tr.get("source") or {}
        raw_tid = src.get("table_id") or ""
        norm_tid, rule, conf = normalize_table_id(raw_tid)
        if raw_tid:
            src["table_id_raw"] = raw_tid
            src["table_id"] = norm_tid            # 归一后值用于去重/查询
            src["table_id_norm_rule"] = rule
            src["table_id_norm_confidence"] = conf
            tr["source"] = src
        # A2/A3：tier（含物理门控 + 非标 token；会写 _demotion_reason）
        tr["_tier"] = tier_for_record(tr)

    # 顶层 domains 分级（4.1）
    dom = classify_domains(L, subdomain_tags)
    rec["primary_domains"] = dom["primary_domains"]
    rec["secondary_domains"] = dom["secondary_domains"]
    rec["mentioned_materials"] = dom["mentioned_materials"]
    rec["domains"] = dom["primary_domains"]  # 向后兼容：顶层 domains = primary

    # 细粒度质量（4.10）
    rec["_quality"] = fine_quality(L, rec.get("_quality") or {})
    rec["_cleaned"] = True
    return rec


def main():
    ap = argparse.ArgumentParser(description="P5 后处理清洗 kb_v2/*.json")
    ap.add_argument("--kb", default=str(_HERE / "kg_v2" / "kb_v2"))
    ap.add_argument("--out", default=str(_HERE / "kg_v2" / "kb_v2_clean"))
    ap.add_argument("--content-store", default="",
                    help="给出则用源 md 重跑确定性表格解析(remerge)，应用最新 table_extract 改进，不重跑 LLM")
    args = ap.parse_args()

    remerge = None
    if args.content_store:
        try:
            from ..extract.table_extract import merge_into_record as remerge
        except ImportError:
            from kg_v2.extract.table_extract import merge_into_record as remerge  # type: ignore

    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    files = sorted(glob.glob(str(Path(args.kb) / "*.json")))
    agg = Counter()
    dom_counter = Counter()
    for fp in files:
        if Path(fp).name.startswith("_"):
            continue
        rec = json.loads(Path(fp).read_text(encoding="utf-8"))
        if remerge:
            md_path = Path(args.content_store) / str(rec.get("paper_id", "")) / "full.md"
            if md_path.exists():
                remerge(rec, md_path.read_text(encoding="utf-8", errors="ignore"), replace=True)
        rec = clean_record(rec)
        (out / Path(fp).name).write_text(json.dumps(rec, ensure_ascii=False, indent=2), encoding="utf-8")
        q = rec["_quality"]
        agg["measurements"] += q.get("measurement_total", 0)
        agg["numeric"] += q.get("numeric_measurement_total", 0)
        agg["enc_err"] += q.get("encoding_error_count", 0)
        agg["rel_downgraded"] += q.get("relation_downgraded_count", 0)
        for d in rec.get("domains") or []:
            dom_counter[d] += 1
    print("=" * 56)
    print(f"cleaned {len(files)} files -> {out}")
    print(f"  measurements={agg['measurements']} numeric={agg['numeric']} "
          f"enc_err_fixed≈{agg['enc_err']} rel_downgraded={agg['rel_downgraded']}")
    print(f"  domains: {dict(dom_counter)}")
    print("=" * 56)


if __name__ == "__main__":
    main()
