#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""export_binary_main.py —— 导出 main-tier 二元合金参数库 + 质量检查（审查§二优先级）。

从 kb_v2_clean/*.json 筛 record_type=binary_alloy_parameter 且 _tier=main，
导出扁平 CSV（一行一个 solvent-solute 记录），并跑三项检查：
  1. 完整性：solvent/solute/binary_system/table_id 非空 + ≥1 数值参数
  2. 去重：按 (binary_system, table_id) 查重复冲突值
  3. 异常值：radius_ratio∉(0,5]、|electroneg_diff|>4、hildebrand<0、mott 极端离群

用法: python -m kg_v2.postprocess.export_binary_main --kb kg_v2/kb_v2_clean --out kg_v2/exports
"""
from __future__ import annotations

import argparse
import csv
import glob
import json
import os
from collections import Counter, defaultdict
from pathlib import Path

_HERE = Path(__file__).resolve().parents[2]
_PARAMS = ["radius_ratio", "energy_ratio", "mott_number",
           "hildebrand_factor", "electronegativity_difference"]
_COLS = ["record_id", "paper_id", "source_genre", "part_id",
         "table_id", "table_id_raw", "table_id_norm_confidence", "row_label",
         "solvent", "solvent_symbol", "solute", "solute_symbol", "solute_raw",
         "binary_system", *_PARAMS, "entity_confidence", "tier", "demotion_reason"]


def _genre(pid): return pid.split("__", 1)[0][:42]
def _part(pid):
    return pid.split("__", 1)[1] if "__" in pid else ""


def collect(kb_dir: str, tier: str = "main"):
    rows = []
    for fp in glob.glob(str(Path(kb_dir) / "*.json")):
        if os.path.basename(fp).startswith("_"):
            continue
        d = json.loads(Path(fp).read_text(encoding="utf-8"))
        pid = d.get("paper_id", "")
        for i, t in enumerate(d.get("layered", {}).get("TableRecords") or []):
            if t.get("record_type") != "binary_alloy_parameter":
                continue
            if tier and t.get("_tier") != tier:
                continue
            p = t.get("parameters") or {}
            src = t.get("source") or {}
            rows.append({
                "record_id": f"{pid}#{i}",
                "paper_id": pid, "source_genre": _genre(pid), "part_id": _part(pid),
                "table_id": src.get("table_id") or "", "table_id_raw": src.get("table_id_raw") or "",
                "table_id_norm_confidence": src.get("table_id_norm_confidence"),
                "row_label": src.get("row_label") or "",
                "solvent": t.get("solvent") or "", "solvent_symbol": t.get("solvent_symbol") or "",
                "solute": t.get("solute") or "", "solute_symbol": t.get("solute_symbol") or "",
                "solute_raw": t.get("solute_raw") or "",
                "binary_system": t.get("binary_system") or "",
                **{k: p.get(k) for k in _PARAMS},
                "entity_confidence": t.get("_entity_confidence"), "tier": t.get("_tier"),
                "demotion_reason": t.get("_demotion_reason") or "",
            })
    return rows


def checks(rows):
    rep = {"total": len(rows)}
    # 1 完整性
    incomplete = [r for r in rows if not (r["solvent"] and r["solute"] and
                  r["binary_system"] and r["table_id"] and
                  any(isinstance(r.get(p), (int, float)) for p in _PARAMS))]
    rep["incomplete"] = len(incomplete)
    # 2 去重：同 (binary_system, table_id) 多条 → 冲突
    grp = defaultdict(list)
    for r in rows:
        grp[(r["binary_system"], r["table_id"])].append(r)
    dup_keys = {k: len(v) for k, v in grp.items() if len(v) > 1}
    conflict = 0
    for k, v in grp.items():
        if len(v) > 1:
            for p in _PARAMS:
                vals = {round(x[p], 4) for x in v if isinstance(x.get(p), (int, float))}
                if len(vals) > 1:
                    conflict += 1
                    break
    rep["dup_group_count"] = len(dup_keys)
    rep["conflict_group_count"] = conflict
    # 3 异常值（区分 OCR 列错位信号）
    out = Counter()
    for r in rows:
        rr = r.get("radius_ratio")
        if isinstance(rr, (int, float)) and not (0 < rr <= 5):
            out["radius_ratio_out_of_range"] += 1
        ed = r.get("electronegativity_difference")
        # Pauling 电负性差物理上 ≤ ~3.3；>4 几乎必为列错位/OCR
        if isinstance(ed, (int, float)) and abs(ed) > 4:
            out["electroneg_diff_impossible(>4=列错位)"] += 1
        hf = r.get("hildebrand_factor")
        if isinstance(hf, (int, float)) and hf < 0:
            out["hildebrand_negative"] += 1
        mn = r.get("mott_number")
        if isinstance(mn, (int, float)) and mn > 1000:
            out["mott_gt_1000"] += 1
        # mott<0 不算硬异常（原文确有小负值），单列统计供参考
        if isinstance(mn, (int, float)) and mn < 0:
            out["mott_negative(参考,未必错)"] += 1
    rep["outliers"] = dict(out)
    # 标记建议：列错位/不完整/冲突的记录应在入库时降到 staging
    flagged = sum(1 for r in rows
                  if (isinstance(r.get("electronegativity_difference"), (int, float))
                      and abs(r["electronegativity_difference"]) > 4)
                  or (isinstance(r.get("radius_ratio"), (int, float))
                      and not (0 < r["radius_ratio"] <= 5)))
    rep["recommend_demote_to_staging"] = flagged
    return rep


def main():
    ap = argparse.ArgumentParser(description="导出 main-tier 二元参数库 + 质量检查")
    ap.add_argument("--kb", default=str(_HERE / "kg_v2" / "kb_v2_clean"))
    ap.add_argument("--out", default=str(_HERE / "kg_v2" / "exports"))
    args = ap.parse_args()
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)

    rows = collect(args.kb)
    csv_path = out / "binary_alloy_parameters_main.csv"
    with open(csv_path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=_COLS)
        w.writeheader()
        for r in rows:
            w.writerow(r)
    rep = checks(rows)
    (out / "binary_main_qc.json").write_text(json.dumps(rep, ensure_ascii=False, indent=2), encoding="utf-8")

    print("=" * 56)
    print(f"导出 main-tier 二元参数: {rep['total']} 条 -> {csv_path}")
    print(f"  完整性: 不完整 {rep['incomplete']} 条")
    print(f"  去重  : 重复组 {rep['dup_group_count']}  其中数值冲突组 {rep['conflict_group_count']}")
    print(f"  异常值: {rep['outliers']}")
    print(f"  -> QC: {out / 'binary_main_qc.json'}")
    print("=" * 56)


if __name__ == "__main__":
    main()
