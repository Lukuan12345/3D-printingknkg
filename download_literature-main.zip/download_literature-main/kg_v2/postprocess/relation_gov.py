#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""relation_gov.py —— 关系边治理：谓词归一 + 强因果证据门控 + relation_tier 分层。

全量暴露 450 种 edge type、CAUSES 占语义边 78%（多为经验相关被强因果化）。
本模块（纯规则，不调 LLM）把每条 Relations 三元组规整为：
  - 有限 ontology 的归一谓词（同义合并 RESULTS_IN/LEADS_TO→CAUSES 等）
  - relation_tier ∈ {core, semantic, causal_candidate}
  - 强因果(CAUSES/CONTROLS/DETERMINES/DRIVES/TRIGGERS)无显式因果证据 → 降级 AFFECTS/ASSOCIATED_WITH

查询层据 relation_tier 决定：数值/结构=core，语义检索=core+semantic，
因果推理默认排除 causal_candidate（除非用户明确问机制）。
"""
from __future__ import annotations

import re
from typing import Dict, Tuple

# ── 谓词同义归一（左=各种写法，右=规范谓词）────────────────────────────────
_SYNONYM = {
    # 结构/受控（core）
    "HAS_MEASUREMENT": "HAS_MEASUREMENT", "MEASURES": "HAS_MEASUREMENT",
    "HAS_PROPERTY": "HAS_PROPERTY", "HAS": "HAS_PROPERTY",
    "FOR_MATERIAL": "FOR_MATERIAL", "OF_MATERIAL": "FOR_MATERIAL",
    "UNDER_CONDITION": "UNDER_CONDITION", "AT_CONDITION": "UNDER_CONDITION",
    "FROM_TABLE": "FROM_TABLE", "CITES": "CITES", "ACHIEVES": "ACHIEVES",
    "HAS_REQUIREMENT": "HAS_REQUIREMENT", "EXPLAINS": "EXPLAINS",
    # 语义/相关（semantic）
    "ASSOCIATED_WITH": "ASSOCIATED_WITH", "ASSOCIATES_WITH": "ASSOCIATED_WITH",
    "RELATED_TO": "ASSOCIATED_WITH", "RELATES_TO": "ASSOCIATED_WITH",
    "CORRELATES_WITH": "CORRELATES_WITH", "CORRELATED_WITH": "CORRELATES_WITH",
    "AFFECTS": "AFFECTS", "INFLUENCES": "AFFECTS", "IMPACTS": "AFFECTS",
    "MODULATES": "AFFECTS", "EXHIBITS": "ASSOCIATED_WITH", "SHOWS": "ASSOCIATED_WITH",
    "SHOW": "ASSOCIATED_WITH", "EXHIBIT": "ASSOCIATED_WITH", "FORMS": "ASSOCIATED_WITH",
    "INDICATES": "INDICATES", "PREDICTS": "PREDICTS", "USED_FOR": "USED_FOR",
    "ENABLES": "ENABLES", "ENABLE": "ENABLES", "INHIBITS": "INHIBITS",
    "IMPROVES": "IMPROVES", "REDUCES": "REDUCES", "INCREASES": "AFFECTS",
    "DECREASES": "AFFECTS", "PROMOTES": "AFFECTS", "TRADEOFF_WITH": "TRADEOFF_WITH",
    # 高频材料谓词归并（全量长尾 top）→ 有限 ontology
    "PRODUCES": "PRODUCES", "CREATES": "PRODUCES", "GENERATES": "PRODUCES",
    "FORMS_AT": "PRODUCES", "PRECIPITATES": "PRODUCES",
    "REQUIRES": "REQUIRES", "NEEDS": "REQUIRES", "MUST_SATISFY": "REQUIRES",
    "CHARACTERIZES": "INDICATES", "CHARACTERIZED_BY": "ASSOCIATED_WITH",
    "REVEALS": "INDICATES", "CONFIRMS": "INDICATES", "DEMONSTRATES": "INDICATES",
    "VALIDATES": "INDICATES", "DETECTS": "INDICATES", "MARKS": "INDICATES",
    "ACCELERATES": "AFFECTS", "ENHANCES": "IMPROVES", "STRENGTHENS": "IMPROVES",
    "REFINES": "IMPROVES", "OPTIMIZES": "IMPROVES", "STABILIZES": "IMPROVES",
    "SUPPRESSES": "INHIBITS", "PREVENTS": "INHIBITS", "ELIMINATES": "INHIBITS",
    "RETARDS": "INHIBITS", "BLOCKS": "INHIBITS", "MITIGATES": "REDUCES",
    "LIMITS": "REDUCES", "CONSTRAINS": "REDUCES", "LOWERS": "REDUCES",
    "DELAYS": "INHIBITS", "RESTRICTS": "REDUCES", "WEAKENS": "REDUCES",
    "TRANSFORMS_TO": "TRANSFORMS_TO", "TRANSFORMS": "TRANSFORMS_TO",
    "TRANSFORMS_INTO": "TRANSFORMS_TO", "DECOMPOSES_TO": "TRANSFORMS_TO",
    "DECOMPOSES_INTO": "TRANSFORMS_TO", "CONVERTS_TO": "TRANSFORMS_TO",
    "TRANSITIONS": "TRANSFORMS_TO", "DECOMPOSES": "TRANSFORMS_TO",
    "PRECEDES": "PRECEDES", "FOLLOWS": "PRECEDES", "INITIATES": "PRECEDES",
    "DEFINES": "ASSOCIATED_WITH", "DESCRIBES": "ASSOCIATED_WITH",
    "REPRESENTS": "ASSOCIATED_WITH", "CONTAINS": "ASSOCIATED_WITH",
    "CONSISTS_OF": "ASSOCIATED_WITH", "COMPOSED_OF": "ASSOCIATED_WITH",
    "PROVIDES": "USED_FOR", "USED_FOR": "USED_FOR", "USED_TO": "USED_FOR",
    "SUITABLE_FOR": "USED_FOR", "ACTS_AS": "USED_FOR", "SERVES_AS": "USED_FOR",
    "INCLUDES": "ASSOCIATED_WITH", "OCCURS_IN": "ASSOCIATED_WITH",
    "OCCURS_AT": "ASSOCIATED_WITH", "OCCURS_WHEN": "ASSOCIATED_WITH",
    "CONTRIBUTES_TO": "AFFECTS", "FACILITATES": "ENABLES", "ACTIVATES": "ENABLES",
    "DEPENDS_ON": "ASSOCIATED_WITH", "DETERMINED_BY": "ASSOCIATED_WITH",
    "CONTROLLED_BY": "ASSOCIATED_WITH", "INHIBITED_BY": "ASSOCIATED_WITH",
    # 强因果同义扩充
    "INDUCES": "CAUSES", "GIVES_RISE_TO": "CAUSES", "PRODUCES_VIA": "CAUSES",
    # 强因果（causal_candidate）
    "CAUSES": "CAUSES", "CAUSED_BY": "CAUSES", "RESULTS_IN": "CAUSES",
    "RESULT_IN": "CAUSES", "LEADS_TO": "CAUSES", "LEAD_TO": "CAUSES",
    "CONTROLS": "CONTROLS", "DETERMINES": "DETERMINES", "DRIVES": "DRIVES",
    "TRIGGERS": "TRIGGERS", "GOVERNS": "CONTROLS",
}

_CORE = {"HAS_MEASUREMENT", "HAS_PROPERTY", "FOR_MATERIAL", "UNDER_CONDITION",
         "FROM_TABLE", "CITES", "ACHIEVES", "HAS_REQUIREMENT", "EXPLAINS"}
_SEMANTIC = {"ASSOCIATED_WITH", "CORRELATES_WITH", "AFFECTS", "INDICATES",
             "PREDICTS", "USED_FOR", "ENABLES", "INHIBITS", "IMPROVES",
             "REDUCES", "TRADEOFF_WITH", "PRODUCES", "REQUIRES",
             "TRANSFORMS_TO", "PRECEDES"}
_CAUSAL = {"CAUSES", "CONTROLS", "DETERMINES", "DRIVES", "TRIGGERS"}

# 显式因果证据线索（有→保留强因果；无→降级）
_CAUSAL_CUE = re.compile(
    r"caused by|results? from|results? in|due to|leads? to|gives? rise|responsible for|"
    r"because|owing to|attributed to|triggers?|induces?|mechanism|"
    r"导致|引起|归因|由于|因为|造成|使得|从而", re.I)
# 降级目标
_DOWNGRADE = {"CAUSES": "AFFECTS", "DRIVES": "AFFECTS", "TRIGGERS": "AFFECTS",
              "CONTROLS": "ASSOCIATED_WITH", "DETERMINES": "ASSOCIATED_WITH"}


def normalize_predicate(rel: str) -> str:
    r = re.sub(r"\s+", "_", (rel or "").strip().upper())
    r = re.sub(r"[^A-Z_]", "", r)
    return _SYNONYM.get(r, r)


def govern_relation(rel: dict) -> dict:
    """归一谓词 + 评定 relation_tier + 无证据强因果降级。返回新 dict。"""
    out = dict(rel)
    raw = out.get("relation") or ""
    pred = normalize_predicate(raw)
    ev = str(out.get("evidence") or "")
    conf = (out.get("confidence") or "").lower()

    if pred in _CAUSAL:
        has_cue = bool(_CAUSAL_CUE.search(ev))
        if not has_cue or conf == "low":
            # 无显式因果线索 → 降级为语义边
            newp = _DOWNGRADE.get(pred, "ASSOCIATED_WITH")
            out["_relation_original"] = raw
            out["relation"] = newp
            out["relation_tier"] = "semantic"
            out["_downgraded"] = True
            return out
        # 有证据 → 保留，但标 causal_candidate（默认不参与自动因果推理）
        out["relation"] = pred
        out["relation_tier"] = "causal_candidate"
        return out

    out["relation"] = pred
    if pred in _CORE:
        out["relation_tier"] = "core"
    elif pred in _SEMANTIC:
        out["relation_tier"] = "semantic"
    else:
        out["relation_tier"] = "semantic"   # 未知谓词归 semantic（不进 core，不当因果）
    return out


def tier_of(predicate: str) -> str:
    p = normalize_predicate(predicate)
    if p in _CORE:
        return "core"
    if p in _CAUSAL:
        return "causal_candidate"
    return "semantic"
