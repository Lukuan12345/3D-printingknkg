#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""build_kg_v2.py —— kg_v2 一键编排：P1 → P2 → P3 → P4。

P1 两层 Schema  -> layered_schema.json
P2 单调用抽取   -> kb_v2/<paper_id>.json   (Haiku)
P3 图谱组装     -> graph_out/graph_v2.json + STATS.md
P4 落库切换     -> scientific_kgqa/artifacts/general_alloy_v2/kgqa.db

每步走子进程（与 build_kb_kg.py 同风格，隔离、可单步重跑）。

用法:
    python -m kg_v2.build_kg_v2 \
        --domain C:/.../refined_schema_general_alloy.csv \
        --content-store scientific_kgqa/data/content_store \
        [--limit 20] [--concurrency 8] [--skip-extract] [--skip-db]
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

_HERE = Path(__file__).resolve().parent           # gen_key/kg_v2
_ROOT = _HERE.parent                              # gen_key/
_META = _HERE / "meta_schema"


def _run(step: str, args: list[str]) -> None:
    print(f"\n{'='*64}\n[kg_v2] {step}\n{'='*64}")
    r = subprocess.run([sys.executable, "-m", *args], cwd=str(_ROOT))
    if r.returncode != 0:
        raise SystemExit(f"[kg_v2] step failed: {step} (rc={r.returncode})")


def main():
    ap = argparse.ArgumentParser(description="kg_v2 一键编排 P1→P2→P3→P4")
    ap.add_argument("--domain", required=True, help="refined_schema_*.csv (schema_gen 产出)")
    ap.add_argument("--content-store", default=str(_ROOT / "scientific_kgqa" / "data" / "content_store"))
    ap.add_argument("--layered", default=str(_META / "layered_schema.json"))
    ap.add_argument("--kb", default=str(_HERE / "kb_v2"))
    ap.add_argument("--kb-clean", default=str(_HERE / "kb_v2_clean"))
    ap.add_argument("--graph-out", default=str(_HERE / "graph_out"))
    ap.add_argument("--db", default=str(_ROOT / "scientific_kgqa" / "artifacts" / "general_alloy_v2" / "kgqa.db"))
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--concurrency", type=int, default=8)
    ap.add_argument("--skip-schema", action="store_true")
    ap.add_argument("--skip-extract", action="store_true")
    ap.add_argument("--skip-clean", action="store_true")
    ap.add_argument("--skip-graph", action="store_true")
    ap.add_argument("--skip-db", action="store_true")
    args = ap.parse_args()

    if not args.skip_schema:
        _run("P1 两层 Schema", ["kg_v2.schema.build_layered_schema",
                               "--domain", args.domain, "--out", args.layered])
    if not args.skip_extract:
        _run("P2 单调用抽取(Haiku)", ["kg_v2.extract.run_extract_v2",
                                  "--layered", args.layered, "--content-store", args.content_store,
                                  "--out", args.kb, "--limit", str(args.limit),
                                  "--concurrency", str(args.concurrency)])
    kb_for_graph = args.kb
    if not args.skip_clean:
        _run("P2.5 后处理清洗", ["kg_v2.postprocess.clean_record",
                              "--kb", args.kb, "--out", args.kb_clean,
                              "--content-store", args.content_store])
        kb_for_graph = args.kb_clean
    if not args.skip_graph:
        _run("P3 图谱组装", ["kg_v2.graph.build_graph_v2",
                          "--kb", kb_for_graph, "--layered", args.layered, "--out", args.graph_out])
        # 分类型诊断报告（审查 §5）：全量后据此定位系统性问题
        _run("P3.5 分类型诊断", ["kg_v2.postprocess.stats_report",
                            "--kb", kb_for_graph, "--out", args.graph_out])
    if not args.skip_db:
        _run("P4 落库 scientific_kgqa", ["kg_v2.graph.to_scientific_kgqa",
                                       "--graph", str(Path(args.graph_out) / "graph_v2.json"),
                                       "--db", args.db])
    print("\n[kg_v2] 全流程完成。图: %s/graph_v2.json  库: %s" % (args.graph_out, args.db))


if __name__ == "__main__":
    main()
