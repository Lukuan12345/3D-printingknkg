#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""qa_source_audit.py —— 二元参数记录「源行结构完整性」审计（可信、可全量）。

为什么不是「抽取对源的忠实度」核对：binary_alloy_parameter 全部来自 deterministic_html
解析器，full.md 就是该解析器的输入；重解析只会复现输出，不存在独立 ground truth。
真正能脱离原书、可信判定的是 **源 HTML 行本身的结构是否完好**：
  解析器按 cell 位置把值映射到固定 5 列（radius/energy/mott/hildebrand/eneg_diff）。
  若某行不是「干净的 5 个数值 cell」（空 cell / 合并多值 / 列数≠5），该记录就会
  缺值或整行列错位——这正是人工抽查发现的三大失效模式（拆行丢值/列错位/单元格合并）。

本脚本用解析器自身的 helper 重跑每个 part（record_id 的 idx 与 kb 精确对齐，已验证），
捕获每条记录源行被丢弃的原始 cell，给每条 binary 记录打结构标签：
  clean5      : 标签后正好 5 个 cell 且 5 个都干净数值        → 结构无缺陷（仍可能有纯 OCR 数字误识，需人对原书）
  blank_merged: 5 个 cell 但 <5 个干净数值（空/合并/含字母）  → 缺值或合并，高风险
  shifted     : 值 cell 数 ≠ 5（行错位）                      → 列错位，高风险
  notfound    : 该 idx 重解析不到（极少）                     → 需人工

按 _tier 交叉统计，验证 main 层是否已挡住坏行；并对 main 层给出
「结构无缺陷率」= 可自动确认的准确率下界。

用法:
  python -m kg_v2.release.qa_source_audit --kb kg_v2/kb_v2_clean --out kg_v2/exports/source_audit.csv
"""
from __future__ import annotations

import argparse
import csv
import glob
import json
import os
import re
from collections import Counter, defaultdict
from pathlib import Path

from kg_v2.extract.table_extract import (
    _TABLE_RE, _TR_RE, _cells, _clean_num, _canon_col,
    _resolve_columns, classify_table,
)
try:
    from kg_v2.extract.elements import normalize_element
except ImportError:
    normalize_element = lambda s: None  # noqa

_ROOT = Path(__file__).resolve().parents[2]
_CS = _ROOT / "scientific_kgqa" / "data" / "content_store"
_PARAMS = ["radius_ratio", "energy_ratio", "mott_number",
           "hildebrand_factor", "electronegativity_difference"]


def audit_rows(md: str):
    """镜像 extract_tables 的行循环，但对每个产出记录额外捕获源行结构。
    返回与 extract_tables 同序的列表，元素 = {row_label, n_val_cells, n_clean, klass, raw_cells}。
    仅在 record_type==binary_alloy_parameter 时打结构标签（与导出口径一致）。"""
    out = []
    for tm in _TABLE_RE.finditer(md):
        body = tm.group(1)
        rows = [_cells(tr) for tr in _TR_RE.findall(body)]
        rows = [r for r in rows if r]
        if len(rows) < 2:
            continue
        header = None
        data_start = 0
        for i, r in enumerate(rows[:4]):
            alpha = sum(1 for c in r if re.search(r"[A-Za-z]", c))
            num = sum(1 for c in r if re.search(r"^\s*[:.]?\d", c))
            if alpha >= 2 and num == 0:
                header = r
                data_start = i + 1
                break
        raw_cols = [_canon_col(c) for c in header[1:]] if header else []
        # 镜像 table_extract 修复：widths 按非空 cell 计数
        widths = [len([c for c in r[1:] if c.strip() != ""]) for r in rows[data_start:] if len(r) >= 2]
        n_val = max(set(widths), key=widths.count) if widths else len(raw_cols)
        col_names = _resolve_columns(raw_cols, n_val)
        solute_samples = [r[0].strip() for r in rows[data_start:data_start + 12] if r and r[0].strip()]
        rec_type = classify_table(col_names, solute_samples)

        for r in rows[data_start:]:
            if len(r) < 2:
                continue
            solute_raw = r[0].strip()
            vals = r[1:]
            if not solute_raw or not any(re.search(r"\d", v) for v in vals):
                continue
            # 镜像 table_extract 修复：行内剔空 cell 压实
            if len(vals) != n_val:
                nonempty = [v for v in vals if v.strip() != ""]
                if len(nonempty) == n_val and all(_clean_num(v)[0] is not None for v in nonempty):
                    vals = nonempty
            params = {}
            for idx, v in enumerate(vals):
                col = col_names[idx] if idx < len(col_names) else f"col_{idx+1}"
                num, raw = _clean_num(v)
                params[col] = num if num is not None else (raw or None)
            params = {k: v for k, v in params.items() if v is not None and v != ""}
            if not params:
                continue
            # 与 extract_tables 一致：到此才会 append 一条记录
            n_val_cells = len(vals)
            n_clean = sum(1 for v in vals if _clean_num(v)[0] is not None)
            if rec_type == "binary_alloy_parameter":
                if n_val_cells == 5 and n_clean == 5:
                    klass = "clean5"
                elif n_val_cells == 5:
                    klass = "blank_merged"
                else:
                    klass = "shifted"
            else:
                klass = "non_binary"
            out.append({"rec_type": rec_type, "row_label": solute_raw,
                        "n_val_cells": n_val_cells, "n_clean": n_clean,
                        "klass": klass, "raw_cells": vals})
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--kb", default=str(_ROOT / "kg_v2" / "kb_v2_clean"))
    ap.add_argument("--out", default=str(_ROOT / "kg_v2" / "exports" / "source_audit.csv"))
    args = ap.parse_args()

    # tier x klass 交叉统计（仅 binary）
    cross = defaultdict(Counter)
    main_klass = Counter()
    detail_rows = []
    n_idx_mismatch = 0

    for fp in sorted(glob.glob(str(Path(args.kb) / "*.json"))):
        if os.path.basename(fp).startswith("_"):
            continue
        pid = os.path.basename(fp)[:-5]
        d = json.loads(Path(fp).read_text(encoding="utf-8"))
        recs = d.get("layered", {}).get("TableRecords") or []
        md_fp = _CS / pid / "full.md"
        if not md_fp.exists():
            continue
        audit = audit_rows(md_fp.read_text(encoding="utf-8", errors="ignore"))

        for i, t in enumerate(recs):
            if t.get("record_type") != "binary_alloy_parameter":
                continue
            tier = t.get("_tier") or "?"
            a = audit[i] if i < len(audit) else None
            if a is None or a["rec_type"] != "binary_alloy_parameter":
                # idx 不对齐（理论上不应发生）→ 结构标签兜底用 kb 自身参数数
                n_clean = sum(1 for k in _PARAMS if isinstance(t.get("parameters", {}).get(k), (int, float)))
                klass = "clean5" if n_clean == 5 else ("notfound_reparse")
                n_idx_mismatch += 1
                a = {"klass": klass, "n_val_cells": "", "n_clean": n_clean, "raw_cells": ""}
            cross[tier][a["klass"]] += 1
            if tier == "main":
                main_klass[a["klass"]] += 1
                detail_rows.append({
                    "record_id": f"{pid}#{i}", "tier": tier, "klass": a["klass"],
                    "n_val_cells": a["n_val_cells"], "n_clean": a["n_clean"],
                    "solvent": t.get("solvent"), "solute": t.get("solute"),
                    "row_label": t.get("row_label"),
                    "raw_cells": " | ".join(a["raw_cells"]) if isinstance(a["raw_cells"], list) else "",
                    **{p: t.get("parameters", {}).get(p) for p in _PARAMS},
                })

    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    if detail_rows:
        with open(args.out, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(detail_rows[0].keys()))
            w.writeheader()
            w.writerows(detail_rows)

    print("=" * 64)
    print("源行结构审计（binary_alloy_parameter，全量）")
    print("tier x 结构类别：")
    for tier in ("main", "staging", "reject", "?"):
        if cross.get(tier):
            tot = sum(cross[tier].values())
            print(f"  {tier:8s} n={tot:5d}  {dict(cross[tier])}")
    mtot = sum(main_klass.values())
    clean = main_klass.get("clean5", 0)
    print("-" * 64)
    print(f"MAIN 层结构无缺陷率(clean5/total) = {clean}/{mtot} = {clean/mtot*100:.1f}%")
    print(f"  需重点人工核对(blank_merged+shifted) = "
          f"{main_klass.get('blank_merged',0)+main_klass.get('shifted',0)} 条")
    if n_idx_mismatch:
        print(f"  [注] idx 重解析不齐 {n_idx_mismatch} 条（已兜底）")
    print(f"  明细 -> {args.out}")
    print("=" * 64)


if __name__ == "__main__":
    main()
