"""kg_v2.release —— v1 冻结归档。"""
