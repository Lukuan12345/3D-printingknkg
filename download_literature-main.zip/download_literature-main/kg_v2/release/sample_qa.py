#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""sample_qa.py —— main-tier 二元参数事实 QA 抽样核对表（审查§3）。

从 main-tier binary 记录分层抽样，生成可人工核对的 CSV：
  分层：主来源(Compilation等)多抽，其他来源、可疑table_id、低entity_confidence各抽若干。
  每行带：record_id / 源文件 part / table_id(raw+norm) / row_label / binary_system / 各参数 /
          一个空白 "verdict" 列(correct/wrong/unsure) + "note" 列，供你对照原书表格逐行打勾。

用法: python -m kg_v2.release.sample_qa --csv kg_v2/exports/binary_alloy_parameters_main.csv --n 150 --out kg_v2/exports/qa_sample.csv
确定性抽样(无随机种子依赖)：按 record_id 哈希排序取样，可复现。
"""
from __future__ import annotations

import argparse
import csv
import hashlib
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[2]


def _h(s: str) -> int:
    return int(hashlib.sha1(s.encode("utf-8")).hexdigest()[:8], 16)


def stratified(rows, n: int):
    """分层抽样。main binary 实际全来自同一本参数汇编，故按 table_id 桶 + 可疑记录分层，
    保证覆盖多个不同 table（而非集中在少数表）+ 优先纳入可疑记录。"""
    from collections import defaultdict
    # 可疑：table_id 归一置信<1 或 entity_confidence<0.95
    susp = [r for r in rows
            if (str(r.get("table_id_norm_confidence") or "1") not in ("", "1", "1.0"))
            or (_f(r.get("entity_confidence")) is not None and _f(r["entity_confidence"]) < 0.95)]
    n_susp = min(len(susp), n // 4)              # ~1/4 配额给可疑记录
    picked, seen = [], set()
    for r in sorted(susp, key=lambda r: _h(r.get("record_id", "")))[:n_susp]:
        seen.add(r["record_id"]); picked.append(r)
    # 其余按 table_id 分桶轮询取样，保证表覆盖广度
    by_tab = defaultdict(list)
    for r in rows:
        if r["record_id"] not in seen:
            by_tab[r.get("table_id", "")].append(r)
    for k in by_tab:
        by_tab[k].sort(key=lambda r: _h(r.get("record_id", "")))
    tabs = sorted(by_tab, key=lambda k: _h(k))
    idx = 0
    while len(picked) < n and any(by_tab.values()):
        k = tabs[idx % len(tabs)]
        if by_tab[k]:
            picked.append(by_tab[k].pop(0))
        idx += 1
        if idx > n * 50:  # 安全阀
            break
    return picked[:n]


def _f(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


_QA_COLS = ["overall_verdict(correct/wrong/unsure)",
            "table_id_ok", "solvent_ok", "solute_ok", "binary_system_ok",
            "params_columns_ok", "values_ocr_ok", "error_type", "note",
            "record_id", "source_genre", "part_id", "table_id", "table_id_raw",
            "row_label", "binary_system", "solvent", "solute",
            "radius_ratio", "energy_ratio", "mott_number",
            "hildebrand_factor", "electronegativity_difference", "entity_confidence"]

# error_type 受控词表（写在表头注释行，供人工填写参考）
_ERROR_TYPES = ("table_id_wrong | solvent_wrong | solute_wrong | binary_system_wrong | "
                "column_shift | value_ocr_error | missing_value | extra_value | "
                "row_misaligned | source_unclear")


def _write(path, sample, mode_label):
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=_QA_COLS, extrasaction="ignore")
        w.writeheader()
        for r in sample:
            r2 = dict(r)
            for c in ("overall_verdict(correct/wrong/unsure)", "table_id_ok", "solvent_ok",
                      "solute_ok", "binary_system_ok", "params_columns_ok", "values_ocr_ok",
                      "error_type", "note"):
                r2[c] = ""
            w.writerow(r2)


def main():
    ap = argparse.ArgumentParser(description="生成 main-tier 事实 QA 核对表(random+suspicious 两份)")
    ap.add_argument("--csv", default=str(_ROOT / "kg_v2/exports/binary_alloy_parameters_main.csv"))
    ap.add_argument("--n-random", type=int, default=100, help="无偏 random-main 抽样数(估准确率)")
    ap.add_argument("--n-suspicious", type=int, default=50, help="可疑(OCR归一/低置信)压力测试数")
    ap.add_argument("--outdir", default=str(_ROOT / "kg_v2/exports"))
    args = ap.parse_args()

    rows = list(csv.DictReader(open(args.csv, encoding="utf-8-sig")))
    out = Path(args.outdir); out.mkdir(parents=True, exist_ok=True)

    # 1) 无偏 random-main：纯哈希排序取前 N（可复现，不偏向可疑）
    rnd = sorted(rows, key=lambda r: _h(r.get("record_id", "")))[: args.n_random]
    _write(out / "qa_random_main.csv", rnd, "random")

    # 2) suspicious：table_id 归一过(raw≠norm) 或 entity_confidence<0.95 或 mott 极端
    susp = [r for r in rows
            if (r.get("table_id_raw") and r.get("table_id_raw") != r.get("table_id"))
            or (_f(r.get("entity_confidence")) is not None and _f(r["entity_confidence"]) < 0.95)
            or (_f(r.get("mott_number")) is not None and (_f(r["mott_number"]) < 0 or _f(r["mott_number"]) > 1000))]
    susp = sorted(susp, key=lambda r: _h(r.get("record_id", "")))[: args.n_suspicious]
    _write(out / "qa_suspicious.csv", susp, "suspicious")

    print("=" * 60)
    print(f"QA 抽样生成（两份）:")
    print(f"  无偏 random-main : {len(rnd)} 条 -> qa_random_main.csv  （用于估全库准确率）")
    print(f"  可疑压力测试     : {len(susp)} 条 -> qa_suspicious.csv   （OCR/table_id/列错位/mott极端）")
    print(f"  error_type 可选值: {_ERROR_TYPES}")
    print("  填法: overall_verdict + 各子项 ok(y/n) + error_type；对照 content_store/<part_id>/full.md 的 table_id 表")
    print("  判定: strict_accuracy = correct/(correct+wrong); unsure 不算 correct; random≥95% → 发 v1")
    print("=" * 60)


if __name__ == "__main__":
    main()
