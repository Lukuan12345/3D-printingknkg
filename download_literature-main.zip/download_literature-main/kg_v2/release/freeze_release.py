#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""freeze_release.py —— 冻结当前全量版本为可复现 v1 baseline（审查§D）。

把这一版的代码状态 + schema + 全部产物 + 统计快照归档到 runs/<release>/，
并写 RELEASE_NOTE.md。归档后可随时回溯/对比。

用法: python -m kg_v2.release.freeze_release --tag v1
"""
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[2]   # gen_key/


def _git(*args):
    try:
        return subprocess.run(["git", *args], cwd=str(_ROOT),
                              capture_output=True, text=True, timeout=30,
                              encoding="utf-8", errors="replace").stdout.strip()
    except Exception:
        return ""


def _count_main(graph_json: Path) -> dict:
    if not graph_json.exists():
        return {}
    g = json.loads(graph_json.read_text(encoding="utf-8"))
    from collections import Counter
    nt = Counter(n["type"] for n in g["nodes"])
    et = Counter(l["relation"] for l in g["links"])
    binrec = [n for n in g["nodes"] if n["type"] == "BinaryRecord"]
    tiers = Counter(n["attrs"].get("tier") for n in binrec)
    return {"nodes": len(g["nodes"]), "links": len(g["links"]),
            "node_types": dict(nt.most_common(15)),
            "binary_tier": dict(tiers),
            "strong_causal": sum(et[k] for k in ("CAUSES", "CONTROLS", "DETERMINES", "DRIVES", "TRIGGERS")),
            "edge_type_count": len(et)}


def main():
    ap = argparse.ArgumentParser(description="冻结全量版本为 v1 baseline")
    ap.add_argument("--tag", default="v1")
    ap.add_argument("--domain", default=str(_ROOT / "schema_output/general_alloy/refined_schema_general_alloy.csv"))
    ap.add_argument("--no-copy-db", action="store_true", help="DB 很大(300MB+)，加此项只记录路径不拷贝")
    args = ap.parse_args()

    # release id：tag + git short hash（避免 Date.now 不可用，用 git 描述）
    short = _git("rev-parse", "--short", "HEAD") or "nogit"
    rel = f"kg_v2_full_1547_{args.tag}_{short}"
    dst = _ROOT / "runs" / rel
    dst.mkdir(parents=True, exist_ok=True)

    go = _ROOT / "kg_v2" / "graph_out"
    stats = _count_main(go / "graph_v2.json")

    # 1) 代码状态
    (dst / "git_commit.txt").write_text(short + "\n" + _git("log", "-1", "--oneline"), encoding="utf-8")
    diff = _git("diff", "HEAD")
    if diff:
        (dst / "uncommitted_diff.patch").write_text(diff, encoding="utf-8")

    # 2) schema + 统计产物
    for src in [Path(args.domain), go / "STATS.md", go / "STATS_FULL.md",
                go / "stats_full.json", _ROOT / "kg_v2/exports/binary_alloy_parameters_main.csv",
                _ROOT / "kg_v2/exports/binary_main_qc.json",
                _ROOT / "kg_v2/meta_schema/layered_schema.json"]:
        if src.exists():
            shutil.copy2(src, dst / src.name)

    # 3) DB 路径（默认不拷大文件）
    db = _ROOT / "scientific_kgqa/artifacts/general_alloy_v2/kgqa.db"
    if db.exists() and not args.no_copy_db:
        try:
            shutil.copy2(db, dst / "kgqa.db")
            db_note = f"copied ({db.stat().st_size//1048576} MB)"
        except Exception as e:
            db_note = f"copy failed: {e}; path={db}"
    else:
        db_note = f"not copied; path={db}"

    # 4) RELEASE_NOTE
    note = [f"# Release {rel}", "",
            f"- git: {short}  ({_git('log','-1','--oneline')})",
            f"- papers: 1547",
            f"- graph nodes: {stats.get('nodes')}  links: {stats.get('links')}",
            f"- edge_type_count: {stats.get('edge_type_count')}  strong_causal: {stats.get('strong_causal')}",
            f"- BinaryRecord tier: {stats.get('binary_tier')}",
            f"- node_types(top): {stats.get('node_types')}",
            f"- db: {db_note}", "",
            "## 关键能力",
            "- 两层Schema(Meta12模块×领域) / 四类语义节点 / Observation Pattern / 引用层 / 机理因果链",
            "- TableRecords tier门控(main/staging/reject) + 确定性HTML表格解析(878行/页)",
            "- 关系治理: CAUSES 56249→976, causal_chain→NEXT_STEP, relation_tier(core/semantic/causal_candidate)",
            "- main-tier二元参数库: 列错位修复(尾随空cell击穿固定5列) + main硬门(n_canon==5) 后 "
            "3298条, 源行结构无缺陷率100%(3297/3298), shifted 581→1, blank_merged→0",
            "", "## 入库分层",
            "- main: 高置信数值库, 结构100%完好; 残余风险=23张表solvent绑定(待人工重绑) + clean5个位OCR(待对原书核60条)",
            "- staging: 语义检索+待审",
            "- reject: 仅审计",
            "- 关系: 查询走 core+semantic, 因果默认排除 causal_candidate"]
    (dst / "RELEASE_NOTE.md").write_text("\n".join(note), encoding="utf-8")

    print("=" * 56)
    print(f"冻结完成 -> {dst}")
    for f in sorted(dst.iterdir()):
        print(f"  {f.name}  ({f.stat().st_size} B)")
    print("=" * 56)
    print("\n".join(note[:9]))


if __name__ == "__main__":
    main()
