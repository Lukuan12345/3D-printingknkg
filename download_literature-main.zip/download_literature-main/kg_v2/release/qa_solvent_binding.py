#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""qa_solvent_binding.py —— solvent 绑定专项检查（结构审计的盲区补充）。

table_extract 用 `_nearest_before` 把「最近一个 SOLVENT-xxx 头」绑给每张表。
若某个 solvent 头被 OCR 漏识别，整张表会**继承上一个 solvent**（#587 类），
其所有行的 solvent / binary_system 都错。结构审计抓不到（行本身结构完好）。

可检信号：参数汇编表按固定 solute 顺序排列（HYDROGEN, LITHIUM, ... 或 CESIUM, ...）。
正常情况下每张 SOLVENT-X 表的 solvent 互不相同且连续递进；若**连续两张表 solvent 相同**，
则第二张多半是漏识别 caption（实际是另一种 solvent）或重复表 → 列为 suspect。

输出：每个 part 的表序列（solvent / 行数 / 首末 solute / idx 范围）+ suspect 标记 + 受影响 record_id。
冲突组三角化结论也一并打印（同 solvent 冲突 = 本问题主体）。

用法:
  python -m kg_v2.release.qa_solvent_binding --kb kg_v2/kb_v2_clean --out kg_v2/exports/solvent_binding_suspects.csv
"""
from __future__ import annotations

import argparse
import csv
import glob
import json
import os
import re
from collections import Counter
from pathlib import Path

from kg_v2.extract.table_extract import (
    _TABLE_RE, _TR_RE, _cells, _SOLVENT_HDR,
)

_ROOT = Path(__file__).resolve().parents[2]
_CS = _ROOT / "scientific_kgqa" / "data" / "content_store"


def tables_with_solvent(md: str):
    """按文档顺序返回每张表 (solvent_caption, [solute_first_cells...])。
    复用 table_extract 的 solvent 头正则与 _nearest_before 同语义。"""
    marks = [(m.start(), re.sub(r"\s+", " ", m.group(1)).strip().title())
             for m in _SOLVENT_HDR.finditer(md)]

    def nearest(pos):
        best = ""
        for off, val in marks:
            if off <= pos:
                best = val
            else:
                break
        return best

    out = []
    for tm in _TABLE_RE.finditer(md):
        rows = [_cells(tr) for tr in _TR_RE.findall(tm.group(1))]
        rows = [r for r in rows if r]
        if len(rows) < 2:
            continue
        solutes = [r[0].strip() for r in rows if r and r[0].strip()
                   and re.search(r"[A-Za-z]", r[0])]
        out.append({"solvent": nearest(tm.start()), "n_solute": len(solutes),
                    "first": solutes[1] if len(solutes) > 1 else (solutes[0] if solutes else ""),
                    "last": solutes[-1] if solutes else ""})
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--kb", default=str(_ROOT / "kg_v2" / "kb_v2_clean"))
    ap.add_argument("--out", default=str(_ROOT / "kg_v2" / "exports" / "solvent_binding_suspects.csv"))
    args = ap.parse_args()

    suspect_rows = []
    n_tables = 0
    n_suspect = 0
    for fp in sorted(glob.glob(str(Path(args.kb) / "*.json"))):
        if os.path.basename(fp).startswith("_"):
            continue
        pid = os.path.basename(fp)[:-5]
        md_fp = _CS / pid / "full.md"
        if not md_fp.exists():
            continue
        tabs = tables_with_solvent(md_fp.read_text(encoding="utf-8", errors="ignore"))
        prev = None
        for i, t in enumerate(tabs):
            n_tables += 1
            sv = t["solvent"]
            # 这些汇编表每个 solvent 分两段：轻半段(HYDROGEN 起) + 重半段(CESIUM/BARIUM 起)，
            # 共用一个 caption。故「连续同 solvent 且第二张从 CESIUM/BARIUM 起」= 正常重半段，非错绑。
            # 仅当第二张**从 HYDROGEN 重新起头**(= 第二个轻半段)才是真·漏 caption：
            # 本该是另一种 solvent 的新表，却继承了上一个 solvent。
            first_n = re.sub(r"[^A-Z]", "", (t["first"] or "").upper()).replace("HYOR", "HYDR")
            is_restart = first_n.startswith("HYDROGEN") or first_n in ("LITHIUM", "HELIUM")
            if prev is not None and sv and sv == prev and t["n_solute"] >= 5 and is_restart:
                n_suspect += 1
                suspect_rows.append({
                    "part_id": pid, "table_seq": i, "solvent_repeated": sv,
                    "n_solute": t["n_solute"], "first_solute": t["first"],
                    "last_solute": t["last"],
                    "hint": "连续同 solvent 且从 HYDROGEN 重排 → 疑似漏识别 caption(实为另一 solvent)",
                })
            prev = sv

    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    if suspect_rows:
        with open(args.out, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(suspect_rows[0].keys()))
            w.writeheader()
            w.writerows(suspect_rows)

    by_part = Counter(r["part_id"].split("__")[-1] for r in suspect_rows)
    print("=" * 64)
    print("solvent 绑定专项检查")
    print(f"  扫描表数: {n_tables}")
    print(f"  suspect(连续同 solvent 的多行表): {n_suspect}")
    print(f"  分布(top 部件): {dict(by_part.most_common(10))}")
    print(f"  明细 -> {args.out}")
    print("  说明: suspect 表的所有 binary 记录 solvent 可能错绑，需对照 full.md 人工确认")
    print("=" * 64)


if __name__ == "__main__":
    main()
