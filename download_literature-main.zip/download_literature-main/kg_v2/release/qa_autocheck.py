#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""qa_autocheck.py —— 自动核对 main-tier 二元参数 QA 表（填 verdict 列 + 出指标）。

思路：每条记录的来源是 deterministic_html 解析的 HTML 表。对每条 QA 记录：
  1. 由 record_id -> 该 part 的 kb_v2_clean JSON 取 TableRecords[idx]，拿到 table_caption / row_label / 5个值；
  2. 解析该 part 的 content_store/<part>/full.md 为「按文档顺序的 HTML 表」列表，
     每张表带最近的前置 caption（SOLVENT-xxx）；
  3. 在 caption 与记录 solvent 匹配的表里，按 row_label 定位行，比对 5 个数值并检测行是否完好。

判定逐项写入：solvent_ok / solute_ok / params_columns_ok / values_ocr_ok / error_type / note，
并汇总 overall_verdict(correct/wrong/unsure)。这是「抽取对源 HTML 的忠实度」核对（非对原书的科学正确性）。

用法:
  python -m kg_v2.release.qa_autocheck --qa kg_v2/exports/qa_random_main.csv --out kg_v2/exports/qa_random_main.checked.csv
  python -m kg_v2.release.qa_autocheck --qa kg_v2/exports/qa_suspicious.csv  --out kg_v2/exports/qa_suspicious.checked.csv
"""
from __future__ import annotations

import argparse
import csv
import json
import re
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[2]
_CS = _ROOT / "scientific_kgqa" / "data" / "content_store"
_KB = _ROOT / "kg_v2" / "kb_v2_clean"
_PARAMS = ["radius_ratio", "energy_ratio", "mott_number",
           "hildebrand_factor", "electronegativity_difference"]

_TD = re.compile(r"<td[^>]*>(.*?)</td>", re.S | re.I)
_TR = re.compile(r"<tr[^>]*>(.*?)</tr>", re.S | re.I)
_TABLE = re.compile(r"<table[^>]*>(.*?)</table>", re.S | re.I)


def _norm(s: str) -> str:
    """归一化用于实体/标题匹配：大写、去非字母数字。"""
    return re.sub(r"[^A-Z0-9]", "", (s or "").upper())


# OCR 常见数字误识修正：O/o->0, l/I->1, S/s->5(谨慎), 全角点、逗号、尾随点、空格
_NUMFIX = str.maketrans({"O": "0", "o": "0", "l": "1", "I": "1",
                         "C": "0", "c": "0", "．": ".", "，": "", ",": "",
                         "：": "", "'": "", "’": "", "·": "", " ": ""})


def _floats(cell: str):
    """从一个 cell 文本里提取所有数值 token（一个 cell 可能 OCR 合并了多个值）。"""
    out = []
    # 先把 cell 内多值按空白拆开
    for tok in re.split(r"\s+", (cell or "").strip()):
        if not tok:
            continue
        t = tok.translate(_NUMFIX).strip(".")
        # 处理形如 '0.1s01' 残留字母 -> 跳过非数值
        m = re.fullmatch(r"-?\d+(?:\.\d+)?", t)
        if m:
            out.append(float(t))
    return out


def _row_floats(cells):
    """把一行除首列(label)外所有 cell 的数值 token 平铺。"""
    vals = []
    for c in cells[1:]:
        vals.extend(_floats(c))
    return vals


def parse_tables(md: str):
    """解析 full.md -> [(caption_norm, caption_raw, [ (label_raw, [cells...]) ... ]), ...] 按文档顺序。"""
    tables = []
    pos = 0
    for m in _TABLE.finditer(md):
        pre = md[pos:m.start()]
        pos = m.end()
        # 该表前置文本里最后一个含 SOLVENT 的行作 caption
        cap = ""
        for line in pre.splitlines():
            if "SOLVENT" in line.upper() or "SOLVEN" in line.upper():
                cap = line
        rows = []
        for tr in _TR.finditer(m.group(1)):
            cells = [re.sub(r"<[^>]+>", "", c).strip() for c in _TD.findall(tr.group(1))]
            if cells:
                rows.append((cells[0], cells))
        tables.append((_norm(cap), cap.strip(), rows))
    return tables


def _close(a, b, rtol=0.01, atol=0.01):
    if a is None or b is None:
        return False
    if abs(a - b) <= atol:
        return True
    denom = max(abs(a), abs(b), 1e-9)
    return abs(a - b) / denom <= rtol


def load_kb_record(record_id: str):
    pid, _, idx = record_id.rpartition("#")
    fp = _KB / f"{pid}.json"
    if not fp.exists():
        return None
    d = json.loads(fp.read_text(encoding="utf-8"))
    recs = d.get("layered", {}).get("TableRecords") or []
    try:
        return recs[int(idx)]
    except (ValueError, IndexError):
        return None


def check_one(row: dict):
    """返回填好的 verdict 字段 dict。"""
    res = {"overall_verdict(correct/wrong/unsure)": "", "table_id_ok": "", "solvent_ok": "",
           "solute_ok": "", "binary_system_ok": "", "params_columns_ok": "",
           "values_ocr_ok": "", "error_type": "", "note": ""}
    rid = row["record_id"]
    rec = load_kb_record(rid)
    pid = rid.rpartition("#")[0]
    md_fp = _CS / pid / "full.md"
    if rec is None or not md_fp.exists():
        res["overall_verdict(correct/wrong/unsure)"] = "unsure"
        res["error_type"] = "source_unclear"
        res["note"] = "kb record or full.md missing"
        return res

    caption = (rec.get("source") or {}).get("table_caption") or ""
    row_label = (rec.get("source") or {}).get("row_label") or rec.get("row_label") or ""
    solvent = rec.get("solvent") or ""
    want = [rec.get("parameters", {}).get(p) for p in _PARAMS]

    tables = parse_tables(md_fp.read_text(encoding="utf-8", errors="ignore"))
    cap_n = _norm(caption)
    lab_n = _norm(row_label)

    # 候选表：caption 归一匹配（双向包含），否则退化为全表搜
    cand_tabs = [t for t in tables if cap_n and (cap_n in t[0] or t[0] in cap_n) and t[0]]
    solvent_anchored = bool(cand_tabs)
    if not cand_tabs:
        cand_tabs = tables

    # 在候选表里找 label 匹配的行，挑 5 值最贴近的
    best = None  # (n_match, n_numeric, vals, label_clean)
    for _, _, rows in cand_tabs:
        for lab_raw, cells in rows:
            if not lab_n:
                continue
            # label 作为 token 出现在首列（处理 'CESIUM BARIUM' 合并）
            toks = [_norm(x) for x in re.split(r"\s+", lab_raw)]
            if lab_n not in toks and lab_n != _norm(lab_raw):
                continue
            vals = _row_floats(cells)
            nmatch = sum(1 for w, v in zip(want, vals) if _close(_f(w), v))
            score = (nmatch, -abs(len(vals) - 5))
            if best is None or score > best[0]:
                best = (score, vals, lab_raw, len(cells))

    # ---- 判定 ----
    res["solvent_ok"] = "y" if solvent_anchored else "?"
    if best is None:
        res["solute_ok"] = "n"
        res["overall_verdict(correct/wrong/unsure)"] = "unsure"
        res["error_type"] = "source_unclear"
        res["note"] = f"row_label '{row_label}' not found under solvent '{solvent}'"
        return res

    _, vals, lab_raw, ncells = best
    res["solute_ok"] = "y"
    nmatch = sum(1 for w, v in zip(want, vals) if _close(_f(w), v))
    n_want = sum(1 for w in want if _f(w) is not None)

    well_formed = (len(vals) == 5)
    res["params_columns_ok"] = "y" if well_formed else "n"

    if nmatch == n_want and well_formed and len(vals) == 5:
        res["values_ocr_ok"] = "y"
        res["overall_verdict(correct/wrong/unsure)"] = "correct"
        res["binary_system_ok"] = "y"
        res["table_id_ok"] = "y" if solvent_anchored else "?"
    else:
        res["values_ocr_ok"] = "n" if nmatch < n_want else "y"
        # 错误类型判定
        if not well_formed and len(vals) < 5:
            res["error_type"] = "missing_value|row_misaligned"
        elif not well_formed and len(vals) > 5:
            res["error_type"] = "column_shift|extra_value"
        elif nmatch < n_want:
            res["error_type"] = "value_ocr_error|column_shift"
        res["overall_verdict(correct/wrong/unsure)"] = "wrong" if nmatch < n_want else "unsure"
        res["note"] = (f"matched src row '{lab_raw}' cells={ncells} numeric={len(vals)} "
                       f"matched {nmatch}/{n_want}; src_vals={vals} kb_vals={want}")
    return res


def _f(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def main():
    ap = argparse.ArgumentParser(description="自动核对 QA 表并填 verdict 列")
    ap.add_argument("--qa", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    rows = list(csv.DictReader(open(args.qa, encoding="utf-8-sig")))
    fields = list(rows[0].keys()) if rows else []
    n = {"correct": 0, "wrong": 0, "unsure": 0}
    et = {}
    for r in rows:
        v = check_one(r)
        r.update(v)
        n[v["overall_verdict(correct/wrong/unsure)"]] += 1
        if v["error_type"]:
            et[v["error_type"]] = et.get(v["error_type"], 0) + 1

    with open(args.out, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)

    tot = sum(n.values())
    denom = n["correct"] + n["wrong"]
    acc = (n["correct"] / denom * 100) if denom else 0
    print("=" * 60)
    print(f"QA 自动核对: {args.qa}")
    print(f"  total={tot}  correct={n['correct']}  wrong={n['wrong']}  unsure={n['unsure']}")
    print(f"  strict_accuracy = correct/(correct+wrong) = {acc:.1f}%")
    print(f"  error_type 分布: {et}")
    print(f"  -> {args.out}")
    print("=" * 60)


if __name__ == "__main__":
    main()
