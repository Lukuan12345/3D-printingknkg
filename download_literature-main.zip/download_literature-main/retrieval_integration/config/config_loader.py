#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
config_loader.py —— YAML 配置加载器（融合版）

功能：
1. 加载主项目 configs/retrieval/default_config.yaml
2. 支持 ${ENV_VAR} 占位符替换
3. 支持运行时覆盖（dict merge）
4. 路径相对于主项目根目录自动解析
5. 知识回流路径锁死（无法被覆盖，仅 warning）
6. inherit_llm_from() 从主项目 extract_config_*.yaml 注入 LLM 凭证
"""

import os
import re
import logging
import yaml
from pathlib import Path
from typing import Any, Dict, Optional
from copy import deepcopy


logger = logging.getLogger(__name__)

# 模块加载时自动读取项目根目录的 .env（已有 os.environ 的变量不覆盖）
def _load_dotenv() -> None:
    dotenv_path = Path(__file__).resolve().parent.parent.parent / ".env"
    if not dotenv_path.exists():
        return
    with open(dotenv_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, value = line.partition("=")
            key = key.strip()
            value = value.strip().strip('"').strip("'")
            if key and key not in os.environ:
                os.environ[key] = value

_load_dotenv()

# retrieval_integration 根目录
RI_ROOT = Path(__file__).resolve().parent.parent
# 主项目根目录（kb_mvp / scientific_kgqa / packages 等的父目录）
PROJECT_ROOT = RI_ROOT.parent

# 默认配置路径：主项目 configs/retrieval/default_config.yaml
DEFAULT_CONFIG_PATH = PROJECT_ROOT / "configs" / "retrieval" / "default_config.yaml"

# 环境变量占位符：${VAR_NAME}
_ENV_PATTERN = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}")

# 知识回流路径锁（无法被 overrides 覆盖；防止误配丢候选）
_LOCKED_PATHS = {
    "knowledge_backflow.candidate_pool.path": "packages/retrieval/backflow/candidates/",
    "knowledge_backflow.schema_evolver.schema_miss_log_path": "packages/retrieval/backflow/schema_miss/",
}


def _resolve_env_vars(value: Any) -> Any:
    """递归替换 ${VAR} 为环境变量值。变量不存在则保留原占位符。"""
    if isinstance(value, str):
        def repl(m):
            var_name = m.group(1)
            return os.environ.get(var_name, m.group(0))
        return _ENV_PATTERN.sub(repl, value)
    elif isinstance(value, dict):
        return {k: _resolve_env_vars(v) for k, v in value.items()}
    elif isinstance(value, list):
        return [_resolve_env_vars(v) for v in value]
    return value


def _deep_merge(base: Dict, override: Dict) -> Dict:
    """深度合并两个 dict，override 优先。"""
    result = deepcopy(base)
    for k, v in override.items():
        if k in result and isinstance(result[k], dict) and isinstance(v, dict):
            result[k] = _deep_merge(result[k], v)
        else:
            result[k] = deepcopy(v)
    return result


def _apply_locked_paths(data: Dict) -> Dict:
    """强制覆盖 knowledge_backflow 的固定路径；若 yaml/overrides 试图改写则 warn。"""
    for key_dotted, locked_value in _LOCKED_PATHS.items():
        parts = key_dotted.split(".")
        node = data
        for p in parts[:-1]:
            if p not in node or not isinstance(node[p], dict):
                node[p] = {}
            node = node[p]
        leaf = parts[-1]
        current = node.get(leaf)
        if current is not None and current != locked_value:
            logger.warning(
                "[config_loader] '%s' 被锁定为 %r，忽略配置值 %r",
                key_dotted, locked_value, current,
            )
        node[leaf] = locked_value
    return data


class Config:
    """配置对象，支持 dot-notation 访问。"""

    def __init__(self, data: Dict):
        self._data = data

    def get(self, key: str, default: Any = None) -> Any:
        """
        支持 dot-notation:
            cfg.get("pipeline.thresholds.m1_parse_confidence")
        """
        parts = key.split(".")
        node = self._data
        for p in parts:
            if not isinstance(node, dict) or p not in node:
                return default
            node = node[p]
        return node

    def __getitem__(self, key: str) -> Any:
        val = self.get(key)
        if val is None:
            raise KeyError(f"Config key not found: {key}")
        return val

    def __contains__(self, key: str) -> bool:
        return self.get(key) is not None

    def as_dict(self) -> Dict:
        return deepcopy(self._data)

    def resolve_path(self, rel_path: str) -> Path:
        """将配置中的相对路径解析为相对于 PROJECT_ROOT 的绝对路径。"""
        p = Path(rel_path)
        if p.is_absolute():
            return p
        return (PROJECT_ROOT / rel_path).resolve()


def load_config(
    config_path: Optional[Path] = None,
    overrides: Optional[Dict] = None,
) -> Config:
    """
    加载配置。

    Args:
        config_path: 自定义配置文件路径；默认 configs/retrieval/default_config.yaml
        overrides:   运行时覆盖（dict），优先级最高

    Returns:
        Config 对象
    """
    if config_path is None:
        config_path = DEFAULT_CONFIG_PATH

    with open(config_path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}

    # 1. 环境变量替换
    data = _resolve_env_vars(data)

    # 2. 运行时覆盖
    if overrides:
        data = _deep_merge(data, overrides)

    # 3. 锁死知识回流路径
    data = _apply_locked_paths(data)

    return Config(data)


def inherit_llm_from(main_yaml: Path, cfg: Config) -> Config:
    """
    从主项目 extract_config_*.yaml 注入 LLM 凭证（base_url + api_key）。

    主项目 yaml 的 llm: 段会覆盖 cfg.llm.base_url / cfg.llm.api_key，
    但不会覆盖 cfg.llm.models.* （模块特定的模型分配保留）。
    """
    if not main_yaml.exists():
        logger.warning("[config_loader] main_yaml 不存在: %s", main_yaml)
        return cfg

    with open(main_yaml, "r", encoding="utf-8") as f:
        main_data = yaml.safe_load(f) or {}
    main_data = _resolve_env_vars(main_data)
    llm_section = main_data.get("llm", {}) or {}
    base_url = llm_section.get("base_url")
    api_key = llm_section.get("api_key")

    if not base_url and not api_key:
        logger.warning("[config_loader] main_yaml 无 llm 段: %s", main_yaml)
        return cfg

    overrides = {"llm": {}}
    if base_url:
        overrides["llm"]["base_url"] = base_url
    if api_key:
        overrides["llm"]["api_key"] = api_key

    merged = _deep_merge(cfg.as_dict(), overrides)
    merged = _apply_locked_paths(merged)

    # 同时把 LLM 凭证设到环境变量，让 kb_mvp / scientific_kgqa 也能读
    if base_url:
        os.environ.setdefault("LKE_LLM_BASE_URL", base_url)
    if api_key:
        os.environ.setdefault("LKE_LLM_API_KEY", api_key)

    return Config(merged)


# 全局单例（懒加载）
_global_config: Optional[Config] = None


def get_config() -> Config:
    """获取全局默认配置（懒加载）。"""
    global _global_config
    if _global_config is None:
        _global_config = load_config()
    return _global_config


def reset_config(cfg: Optional[Config] = None) -> None:
    """重置或替换全局配置（主要用于测试）。"""
    global _global_config
    _global_config = cfg
