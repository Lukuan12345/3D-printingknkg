# Retrieval_Integration 技术文档（组会汇报版）

> 版本：2026-05-12
> 适用范围：6 模块检索集成系统（内部混合检索 + 外部补充检索 + 知识回流）
> 配套阅读：[README.md](README.md)、[IMPLEMENTATION_PLAN.md](IMPLEMENTATION_PLAN.md)、[config/default_config.yaml](config/default_config.yaml)

---

## 一、项目定位与目标

### 1.1 解决的问题

学姐原始优化方案的痛点：单纯依赖 `kb_mvp` 的三路混合检索（BM25 + 向量 + Metadata），无法处理 KB 覆盖外的查询；而直接调用外部 API（PubMed/arXiv 等）又会丧失内部知识沉淀。**Retrieval_Integration 是连接「内部 KB」与「外部 API」的智能路由层**，按查询置信度决定走哪条路径，最后把高质量答案回流到 KB 实现增量演进。

### 1.2 三大目标

| 目标 | 设计动作 |
| --- | --- |
| **不重写检索能力** | M2 通过 `kb_mvp_adapter.py` 直接复用 `kb_mvp.HybridSearcher`，权重经 config 注入 |
| **可调可观测** | 全部阈值/模型/API 集中在 [config/default_config.yaml](config/default_config.yaml)；每模块自动落 JSONL 日志，可瓶颈分析 |
| **闭环演进** | M6 高置信答案 → 候选池 → 学姐审核 → 入库；M1 解析失败 Query → 聚类 → Schema 演进建议 |

---

## 二、系统架构

### 2.1 顶层流程图

```text
[用户 Query]
    ↓
┌────────────────────────────────────────────────────────────────┐
│ 模块1  Schema 解析（M1）                                         │
│   ├─ 关键词预筛（三路：英文 token / CJK 子串 / CJK bigram）         │
│   └─ LLM 打分：parse_confidence + matched_fields                │
└──────┬───────────────────────────────────────────────────────┬─┘
       │ ≥ T1 (0.4)                                            │ < T1
       ↓                                                       ↓
┌──────────────────────────────────────┐                  ┌─────────┐
│ 模块2  内部混合检索（M2）              │                  │ 状态 A   │
│   ├─ QueryStructurizer 生成 query_json│                  │（零知识）│
│   ├─ kb_mvp 三路融合（BM25+Dense+Meta）│                  └────┬────┘
│   └─ Title-Boost（lex+sem hybrid）    │                       │
└──────┬─────────────────────────────┬─┘                       │
       │ ≥ T2 (0.55)                 │ < T2                     │
       ↓                             ↓                          │
┌──────────────────────────────────┐ │                          │
│ 模块3  答案验证（M3）              │ │                          │
│   ├─ LLM 判断 covered/missing    │ │                          │
│   └─ 输出 answer_confidence      │ │                          │
└──────┬───────────────┬───────────┘ │                          │
       │ ≥ T3 (0.5)    │ < T3        │                          │
       ↓               ↓             ↓                          ↓
┌──────────┐      ┌────────┐    ┌──────────┐              ┌─────────┐
│ 直接回答 │      │ 状态 B │    │ 状态 A   │              │ 模块4   │
│  Direct  │      │(部分)  │───→│(零知识)  │──────────────→│ 检索计划 │
└──────────┘      └────────┘    └──────────┘              └────┬────┘
                                                                ↓
                                                       ┌────────────────┐
                                                       │ 模块5 外部检索 │
                                                       │ 双轨 + 三级递进│
                                                       └────┬───────────┘
                                                            ↓
                                                       ┌────────────────┐
                                                       │ 模块6 答案生成 │
                                                       │ + 知识回流触发 │
                                                       └────────────────┘
```

### 2.2 三个关键阈值（路由决策）

| 阈值 | 配置 key | 当前值 | 历史调整 | 含义 |
| --- | --- | --- | --- | --- |
| T1 | `pipeline.thresholds.m1_parse_confidence` | **0.4** | 0.6 → 0.5 → 0.4 | 小于则视为 Schema 之外的 Query |
| T2 | `pipeline.thresholds.m2_retrieval_confidence` | **0.55** | — | Reranker top-3 均分；低于则 KB 召回失败 |
| T3 | `pipeline.thresholds.m3_answer_confidence` | **0.5** | 0.7 → 0.5 | 大于则直接出答案；小于则进入状态 B 缝合外部 |

> T3 从 0.7 下调到 0.5 的原因：实测 179/179 全部走外部路径，直接回答率为 0。下调后给了 Prompt 放宽的空间，让 M3 有机会判 "可直接答"。

### 2.3 两种状态

- **状态 A**：内部零知识（M1 不通过 / M2 不通过）→ M4 从零开始构建外部检索式 → M6 用纯外部文献作答
- **状态 B**：内部部分知识（M3 不通过但有 chunks）→ M4 基于 Gap Analysis 仅检索缺失方面 → M6 内外缝合作答

---

## 三、目录与代码组织

```
Retrieval_Integration/
├── config/             # 配置中心（所有阈值 / 模型 / API 集中此处）
│   ├── default_config.yaml
│   ├── prompts.yaml
│   └── config_loader.py
├── core/               # 编排核心（pipeline + state + context + base_module）
├── modules/            # 6 业务模块（独立可测试）
│   ├── m1_schema_parser/
│   ├── m2_internal_retrieval/
│   ├── m3_answer_validator/
│   ├── m4_plan_generator/
│   ├── m5_external_retrieval/
│   ├── m6_answer_generator/
│   ├── confidence_scorer.py   # final_confidence 加权公式
│   └── direct_answer.py       # M3 直答分支的答案生成
├── llm/                # LLM 统一客户端 + Prompt 缓存
├── monitoring/         # 结构化日志 + 指标聚合 + 瓶颈分析
├── knowledge_backflow/ # 候选池 + Schema 演进 + 管理员 CLI
├── scripts/            # 入口：run_query / batch_test / analyze_metrics
└── tests/              # 单元 + 集成（4 类测试集）
```

抽象层次（自下而上）：

1. `core.BaseModule.run(ctx) → ctx`：所有模块统一接口
2. `core.RequestContext`：跨模块传递的数据契约（dataclass，见 [core/context.py](core/context.py)）
3. `core.RetrievalPipeline`：编排器，按阈值分流

---

## 四、各模块详解

### 4.1 模块 1：Schema 解析（[modules/m1_schema_parser/](modules/m1_schema_parser/)）

**职责**：判断 Query 与本项目 Schema（refined_schema_200_1.csv 中 200 余字段）契合度。
**核心产出**：`parse_confidence ∈ [0, 1]`，`matched_schema_fields: List[str]`。

#### 4.1.1 两阶段流程

1. **关键词预筛**：低耗本地计算，过滤完全无关的 Query，避免无效 LLM 调用
2. **LLM 打分**：使用 `claude-haiku-4-5-20251001`（快速模型），输出 JSON

#### 4.1.2 关键词预筛（核心修复点）

旧实现 `ratio = hits / total_keywords < 0.05` 在 285 字段 ≈ 447 关键词的 schema 下永远成立 → 真实 Query 全被拦截。已重构为**绝对命中数 + 三路匹配**（见 [modules/m1_schema_parser/confidence.py](modules/m1_schema_parser/confidence.py)）：

| 路径 | 处理 | 适用场景 |
| --- | --- | --- |
| 英文 token 交集 | split('_', ' ', '-') → 集合交集，过滤停用词 | `FR4 substrate` 命中 `substrate_material` |
| CJK 双向子串 | schema 段 ⊂ query 或反之 | `基板` 命中 `基底/基板材料` |
| CJK bigram 兜底 | 2 字组合的集合交集 | `基板设计` ↔ `基板材料` 部分相似 |

`min_keyword_hits = 1`，至少命中 1 个 schema 关键词即进 LLM。

#### 4.1.3 失败 Query 落盘

预筛失败或 LLM 评分低 → 写入 `data/schema_miss_log/miss_YYYY-MM-DD.jsonl`，供 SchemaEvolver 周期性聚类。

---

### 4.2 模块 2：内部混合检索（[modules/m2_internal_retrieval/](modules/m2_internal_retrieval/)）

**职责**：在 KB 中召回与 Query 最相关的 chunks。
**核心产出**：`internal_chunks: List[Dict]`，`retrieval_confidence`（reranker top-3 均分）。

#### 4.2.1 三层流水线

```
原始 Query
    ↓ (Step 1)
QueryStructurizer (kb_mvp) → structured_json {core_topic, keywords_cn/en, ...}
    ↓ (Step 2: 重建关键词密集 query_text，改善 BM25)
kb_mvp.HybridSearcher (BM25 + Dense + Metadata 三路融合)
    权重: metadata 0.2 / dense 0.45 / sparse 0.35
    ↓ (Step 3: Title-Boost 重排)
最终 top-k chunks
```

#### 4.2.2 为什么要 QueryStructurizer 预处理（F3 升级）

实测 P001-Q1 原始 Query 被 jieba 切成 15+ 碎 token 后 BM25 命中为 0。先通过 structurizer 抽出 `search_keywords_cn/en + core_topic`，再用关键词密集的 string 作为 `query_text`，使 sparse 分支真正生效。代价：每条查询多一次 LLM 调用（约 2-3 秒）。

#### 4.2.3 Title-Boost（A2c → H1 → H2，多轮迭代）

**背景**：FSS 领域 KB 中 P029、P030、P093 等"通用 FSS 论文" dense 分基线就高（≈0.9），把目标论文（如 P001 "一种宽通带低插损吸透一体 FSS"）的真实命中 chunk 挤出 top-K。

**Title-Boost 完整机制**（见 [modules/m2_internal_retrieval/retriever.py:328-422](modules/m2_internal_retrieval/retriever.py)）：

1. **提取标题前缀**：query 第一个逗号前 ≥ 6 字符即视为论文标题
2. **混合匹配**（H1）：
   - lexical：SequenceMatcher 字符相似度（阈值 0.7）
   - semantic：BGE-M3 embedding cosine（阈值 0.55，支持中英跨语言）
   - hybrid 模式（默认）：任一命中即视为候选，得分取 max
3. **候选封顶**（H1.1）：最多取相似度最高的 10 篇，避免 FSS 同域全员通过
4. **注入兜底**（H2a）：候选论文若没出现在 top-K，直接按 paper_id 反查 KB 拉它们的 top-N best chunks
5. **分级 bonus**（H2d）：
   - rank-1 论文：`bonus = 0.3 × 2.0 = 0.6`
   - rank 2-3：`bonus = 0.3 × 0.5 = 0.15`
   - rank 4+：`bonus = 0.3 × 0.15 = 0.045`
6. **回退 title_cn**：adapter 优先返回中文标题，使中文 query 的 lexical sim ≈ 1.0 升至 rank-1

> 这个 boost 机制是过去一周迭代最频繁的部分。逻辑复杂但效果显著：P001/P002 等"被通用论文压制"的目标论文现在能进 top3。

#### 4.2.4 置信度策略

`pipeline.m2_confidence_strategy = "reranker_top3_avg"`（top-3 融合分均值）。可选值：
- `reranker_top1`：单点最高分（噪声敏感）
- `reranker_top3_avg`：当前默认（鲁棒折中）
- `reranker_topk_weighted`：top-k 加权
- `llm_score`：调 LLM 再评（关闭以避免延迟）

---

### 4.3 模块 3：答案验证（[modules/m3_answer_validator/](modules/m3_answer_validator/)）

**职责**：判定当前 chunks 是否足以回答用户问题。
**核心产出**：`answer_confidence`、`covered_aspects`、`missing_aspects`、`can_answer_directly`。

#### 4.3.1 关键设计

- **送 LLM 的 chunks 上限**：10 条，每条 ≤ 800 字符，控制 prompt 体积
- **结构化输出契约**：必含 `answer_confidence / covered_aspects / missing_aspects / can_answer_directly`，未满足则进保守降级（置信度 0，走外部路径）
- **后处理守门**：`len(missing) > len(covered)` 时强制 `can_answer_directly = False`，防止 LLM 过度乐观

#### 4.3.2 输出示例

```json
{
  "answer_confidence": 0.55,
  "covered_aspects": ["药物A的作用机制"],
  "missing_aspects": ["药物B的作用机制", "A和B的对比实验数据"],
  "can_answer_directly": false
}
```

`missing_aspects` 是模块 4 状态 B 检索计划的输入。

---

### 4.4 模块 4：动态检索计划（[modules/m4_plan_generator/](modules/m4_plan_generator/)）

**职责**：根据状态生成结构化检索计划（含布尔查询 + 同义词 + 双轨）。
**核心产出**：`search_plan: Dict`（含 `query_rewrites + source_priority`）。

#### 4.4.1 状态 A vs 状态 B 的 Prompt 差异

| 维度 | 状态 A（零知识） | 状态 B（部分知识） |
| --- | --- | --- |
| 输入 | Query | Query + internal_context + covered + missing |
| 指令 | 从 0 构建完整布尔式 | 仅针对 missing_aspects 生成补充查询 |
| 双轨产物 | strict + expansive | strict + expansive（聚焦 gap） |

#### 4.4.2 双轨设计

- **strict_query**：高精度，包含核心实体 AND
- **expansive_query**：高召回，融入同义词与发散机制词
- **keywords_expand**：第 3 级 fallback（M5 用，无需再调 M4）

#### 4.4.3 防御性约束

- **PDF 笔误兜底**：原设计文档 JSON 示例第 26 行 `"strict_query", "..."` 用了逗号代替冒号，可能误导 LLM。已在 Prompt 增加硬性约束 + 容错解析三段式（` ``` ` 块 → `{...}` 子串 → 整体 loads）+ 字段缺失兜底 [plan_schema.py#ensure_default_plan](modules/m4_plan_generator/plan_schema.py)
- **target_apis 收敛**：M4 选的 API 必须在 `m4_plan_generator.available_apis` 与 `m5_external_retrieval.clients.*.enabled` 双白名单内，否则用 `default_apis` 兜底

#### 4.4.4 模型选择（C1 优化）

`m4_planner` 从 Sonnet 改为 Haiku，平均耗时从 10-15s 降到 2-3s，质量未明显下降（结构化提取任务对模型规模不敏感）。

---

### 4.5 模块 5：外部检索（[modules/m5_external_retrieval/](modules/m5_external_retrieval/)）

**职责**：调用外部 API 池，按双轨 + 三级递进策略召回文献，去重后输出。
**核心产出**：`external_docs: List[ExternalDoc]`、`external_docs_stats`。

#### 5.1 API 客户端注册表

[api_clients/__init__.py](modules/m5_external_retrieval/api_clients/__init__.py)：

| API | 状态 | 备注 |
| --- | --- | --- |
| **星河图书馆 ROS** | ✅ 启用 | meta + content 双端点，async + 同步对外，DOI 合并去重，分页/年份/期刊过滤 |
| **星河图书馆 SQL** | ⚠ 可选 | StarRocks 直连，需 sqlalchemy+pymysql，默认禁用 |
| **arXiv** | ✅ 启用 | 零 key，物理/计算机覆盖好 |
| **Semantic Scholar** | ✅ 启用 | 零 key（限速 100 req/5min），可选 S2_API_KEY |
| **OpenAlex** | ✅ 启用 | 零 key 学术 metadata 覆盖最广（2.5 亿论文） |
| **PubMed** | ❌ 禁用 | 领域不匹配（医学），key 已申请留备用 |
| ~~Bing Search~~ | ❌ 移除 | 微软 2025-08-11 全面下线 |

新增 API 客户端只需继承 `ExternalAPIClient`，实现 `search()` + `health_check()` 并注册到 `CLIENT_REGISTRY`。

#### 4.5.2 三级递进检索

[executor.py](modules/m5_external_retrieval/executor.py)：

```text
轮次 1 (strict)     → 双轨并发 strict_query + expansive_query
       │
       │ 累计文献 < min_docs_threshold (5)?
       ↓
轮次 2 (expansive)  → 单轨 expansive_query
       │
       │ 仍 < threshold?
       ↓
轮次 3 (fallback)   → keywords_expand 拼成 "K1" AND "K2" AND ...
```

#### 4.5.3 星河 ROS Client 实现要点（[xinghe_client.py](modules/m5_external_retrieval/api_clients/xinghe_client.py)，467 行）

- **认证**：`X-API-Key` = `ROS_API_KEY`（与下载用的 `XINGHE_API_KEY` 是两把不同的 key）
- **布尔解析**：`parse_boolean_query()` 把 M4 输出的 `("A" OR "B") AND ("C")` 拍平为 AND-of-OR 嵌套条件树
- **查询体构造**：每个 OR 组对 title + abstract 两字段做 `$match`
- **meta + content 双端点**：分别按 `publication_venue_name / magazine`、`publication_published_year / pub_time` 过滤；返回后按 DOI 合并（meta 补 venue/abstract，content 补 sha256/origin_path）
- **并发**：内部 `asyncio.Semaphore(concurrency=8)`；外层 ExternalRetriever 用 `ThreadPoolExecutor` 调度多 API 并发，所以单次 `search()` 自创自销 event loop

#### 4.5.4 去重

按 `["doi", "url", "title"]` 优先级，首个非空 key 命中即视为重复（[deduplicator.py](modules/m5_external_retrieval/deduplicator.py)）。

---

### 4.6 模块 6：答案生成（[modules/m6_answer_generator/](modules/m6_answer_generator/)）

**职责**：综合内外文献，生成结构化最终答案 + 触发知识回流。
**核心产出**：`final_answer`、`final_confidence`、`key_findings`、`references`、`conflicts`、`limitations`。

#### 4.6.1 三种执行分支

```text
n_internal=0 AND n_external=0 → 短路：返回结构化诊断信息（不调 LLM）
state==A AND n_external>0     → user_state_a Prompt（纯外部总结）
其他（state==B 或 A 降级）     → user_state_b Prompt（内外缝合）
```

#### 4.6.2 防截断与重试

- `max_tokens.m6_generator = 32768`（前几版 16384 仍遇截断）
- `thinking_mode.m6_generator = false`（思考会先占 max_tokens 配额）
- 解析失败 → 自动**精简重试**：top-3 文献 × 300 字符，避免 prompt 过长

#### 4.6.3 final_confidence 加权公式（[confidence_scorer.py](modules/confidence_scorer.py)）

**核心思想**：LLM 主观自评不可靠，改为「客观指标 70% + LLM 评估 30%」加权：

```
final_confidence =
    source_score      × 0.40   (代码计算：内部命中质量 + 外部文献数)
  + coverage_score    × 0.30   (代码计算：covered / (covered + missing))
  + factual_grounding × 0.20   (LLM 评估：答案声明是否有来源支撑)
  + completeness      × 0.10   (LLM 评估：核心问题是否被回答)
```

`source_score` 的分级见 `compute_source_score()`：从「内部 ≥ 0.6 + 外部 ≥ 5 → 1.0」一直到「内外都空 → 0.0」，覆盖 8 档。

#### 4.6.4 知识回流触发

`final_confidence ≥ 0.85` → `backflow_trigger.maybe_push_backflow()` → 写入 `data/candidate_pool/candidates_YYYY-MM-DD.jsonl`。

---

## 五、配置系统（[config/](config/)）

### 5.1 三层加载优先级

```
config_loader.py 加载顺序：
  ① default_config.yaml         （仓库默认值）
  ② 环境变量 ${VAR_NAME}        （${LLM_API_KEY} / ${ROS_API_KEY} 等）
  ③ 运行时 Config.set() 覆盖   （前端调阈值 / 测试夹具）
```

### 5.2 关键配置一览

| 类别 | 配置 | 说明 |
| --- | --- | --- |
| **阈值** | `pipeline.thresholds.{m1,m2,m3,m6}_*` | 路由决策与回流入库 |
| **模型** | `llm.models.{m1_parser,m3_validator,m4_planner,m6_generator}` | 各模块独立模型 |
| **max_tokens** | `llm.max_tokens.{module,default}` | 防截断（M6=32K） |
| **thinking_mode** | `llm.thinking_mode.{module}` | 简单任务关闭，提速并避免截断 |
| **缓存** | `llm.cache.{enabled,ttl_seconds,max_size}` | Prompt 哈希缓存 |
| **检索权重** | `m2_internal_retrieval.weights.{metadata,dense,sparse}` | 复用 kb_mvp |
| **API 启用** | `m5_external_retrieval.clients.{xinghe,arxiv,...}.enabled` | 与 m4.available_apis 必须一致 |
| **回流阈值** | `knowledge_backflow.candidate_pool.min_confidence` | 0.85 入库 |

### 5.3 Prompt 中心化

所有 LLM Prompt 集中在 [config/prompts.yaml](config/prompts.yaml)（263 行），格式：

```yaml
m4_plan_generator:
  system: "..."
  user_state_a: "..."   # 状态 A 模板
  user_state_b: "..."   # 状态 B 模板（含 missing_aspects 占位）
  output_format: "..."  # 共享的 JSON Schema 描述
```

调用方 `get_prompt("m4_plan_generator", "user_state_a")` → 模板字符串 → `.format(...)` 填占位符。

---

## 六、监控与可观测性

### 6.1 结构化日志

每条请求落 `data/logs/requests_YYYY-MM-DD.jsonl`，包含完整 `RequestContext` 序列化：

```json
{
  "request_id": "...",
  "query": "...",
  "parse_confidence": 0.85,
  "retrieval_confidence": 0.62,
  "answer_confidence": 0.55,
  "state": "B",
  "exit_reason": "external_success",
  "execution_path": ["m1_schema_parser", "m2_internal_retrieval", "m3_answer_validator", "m4_plan_generator", "m5_external_retrieval", "m6_answer_generator"],
  "module_metrics": {
    "m1_schema_parser": {"latency_ms": 450, "jumped": false},
    "m2_internal_retrieval": {"latency_ms": 1200, "kb_mvp_stats": {...}},
    ...
  },
  "final_confidence": 0.78,
  "warnings": [...]
}
```

### 6.2 指标聚合

`monitoring/metrics.py::compute_metrics()` 输出：

- 各模块 avg / P50 / P90 / P95 / P99 / max 耗时
- 三个跳转率：m1→m4、m2→m4、m3→m4
- 直接回答率
- 平均最终置信度
- 退出原因分布

### 6.3 瓶颈分析脚本

```bash
python -m Retrieval_Integration.scripts.analyze_metrics
```

输出报表（`bottleneck_report.json`）—— 用于识别哪个模块是延迟瓶颈、哪个跳转链异常偏高。

---

## 七、知识回流子系统

### 7.1 候选池（[knowledge_backflow/candidate_pool.py](knowledge_backflow/candidate_pool.py)）

- **数据格式**：JSONL，每行一条候选答案
- **目录结构**：
  ```
  data/candidate_pool/
    candidates_2026-05-09.jsonl     # 待审核
    approved/YYYY-MM-DD.jsonl       # 已批准（待入库 KB）
    rejected/YYYY-MM-DD.jsonl       # 已拒绝
  ```
- **管理员 CLI**：
  ```bash
  python -m Retrieval_Integration.knowledge_backflow.admin_interface status
  python -m Retrieval_Integration.knowledge_backflow.admin_interface list
  python -m Retrieval_Integration.knowledge_backflow.admin_interface approve <request_id>
  python -m Retrieval_Integration.knowledge_backflow.admin_interface reject <request_id>
  ```

### 7.2 Schema 演进（[knowledge_backflow/schema_evolver.py](knowledge_backflow/schema_evolver.py)）

- **触发**：周期性（默认 7 天）扫描 `schema_miss_log/`
- **流程**：收集近 N 天失败 Query → 达到 `min_cluster_size=10` 阈值 → 调 LLM 聚类 → 输出建议字段
- **输出**：每个 cluster 包含 theme / frequency / sample_queries / suggested_schema_field / rationale
- **用途**：人工审核后增量扩展 `refined_schema_200_1.csv`

---

## 八、关键工程决策与权衡

| 决策 | 备选 | 选定方案 | 理由 |
| --- | --- | --- | --- |
| M2 置信度 | LLM 评分 / Reranker 分数 | **Reranker top-3 均分** | LLM 评分增加 2-3s 延迟且贵；reranker 分数已经是融合后结果 |
| LLM 提供方 | 直连 Anthropic / OpenAI 兼容代理 | **OpenAI 兼容代理** | 复用 kb_mvp 已有 base_url，统一鉴权 |
| 内部路径 | 重写检索 / Adapter 模式 | **Adapter 模式** | kb_mvp 已稳定，重写风险高、收益低 |
| 模块编排 | DAG 框架（Prefect） / 显式 if-else | **显式 if-else** | 流程清晰、易调试、便于学姐 review |
| 状态传递 | 函数参数 / 共享 Context | **共享 RequestContext** | 字段一处声明，避免 6 模块接口 N 个参数 |
| Prompt 管理 | 散落在代码 / 中心 yaml | **prompts.yaml 中心化** | 修改 Prompt 不动代码，diff 清晰 |
| 知识回流入口 | 异步消息队列 / 文件 JSONL | **文件 JSONL** | 学姐审核体量小（每周几十条），可手工 vim 编辑 |
| 失败处理 | 抛异常 / 兜底降级 | **三层防御**（Prompt + 解析 + 默认值） | LLM 输出本就不稳定，主动兜底比 retry 快 |

---

## 九、已修复的关键问题（CHANGELOG 摘录）

### 9.1 M1 预筛阈值误判（高严重度）

- **症状**：电磁吸波体 Query 命中率 = 0.000 < 0.05，被直接降级到状态 A
- **根因**：
  1. `ratio < 0.05` 在 447 关键词的 schema 下要求命中 ≥ 22 个 token，普通 Query 不可能达到
  2. 朴素子串匹配（`"operating_frequency_range" in "8-12 GHz"`）永远 False
- **修复**：阈值改为绝对命中数 `min_keyword_hits=1` + 三路匹配（英文 token / CJK 子串 / CJK bigram）
- **效果**：6 类 Query 全部正确分桶（4 个 PASS、2 个 FILTER）

### 9.2 M6 LLM 输出截断

- **症状**：`finish_reason=length`，最终 JSON 不完整 → 解析失败 → 空答案
- **根因**：未传 `max_tokens`，使用了 API 默认上限（约 4096），对长答案不够
- **修复**：模块级 `max_tokens` 配置（M6=32768），客户端层 `_resolve_max_tokens()` 三段优先级

### 9.3 M6 内外资料皆空仍调 LLM

- **症状**：LLM 在零依据下幻觉式输出，耗 token 直至截断
- **修复**：M6 入口短路 `if n_internal==0 and n_external==0`，直接返回结构化诊断信息（路由状态 / 缺失方面 / 处理建议）

### 9.4 循环导入隐蔽 Bug

- **症状**：单文件 pytest 报 `ImportError: cannot import name 'SchemaParser' from partially initialized module`
- **根因**：`core/__init__.py` eager 导出 `RetrievalPipeline`，pipeline 又 import 所有 6 模块，模块再 import core → 菱形依赖
- **修复**：核心 `__init__.py` 移除 eager 导入，调用方一律全路径 `from Retrieval_Integration.core.pipeline import RetrievalPipeline`

### 9.5 PDF 设计文档 JSON 笔误

- **症状**：`知识库优化方案.pdf` 第 3 页代码块 line 26 用逗号代替冒号
- **三层防御**：Prompt 硬约束 + 容错 JSON 解析 + 字段缺失兜底（`ensure_default_plan`）
- **影响**：实现层不受影响（prompts.yaml 本就用冒号）

---

## 十、测试与运行

### 10.1 测试规模

- **单元测试**：54 → 64+ 项（约 0.21s 全套）
- **覆盖范围**：M1 三路匹配、M2 标题 boost、M4 plan schema 兜底、M5 dedupe、M6 空输入短路、Xinghe client 布尔解析、LLM max_tokens 优先级、final_confidence 加权
- **4 类测试集**：
  - Type A：完整 KB 覆盖 → 期望直接输出
  - Type B：部分 KB 覆盖 → 期望状态 B
  - Type C：零 KB 覆盖 → 期望状态 A
  - Type D：Schema 之外 → 期望 M1 直接跳转

### 10.2 运行入口

```bash
# 单次查询
python -m Retrieval_Integration.scripts.run_query "FR4 基板 X 波段吸波体设计"

# 批量测试
python -m Retrieval_Integration.scripts.batch_test \
    --test-file tests/test_cases/type_A_full_coverage.json \
    --output data/logs/type_A_report.json

# 瓶颈分析
python -m Retrieval_Integration.scripts.analyze_metrics

# 星河 CLI（独立调用 ROS API + 下载 PDF）
python -m Retrieval_Integration.scripts.xinghe_search_cli ...
```

### 10.3 环境变量

```bash
export LLM_API_KEY="sk-xxx"          # LLM 代理
export ROS_API_KEY="xxx"              # 星河 ROS 检索
export XINGHE_API_KEY="xxx"           # 星河 S3 下载（可选）
export S2_API_KEY="xxx"               # Semantic Scholar（可选）
export OPENALEX_EMAIL="..."           # OpenAlex Polite Pool（可选）
```

---

## 十一、当前状态与下一步

### 11.1 现状

- ✅ 6 模块全链路打通，前端 RI tab 可端到端响应
- ✅ 54+ 单元测试全过，单文件运行无循环导入
- ✅ 星河 ROS 真实 API 接入（meta + content 双端点）
- ✅ 候选池 JSONL + 管理员 CLI 可工作
- ✅ 失败 Query 已积累 30+ 条（`schema_miss_log/`），可触发首轮聚类

### 11.2 已知待办

| 优先级 | 项 | 说明 |
| --- | --- | --- |
| 高 | 直接回答率上调 | T3=0.5 后仍偏低，需 Prompt 工程让 M3 更敢判 "可直接答" |
| 高 | Title-Boost 通用化 | 当前对"标题前缀 query"有效，但常规 Q&A 形式 Query 不触发；需扩展到含论文关键短语的 Query |
| 中 | 知识回流 KB 写入 | `approved/` 目录的答案目前未自动写回 kb_mvp，需对接 `kb_mvp/src/ingest.py` 的增量接口 |
| 中 | Schema 演进首轮跑通 | 等待失败 Query 累积到 30+ 后人工触发首次聚类 |
| 低 | 异步 / 流式输出 | 目前同步，前端体验改进项 |
| 低 | 日志接入 ELK | 当前是本地 JSONL，规模上去需要中心化 |

### 11.3 风险与依赖

- **kb_mvp 版本**：M2 强依赖 `kb_mvp.HybridSearcher` 接口签名。kb_mvp 升级时需同步检查 `kb_mvp_adapter.py`
- **外部 API 稳定性**：星河 ROS 偶发 SSL 异常（已配 `verify_mode=CERT_NONE`）；Semantic Scholar 限速；OpenAlex Polite Pool 建议填邮件
- **Schema 漂移**：`refined_schema_200_1.csv` 字段调整会影响 M1 关键词预筛和 M2 metadata 召回，需同步重跑测试集

---

## 十二、汇报要点（一分钟版）

1. **路由层定位**：在「内部 KB 检索」与「外部 API 补检」之间智能分流，按置信度决定走哪条；高置信答案回流 KB 实现闭环
2. **6 模块协作**：M1 解析 → M2 内部检索 → M3 验证 → (直答 | M4 规划 → M5 外检 → M6 缝合)，全部走统一 `RequestContext`
3. **核心技术亮点**：
   - 三路关键词预筛修复 M1 误杀（绝对命中数 + CJK bigram）
   - QueryStructurizer + Title-Boost 让 M2 BM25 重新工作
   - final_confidence 加权公式（70% 客观 + 30% LLM）替代主观自评
   - 三级递进双轨检索 + 多 API 并发
4. **可观测**：全链路 JSONL 日志 + 指标聚合 + 瓶颈分析报表
5. **当前数据**：54+ 单测全过，前端端到端打通，星河 ROS 真实接入，候选池累积中
6. **下一步**：直答率提升、Title-Boost 通用化、KB 写回链路对接、Schema 首轮聚类

---

> 文档结束。如需深入任一模块，参见对应的源码注释（每个 .py 顶部都有用途说明）以及 `IMPLEMENTATION_PLAN.md` 第十节的变更日志。
