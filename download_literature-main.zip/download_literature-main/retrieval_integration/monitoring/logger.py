#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
logger.py —— 结构化日志

功能：
1. 配置标准 Python logging（带模块名前缀）
2. 提供 RequestLogger：每个请求的结构化 JSON 日志
"""

import sys
import json
import logging
from pathlib import Path
from datetime import datetime
from threading import Lock
from typing import Any, Dict, Optional

from ..config import get_config, RI_ROOT


_logging_configured = False
_file_handlers: Dict[str, "logging.FileHandler"] = {}
_file_lock = Lock()


def setup_logging(level: Optional[str] = None) -> None:
    """配置全局 logging（仅首次生效）。"""
    global _logging_configured
    if _logging_configured:
        return

    cfg = get_config()
    lvl = level or cfg.get("monitoring.log_level", "INFO")
    fmt = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter(fmt))

    root = logging.getLogger()
    root.setLevel(lvl)
    # 避免重复添加
    if not any(isinstance(h, logging.StreamHandler) for h in root.handlers):
        root.addHandler(handler)

    _logging_configured = True


# ============================================================
# 请求级结构化日志
# ============================================================


def _get_request_log_file() -> Path:
    """按日期滚动的 JSONL 文件。"""
    cfg = get_config()
    log_dir = cfg.resolve_path(cfg.get("monitoring.log_dir", "data/logs"))
    log_dir.mkdir(parents=True, exist_ok=True)
    date_str = datetime.now().strftime("%Y-%m-%d")
    return log_dir / f"requests_{date_str}.jsonl"


def log_request(ctx_dict: Dict[str, Any]) -> None:
    """
    写入一条请求的结构化日志到 JSONL 文件。
    线程安全。
    """
    path = _get_request_log_file()
    line = json.dumps(ctx_dict, ensure_ascii=False, default=str)

    with _file_lock:
        with open(path, "a", encoding="utf-8") as f:
            f.write(line + "\n")
