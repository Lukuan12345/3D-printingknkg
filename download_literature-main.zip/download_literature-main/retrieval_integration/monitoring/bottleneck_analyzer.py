#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
bottleneck_analyzer.py —— 瓶颈分析

基于 JSONL 请求日志，产出：
1. 各模块时间分布（avg / p50 / p90 / p95 / p99）
2. 跳转率 / 直接回答率 / 覆盖率
3. Top-N 耗时模块
4. 异常请求列表（error != None 或 total_latency 超过阈值）
"""

import json
from pathlib import Path
from datetime import datetime
from typing import Any, Dict, List, Optional

from ..config import get_config
from .metrics import load_request_logs, compute_metrics


def analyze_bottlenecks(
    log_dir: Optional[Path] = None,
    output_path: Optional[Path] = None,
    slow_threshold_ms: float = 10000.0,
) -> Dict[str, Any]:
    """
    生成完整的瓶颈分析报表。

    Args:
        log_dir:           日志目录（默认 data/logs/）
        output_path:       报表输出路径（默认 data/logs/bottleneck_report.json）
        slow_threshold_ms: 慢请求阈值

    Returns:
        完整报表字典
    """
    cfg = get_config()
    if log_dir is None:
        log_dir = cfg.resolve_path(cfg.get("monitoring.log_dir", "data/logs"))
    if output_path is None:
        output_path = cfg.resolve_path(
            cfg.get(
                "monitoring.bottleneck_analysis.output_path",
                "data/logs/bottleneck_report.json",
            )
        )

    records = load_request_logs(log_dir)
    base_metrics = compute_metrics(records)

    # 识别 Top-N 耗时模块
    module_stats = base_metrics.get("modules", {})
    top_slow = sorted(
        [
            {"module": m, **stats}
            for m, stats in module_stats.items()
        ],
        key=lambda x: x.get("p90_ms", 0),
        reverse=True,
    )[:5]

    # 慢请求
    slow_requests = [
        {
            "request_id": r.get("request_id"),
            "query": r.get("query"),
            "total_latency_ms": sum(
                m.get("latency_ms", 0) for m in (r.get("module_metrics") or {}).values()
            ),
            "exit_reason": r.get("exit_reason"),
            "execution_path": r.get("execution_path"),
        }
        for r in records
        if sum(
            m.get("latency_ms", 0) for m in (r.get("module_metrics") or {}).values()
        )
        >= slow_threshold_ms
    ]

    # 错误请求
    error_requests = [
        {
            "request_id": r.get("request_id"),
            "query": r.get("query"),
            "error": r.get("error"),
            "warnings": r.get("warnings"),
        }
        for r in records
        if r.get("error") or (r.get("warnings") and len(r.get("warnings", [])) > 0)
    ]

    # 覆盖率告警
    direct_rate = base_metrics.get("direct_answer_rate", 0.0)
    coverage_alert = None
    min_rate = cfg.get("pipeline.coverage_fallback.min_direct_answer_rate", 0.20)
    if direct_rate < min_rate and base_metrics.get("total_requests", 0) >= 20:
        coverage_alert = (
            f"直接回答率 {direct_rate:.2%} 低于阈值 {min_rate:.2%}，"
            f"建议扩充内部知识库"
        )

    report = {
        "generated_at": datetime.now().isoformat(),
        "log_dir": str(log_dir),
        "summary": {
            "total_requests": base_metrics.get("total_requests", 0),
            "direct_answer_rate": direct_rate,
            "avg_final_confidence": base_metrics.get("avg_final_confidence", 0.0),
            "slow_request_count": len(slow_requests),
            "error_request_count": len(error_requests),
            "coverage_alert": coverage_alert,
        },
        "modules": module_stats,
        "top_slow_modules": top_slow,
        "jump_rates": base_metrics.get("jump_rates", {}),
        "exit_reasons": base_metrics.get("exit_reasons", {}),
        "slow_requests": slow_requests[:20],
        "error_requests": error_requests[:20],
    }

    # 写入
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)

    return report


def print_report(report: Dict[str, Any]) -> None:
    """人类可读的报表打印。"""
    print("=" * 70)
    print(f"瓶颈分析报告 @ {report.get('generated_at')}")
    print("=" * 70)

    s = report["summary"]
    print(f"总请求数:        {s['total_requests']}")
    print(f"直接回答率:      {s['direct_answer_rate']:.2%}")
    print(f"平均最终置信度:  {s['avg_final_confidence']:.3f}")
    print(f"慢请求数:        {s['slow_request_count']}")
    print(f"异常请求数:      {s['error_request_count']}")
    if s.get("coverage_alert"):
        print(f"⚠️  {s['coverage_alert']}")

    print("\n--- 模块耗时 (ms) ---")
    print(f"{'模块':30} {'avg':>8} {'p50':>8} {'p90':>8} {'p99':>8}")
    for mod, stats in report["modules"].items():
        print(
            f"{mod:30} {stats['avg_ms']:>8.1f} {stats['p50_ms']:>8.1f} "
            f"{stats['p90_ms']:>8.1f} {stats['p99_ms']:>8.1f}"
        )

    print("\n--- 跳转率 ---")
    for k, v in report["jump_rates"].items():
        print(f"  {k}: {v:.2%}")

    print("\n--- 退出原因 ---")
    for k, v in report["exit_reasons"].items():
        print(f"  {k}: {v}")
