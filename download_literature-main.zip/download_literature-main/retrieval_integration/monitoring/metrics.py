#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
metrics.py —— 指标收集

从 JSONL 日志中聚合指标：
- 各模块平均 / P50 / P90 / P95 / P99 耗时
- 各模块跳转率
- 直接回答率
- 平均最终置信度
"""

import json
import statistics
from pathlib import Path
from typing import Any, Dict, List, Optional

from ..config import get_config


def load_request_logs(log_dir: Optional[Path] = None) -> List[Dict[str, Any]]:
    """加载日志目录下所有 requests_*.jsonl。"""
    if log_dir is None:
        cfg = get_config()
        log_dir = cfg.resolve_path(cfg.get("monitoring.log_dir", "data/logs"))
    log_dir = Path(log_dir)

    records = []
    if not log_dir.exists():
        return records

    for f in sorted(log_dir.glob("requests_*.jsonl")):
        with open(f, "r", encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    records.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
    return records


def _percentile(values: List[float], p: int) -> float:
    """简单分位数计算（1~99）。"""
    if not values:
        return 0.0
    values = sorted(values)
    k = (len(values) - 1) * p / 100.0
    f = int(k)
    c = min(f + 1, len(values) - 1)
    if f == c:
        return values[f]
    return values[f] + (values[c] - values[f]) * (k - f)


def compute_metrics(records: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    聚合指标。

    Returns:
        {
          "total_requests": N,
          "direct_answer_rate": 0.xx,
          "avg_final_confidence": 0.xx,
          "modules": {
            "m1_schema_parser": {"count": N, "avg_ms": ..., "p50": ..., "p90": ..., ...},
            ...
          },
          "jump_rates": {
            "m1_to_m4": 0.xx,
            "m2_to_m4": 0.xx,
            "m3_to_m4": 0.xx,
          },
          "exit_reasons": {
            "direct_answer": N,
            "external_success": N,
            ...
          }
        }
    """
    total = len(records)
    if total == 0:
        return {"total_requests": 0}

    # 收集各模块耗时
    module_latencies: Dict[str, List[float]] = {}
    for rec in records:
        mm = rec.get("module_metrics") or {}
        for mod_name, info in mm.items():
            lat = info.get("latency_ms", 0.0)
            module_latencies.setdefault(mod_name, []).append(lat)

    # 聚合
    module_stats = {}
    for mod, lats in module_latencies.items():
        module_stats[mod] = {
            "count": len(lats),
            "avg_ms": round(statistics.mean(lats), 2),
            "p50_ms": round(_percentile(lats, 50), 2),
            "p90_ms": round(_percentile(lats, 90), 2),
            "p95_ms": round(_percentile(lats, 95), 2),
            "p99_ms": round(_percentile(lats, 99), 2),
            "max_ms": round(max(lats), 2),
        }

    # 跳转率
    jump_1 = sum(
        1
        for r in records
        if r.get("exit_reason") == "schema_miss"
        or (r.get("parse_confidence", 1.0) < 0.6)
    )
    jump_2 = sum(
        1
        for r in records
        if r.get("exit_reason") == "retrieval_miss"
    )
    jump_3 = sum(
        1
        for r in records
        if r.get("exit_reason") == "answer_insufficient"
    )
    direct = sum(1 for r in records if r.get("exit_reason") == "direct_answer")

    # 退出原因统计
    exit_counts: Dict[str, int] = {}
    for r in records:
        er = r.get("exit_reason") or "unknown"
        exit_counts[er] = exit_counts.get(er, 0) + 1

    # 平均最终置信度
    confs = [
        r.get("final_confidence", 0.0)
        for r in records
        if r.get("final_confidence") is not None
    ]
    avg_conf = round(statistics.mean(confs), 3) if confs else 0.0

    return {
        "total_requests": total,
        "direct_answer_rate": round(direct / total, 3),
        "avg_final_confidence": avg_conf,
        "modules": module_stats,
        "jump_rates": {
            "m1_to_m4": round(jump_1 / total, 3),
            "m2_to_m4": round(jump_2 / total, 3),
            "m3_to_m4": round(jump_3 / total, 3),
        },
        "exit_reasons": exit_counts,
    }
