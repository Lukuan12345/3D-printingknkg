#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
run_query.py —— 单次查询 CLI

用法:
    python -m retrieval_integration.scripts.run_query "FR4 基板 X 波段吸波体设计"
    python -m retrieval_integration.scripts.run_query "..." --channel deep
    python -m retrieval_integration.scripts.run_query "..." --channel fast
    python -m retrieval_integration.scripts.run_query "..." --json   # 输出原始 JSON
"""

import sys
import json
import argparse
from pathlib import Path

_THIS = Path(__file__).resolve()
_RI_PARENT = _THIS.parent.parent.parent
if str(_RI_PARENT) not in sys.path:
    sys.path.insert(0, str(_RI_PARENT))

from retrieval_integration.config import load_config, inherit_llm_from, PROJECT_ROOT as RI_ROOT, reset_config
from retrieval_integration.core.pipeline import RetrievalPipeline

SEP  = "=" * 70
SEP2 = "-" * 70


def _print_section(title: str, items, formatter=None):
    print(f"\n{SEP2}")
    print(f"  {title}")
    print(SEP2)
    if not items:
        print("  (无)")
        return
    for i, item in enumerate(items, 1):
        if formatter:
            formatter(i, item)
        else:
            print(f"  [{i}] {item}")


def print_result(r: dict):
    print(SEP)
    print(f"  Query      : {r.get('query', '')}")
    print(f"  Channel    : {(r.get('metrics') or {}).get('channel', '-')}")
    print(f"  State      : {(r.get('metrics') or {}).get('state', '-')}")
    print(f"  Confidence : {(r.get('metrics') or {}).get('final_confidence', 0):.3f}")
    print(f"  Log Dir    : {r.get('process_log_dir', '-')}")
    print(SEP)

    # ── 1. 图谱初始种子节点 ──────────────────────────────────────────
    plan = r.get("kg_retrieval_plan") or {}
    seed_nodes = plan.get("seed_nodes") or []
    _print_section(f"[1] 图谱检索初始种子节点  ({len(seed_nodes)} 个)", seed_nodes,
        lambda i, n: print(f"  [{i}] [{n.get('node_type','')}] {n.get('canonical_name','')}  id={n.get('node_id','')}"))

    # ── 2. 图谱拓展后的节点 ──────────────────────────────────────────
    soft_nodes = plan.get("soft_nodes") or []
    _print_section(f"[2] 图谱拓展后的节点  ({len(soft_nodes)} 个)", soft_nodes,
        lambda i, n: print(f"  [{i}] [{n.get('node_type','')}] {n.get('canonical_name','')}  id={n.get('node_id','')}"))

    # ── 3. 图谱推理路径 ──────────────────────────────────────────────
    paths = r.get("kg_reasoning_paths") or []
    def _fmt_path(i, p):
        print(f"  [{i}] {p.get('text','') if isinstance(p, dict) else p}")
        for sp in (p.get("support_papers") or [] if isinstance(p, dict) else []):
            print(f"       └─ 《{sp.get('title','')}》 {sp.get('year','')}  score={sp.get('support_score','')}")
    _print_section(f"[3] 图谱推理路径  ({len(paths)} 条)", paths, _fmt_path)

    # ── 4. 知识库证据 ────────────────────────────────────────────────
    chunks = r.get("kb_evidence") or []
    def _fmt_chunk(i, c):
        print(f"  [{i}] paper_id={c.get('paper_id','')}  field={c.get('field_type','')}  score={c.get('fused_score',0):.4f}")
        content = (c.get("content") or "")[:200]
        print(f"       {content}{'...' if len(c.get('content',''))>200 else ''}")
    _print_section(f"[4] 知识库证据  ({len(chunks)} 条)", chunks, _fmt_chunk)

    # ── 5. 参考文献本地路径 ──────────────────────────────────────────
    ev_papers = r.get("evidence_papers") or []
    def _fmt_paper(i, ep):
        print(f"  [{i}] 《{ep.get('title','')}》  uid={ep.get('paper_uid','')}")
        if ep.get("md_path"):
            print(f"       md  : {ep['md_path']}")
        for p in ep.get("pdf_paths") or []:
            print(f"       pdf : {p}")
    _print_section(f"[5] 参考文献本地路径  ({len(ev_papers)} 篇)", ev_papers, _fmt_paper)

    # ── LLM 回答 ────────────────────────────────────────────────────
    print(f"\n{SEP2}")
    print("  [6] LLM 最终回答")
    print(SEP2)
    answer = r.get("llm_answer") or r.get("answer") or ""
    if answer:
        print(answer)
    else:
        print("  (无回答)")

    # ── 警告 / 错误 ──────────────────────────────────────────────────
    if r.get("warnings"):
        print(f"\n{'!'*70}")
        for w in r["warnings"]:
            print(f"  ⚠  {w}")
    if r.get("error"):
        print(f"\n{'!'*70}")
        print(f"  ❌ ERROR: {r['error']}")

    print(f"\n{SEP}")
    print(f"  推理日志目录: {r.get('process_log_dir', '-')}")
    print(f"  完整摘要    : {r.get('process_log_dir', '-')}\\10_summary.txt")
    print(SEP)


def main():
    parser = argparse.ArgumentParser(description="retrieval_integration 单次查询")
    parser.add_argument("query", nargs="?", default=None, help="用户查询")
    parser.add_argument("--query", dest="query_flag", default=None)
    parser.add_argument("--channel", default=None, choices=["fast", "deep", "auto"],
                        help="通道: fast(知识库) / deep(图谱+知识库) / auto(自动)")
    parser.add_argument("--config", default=None, help="自定义配置文件路径")
    parser.add_argument("--json", action="store_true", help="输出原始 JSON")
    parser.add_argument("--no-log", action="store_true", help="不写入日志文件")
    args = parser.parse_args()

    query = args.query or args.query_flag
    if not query:
        parser.print_help()
        sys.exit(1)

    cfg = load_config(Path(args.config)) if args.config else load_config()
    cfg = inherit_llm_from(RI_ROOT / "configs" / "extract_config_aero.yaml", cfg)
    reset_config(cfg)

    pipeline = RetrievalPipeline(cfg)
    result = pipeline.run(query, log=not args.no_log, channel=args.channel)

    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print_result(result)


if __name__ == "__main__":
    main()
