#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
xinghe_search_cli.py —— 星河图书馆批量检索 + CSV 导出 + 可选下载 PDF

与 D:/Users/Lean2023/Desktop/new_G_K/星河查询相关示例代码/xinghe_search.py 对齐，
但全部配置化，认证走环境变量：
    ROS_API_KEY       检索用 key  （必填）
    XINGHE_API_KEY    S3 下载 key（--download 时必填）
    STARROCKS_HOST / STARROCKS_USER / STARROCKS_PASSWORD  （--backend sql 时必填）

三种用法：

1) 单一关键词直接检索（冒烟测试用）
   python -m retrieval_integration.scripts.xinghe_search_cli \
       --query 'titanium additive manufacturing' --limit 50 \
       --out outputs/xinghe_smoke

2) 配置文件批量检索（推荐；沿用示例代码的 setting/*.json 格式）
   python -m retrieval_integration.scripts.xinghe_search_cli \
       --config setting/alloy.json --out outputs/xinghe/alloy --download

3) 从已有 CSV（或 CSV 目录）批量下载 PDF
   python -m retrieval_integration.scripts.xinghe_search_cli \
       --download-only --csv outputs/xinghe/alloy --out outputs/xinghe/alloy/pdf

配置文件格式（与示例代码一致）：
{
  "journals": [...可选期刊白名单...],
  "tasks": [
    {
      "name": "oxygen_in_Ti_AM",
      "base_logic": "and",
      "layers": [
        {"keywords": ["titanium additive manufacturing"]},
        {"keywords": ["oxygen contamination", "oxygen uptake"]}
      ]
    }
  ]
}
"""

from __future__ import annotations

import argparse
import csv
import json
import logging
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# 允许脚本直接运行
_THIS = Path(__file__).resolve()
_RI_PARENT = _THIS.parent.parent.parent  # .../literature_knowledge_extractor
if str(_RI_PARENT) not in sys.path:
    sys.path.insert(0, str(_RI_PARENT))

from retrieval_integration.modules.m5_external_retrieval.api_clients import (  # noqa: E402
    XingheClient,
    XingheSQLClient,
    XingheDownloader,
    build_tasks_from_csv,
    build_tasks_from_csv_dir,
)


logger = logging.getLogger("xinghe_cli")


# ------------------------------------------------------------------
# 配置文件 → 多任务 → 每任务 (keywords[], base_keywords[], base_logic)
# ------------------------------------------------------------------
def _resolve_task(task: Dict[str, Any]) -> Tuple[List[str], Optional[List[str]], str]:
    """还原示例代码中 layers + base_logic 的语义。

    1 层 + base_logic=and 且 ≥2 个词 → 最后一个词为 direction，其余为 base(AND)
    1 层 其他 → 每个 keyword 独立查询
    多层 → 前 N-1 层合并为 base，最后一层为 direction（独立查询各词）
    """
    layers = task.get("layers", []) or []
    base_logic = task.get("base_logic", "or")
    if not layers:
        return [], None, base_logic

    if len(layers) == 1:
        kws = [k for k in layers[0].get("keywords", []) if isinstance(k, str) and k.strip()]
        if base_logic == "and" and len(kws) >= 2:
            return [kws[-1]], kws[:-1], base_logic
        return kws, None, base_logic

    base: List[str] = []
    for layer in layers[:-1]:
        base.extend(k for k in layer.get("keywords", []) if isinstance(k, str) and k.strip())
    direction = [
        k for k in layers[-1].get("keywords", []) if isinstance(k, str) and k.strip()
    ]
    return direction, base, base_logic


def _build_query(direction: str, base: Optional[List[str]], base_logic: str) -> str:
    """产出 XingheClient.parse_boolean_query 可识别的字符串。

    - base + direction(AND) → ("base1" AND "base2") AND ("direction")
    - base + direction(OR)  → ("base1" OR "base2") AND ("direction")
    - 仅 direction → ("direction")
    """
    def _quote(t: str) -> str:
        t = t.replace('"', "'")
        return f'"{t}"'

    if not base:
        return f"({_quote(direction)})"

    op = " AND " if base_logic == "and" else " OR "
    base_str = "(" + op.join(_quote(b) for b in base) + ")"
    return f"{base_str} AND ({_quote(direction)})"


# ------------------------------------------------------------------
# 结果 → CSV
# ------------------------------------------------------------------
_CSV_FIELDS = [
    "title", "author", "pub_time", "magazine", "file_type",
    "abstract", "doi", "isbn", "sha256", "origin_path",
]


def _doc_to_row(doc) -> Dict[str, Any]:
    raw = doc.raw or {}
    return {
        "title": doc.title,
        "author": "; ".join(doc.authors) if doc.authors else "",
        "pub_time": doc.year if doc.year is not None else "",
        "magazine": doc.venue or "",
        "file_type": raw.get("file_type", ""),
        "abstract": doc.abstract or "",
        "doi": doc.doi or "",
        "isbn": raw.get("isbn", ""),
        "sha256": raw.get("sha256", ""),
        "origin_path": raw.get("origin_path", "") or (doc.url or ""),
    }


def _save_csv(rows: List[Dict[str, Any]], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=_CSV_FIELDS)
        writer.writeheader()
        for r in rows:
            writer.writerow({k: r.get(k, "") for k in _CSV_FIELDS})


def _safe_keyword(s: str) -> str:
    out = "".join(c if c.isalnum() or c in (" ", "-", "_") else "_" for c in s).strip()
    return out.replace(" ", "_") or "query"


# ------------------------------------------------------------------
# Client 工厂
# ------------------------------------------------------------------
def _make_client(args) -> Tuple[Any, str]:
    venues = _load_journals(args)
    common: Dict[str, Any] = {
        "enabled": True,
        "year_from": args.year_from,
        "year_to": args.year_to,
        "venues": venues,
    }

    if args.backend == "api":
        ros_key = os.environ.get("ROS_API_KEY", "")
        if not ros_key:
            print("❌ 未设置 ROS_API_KEY 环境变量，API 后端无法使用", file=sys.stderr)
            sys.exit(2)
        cfg = {
            **common,
            "api_key": ros_key,
            "page_size": args.page_size,
            "max_pages": args.max_pages,
            "timeout_s": args.timeout,
            "concurrency": args.concurrency,
        }
        return XingheClient(cfg), "api"

    # sql
    host = os.environ.get("STARROCKS_HOST", "")
    user = os.environ.get("STARROCKS_USER", "")
    pwd = os.environ.get("STARROCKS_PASSWORD", "")
    if not (host and user and pwd):
        print(
            "❌ 未设置 STARROCKS_HOST / STARROCKS_USER / STARROCKS_PASSWORD，"
            "SQL 后端无法使用",
            file=sys.stderr,
        )
        sys.exit(2)
    cfg = {
        **common,
        "host": host, "user": user, "password": pwd,
        "port": args.sr_port,
        "database": args.sr_db,
        "row_limit": args.row_limit,
        "timeout_s": args.timeout,
    }
    return XingheSQLClient(cfg), "sql"


def _load_journals(args) -> List[str]:
    if args.journals_file:
        with open(args.journals_file, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, list):
            raise ValueError(f"journals-file 必须是 JSON 数组: {args.journals_file}")
        return [str(x) for x in data]
    return list(args.venue or [])


# ------------------------------------------------------------------
# 任务执行
# ------------------------------------------------------------------
def _run_single_query(client, query: str, limit: int) -> List[Dict[str, Any]]:
    t0 = time.time()
    docs = client.search(query, max_results=limit)
    elapsed = time.time() - t0
    logger.info(f"query={query[:60]!r}  {len(docs)} 条  {elapsed:.2f}s")
    return [_doc_to_row(d) for d in docs]


def _run_config(client, config_path: Path, out_dir: Path, limit: int) -> List[Dict[str, Any]]:
    with open(config_path, "r", encoding="utf-8") as f:
        cfg = json.load(f)

    config_venues = list(cfg.get("journals", []) or [])
    if cfg.get("journals_file"):
        jp = cfg["journals_file"]
        with open(jp, "r", encoding="utf-8") as f:
            extra = json.load(f)
        config_venues = list(dict.fromkeys(config_venues + extra))

    if config_venues and not client.venues:
        client.venues = config_venues

    tasks = cfg.get("tasks", [])
    all_rows: List[Dict[str, Any]] = []

    for t_idx, task in enumerate(tasks, start=1):
        name = task.get("name", f"task_{t_idx}")
        keywords, base, base_logic = _resolve_task(task)
        if not keywords:
            logger.warning(f"任务 [{name}] 无 keywords，跳过")
            continue

        print(f"\n{'=' * 60}\n  任务 {t_idx}: {name}\n{'=' * 60}")
        task_dir = out_dir / name
        task_dir.mkdir(parents=True, exist_ok=True)

        seen_dois: set = set()
        task_rows: List[Dict[str, Any]] = []
        for kw_idx, kw in enumerate(keywords, start=1):
            q = _build_query(kw, base, base_logic)
            print(f"  [{kw_idx}/{len(keywords)}] {kw}  →  {q[:120]}")
            rows = _run_single_query(client, q, limit)

            csv_name = f"{kw_idx}.{_safe_keyword(kw)}_{len(rows)}.csv"
            _save_csv(rows, task_dir / csv_name)

            for r in rows:
                key = r.get("doi") or r.get("title") or r.get("sha256")
                if not key or key in seen_dois:
                    continue
                seen_dois.add(key)
                task_rows.append(r)

        all_rows.extend(task_rows)
        # 汇总 CSV
        _save_csv(task_rows, task_dir / "_merged.csv")
        print(f"  ✅ 任务 [{name}] 去重后 {len(task_rows)} 条 → {task_dir}")

    return all_rows


# ------------------------------------------------------------------
# 主流程
# ------------------------------------------------------------------
def _download(records: List[Dict[str, Any]], out_dir: Path, workers: int) -> None:
    api_key = os.environ.get("XINGHE_API_KEY", "")
    if not api_key:
        print("❌ 未设置 XINGHE_API_KEY，跳过下载", file=sys.stderr)
        return
    dl = XingheDownloader(api_key=api_key, max_workers=workers)
    print(f"\n📥 开始下载 {sum(1 for r in records if r.get('origin_path'))} 个 PDF → {out_dir}")
    res = dl.download_many(records, str(out_dir), max_workers=workers)
    print(f"📥 完成：ok={res['ok']} fail={res['fail']} dir={out_dir}")


def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="星河图书馆批量检索 + 下载 CLI",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    mode = p.add_mutually_exclusive_group(required=True)
    mode.add_argument("--query", help="单次检索字符串（用 \"a\" OR \"b\" 形式）")
    mode.add_argument("--config", help="批量任务配置文件（JSON）")
    mode.add_argument("--download-only", action="store_true",
                      help="跳过检索，直接从 --csv 指定的 CSV 或目录下载 PDF")

    p.add_argument("--out", required=True, help="输出目录（CSV + PDF 都在这下面）")
    p.add_argument("--csv", help="--download-only 时的 CSV 文件或目录")

    p.add_argument("--backend", choices=["api", "sql"], default="api")
    p.add_argument("--limit", type=int, default=200, help="每次检索返回条数上限")
    p.add_argument("--download", action="store_true", help="检索后下载 PDF")
    p.add_argument("--dl-workers", type=int, default=10, help="PDF 下载并发")

    # API 后端参数
    p.add_argument("--page-size", type=int, default=200)
    p.add_argument("--max-pages", type=int, default=20, help="CLI 默认拉全量（≤API 上限）")
    p.add_argument("--concurrency", type=int, default=16)
    p.add_argument("--timeout", type=int, default=60)

    # SQL 后端参数
    p.add_argument("--sr-port", type=int, default=30030)
    p.add_argument("--sr-db", default="ads")
    p.add_argument("--row-limit", type=int, default=10000)

    # 通用过滤
    p.add_argument("--year-from", type=int, default=None)
    p.add_argument("--year-to", type=int, default=None)
    p.add_argument("--venue", action="append", default=[],
                   help="期刊名白名单；可多次指定")
    p.add_argument("--journals-file", help="期刊名 JSON 数组文件")

    p.add_argument("-v", "--verbose", action="store_true")
    return p.parse_args()


def main() -> None:
    args = _parse_args()
    logging.basicConfig(
        level=logging.INFO if args.verbose else logging.WARNING,
        format="%(asctime)s %(levelname)-5s %(name)s: %(message)s",
    )

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    # ---- download-only ----
    if args.download_only:
        if not args.csv:
            print("❌ --download-only 必须同时指定 --csv", file=sys.stderr)
            sys.exit(2)
        src = Path(args.csv)
        if src.is_dir():
            records = build_tasks_from_csv_dir(str(src))
        elif src.is_file():
            records = build_tasks_from_csv(str(src))
        else:
            print(f"❌ --csv 路径不存在: {src}", file=sys.stderr)
            sys.exit(2)
        _download(records, out_dir / "pdf", args.dl_workers)
        return

    # ---- search mode ----
    client, backend_label = _make_client(args)
    print(f"🔎 后端: {backend_label}")

    t0 = time.time()
    if args.query:
        rows = _run_single_query(client, args.query, args.limit)
        csv_path = out_dir / f"{_safe_keyword(args.query)[:80]}_{len(rows)}.csv"
        _save_csv(rows, csv_path)
        print(f"✅ 已保存: {csv_path}  ({len(rows)} 条)")
        records = rows
    else:
        records = _run_config(client, Path(args.config), out_dir, args.limit)

    elapsed = time.time() - t0
    print(f"\n⏱️  总耗时: {elapsed:.2f}s，共 {len(records)} 条去重结果")

    if args.download:
        _download(records, out_dir / "pdf", args.dl_workers)


if __name__ == "__main__":
    main()
