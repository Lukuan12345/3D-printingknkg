#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
analyze_metrics.py —— 指标分析 & 瓶颈报告

用法:
    python -m retrieval_integration.scripts.analyze_metrics
    python -m retrieval_integration.scripts.analyze_metrics --log-dir data/logs
"""

import sys
import argparse
from pathlib import Path

_THIS = Path(__file__).resolve()
_RI_PARENT = _THIS.parent.parent.parent
if str(_RI_PARENT) not in sys.path:
    sys.path.insert(0, str(_RI_PARENT))

from retrieval_integration.monitoring import analyze_bottlenecks, print_report


def main():
    parser = argparse.ArgumentParser(description="指标与瓶颈分析")
    parser.add_argument("--log-dir", default=None, help="日志目录")
    parser.add_argument("--output", default=None, help="报表输出路径")
    parser.add_argument(
        "--slow-threshold-ms",
        type=float,
        default=10000.0,
        help="慢请求阈值（ms），默认 10s",
    )
    args = parser.parse_args()

    report = analyze_bottlenecks(
        log_dir=Path(args.log_dir) if args.log_dir else None,
        output_path=Path(args.output) if args.output else None,
        slow_threshold_ms=args.slow_threshold_ms,
    )
    print_report(report)


if __name__ == "__main__":
    main()
