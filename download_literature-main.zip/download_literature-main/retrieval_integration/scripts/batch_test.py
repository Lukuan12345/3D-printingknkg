#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
batch_test.py —— 批量测试

用法:
    python -m retrieval_integration.scripts.batch_test \
        --test-file tests/test_cases/type_A_full_coverage.json
"""

import sys
import json
import time
import argparse
from pathlib import Path
from typing import List, Dict, Any

_THIS = Path(__file__).resolve()
_RI_PARENT = _THIS.parent.parent.parent
if str(_RI_PARENT) not in sys.path:
    sys.path.insert(0, str(_RI_PARENT))

from retrieval_integration.core.pipeline import RetrievalPipeline


def load_test_cases(path: Path) -> List[Dict[str, Any]]:
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if isinstance(data, list):
        return data
    return data.get("test_cases", [])


def run_batch(test_file: Path, output_file: Path = None) -> Dict[str, Any]:
    cases = load_test_cases(test_file)
    print(f"Loaded {len(cases)} test cases from {test_file}")

    pipeline = RetrievalPipeline()
    results = []
    matched = 0

    for i, case in enumerate(cases, 1):
        query = case.get("query") or case.get("question")
        expected_path = case.get("expected_path")
        expected_exit = case.get("expected_exit_reason")

        print(f"\n[{i}/{len(cases)}] {query[:60]}")
        t0 = time.time()
        result = pipeline.run(query)
        elapsed = time.time() - t0

        actual_path = result["execution_path"]
        actual_exit = result["exit_reason"]

        path_match = expected_path is None or actual_path == expected_path
        exit_match = expected_exit is None or actual_exit == expected_exit
        passed = path_match and exit_match
        if passed:
            matched += 1

        results.append(
            {
                "id": case.get("id", f"case_{i}"),
                "query": query,
                "expected_path": expected_path,
                "actual_path": actual_path,
                "expected_exit": expected_exit,
                "actual_exit": actual_exit,
                "passed": passed,
                "final_confidence": result["final_confidence"],
                "elapsed_s": round(elapsed, 2),
                "warnings": result.get("warnings", []),
            }
        )
        status = "✅" if passed else "❌"
        print(
            f"  {status} path={' → '.join(actual_path)} | exit={actual_exit} | "
            f"conf={result['final_confidence']:.3f} | {elapsed:.1f}s"
        )

    summary = {
        "total": len(cases),
        "passed": matched,
        "pass_rate": round(matched / max(len(cases), 1), 3),
        "results": results,
    }

    if output_file:
        output_file.parent.mkdir(parents=True, exist_ok=True)
        with open(output_file, "w", encoding="utf-8") as f:
            json.dump(summary, f, ensure_ascii=False, indent=2)
        print(f"\nReport written to: {output_file}")

    print(
        f"\n=== Summary: {matched}/{len(cases)} passed "
        f"({summary['pass_rate']:.1%}) ==="
    )
    return summary


def main():
    parser = argparse.ArgumentParser(description="批量测试")
    parser.add_argument(
        "--test-file",
        required=True,
        help="测试用例 JSON（格式: [{id, query, expected_path, expected_exit_reason}, ...]）",
    )
    parser.add_argument("--output", default=None, help="输出 JSON 报表路径")
    args = parser.parse_args()

    test_file = Path(args.test_file)
    output = Path(args.output) if args.output else None
    run_batch(test_file, output)


if __name__ == "__main__":
    main()
