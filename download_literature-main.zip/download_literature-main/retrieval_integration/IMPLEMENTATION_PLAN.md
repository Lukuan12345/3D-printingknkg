# Retrieval_Integration 实施方案

> 基于 `详细实现方案.md` 的 6 模块架构，在 `literature_knowledge_extractor/Retrieval_Integration/` 下实现可维护、可配置的检索集成系统。

---

## 一、设计原则

| 原则 | 具体做法 |
|------|----------|
| **模块化** | 6 个业务模块各自独立成包，同一接口（`BaseModule.run()`）对外 |
| **可维护** | 核心编排（`core/pipeline.py`）与业务逻辑分离；Prompt 统一在 `config/prompts.yaml` 中管理 |
| **参数可调** | 全部阈值/权重/模型名集中在 `config/default_config.yaml`，支持环境变量和运行时覆盖 |
| **可复用** | 模块2通过 `kb_mvp_adapter.py` 直接复用已有的 `kb_mvp/HybridSearcher`，不重写检索 |
| **可观测** | `monitoring/` 统一收集各模块耗时、置信度、跳转率，对齐方案中的"实验指标" |
| **可测试** | 每个模块独立单元测试 + 4 类测试集（A/B/C/D 覆盖度）的集成测试 |

---

## 二、目录结构

```
Retrieval_Integration/
├── README.md                           # 项目说明
├── IMPLEMENTATION_PLAN.md              # 本文档
├── requirements.txt                    # 依赖清单
│
├── config/                             # 【配置中心】所有可调参数集中在此
│   ├── __init__.py
│   ├── default_config.yaml             # 默认配置（阈值/权重/API/模型）
│   ├── prompts.yaml                    # 所有 LLM Prompt 模板
│   └── config_loader.py                # 配置加载器（支持环境变量 + 运行时覆盖）
│
├── core/                               # 【编排核心】Pipeline 与状态
│   ├── __init__.py
│   ├── pipeline.py                     # 主编排器：6 模块串联
│   ├── state.py                        # 状态机：StateA / StateB 定义
│   ├── context.py                      # 请求上下文（跨模块传递）
│   └── base_module.py                  # 模块抽象基类（统一 run() 接口）
│
├── modules/                            # 【业务模块】6 个模块
│   ├── __init__.py
│   │
│   ├── m1_schema_parser/               # 模块1：Schema 解析
│   │   ├── __init__.py
│   │   ├── parser.py                   # SchemaParser（主类）
│   │   ├── confidence.py               # parse_confidence 计算
│   │   └── prompts.py                  # 本模块 Prompt 组装
│   │
│   ├── m2_internal_retrieval/          # 模块2：内部混合检索
│   │   ├── __init__.py
│   │   ├── retriever.py                # InternalRetriever（主类）
│   │   ├── kb_mvp_adapter.py           # 适配 kb_mvp.HybridSearcher
│   │   └── confidence.py               # retrieval_confidence（Reranker 分数）
│   │
│   ├── m3_answer_validator/            # 模块3：答案验证
│   │   ├── __init__.py
│   │   ├── validator.py                # AnswerValidator（主类）
│   │   ├── gap_analyzer.py             # 提取 missing_aspects（Internal_Context）
│   │   └── prompts.py
│   │
│   ├── m4_plan_generator/              # 模块4：动态检索计划生成
│   │   ├── __init__.py
│   │   ├── planner.py                  # RetrievalPlanner（主类）
│   │   ├── state_a_handler.py          # 状态A：从0构建检索式
│   │   ├── state_b_handler.py          # 状态B：Gap Analysis 补充
│   │   └── prompts.py
│   │
│   ├── m5_external_retrieval/          # 模块5：外部检索
│   │   ├── __init__.py
│   │   ├── executor.py                 # ExternalRetriever（双轨执行器）
│   │   ├── deduplicator.py             # 按 DOI/URL 去重
│   │   └── api_clients/                # 外部 API 可插拔
│   │       ├── __init__.py
│   │       ├── base_client.py          # ExternalAPIClient 抽象基类
│   │       ├── xinghe_client.py        # 星河图书馆
│   │       ├── pubmed_client.py        # PubMed
│   │       ├── arxiv_client.py         # arXiv
│   │       └── bing_client.py          # Bing Search
│   │
│   └── m6_answer_generator/            # 模块6：答案生成 + 知识回流触发
│       ├── __init__.py
│       ├── generator.py                # FinalAnswerGenerator（主类）
│       ├── state_a_prompt.py           # 纯外部总结
│       ├── state_b_prompt.py           # 内外缝合
│       └── backflow_trigger.py         # 触发异步知识回流
│
├── llm/                                # LLM 基础设施
│   ├── __init__.py
│   ├── llm_client.py                   # 统一 LLM 客户端（复用 kb_mvp 的 API 配置）
│   └── cache.py                        # Prompt+输入 哈希缓存（LRU/Redis 可切换）
│
├── monitoring/                         # 监控与指标
│   ├── __init__.py
│   ├── metrics.py                      # MetricsCollector（耗时/置信度/跳转率）
│   ├── logger.py                       # 结构化日志（JSON）
│   └── bottleneck_analyzer.py          # 瓶颈分析脚本
│
├── knowledge_backflow/                 # 知识回流子系统（异步）
│   ├── __init__.py
│   ├── candidate_pool.py               # 待入库候选池
│   ├── schema_evolver.py               # Schema 演进（聚类分析解析失败 Query）
│   └── admin_interface.py              # 管理员确认接口（CLI / Web）
│
├── tests/
│   ├── __init__.py
│   ├── test_cases/                     # 测试集（4 类）
│   │   ├── type_A_full_coverage.json    # 期望直接输出
│   │   ├── type_B_partial_coverage.json # 期望状态B → 模块4
│   │   ├── type_C_zero_coverage.json    # 期望状态A → 模块4
│   │   └── type_D_schema_miss.json      # 期望模块1直接跳转
│   ├── unit/                           # 单元测试（每模块一个）
│   │   ├── test_m1_schema_parser.py
│   │   ├── test_m2_internal_retrieval.py
│   │   ├── test_m3_answer_validator.py
│   │   ├── test_m4_plan_generator.py
│   │   ├── test_m5_external_retrieval.py
│   │   └── test_m6_answer_generator.py
│   └── integration/
│       └── test_pipeline_end2end.py    # 4 类测试集的 end2end 验证
│
├── scripts/                            # 运行入口
│   ├── run_query.py                    # 单次查询 CLI
│   ├── batch_test.py                   # 批量测试（输出指标报表）
│   └── analyze_metrics.py              # 瓶颈分析报表生成
│
└── data/                               # 运行时数据
    ├── logs/                           # 结构化日志文件
    ├── schema_miss_log/                # 解析失败 Query 记录（供 Schema 演进用）
    └── candidate_pool/                 # 待入库高质量答案候选
```

---

## 三、核心抽象

### 3.1 `BaseModule`（统一模块接口）

所有模块实现相同接口，便于 Pipeline 统一调度：

```python
# core/base_module.py
class BaseModule(ABC):
    name: str
    config: dict

    @abstractmethod
    def run(self, ctx: RequestContext) -> RequestContext:
        """执行模块逻辑，读取并更新 ctx。"""
```

### 3.2 `RequestContext`（跨模块传递数据）

```python
# core/context.py
@dataclass
class RequestContext:
    query: str
    request_id: str

    # 模块1 产出
    parse_confidence: float = 0.0
    matched_schema_fields: list = field(default_factory=list)

    # 模块2 产出
    retrieval_confidence: float = 0.0
    internal_chunks: list = field(default_factory=list)

    # 模块3 产出
    answer_confidence: float = 0.0
    missing_aspects: list = field(default_factory=list)

    # 状态（A/B）
    state: Optional[State] = None

    # 模块4 产出
    search_plan: dict = field(default_factory=dict)

    # 模块5 产出
    external_docs: list = field(default_factory=list)

    # 模块6 产出
    final_answer: str = ""
    final_confidence: float = 0.0

    # 指标
    metrics: dict = field(default_factory=dict)
```

### 3.3 `Pipeline`（主编排器）

```python
# core/pipeline.py
class RetrievalPipeline:
    def run(self, query: str) -> dict:
        ctx = RequestContext(query=query, ...)

        ctx = self.m1.run(ctx)
        if ctx.parse_confidence < cfg.M1_THRESHOLD:
            ctx.state = State.A
            return self._go_external(ctx)

        ctx = self.m2.run(ctx)
        if ctx.retrieval_confidence < cfg.M2_THRESHOLD:
            ctx.state = State.A
            return self._go_external(ctx)

        ctx = self.m3.run(ctx)
        if ctx.answer_confidence >= cfg.M3_THRESHOLD:
            return self._direct_answer(ctx)    # 流程提前结束
        else:
            ctx.state = State.B
            return self._go_external(ctx)

    def _go_external(self, ctx):
        ctx = self.m4.run(ctx)
        ctx = self.m5.run(ctx)
        ctx = self.m6.run(ctx)
        return self._finalize(ctx)
```

---

## 四、分阶段实施计划

### 阶段 1：地基搭建（1~2 天）
- [ ] `config/default_config.yaml` — 定义所有配置项
- [ ] `config/prompts.yaml` — 沉淀方案中的所有 Prompt 模板
- [ ] `config/config_loader.py` — 加载器（YAML + 环境变量覆盖）
- [ ] `core/base_module.py` / `core/context.py` / `core/state.py`
- [ ] `llm/llm_client.py` — 统一 LLM 客户端（复用 `kb_mvp/src/answer_generator.py` 已有 API）
- [ ] `llm/cache.py` — Prompt 缓存

### 阶段 2：内部路径（2~3 天）
- [ ] **模块1**：`m1_schema_parser/` — 读 Schema CSV，LLM 判 `parse_confidence`
- [ ] **模块2**：`m2_internal_retrieval/kb_mvp_adapter.py` — 包装 `HybridSearcher`，`retrieval_confidence = max(reranker_scores)`
- [ ] **模块3**：`m3_answer_validator/` — LLM 判 `answer_confidence`，输出 `missing_aspects`
- [ ] `core/pipeline.py` — 串联 m1→m2→m3，实现"直接输出高分答案"分支
- [ ] 单元测试 + type_A 测试集验证

### 阶段 3：外部路径（2~3 天）
- [ ] **模块4**：`m4_plan_generator/` — 两个状态各自的 Prompt + JSON 解析
- [ ] **模块5**：先实现 `base_client.py` 抽象 + `xinghe_client.py` 一个，其他 API 后续补齐
- [ ] `m5_external_retrieval/executor.py` — 双轨 strict/expansive 并发 + 去重
- [ ] **模块6**：`m6_answer_generator/` — 两个状态各自的 Prompt 生成答案
- [ ] type_B / type_C 测试集验证

### 阶段 4：监控与回流（1~2 天）
- [ ] `monitoring/metrics.py` — 跨模块指标收集装饰器
- [ ] `monitoring/logger.py` — 结构化 JSON 日志
- [ ] `knowledge_backflow/candidate_pool.py` — 高分答案入库
- [ ] `knowledge_backflow/schema_evolver.py` — 失败 Query 聚类
- [ ] `scripts/analyze_metrics.py` — 瓶颈分析报表

### 阶段 5：集成测试与调优（1~2 天）
- [ ] 4 类测试集的端到端验证
- [ ] 阈值调优：`M1_THRESHOLD / M2_THRESHOLD / M3_THRESHOLD`
- [ ] 性能瓶颈分析（按 P50/P90/P99）
- [ ] 学姐审核接口对接

---

## 五、关键配置项（预览 default_config.yaml）

```yaml
pipeline:
  thresholds:
    m1_parse_confidence: 0.6       # 模块1阈值
    m2_retrieval_confidence: 0.55  # 模块2阈值（Reranker 分数）
    m3_answer_confidence: 0.7      # 模块3直接输出阈值
    m6_high_quality: 0.85          # 模块6知识回流入库阈值

  # 模块2 是否用 LLM 评置信度（关闭则直接用 Reranker 分数）
  m2_use_llm_confidence: false

llm:
  provider: "openai_compatible"
  base_url: "http://35.220.164.252:3888"
  api_key: "${LLM_API_KEY}"
  models:
    m1_parser: "claude-haiku-4-5-20251001"    # 快速模型
    m3_validator: "claude-haiku-4-5-20251001"
    m4_planner: "claude-sonnet-4-6"           # 复杂规划用强模型
    m6_generator: "claude-sonnet-4-6"
  cache:
    enabled: true
    ttl_seconds: 3600

internal_retrieval:
  adapter: "kb_mvp"                # 当前唯一实现
  top_k: 10
  weights:                          # 复用 kb_mvp 权重配置
    metadata: 0.2
    dense: 0.6
    sparse: 0.2

external_retrieval:
  default_apis: ["星河图书馆"]      # 默认启用的 API 列表
  clients:
    xinghe:
      enabled: true
      base_url: "..."
      api_key: "${XINGHE_API_KEY}"
      timeout_s: 30
    pubmed:
      enabled: false
    arxiv:
      enabled: false
    bing:
      enabled: false
  dual_track:
    enabled: true
    max_docs_per_track: 20

knowledge_backflow:
  enabled: true
  candidate_pool_path: "data/candidate_pool/"
  schema_evolver:
    cluster_interval_days: 7        # 每周聚类一次
    min_cluster_size: 10            # 聚类最小 Query 数

monitoring:
  log_level: "INFO"
  log_dir: "data/logs/"
  metrics:
    enabled: true
    record_latency: true
    record_confidence: true
    record_jump_rate: true
```

---

## 六、关键实现细节

### 6.1 模块2 Reranker 置信度（解决"LLM判置信度延迟问题"）

```python
# modules/m2_internal_retrieval/confidence.py
def compute_retrieval_confidence(chunks: list) -> float:
    """直接使用 Reranker 的 top 分数作为置信度，避免额外 LLM 调用。"""
    if not chunks:
        return 0.0
    scores = [c.get("fused_score", 0.0) for c in chunks]
    # 取 top-3 均值更鲁棒
    top_scores = sorted(scores, reverse=True)[:3]
    return sum(top_scores) / len(top_scores)
```

### 6.2 模块3 Gap Analysis 输出（供模块4使用）

```python
# modules/m3_answer_validator/validator.py
# LLM 输出示例
{
  "answer_confidence": 0.55,
  "covered_aspects": ["药物A的作用机制"],
  "missing_aspects": ["药物B的作用机制", "A和B的对比实验数据"],
  "can_answer_directly": false
}
```

### 6.3 模块4 双轨检索式生成（状态B带 Gap）

```python
# modules/m4_plan_generator/state_b_handler.py
def build_prompt(ctx: RequestContext) -> str:
    return f"""
已从内部知识库获取以下信息（不完整）：
{format_docs(ctx.internal_chunks)}

已覆盖方面：{ctx.covered_aspects}
缺失方面：{ctx.missing_aspects}

请仅针对【缺失方面】生成双轨布尔检索式：
- strict_query: 精准匹配缺失实体
- expansive_query: 发散机制探测词
输出 JSON...
"""
```

### 6.4 模块5 可插拔 API 客户端

```python
# modules/m5_external_retrieval/api_clients/base_client.py
class ExternalAPIClient(ABC):
    @abstractmethod
    def search(self, query: str, max_results: int = 20) -> List[ExternalDoc]: ...

    @abstractmethod
    def health_check(self) -> bool: ...

# executor.py 通过注册表动态选择
CLIENT_REGISTRY = {
    "星河图书馆": XingheClient,
    "PubMed API": PubMedClient,
    "arXiv": ArxivClient,
    "Bing Search API": BingClient,
}
```

### 6.5 监控指标自动收集

```python
# monitoring/metrics.py
@collect_metrics(module_name="m1_schema_parser")
def run(self, ctx: RequestContext) -> RequestContext:
    # 自动记录: 耗时、是否跳转、输出置信度
    ...
```

输出到 `data/logs/requests_YYYY-MM-DD.jsonl`：
```json
{"request_id": "...", "query": "...", "modules": {"m1": {...}, "m2": {...}}, "total_latency_ms": 3570, "final_path": "m1→m2→m3→m4B→m5→m6"}
```

---

## 七、与现有 `kb_mvp` 的复用关系

| 需求 | 复用方式 |
|------|----------|
| 三路混合检索 | `m2_internal_retrieval/kb_mvp_adapter.py` 直接调用 `kb_mvp.src.searcher.HybridSearcher` |
| LLM API 客户端 | `llm/llm_client.py` 沿用 `kb_mvp/src/answer_generator.py` 的 base_url/api_key 配置 |
| Schema CSV | 直接读取 `refined_schema_output/refined_schema_200_1.csv`（模块1、模块4使用） |
| Embedding API | 不直接复用，但共享同一 API 端点配置 |
| 查询结构化 | **不复用** `query_structurizer.py`——模块1的任务不同（Schema 契合度 vs 结构化提取） |

---

## 八、待确认事项

| # | 问题 | 影响模块 | 我的建议 |
|---|------|----------|----------|
| 1 | 外部 API（星河图书馆）的端点/认证方式？ | M5 | 先用 mock，接口预留 |
| 2 | 模块3 是否也用 LLM 判置信度（存在时延问题）？ | M3 | 保留 LLM，但加缓存 |
| 3 | 知识回流的管理员确认是 CLI 还是 Web？ | Backflow | 先实现 CLI，Web 后期 |
| 4 | 是否需要异步 / 流式输出？ | Pipeline | v1 同步，v2 考虑 async |
| 5 | 日志是否需要接入 ELK / Loki？ | Monitoring | 先文件日志，后对接 |

---

## 九、进度追踪

请 Review 本方案后确认以下几点：

1. **目录结构**是否合理？是否要拆分/合并某些模块？
2. **分阶段计划**是否匹配你的时间安排？优先级是否正确？
3. **kb_mvp 复用策略**（通过 adapter 而非重写）是否认可？
4. **配置项覆盖范围**是否够用？是否有需要额外暴露为 config 的参数？
5. **未决事项**（第八节）的建议是否采纳？

确认后，我会按阶段 1 → 5 依次实现。

---

## 十、变更日志（CHANGELOG）

> 本节记录初版实施完成（2026-05-06）后，基于真实运行/审阅反馈做的所有修改。
> 每条变更包含：发现路径 → 根因分析 → 修复方案 → 验证手段 → 影响范围。
> 用于汇报与回溯。

---

### 10.1 [2026-05-06] PDF 设计文档 JSON 语法笔误

#### 发现路径

学姐对照原 `知识库优化方案.pdf` 截图反馈：模块4 输出格式规范第 26 行 `"strict_query", "..."` 形如 JSON 但用了逗号代替冒号，是非法 JSON。

#### 根因分析

- **位置**：`知识库优化方案.pdf` 第 3 页代码块 line 26
- **错误**：`"strict_query", "..."`（应为 `"strict_query": "..."`）
- **风险**：若 LLM 严格按"示例"复刻输出，会产出无法 `json.loads` 的字符串，导致模块4 直接抛异常或后续模块拿到空计划

#### 修复方案（三层防御）

| 层 | 实施位置 | 作用 |
| --- | --- | --- |
| L1 防御性 Prompt | [config/prompts.yaml#L80-L92](config/prompts.yaml) | M4 system prompt 增加硬性约束："键值对必须用冒号分隔，禁止用逗号代替"，并给反例 |
| L2 容错解析 | [llm/llm_client.py#L77-L104](llm/llm_client.py) `extract_json_from_text` | 三段式尝试：``` 块抽取 → 第一个 `{` 到最后一个 `}` 的子串 → 整体 `json.loads` |
| L3 字段缺失兜底 | [modules/m4_plan_generator/plan_schema.py#L40-L68](modules/m4_plan_generator/plan_schema.py) `ensure_default_plan` | 若 `strict_query/expansive_query` 缺失，用 `boolean_query` 或原始 `query` 兜底 |

#### 我的实现是否受影响？

**不受影响**。`config/prompts.yaml` 的 `output_format` 模板本身就用冒号；模块4 经过容错解析与兜底已经可以承受 LLM 偶发的语法异常。

#### 验证手段

- 在 [详细实现方案.md L220-226](../../详细实现方案.md) 添加显式勘误 block，标明 PDF 笔误位置
- 单元测试 `test_m4_plan_schema.py` 4 项全过：覆盖完整 plan / 缺失字段 / 全空兜底 / 既存字段保留

#### 影响范围

- 实现层：仅 prompts.yaml 的 M4 system prompt 增加 ~7 行硬性约束
- 文档层：详细实现方案.md 增加勘误说明
- **无代码逻辑改动，无数据迁移**

---

### 10.2 [2026-05-06 23:49] M1 预筛阈值误判（高严重度）

#### 发现路径

真实运行日志（用户测试集成检索 tab）：

```text
[f6d82c041ab4] query='设计一款工作在 8-12 GHz、±60°角域内，吸收率≥90%、
                       厚度≤2 mm 的极化不敏感吸波体，基于 FR4 基板'
[f6d82c041ab4] Prefilter: overlap=0.000 < 0.05, skipping LLM
[f6d82c041ab4] M1 miss (conf=0.000) → State A
```

明显与 schema 强相关的电磁吸波体 Query 被预筛拦截，没机会进 M1 LLM 评估，直接降级到状态 A 走外部路径。

#### 根因分析

**Bug 1：阈值语义错误（数学问题）**
- 原实现：`ratio = hits / len(schema_keywords)`
- 默认阈值：`min_keyword_overlap = 0.05`（命中率 ≥ 5% 才算通过）
- 实际：schema 字段数 285，每字段 + 中文别名 + 聚类名 ≈ 447 个关键词；命中 5 个就需要 22 个，普通 Query 不可能达到

**Bug 2：关键词形态错配（语义问题）**
- schema 的 EN 字段是复合词：`operating_frequency_range`、`substrate_material`
- schema 的 CN 字段是长短语：`基底/基板材料`、`仿真/测试扫频范围`
- 用户 Query 用的是字段值或子词：`FR4`、`基板`、`X 波段`、`8-12 GHz`
- 旧代码：`if kw.lower() in query.lower()`（整体子串包含）
  - `"operating_frequency_range" in "8-12 GHz"` → False
  - `"基底/基板材料" in "FR4 基板"` → False（schema 含斜杠和"材料"，query 没有）
- **结论**：原匹配方法对自然语言查询永远 0 命中

#### 修复方案

##### 修复 A：阈值语义改为「绝对命中数」

| 项 | 旧 | 新 |
| --- | --- | --- |
| 配置 key | `min_keyword_overlap` | `min_keyword_hits` |
| 默认值 | 0.05（5% 命中率） | 1（至少命中 1 个 token） |
| 单位 | 比例 ∈ [0,1] | 整数 ≥ 0 |
| 优点 | — | schema 字段数变化时阈值语义稳定 |

##### 修复 B：匹配算法升级（三路并集）

实现位置：[modules/m1_schema_parser/confidence.py](modules/m1_schema_parser/confidence.py) `keyword_hit_count`

```text
1. 英文 token 直接交集
   - 拆分 schema 关键词：split('_', ' ', '-') → token 集合
   - 拆分 query：连续 [a-z0-9]+ → token 集合
   - 交集，去停用词、长度<2 的 token

2. CJK 双向子串匹配
   - schema 段在 query 中（"基板材料" ⊂ "FR4 基板材料的损耗"）
   - query 段在 schema 段中（"基板" ⊂ "基底/基板材料"）

3. CJK bigram 兜底
   - 拆分 query 与 schema 的 CJK 段为连续 2-字组合
   - 取 bigram 集合交集
   - 避免依赖中文分词器，对"基板设计"vs"基板材料"等部分相似场景生效
```

##### 实测效果（命中数对比表）

| Query | 旧逻辑（ratio） | 新逻辑（hits） | 期望 |
| --- | --- | --- | --- |
| 设计一款工作在 8-12 GHz... 吸波体, FR4 基板 | 0.000（误杀） | **6**（PASS） | ✅ PASS |
| FR4基板X波段吸波体的典型介电常数 | 0.000 | **5**（PASS） | ✅ PASS |
| X-band absorber design with FR4 substrate | 0.000 | **3**（PASS） | ✅ PASS |
| 量子点超材料吸波体的理论设计 | 0.000 | ≥1（PASS） | ✅ PASS |
| 如何烹饪宫保鸡丁 | 0.000 | **0**（FILTER） | ✅ FILTER |
| 今天天气如何 | 0.000 | **0**（FILTER） | ✅ FILTER |

#### 验证手段

- 单元测试新增 5 条：`test_hit_count_*`（覆盖空集 / 命中 / 不命中 / 中文 / 大 schema 不被稀释 / 复合字段）
- 真实 Query 端到端验证：用户原失败 Query 现命中数 = 6

#### 影响范围

- 修改文件：`modules/m1_schema_parser/confidence.py`、`parser.py`、`config/default_config.yaml`
- 配置兼容性：旧 key `min_keyword_overlap` 已废弃；YAML 中改为 `min_keyword_hits`
- 单元测试新增 5 条，全套 54 项通过

---

### 10.3 [2026-05-06 23:49] M6 LLM 输出截断

#### 发现路径

同一次运行日志：

```text
2026-05-06 23:49:56 [WARNING] llm_client - LLM 输出被截断
   （finish_reason=length），模型: claude-sonnet-4-6
   — 考虑增加 max_tokens 或简化 prompt
```

模块6 调用 Claude Sonnet 生成最终答案时，输出被强制截断，导致返回的 JSON 不完整 → 解析失败 → 答案为空。

#### 根因分析

| 链路 | 现象 |
| --- | --- |
| `LLMClient.call()` | 未传 `max_tokens` 参数 |
| 底层 `_raw_call_llm()` | 默认 `max_tokens=None` |
| HTTP 请求 | API 服务方默认值（多数 `~4096`，对长答案偏小） |
| 模块6 任务 | 状态A 全外部总结 / 状态B 内外缝合，含 `answer + key_findings + references + conflicts + limitations`，token 需求 8K-16K |

**结论**：长答案任务用了 API 默认上限，必然截断。

#### 修复方案

##### 配置层：每模块独立 max_tokens

[config/default_config.yaml](config/default_config.yaml)：

```yaml
llm:
  max_tokens:
    default: 8192
    m1_parser: 1024            # JSON 输出短
    m3_validator: 1024
    m4_planner: 4096           # 含布尔式与同义词
    m6_generator: 16384        # 最终答案 + 引用，给足空间
```

##### 客户端层：按模块自动选择

[llm/llm_client.py](llm/llm_client.py) 新增 `_resolve_max_tokens()`：

```text
解析优先级：
  1. 显式 call(max_tokens=N) 参数
  2. config.llm.max_tokens.<module>
  3. config.llm.max_tokens.default
  4. None（让底层用提供方默认）
```

`call()` 与 `call_json()` 都新增 `max_tokens` 可选参数；缓存 key 包含 max_tokens，避免不同长度互相污染。

#### 验证手段

- 单元测试新增 6 条 `test_llm_max_tokens.py`（含优先级链 / 模块缺失回退 / 默认配置完整性）
- 端到端：实际配置加载验证 `llm.max_tokens.m6_generator = 16384, default = 8192`

#### 影响范围

- 修改文件：`llm/llm_client.py`（新增 `_resolve_max_tokens` + 参数透传）、`config/default_config.yaml`
- API 兼容性：所有 `call()` / `call_json()` 调用方无需改动（max_tokens 默认 None）
- 性能影响：可忽略（仅在请求 payload 多一个字段）

---

### 10.4 [2026-05-06 23:49] M6 内外资料皆空时仍调 LLM

#### 发现路径

同一次运行日志的链式诊断：

```text
m1: prefilter 误杀 → State A
m4: 生成 search_plan，但 target_apis = ["星河图书馆"]
m5: XingheClient base_url 未配置 → 跳过调用 → 返回 0 篇
m6: 仍走 LLM 调用 → 输入只有 "无内部信息" + "未检索到外部文献"
   → LLM 试图凭空生成回答，输出冗长 → 截断
```

外部资料 0 篇时，M6 不应让 LLM 凭空作答。

#### 根因分析

- 旧 M6 实现无短路逻辑：无论 `internal_chunks` 与 `external_docs` 是否都空，一律构造 Prompt 调 LLM
- LLM 在没有依据的情况下要么编造（幻觉），要么疯狂解释为什么不能回答（耗 tokens 直至截断）

#### 修复方案

实现位置：[modules/m6_answer_generator/generator.py](modules/m6_answer_generator/generator.py) `_run` 方法开头：

```python
n_internal = len(ctx.internal_chunks or [])
n_external = len(ctx.external_docs or [])
if n_internal == 0 and n_external == 0:
    ctx.warnings.append("m6: 内外资料均为空，已跳过 LLM 调用")
    ctx.final_answer = self._empty_inputs_answer(ctx)
    ctx.final_confidence = 0.0
    return ctx
```

`_empty_inputs_answer()` 给前端返回**结构化的诊断信息**而非空白：

```text
⚠️ 本次未获得任何参考资料，无法生成可靠答案。

诊断信息:
· 路由状态: A
· M2 内部命中: 0 条 chunks
· M5 外部检索: 0 篇文献
· 缺失方面: ...

可能原因与处理建议:
1. 外部 API 未配置 → 在 default_config.yaml 启用 PubMed/arXiv
2. 内部知识库该领域覆盖不足 → 扩充 KB 后重试
3. M1/M2 阈值过严 → 在前端调低 M1/M2 阈值再试
```

#### 验证手段

- 4 条 Mock 单元测试 `test_m6_empty_inputs.py`：
  1. 内外都空 → 跳过 LLM、给诊断
  2. 仅内部有 → 走 LLM
  3. 仅外部有 → 走 LLM
  4. 诊断信息含状态与缺失方面

#### 影响范围

- 修改文件：`modules/m6_answer_generator/generator.py`
- 用户体验：失败请求从"空答案 + 截断告警"变为"明确诊断 + 处理建议"
- 副作用：节省一次 LLM 调用费用（典型 16K tokens）

---

### 10.5 [2026-05-06] 循环导入隐蔽 Bug

#### 发现路径

单独运行 `test_m1_confidence.py` 时报 `ImportError: cannot import name 'SchemaParser' from partially initialized module`。
全套测试通过是因为 pytest 字典序 collection 让 `test_config.py / test_context.py` 先跑，先把 `core` 模块完整加载。

```text
m1_schema_parser/__init__.py
   → parser.py
   → from ...core import BaseModule
   → core/__init__.py
   → from .pipeline import RetrievalPipeline
   → pipeline.py
   → from ..modules.m1_schema_parser import SchemaParser  ← 此时 m1 包仍在加载
   ImportError
```

#### 根因分析

`core/__init__.py` 在顶层 eager 导出 `RetrievalPipeline`，而 `pipeline.py` 必须导入所有 6 个模块。模块本身又依赖 `core.BaseModule`。形成菱形依赖。

#### 修复方案

[core/__init__.py](core/__init__.py)：移除 `from .pipeline import RetrievalPipeline`，改为延迟导入。

```python
"""
注意：RetrievalPipeline 不在此处 eager 导出，避免循环导入。
请用：from Retrieval_Integration.core.pipeline import RetrievalPipeline
"""
from .state import State, ExitReason
from .context import RequestContext
from .base_module import BaseModule
# (不再 import RetrievalPipeline)
```

调用方一律用全路径导入：`from Retrieval_Integration.core.pipeline import RetrievalPipeline`。

#### 验证手段

- 单文件 pytest：`pytest test_m1_confidence.py` 单独跑通过
- 全局 grep 确认无依赖 `from core import RetrievalPipeline` 的残留

#### 影响范围

- 修改文件：`core/__init__.py`（移除一行 import + 加注释）
- 调用方：`scripts/run_query.py`、`scripts/batch_test.py`、`frontend/server.py` 已用全路径导入，无需改动

---

## 十一、修改文件总览

| 类别 | 文件 | 涉及变更条目 |
| --- | --- | --- |
| 配置 | `config/default_config.yaml` | 10.2 / 10.3 |
| 配置 | `config/prompts.yaml` | 10.1 |
| 核心 | `core/__init__.py` | 10.5 |
| LLM | `llm/llm_client.py` | 10.3 |
| 模块1 | `modules/m1_schema_parser/confidence.py` | 10.2 |
| 模块1 | `modules/m1_schema_parser/parser.py` | 10.2 |
| 模块6 | `modules/m6_answer_generator/generator.py` | 10.4 |
| 测试 | `tests/unit/test_m1_confidence.py` | 10.2（+7 项） |
| 测试 | `tests/unit/test_llm_max_tokens.py` | 10.3（新建，6 项） |
| 测试 | `tests/unit/test_m6_empty_inputs.py` | 10.4（新建，4 项） |
| 文档 | `../../详细实现方案.md` | 10.1（勘误 block） |

**测试规模**：单元测试由 37 项 → 54 项（+17），全套 0.21s 通过。

---

## 十二、向上汇报要点（一句话版）

1. **PDF 笔误**：原设计文档模块4 JSON 示例第 26 行有逗号错位，已在 Prompt + 解析 + 兜底三层防御，实现层不受影响。
2. **预筛误杀**：M1 阈值语义有 bug（`ratio < 0.05` 永远成立），用户真实 Query 直接被拦截。已升级为「绝对命中数 + token 拆分 + CJK bigram」三路匹配，实测 6 类 Query 全部正确分桶。
3. **LLM 截断**：M6 长答案任务未传 `max_tokens` 导致输出被砍。已按模块独立配置（M6 = 16K），并用模块级 → default → None 的解析优先级保证向后兼容。
4. **空输入幻觉**：内外资料都空时短路返回结构化诊断，节省一次 LLM 调用并给用户明确处理建议。
5. **循环导入**：暴露的隐蔽 bug，pytest 收集顺序碰巧绕开，已用延迟导入修复并加注释防回归。

**当前状态**：54/54 单元测试全过；前端 RI tab 可端到端响应；用户原失败 Query 已能正常进入 LLM 评估。
