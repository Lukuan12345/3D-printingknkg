"""S5 MatchKGKB — 把 KB 召回的 chunks 反向归并到 KG 推理链。

输入:
  - kb_hits: list[chunk] (来自 S4)
  - kg_paths: list[dict] (来自 S2，每条带 nodes/support_papers)
  - kg_expanded_node_ids: list[int]

输出:
  MatchedFrame {
    answer_units: 按 evolution_chain 分组的 chunks
    supplementary_chunks: KG 未锚定但 BM25 高分的 chunks
    inconsistencies: 4 类不一致诊断（v2 §9.1）
  }
"""
from __future__ import annotations

import logging
import sqlite3
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)


@dataclass
class AnswerUnit:
    """一条推理链 + 其物理证据。供 S6 prompt 渲染。"""
    chain_id: int
    chain_text: str                # "Prototype:A -> Prototype:B -> Prototype:C"
    chain_nodes: List[Dict[str, Any]] = field(default_factory=list)
    chain_edges: List[str] = field(default_factory=list)  # ["EVOLVES_TO", "IMPROVES_UPON", ...]
    support_papers: List[Dict[str, Any]] = field(default_factory=list)  # 来自 KG path 自带
    kb_chunks: List[Dict[str, Any]] = field(default_factory=list)       # 反向匹配上的 chunks
    overlap_node_count: int = 0    # 该 chain 上有几个 prototype 被 KB chunks 支撑

    def to_dict(self) -> Dict[str, Any]:
        return {
            "chain_id": self.chain_id,
            "chain_text": self.chain_text,
            "chain_nodes": self.chain_nodes,
            "chain_edges": self.chain_edges,
            "support_papers": self.support_papers,
            "kb_chunks": [
                {k: v for k, v in c.items() if k not in ("__weighted_score",)}
                for c in self.kb_chunks
            ],
            "overlap_node_count": self.overlap_node_count,
        }


@dataclass
class Inconsistency:
    """KG↔KB 不一致诊断。"""
    type: str  # chain_unsupported | kb_unanchored | edge_mismatch | user_feedback
    description: str
    chain_id: Optional[int] = None
    chain_text: Optional[str] = None
    chain_edges: List[str] = field(default_factory=list)
    chunk_ids: List[str] = field(default_factory=list)
    paper_ids: List[str] = field(default_factory=list)
    suggestion: str = ""           # kg_too_coarse | kb_missing_data | edge_mislabeled

    def to_dict(self) -> Dict[str, Any]:
        return self.__dict__.copy()


@dataclass
class MatchedFrame:
    answer_units: List[AnswerUnit] = field(default_factory=list)
    supplementary_chunks: List[Dict[str, Any]] = field(default_factory=list)
    inconsistencies: List[Inconsistency] = field(default_factory=list)
    stats: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "answer_units": [u.to_dict() for u in self.answer_units],
            "supplementary_chunks": self.supplementary_chunks,
            "inconsistencies": [i.to_dict() for i in self.inconsistencies],
            "stats": self.stats,
        }


@lru_cache(maxsize=1)
def _open(db_path: str) -> sqlite3.Connection:
    con = sqlite3.connect(db_path, check_same_thread=False)
    con.row_factory = sqlite3.Row
    return con


def match(
    kg_db_path: Path,
    *,
    kg_paths: List[Dict[str, Any]],
    kg_anchor_node_ids: List[int],
    kg_expanded_node_ids: List[int],
    kb_hits: List[Dict[str, Any]],
    min_overlap: int = 2,
    keep_supplementary: bool = True,
    enable_diagnose: bool = True,
) -> MatchedFrame:
    """
    Args:
        kg_paths: list of {text, nodes:[{node_id, canonical_name, ...}], support_papers}
        kb_hits:  S4 输出的 top_k chunks
        min_overlap: chain 上至少几个 prototype 被 chunk 支撑才算"chain 命中"
        enable_diagnose: 是否做 4 类不一致诊断
    """
    if not kg_paths and not kb_hits:
        return MatchedFrame(stats={"reason": "no_input"})

    con = _open(str(kg_db_path))

    # ---- 1. 给每个 KB chunk 反查"它支撑哪些 prototype node_id" ----
    chunk_ids = [c.get("chunk_id") for c in kb_hits if c.get("chunk_id")]
    chunk_to_nodes: Dict[str, Set[int]] = {cid: set() for cid in chunk_ids}
    if chunk_ids:
        ph = ",".join("?" * len(chunk_ids))
        rows = con.execute(
            f"""
            SELECT chunk_id, node_id FROM node_chunk_posting
            WHERE chunk_id IN ({ph})
            """,
            chunk_ids,
        ).fetchall()
        for r in rows:
            chunk_to_nodes[r["chunk_id"]].add(r["node_id"])

    # ---- 2. 对每条 KG path 反查"它的 nodes 被哪些 chunk 支撑" ----
    answer_units: List[AnswerUnit] = []
    matched_chunk_ids: Set[str] = set()
    for idx, p in enumerate(kg_paths):
        nodes = p.get("nodes", []) or []
        node_ids = [n.get("node_id") for n in nodes if n.get("node_id")]
        if not node_ids:
            continue

        # 找哪些 chunks 包含 chain 上的 node
        unit_chunks: List[Dict[str, Any]] = []
        overlap_nodes: Set[int] = set()
        for c in kb_hits:
            cid = c.get("chunk_id")
            if not cid:
                continue
            hit_nodes = chunk_to_nodes.get(cid, set()) & set(node_ids)
            if hit_nodes:
                unit_chunks.append({
                    **c,
                    "_match_nodes": list(hit_nodes),
                })
                overlap_nodes.update(hit_nodes)
                matched_chunk_ids.add(cid)

        # 推断 chain_edges（如果 path 中提供 nodes 但没显式 edges）
        chain_edges = _infer_chain_edges(con, node_ids)

        unit = AnswerUnit(
            chain_id=idx,
            chain_text=p.get("text", ""),
            chain_nodes=nodes,
            chain_edges=chain_edges,
            support_papers=p.get("support_papers", []) or [],
            kb_chunks=unit_chunks,
            overlap_node_count=len(overlap_nodes),
        )
        answer_units.append(unit)

    # 排序：按 overlap_node_count + chunk 数量
    answer_units.sort(
        key=lambda u: (-u.overlap_node_count, -len(u.kb_chunks)),
    )

    # ---- 3. supplementary_chunks（KG 没锚定但 BM25 高分）----
    supplementary: List[Dict[str, Any]] = []
    if keep_supplementary:
        for c in kb_hits:
            if c.get("chunk_id") not in matched_chunk_ids:
                supplementary.append(c)

    # ---- 4. 不一致诊断（v2 §9.1）----
    inconsistencies: List[Inconsistency] = []
    if enable_diagnose:
        # TODO-NEW-6 前提检查：若 chain_chunk_ratio 极低（< 10%），多半是数据不同源
        # 而非 KG 真正过粗，跳过 chain_unsupported 避免伪报
        chain_chunk_ratio = (
            len(matched_chunk_ids) / len(kb_hits) if kb_hits else 0.0
        )
        skip_chain_unsupported = (
            kb_hits and chain_chunk_ratio < 0.10
        )
        if skip_chain_unsupported:
            inconsistencies.append(Inconsistency(
                type="data_mismatch",
                description=f"KG↔KB bridge hit rate too low ({chain_chunk_ratio:.1%}). "
                            f"Likely data source mismatch, skipping chain_unsupported diagnosis.",
                suggestion="rebuild_kb_index",
            ))

        # ① chain 完整但 chunks 全空
        if not skip_chain_unsupported:
            for u in answer_units:
                if not u.kb_chunks and u.chain_nodes:
                    inconsistencies.append(Inconsistency(
                        type="chain_unsupported",
                        description=f"KG chain #{u.chain_id} has {len(u.chain_nodes)} nodes "
                                    f"but 0 KB chunks support it",
                        chain_id=u.chain_id,
                        chain_text=u.chain_text,
                        chain_edges=u.chain_edges,
                        suggestion="kg_too_coarse|kb_missing_data",
                    ))

        # ② KB 高分 chunks 不在任何 KG chain 上
        if supplementary:
            top_unanchored = supplementary[:3]
            inconsistencies.append(Inconsistency(
                type="kb_unanchored",
                description=f"{len(supplementary)} high-score KB chunks not anchored on any KG chain",
                chunk_ids=[c.get("chunk_id") for c in top_unanchored],
                paper_ids=list({c.get("paper_id") for c in top_unanchored if c.get("paper_id")}),
                suggestion="kg_too_coarse",
            ))

        # ③ chain 上 overlap 太弱（命中 < min_overlap）
        for u in answer_units:
            if 0 < u.overlap_node_count < min_overlap and u.kb_chunks:
                inconsistencies.append(Inconsistency(
                    type="chain_weak_overlap",
                    description=f"chain #{u.chain_id} only {u.overlap_node_count} nodes overlap "
                                f"(min={min_overlap}), evidence may be insufficient",
                    chain_id=u.chain_id,
                    chain_text=u.chain_text,
                    chunk_ids=[c.get("chunk_id") for c in u.kb_chunks[:3]],
                    suggestion="kg_too_coarse",
                ))
        # ④ user_feedback 由前端注入，本函数不处理

    stats = {
        "n_chains_with_chunks": sum(1 for u in answer_units if u.kb_chunks),
        "n_chains_unsupported": sum(1 for u in answer_units if not u.kb_chunks),
        "n_supplementary": len(supplementary),
        "n_matched_chunks": len(matched_chunk_ids),
        "n_inconsistencies": len(inconsistencies),
        "chain_chunk_ratio": (
            len(matched_chunk_ids) / len(kb_hits) if kb_hits else 0.0
        ),
    }

    return MatchedFrame(
        answer_units=answer_units,
        supplementary_chunks=supplementary,
        inconsistencies=inconsistencies,
        stats=stats,
    )


def _infer_chain_edges(con: sqlite3.Connection, node_ids: List[int]) -> List[str]:
    """对相邻 node 对查 graph_edge.relation_type。"""
    if len(node_ids) < 2:
        return []
    edges: List[str] = []
    for src, dst in zip(node_ids[:-1], node_ids[1:]):
        if src is None or dst is None:
            edges.append("?")
            continue
        r = con.execute(
            """
            SELECT relation_type FROM graph_edge
            WHERE src_node_id=? AND dst_node_id=?
            ORDER BY weight DESC NULLS LAST LIMIT 1
            """,
            (src, dst),
        ).fetchone()
        edges.append(r["relation_type"] if r else "?")
    return edges
