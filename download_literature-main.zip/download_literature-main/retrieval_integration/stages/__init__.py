"""retrieval_integration.stages — v2 重构的新阶段实现。

- bridge.py:  S3 BridgeKGtoKB (softmax 加权动态白名单)
- match.py:   S5 MatchKGKB + 不一致诊断
- render.py:  S6 prompt 片段渲染
- _cluster_naming.py: Cluster 临时显示名（永久方案见 TODO_LIST.md TODO-2）

Stage S0/S1/S2 暂未单独实现，沿用旧 M1 + KGPathAdapter（v2 §6.1 决策点 #2）。
S7 沿用旧 M4+M5+M6。
"""
from .bridge import build_kb_hints_from_kg, KBSearchHints
from .match import match, MatchedFrame, AnswerUnit, Inconsistency
from .render import render_chains_block, render_chunks_block, render_supplementary_block

__all__ = [
    "build_kb_hints_from_kg", "KBSearchHints",
    "match", "MatchedFrame", "AnswerUnit", "Inconsistency",
    "render_chains_block", "render_chunks_block", "render_supplementary_block",
]
