"""S3 BridgeKGtoKB — 把 KG 推演结果转成 KB 检索白名单。

核心算法（v2 审核决策）：
1. 收集 KG 阶段输出的 anchor + expanded prototypes 的 node_id
2. 通过 node_chunk_posting 反查 (chunk_id, paper_id, support_score)
3. **softmax 加权动态白名单**：
   - 对节点的 support_score 做温度 softmax 得到概率分布
   - 按概率累加 / 直接按概率 × budget 取每个节点的 quota
   - 总数封顶在 [whitelist_min, whitelist_max]
4. 配合 EXPECTED_IN（SchemaField→ChunkType）拿到的 chunk_type_filter 进行类型过滤
5. 提取 boost_keywords 给 BM25

输出 KBSearchHints 喂给 S4。
"""
from __future__ import annotations

import logging
import math
import sqlite3
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)


@dataclass
class KBSearchHints:
    """S3 输出，喂给 S4 KBRetrieve。"""
    chunk_id_whitelist: Set[str] = field(default_factory=set)
    chunk_type_filter: Set[str] = field(default_factory=set)
    anchor_papers: List[Tuple[str, float]] = field(default_factory=list)  # (paper_id, anchor_score)
    boost_keywords: List[str] = field(default_factory=list)

    # 诊断信息（供 S5/前端展示）
    debug: Dict[str, Any] = field(default_factory=dict)


@lru_cache(maxsize=1)
def _open(db_path: str) -> sqlite3.Connection:
    con = sqlite3.connect(db_path, check_same_thread=False)
    con.row_factory = sqlite3.Row
    return con


def _softmax(scores: List[float], temperature: float = 1.0) -> List[float]:
    """数值稳定的 softmax。"""
    if not scores:
        return []
    if temperature <= 0:
        temperature = 1.0
    # 减去最大值防溢出
    m = max(scores)
    exps = [math.exp((s - m) / temperature) for s in scores]
    z = sum(exps) or 1.0
    return [e / z for e in exps]


def build_kb_hints_from_kg(
    db_path: Path,
    *,
    anchor_node_ids: List[int],
    expanded_node_ids: List[int],
    entry_field_names: Optional[List[str]] = None,
    # 配置
    total_budget: int = 200,
    whitelist_min: int = 50,
    whitelist_max: int = 500,
    softmax_temperature: float = 1.0,
    per_node_cap: int = 30,
    boost_keyword_top_k: int = 12,
    fetch_pool_per_node: int = 60,
) -> KBSearchHints:
    """
    S3 主入口。

    Args:
        db_path: KG SQLite 路径
        anchor_node_ids: query 直接命中的节点（权重 ×2）
        expanded_node_ids: KG 扩散出的节点
        entry_field_names: query 命中的 SchemaField 名（用于 EXPECTED_IN → chunk_type_filter）
        total_budget: 期望白名单 chunk 总数（实际会按 softmax 加权分配）
        whitelist_min/max: 总数硬边界
        softmax_temperature: 温度参数，>1 平滑（更分散），<1 尖锐（向高分集中）
        per_node_cap: 单个节点最多贡献的 chunk 数（避免一个节点淹没全部预算）
        boost_keyword_top_k: 提取多少个关键词喂 BM25
        fetch_pool_per_node: 每个节点先取多少候选 chunk 再做加权（防候选池过大）

    Returns:
        KBSearchHints
    """
    con = _open(str(db_path))

    # ---- 0. 合并节点权重：anchor ×2, expanded ×1 ----
    node_weights: Dict[int, float] = {}
    for nid in anchor_node_ids or []:
        node_weights[nid] = 2.0
    for nid in expanded_node_ids or []:
        node_weights[nid] = max(node_weights.get(nid, 0.0), 1.0)
    if not node_weights:
        logger.info("S3: no KG nodes provided, returning empty hints")
        return KBSearchHints(debug={"reason": "no_nodes"})

    node_ids = list(node_weights.keys())

    # ---- 1. 拉每个节点的候选 chunks ----
    # node_chunk_posting: node_id → (chunk_id, paper_id, support_score, support_role)
    placeholders = ",".join("?" * len(node_ids))
    sql = f"""
        SELECT node_id, chunk_id, paper_id, support_score, support_role
        FROM node_chunk_posting
        WHERE node_id IN ({placeholders})
    """
    rows = con.execute(sql, node_ids).fetchall()
    # 按 node 分组并截断
    per_node: Dict[int, List[Dict[str, Any]]] = {}
    for r in rows:
        per_node.setdefault(r["node_id"], []).append(dict(r))
    for nid in list(per_node.keys()):
        per_node[nid].sort(key=lambda x: -(x["support_score"] or 0.0))
        per_node[nid] = per_node[nid][:fetch_pool_per_node]

    if not per_node:
        logger.info("S3: nodes have no postings, returning empty hints")
        return KBSearchHints(debug={"reason": "no_postings"})

    # ---- 2. softmax 加权分配每个节点的 chunk quota ----
    # 节点级 score = 节点权重 × 节点 top-K posting 平均 support_score
    node_score: Dict[int, float] = {}
    for nid, items in per_node.items():
        avg_sup = sum(x["support_score"] or 0.0 for x in items) / max(1, len(items))
        node_score[nid] = node_weights[nid] * (1.0 + avg_sup)

    nids_sorted = sorted(node_score.keys(), key=lambda n: -node_score[n])
    scores_sorted = [node_score[n] for n in nids_sorted]
    probs = _softmax(scores_sorted, temperature=softmax_temperature)

    # 每个节点的 quota（至少 1，最多 per_node_cap）
    node_quota: Dict[int, int] = {}
    raw_quotas = [max(1, round(p * total_budget)) for p in probs]
    # 调整 quota 总和靠近 total_budget
    total_raw = sum(raw_quotas)
    if total_raw > 0:
        scale = total_budget / total_raw
        raw_quotas = [max(1, min(per_node_cap, int(round(q * scale)))) for q in raw_quotas]
    for nid, q in zip(nids_sorted, raw_quotas):
        node_quota[nid] = q

    # ---- 3. 选 chunks：按节点取 top-quota，去重 ----
    chunk_pool: Dict[str, Dict[str, Any]] = {}  # chunk_id → record (含最高 support 与原 node)
    for nid in nids_sorted:
        q = node_quota.get(nid, 1)
        for item in per_node[nid][:q]:
            cid = item["chunk_id"]
            prev = chunk_pool.get(cid)
            score = (item["support_score"] or 0.0) * node_weights[nid]
            if (prev is None) or (score > prev["__weighted_score"]):
                chunk_pool[cid] = {
                    **item,
                    "__weighted_score": score,
                    "__from_node_id": nid,
                }

    # ---- 4. chunk_type_filter（来自 entry_field_names 的 EXPECTED_IN）----
    chunk_type_filter: Set[str] = set()
    if entry_field_names:
        field_ph = ",".join("?" * len(entry_field_names))
        type_rows = con.execute(
            f"""
            SELECT DISTINCT ct.canonical_name
            FROM graph_node sf
            JOIN graph_edge e ON e.src_node_id = sf.node_id
                              AND e.relation_type = 'EXPECTED_IN'
            JOIN graph_node ct ON e.dst_node_id = ct.node_id
                              AND ct.node_type = 'ChunkType'
            WHERE sf.canonical_name IN ({field_ph})
              AND sf.node_type = 'SchemaField'
            """,
            entry_field_names,
        ).fetchall()
        chunk_type_filter = {r["canonical_name"] for r in type_rows}

    # ---- 5. 应用 chunk_type_filter 并按 weighted_score 排序 ----
    candidates = list(chunk_pool.values())
    if chunk_type_filter:
        # 需要查每个 chunk 的 chunk_type
        cids = [c["chunk_id"] for c in candidates]
        cid_ph = ",".join("?" * len(cids))
        type_rows = con.execute(
            f"SELECT chunk_id, chunk_type FROM paper_chunk WHERE chunk_id IN ({cid_ph})",
            cids,
        ).fetchall() if cids else []
        cid_to_type = {r["chunk_id"]: r["chunk_type"] for r in type_rows}

        filtered = [c for c in candidates
                    if cid_to_type.get(c["chunk_id"]) in chunk_type_filter]
        # 若过滤后过少，放宽
        if len(filtered) < whitelist_min:
            logger.info(
                "S3: chunk_type filter too tight (%d < %d), expanding",
                len(filtered), whitelist_min,
            )
            extras = [c for c in candidates
                      if cid_to_type.get(c["chunk_id"]) not in chunk_type_filter]
            extras.sort(key=lambda c: -c["__weighted_score"])
            filtered.extend(extras[: whitelist_min - len(filtered)])
        candidates = filtered

    candidates.sort(key=lambda c: -c["__weighted_score"])

    # ---- 6. 边界 ----
    if len(candidates) > whitelist_max:
        candidates = candidates[:whitelist_max]

    chunk_id_whitelist = {c["chunk_id"] for c in candidates}

    # ---- 7. paper-level anchor_score 聚合 ----
    paper_score: Dict[str, float] = {}
    for c in candidates:
        pid = c["paper_id"]
        if pid:
            paper_score[pid] = paper_score.get(pid, 0.0) + c["__weighted_score"]
    anchor_papers = sorted(paper_score.items(), key=lambda kv: -kv[1])

    # ---- 8. boost_keywords：从 expanded prototypes 的 canonical_name 提取 ----
    proto_rows = con.execute(
        f"""
        SELECT canonical_name FROM graph_node
        WHERE node_id IN ({placeholders}) AND node_type='Prototype'
        ORDER BY (SELECT COUNT(*) FROM node_chunk_posting p WHERE p.node_id=graph_node.node_id) DESC
        LIMIT ?
        """,
        node_ids + [boost_keyword_top_k * 2],
    ).fetchall()
    # 简单清洗：太短 / 全数字 / 含标点的丢掉
    boost_keywords = []
    for r in proto_rows:
        n = (r["canonical_name"] or "").strip()
        if len(n) < 4 or n.isdigit():
            continue
        if any(ch in n for ch in "(),:;"):
            continue
        boost_keywords.append(n)
        if len(boost_keywords) >= boost_keyword_top_k:
            break

    hints = KBSearchHints(
        chunk_id_whitelist=chunk_id_whitelist,
        chunk_type_filter=chunk_type_filter,
        anchor_papers=anchor_papers,
        boost_keywords=boost_keywords,
        debug={
            "n_nodes": len(node_ids),
            "n_anchor": len(anchor_node_ids or []),
            "n_expanded": len(expanded_node_ids or []),
            "node_quota_top": dict(list(node_quota.items())[:5]),
            "softmax_temperature": softmax_temperature,
            "total_budget": total_budget,
            "actual_whitelist_size": len(chunk_id_whitelist),
            "n_anchor_papers": len(anchor_papers),
            "n_boost_keywords": len(boost_keywords),
        },
    )
    return hints
