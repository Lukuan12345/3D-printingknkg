"""Cluster naming helper (temporary).

Cluster 节点 (L5) 在当前 KG 中 display_name 全空。
临时方案：用该 Cluster 的 HAS_FIELD 邻居字段名前 N 个拼成可读名。
永久方案见 TODO_LIST.md#TODO-2。
"""
from __future__ import annotations

import sqlite3
from functools import lru_cache
from pathlib import Path
from typing import Dict, List, Optional, Tuple


@lru_cache(maxsize=1)
def _open(db_path: str) -> sqlite3.Connection:
    con = sqlite3.connect(db_path, check_same_thread=False)
    con.row_factory = sqlite3.Row
    return con


@lru_cache(maxsize=256)
def get_cluster_display_name(
    db_path: str,
    cluster_node_id: int,
    max_fields: int = 2,
) -> str:
    """返回形如 'dominant_mechanism + design_method' 的临时显示名。"""
    con = _open(db_path)
    rows = con.execute(
        """
        SELECT n.canonical_name
        FROM graph_edge e
        JOIN graph_node n ON e.dst_node_id = n.node_id
        WHERE e.src_node_id = ?
          AND e.relation_type = 'HAS_FIELD'
        ORDER BY e.weight DESC NULLS LAST
        LIMIT ?
        """,
        (cluster_node_id, max_fields),
    ).fetchall()
    if not rows:
        return f"cluster#{cluster_node_id}"
    return " + ".join(r["canonical_name"] for r in rows)


def get_clusters_for_fields(
    db_path: str, field_names: List[str]
) -> Dict[str, List[Tuple[int, str]]]:
    """
    给一组 SchemaField name，找它们各自所在的 Cluster。
    返回 {field_name: [(cluster_node_id, display_name), ...]}
    """
    if not field_names:
        return {}
    con = _open(db_path)
    placeholders = ",".join("?" * len(field_names))
    rows = con.execute(
        f"""
        SELECT sf.canonical_name AS field_name,
               c.node_id        AS cluster_id,
               c.canonical_name AS cluster_key
        FROM graph_node sf
        JOIN graph_edge e ON e.dst_node_id = sf.node_id
                          AND e.relation_type = 'HAS_FIELD'
        JOIN graph_node c ON e.src_node_id = c.node_id
                          AND c.node_type = 'Cluster'
        WHERE sf.canonical_name IN ({placeholders})
          AND sf.node_type = 'SchemaField'
        """,
        field_names,
    ).fetchall()

    out: Dict[str, List[Tuple[int, str]]] = {}
    for r in rows:
        display = get_cluster_display_name(db_path, r["cluster_id"])
        out.setdefault(r["field_name"], []).append((r["cluster_id"], display))
    return out
