"""S6 helpers — 把 MatchedFrame 渲染成 LLM prompt 片段。

与 [retrieval_integration/modules/kg_context.py](retrieval_integration/modules/kg_context.py) 配套。
此处更结构化，专为 v2 prompt 模板设计。
"""
from __future__ import annotations

from typing import Any, Dict, List


def render_chains_block(answer_units: List[Any], max_chains: int = 6,
                        max_papers_per_chain: int = 2) -> str:
    """渲染 KG chains 段落。"""
    if not answer_units:
        return "(无可用的 KG 推理链)"
    lines: List[str] = []
    for idx, u in enumerate(answer_units[:max_chains]):
        cid = getattr(u, "chain_id", idx)
        text = getattr(u, "chain_text", "") or "(空 chain)"
        edges = getattr(u, "chain_edges", []) or []
        overlap = getattr(u, "overlap_node_count", 0)
        n_chunks = len(getattr(u, "kb_chunks", []) or [])
        n_papers = len(getattr(u, "support_papers", []) or [])
        lines.append(f"### chain #{cid}  (overlap={overlap}, KB chunks={n_chunks}, support papers={n_papers})")
        lines.append(f"  路径: {text}")
        if edges:
            lines.append(f"  关系: {' → '.join(edges)}")
        sp_short = []
        for sp in (u.support_papers or [])[:max_papers_per_chain]:
            t = (sp.get("title") or "").strip()
            if not t: continue
            if len(t) > 70: t = t[:70] + "..."
            yr = sp.get("year")
            sp_short.append(f"《{t}》" + (f"({yr})" if yr else ""))
        if sp_short:
            lines.append(f"  支撑文献候选: {' | '.join(sp_short)}")
        lines.append("")
    return "\n".join(lines)


def render_chunks_block(answer_units: List[Any],
                        supplementary: List[Dict[str, Any]],
                        max_chunks_per_chain: int = 3,
                        max_chars_per_chunk: int = 400) -> str:
    """渲染 KB chunks 段落，按 chain 分组，编号连续。"""
    out_lines: List[str] = []
    counter = 1
    for u in answer_units:
        chunks = getattr(u, "kb_chunks", []) or []
        if not chunks:
            continue
        cid = getattr(u, "chain_id", "?")
        out_lines.append(f"### chain #{cid} 关联的证据:")
        for c in chunks[:max_chunks_per_chain]:
            pid = c.get("paper_id", "")
            title = (c.get("title") or "")[:60]
            ftype = c.get("field_type") or c.get("chunk_type") or ""
            content = (c.get("content") or c.get("text") or "")[:max_chars_per_chunk]
            score = c.get("fused_score") or 0.0
            out_lines.append(
                f"[{counter}] paper={pid} ({title}) · {ftype} · fused={score:.3f}"
            )
            out_lines.append(f"    {content}")
            counter += 1
        out_lines.append("")
    if not out_lines:
        out_lines.append("(无 chain-matched chunks)")
    return "\n".join(out_lines)


def render_supplementary_block(supplementary: List[Dict[str, Any]],
                               max_chunks: int = 5,
                               max_chars: int = 300) -> str:
    if not supplementary:
        return ""
    out = ["## 补充证据（KB 命中但 KG 未关联）"]
    counter = 1000  # 用大编号区分主证据
    for c in supplementary[:max_chunks]:
        pid = c.get("paper_id", "")
        title = (c.get("title") or "")[:60]
        ftype = c.get("field_type") or c.get("chunk_type") or ""
        content = (c.get("content") or c.get("text") or "")[:max_chars]
        out.append(f"[S{counter}] paper={pid} ({title}) · {ftype}")
        out.append(f"    {content}")
        counter += 1
    return "\n".join(out)
