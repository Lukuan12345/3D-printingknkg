#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
cache.py —— LLM Prompt 缓存

简单的 LRU + TTL 内存缓存。
未来可扩展到 Redis / 文件系统后端。
"""

import time
import hashlib
from collections import OrderedDict
from threading import Lock
from typing import Optional


class LLMCache:
    """基于内存的 LRU + TTL 缓存。线程安全。"""

    def __init__(self, max_size: int = 1000, ttl_seconds: int = 3600):
        self.max_size = max_size
        self.ttl_seconds = ttl_seconds
        self._store: "OrderedDict[str, tuple]" = OrderedDict()
        self._lock = Lock()

    @staticmethod
    def make_key(model: str, prompt: str, system_prompt: str = "") -> str:
        """生成缓存 key：基于 (model, system, prompt) 的 sha256。"""
        h = hashlib.sha256()
        h.update(model.encode("utf-8"))
        h.update(b"\0")
        h.update(system_prompt.encode("utf-8"))
        h.update(b"\0")
        h.update(prompt.encode("utf-8"))
        return h.hexdigest()

    def get(self, key: str) -> Optional[str]:
        with self._lock:
            if key not in self._store:
                return None
            value, expires_at = self._store[key]
            if time.time() > expires_at:
                # 过期
                self._store.pop(key, None)
                return None
            # LRU 刷新
            self._store.move_to_end(key)
            return value

    def set(self, key: str, value: str) -> None:
        with self._lock:
            expires_at = time.time() + self.ttl_seconds
            self._store[key] = (value, expires_at)
            self._store.move_to_end(key)
            # 超容量淘汰
            while len(self._store) > self.max_size:
                self._store.popitem(last=False)

    def clear(self) -> None:
        with self._lock:
            self._store.clear()

    def stats(self) -> dict:
        with self._lock:
            return {
                "size": len(self._store),
                "max_size": self.max_size,
                "ttl_seconds": self.ttl_seconds,
            }
