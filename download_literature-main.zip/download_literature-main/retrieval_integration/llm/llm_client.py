#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
llm_client.py —— LLM 统一客户端

封装 kb_mvp / literature_knowledge_extractor 已有的 call_llm，
提供：
1. 按模块自动选择模型（从 config.yaml 读取）
2. Prompt 模板加载（从 prompts.yaml）
3. 自动 JSON 提取与校验
4. 缓存集成
"""

import sys
import json
import re
import yaml
import logging
from pathlib import Path
from typing import Any, Dict, Optional

# 让主项目根可导入（kb_mvp/scientific_kgqa/literature_knowledge_extractor 都在主项目根下）
_RI_ROOT = Path(__file__).resolve().parent.parent
_PROJECT_ROOT = _RI_ROOT.parent  # 主项目根
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from literature_knowledge_extractor.llm_client import call_llm as _raw_call_llm

from ..config import Config, get_config, RI_ROOT, PROJECT_ROOT
from .cache import LLMCache

logger = logging.getLogger(__name__)


# ============================================================
# Prompt 模板加载（全局单例）
# ============================================================

_prompts_cache: Optional[Dict] = None


def _load_prompts() -> Dict:
    """加载 configs/retrieval/prompts.yaml（主项目）。"""
    global _prompts_cache
    if _prompts_cache is None:
        # 优先用主项目下的合并位置，向后兼容老路径
        candidates = [
            PROJECT_ROOT / "configs" / "retrieval" / "prompts.yaml",
            RI_ROOT / "config" / "prompts.yaml",
        ]
        for prompt_path in candidates:
            if prompt_path.exists():
                with open(prompt_path, "r", encoding="utf-8") as f:
                    _prompts_cache = yaml.safe_load(f)
                break
        else:
            raise FileNotFoundError(
                f"prompts.yaml not found in any of: {candidates}"
            )
    return _prompts_cache


def get_prompt(module: str, key: str = "user") -> str:
    """
    获取指定模块的 Prompt 模板。

    Args:
        module: prompts.yaml 中的顶层 key（如 "m1_schema_parser"）
        key:    二级 key（"system" / "user" / "user_state_a" 等）
    """
    prompts = _load_prompts()
    if module not in prompts:
        raise KeyError(f"Module '{module}' not found in prompts.yaml")
    if key not in prompts[module]:
        raise KeyError(f"Prompt key '{key}' not found under '{module}'")
    return prompts[module][key]


# ============================================================
# JSON 提取工具
# ============================================================

def extract_json_from_text(text: str) -> Optional[Dict]:
    """
    从 LLM 文本输出中提取 JSON。
    支持：
    - ```json ... ``` 代码块
    - 裸 JSON
    - 前后带说明文字的 JSON
    """
    if not text:
        return None

    # 1. ```json ... ``` 或 ``` ... ```
    m = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.DOTALL)
    if m:
        try:
            return json.loads(m.group(1))
        except json.JSONDecodeError:
            pass

    # 2. 第一个 { 到最后一个 }
    first = text.find("{")
    last = text.rfind("}")
    if first != -1 and last > first:
        candidate = text[first: last + 1]
        try:
            return json.loads(candidate)
        except json.JSONDecodeError:
            pass

    # 3. 整体直接解析
    try:
        return json.loads(text.strip())
    except json.JSONDecodeError:
        return None


def extract_answer_and_meta(text: str) -> Optional[Dict]:
    """
    解析 M6/direct_answer 的混合输出格式：

        [ANSWER]
        （答案正文，可含 Markdown 和 [1][2] 引用）

        [META]
        {"final_confidence": 0.8, "key_findings": [...], ...}

    返回合并后的 dict，其中 "answer" 为正文字符串。
    若格式不符（缺少 [ANSWER] 或 [META]），尝试回退到 extract_json_from_text。
    """
    if not text:
        return None

    answer_tag = "[ANSWER]"
    meta_tag = "[META]"

    a_pos = text.find(answer_tag)
    m_pos = text.find(meta_tag)

    if a_pos == -1 or m_pos == -1 or m_pos <= a_pos:
        # 标记缺失，回退到旧 JSON 提取（向后兼容）
        return extract_json_from_text(text)

    # 提取答案正文（[ANSWER] 和 [META] 之间）
    answer_text = text[a_pos + len(answer_tag): m_pos].strip()

    # 提取 META 行（[META] 之后的第一个非空行）
    meta_raw = text[m_pos + len(meta_tag):].strip()
    # 只取第一行（防止 LLM 在 JSON 后再输出多余内容）
    meta_line = meta_raw.split("\n")[0].strip()

    meta: Dict[str, Any] = {}
    try:
        meta = json.loads(meta_line)
    except json.JSONDecodeError:
        # META 行解析失败，尝试从整个剩余文本里找 JSON
        fallback = extract_json_from_text(meta_raw)
        if fallback:
            meta = fallback

    result: Dict[str, Any] = {"answer": answer_text}
    result.update(meta)
    return result if answer_text or meta else None


# ============================================================
# LLMClient
# ============================================================

class LLMClient:
    """
    统一 LLM 客户端。

    用法：
        client = LLMClient()
        # 纯文本
        text = client.call(prompt="...", module="m1_parser")
        # JSON
        data = client.call_json(prompt="...", module="m3_validator")
    """

    def __init__(self, config: Optional[Config] = None):
        self.config = config or get_config()

        llm_cfg = self.config.get("llm", {})
        self.base_url = llm_cfg.get("base_url", "")
        # 环境变量优先；若占位符未被替换，使用 fallback
        raw_key = llm_cfg.get("api_key", "")
        if not raw_key or raw_key.startswith("${"):
            raw_key = llm_cfg.get("api_key_fallback", "")
        self.api_key = raw_key

        self.timeout_s = llm_cfg.get("timeout_s", 60)
        self.max_retries = llm_cfg.get("max_retries", 3)
        self.retry_delay_s = llm_cfg.get("retry_delay_s", 2)

        self.models: Dict[str, str] = llm_cfg.get("models", {})
        # max_tokens 配置：模块级 → default → None
        self.max_tokens_cfg: Dict[str, int] = llm_cfg.get("max_tokens", {}) or {}
        # thinking_mode 配置：模块级 → None（= 让底层用默认 True）
        self.thinking_mode_cfg: Dict[str, bool] = llm_cfg.get("thinking_mode", {}) or {}

        # 缓存
        cache_cfg = llm_cfg.get("cache", {})
        self.cache_enabled = cache_cfg.get("enabled", False)
        self.cache = (
            LLMCache(
                max_size=cache_cfg.get("max_size", 1000),
                ttl_seconds=cache_cfg.get("ttl_seconds", 3600),
            )
            if self.cache_enabled
            else None
        )

    # ------------------------------------------------------------
    def _resolve_model(self, module: Optional[str], model: Optional[str]) -> str:
        """按优先级选择模型：显式 model > 模块映射 > 默认 claude-haiku。"""
        if model:
            return model
        if module and module in self.models:
            return self.models[module]
        return self.models.get("default", "claude-haiku-4-5-20251001")

    # ------------------------------------------------------------
    def _resolve_max_tokens(
        self, module: Optional[str], max_tokens: Optional[int]
    ) -> Optional[int]:
        """显式 > 模块级 > default > None（让底层用提供方默认）。"""
        if max_tokens is not None:
            return max_tokens
        if module and module in self.max_tokens_cfg:
            return self.max_tokens_cfg[module]
        return self.max_tokens_cfg.get("default")

    # ------------------------------------------------------------
    def _resolve_thinking_mode(
        self, module: Optional[str], thinking_mode: Optional[bool]
    ) -> Optional[bool]:
        """显式 > 模块级 > None（底层默认 True）。"""
        if thinking_mode is not None:
            return thinking_mode
        if module and module in self.thinking_mode_cfg:
            return self.thinking_mode_cfg[module]
        return self.thinking_mode_cfg.get("default")

    # ------------------------------------------------------------
    def call(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        module: Optional[str] = None,
        model: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        thinking_mode: Optional[bool] = None,
        use_cache: bool = True,
    ) -> Optional[str]:
        """调用 LLM，返回纯文本。"""
        model_name = self._resolve_model(module, model)
        resolved_max_tokens = self._resolve_max_tokens(module, max_tokens)
        resolved_thinking = self._resolve_thinking_mode(module, thinking_mode)

        # 缓存 key 包含 max_tokens 和 thinking_mode，避免配置变化后污染
        cache_key = None
        if self.cache and use_cache:
            cache_key = self.cache.make_key(
                model=f"{model_name}|max_tokens={resolved_max_tokens}|thinking={resolved_thinking}",
                prompt=prompt,
                system_prompt=system_prompt or "",
            )
            cached = self.cache.get(cache_key)
            if cached is not None:
                logger.debug(f"LLM cache hit for model={model_name}")
                return cached

        # 组装底层参数；thinking_mode 仅在显式为 False 时传入（True 是底层默认）
        raw_kwargs = dict(
            prompt=prompt,
            base_url=self.base_url,
            api_key=self.api_key,
            model_name=model_name,
            system_prompt=system_prompt,
            temperature=temperature,
            max_retries=self.max_retries,
            retry_delay=self.retry_delay_s,
            timeout=self.timeout_s,
            max_tokens=resolved_max_tokens,
        )
        if resolved_thinking is not None:
            raw_kwargs["thinking_mode"] = resolved_thinking

        text = _raw_call_llm(**raw_kwargs)

        # 回填缓存
        if self.cache and use_cache and cache_key and text:
            self.cache.set(cache_key, text)

        return text

    # ------------------------------------------------------------
    def call_json(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        module: Optional[str] = None,
        model: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        thinking_mode: Optional[bool] = None,
        use_cache: bool = True,
    ) -> Optional[Dict]:
        """调用 LLM 并自动解析 JSON。失败返回 None。"""
        text = self.call(
            prompt=prompt,
            system_prompt=system_prompt,
            module=module,
            model=model,
            temperature=temperature,
            max_tokens=max_tokens,
            thinking_mode=thinking_mode,
            use_cache=use_cache,
        )
        if not text:
            return None
        return extract_json_from_text(text)


# ============================================================
# 全局单例
# ============================================================

_global_client: Optional[LLMClient] = None


def get_llm_client() -> LLMClient:
    """获取全局 LLM 客户端（懒加载）。"""
    global _global_client
    if _global_client is None:
        _global_client = LLMClient()
    return _global_client
