#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
端到端集成测试

这些测试需要真实的 LLM 和 kb_mvp 索引，
默认 skip；设置环境变量 RI_RUN_E2E=1 才运行。
"""

import os
import sys
import pytest
from pathlib import Path

_RI_PARENT = Path(__file__).resolve().parent.parent.parent.parent
sys.path.insert(0, str(_RI_PARENT))

pytestmark = pytest.mark.skipif(
    os.environ.get("RI_RUN_E2E") != "1",
    reason="需要设置 RI_RUN_E2E=1 启用端到端测试（需要 LLM API 和 kb_mvp 索引）",
)


from retrieval_integration.core.pipeline import RetrievalPipeline


@pytest.fixture(scope="module")
def pipeline():
    return RetrievalPipeline()


def test_type_d_schema_miss(pipeline):
    """Type D: Query 完全不契合 Schema"""
    result = pipeline.run("如何烹饪宫保鸡丁？")
    assert result["exit_reason"] in ("schema_miss", "external_success")
    # 即便走了外部路径，parse_confidence 应该很低
    # 路径至少包含 m1_schema_parser
    assert "m1_schema_parser" in result["execution_path"]


def test_type_a_direct_answer(pipeline):
    """Type A: Query 有内部完整覆盖"""
    result = pipeline.run("FR4基板X波段吸波体的典型介电常数")
    # 接受 direct_answer 或 external（取决于索引实际覆盖度）
    assert result["answer"]
    assert "m1_schema_parser" in result["execution_path"]


def test_pipeline_populates_metrics(pipeline):
    """检查是否产生了 metrics。"""
    result = pipeline.run("测试查询")
    assert result["total_latency_ms"] > 0
    assert len(result["execution_path"]) >= 1


if __name__ == "__main__":
    os.environ["RI_RUN_E2E"] = "1"
    pytest.main([__file__, "-v"])
