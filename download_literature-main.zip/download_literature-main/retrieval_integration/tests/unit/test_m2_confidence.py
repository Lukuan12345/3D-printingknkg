#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""测试模块2的置信度计算。"""
import sys
from pathlib import Path

_RI_PARENT = Path(__file__).resolve().parent.parent.parent.parent
sys.path.insert(0, str(_RI_PARENT))

from retrieval_integration.modules.m2_internal_retrieval.confidence import (
    compute_retrieval_confidence,
)


def test_empty_chunks():
    assert compute_retrieval_confidence([]) == 0.0


def test_top1_strategy():
    chunks = [
        {"fused_score": 0.8},
        {"fused_score": 0.3},
    ]
    assert compute_retrieval_confidence(chunks, strategy="reranker_top1") == 0.8


def test_top3_avg():
    chunks = [
        {"fused_score": 0.9},
        {"fused_score": 0.6},
        {"fused_score": 0.3},
        {"fused_score": 0.1},
    ]
    v = compute_retrieval_confidence(chunks, strategy="reranker_top3_avg")
    assert abs(v - 0.6) < 1e-6


def test_clip_to_01():
    chunks = [{"fused_score": 1.5}, {"fused_score": -0.2}]
    v = compute_retrieval_confidence(chunks, strategy="reranker_top1")
    assert 0.0 <= v <= 1.0


def test_missing_score_key():
    chunks = [{"other_field": 0.5}]
    assert compute_retrieval_confidence(chunks) == 0.0


def test_topk_weighted():
    chunks = [{"fused_score": v} for v in [0.9, 0.8, 0.7]]
    v = compute_retrieval_confidence(chunks, strategy="reranker_topk_weighted")
    # w = [1, 0.5, 0.333]; sum = 1.833
    # val = (0.9 + 0.4 + 0.2333) / 1.833 ≈ 0.8363...
    assert 0.8 <= v <= 0.9


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v"])
