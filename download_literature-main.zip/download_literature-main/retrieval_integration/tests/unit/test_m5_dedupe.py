#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""测试模块5的去重与 API 客户端注册表。"""
import sys
from pathlib import Path

_RI_PARENT = Path(__file__).resolve().parent.parent.parent.parent
sys.path.insert(0, str(_RI_PARENT))

from retrieval_integration.modules.m5_external_retrieval import dedupe_docs
from retrieval_integration.modules.m5_external_retrieval.api_clients import (
    ExternalDoc,
    CLIENT_REGISTRY,
    XingheClient,
    PubMedClient,
    ArxivClient,
    SemanticScholarClient,
    OpenAlexClient,
)


def test_dedupe_by_doi():
    docs = [
        ExternalDoc(title="A", doi="10.1/xyz"),
        ExternalDoc(title="B", doi="10.1/xyz"),  # 同 DOI
        ExternalDoc(title="C", doi="10.1/abc"),
    ]
    out = dedupe_docs(docs)
    assert len(out) == 2
    assert {d.title for d in out} == {"A", "C"}


def test_dedupe_fallback_to_url():
    docs = [
        ExternalDoc(title="A", url="http://x"),
        ExternalDoc(title="B", url="http://x"),  # 同 URL
        ExternalDoc(title="C", url="http://y"),
    ]
    out = dedupe_docs(docs)
    assert len(out) == 2


def test_dedupe_fallback_to_title():
    docs = [
        ExternalDoc(title="Same Title"),
        ExternalDoc(title="Same Title"),
        ExternalDoc(title="Different"),
    ]
    out = dedupe_docs(docs)
    assert len(out) == 2


def test_registry_has_expected_clients():
    """注册表应包含 6 个客户端：星河 API、星河 SQL、arXiv、S2、OpenAlex、PubMed（保留备用）。"""
    expected = {
        "星河图书馆", "星河图书馆SQL",
        "arXiv", "Semantic Scholar", "OpenAlex", "PubMed API",
    }
    assert set(CLIENT_REGISTRY.keys()) == expected

    assert CLIENT_REGISTRY["星河图书馆"] is XingheClient
    assert CLIENT_REGISTRY["arXiv"] is ArxivClient
    assert CLIENT_REGISTRY["Semantic Scholar"] is SemanticScholarClient
    assert CLIENT_REGISTRY["OpenAlex"] is OpenAlexClient
    assert CLIENT_REGISTRY["PubMed API"] is PubMedClient


def test_bing_removed():
    """Bing Search API 已下线（2025-08-11）应彻底移除注册表。"""
    assert "Bing Search API" not in CLIENT_REGISTRY


def test_disabled_client_returns_empty():
    c = XingheClient({"enabled": False})
    assert c.search("test") == []


def test_disabled_s2_returns_empty():
    c = SemanticScholarClient({"enabled": False})
    assert c.search("test") == []


def test_disabled_openalex_returns_empty():
    c = OpenAlexClient({"enabled": False})
    assert c.search("test") == []


def test_external_doc_to_dict():
    d = ExternalDoc(title="X", doi="10.1/y", year=2024)
    out = d.to_dict()
    assert out["title"] == "X"
    assert out["doi"] == "10.1/y"
    assert out["year"] == 2024


# ============================================================
# Boolean → keywords 降级（S2/OpenAlex 共用逻辑）
# ============================================================
def test_s2_boolean_to_keywords():
    from retrieval_integration.modules.m5_external_retrieval.api_clients.semantic_scholar_client import (
        _boolean_to_keywords,
    )
    q = '("metamaterial" OR "absorber") AND ("FR4" OR "PCB")'
    kw = _boolean_to_keywords(q)
    # 不应有运算符 / 括号
    assert "AND" not in kw
    assert "OR" not in kw
    assert "(" not in kw
    # 关键词应保留
    assert "metamaterial" in kw
    assert "absorber" in kw
    assert "FR4" in kw


def test_openalex_inverted_abstract_decode():
    from retrieval_integration.modules.m5_external_retrieval.api_clients.openalex_client import (
        _decode_inverted_abstract,
    )
    inv = {"the": [0, 5], "cat": [1], "is": [2], "happy": [3], "and": [4]}
    text = _decode_inverted_abstract(inv)
    assert text == "the cat is happy and the"


def test_openalex_strip_doi():
    from retrieval_integration.modules.m5_external_retrieval.api_clients.openalex_client import (
        _strip_doi,
    )
    assert _strip_doi("https://doi.org/10.1109/Abc") == "10.1109/abc"
    assert _strip_doi("http://doi.org/10.1/X") == "10.1/x"
    assert _strip_doi("10.1/y") == "10.1/y"
    assert _strip_doi(None) == ""
    assert _strip_doi(123) == ""  # 非字符串不应崩


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v"])
