#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""测试 config_loader."""
import os
import sys
from pathlib import Path

import pytest

_RI_PARENT = Path(__file__).resolve().parent.parent.parent.parent
sys.path.insert(0, str(_RI_PARENT))

from retrieval_integration.config import load_config, Config


def test_load_default():
    cfg = load_config()
    assert isinstance(cfg, Config)
    # M1 阈值：0.6→0.5（2026-05-07）→0.4（2026-05-08）
    assert cfg.get("pipeline.thresholds.m1_parse_confidence") == 0.4
    assert cfg.get("pipeline.thresholds.m2_retrieval_confidence") == 0.55
    # M3 阈值历史 0.7，2026-05-07 下调到 0.5（因 0% direct_answer 率）
    assert cfg.get("pipeline.thresholds.m3_answer_confidence") == 0.5


def test_env_var_substitution(monkeypatch):
    monkeypatch.setenv("TEST_VAR_XYZ", "hello_world")
    # 临时写一个 yaml 用于测试
    import tempfile
    import yaml

    data = {"llm": {"api_key": "${TEST_VAR_XYZ}"}}
    with tempfile.NamedTemporaryFile(
        "w", suffix=".yaml", delete=False, encoding="utf-8"
    ) as f:
        yaml.safe_dump(data, f)
        tmp = f.name

    cfg = load_config(Path(tmp))
    assert cfg.get("llm.api_key") == "hello_world"
    os.unlink(tmp)


def test_dot_notation():
    cfg = load_config()
    # 不存在的 key 返回默认
    assert cfg.get("a.b.c.d", "default") == "default"


def test_overrides():
    cfg = load_config(overrides={"pipeline": {"thresholds": {"m1_parse_confidence": 0.99}}})
    assert cfg.get("pipeline.thresholds.m1_parse_confidence") == 0.99
    # 其他值保留
    assert cfg.get("pipeline.thresholds.m2_retrieval_confidence") == 0.55


def test_resolve_path():
    cfg = load_config()
    p = cfg.resolve_path("data/logs/test.log")
    assert p.is_absolute()
    assert p.name == "test.log"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
