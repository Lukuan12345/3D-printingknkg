#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
A2c：测试 M2 论文标题精确匹配 boost 逻辑
H1（2026-05-10）：补充跨语言（中英）匹配测试

不需要真实 kb_mvp / 真实 embedding API，用 mock adapter 测纯逻辑。
"""
import sys
from pathlib import Path
from unittest.mock import MagicMock

import numpy as np

_RI_PARENT = Path(__file__).resolve().parent.parent.parent.parent
sys.path.insert(0, str(_RI_PARENT))

from retrieval_integration.modules.m2_internal_retrieval.retriever import (
    InternalRetriever,
)


# 30 篇论文的简化标题映射（与 KB 实际格式相近）
_FAKE_PAPERS = [
    ("P001", "一种宽通带低插损的吸透一体频率选择表面"),
    ("P002", "新型吸透一体频率选择表面研究"),
    ("P029", "频率选择表面综述"),
    ("P030", "FSS 设计方法"),
    ("P008", "电磁吸波材料综述"),
]


# H1：模拟真实 KB（英文标题）+ 中文 query 的跨语言场景
_FAKE_PAPERS_EN = [
    ("P001", "A Wide Passband and Low Insertion Loss Frequency-selective Resorber"),
    ("P002", "Research on Novel Frequency Selective Rasorber"),
    ("P029", "Frequency Selective Surfaces: A Review"),
    ("P030", "FSS Design Methods"),
    ("P008", "Electromagnetic Absorbing Materials Review"),
]


def _make_retriever(papers=None):
    """构造一个轻量 retriever，跳过真实初始化。默认 lexical-only 行为，便于复用旧用例。"""
    r = InternalRetriever.__new__(InternalRetriever)
    r.logger = MagicMock()
    r.adapter = MagicMock()
    r.adapter.get_papers_titles.return_value = papers or _FAKE_PAPERS
    # 默认 mock embed_texts 失败 → 自动降级到 lexical（保持旧用例语义）
    r.adapter.embed_texts.side_effect = RuntimeError(
        "embedding API not mocked in this test"
    )
    r._papers_titles_cache = None
    r._title_embeddings_cache = None
    r._semantic_disabled = False
    r.title_boost_enabled = True
    r.title_boost_threshold = 0.7
    r.title_boost_bonus = 0.3
    r.title_boost_min_prefix_len = 8
    r.title_boost_mode = "hybrid"
    r.title_boost_semantic_threshold = 0.55
    r.title_boost_max_candidates = 0  # 默认不封顶，保持旧 12 个用例行为
    # H2 fields - 默认全关，旧用例保持原行为
    r.title_boost_inject_top_n = 0
    r.title_boost_chunk_title_verify = False
    r.title_boost_chunk_title_floor = 0.5
    r.title_boost_paper_level_rerank = False
    # H2d: 分级 bonus —— 默认 flat(factor=1.0) 保持旧用例 bonus 不变
    r.title_boost_rank1_factor = 1.0
    r.title_boost_rank23_factor = 1.0
    r.title_boost_rank4plus_factor = 1.0
    r.top_k = 10
    r.adapter.fetch_chunks_for_papers.return_value = []
    return r


def _set_semantic(r, prefix_to_paper_sims):
    """
    给 retriever 注入语义相似度。

    prefix_to_paper_sims: dict { title_prefix_str: { paper_id: cosine_sim } }
    实现：mock embed_texts 返回归一化向量，让 inner product 等于配置的 sim。
    最简形式：把每篇 paper 编码成 e_i = sim_i * v + sqrt(1-sim_i^2) * u_i，
    其中 v 是 query embedding 方向，u_i 与 v 正交且互不相关。
    实际只要 mock embed_texts，让其顺序返回 [paper_titles_vecs, query_vec]。
    我们用一个更简单的方法：直接控制 embed_texts 返回值。
    """
    # 设计简化向量：query = [1,0,0]; paper_i = [sim_i, sqrt(1-sim_i^2), 0]
    # inner product = sim_i ✓
    papers = r.adapter.get_papers_titles.return_value
    # 我们假设 _set_semantic 被调用时 prefix_to_paper_sims 只含一个 prefix
    assert len(prefix_to_paper_sims) == 1
    prefix, sims_by_pid = next(iter(prefix_to_paper_sims.items()))

    title_vecs = []
    for pid, _t in papers:
        s = sims_by_pid.get(pid, 0.0)
        # clamp
        s = max(-1.0, min(1.0, s))
        ortho = (1.0 - s * s) ** 0.5
        title_vecs.append([s, ortho, 0.0])
    title_vecs = np.array(title_vecs, dtype=np.float32)
    query_vec = np.array([[1.0, 0.0, 0.0]], dtype=np.float32)

    def fake_embed(texts):
        # 标题列表（顺序与 papers 一致）走 title_vecs；其余视为 query
        if len(texts) == len(papers) and texts == [t for _p, t in papers]:
            return title_vecs
        if len(texts) == 1 and texts[0] == prefix:
            return query_vec
        # 兜底：未预期的输入返回零向量（即语义相似度 0）
        return np.zeros((len(texts), 3), dtype=np.float32)

    r.adapter.embed_texts.side_effect = fake_embed


# ============================================================
# _find_boost_papers（lexical 兼容性）
# ============================================================

def test_find_boost_exact_title_match():
    """query 含完整 P001 标题 → 命中 P001。"""
    r = _make_retriever()
    q = "一种宽通带低插损的吸透一体频率选择表面，无耗层采用什么单元结构？"
    boost = r._find_boost_papers(q)
    assert "P001" in boost
    # P002 标题虽含"吸透一体频率选择表面"子串，包含关系也会触发 (sim=0.85)
    # 这是符合预期的：query 提到 P001 时，P002 也是相关的
    assert boost[0] == "P001"  # P001 应排第一（更高匹配度）


def test_find_boost_p002_query():
    r = _make_retriever()
    q = "新型吸透一体频率选择表面研究，提出哪三款 FSR 结构？"
    boost = r._find_boost_papers(q)
    assert "P002" in boost
    assert boost[0] == "P002"


def test_find_boost_no_title_in_query():
    """query 没有标题前缀 → 不 boost。"""
    r = _make_retriever()
    q = "什么是 FSS 的吸收机理？"
    boost = r._find_boost_papers(q)
    assert boost == []


def test_find_boost_short_prefix():
    """前缀过短（<8字）→ 不触发，避免噪声。"""
    r = _make_retriever()
    q = "FSS，怎么设计？"  # "FSS" 只有 3 字
    boost = r._find_boost_papers(q)
    assert boost == []


def test_find_boost_unrelated_title():
    """query 含某个标题，但 KB 中无任何论文匹配 → 空。"""
    r = _make_retriever()
    q = "量子点太阳能电池的光电转换效率优化研究，目前进展如何？"
    boost = r._find_boost_papers(q)
    assert boost == []


def test_find_boost_below_threshold():
    """部分相似但 < threshold → 不命中。"""
    r = _make_retriever()
    r.title_boost_threshold = 0.95  # 收紧到几乎完全匹配
    q = "一种宽通带的吸透频率选择表面"  # 与 P001 标题略有差异
    boost = r._find_boost_papers(q)
    # threshold 0.95 下，sim 0.85（包含触发的）也通不过
    # 但其实"一种宽通带的吸透频率选择表面" 不是 P001 标题的子串
    # SequenceMatcher 也不会到 0.95
    assert "P001" not in boost or len(boost) == 0


# ============================================================
# H1：跨语言（中文 query × 英文 KB 标题）
# ============================================================

def test_cross_lang_semantic_hits_correct_paper():
    """中文 query 标题前缀 + 英文 KB 标题：semantic 分支命中正确论文。"""
    r = _make_retriever(papers=_FAKE_PAPERS_EN)
    prefix = "一种宽通带低插损的吸透一体频率选择表面"  # P001 中文等价
    _set_semantic(r, {prefix: {
        "P001": 0.78,  # 同义高分
        "P002": 0.62,  # 同领域中分（也过 0.55 阈值）
        "P029": 0.40,
        "P030": 0.30,
        "P008": 0.20,
    }})
    q = prefix + "，无耗层采用什么单元结构？"
    boost = r._find_boost_papers(q)
    assert boost[0] == "P001"
    assert "P002" in boost  # 高于 semantic_threshold 0.55
    assert "P008" not in boost  # 0.20 远低于阈值


def test_cross_lang_pure_lexical_misses():
    """对照：纯 lexical 模式下，中文 query × 英文 KB 必然漏。"""
    r = _make_retriever(papers=_FAKE_PAPERS_EN)
    r.title_boost_mode = "lexical"
    q = "一种宽通带低插损的吸透一体频率选择表面，无耗层采用什么单元结构？"
    boost = r._find_boost_papers(q)
    assert boost == []  # 字符级跨语言相似度 ~0


def test_semantic_disabled_falls_back_to_lexical():
    """embedding API 失败 → 关闭语义分支，hybrid 退化到 lexical（中文 query × 中文 KB 仍可命中）。"""
    r = _make_retriever()  # 默认 _FAKE_PAPERS 中文标题；adapter.embed_texts 默认抛异常
    q = "一种宽通带低插损的吸透一体频率选择表面，无耗层采用什么单元结构？"
    boost = r._find_boost_papers(q)
    # 字符级仍能命中 P001
    assert "P001" in boost
    # 后续调用应直接跳过 embedding（_semantic_disabled 已置位），不再触发 adapter
    call_count_before = r.adapter.embed_texts.call_count
    r._find_boost_papers(q)
    assert r.adapter.embed_texts.call_count == call_count_before


def test_semantic_only_mode():
    """mode=semantic 时不走 lexical，只看语义阈值。"""
    r = _make_retriever(papers=_FAKE_PAPERS_EN)
    r.title_boost_mode = "semantic"
    prefix = "一种宽通带低插损的吸透一体频率选择表面"
    _set_semantic(r, {prefix: {"P001": 0.80, "P002": 0.30}})
    q = prefix + "，无耗层采用什么单元结构？"
    boost = r._find_boost_papers(q)
    assert boost == ["P001"]  # P002 < 0.55


def test_hybrid_combines_lex_and_sem():
    """hybrid 模式下：lex 命中 + sem 命中 → 取 max 排序。"""
    r = _make_retriever()  # 中文 KB
    prefix = "一种宽通带低插损的吸透一体频率选择表面"
    # 让 P002 语义分高于其字符级分（包含触发的 0.85），看是否影响排序：
    # 注意 P001 字符级是完全匹配 sim≈1.0，max 仍 ~1.0；P002 字符级 0.85，sem 给 0.95 → max 0.95
    _set_semantic(r, {prefix: {"P001": 0.5, "P002": 0.95}})
    q = prefix + "，问题？"
    boost = r._find_boost_papers(q)
    # P001 仍应排第一（lexical 接近 1.0 > P002 max 0.95）
    assert boost[0] == "P001"
    assert "P002" in boost


def test_title_embeddings_cached_once():
    """整个生命周期内标题 embedding 只批量算一次。"""
    r = _make_retriever(papers=_FAKE_PAPERS_EN)
    prefix = "一种宽通带低插损的吸透一体频率选择表面"
    _set_semantic(r, {prefix: {"P001": 0.8}})
    q = prefix + "，问题？"
    r._find_boost_papers(q)
    r._find_boost_papers(q)
    r._find_boost_papers(q)
    # 标题 batch 调用：只触发 1 次（5 条 papers）
    title_calls = [
        c for c in r.adapter.embed_texts.call_args_list
        if len(c.args[0]) == len(_FAKE_PAPERS_EN)
    ]
    assert len(title_calls) == 1


def test_max_candidates_cap():
    """H1.1: 语义阈值下过多论文通过时，按相似度只保留 top-N。"""
    r = _make_retriever(papers=_FAKE_PAPERS_EN)
    r.title_boost_max_candidates = 2
    prefix = "一种宽通带低插损的吸透一体频率选择表面"
    # 5 篇都超过 0.55 阈值，但只应保留 top-2
    _set_semantic(r, {prefix: {
        "P001": 0.80, "P002": 0.75, "P029": 0.65, "P030": 0.60, "P008": 0.58,
    }})
    q = prefix + "，问题？"
    boost = r._find_boost_papers(q)
    assert boost == ["P001", "P002"]


def test_max_candidates_zero_means_no_cap():
    """max_candidates=0 等价于旧行为（不封顶）。"""
    r = _make_retriever(papers=_FAKE_PAPERS_EN)
    r.title_boost_max_candidates = 0
    prefix = "一种宽通带低插损的吸透一体频率选择表面"
    _set_semantic(r, {prefix: {
        "P001": 0.80, "P002": 0.75, "P029": 0.65, "P030": 0.60, "P008": 0.58,
    }})
    q = prefix + "，问题？"
    boost = r._find_boost_papers(q)
    assert len(boost) == 5


# ============================================================
# H2 (Round 12)：chunk 注入 + chunk×title 验证 + paper-level rerank
# ============================================================

def _embed_returns(text_to_vec):
    """构造 mock embed_texts 函数：按文本查表返回归一化向量。"""
    def fake(texts):
        out = []
        for t in texts:
            v = text_to_vec.get(t)
            if v is None:
                v = [0.0] * 3
            out.append(v)
        return np.array(out, dtype=np.float32)
    return fake


def test_inject_pulls_missing_boost_paper_chunks():
    """H2(a)：boost_papers 中没出现在 top-K 的论文，应被注入它们的 top-N 最佳 chunks。"""
    r = _make_retriever()
    r.title_boost_inject_top_n = 2
    # 当前 top-K 全是 P093（不在 boost）；P001 是 boost target 但缺席
    chunks = [
        {"paper_id": "P093", "chunk_id": "P093_a", "fused_score": 0.9, "content": "P093-a"},
        {"paper_id": "P093", "chunk_id": "P093_b", "fused_score": 0.85, "content": "P093-b"},
    ]
    r.adapter.fetch_chunks_for_papers.return_value = [
        {"paper_id": "P001", "chunk_id": "P001_a", "field_type": "f1", "content": "P001-a"},
        {"paper_id": "P001", "chunk_id": "P001_b", "field_type": "f2", "content": "P001-b"},
        {"paper_id": "P001", "chunk_id": "P001_c", "field_type": "f3", "content": "P001-c"},
    ]
    # 让 P001_a 和 P001_b 的 dense 分高于 P001_c
    r.adapter.embed_texts.side_effect = _embed_returns({
        "P001-a": [0.9, 0.4, 0.0],
        "P001-b": [0.8, 0.6, 0.0],
        "P001-c": [0.3, 0.95, 0.0],
        "kw query": [1.0, 0.0, 0.0],
    })
    out = r._apply_title_boost(chunks, ["P001"], query_text="kw query", title_prefix="")
    pids = [c["paper_id"] for c in out]
    # 注入了 top-2 P001 chunks (a 和 b，排除 c)
    assert pids.count("P001") == 2
    p001_chunk_ids = sorted(c["chunk_id"] for c in out if c["paper_id"] == "P001")
    assert p001_chunk_ids == ["P001_a", "P001_b"]
    # 注入的 chunks 标记 title_injected
    for c in out:
        if c["paper_id"] == "P001":
            assert c.get("title_injected") is True


def test_inject_disabled_when_inject_top_n_zero():
    """inject_top_n=0 → 不注入，旧行为。"""
    r = _make_retriever()
    r.title_boost_inject_top_n = 0
    chunks = [{"paper_id": "P093", "chunk_id": "x", "fused_score": 0.9, "content": ""}]
    out = r._apply_title_boost(chunks, ["P001"], query_text="q", title_prefix="")
    assert all(c["paper_id"] != "P001" for c in out)
    r.adapter.fetch_chunks_for_papers.assert_not_called()


def test_chunk_title_verify_modulates_bonus():
    """H2(b)：chunk×title sim 高的 chunk 得到更大 bonus；低的拿到 floor 兜底。"""
    r = _make_retriever()
    r.title_boost_chunk_title_verify = True
    r.title_boost_chunk_title_floor = 0.5
    r.title_boost_bonus = 0.3
    chunks = [
        {"paper_id": "P001", "chunk_id": "high", "fused_score": 0.5, "content": "core-design"},
        {"paper_id": "P001", "chunk_id": "low", "fused_score": 0.5, "content": "experiment"},
    ]
    title_prefix = "P001 standard title"
    # title 与 core-design 高度相似 (0.9)，与 experiment 几乎无关 (0.1)
    r.adapter.embed_texts.side_effect = _embed_returns({
        "core-design": [0.95, 0.31, 0.0],   # cos with title-vec ≈ 0.95
        "experiment": [0.1, 0.99, 0.0],     # cos ≈ 0.1
        title_prefix: [1.0, 0.0, 0.0],
    })
    out = r._apply_title_boost(
        chunks, ["P001"], query_text="q", title_prefix=title_prefix
    )
    bo = {c["chunk_id"]: c for c in out}
    # high: bonus = 0.3 * max(0.5, 0.95) ≈ 0.285
    assert abs(bo["high"]["title_boost"] - 0.285) < 0.01
    # low: bonus = 0.3 * max(0.5, 0.1) = 0.15 (floor 兜底)
    assert abs(bo["low"]["title_boost"] - 0.15) < 0.01
    # 验证 sim 也透传出来
    assert bo["high"]["title_boost_chunk_title_sim"] > 0.9
    assert bo["low"]["title_boost_chunk_title_sim"] < 0.2


def test_paper_level_rerank_groups_chunks_by_paper():
    """
    H2(c)：boost 后用 paper-level max score 主排序；同一 paper 的 chunks 聚成一团，
    防止 P093 的 5 个 chunks 把 P001 的唯一 chunk 挤出 top-K。
    """
    r = _make_retriever()
    r.title_boost_paper_level_rerank = True
    r.title_boost_chunk_title_verify = False  # 简化：固定 +0.3 bonus
    chunks = [
        {"paper_id": "P093", "chunk_id": "p93_1", "fused_score": 0.90, "content": ""},
        {"paper_id": "P093", "chunk_id": "p93_2", "fused_score": 0.88, "content": ""},
        {"paper_id": "P093", "chunk_id": "p93_3", "fused_score": 0.86, "content": ""},
        {"paper_id": "P001", "chunk_id": "p1_1", "fused_score": 0.62, "content": ""},  # +0.3 → 0.92
        {"paper_id": "P001", "chunk_id": "p1_2", "fused_score": 0.55, "content": ""},  # +0.3 → 0.85
    ]
    out = r._apply_title_boost(chunks, ["P001"], query_text="q", title_prefix="")
    # P001 的 max=0.92 > P093 的 max=0.90，所以 P001 整组排在前面
    assert out[0]["paper_id"] == "P001"
    assert out[1]["paper_id"] == "P001"
    # P093 紧随其后，三个 chunks 按各自 fused_score 排序
    assert all(out[i]["paper_id"] == "P093" for i in range(2, 5))


def test_inject_handles_fetch_failure_gracefully():
    """注入时 SQL/embedding 失败不应中断主流程。"""
    r = _make_retriever()
    r.title_boost_inject_top_n = 2
    r.adapter.fetch_chunks_for_papers.side_effect = RuntimeError("DB error")
    chunks = [{"paper_id": "P093", "chunk_id": "x", "fused_score": 0.9, "content": ""}]
    out = r._apply_title_boost(chunks, ["P001"], query_text="q", title_prefix="")
    # 主流程仍然返回原 chunks，只是没有注入
    assert len(out) == 1
    assert out[0]["paper_id"] == "P093"


def test_top_k_truncation_after_inject():
    """注入会撑大候选池，最后必须截到 self.top_k。"""
    r = _make_retriever()
    r.title_boost_inject_top_n = 5
    r.top_k = 3
    chunks = [
        {"paper_id": f"P09{i}", "chunk_id": f"x{i}", "fused_score": 0.9 - i * 0.05, "content": ""}
        for i in range(3)
    ]
    r.adapter.fetch_chunks_for_papers.return_value = [
        {"paper_id": "P001", "chunk_id": f"P001_{i}", "field_type": "f", "content": f"c{i}"}
        for i in range(5)
    ]
    r.adapter.embed_texts.side_effect = _embed_returns({
        **{f"c{i}": [0.5, 0.5, 0.0] for i in range(5)},
        "q": [1.0, 0.0, 0.0],
    })
    out = r._apply_title_boost(chunks, ["P001"], query_text="q", title_prefix="")
    assert len(out) == 3


# ============================================================
# _apply_title_boost
# ============================================================

def test_apply_boost_lifts_chunks_to_top():
    """boost 让 P001 的 chunk 从 rank 5 跳到 top1。"""
    r = _make_retriever()
    chunks = [
        {"paper_id": "P029", "fused_score": 0.85, "content": "P029-c"},
        {"paper_id": "P030", "fused_score": 0.82, "content": "P030-c"},
        {"paper_id": "P008", "fused_score": 0.78, "content": "P008-c"},
        {"paper_id": "P012", "fused_score": 0.65, "content": "P012-c"},
        {"paper_id": "P001", "fused_score": 0.55, "content": "P001-c"},  # rank 5
    ]
    out = r._apply_title_boost(chunks, ["P001"])
    # P001 的 fused_score = 0.55 + 0.3 = 0.85，与 P029 持平；
    # 排序时 P001 在 P029 前/后取决于 stable sort，但至少进了 top-3
    top3_ids = [c["paper_id"] for c in out[:3]]
    assert "P001" in top3_ids


def test_apply_boost_marks_title_boost_field():
    """被 boost 的 chunk 应标记 title_boost 字段，便于诊断。"""
    r = _make_retriever()
    chunks = [
        {"paper_id": "P001", "fused_score": 0.5},
        {"paper_id": "P029", "fused_score": 0.8},
    ]
    out = r._apply_title_boost(chunks, ["P001"])
    p001 = next(c for c in out if c["paper_id"] == "P001")
    p029 = next(c for c in out if c["paper_id"] == "P029")
    assert p001.get("title_boost") == 0.3
    assert "title_boost" not in p029


def test_apply_boost_no_match_unchanged():
    """boost_papers 为空时 chunks 完全不变。"""
    r = _make_retriever()
    chunks = [{"paper_id": "P029", "fused_score": 0.85}]
    out = r._apply_title_boost(chunks, [])
    assert out[0]["fused_score"] == 0.85
    assert "title_boost" not in out[0]


def test_apply_boost_handles_missing_score():
    """fused_score 缺失或 None 时不抛异常。"""
    r = _make_retriever()
    chunks = [
        {"paper_id": "P001", "fused_score": None},
        {"paper_id": "P002"},  # 缺 fused_score
    ]
    out = r._apply_title_boost(chunks, ["P001", "P002"])
    # 都 boost 到 0.3，不应抛异常
    for c in out:
        assert c["fused_score"] == 0.3


# ============================================================
# 集成：缓存
# ============================================================

def test_papers_titles_cache_loaded_once():
    r = _make_retriever()
    r._get_papers_titles()
    r._get_papers_titles()
    r._get_papers_titles()
    # adapter 只应被调用一次
    assert r.adapter.get_papers_titles.call_count == 1


def test_papers_titles_cache_handles_exception():
    """adapter 异常时不应中断主流程，返回空列表。"""
    r = _make_retriever()
    r.adapter.get_papers_titles.side_effect = RuntimeError("DB error")
    r._papers_titles_cache = None
    titles = r._get_papers_titles()
    assert titles == []
    # 后续调用应直接返回缓存的空列表，不再尝试 adapter
    r._get_papers_titles()
    assert r.adapter.get_papers_titles.call_count == 1


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v"])
