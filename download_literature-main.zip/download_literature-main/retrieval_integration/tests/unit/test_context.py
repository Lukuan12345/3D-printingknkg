#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""测试 core.context 与 core.state."""
import sys
from pathlib import Path

_RI_PARENT = Path(__file__).resolve().parent.parent.parent.parent
sys.path.insert(0, str(_RI_PARENT))

from retrieval_integration.core import RequestContext, State, ExitReason


def test_context_default():
    ctx = RequestContext(query="test")
    assert ctx.query == "test"
    assert ctx.parse_confidence == 0.0
    assert ctx.state is None
    assert ctx.internal_chunks == []


def test_record_module():
    ctx = RequestContext(query="test")
    ctx.record_module("m1", 100.0, jumped=False)
    ctx.record_module("m2", 200.0, jumped=True)
    assert ctx.execution_path == ["m1", "m2"]
    assert ctx.total_latency_ms() == 300.0
    assert ctx.module_metrics["m2"]["jumped"] is True


def test_to_dict_enum_serialization():
    ctx = RequestContext(query="test")
    ctx.state = State.A
    ctx.exit_reason = ExitReason.SCHEMA_MISS
    d = ctx.to_dict()
    assert d["state"] == "A"
    assert d["exit_reason"] == "schema_miss"


def test_to_response():
    ctx = RequestContext(query="test")
    ctx.final_answer = "hello"
    ctx.final_confidence = 0.8
    ctx.record_module("m1", 50.0)
    resp = ctx.to_response()
    assert resp["answer"] == "hello"
    assert resp["final_confidence"] == 0.8
    assert resp["total_latency_ms"] == 50.0
    # 不包含中间数据
    assert "internal_chunks" not in resp


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v"])
