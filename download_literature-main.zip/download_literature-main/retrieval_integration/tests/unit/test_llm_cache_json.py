#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""测试 LLM 缓存与 JSON 提取。"""
import sys
from pathlib import Path

_RI_PARENT = Path(__file__).resolve().parent.parent.parent.parent
sys.path.insert(0, str(_RI_PARENT))

from retrieval_integration.llm import LLMCache, extract_json_from_text


def test_cache_basic():
    cache = LLMCache(max_size=5, ttl_seconds=60)
    k = cache.make_key("model-a", "prompt-x", "sys")
    assert cache.get(k) is None
    cache.set(k, "result")
    assert cache.get(k) == "result"


def test_cache_lru():
    cache = LLMCache(max_size=2, ttl_seconds=60)
    for i in range(3):
        cache.set(f"key{i}", f"val{i}")
    # 超过容量，最旧的 key0 应被淘汰
    assert cache.get("key0") is None
    assert cache.get("key1") == "val1"
    assert cache.get("key2") == "val2"


def test_cache_ttl_expire():
    import time
    cache = LLMCache(max_size=5, ttl_seconds=0)  # 立即过期
    cache.set("k", "v")
    time.sleep(0.01)
    assert cache.get("k") is None


def test_extract_json_from_code_block():
    text = 'some text\n```json\n{"a": 1, "b": "hello"}\n```\nmore text'
    result = extract_json_from_text(text)
    assert result == {"a": 1, "b": "hello"}


def test_extract_json_bare():
    text = '   {"key": "value"}   '
    assert extract_json_from_text(text) == {"key": "value"}


def test_extract_json_with_surrounding_text():
    text = '这是说明。{"k": "v"} 然后是更多说明'
    assert extract_json_from_text(text) == {"k": "v"}


def test_extract_json_invalid():
    assert extract_json_from_text("not json") is None
    assert extract_json_from_text("") is None


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v"])
