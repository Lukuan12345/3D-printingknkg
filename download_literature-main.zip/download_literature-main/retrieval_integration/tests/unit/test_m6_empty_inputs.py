#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""测试模块6的空输入短路逻辑（无需真实 LLM）。"""
import sys
from pathlib import Path
from unittest.mock import MagicMock

_RI_PARENT = Path(__file__).resolve().parent.parent.parent.parent
sys.path.insert(0, str(_RI_PARENT))

from retrieval_integration.core import RequestContext, State
from retrieval_integration.modules.m6_answer_generator import FinalAnswerGenerator

# 符合新混合格式的 mock LLM 输出（含新评分字段）
_MOCK_ANSWER = (
    "[ANSWER]\nfake answer\n\n"
    '[META]\n{"factual_grounding": 0.7, "factual_reason": "based on chunks", '
    '"completeness": 0.7, "completeness_reason": "covers core question", '
    '"key_findings": ["a"], "references": [], "conflicts": [], "limitations": ""}'
)


def _make_generator():
    g = FinalAnswerGenerator.__new__(FinalAnswerGenerator)
    g.config = MagicMock()
    g.config.get.return_value = 0.85
    g.logger = MagicMock()
    g.llm = MagicMock()
    # 现在 generator.py 用 llm.call()，不再用 llm.call_json()
    g.llm.call.return_value = None  # 默认模拟 LLM 失败
    g.max_docs = 15
    g.max_chars_per_doc = 1000
    g.hq_threshold = 0.85
    g.backflow_enabled = False
    return g


def test_short_circuit_when_both_empty():
    """内部+外部都空 → 跳过 LLM，给诊断信息。"""
    g = _make_generator()
    ctx = RequestContext(query="test query")
    ctx.state = State.A
    ctx.internal_chunks = []
    ctx.external_docs = []

    result = g._run(ctx)

    # LLM 不应被调用
    assert g.llm.call.call_count == 0
    # 应给出诊断答案
    assert "未获得任何参考资料" in result.final_answer
    assert result.final_confidence == 0.0
    # 应有警告
    assert any("内外资料均为空" in w for w in result.warnings) or \
           any("跳过 LLM" in w for w in result.warnings)


def test_no_short_circuit_when_internal_present():
    """有内部 chunks → 走 LLM 路径（即便外部空）。"""
    g = _make_generator()
    g.llm.call.return_value = _MOCK_ANSWER
    ctx = RequestContext(query="test")
    ctx.state = State.B
    ctx.internal_chunks = [{"title": "P001", "content": "..."}]
    ctx.external_docs = []

    result = g._run(ctx)

    assert g.llm.call.call_count == 1
    assert result.final_answer == "fake answer"


def test_no_short_circuit_when_external_present():
    """有外部 docs → 走 LLM 路径（即便内部空）。"""
    g = _make_generator()
    g.llm.call.return_value = _MOCK_ANSWER
    ctx = RequestContext(query="test")
    ctx.state = State.A
    ctx.internal_chunks = []
    ctx.external_docs = [{"title": "Paper X", "abstract": "..."}]

    result = g._run(ctx)

    assert g.llm.call.call_count == 1
    # final_confidence 由 scorer 计算：有 1 篇外部 → source_score=0.3 → conf > 0
    assert result.final_confidence > 0


def test_diagnostic_message_includes_state():
    """诊断信息应包含路由状态。"""
    g = _make_generator()
    ctx = RequestContext(query="test")
    ctx.state = State.A
    ctx.missing_aspects = ["缺失主题1", "缺失主题2"]

    result = g._run(ctx)
    assert "状态: A" in result.final_answer
    assert "缺失主题1" in result.final_answer


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v"])
