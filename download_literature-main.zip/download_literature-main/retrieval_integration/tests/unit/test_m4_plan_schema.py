#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""测试模块4的 plan_schema 校验与兜底。"""
import sys
from pathlib import Path

_RI_PARENT = Path(__file__).resolve().parent.parent.parent.parent
sys.path.insert(0, str(_RI_PARENT))

from retrieval_integration.modules.m4_plan_generator.plan_schema import (
    validate_search_plan,
    ensure_default_plan,
)


def test_validate_complete_plan():
    plan = {
        "query_rewrites": {
            "core_entities": [],
            "boolean_query": "x",
            "keywords_expand": [],
            "dual_track_queries": {"strict_query": "x", "expansive_query": "y"},
        },
        "source_priority": {"target_apis": ["星河图书馆"]},
    }
    assert validate_search_plan(plan) == []


def test_validate_missing_fields():
    plan = {"query_rewrites": {"boolean_query": "x"}}
    missing = validate_search_plan(plan)
    assert "query_rewrites.core_entities" in missing
    assert "query_rewrites.dual_track_queries.strict_query" in missing
    assert "source_priority.target_apis" in missing


def test_ensure_default_plan_empty():
    plan = ensure_default_plan({}, query="test_query", default_apis=["星河图书馆"])
    assert plan["query_rewrites"]["boolean_query"] == '"test_query"'
    assert plan["source_priority"]["target_apis"] == ["星河图书馆"]
    # 校验应通过
    assert validate_search_plan(plan) == []


def test_ensure_default_plan_preserves_existing():
    original = {
        "query_rewrites": {"boolean_query": "EXISTING"},
        "source_priority": {"target_apis": ["arXiv"]},
    }
    plan = ensure_default_plan(original, "q", ["星河图书馆"])
    assert plan["query_rewrites"]["boolean_query"] == "EXISTING"
    assert plan["source_priority"]["target_apis"] == ["arXiv"]


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v"])
