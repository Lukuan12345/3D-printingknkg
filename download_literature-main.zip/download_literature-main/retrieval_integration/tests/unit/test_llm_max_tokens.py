#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""测试 LLMClient 的 max_tokens 解析逻辑（不真实调用）。"""
import sys
from pathlib import Path
from unittest.mock import MagicMock

_RI_PARENT = Path(__file__).resolve().parent.parent.parent.parent
sys.path.insert(0, str(_RI_PARENT))

from retrieval_integration.config import load_config
from retrieval_integration.llm.llm_client import LLMClient


def _client_with_max_tokens(mt_cfg):
    """构造一个 LLMClient，指定 max_tokens_cfg（绕过 default_config 合并）。"""
    c = LLMClient.__new__(LLMClient)
    c.config = MagicMock()
    c.base_url = ""
    c.api_key = ""
    c.timeout_s = 60
    c.max_retries = 3
    c.retry_delay_s = 2
    c.models = {}
    c.max_tokens_cfg = mt_cfg
    c.cache_enabled = False
    c.cache = None
    return c


def test_max_tokens_explicit_wins():
    """显式参数 > 模块级 > default。"""
    c = _client_with_max_tokens({"default": 1000, "m6_generator": 16384})
    assert c._resolve_max_tokens(module="m6_generator", max_tokens=999) == 999


def test_max_tokens_module_level():
    """无显式参数时返回模块级配置。"""
    c = _client_with_max_tokens({"default": 1000, "m6_generator": 16384})
    assert c._resolve_max_tokens(module="m6_generator", max_tokens=None) == 16384


def test_max_tokens_falls_back_to_default():
    """模块未配置时回退到 default。"""
    c = _client_with_max_tokens({"default": 4096, "m6_generator": 16384})
    assert c._resolve_max_tokens(module="unknown_module", max_tokens=None) == 4096


def test_max_tokens_none_when_unconfigured():
    """完全未配置时返回 None（让底层使用提供方默认）。"""
    c = _client_with_max_tokens({})
    assert c._resolve_max_tokens(module="m6_generator", max_tokens=None) is None


def test_default_config_has_max_tokens():
    """默认配置应包含 max_tokens 防止截断。"""
    cfg = load_config()
    assert cfg.get("llm.max_tokens.default") is not None
    # M6 应明显大于 default（最终答案最长）
    m6 = cfg.get("llm.max_tokens.m6_generator", 0)
    default = cfg.get("llm.max_tokens.default", 0)
    assert m6 >= default
    # M1/M3 短输出，应小于等于 default
    assert cfg.get("llm.max_tokens.m1_parser", 0) <= default


def test_real_client_loads_max_tokens_from_config():
    """LLMClient 用默认 config 时能正确读取 max_tokens 配置。"""
    cfg = load_config()
    c = LLMClient(cfg)
    # 应该读到默认 config 里的 m6_generator
    expected_m6 = cfg.get("llm.max_tokens.m6_generator")
    assert c._resolve_max_tokens(module="m6_generator", max_tokens=None) == expected_m6


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v"])
