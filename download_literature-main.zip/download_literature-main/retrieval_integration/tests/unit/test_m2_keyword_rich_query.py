#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
F3 + A2: 测试 M2 adapter 的 _build_keyword_rich_query() 与 _extract_paper_title() 逻辑

不涉及实际 LLM / kb_mvp 调用。
"""
import sys
from pathlib import Path

_RI_PARENT = Path(__file__).resolve().parent.parent.parent.parent
sys.path.insert(0, str(_RI_PARENT))

from retrieval_integration.modules.m2_internal_retrieval.retriever import (
    InternalRetriever,
)


_build = InternalRetriever._build_keyword_rich_query  # 静态方法
_extract_title = InternalRetriever._extract_paper_title


# ============================================================
# A2: _extract_paper_title 测试
# ============================================================

def test_extract_title_chinese_comma():
    """中文逗号分隔的 golden_qa 格式。"""
    q = "一种宽通带低插损的吸透一体频率选择表面，无耗层采用什么单元结构？"
    assert _extract_title(q) == "一种宽通带低插损的吸透一体频率选择表面"


def test_extract_title_english_comma():
    """英文逗号分隔的格式。"""
    q = "Novel FSS absorber design, what is the unit structure?"
    assert _extract_title(q) == "Novel FSS absorber design"


def test_extract_title_no_comma():
    """无逗号时返回空字符串。"""
    assert _extract_title("what is the absorption rate?") == ""


def test_extract_title_short_prefix_ignored():
    """逗号前太短（<6字）的不算标题。"""
    assert _extract_title("FSS，问题") == ""


def test_extract_title_empty():
    assert _extract_title("") == ""


# ============================================================
# A2: 论文标题前置到 BM25 query 中
# ============================================================

def test_title_prepended_before_keywords():
    """A2: 论文标题应出现在关键词之前（parts 顺序）。"""
    q = "一种宽通带低插损的吸透一体频率选择表面，无耗层采用什么单元结构？"
    structured = {"core_topic": "FSS 吸透一体", "search_keywords_cn": ["吸波", "透波"]}
    result = _build(q, structured)
    title_idx = result.find("一种宽通带低插损的吸透一体频率选择表面")
    core_idx = result.find("FSS 吸透一体")
    assert title_idx != -1, "论文标题应在 query 中"
    assert title_idx < core_idx, "论文标题应前置于 core_topic"


def test_title_improves_per_paper_recall():
    """A2 核心场景：含标题的 query 包含了该论文独特内容的上下文。"""
    q = "新型吸透一体频率选择表面研究，有源 FSR 如何实现天线带内隐身？"
    structured = {"core_topic": "FSS 吸透一体", "search_keywords_cn": ["PIN 二极管"]}
    result = _build(q, structured)
    assert "新型吸透一体频率选择表面研究" in result


def test_no_title_query_still_works():
    """没有论文标题的普通 query，不影响 keywords 组装。"""
    q = "什么是 FSS 的吸收机理？"
    structured = {"core_topic": "FSS 吸波", "search_keywords_cn": ["吸收机理"]}
    result = _build(q, structured)
    assert "FSS 吸波" in result
    assert "吸收机理" in result


# ============================================================
# 原有测试（保留）
# ============================================================

def test_core_topic_plus_keywords():
    """core_topic + 关键词 → 紧凑 query。"""
    structured = {
        "core_topic": "FR4基板X波段吸波体",
        "search_keywords_cn": ["吸波体", "FR4基板", "极化不敏感"],
        "search_keywords_en": ["absorber", "FR4"],
        "operating_frequency_range": "8-12 GHz",
    }
    result = _build("原始长 query", structured)
    assert "FR4基板X波段吸波体" in result
    assert "吸波体" in result
    assert "absorber" in result
    assert "8-12 GHz" in result


def test_deduplication_exact_part_match():
    """完全相等的 part 字符串应去重为 1 个（part 级 dedup，非 token 级）。"""
    structured = {
        "search_keywords_cn": ["FSS", "FSS", "FSS"],
        "substrate_material": ["FSS"],
    }
    result = _build("q", structured)
    assert result.split().count("FSS") == 1


def test_deduplication_is_part_level_not_token_level():
    """注意：dedup 是整个 part 字符串相等才算重复，不拆 token。"""
    structured = {
        "core_topic": "FR4 吸波体",
        "search_keywords_cn": ["FR4"],
    }
    result = _build("q", structured)
    assert result.split().count("FR4") == 2


def test_empty_structured_falls_back():
    """structured 完全空 → 退回原始 query。"""
    assert _build("原始查询", {}) == "原始查询"
    assert _build("原始查询", {"core_topic": ""}) == "原始查询"


def test_no_core_topic_still_useful():
    """没有 core_topic 但有关键词 → 拼接关键词。"""
    structured = {
        "search_keywords_cn": ["极化不敏感", "吸波体"],
    }
    result = _build("fallback", structured)
    assert "极化不敏感" in result
    assert "吸波体" in result


def test_max_chars_truncation():
    """过长应截断。"""
    structured = {
        "core_topic": "a" * 100,
        "search_keywords_cn": ["b" * 100],
        "search_keywords_en": ["c" * 100],
    }
    result = _build("q", structured, max_chars=50)
    assert len(result) <= 50


def test_ignores_non_list_non_string():
    """非 list / str 字段应被忽略，不抛异常。"""
    structured = {
        "core_topic": "topic",
        "search_keywords_cn": None,
        "something_weird": {"nested": "value"},
        "another": 42,
    }
    result = _build("q", structured)
    assert result == "topic"


def test_ignores_empty_strings_in_list():
    """list 中空字符串应被跳过。"""
    structured = {
        "core_topic": "topic",
        "search_keywords_cn": ["valid", "", "  "],
    }
    result = _build("q", structured)
    parts = result.split()
    assert "" not in parts


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v"])
