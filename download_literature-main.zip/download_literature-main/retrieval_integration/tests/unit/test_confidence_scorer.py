#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""测试 confidence_scorer 的加权计算逻辑。"""
import sys
from pathlib import Path

_RI_PARENT = Path(__file__).resolve().parent.parent.parent.parent
sys.path.insert(0, str(_RI_PARENT))

from retrieval_integration.modules.confidence_scorer import (
    compute_source_score,
    compute_coverage_score,
    compute_final_confidence,
)


# ── source_score ────────────────────────────────────────────
def test_source_high_internal_and_external():
    assert compute_source_score(0.7, 10, 6) == 1.0

def test_source_high_internal_no_external():
    assert compute_source_score(0.7, 10, 0) == 0.7

def test_source_mid_internal_many_external():
    assert compute_source_score(0.5, 5, 5) == 0.7

def test_source_mid_internal_no_external():
    assert compute_source_score(0.5, 5, 0) == 0.5

def test_source_low_internal_some_external():
    assert compute_source_score(0.2, 5, 3) == 0.3

def test_source_low_internal_many_external():
    assert compute_source_score(0.0, 0, 5) == 0.4

def test_source_all_empty():
    assert compute_source_score(0.0, 0, 0) == 0.0

def test_source_low_internal_no_external():
    assert compute_source_score(0.3, 5, 0) == 0.1


# ── coverage_score ───────────────────────────────────────────
def test_coverage_full():
    assert compute_coverage_score(["a", "b"], []) == 1.0

def test_coverage_half():
    assert compute_coverage_score(["a"], ["b"]) == 0.5

def test_coverage_none():
    assert compute_coverage_score([], ["a", "b"]) == 0.0

def test_coverage_m3_not_run():
    assert compute_coverage_score([], []) == 0.0


# ── compute_final_confidence ─────────────────────────────────
def test_final_perfect():
    # 完美情况：内部命中好 + 外部 5 篇 + LLM 全满分
    score = compute_final_confidence(0.8, 10, 5, ["a","b","c"], ["d"], 1.0, 1.0)
    # source=1.0×0.4 + coverage=0.75×0.3 + 1.0×0.2 + 1.0×0.1 = 0.4+0.225+0.2+0.1=0.925
    assert 0.9 < score <= 1.0

def test_final_p001_q4_like():
    """P001-Q4 情景：内部中等，无外部，covered=5 missing=5，LLM 较高。"""
    score = compute_final_confidence(
        retrieval_confidence=0.553,
        n_internal_chunks=10,
        n_external_docs=0,
        covered_aspects=["a","b","c","d","e"],
        missing_aspects=["f","g","h","i","j"],
        factual_grounding=0.7,
        completeness=0.6,
    )
    # source=0.5×0.4=0.20 + coverage=0.5×0.3=0.15 + 0.7×0.2=0.14 + 0.6×0.1=0.06 = 0.55
    assert 0.50 <= score <= 0.60, f"expected ~0.55, got {score}"

def test_final_p001_q2_like():
    """P001-Q2 情景：State A，无内部，外部 1 篇，M3 未运行。"""
    score = compute_final_confidence(
        retrieval_confidence=0.0,
        n_internal_chunks=0,
        n_external_docs=1,
        covered_aspects=[],
        missing_aspects=[],
        factual_grounding=0.2,
        completeness=0.2,
    )
    # source=0.3×0.4=0.12 + coverage=0×0.3=0 + 0.2×0.2=0.04 + 0.2×0.1=0.02 = 0.18
    assert score < 0.30, f"should be low, got {score}"

def test_final_both_empty():
    score = compute_final_confidence(0.0, 0, 0, [], [], 0.0, 0.0)
    assert score == 0.0

def test_final_clips_to_1():
    score = compute_final_confidence(1.0, 20, 20, ["a"]*10, [], 1.0, 1.0)
    assert score <= 1.0


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v"])
