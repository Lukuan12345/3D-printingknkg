#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""测试模块1的 confidence 工具函数。"""
import sys
from pathlib import Path

_RI_PARENT = Path(__file__).resolve().parent.parent.parent.parent
sys.path.insert(0, str(_RI_PARENT))

from retrieval_integration.modules.m1_schema_parser.confidence import (
    keyword_overlap_ratio,
    keyword_hit_count,
    normalize_confidence,
)


def test_overlap_empty():
    assert keyword_overlap_ratio("", ["a", "b"]) == 0.0
    assert keyword_overlap_ratio("text", []) == 0.0


def test_overlap_hit():
    q = "FR4 substrate material X-band absorber"
    keywords = ["FR4", "substrate", "吸波体"]
    ratio = keyword_overlap_ratio(q, keywords)
    # FR4, substrate 命中，共 2/3
    assert abs(ratio - 2 / 3) < 1e-6


def test_overlap_no_hit():
    q = "cooking recipes"
    keywords = ["FR4", "substrate"]
    assert keyword_overlap_ratio(q, keywords) == 0.0


# ───── keyword_hit_count（新预筛核心）────────────────────────
def test_hit_count_empty():
    assert keyword_hit_count("", ["a", "b"]) == 0
    assert keyword_hit_count("text", []) == 0


def test_hit_count_basic():
    q = "FR4 substrate material X-band absorber"
    assert keyword_hit_count(q, ["FR4", "substrate", "吸波体"]) == 2


def test_hit_count_no_match():
    assert keyword_hit_count("cooking recipes", ["FR4", "substrate"]) == 0


def test_hit_count_chinese_query_ok():
    """中文 Query 命中中文 schema 关键词。"""
    q = "设计一款 X 波段 吸波体 工作在 8-12 GHz, 基于 FR4 基板"
    keywords = ["吸波体", "频段", "FR4", "无关词"]
    # 至少命中 吸波体 + FR4 = 2（新版用 bigram 可能多算几个，这里只断言下限）
    assert keyword_hit_count(q, keywords) >= 2


def test_hit_count_large_schema_does_not_dilute():
    """命中数语义不会被 schema 大小稀释（修复历史 bug）。"""
    big_schema = ["x"] * 280 + ["FR4", "absorber"]
    q = "FR4 absorber design"
    # 比例: 2/282 ≈ 0.007 远低于历史阈值 0.05
    # 但命中数 = 2 > 1（修复后默认阈值）
    assert keyword_hit_count(q, big_schema) == 2
    assert keyword_overlap_ratio(q, big_schema) < 0.01


def test_hit_count_compound_schema_field():
    """
    schema 字段是复合词（operating_frequency_range），
    自然语言 query 不会原样出现这种字段名，应靠 token 拆分匹配。
    （历史 bug：旧字符串包含匹配下永远 0 命中）
    """
    keywords = [
        "operating_frequency_range",
        "substrate_material",
        "工作频率范围",
        "基底/基板材料",
    ]
    # 英文：query 含 substrate
    assert keyword_hit_count("X-band absorber with FR4 substrate", keywords) >= 1
    # CJK 双向子串：query "基板" ⊂ schema "基底/基板材料"
    assert keyword_hit_count("FR4 基板设计", keywords) >= 1
    # CJK bigram：query "频率范围" 与 schema "工作频率范围" 共享 bigram
    assert keyword_hit_count("8-12 GHz 频率范围", keywords) >= 1


def test_hit_count_off_topic_query():
    """完全无关的 query 应得 0 hits。"""
    keywords = ["operating_frequency_range", "substrate_material", "吸波体"]
    assert keyword_hit_count("如何烹饪宫保鸡丁", keywords) == 0
    assert keyword_hit_count("today's weather", keywords) == 0


# ───── normalize_confidence ──────────────────────────────
def test_normalize_confidence_clip():
    assert normalize_confidence(1.5) == 1.0
    assert normalize_confidence(-0.2) == 0.0
    assert normalize_confidence(0.5) == 0.5


def test_normalize_confidence_invalid():
    assert normalize_confidence(None) == 0.0
    assert normalize_confidence("abc") == 0.0


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v"])
