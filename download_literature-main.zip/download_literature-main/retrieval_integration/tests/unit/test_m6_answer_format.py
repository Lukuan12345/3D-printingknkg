#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
测试 extract_answer_and_meta —— M6/direct_answer 混合输出格式解析器。

格式规范：
    [ANSWER]
    （答案正文，可含 Markdown）

    [META]
    {"final_confidence": 0.8, "key_findings": [...], "references": [...]}
"""
import sys
from pathlib import Path

_RI_PARENT = Path(__file__).resolve().parent.parent.parent.parent
sys.path.insert(0, str(_RI_PARENT))

from retrieval_integration.llm import extract_answer_and_meta


# ============================================================
# 正常格式
# ============================================================

def test_standard_format():
    """标准两段式，包含所有字段。"""
    text = (
        "[ANSWER]\n"
        "该 FSR 结构的设计目标是实现低频吸收、高频透过 [1]。\n\n"
        "[META]\n"
        '{"final_confidence": 0.72, "key_findings": ["低频吸收", "高频透过"], '
        '"references": [{"index": 1, "title": "FSS论文", "url_or_doi": "https://arxiv.org/1"}], '
        '"conflicts": [], "limitations": "仅基于内部知识库"}'
    )
    result = extract_answer_and_meta(text)
    assert result is not None
    assert "低频吸收、高频透过" in result["answer"]
    assert result["final_confidence"] == 0.72
    assert result["key_findings"] == ["低频吸收", "高频透过"]
    assert len(result["references"]) == 1
    assert result["conflicts"] == []


def test_answer_with_markdown():
    """答案正文含 Markdown 标题和列表，不影响解析。"""
    text = (
        "[ANSWER]\n"
        "## 等效电路分析\n\n"
        "无耗层等效为 LC 谐振，如下所示：\n"
        "- 无耗层：并联 LC（Zp1）\n"
        "- 损耗层：串联 RLC（Zr1）\n\n"
        "[META]\n"
        '{"final_confidence": 0.55, "key_findings": ["LC谐振"], "references": []}'
    )
    result = extract_answer_and_meta(text)
    assert result is not None
    assert "## 等效电路分析" in result["answer"]
    assert result["final_confidence"] == 0.55


def test_meta_only_required_fields():
    """META 只包含 final_confidence 和 key_findings（最小 direct_answer 格式）。"""
    text = (
        "[ANSWER]\n"
        "主要设计目标是宽带低插损。\n\n"
        "[META]\n"
        '{"final_confidence": 0.68, "key_findings": ["宽带低插损"]}'
    )
    result = extract_answer_and_meta(text)
    assert result is not None
    assert result["final_confidence"] == 0.68
    assert "references" not in result or result.get("references") is None


def test_meta_json_with_extra_whitespace():
    """META 行前后有空行不影响解析。"""
    text = "[ANSWER]\n答案文本\n\n[META]\n\n" \
           '{"final_confidence": 0.5, "key_findings": []}\n\n'
    result = extract_answer_and_meta(text)
    assert result is not None
    assert result["final_confidence"] == 0.5


# ============================================================
# 边界情况
# ============================================================

def test_meta_json_broken_falls_back_gracefully():
    """META 的 JSON 不合法时，answer 仍然被提取，meta 字段为空。"""
    text = (
        "[ANSWER]\n"
        "有效的答案文本。\n\n"
        "[META]\n"
        "这不是 JSON"
    )
    result = extract_answer_and_meta(text)
    assert result is not None
    assert result["answer"] == "有效的答案文本。"
    # META 解析失败时没有结构化字段，但不应抛异常
    assert "final_confidence" not in result or result.get("final_confidence") is None


def test_missing_answer_tag_falls_back_to_json():
    """缺少 [ANSWER] 标记时，回退到旧 JSON 提取路径。"""
    text = '{"answer": "旧格式答案", "final_confidence": 0.6}'
    result = extract_answer_and_meta(text)
    assert result is not None
    assert result["answer"] == "旧格式答案"
    assert result["final_confidence"] == 0.6


def test_missing_meta_tag_falls_back_to_json():
    """缺少 [META] 标记时，回退到旧 JSON 提取路径。"""
    text = '[ANSWER]\n答案文本\n{"final_confidence": 0.5}'
    result = extract_answer_and_meta(text)
    # [META] 缺失，应尝试 JSON 回退
    assert result is not None


def test_empty_input_returns_none():
    assert extract_answer_and_meta("") is None
    assert extract_answer_and_meta(None) is None


def test_answer_whitespace_stripped():
    """正文前后空白应被 strip。"""
    text = "[ANSWER]\n\n  答案文本  \n\n[META]\n{}"
    result = extract_answer_and_meta(text)
    assert result["answer"] == "答案文本"


def test_meta_after_extra_content_ignored():
    """[META] 行之后若 LLM 多输出了内容，只取第一行 JSON。"""
    text = (
        "[ANSWER]\n答案\n[META]\n"
        '{"final_confidence": 0.7}\n'
        "这是 LLM 多余输出的文字，不应影响结果\n"
    )
    result = extract_answer_and_meta(text)
    assert result is not None
    assert result["final_confidence"] == 0.7


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v"])
