#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""星河 ROS API 客户端单元测试：
- 布尔查询串解析
- 查询体构造（搜索条件 + 过滤条件）
- meta / content 合并去重
- 无 key 时的降级
"""

import sys
from pathlib import Path

import pytest

_RI_PARENT = Path(__file__).resolve().parent.parent.parent.parent
sys.path.insert(0, str(_RI_PARENT))

from retrieval_integration.modules.m5_external_retrieval.api_clients.xinghe_client import (
    XingheClient,
    parse_boolean_query,
    _build_body,
    _build_search_condition,
    _extract_year,
    _split_authors,
)


# ------------------------------------------------------------------
# parse_boolean_query
# ------------------------------------------------------------------
class TestParseBooleanQuery:

    def test_m4_style_and_of_or(self):
        q = '("frequency selective surface" OR "FSS") AND ("wideband")'
        out = parse_boolean_query(q)
        assert out == [["frequency selective surface", "FSS"], ["wideband"]]

    def test_simple_quoted_and(self):
        q = '"a" AND "b" AND "c"'
        assert parse_boolean_query(q) == [["a"], ["b"], ["c"]]

    def test_semicolon_bare_words(self):
        q = "a; b c"
        assert parse_boolean_query(q) == [["a"], ["b", "c"]]

    def test_empty(self):
        assert parse_boolean_query("") == []
        assert parse_boolean_query("   ") == []

    def test_plain_bare_words(self):
        assert parse_boolean_query("alpha") == [["alpha"]]
        # 纯空格 AND 连接
        out = parse_boolean_query("alpha AND beta")
        assert out == [["alpha"], ["beta"]]


# ------------------------------------------------------------------
# _build_search_condition
# ------------------------------------------------------------------
class TestBuildSearchCondition:

    def test_single_term(self):
        cond = _build_search_condition([["term"]])
        assert cond["type"] == "or"
        assert len(cond["conditions"]) == 2
        fields = sorted(c["field"] for c in cond["conditions"])
        assert fields == ["abstract", "title"]
        assert all(c["operator"] == "$match" for c in cond["conditions"])

    def test_and_of_or(self):
        cond = _build_search_condition([["a", "b"], ["c"]])
        assert cond["type"] == "and"
        assert len(cond["conditions"]) == 2
        first_or = cond["conditions"][0]
        assert first_or["type"] == "or"
        # 每个词复制到 title + abstract 两个字段
        assert len(first_or["conditions"]) == 4


# ------------------------------------------------------------------
# _build_body
# ------------------------------------------------------------------
class TestBuildBody:

    def test_meta_body_with_venue_and_year(self):
        body = _build_body(
            groups=[["oxygen"]],
            fields=["title", "doi"],
            venues=["Nature", "Science"],
            venue_field="publication_venue_name",
            year_field="publication_published_year",
            year_from=2020,
            year_to=2026,
            year_is_date=False,
        )
        assert body["projection"]["fields"] == ["title", "doi"]
        assert body["search"]["type"] == "or"
        filt = body["filter"]
        assert filt["type"] == "and"
        venue_cond = next(c for c in filt["conditions"] if c["field"] == "publication_venue_name")
        assert venue_cond["operator"] == "$in"
        assert venue_cond["value"] == ["Nature", "Science"]

        years = [c for c in filt["conditions"] if c["field"] == "publication_published_year"]
        assert {c["operator"] for c in years} == {"$gte", "$lte"}
        assert {c["value"] for c in years} == {2020, 2026}

    def test_content_body_year_as_date(self):
        body = _build_body(
            groups=[["x"]],
            fields=["sha256"],
            venues=None,
            venue_field="magazine",
            year_field="pub_time",
            year_from=2020,
            year_to=None,
            year_is_date=True,
        )
        filt = body["filter"]
        assert len(filt["conditions"]) == 1
        cond = filt["conditions"][0]
        assert cond["value"] == "2020-01-01"

    def test_no_filter_block(self):
        body = _build_body(
            groups=[["x"]],
            fields=["title"],
            venues=None,
            venue_field="publication_venue_name",
            year_field="publication_published_year",
            year_from=None,
            year_to=None,
            year_is_date=False,
        )
        assert "filter" not in body


# ------------------------------------------------------------------
# _merge (meta + content 合并)
# ------------------------------------------------------------------
class TestMerge:

    def _client(self):
        return XingheClient({"enabled": True, "api_key": "dummy"})

    def test_merge_by_doi_fills_origin_path_from_content(self):
        client = self._client()
        meta = [{
            "title": "A", "author": "X", "doi": "10.1/A",
            "publication_published_year": 2022,
            "publication_venue_name": "Nature",
            "abstract": "abc", "type": "journal", "isbn13": "",
        }]
        content = [{
            "title": "A", "author": "X", "doi": "10.1/A",
            "sha256": "hash1", "origin_path": "/s3/a.pdf",
            "file_format": "pdf", "magazine": "Nature", "pub_time": "2022-05-01",
        }]
        merged = client._merge(meta, content)
        assert len(merged) == 1
        row = merged[0]
        assert row["doi"] == "10.1/A"
        assert row["sha256"] == "hash1"
        assert row["origin_path"] == "/s3/a.pdf"
        assert row["abstract"] == "abc"
        assert row["venue"] == "Nature"

    def test_orphans_without_doi_kept_separately(self):
        client = self._client()
        meta = [{"title": "no-doi", "author": "Y"}]
        content = []
        merged = client._merge(meta, content)
        assert len(merged) == 1
        assert merged[0]["doi"] == ""

    def test_dedup_priority_stable_first_wins(self):
        client = self._client()
        meta = [
            {"title": "A1", "doi": "10.1/A", "abstract": "first"},
            {"title": "A2", "doi": "10.1/A", "abstract": "second"},
        ]
        merged = client._merge(meta, [])
        assert len(merged) == 1
        assert merged[0]["title"] == "A1"


# ------------------------------------------------------------------
# 无 key 降级
# ------------------------------------------------------------------
def test_search_returns_empty_when_key_missing():
    client = XingheClient({"enabled": True, "api_key": ""})
    assert client.health_check() is False
    assert client.search("anything") == []


def test_search_returns_empty_when_disabled():
    client = XingheClient({"enabled": False, "api_key": "x"})
    assert client.search("anything") == []


def test_health_check_rejects_unresolved_placeholder():
    client = XingheClient({"enabled": True, "api_key": "${ROS_API_KEY}"})
    assert client.health_check() is False


# ------------------------------------------------------------------
# helpers
# ------------------------------------------------------------------
class TestHelpers:

    def test_extract_year_from_int(self):
        assert _extract_year(2021) == 2021
        assert _extract_year(99) is None
        assert _extract_year(None) is None

    def test_extract_year_from_string(self):
        assert _extract_year("2022-01-01") == 2022
        assert _extract_year("no year") is None
        assert _extract_year("2024") == 2024

    def test_split_authors_list(self):
        assert _split_authors(["A", "B"]) == ["A", "B"]

    def test_split_authors_string_semicolon(self):
        assert _split_authors("A; B; C") == ["A", "B", "C"]

    def test_split_authors_string_comma(self):
        assert _split_authors("A, B") == ["A", "B"]
