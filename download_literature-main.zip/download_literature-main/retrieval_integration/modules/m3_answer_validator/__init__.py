"""模块3：答案验证。"""
from .validator import AnswerValidator
from .gap_analyzer import build_internal_context, format_chunks_for_prompt

__all__ = [
    "AnswerValidator",
    "build_internal_context",
    "format_chunks_for_prompt",
]
