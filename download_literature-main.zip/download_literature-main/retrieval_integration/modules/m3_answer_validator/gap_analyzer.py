#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gap_analyzer.py —— 从模块3输出中提取 Internal_Context

输出结构化的"缺口描述"，供模块4使用。
"""

from typing import Any, Dict, List


def build_internal_context(
    chunks: List[Dict[str, Any]],
    covered_aspects: List[str],
    missing_aspects: List[str],
    max_chunks: int = 5,
    max_chars_per_chunk: int = 400,
) -> Dict[str, Any]:
    """
    构造 Internal_Context，供模块4做 Gap Analysis。

    Returns:
        {
          "chunks_text": "拼接的 chunks 文本",
          "covered_aspects": [...],
          "missing_aspects": [...],
          "chunk_refs": [{"paper_id": "...", "title": "...", "field_type": "..."}, ...]
        }
    """
    selected = chunks[:max_chunks]

    text_parts = []
    refs = []
    for i, c in enumerate(selected, 1):
        content = (c.get("content") or "")[:max_chars_per_chunk]
        title = c.get("title", "")
        field = c.get("field_type", "")
        text_parts.append(
            f"[内部{i}] ({field}) {content}"
        )
        refs.append(
            {
                "index": i,
                "paper_id": c.get("paper_id"),
                "title": title,
                "field_type": field,
            }
        )

    return {
        "chunks_text": "\n\n".join(text_parts),
        "covered_aspects": covered_aspects,
        "missing_aspects": missing_aspects,
        "chunk_refs": refs,
    }


def format_chunks_for_prompt(
    chunks: List[Dict[str, Any]],
    max_chunks: int = 10,
    max_chars: int = 800,
) -> str:
    """为模块3的 Prompt 格式化 chunks。"""
    lines = []
    for i, c in enumerate(chunks[:max_chunks], 1):
        content = (c.get("content") or "")[:max_chars]
        title = c.get("title", "")
        field = c.get("field_type", "")
        score = c.get("fused_score", 0.0)
        lines.append(
            f"【片段 {i}】(field={field}, score={score:.3f})\n"
            f"  title: {title}\n"
            f"  content: {content}"
        )
    return "\n\n".join(lines)
