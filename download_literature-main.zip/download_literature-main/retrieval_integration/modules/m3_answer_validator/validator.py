#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
validator.py —— 模块3：答案验证

判断检索到的 chunks 是否足以回答用户问题。
输出 answer_confidence + missing_aspects（供模块4使用）。
"""

from typing import Optional

from ...core import BaseModule, RequestContext
from ...llm import get_llm_client, get_prompt
from ..kg_context import format_kg_context
from .gap_analyzer import format_chunks_for_prompt


class AnswerValidator(BaseModule):
    name = "m3_answer_validator"

    def __init__(self, config=None):
        super().__init__(config)
        self.llm = get_llm_client()
        self.max_chunks = self._module_cfg.get("max_chunks_in_prompt", 10)
        self.max_chars = self._module_cfg.get("max_chars_per_chunk", 800)

    # ------------------------------------------------------------
    def _run(self, ctx: RequestContext) -> RequestContext:
        if not ctx.internal_chunks and not ctx.kg_reasoning_paths:
            # 双轨都为空才判 0
            ctx.answer_confidence = 0.0
            ctx.covered_aspects = []
            ctx.missing_aspects = ["无任何内部信息"]
            ctx.can_answer_directly = False
            return ctx

        chunks_text = format_chunks_for_prompt(
            ctx.internal_chunks,
            max_chunks=self.max_chunks,
            max_chars=self.max_chars,
        )
        kg_text = format_kg_context(
            ctx.kg_reasoning_paths,
            kg_summary=ctx.kg_summary,
            kg_intent=ctx.kg_intent or "",
        )
        # 双轨上下文一并喂给验证器
        if kg_text:
            chunks_text = f"{kg_text}\n\n[知识库证据]\n{chunks_text}"

        system_prompt = get_prompt("m3_answer_validator", "system")
        user_prompt = get_prompt("m3_answer_validator", "user").format(
            query=ctx.query,
            num_chunks=min(len(ctx.internal_chunks), self.max_chunks),
            chunks=chunks_text,
        )

        result = self.llm.call_json(
            prompt=user_prompt,
            system_prompt=system_prompt,
            module="m3_validator",
        )

        if not result:
            ctx.warnings.append("m3: LLM 返回解析失败")
            # 保守降级：置信度置 0，让流程走模块4
            ctx.answer_confidence = 0.0
            ctx.covered_aspects = []
            ctx.missing_aspects = ["模块3验证失败，走外部路径"]
            ctx.can_answer_directly = False
            return ctx

        ctx.answer_confidence = self._clip(result.get("answer_confidence", 0.0))
        ctx.covered_aspects = result.get("covered_aspects") or []
        ctx.missing_aspects = result.get("missing_aspects") or []
        ctx.can_answer_directly = bool(result.get("can_answer_directly", False))

        # 后处理：缺失比覆盖多时禁止直接回答（没有足够依据）
        if len(ctx.missing_aspects) > len(ctx.covered_aspects):
            ctx.can_answer_directly = False

        return ctx

    @staticmethod
    def _clip(v) -> float:
        try:
            v = float(v)
        except (TypeError, ValueError):
            return 0.0
        return max(0.0, min(1.0, v))
