#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
direct_answer.py —— 模块3高分时的直接回答生成

不走模块4/5/6，仅基于内部 chunks 生成答案。
"""

from typing import Optional

from ..core import BaseModule, RequestContext
from ..llm import get_llm_client, get_prompt, extract_answer_and_meta
from .m3_answer_validator.gap_analyzer import format_chunks_for_prompt
from .confidence_scorer import score_from_ctx
from .kg_context import format_kg_context


class DirectAnswerGenerator(BaseModule):
    """基于内部检索结果直接生成答案（模块3高分分支）。"""

    name = "direct_answer"

    def __init__(self, config=None):
        super().__init__(config)
        self.llm = get_llm_client()
        self.llm_response_enabled = self.config.get(
            "m6_answer_generator.llm_response", True
        )

    def _run(self, ctx: RequestContext) -> RequestContext:
        # M6 LLM 开关同时控制本路径，避免 DIRECT 路径绕过 llm_response=false
        if not self.llm_response_enabled:
            ctx.skipped_llm = True
            ctx.final_answer = ""
            ctx.final_confidence = 0.0
            ctx.warnings.append("direct_answer: llm_response=false, LLM 跳过")
            return ctx

        chunks_text = format_chunks_for_prompt(ctx.internal_chunks, max_chunks=5)
        kg_text = format_kg_context(
            ctx.kg_reasoning_paths,
            kg_summary=ctx.kg_summary,
            kg_intent=ctx.kg_intent or "",
        )
        chunks_with_kg = chunks_text
        if kg_text:
            chunks_with_kg = f"{kg_text}\n\n[知识库证据]\n{chunks_text}"

        system_prompt = get_prompt("direct_answer", "system")
        user_prompt = get_prompt("direct_answer", "user").format(
            query=ctx.query,
            chunks=chunks_with_kg,
        )

        raw = self.llm.call(
            prompt=user_prompt,
            system_prompt=system_prompt,
            module="m6_generator",
        )
        result = extract_answer_and_meta(raw) if raw else None

        if not result or not result.get("answer"):
            # 新格式解析失败：仍保留纯文本降级，保证有答案输出
            self.logger.warning("direct_answer: 混合格式解析失败，降级为纯文本")
            ctx.final_answer = raw.strip() if raw else "（内部知识库匹配度高，但生成答案失败）"
            ctx.key_findings = []
            ctx.final_confidence = ctx.answer_confidence
            return ctx

        ctx.final_answer = result.get("answer", "")
        ctx.key_findings = result.get("key_findings") or []

        # final_confidence 由加权公式计算，LLM 只提供 factual_grounding 和 completeness
        llm_scores = {
            "factual_grounding": result.get("factual_grounding", 0.0),
            "completeness":      result.get("completeness", 0.0),
        }
        ctx.final_confidence = score_from_ctx(ctx, llm_scores)

        # 附上内部引用
        ctx.references = [
            {
                "index": i + 1,
                "paper_id": c.get("paper_id"),
                "title": c.get("title"),
                "field_type": c.get("field_type"),
                "source": "internal",
            }
            for i, c in enumerate(ctx.internal_chunks[:5])
        ]
        return ctx

    @staticmethod
    def _clip(v) -> float:
        try:
            v = float(v)
        except (TypeError, ValueError):
            return 0.0
        return max(0.0, min(1.0, v))
