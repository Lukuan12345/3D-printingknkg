#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
confidence.py —— 模块1的置信度计算辅助

目前置信度由 LLM 直接打分，此处提供：
1. 关键词预筛（低延迟快速判断）—— token 级匹配
2. 置信度后处理（clip 到 [0,1]）
"""

import re
from typing import Iterable, List, Set


# 通用过滤：太短或纯数字的 token 不参与匹配
_MIN_TOKEN_LEN = 2
_STOPWORDS = {
    # 英文
    "the", "a", "an", "of", "in", "on", "at", "to", "for", "and", "or", "is",
    "are", "was", "were", "be", "by", "with", "as",
    # 中文常见停用词（领域无关）
    "的", "了", "在", "是", "有", "和", "或",
}


def _tokenize_keyword_bag(keywords: Iterable[str]) -> Set[str]:
    """
    把 schema 关键词集合（含复合词）展开为 token 集合。

    示例:
        ["operating_frequency_range", "substrate_material", "吸波体"]
      → {"operating", "frequency", "range", "substrate", "material", "吸波体"}
    """
    out: Set[str] = set()
    for kw in keywords:
        if not kw:
            continue
        # 切分: 下划线 / 空格 / 连字符
        parts = re.split(r"[_\s\-]+", kw.lower())
        for p in parts:
            p = p.strip()
            if len(p) >= _MIN_TOKEN_LEN and p not in _STOPWORDS:
                out.add(p)
        # 中文整体也保留（连续 CJK 不切分）
        if re.search(r"[一-鿿]", kw):
            out.add(kw.strip())
    return out


def _tokenize_query(query: str) -> Set[str]:
    """
    把 query 切成 token 集合（粗粒度分词）。
    - 英文按空白/标点切分
    - CJK 字符保留连续段（避免依赖中文分词器）
    """
    if not query:
        return set()

    q = query.lower()
    # 英文 token：连续字母数字
    en_tokens = set(re.findall(r"[a-z0-9]+", q))
    # CJK 段：连续 一-鿿
    cjk_segs = set(re.findall(r"[一-鿿]+", q))

    tokens = {t for t in en_tokens if len(t) >= _MIN_TOKEN_LEN and t not in _STOPWORDS}
    tokens |= cjk_segs
    return tokens


def keyword_hit_count(query: str, schema_keywords: List[str]) -> int:
    """
    统计 query 与 schema 关键词的 token 级命中数。

    匹配策略（多路并集计数）：
    1. **英文 token 直接交集**：query 与 schema 拆出的英文 token 取交集
    2. **CJK 双向子串匹配**：query 段在任一 schema 段中（如 "基板" ⊂ "基底/基板材料"），
       或 schema 段在 query 中
    3. **CJK 二元组匹配**：把 query 与 schema 的 CJK 段都拆成 bigram（连续 2 字），
       取交集（避免分词依赖；适合"基板材料"vs"基板设计"这种局部相似场景）

    设计理由：
    - schema 字段名通常是长短语（"基底/基板材料"），query 用短词（"基板"），
      单向 substring 不够，必须双向
    - 中文无空格，bigram 是无依赖的近似分词手段
    """
    if not schema_keywords or not query:
        return 0

    schema_tokens = _tokenize_keyword_bag(schema_keywords)
    query_tokens = _tokenize_query(query)
    q_lower = query.lower()

    # 1) 英文 token 直接交集
    en_schema = {t for t in schema_tokens if t.isascii()}
    en_query = {t for t in query_tokens if t.isascii()}
    en_hits = en_schema & en_query

    # 2) CJK 双向子串匹配
    cjk_schema = [t for t in schema_tokens if not t.isascii()]
    cjk_query = [t for t in query_tokens if not t.isascii()]

    cjk_substring_hits: Set[str] = set()
    for s in cjk_schema:
        if len(s) >= _MIN_TOKEN_LEN and s in q_lower:
            cjk_substring_hits.add(s)
    for q_seg in cjk_query:
        for s in cjk_schema:
            # query 段是 schema 段的子串（如 "基板" ⊂ "基板材料"）
            if len(q_seg) >= _MIN_TOKEN_LEN and q_seg in s:
                cjk_substring_hits.add(q_seg)
                break

    # 3) CJK bigram 交集（兜底）
    schema_bigrams = _cjk_bigrams(cjk_schema)
    query_bigrams = _cjk_bigrams(cjk_query)
    bigram_hits = schema_bigrams & query_bigrams

    return len(en_hits) + len(cjk_substring_hits) + len(bigram_hits)


def _cjk_bigrams(segments: List[str]) -> Set[str]:
    """从 CJK 段列表中生成所有连续 2 字组合的集合。"""
    out: Set[str] = set()
    for seg in segments:
        if len(seg) < 2:
            continue
        for i in range(len(seg) - 1):
            bg = seg[i:i + 2]
            # 必须全是 CJK
            if all("一" <= ch <= "鿿" for ch in bg):
                out.add(bg)
    return out


def keyword_overlap_ratio(query: str, schema_keywords: List[str]) -> float:
    """
    （已弃用）保留为兼容工具。新代码请用 keyword_hit_count。
    """
    if not schema_keywords or not query:
        return 0.0
    hits = keyword_hit_count(query, schema_keywords)
    return hits / max(len(schema_keywords), 1)


def normalize_confidence(value: float) -> float:
    """Clip 到 [0, 1]。"""
    try:
        v = float(value)
    except (TypeError, ValueError):
        return 0.0
    if v < 0.0:
        return 0.0
    if v > 1.0:
        return 1.0
    return v
