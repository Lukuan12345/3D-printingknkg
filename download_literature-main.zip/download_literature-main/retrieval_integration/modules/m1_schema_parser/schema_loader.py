#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
schema_loader.py —— 模块1的 Schema 加载器

从 CSV 读取 Schema 字段信息，构建 LLM Prompt 所需的字段列表。
与 kb_mvp/src/schema_loader.py 解耦，避免耦合 DB 依赖。
"""

import csv
from pathlib import Path
from typing import Dict, List, Optional


class SchemaFieldList:
    """轻量级 Schema 加载器：只读字段名和描述，不碰 DB。"""

    def __init__(self, csv_path: Path):
        self.csv_path = Path(csv_path)
        self.fields: List[Dict[str, str]] = []
        self._load()

    def _load(self) -> None:
        if not self.csv_path.exists():
            raise FileNotFoundError(f"Schema CSV not found: {self.csv_path}")

        with open(self.csv_path, "r", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            for row in reader:
                # 兼容中英文列名
                en = (row.get("字段名（英文）") or row.get("field_en") or "").strip()
                cn = (row.get("字段名（中文）") or row.get("field_cn") or "").strip()
                desc = (row.get("完整描述") or row.get("description") or "").strip()
                cluster = (row.get("聚类名称") or row.get("cluster") or "").strip()
                if not en:
                    continue
                self.fields.append(
                    {
                        "en": en,
                        "cn": cn,
                        "desc": desc,
                        "cluster": cluster,
                    }
                )

    def all_keywords(self) -> List[str]:
        """用于预筛的关键词集合：中/英字段名 + 聚类名。"""
        kws: List[str] = []
        for f in self.fields:
            if f["en"]:
                kws.append(f["en"].replace("_", " "))
            if f["cn"]:
                kws.append(f["cn"])
            if f["cluster"]:
                kws.append(f["cluster"])
        return list(dict.fromkeys(kws))  # 去重保持顺序

    def format_for_prompt(self, max_fields: int = 50) -> str:
        """格式化为 LLM Prompt 友好的字段列表文本。"""
        lines = []
        for f in self.fields[:max_fields]:
            parts = [f["en"]]
            if f["cn"]:
                parts.append(f"({f['cn']})")
            if f["cluster"]:
                parts.append(f"[聚类: {f['cluster']}]")
            lines.append(" - " + " ".join(parts))
            if f["desc"]:
                lines.append(f"     {f['desc'][:120]}")
        if len(self.fields) > max_fields:
            lines.append(f" - ...（共 {len(self.fields)} 个字段，此处仅展示前 {max_fields} 个）")
        return "\n".join(lines)
