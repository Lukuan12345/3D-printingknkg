#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
parser.py —— 模块1：Schema 解析器

流程：
1. 关键词预筛：重叠率 < 阈值 → parse_confidence = 0，跳过 LLM
2. LLM 打分：返回 {parse_confidence, matched_fields, reason}
3. 记录失败 Query（供 Schema 演进使用）
"""

import json
from pathlib import Path
from typing import Optional

from ...core import BaseModule, RequestContext
from ...llm import get_llm_client, get_prompt
from .schema_loader import SchemaFieldList
from .confidence import keyword_hit_count, normalize_confidence


class SchemaParser(BaseModule):
    name = "m1_schema_parser"

    def __init__(self, config=None, schema_loader: Optional[SchemaFieldList] = None):
        super().__init__(config)

        if schema_loader is None:
            csv_rel = self._module_cfg.get(
                "schema_csv_path",
                "../refined_schema_output/refined_schema_200_1.csv",
            )
            csv_path = self.config.resolve_path(csv_rel)
            schema_loader = SchemaFieldList(csv_path)

        self.schema = schema_loader
        self.llm = get_llm_client()

        # 预筛参数（语义改为：至少命中 N 个 schema 关键词才送入 LLM）
        prefilter_cfg = self._module_cfg.get("prefilter", {})
        self.prefilter_enabled = prefilter_cfg.get("enabled", True)
        # 兼容旧 key：min_keyword_overlap（已弃用） → min_keyword_hits
        self.min_hits = prefilter_cfg.get("min_keyword_hits", 1)

        self.max_fields_in_prompt = self._module_cfg.get(
            "max_schema_fields_in_prompt", 50
        )

        # 失败 Query 日志目录
        self.miss_log_dir = self.config.resolve_path(
            self.config.get(
                "knowledge_backflow.schema_evolver.schema_miss_log_path",
                "data/schema_miss_log/",
            )
        )
        self.miss_log_dir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------
    def _run(self, ctx: RequestContext) -> RequestContext:
        query = ctx.query

        # --- Step 1: 关键词预筛（仅用于过滤完全无关的 Query）---
        if self.prefilter_enabled:
            hits = keyword_hit_count(query, self.schema.all_keywords())
            if hits < self.min_hits:
                self.logger.info(
                    f"[{ctx.request_id}] Prefilter: hits={hits} < "
                    f"{self.min_hits}, skipping LLM"
                )
                ctx.parse_confidence = 0.0
                ctx.matched_schema_fields = []
                ctx.m1_reason = (
                    f"关键词命中数过低 ({hits}/{self.min_hits})"
                )
                self._log_miss(ctx)
                return ctx

        # --- Step 2: LLM 打分 ---
        system_prompt = get_prompt("m1_schema_parser", "system")
        user_prompt = get_prompt("m1_schema_parser", "user").format(
            schema_fields=self.schema.format_for_prompt(self.max_fields_in_prompt),
            query=query,
        )

        result = self.llm.call_json(
            prompt=user_prompt,
            system_prompt=system_prompt,
            module="m1_parser",
        )

        if not result:
            ctx.warnings.append("m1: LLM 返回解析失败，降级为 parse_confidence=0")
            ctx.parse_confidence = 0.0
            return ctx

        ctx.parse_confidence = normalize_confidence(
            result.get("parse_confidence", 0.0)
        )
        ctx.matched_schema_fields = result.get("matched_fields") or []
        ctx.m1_reason = result.get("reason", "")

        # 低置信度记录
        threshold = self.config.get("pipeline.thresholds.m1_parse_confidence", 0.6)
        if ctx.parse_confidence < threshold:
            self._log_miss(ctx)

        return ctx

    # ------------------------------------------------------------
    def _log_miss(self, ctx: RequestContext) -> None:
        """记录 Schema 解析失败的 Query，供后续聚类分析。"""
        from datetime import datetime

        rec = {
            "request_id": ctx.request_id,
            "query": ctx.query,
            "parse_confidence": ctx.parse_confidence,
            "reason": ctx.m1_reason,
            "timestamp": datetime.now().isoformat(),
        }
        date_str = datetime.now().strftime("%Y-%m-%d")
        path = self.miss_log_dir / f"miss_{date_str}.jsonl"
        try:
            with open(path, "a", encoding="utf-8") as f:
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        except Exception as e:
            self.logger.warning(f"写入 miss log 失败: {e}")
