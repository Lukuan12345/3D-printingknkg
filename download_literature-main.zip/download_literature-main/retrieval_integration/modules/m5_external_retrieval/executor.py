#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
executor.py —— 模块5：外部检索执行器

功能：
1. 按 search_plan["source_priority"]["target_apis"] 动态选择 API 客户端
2. 对每个 API 执行双轨检索（strict + expansive）
3. 三级递进循环：若召回文献 < min_docs 阈值，依次扩宽查询词（最多 3 级）
   - 第 1 级：strict_query（精准，M4 已生成）
   - 第 2 级：expansive_query（宽泛，M4 已生成）
   - 第 3 级：keywords_expand 拼接的 fallback（最宽松，无需再调 M4）
4. 并发调用（ThreadPoolExecutor）
5. 合并去重
"""

from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Dict, List, Optional

from ...core import BaseModule, RequestContext
from .api_clients import CLIENT_REGISTRY, ExternalAPIClient, ExternalDoc
from .deduplicator import dedupe_docs


class ExternalRetriever(BaseModule):
    name = "m5_external_retrieval"

    def __init__(self, config=None):
        super().__init__(config)

        self.default_apis: List[str] = self._module_cfg.get(
            "default_apis", ["星河图书馆"]
        )
        self.clients_cfg: Dict[str, Any] = self._module_cfg.get("clients", {})

        dual_cfg = self._module_cfg.get("dual_track", {})
        self.dual_track_enabled = dual_cfg.get("enabled", True)
        self.max_per_track = dual_cfg.get("max_docs_per_track", 20)
        self.concurrent = dual_cfg.get("concurrent", True)

        dedupe_cfg = self._module_cfg.get("dedupe", {})
        self.dedupe_enabled = dedupe_cfg.get("enabled", True)
        self.dedupe_keys: List[str] = dedupe_cfg.get(
            "key_priority", ["doi", "url", "title"]
        )

        # 三级递进阈值：召回文献数低于此值时尝试下一级查询
        self.min_docs_threshold: int = self._module_cfg.get("min_docs_threshold", 5)
        # 最大递进轮次（含第一轮）
        self.max_expand_rounds: int = self._module_cfg.get("max_expand_rounds", 3)

        # 客户端实例缓存
        self._client_cache: Dict[str, ExternalAPIClient] = {}

    # ------------------------------------------------------------
    def _get_client(self, api_name: str) -> ExternalAPIClient:
        """懒加载 + 配置映射。"""
        if api_name in self._client_cache:
            return self._client_cache[api_name]

        cls = CLIENT_REGISTRY.get(api_name)
        if cls is None:
            raise ValueError(f"未注册的 API: {api_name}")

        client_key = self._api_name_to_config_key(api_name)
        client_cfg = self.clients_cfg.get(client_key, {})
        client = cls(client_cfg)
        self._client_cache[api_name] = client
        return client

    @staticmethod
    def _api_name_to_config_key(api_name: str) -> str:
        mapping = {
            "星河图书馆":      "xinghe",
            "星河图书馆SQL":   "xinghe_sql",
            "arXiv":           "arxiv",
            "Semantic Scholar": "semantic_scholar",
            "OpenAlex":        "openalex",
            "PubMed API":      "pubmed",
        }
        return mapping.get(api_name, api_name.lower().replace(" ", "_"))

    # ------------------------------------------------------------
    def _run(self, ctx: RequestContext) -> RequestContext:
        if not self.config.get("m5_external_retrieval.enabled", True):
            ctx.warnings.append("m5: enabled=false，已跳过外部检索")
            ctx.external_docs = []
            ctx.external_docs_stats = {"skipped": True}
            return ctx

        plan = ctx.search_plan or {}
        qr = plan.get("query_rewrites", {}) or {}
        dual = qr.get("dual_track_queries", {}) or {}

        strict_q = dual.get("strict_query") or qr.get("boolean_query") or ctx.query
        expansive_q = dual.get("expansive_query") or strict_q

        # 第 3 级 fallback：把 keywords_expand 拼成简单的 AND 查询
        kw_expand: List[str] = qr.get("keywords_expand") or []
        fallback_q = (" AND ".join(f'"{k}"' for k in kw_expand[:5])
                      if kw_expand else expansive_q)

        # 三级查询词列表（去重，保留顺序）
        query_levels: List[str] = []
        for q in [strict_q, expansive_q, fallback_q]:
            if q and q not in query_levels:
                query_levels.append(q)

        target_apis: List[str] = list(
            plan.get("source_priority", {}).get("target_apis") or self.default_apis
        )
        # 星河图书馆是私有 KB，确保至少有一个星河源在列表里
        has_xinghe = any(a in target_apis for a in ("星河图书馆", "星河图书馆SQL"))
        if not has_xinghe:
            target_apis.insert(0, "星河图书馆SQL")

        # 过滤掉健康检查不通过的 API（避免每次等超时）
        healthy_apis: List[str] = []
        for api in target_apis:
            cls = CLIENT_REGISTRY.get(api)
            if cls is None:
                continue
            client_key = self._api_name_to_config_key(api)
            client_cfg = self.clients_cfg.get(client_key, {})
            client = cls(client_cfg)
            if hasattr(client, "health_check") and not client.health_check():
                self.logger.info(f"m5: {api} health_check failed，跳过")
                ctx.warnings.append(f"m5: {api} 不可用（health_check failed）")
                continue
            healthy_apis.append(api)
        target_apis = healthy_apis

        all_docs: List[ExternalDoc] = []
        track_counts: Dict[str, int] = {}

        for round_idx, query in enumerate(query_levels[: self.max_expand_rounds]):
            # 已达到阈值，不再继续
            if round_idx > 0 and len(all_docs) >= self.min_docs_threshold:
                break

            round_label = ["strict", "expansive", "fallback"][round_idx]
            self.logger.info(
                f"m5 round {round_idx + 1}/{min(len(query_levels), self.max_expand_rounds)}"
                f" [{round_label}]: {query[:60]!r}  already={len(all_docs)}"
            )

            round_docs = self._search_one_round(
                query, target_apis, ctx, track_counts, round_label
            )
            all_docs.extend(round_docs)

            # 去重（轮次间）
            if self.dedupe_enabled:
                all_docs = dedupe_docs(all_docs, key_priority=self.dedupe_keys)

        # 写回 ctx
        ctx.external_docs = [d.to_dict() for d in all_docs]
        ctx.external_docs_stats = {
            "before_dedupe": len(all_docs),
            "after_dedupe": len(all_docs),
            "per_track": track_counts,
            "target_apis": target_apis,
        }

        # ----- PDF 下载（需求 3e / #4）-----
        if ctx.external_docs:
            try:
                from .pdf_downloader import PDFDownloader
                pdf_dir = self._resolve_pdf_dir(ctx)
                if pdf_dir is not None:
                    downloader = PDFDownloader(
                        target_dir=pdf_dir,
                        timeout=self._module_cfg.get("pdf_download_timeout_s", 30),
                        max_workers=self._module_cfg.get("pdf_download_workers", 4),
                    )
                    downloader.download_many(ctx.external_docs)

                    # 星河 S3 专用下载：WORKBENCH_API_KEY 优先，其次 XINGHE_API_KEY
                    import os as _os
                    xinghe_download_key = (
                        _os.environ.get("WORKBENCH_API_KEY")
                        or _os.environ.get("XINGHE_API_KEY")
                        or self.clients_cfg.get("xinghe", {}).get("api_key", "")
                    )
                    if xinghe_download_key and xinghe_download_key.startswith("${"):
                        xinghe_download_key = ""
                    if xinghe_download_key:
                        from pathlib import Path as _Path
                        from .api_clients.xinghe_downloader import XingheDownloader
                        xdl = XingheDownloader(api_key=xinghe_download_key)
                        for doc in ctx.external_docs:
                            if doc.get("local_pdf_path"):
                                continue
                            origin_path = (doc.get("raw") or {}).get("origin_path") or ""
                            if not origin_path:
                                continue
                            ok, result = xdl.download_one(origin_path, str(pdf_dir))
                            if ok:
                                doc["local_pdf_path"] = str(_Path(pdf_dir) / result)
                            else:
                                doc.setdefault("download_error", result)

                    n_ok = sum(1 for d in ctx.external_docs if d.get("local_pdf_path"))
                    self.logger.info(
                        f"PDFDownloader: {n_ok}/{len(ctx.external_docs)} pdfs saved → {pdf_dir}"
                    )
            except Exception as e:  # noqa: BLE001
                self.logger.warning(f"PDFDownloader failed: {e}")
                ctx.warnings.append(f"m5/pdf: {e}")

        return ctx

    # ------------------------------------------------------------
    def _resolve_pdf_dir(self, ctx: RequestContext):
        """PDF 落到 process_log_dir/external_pdfs/ 下。"""
        from pathlib import Path
        if ctx.process_log_dir:
            p = Path(ctx.process_log_dir) / "external_pdfs"
            return p
        # 兜底：runs/{request_id}/external_pdfs
        run_root = self.config.resolve_path(
            self.config.get("monitoring.log_dir", "packages/retrieval/runs/")
        )
        return run_root / ctx.request_id / "external_pdfs"

    # ------------------------------------------------------------
    def _search_one_round(
        self,
        query: str,
        target_apis: List[str],
        ctx: RequestContext,
        track_counts: Dict[str, int],
        round_label: str,
    ) -> List[ExternalDoc]:
        """对所有 target_apis 并发执行单轮检索，返回新增文献列表。"""
        tasks = []
        for api in target_apis:
            if api not in CLIENT_REGISTRY:
                ctx.warnings.append(f"m5: 未知 API {api}，跳过")
                continue
            tasks.append((api, query))
            if self.dual_track_enabled and round_label == "strict":
                # 双轨仅在第 1 轮（strict）执行，后续轮次直接单轨避免重复
                pass  # 第 2、3 轮不再加双轨（query 本身已是宽泛版本）

        round_docs: List[ExternalDoc] = []

        if self.concurrent and len(tasks) > 1:
            with ThreadPoolExecutor(max_workers=min(len(tasks), 4)) as ex:
                futures = {
                    ex.submit(self._call_one, api, q): api
                    for api, q in tasks
                }
                for fut in as_completed(futures):
                    api = futures[fut]
                    try:
                        docs = fut.result()
                    except Exception as e:
                        ctx.warnings.append(f"m5: {api}/{round_label} 调用失败 {e}")
                        docs = []
                    round_docs.extend(docs)
                    key = f"{api}/{round_label}"
                    track_counts[key] = track_counts.get(key, 0) + len(docs)
        else:
            for api, q in tasks:
                try:
                    docs = self._call_one(api, q)
                except Exception as e:
                    ctx.warnings.append(f"m5: {api}/{round_label} 调用失败 {e}")
                    docs = []
                round_docs.extend(docs)
                key = f"{api}/{round_label}"
                track_counts[key] = track_counts.get(key, 0) + len(docs)

        return round_docs

    # ------------------------------------------------------------
    def _call_one(self, api_name: str, query: str) -> List[ExternalDoc]:
        client = self._get_client(api_name)
        return client.search(query, max_results=self.max_per_track)

