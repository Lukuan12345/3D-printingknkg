#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
deduplicator.py —— 外部文献去重
"""

from typing import Any, Dict, List

from .api_clients.base_client import ExternalDoc


def dedupe_docs(
    docs: List[ExternalDoc],
    key_priority: List[str] = None,
) -> List[ExternalDoc]:
    """
    按指定优先级 key 去重。

    Args:
        docs: 待去重文档列表
        key_priority: 用于生成去重 ID 的字段优先级（例如 ["doi", "url", "title"]）

    Returns:
        去重后保持首次出现顺序的列表
    """
    key_priority = key_priority or ["doi", "url", "title"]
    seen = set()
    out: List[ExternalDoc] = []

    for d in docs:
        dedup_id = None
        for k in key_priority:
            v = getattr(d, k, None)
            if v:
                dedup_id = f"{k}::{v}".strip().lower()
                break

        if dedup_id is None or dedup_id in seen:
            if dedup_id is None:
                # 无可去重字段，保留
                out.append(d)
            continue

        seen.add(dedup_id)
        out.append(d)

    return out
