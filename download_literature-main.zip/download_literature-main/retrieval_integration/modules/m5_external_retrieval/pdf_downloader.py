#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
pdf_downloader.py —— 外部参考 PDF 下载器（需求 3e / #4）

输入：ExternalDoc 列表（dict 形态，含 doi/url/raw.arxiv_id 等字段）。
输出：每条 doc 增加 local_pdf_path（下载成功）或 download_error（失败）。

下载来源优先级：
  1. raw.arxiv_id / arxiv_id     → http://arxiv.org/pdf/{id}.pdf
  2. raw.openalex_oa_url         → 直链
  3. pdf_url                     → 直链
  4. url                         → 若是 .pdf 直接下载，否则跳过（避免 doi.org 跳转 403）

文件命名：sha1(doi or url or arxiv_id)[:12].pdf
失败默认不抛异常，仅记录 download_error。
"""

from __future__ import annotations

import hashlib
import logging
import re
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

logger = logging.getLogger(__name__)

# 静态降级：若 httpx 不可用，回退到 stdlib（外部环境通常都有 httpx）
try:
    import httpx  # noqa: F401
    _HAS_HTTPX = True
except ImportError:
    _HAS_HTTPX = False


_ARXIV_ID_RE = re.compile(r"\b(\d{4}\.\d{4,5})(v\d+)?\b")


class PDFDownloader:
    """串/并发 PDF 下载。"""

    def __init__(
        self,
        target_dir: Path,
        timeout: float = 30.0,
        max_workers: int = 4,
        max_size_mb: int = 50,
    ):
        self.target_dir = Path(target_dir)
        self.target_dir.mkdir(parents=True, exist_ok=True)
        self.timeout = timeout
        self.max_workers = max_workers
        self.max_size = max_size_mb * 1024 * 1024

    # ------------------------------------------------------------
    def download_many(self, docs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        并发下载多篇。返回与输入同序的 docs 列表（原 dict 引用，原地填字段）。
        """
        if not docs:
            return docs

        with ThreadPoolExecutor(max_workers=self.max_workers) as pool:
            futs = {pool.submit(self._download_one, d): d for d in docs}
            for fut in as_completed(futs):
                d = futs[fut]
                try:
                    res = fut.result()
                except Exception as e:  # noqa: BLE001
                    res = {"download_error": str(e)}
                d.update(res)
        return docs

    # ------------------------------------------------------------
    def _download_one(self, doc: Dict[str, Any]) -> Dict[str, Any]:
        """单篇下载逻辑。返回 update 字段。"""
        candidate_urls = self._resolve_urls(doc)
        if not candidate_urls:
            return {"download_error": "no candidate URL (no arxiv_id / pdf_url)"}

        # 命名
        key = doc.get("doi") or candidate_urls[0]
        h = hashlib.sha1(key.encode("utf-8")).hexdigest()[:12]
        out_path = self.target_dir / f"{h}.pdf"

        # 已下载就直接返回
        if out_path.exists() and out_path.stat().st_size > 0:
            return {
                "local_pdf_path": str(out_path),
                "download_skipped": "cached",
            }

        last_err = ""
        for url in candidate_urls:
            try:
                ok = self._fetch(url, out_path)
                if ok:
                    return {"local_pdf_path": str(out_path)}
                last_err = "non-pdf or empty body"
            except Exception as e:  # noqa: BLE001
                last_err = str(e)
                logger.info("PDF fetch failed %s: %s", url, e)

        return {"download_error": last_err}

    # ------------------------------------------------------------
    def _resolve_urls(self, doc: Dict[str, Any]) -> List[str]:
        """挑出候选下载 URL，按优先级排序。"""
        urls: List[str] = []
        raw = doc.get("raw") or {}

        # 1) arxiv_id
        arxiv_id = (
            raw.get("arxiv_id")
            or doc.get("arxiv_id")
            or _extract_arxiv_id(doc.get("url") or "")
            or _extract_arxiv_id(doc.get("doi") or "")
        )
        if arxiv_id:
            urls.append(f"https://arxiv.org/pdf/{arxiv_id}.pdf")

        # 2) openalex oa_url（open_access.oa_url）和 primary_location.pdf_url
        oa = (
            raw.get("openalex_oa_url")
            or raw.get("oa_url")
            or _dig(raw, "open_access", "oa_url")
        )
        if isinstance(oa, str) and oa:
            urls.append(oa)

        pl_pdf = _dig(raw, "primary_location", "pdf_url")
        if isinstance(pl_pdf, str) and pl_pdf:
            urls.append(pl_pdf)

        # 3) pdf_url 字段
        for k in ("pdf_url", "fulltext_url", "openaccess_url"):
            v = doc.get(k) or raw.get(k)
            if isinstance(v, str) and v:
                urls.append(v)

        # 4) 通用 url（仅当看起来是 .pdf）
        u = doc.get("url") or ""
        if isinstance(u, str) and u.lower().endswith(".pdf"):
            urls.append(u)

        # 去重保序
        seen = set()
        out: List[str] = []
        for x in urls:
            if x and x not in seen:
                seen.add(x)
                out.append(x)
        return out

    # ------------------------------------------------------------
    def _fetch(self, url: str, out_path: Path) -> bool:
        """同步下载。检测 content-type 是否 PDF。"""
        if _HAS_HTTPX:
            return self._fetch_httpx(url, out_path)
        return self._fetch_urllib(url, out_path)

    def _fetch_httpx(self, url: str, out_path: Path) -> bool:
        import httpx  # local
        with httpx.Client(timeout=self.timeout, follow_redirects=True) as cli:
            with cli.stream("GET", url) as r:
                if r.status_code not in (200, 202, 203):
                    raise RuntimeError(f"http {r.status_code}")
                ctype = r.headers.get("content-type", "").lower()
                if "pdf" not in ctype and not url.lower().endswith(".pdf"):
                    return False
                size = 0
                tmp = out_path.with_suffix(".pdf.part")
                with open(tmp, "wb") as f:
                    for chunk in r.iter_bytes():
                        if not chunk:
                            continue
                        size += len(chunk)
                        if size > self.max_size:
                            tmp.unlink(missing_ok=True)
                            raise RuntimeError(
                                f"exceeded max_size ({self.max_size} bytes)"
                            )
                        f.write(chunk)
                tmp.replace(out_path)
                return True

    def _fetch_urllib(self, url: str, out_path: Path) -> bool:
        import urllib.request
        req = urllib.request.Request(url, headers={"User-Agent": "RI-PDFDownloader/1"})
        with urllib.request.urlopen(req, timeout=self.timeout) as r:
            ctype = (r.headers.get("Content-Type") or "").lower()
            if "pdf" not in ctype and not url.lower().endswith(".pdf"):
                return False
            tmp = out_path.with_suffix(".pdf.part")
            with open(tmp, "wb") as f:
                while True:
                    buf = r.read(64 * 1024)
                    if not buf:
                        break
                    f.write(buf)
                    if f.tell() > self.max_size:
                        f.close()
                        tmp.unlink(missing_ok=True)
                        raise RuntimeError("exceeded max_size")
            tmp.replace(out_path)
            return True


# ============================================================
# helpers
# ============================================================

def _extract_arxiv_id(s: str) -> Optional[str]:
    if not s:
        return None
    m = _ARXIV_ID_RE.search(s)
    return m.group(1) if m else None


def _dig(obj: Any, *path: str) -> Any:
    cur = obj
    for p in path:
        if not isinstance(cur, dict):
            return None
        cur = cur.get(p)
    return cur
