#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
semantic_scholar_client.py —— Semantic Scholar Graph API 客户端

API 文档：https://api.semanticscholar.org/api-docs/graph

特点：
- 不需要 API key 即可使用（限速 100 req / 5min）
- 配置 `S2_API_KEY` 后限速 1 req/s
- 对 429 做指数退避重试（最多 3 次），避免连续调用导致的限速失效

替换：原 PubMed（领域不匹配，PubMed 是医学）的位置。
"""

import logging
import re
import time
import requests
from typing import Any, Dict, List

from .base_client import ExternalAPIClient, ExternalDoc

logger = logging.getLogger(__name__)


class SemanticScholarClient(ExternalAPIClient):
    name = "Semantic Scholar"

    # ── 类级熔断器（所有实例共享，跨 query 批次持久）──────────────
    _circuit_open_until: float = 0.0   # 熔断截止时间戳
    _circuit_cooldown_s: int = 120     # 冷却 2 分钟

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.base_url = self.config.get(
            "base_url", "https://api.semanticscholar.org/graph/v1/"
        ).rstrip("/")
        self.api_key = self.config.get("api_key", "")
        self.fields = "title,abstract,year,authors,externalIds,venue,url"

        # 有 key：允许 2 次退避重试（5s / 15s）
        # 无 key：只尝试 1 次，不重试（匿名限速窗口太长，重试无意义）
        has_key = bool(self.api_key and not self.api_key.startswith("${"))
        self._backoff_seq = [5, 15] if has_key else []

    # ------------------------------------------------------------
    def search(self, query: str, max_results: int = 20) -> List[ExternalDoc]:
        if not self.enabled:
            return []

        # 熔断器：若在冷却期内直接跳过（类级，跨实例共享）
        if time.time() < SemanticScholarClient._circuit_open_until:
            remaining = int(SemanticScholarClient._circuit_open_until - time.time())
            logger.info(f"SemanticScholarClient: 熔断冷却中（{remaining}s 后恢复），跳过本次调用")
            return []

        keyword_query = _boolean_to_keywords(query)
        if not keyword_query:
            return []

        headers = {"User-Agent": "RetrievalIntegration/1.0 (academic research)"}
        if self.api_key and not self.api_key.startswith("${"):
            headers["x-api-key"] = self.api_key

        params = {
            "query": keyword_query,
            "limit": min(max_results, 100),
            "fields": self.fields,
        }

        def _trigger_circuit():
            SemanticScholarClient._circuit_open_until = (
                time.time() + SemanticScholarClient._circuit_cooldown_s
            )
            logger.warning(
                f"SemanticScholarClient: 触发熔断，冷却 {SemanticScholarClient._circuit_cooldown_s}s"
            )

        for attempt, wait in enumerate([0] + self._backoff_seq):
            if wait > 0:
                logger.info(f"SemanticScholarClient 429，等待 {wait}s 后重试...")
                time.sleep(wait)
            try:
                resp = requests.get(
                    f"{self.base_url}/paper/search",
                    params=params,
                    headers=headers,
                    timeout=self.timeout_s,
                )
                if resp.status_code == 429:
                    if attempt < len(self._backoff_seq):
                        continue          # 触发下一次退避
                    _trigger_circuit()
                    logger.warning("SemanticScholarClient: 超过重试上限，触发熔断")
                    return []
                resp.raise_for_status()
                data = resp.json()
                return [_to_external_doc(p) for p in (data.get("data") or [])]
            except requests.HTTPError as e:
                if e.response is not None and e.response.status_code == 429:
                    if attempt < len(self._backoff_seq):
                        continue
                    _trigger_circuit()
                logger.warning(f"SemanticScholarClient 调用失败: {e}")
                return []
            except Exception as e:
                logger.warning(f"SemanticScholarClient 调用失败: {e}")
                return []

        return []


# ============================================================
# 工具函数
# ============================================================

def _boolean_to_keywords(query: str) -> str:
    """
    把 M4 生成的布尔式降级为关键词串。

    `("metamaterial" OR "absorber") AND ("FR4")` → `metamaterial absorber FR4`
    """
    if not query:
        return ""
    text = re.sub(r"\b(AND|OR|NOT)\b", " ", query, flags=re.IGNORECASE)
    text = text.replace("(", " ").replace(")", " ")
    text = re.sub(r"\s+", " ", text).strip()
    return text


def _to_external_doc(item: Dict[str, Any]) -> ExternalDoc:
    ext_ids = item.get("externalIds") or {}
    doi = ext_ids.get("DOI")
    if doi:
        doi = doi.lower()

    authors = []
    for a in item.get("authors") or []:
        name = a.get("name") if isinstance(a, dict) else str(a)
        if name:
            authors.append(name)

    return ExternalDoc(
        title=item.get("title") or "",
        abstract=item.get("abstract") or "",
        authors=authors,
        year=item.get("year"),
        doi=doi,
        url=item.get("url"),
        venue=item.get("venue"),
        source_api="Semantic Scholar",
        raw=item,
    )
