#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
xinghe_client.py —— 星河图书馆 ROS API 客户端（真实实现）

调用 ROS API 的两个端点：
  - POST /v1/resources/metadata/query  (meta 库，按 publication_venue_name / publication_published_year 过滤)
  - POST /v1/resources/content/query   (content 库，按 magazine / pub_time 过滤；含 sha256 + origin_path)

认证：
  - 检索用 ROS_API_KEY    → X-API-Key 头
  - 下载用 XINGHE_API_KEY → X-API-Key 头（参见 xinghe_downloader.py）

线程安全：
  每次 search() 内部 asyncio.run()，仅在子线程中创建 / 销毁 event loop，
  ExternalRetriever 已用 ThreadPoolExecutor 调度，兼容。
"""

import asyncio
import logging
import re
import ssl
from typing import Any, Dict, List, Optional, Tuple

import aiohttp

from .base_client import ExternalAPIClient, ExternalDoc

logger = logging.getLogger(__name__)


# ------------------------------------------------------------------
# SSL 上下文（星河内网证书不走默认链，沿用示例代码的宽松配置）
# ------------------------------------------------------------------
def _create_ssl_context() -> ssl.SSLContext:
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx


_SSL_CTX = _create_ssl_context()


# ------------------------------------------------------------------
# 布尔查询串解析：把 M4 生成的 `("A" OR "B") AND ("C")` 拍平为
# 两层列表 [[A, B], [C]]，其中外层 AND、内层 OR。
# ------------------------------------------------------------------
_QUOTED_TOKEN = re.compile(r'"([^"]+)"')


def parse_boolean_query(q: str) -> List[List[str]]:
    """把布尔查询串解析成 AND-of-OR 结构。

    支持三种输入：
      1. M4 风格 `("term1" OR "term2") AND ("term3")`
      2. 纯 AND `"a" AND "b"`
      3. 空格/分号分隔的裸词 `a; b c`

    返回 [[group1_terms], [group2_terms], ...]，组间 AND、组内 OR。
    """
    if not q or not q.strip():
        return []

    # 括号组 → 每个括号内的引号词为一组（OR）
    if "(" in q and ")" in q:
        groups: List[List[str]] = []
        for grp in re.findall(r"\(([^()]+)\)", q):
            terms = _QUOTED_TOKEN.findall(grp)
            if not terms:
                # 括号内没有引号时，按空白切分
                terms = [t for t in re.split(r"\s+(?:OR|AND)\s+|\s+", grp) if t.strip()]
            if terms:
                groups.append([t.strip() for t in terms if t.strip()])
        if groups:
            return groups

    # 无括号：引号词按 AND 拆分
    if '"' in q:
        and_parts = re.split(r"\s+AND\s+", q)
        groups = []
        for part in and_parts:
            terms = _QUOTED_TOKEN.findall(part)
            if not terms:
                terms = [part.strip().strip('"')]
            groups.append([t for t in terms if t])
        return [g for g in groups if g]

    # 裸词：按分号分组，组内按空格再切。没分号则全部当 OR。
    if ";" in q:
        return [[t.strip() for t in seg.split() if t.strip()] for seg in q.split(";") if seg.strip()]

    toks = [t for t in re.split(r"\s+(?:AND|OR)\s+|\s+", q) if t.strip()]
    return [[t] for t in toks] if toks else []


# ------------------------------------------------------------------
# 查询体构造
# ------------------------------------------------------------------
_META_FIELDS = [
    "title", "author", "doi",
    "publication_published_year", "publication_venue_name",
    "abstract", "type", "isbn13",
]
_CONTENT_FIELDS = [
    "sha256", "title", "author", "doi",
    "file_format", "origin_path", "magazine", "pub_time",
]


def _or_title_abstract(term: str) -> Dict[str, Any]:
    return {
        "type": "or",
        "conditions": [
            {"field": "title", "operator": "$match", "value": term},
            {"field": "abstract", "operator": "$match", "value": term},
        ],
    }


def _build_search_condition(groups: List[List[str]]) -> Dict[str, Any]:
    """groups = [[or-terms], ...] → 嵌套 and-of-or 条件树。"""
    assert groups, "empty groups"
    and_items: List[Dict[str, Any]] = []
    for group in groups:
        or_conds = []
        for term in group:
            or_conds.extend([
                {"field": "title", "operator": "$match", "value": term},
                {"field": "abstract", "operator": "$match", "value": term},
            ])
        and_items.append({"type": "or", "conditions": or_conds})
    if len(and_items) == 1:
        return and_items[0]
    return {"type": "and", "conditions": and_items}


def _build_body(
    groups: List[List[str]],
    fields: List[str],
    venues: Optional[List[str]],
    venue_field: str,
    year_field: str,
    year_from: Optional[int],
    year_to: Optional[int],
    year_is_date: bool,
) -> Dict[str, Any]:
    body: Dict[str, Any] = {
        "search": _build_search_condition(groups),
        "projection": {"fields": list(fields)},
    }

    filter_conds: List[Dict[str, Any]] = []
    if venues:
        filter_conds.append({"field": venue_field, "operator": "$in", "value": list(venues)})
    if year_from is not None:
        val = f"{year_from}-01-01" if year_is_date else year_from
        filter_conds.append({"field": year_field, "operator": "$gte", "value": val})
    if year_to is not None:
        val = f"{year_to}-12-31" if year_is_date else year_to
        filter_conds.append({"field": year_field, "operator": "$lte", "value": val})
    if filter_conds:
        body["filter"] = {"type": "and", "conditions": filter_conds}
    return body


# ------------------------------------------------------------------
# XingheClient
# ------------------------------------------------------------------
class XingheClient(ExternalAPIClient):
    """星河图书馆 ROS API 检索客户端。

    config 支持字段（见 default_config.yaml 的 m5_external_retrieval.clients.xinghe）：
      enabled, base_url (或 ros_api_base), api_key (ROS key),
      page_size, max_pages, year_from, year_to, venues, timeout_s,
      concurrency, search_targets (["meta", "content"] 的子集)
    """

    name = "星河图书馆"

    DEFAULT_BASE_URL = "https://ros-api.ros.shlab.tech:18443"
    DEFAULT_PAGE_SIZE = 200
    DEFAULT_MAX_PAGES = 1          # pipeline 场景下只取第一页足够，批量任务用 CLI
    DEFAULT_CONCURRENCY = 8

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        # 兼容旧 base_url；优先使用 ros_api_base
        self.base_url: str = (
            self.config.get("ros_api_base")
            or self.config.get("base_url")
            or self.DEFAULT_BASE_URL
        )
        self.api_key: str = self.config.get("api_key", "") or ""

        self.page_size: int = int(self.config.get("page_size", self.DEFAULT_PAGE_SIZE))
        self.max_pages: int = int(self.config.get("max_pages", self.DEFAULT_MAX_PAGES))
        self.concurrency: int = int(self.config.get("concurrency", self.DEFAULT_CONCURRENCY))
        self.year_from: Optional[int] = self.config.get("year_from")
        self.year_to: Optional[int] = self.config.get("year_to")
        self.venues: List[str] = list(self.config.get("venues", []) or [])

        targets = self.config.get("search_targets") or ["meta", "content"]
        self.search_targets: List[str] = [t for t in targets if t in ("meta", "content")]
        if not self.search_targets:
            self.search_targets = ["meta", "content"]

    # --------------------------------------------------------------
    # 健康检查：key 是否存在 + base_url 是否合法
    # --------------------------------------------------------------
    def health_check(self) -> bool:
        if not self.enabled:
            return False
        if not self.api_key or self.api_key.startswith("${"):
            return False
        if not self.base_url or self.base_url.startswith("${"):
            return False
        # 快速 TCP 连通性检查（3s 超时），避免后续每轮都等完整超时
        import socket
        from urllib.parse import urlparse
        try:
            parsed = urlparse(self.base_url)
            host = parsed.hostname or ""
            port = parsed.port or (443 if parsed.scheme == "https" else 80)
            with socket.create_connection((host, port), timeout=3):
                pass
        except OSError:
            logger.info("XingheClient: TCP 连通性检查失败（%s），跳过", self.base_url)
            return False
        return True

    # --------------------------------------------------------------
    # 同步对外接口（BaseClient 约定）
    # --------------------------------------------------------------
    def search(self, query: str, max_results: int = 20) -> List[ExternalDoc]:
        if not self.enabled:
            return []
        if not self.health_check():
            logger.warning(
                "XingheClient: ROS api_key / base_url 未配置 "
                "(env 变量 ROS_API_KEY 可能未设置)，跳过调用"
            )
            return []

        groups = parse_boolean_query(query)
        if not groups:
            logger.debug("XingheClient: empty query groups, skip")
            return []

        try:
            items = asyncio.run(self._search_async(groups, max_results))
        except RuntimeError as e:
            # 已在 event loop 里（罕见）→ 退化为新建临时 loop
            if "event loop" in str(e).lower():
                loop = asyncio.new_event_loop()
                try:
                    items = loop.run_until_complete(self._search_async(groups, max_results))
                finally:
                    loop.close()
            else:
                raise
        except Exception as e:
            logger.warning(f"XingheClient 调用失败: {e}")
            return []

        return [self._to_doc(x) for x in items[:max_results]]

    # --------------------------------------------------------------
    # 内部 async 实现
    # --------------------------------------------------------------
    async def _search_async(
        self,
        groups: List[List[str]],
        max_results: int,
    ) -> List[Dict[str, Any]]:
        sem = asyncio.Semaphore(self.concurrency)
        connector = aiohttp.TCPConnector(limit=self.concurrency, limit_per_host=self.concurrency)
        async with aiohttp.ClientSession(connector=connector) as session:
            tasks = []
            if "meta" in self.search_targets:
                tasks.append(self._search_meta(session, sem, groups))
            if "content" in self.search_targets:
                tasks.append(self._search_content(session, sem, groups))
            results = await asyncio.gather(*tasks, return_exceptions=True)

        meta_items: List[Dict[str, Any]] = []
        content_items: List[Dict[str, Any]] = []
        for i, target in enumerate(self.search_targets):
            r = results[i]
            if isinstance(r, Exception):
                logger.warning(f"XingheClient [{target}] 查询失败: {r}")
                continue
            if target == "meta":
                meta_items = r  # type: ignore[assignment]
            else:
                content_items = r  # type: ignore[assignment]

        merged = self._merge(meta_items, content_items)
        return merged[:max_results]

    async def _search_meta(self, session, sem, groups) -> List[Dict[str, Any]]:
        body = _build_body(
            groups=groups,
            fields=_META_FIELDS,
            venues=self.venues or None,
            venue_field="publication_venue_name",
            year_field="publication_published_year",
            year_from=self.year_from,
            year_to=self.year_to,
            year_is_date=False,
        )
        return await self._query_all_pages(session, sem, "/v1/resources/metadata/query", body)

    async def _search_content(self, session, sem, groups) -> List[Dict[str, Any]]:
        body = _build_body(
            groups=groups,
            fields=_CONTENT_FIELDS,
            venues=self.venues or None,
            venue_field="magazine",
            year_field="pub_time",
            year_from=self.year_from,
            year_to=self.year_to,
            year_is_date=True,
        )
        return await self._query_all_pages(session, sem, "/v1/resources/content/query", body)

    async def _query_all_pages(self, session, sem, endpoint, body) -> List[Dict[str, Any]]:
        out: List[Dict[str, Any]] = []
        for page in range(1, self.max_pages + 1):
            paged = dict(body)
            paged["pagination"] = {"page": page, "page_size": self.page_size}
            data = await self._post(session, sem, endpoint, paged)
            if data is None:
                break
            items = (data.get("data") or {}).get("items") or []
            if not items:
                break
            out.extend(items)
            if len(items) < self.page_size:
                break
        return out

    async def _post(self, session, sem, endpoint, body) -> Optional[Dict[str, Any]]:
        url = f"{self.base_url}{endpoint}"
        headers = {"X-API-Key": self.api_key, "Content-Type": "application/json"}
        async with sem:
            try:
                async with session.post(
                    url, json=body, headers=headers, ssl=_SSL_CTX,
                    timeout=aiohttp.ClientTimeout(total=self.timeout_s),
                ) as resp:
                    if resp.status != 200:
                        text = await resp.text()
                        logger.warning(
                            f"XingheClient HTTP {resp.status} on {endpoint}: {text[:300]}"
                        )
                        return None
                    return await resp.json()
            except Exception as e:
                logger.warning(f"XingheClient POST {endpoint} 失败: {e}")
                return None

    # --------------------------------------------------------------
    # meta + content 合并：按 DOI 去重，优先带 origin_path 的行
    # --------------------------------------------------------------
    @staticmethod
    def _merge(
        meta: List[Dict[str, Any]],
        content: List[Dict[str, Any]],
    ) -> List[Dict[str, Any]]:
        by_doi: Dict[str, Dict[str, Any]] = {}
        orphans: List[Dict[str, Any]] = []

        def _norm_meta(m: Dict[str, Any]) -> Dict[str, Any]:
            return {
                "title": m.get("title") or "",
                "author": _join_authors(m.get("author")),
                "abstract": m.get("abstract") or "",
                "year": _extract_year(m.get("publication_published_year")),
                "venue": m.get("publication_venue_name") or "",
                "doi": (m.get("doi") or "").strip(),
                "type": m.get("type") or "",
                "isbn": m.get("isbn13") or "",
                "sha256": "",
                "origin_path": "",
                "_source": "meta",
            }

        def _norm_content(m: Dict[str, Any]) -> Dict[str, Any]:
            return {
                "title": m.get("title") or "",
                "author": _join_authors(m.get("author")),
                "abstract": "",
                "year": _extract_year(m.get("pub_time")),
                "venue": m.get("magazine") or "",
                "doi": (m.get("doi") or "").strip(),
                "type": m.get("file_format") or "",
                "isbn": "",
                "sha256": m.get("sha256") or "",
                "origin_path": m.get("origin_path") or "",
                "_source": "content",
            }

        for m in meta:
            row = _norm_meta(m)
            doi = row["doi"]
            if doi:
                by_doi.setdefault(doi, row)
            else:
                orphans.append(row)

        for c in content:
            row = _norm_content(c)
            doi = row["doi"]
            if not doi:
                orphans.append(row)
                continue
            prev = by_doi.get(doi)
            if prev is None:
                by_doi[doi] = row
                continue
            # 用 content 补 meta 空缺字段（origin_path / sha256），反之亦然
            for k in ("abstract", "venue", "isbn", "year", "type"):
                if not prev.get(k) and row.get(k):
                    prev[k] = row[k]
            for k in ("sha256", "origin_path"):
                if not prev.get(k) and row.get(k):
                    prev[k] = row[k]

        return list(by_doi.values()) + orphans

    # --------------------------------------------------------------
    # 规范化为 ExternalDoc
    # --------------------------------------------------------------
    def _to_doc(self, row: Dict[str, Any]) -> ExternalDoc:
        return ExternalDoc(
            title=row.get("title") or "",
            abstract=row.get("abstract") or "",
            authors=_split_authors(row.get("author")),
            year=row.get("year"),
            doi=row.get("doi") or None,
            url=row.get("origin_path") or None,
            venue=row.get("venue") or None,
            source_api=self.name,
            raw={
                "sha256": row.get("sha256", ""),
                "origin_path": row.get("origin_path", ""),
                "file_type": row.get("type", ""),
                "isbn": row.get("isbn", ""),
                "_source": row.get("_source", ""),
            },
        )


# ------------------------------------------------------------------
# helpers
# ------------------------------------------------------------------
def _join_authors(value: Any) -> str:
    if isinstance(value, (list, tuple)):
        return "; ".join(str(x).strip() for x in value if str(x).strip())
    return str(value or "").strip()


def _split_authors(text: Any) -> List[str]:
    if isinstance(text, (list, tuple)):
        return [str(x).strip() for x in text if str(x).strip()]
    s = str(text or "").strip()
    if not s:
        return []
    return [p.strip() for p in re.split(r"[;,]|\band\b", s) if p.strip()]


def _extract_year(value: Any) -> Optional[int]:
    if value is None:
        return None
    if isinstance(value, int):
        return value if 1000 <= value <= 2999 else None
    m = re.match(r"^\s*(\d{4})", str(value))
    return int(m.group(1)) if m else None
