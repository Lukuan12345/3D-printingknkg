#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
base_client.py —— 外部 API 客户端抽象基类
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class ExternalDoc:
    """统一的外部文献结构。"""

    title: str = ""
    abstract: str = ""
    authors: List[str] = field(default_factory=list)
    year: Optional[int] = None
    doi: Optional[str] = None
    url: Optional[str] = None
    venue: Optional[str] = None          # 期刊/会议
    source_api: str = ""                 # 来源 API 名称
    raw: Dict[str, Any] = field(default_factory=dict)  # 原始响应保留

    def unique_id(self) -> str:
        """用于去重的 ID。优先 DOI > URL > title。"""
        return (self.doi or self.url or self.title or "").strip()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "title": self.title,
            "abstract": self.abstract,
            "authors": self.authors,
            "year": self.year,
            "doi": self.doi,
            "url": self.url,
            "venue": self.venue,
            "source_api": self.source_api,
            "raw": self.raw,
        }


class ExternalAPIClient(ABC):
    """外部学术 API 的统一接口。"""

    name: str = "base"

    def __init__(self, config: Dict[str, Any]):
        self.config = config or {}
        self.enabled = bool(self.config.get("enabled", True))
        self.timeout_s = self.config.get("timeout_s", 30)

    @abstractmethod
    def search(self, query: str, max_results: int = 20) -> List[ExternalDoc]:
        """根据布尔查询获取文献。子类实现。"""
        raise NotImplementedError

    def health_check(self) -> bool:
        """默认健康检查（可被子类覆盖）。"""
        return self.enabled
