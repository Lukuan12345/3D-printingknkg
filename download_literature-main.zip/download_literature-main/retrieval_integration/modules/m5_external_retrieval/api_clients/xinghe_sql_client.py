#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
xinghe_sql_client.py —— 星河图书馆 SQL 客户端（可选后端）

通过 SQLAlchemy + MySQL 协议直连 StarRocks，模拟 ROS API 的 $match 词边界匹配。
仅在 env 变量 STARROCKS_HOST / STARROCKS_USER / STARROCKS_PASSWORD 齐全、
且配置 enabled=true 时可用。

相比 ROS API 的优势：
  - 无分页上限（API 单次 4000 条封顶）
  - 无需 ROS_API_KEY，只要数据库账号

依赖（可选，未安装则在 import 时直接报错）：
  pip install sqlalchemy pymysql
"""

import logging
import os
import re
import time
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import quote_plus

from .base_client import ExternalAPIClient, ExternalDoc

logger = logging.getLogger(__name__)


def _resolve_env(val: Any) -> str:
    """Resolve '${VAR_NAME}' → os.environ.get('VAR_NAME', ''), else return as-is."""
    if not isinstance(val, str):
        return str(val) if val else ""
    m = re.match(r"^\$\{(\w+)\}$", val.strip())
    if m:
        return os.environ.get(m.group(1), "")
    return val


# ------------------------------------------------------------------
# 延迟导入：允许 import api_clients 而不强制安装 sqlalchemy
# ------------------------------------------------------------------
def _require_sqlalchemy():
    try:
        from sqlalchemy import create_engine, text  # noqa: F401
        import pymysql  # noqa: F401
    except ImportError as e:
        raise ImportError(
            "XingheSQLClient 需要 sqlalchemy + pymysql："
            "pip install sqlalchemy pymysql"
        ) from e


# ------------------------------------------------------------------
# 单数据源：ads.ads_meta_xinghe_journal_paper_data_acc
# ------------------------------------------------------------------
_DEFAULT_SOURCES: List[Dict[str, str]] = [
    {
        "name": "xinghe_journal_paper",
        "table": "ads_meta_xinghe_journal_paper_data_acc",
        "journal_field": "journal_name",
        "select": (
            "title, author, "
            "publication_date AS pub_time, "
            "journal_name AS magazine, "
            "file_format AS file_type, "
            "abstract, doi, "
            "issn AS isbn, "
            "sha256, origin_path"
        ),
    },
]


# ------------------------------------------------------------------
# WHERE 子句构造（完全复刻示例代码的 $match 词边界模拟）
# ------------------------------------------------------------------
_SEARCH_FIELDS = ("title", "abstract")


def _escape_sql_string(s: str) -> str:
    return s.replace("\\", "\\\\").replace("'", "''")


def _tokenize(keyword: str) -> List[str]:
    return [t for t in re.findall(r"\w+", keyword.lower()) if t]


def _kw_clause(keyword: str, fields=_SEARCH_FIELDS) -> str:
    tokens = _tokenize(keyword)
    if not tokens:
        return "1=1"
    clauses = []
    for tok in tokens:
        esc = _escape_sql_string(tok)
        if tok.isascii():
            pattern = f"(^|[^a-z0-9_]){esc}s?([^a-z0-9_]|$)"
            ors = [f"LOWER({f}) RLIKE '{pattern}'" for f in fields]
        else:
            ors = [f"{f} LIKE '%{esc}%'" for f in fields]
        clauses.append("(" + " OR ".join(ors) + ")")
    return "(" + " AND ".join(clauses) + ")"


def _or_group(terms: List[str]) -> str:
    if not terms:
        return "1=1"
    return "(" + " OR ".join(_kw_clause(t) for t in terms) + ")"


def _and_groups(groups: List[List[str]]) -> str:
    if not groups:
        return "1=1"
    return "(" + " AND ".join(_or_group(g) for g in groups) + ")"


def _venue_clause(venues: List[str], field: str) -> str:
    if not venues:
        return ""
    quoted = ", ".join("'" + _escape_sql_string(v.lower()) + "'" for v in venues)
    return f"LOWER({field}) IN ({quoted})"


def _year_clause(year_from: Optional[int], year_to: Optional[int]) -> str:
    parts = []
    if year_from is not None:
        parts.append(f"publication_date >= '{year_from}-01-01'")
    if year_to is not None:
        parts.append(f"publication_date <= '{year_to}-12-31'")
    return " AND ".join(parts)


# ------------------------------------------------------------------
# Client
# ------------------------------------------------------------------
class XingheSQLClient(ExternalAPIClient):
    """直连 StarRocks 的星河 SQL 检索客户端。"""

    name = "星河图书馆SQL"

    DEFAULT_PORT = 30030
    DEFAULT_DATABASE = "ads"
    DEFAULT_ROW_LIMIT = 10000

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.host: str = _resolve_env(self.config.get("host") or "") or os.environ.get("STARROCKS_HOST", "")
        self.port: int = int(self.config.get("port", self.DEFAULT_PORT))
        self.user: str = _resolve_env(self.config.get("user") or "") or os.environ.get("STARROCKS_USER", "")
        self.password: str = _resolve_env(self.config.get("password") or "") or os.environ.get("STARROCKS_PASSWORD", "")
        self.database: str = self.config.get("database", self.DEFAULT_DATABASE)
        self.row_limit: int = int(self.config.get("row_limit", self.DEFAULT_ROW_LIMIT))
        self.year_from: Optional[int] = self.config.get("year_from")
        self.year_to: Optional[int] = self.config.get("year_to")
        self.venues: List[str] = list(self.config.get("venues", []) or [])
        self.sources: List[Dict[str, str]] = (
            list(self.config.get("sources", []) or []) or _DEFAULT_SOURCES
        )

        self._engine = None  # 懒加载，避免无 sqlalchemy 也能 import 这个类

    # --------------------------------------------------------------
    def health_check(self) -> bool:
        if not (self.enabled and self.host and self.user and self.password):
            return False
        import socket
        try:
            with socket.create_connection((self.host, self.port), timeout=3):
                pass
            return True
        except OSError:
            return False

    def _get_engine(self):
        if self._engine is not None:
            return self._engine
        _require_sqlalchemy()
        from sqlalchemy import create_engine
        user = quote_plus(self.user)
        pwd = quote_plus(self.password)
        url = (
            f"mysql+pymysql://{user}:{pwd}@{self.host}:{self.port}/{self.database}"
            "?charset=utf8mb4"
        )
        self._engine = create_engine(
            url, pool_recycle=3600, pool_pre_ping=True, pool_size=4, max_overflow=4,
            connect_args={"connect_timeout": 5},
        )
        return self._engine

    # --------------------------------------------------------------
    def search(self, query: str, max_results: int = 20) -> List[ExternalDoc]:
        if not self.enabled:
            return []
        if not self.health_check():
            logger.warning(
                "XingheSQLClient: StarRocks 连接参数未配置 "
                "(env STARROCKS_HOST / STARROCKS_USER / STARROCKS_PASSWORD)，跳过"
            )
            return []

        # 复用 xinghe_client 的解析器
        from .xinghe_client import parse_boolean_query  # 局部 import 避免循环
        groups = parse_boolean_query(query)
        if not groups:
            return []

        try:
            rows = self._execute(groups, max_results)
        except Exception as e:
            logger.warning(f"XingheSQLClient 查询失败: {e}")
            return []

        return [self._to_doc(r) for r in rows[:max_results]]

    # --------------------------------------------------------------
    def _execute(self, groups: List[List[str]], max_results: int) -> List[Dict[str, Any]]:
        from sqlalchemy import text

        engine = self._get_engine()
        all_rows: List[Dict[str, Any]] = []
        where_search = _and_groups(groups)
        where_venue = _venue_clause(self.venues, "journal_name")
        where_year = _year_clause(self.year_from, self.year_to)

        where_parts = [w for w in [where_venue, where_year, where_search] if w]
        where = " AND ".join(where_parts) if where_parts else "1=1"

        limit = min(self.row_limit, max(max_results * 5, 200))

        t0 = time.time()
        for source in self.sources:
            table = f"{self.database}.{source['table']}"
            sql = f"SELECT {source['select']} FROM {table} WHERE {where} LIMIT {limit}"
            try:
                with engine.connect() as conn:
                    result = conn.execute(text(sql))
                    cols = list(result.keys())
                    for row in result.fetchall():
                        all_rows.append(dict(zip(cols, row)))
            except Exception as e:
                logger.warning(f"XingheSQLClient source={source['name']} SQL 失败: {e}")

        if not all_rows:
            return []

        # 去重（doi > title > sha256）+ 优先保留有 origin_path 的
        seen: Dict[str, int] = {}  # key -> index in deduped
        deduped: List[Dict[str, Any]] = []
        for row in all_rows:
            key = str(row.get("doi") or row.get("title") or row.get("sha256") or "")
            if not key:
                continue
            has_path = bool(str(row.get("origin_path") or "").strip())
            if key not in seen:
                seen[key] = len(deduped)
                deduped.append(row)
            elif has_path and not str(deduped[seen[key]].get("origin_path") or "").strip():
                # 已有记录没路径，当前有路径，替换
                deduped[seen[key]] = row

        logger.info(
            f"XingheSQLClient: {len(deduped)} 条结果（去重前 {len(all_rows)}）({time.time() - t0:.2f}s)"
        )
        return deduped

    # --------------------------------------------------------------
    def _to_doc(self, row: Dict[str, Any]) -> ExternalDoc:
        from .xinghe_client import _extract_year, _split_authors  # 复用
        return ExternalDoc(
            title=str(row.get("title") or ""),
            abstract=str(row.get("abstract") or ""),
            authors=_split_authors(row.get("author")),
            year=_extract_year(row.get("pub_time")),
            doi=(str(row.get("doi") or "").strip() or None),
            url=(str(row.get("origin_path") or "").strip() or None),
            venue=(str(row.get("magazine") or "").strip() or None),
            source_api=self.name,
            raw={
                "sha256": row.get("sha256", ""),
                "origin_path": row.get("origin_path", ""),
                "file_type": row.get("file_type", ""),
                "isbn": row.get("isbn", ""),
            },
        )
