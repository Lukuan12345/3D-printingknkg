#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
pubmed_client.py —— PubMed E-utilities API 客户端（占位实现）

TODO: 完善 ESearch → ESummary → EFetch 流程。
      当前为最小实现：仅 ESearch 拿到 PMID 列表，不拉摘要。
"""

import logging
import requests
from typing import Any, Dict, List

from .base_client import ExternalAPIClient, ExternalDoc

logger = logging.getLogger(__name__)


class PubMedClient(ExternalAPIClient):
    name = "PubMed API"

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.base_url = self.config.get(
            "base_url", "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/"
        )
        self.api_key = self.config.get("api_key", "")

    def search(self, query: str, max_results: int = 20) -> List[ExternalDoc]:
        if not self.enabled:
            return []

        params = {
            "db": "pubmed",
            "term": query,
            "retmode": "json",
            "retmax": max_results,
        }
        if self.api_key and not self.api_key.startswith("${"):
            params["api_key"] = self.api_key

        try:
            resp = requests.get(
                f"{self.base_url.rstrip('/')}/esearch.fcgi",
                params=params,
                timeout=self.timeout_s,
            )
            resp.raise_for_status()
            data = resp.json()
        except Exception as e:
            logger.warning(f"PubMedClient 调用失败: {e}")
            return []

        pmids = data.get("esearchresult", {}).get("idlist", [])
        # 最小实现：只构造占位文档（Title/Abstract 留空，后续可扩展 ESummary）
        return [
            ExternalDoc(
                title=f"PubMed PMID:{pmid}",
                url=f"https://pubmed.ncbi.nlm.nih.gov/{pmid}/",
                source_api=self.name,
                raw={"pmid": pmid},
            )
            for pmid in pmids
        ]
