#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
openalex_client.py —— OpenAlex API 客户端

API 文档：https://docs.openalex.org/

特点：
- 完全免费，不需要 API key
- 配置 user_email 进入"Polite Pool"，更稳定（限速 10 req/s）
- /works 端点：按 search 字符串搜文献，返回完整 metadata（含期刊、作者、引用数等）
- 不支持复杂布尔语法 → 降级为关键词

替换：原 Bing Search API（已于 2025-08-11 下线）的位置。
"""

import logging
import re
import requests
from typing import Any, Dict, List

from .base_client import ExternalAPIClient, ExternalDoc

logger = logging.getLogger(__name__)


class OpenAlexClient(ExternalAPIClient):
    name = "OpenAlex"

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.base_url = self.config.get(
            "base_url", "https://api.openalex.org/"
        ).rstrip("/")
        # OpenAlex 推荐在请求里附带 email 进入 Polite Pool
        self.user_email = self.config.get("user_email", "") or ""
        self.select_fields = ",".join([
            "id", "doi", "title", "display_name", "publication_year",
            "abstract_inverted_index",
            "authorships", "primary_location",
            "open_access",   # OA PDF 链接（oa_url）
        ])

    # ------------------------------------------------------------
    def search(self, query: str, max_results: int = 20) -> List[ExternalDoc]:
        if not self.enabled:
            return []

        keyword_query = _boolean_to_keywords(query, english_only=True)
        if not keyword_query:
            logger.debug("OpenAlexClient: 过滤中文后无英文 keywords，跳过")
            return []

        params = {
            "search": keyword_query,
            "per-page": min(max_results, 200),
            "select": self.select_fields,
        }
        if self.user_email and not self.user_email.startswith("${"):
            params["mailto"] = self.user_email

        try:
            resp = requests.get(
                f"{self.base_url}/works",
                params=params,
                timeout=self.timeout_s,
                headers={"User-Agent": f"RetrievalIntegration/1.0 (mailto:{self.user_email})"
                         if self.user_email else "RetrievalIntegration/1.0"},
            )
            resp.raise_for_status()
            data = resp.json()
        except Exception as e:
            logger.warning(f"OpenAlexClient 调用失败: {e}")
            return []

        return [_to_external_doc(w) for w in (data.get("results") or [])]


# ============================================================
# 工具函数
# ============================================================

def _boolean_to_keywords(query: str, english_only: bool = False, max_tokens: int = 8) -> str:
    """
    把 M4 的布尔式降级为关键词串（OpenAlex search 不需要复杂语法）。

    english_only=True 时过滤中文 token（OpenAlex 是英文学术库）。
    max_tokens: 限制关键词数量，避免过度约束导致 0 结果。
    """
    if not query:
        return ""
    text = re.sub(r"\b(AND|OR|NOT)\b", " ", query, flags=re.IGNORECASE)
    text = text.replace("(", " ").replace(")", " ")
    text = text.replace('"', " ")   # 去掉引号，避免 OpenAlex 严格短语匹配
    text = re.sub(r"\s+", " ", text).strip()

    if english_only:
        # 只保留 ASCII 可打印字符（英文词、数字、连字符等）
        tokens = []
        for tok in text.split():
            if all(ord(c) < 128 for c in tok):
                tokens.append(tok)
        text = " ".join(tokens).strip()

    # 限制 token 数，取最前面的 max_tokens 个（M4 已按重要性排序）
    tokens = text.split()
    if len(tokens) > max_tokens:
        text = " ".join(tokens[:max_tokens])

    return text


def _strip_doi(doi: Any) -> str:
    """OpenAlex 返回的 DOI 是完整 URL，提取裸 DOI。"""
    if not doi or not isinstance(doi, str):
        return ""
    return doi.replace("https://doi.org/", "").replace("http://doi.org/", "").lower()


def _decode_inverted_abstract(inv: Dict[str, List[int]]) -> str:
    """
    OpenAlex 返回的是倒排索引格式的 abstract（节省带宽），需要还原。

    例: {"the": [0,5], "cat": [1]} → "the cat _ _ _ the"
    """
    if not inv:
        return ""
    # 找到最大位置
    max_pos = -1
    for positions in inv.values():
        if positions:
            max_pos = max(max_pos, max(positions))
    if max_pos < 0:
        return ""

    words = [""] * (max_pos + 1)
    for word, positions in inv.items():
        for p in positions:
            if 0 <= p <= max_pos:
                words[p] = word
    return " ".join(w for w in words if w)


def _to_external_doc(item: Dict[str, Any]) -> ExternalDoc:
    title = item.get("title") or item.get("display_name") or ""

    # 抽 abstract
    abstract = _decode_inverted_abstract(item.get("abstract_inverted_index") or {})

    # 抽 authors
    authors = []
    for ah in item.get("authorships") or []:
        author = (ah or {}).get("author") or {}
        name = author.get("display_name")
        if name:
            authors.append(name)

    # 抽 venue
    venue = None
    primary = item.get("primary_location") or {}
    src = primary.get("source") or {}
    if src.get("display_name"):
        venue = src["display_name"]

    # url 用 OpenAlex 自身链接（doi 也可）
    url = primary.get("landing_page_url") or item.get("id")

    return ExternalDoc(
        title=title,
        abstract=abstract,
        authors=authors,
        year=item.get("publication_year"),
        doi=_strip_doi(item.get("doi")) or None,
        url=url,
        venue=venue,
        source_api="OpenAlex",
        raw=item,
    )
