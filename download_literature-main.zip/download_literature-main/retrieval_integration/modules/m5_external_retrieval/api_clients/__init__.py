"""外部 API 客户端注册表。

2026-05-11 更新：
- XingheClient 从占位升级为真实 ROS API 实现（meta + content 双端点，
  async + 同步对外接口，分页、年份/期刊过滤、DOI 合并去重）
- 新增 XingheSQLClient（可选后端，直连 StarRocks，需 sqlalchemy+pymysql）
- 新增 XingheDownloader（S3 PDF 下载工具，供 scripts/ 使用）

2026-05-08 更新：
- 移除 BingClient（微软 2025-08-11 全面下线 Bing Search API）
- 新增 SemanticScholarClient 替换 PubMed（领域更匹配，电磁/超材料类）
- 新增 OpenAlexClient 替换 Bing（学术 metadata 覆盖最广，无需 key）
- PubMedClient 保留为可选（领域不匹配，默认 disabled），key 已申请留备用
"""
from .base_client import ExternalAPIClient, ExternalDoc
from .xinghe_client import XingheClient
from .xinghe_sql_client import XingheSQLClient
from .xinghe_downloader import XingheDownloader, build_save_name, build_tasks_from_csv, build_tasks_from_csv_dir
from .pubmed_client import PubMedClient
from .arxiv_client import ArxivClient
from .semantic_scholar_client import SemanticScholarClient
from .openalex_client import OpenAlexClient


# 名字 → 客户端类（与 m4_plan_generator.available_apis 对齐）
CLIENT_REGISTRY = {
    "星河图书馆":         XingheClient,
    "星河图书馆SQL":      XingheSQLClient,   # 可选：需 StarRocks 直连 + sqlalchemy+pymysql
    "arXiv":              ArxivClient,
    "Semantic Scholar":   SemanticScholarClient,
    "OpenAlex":           OpenAlexClient,
    "PubMed API":         PubMedClient,        # 保留但默认禁用，需要时可开
}


__all__ = [
    "ExternalAPIClient",
    "ExternalDoc",
    "XingheClient",
    "XingheSQLClient",
    "XingheDownloader",
    "build_save_name",
    "build_tasks_from_csv",
    "build_tasks_from_csv_dir",
    "PubMedClient",
    "ArxivClient",
    "SemanticScholarClient",
    "OpenAlexClient",
    "CLIENT_REGISTRY",
]
