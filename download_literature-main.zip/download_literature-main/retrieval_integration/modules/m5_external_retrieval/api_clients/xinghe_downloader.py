#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
xinghe_downloader.py —— 星河 S3 PDF 下载工具

下载端点（不同于 ROS 检索端点）：
  GET https://data-workbench.dc.shlab.tech/api/s3/v1/bucket/download?path=<origin_path>
  Header: X-API-Key: XINGHE_API_KEY

使用：
  >>> dl = XingheDownloader(api_key=os.environ["XINGHE_API_KEY"])
  >>> dl.download_many(tasks, output_dir="outputs/pdf")
  # tasks = [{"origin_path": "...", "title": "...", "pub_time": "...", "magazine": "..."}]

批量下载支持：
  - year-magazine-title 命名 + 断点续传（同名已存在则跳过）
  - 线程池并发
  - 失败列表返回供上层重试
"""

import logging
import os
import re
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

import requests

logger = logging.getLogger(__name__)


DEFAULT_DOWNLOAD_URL = "https://data-workbench.dc.shlab.tech/api/s3/v1/bucket/download"
DEFAULT_TIMEOUT: Tuple[int, int] = (30, 600)  # (connect, read)
DEFAULT_MAX_WORKERS = 10
_NAME_LOCK = threading.Lock()


# ------------------------------------------------------------------
# 文件名处理
# ------------------------------------------------------------------
def _year_from_pub_time(pub_time: Any) -> str:
    if pub_time is None:
        return "unknown"
    s = str(pub_time).strip()
    if not s:
        return "unknown"
    m = re.match(r"^(\d{4})", s)
    return m.group(1) if m else "unknown"


def _sanitize_filename_part(s: Any, max_len: int = 100) -> str:
    if s is None:
        return "unknown"
    t = str(s).strip()
    if not t:
        return "unknown"
    t = re.sub(r"[\r\n\t]+", " ", t)
    t = re.sub(r'[<>:"/\\|?*]', "_", t)
    t = re.sub(r"[\x00-\x1f\x7f]", "", t)
    t = re.sub(r"\s+", " ", t).strip(" .")
    if len(t) > max_len:
        t = t[:max_len].rstrip()
    return t or "unknown"


def _url_ext(url: Any) -> str:
    path_part = str(url).split("?")[0]
    ext = os.path.splitext(path_part)[1]
    return ext if ext else ".pdf"


def build_save_name(
    pub_time: Any,
    magazine: Any,
    title: Any,
    origin_path: Any,
    used: Optional[set] = None,
) -> str:
    """生成 `YYYY-journal-title[_n].ext` 格式的文件名，线程安全。"""
    year = _year_from_pub_time(pub_time)
    mag = _sanitize_filename_part(magazine, max_len=60)
    tit = _sanitize_filename_part(title, max_len=120)
    stem = f"{year}-{mag}-{tit}"
    ext = _url_ext(origin_path)
    if not ext.startswith("."):
        ext = "." + ext
    base = stem + ext

    if used is None:
        return base

    with _NAME_LOCK:
        if base not in used:
            used.add(base)
            return base
        n = 2
        name_stem, ext2 = os.path.splitext(base)
        while True:
            cand = f"{name_stem}_{n}{ext2}"
            if cand not in used:
                used.add(cand)
                return cand
            n += 1


# ------------------------------------------------------------------
# Downloader
# ------------------------------------------------------------------
class XingheDownloader:
    """星河 S3 PDF 下载器。"""

    def __init__(
        self,
        api_key: str,
        download_url: str = DEFAULT_DOWNLOAD_URL,
        timeout: Tuple[int, int] = DEFAULT_TIMEOUT,
        max_workers: int = DEFAULT_MAX_WORKERS,
        verify_ssl: bool = False,
    ):
        self.api_key = api_key
        self.download_url = download_url
        self.timeout = timeout
        self.max_workers = max_workers
        self.verify_ssl = verify_ssl

    # --------------------------------------------------------------
    def download_one(
        self,
        origin_path: str,
        output_dir: str,
        save_name: Optional[str] = None,
    ) -> Tuple[bool, str]:
        """下载单个文件。返回 (success, filename_or_error)。"""
        if not origin_path or not str(origin_path).strip():
            return False, "(empty origin_path)"

        os.makedirs(output_dir, exist_ok=True)
        if not save_name:
            save_name = os.path.basename(str(origin_path).split("?")[0]) or "download.pdf"
        save_name = os.path.basename(str(save_name).strip()) or "download.pdf"
        save_path = os.path.join(output_dir, save_name)

        if os.path.exists(save_path) and os.path.getsize(save_path) > 0:
            return True, save_name

        try:
            resp = requests.get(
                self.download_url,
                headers={"X-API-Key": self.api_key},
                params={"path": str(origin_path)},
                stream=True,
                timeout=self.timeout,
                verify=self.verify_ssl,
            )
            if resp.status_code == 200:
                with open(save_path, "wb") as f:
                    for chunk in resp.iter_content(chunk_size=8192):
                        if chunk:
                            f.write(chunk)
                return True, save_name
            return False, f"HTTP {resp.status_code}"
        except Exception as e:
            return False, str(e)

    # --------------------------------------------------------------
    def download_many(
        self,
        records: Iterable[Dict[str, Any]],
        output_dir: str,
        max_workers: Optional[int] = None,
    ) -> Dict[str, Any]:
        """批量下载。

        Args:
            records: 每条 dict 需含 origin_path；可选 pub_time / magazine / title 决定文件名。
            output_dir: 保存目录。
            max_workers: 线程数；默认取 self.max_workers。

        Returns:
            dict(ok=N, fail=N, items=[{origin_path, save_name, success, error?}])
        """
        records = [r for r in records if r.get("origin_path")]
        if not records:
            return {"ok": 0, "fail": 0, "items": []}

        os.makedirs(output_dir, exist_ok=True)
        used: set = set()
        tasks: List[Tuple[Dict[str, Any], str]] = []
        for r in records:
            name = r.get("save_name") or build_save_name(
                r.get("pub_time"), r.get("magazine"), r.get("title"),
                r["origin_path"], used,
            )
            tasks.append((r, name))

        w = max_workers or self.max_workers
        results: List[Dict[str, Any]] = []
        ok = fail = 0
        with ThreadPoolExecutor(max_workers=w) as pool:
            futures = {
                pool.submit(self.download_one, r["origin_path"], output_dir, name): (r, name)
                for r, name in tasks
            }
            for fut in as_completed(futures):
                r, name = futures[fut]
                try:
                    success, msg = fut.result()
                except Exception as e:
                    success, msg = False, str(e)
                entry = {
                    "origin_path": r["origin_path"],
                    "save_name": name,
                    "success": success,
                }
                if not success:
                    entry["error"] = msg
                    fail += 1
                else:
                    ok += 1
                results.append(entry)

        logger.info(
            f"XingheDownloader: ok={ok} fail={fail} dir={os.path.abspath(output_dir)}"
        )
        return {"ok": ok, "fail": fail, "items": results}


# ------------------------------------------------------------------
# CSV-driven 工厂：从 CSV 读取 origin_path 批量下载
# ------------------------------------------------------------------
def build_tasks_from_csv(csv_path: str) -> List[Dict[str, Any]]:
    """读取 CSV 产出 download_many 所需的 records。"""
    import csv

    tasks: List[Dict[str, Any]] = []
    seen_paths: set = set()
    with open(csv_path, "r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            p = (row.get("origin_path") or "").strip()
            if not p or p in seen_paths:
                continue
            seen_paths.add(p)
            tasks.append({
                "origin_path": p,
                "title": row.get("title", ""),
                "pub_time": row.get("pub_time") or row.get("publication_date") or "",
                "magazine": row.get("magazine") or row.get("journal_name") or "",
            })
    return tasks


def build_tasks_from_csv_dir(csv_dir: str) -> List[Dict[str, Any]]:
    """读取一个目录下所有 CSV 合并去重。"""
    tasks: List[Dict[str, Any]] = []
    seen: set = set()
    for p in sorted(Path(csv_dir).glob("*.csv")):
        for t in build_tasks_from_csv(str(p)):
            if t["origin_path"] in seen:
                continue
            seen.add(t["origin_path"])
            tasks.append(t)
    return tasks
