#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
arxiv_client.py —— arXiv API 客户端

使用 arXiv 公开 API（无需认证）：
    http://export.arxiv.org/api/query?search_query=...&max_results=...
返回 Atom XML，这里用简单正则解析（避免额外依赖）。
"""

import logging
import re
import requests
from typing import Any, Dict, List
from urllib.parse import urlencode

from .base_client import ExternalAPIClient, ExternalDoc

logger = logging.getLogger(__name__)


class ArxivClient(ExternalAPIClient):
    name = "arXiv"

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.base_url = self.config.get(
            "base_url", "http://export.arxiv.org/api/query"
        )

    def search(self, query: str, max_results: int = 20) -> List[ExternalDoc]:
        if not self.enabled:
            return []

        params = {
            "search_query": self._to_arxiv_query(query),
            "max_results": max_results,
            "sortBy": "relevance",
            "sortOrder": "descending",
        }
        url = f"{self.base_url}?{urlencode(params)}"

        try:
            resp = requests.get(url, timeout=self.timeout_s)
            resp.raise_for_status()
            xml = resp.text
        except Exception as e:
            logger.warning(f"ArxivClient 调用失败: {e}")
            return []

        return self._parse_atom(xml)

    # ------------------------------------------------------------
    @staticmethod
    def _to_arxiv_query(q: str) -> str:
        """将布尔式转 arXiv 查询串。

        处理两种输入格式：
        1. M4 生成的括号+引号式  ("term1" OR "term2") AND ("term3")
           → (all:"term1" OR all:"term2") AND (all:"term3")
           规则：在没有字段前缀的每个 " 前插入 all:，括号和 AND/OR 保留原样。

        2. 简单空格分隔或 AND/OR 连接的纯词
           FSS wideband  →  all:"FSS wideband"
           FSS AND wideband  →  all:"FSS" AND all:"wideband"
        """
        if not q.strip():
            return q

        # 格式1：已含引号，逐个 " 加前缀（lookbehind 排除已有 field: 前缀）
        if '"' in q:
            # (?<![:\w]) 匹配「前一个字符不是字母/数字/冒号」的引号位置
            return re.sub(r'(?<![:\w])"', 'all:"', q)

        # 格式2：纯文本，按 AND/OR/NOT 拆分并用 all: 包裹各段
        tokens = re.split(r'\s+(AND|OR|NOT)\s+', q.strip())
        result = []
        for token in tokens:
            if token in ('AND', 'OR', 'NOT'):
                result.append(token)
            else:
                token = token.strip()
                if not token:
                    continue
                if ':' in token or token.startswith('"'):
                    result.append(token)
                else:
                    result.append(f'all:"{token}"')
        return ' '.join(result)

    @staticmethod
    def _parse_atom(xml: str) -> List[ExternalDoc]:
        docs = []
        entries = re.findall(r"<entry>(.*?)</entry>", xml, re.DOTALL)
        for e in entries:
            def _get(tag: str) -> str:
                m = re.search(rf"<{tag}[^>]*>(.*?)</{tag}>", e, re.DOTALL)
                return re.sub(r"\s+", " ", m.group(1)).strip() if m else ""

            title = _get("title")
            summary = _get("summary")
            arxiv_id = _get("id")
            published = _get("published")
            authors = re.findall(r"<name>(.*?)</name>", e, re.DOTALL)
            year = None
            if published:
                ym = re.match(r"(\d{4})", published)
                if ym:
                    year = int(ym.group(1))

            docs.append(
                ExternalDoc(
                    title=title,
                    abstract=summary,
                    authors=[a.strip() for a in authors],
                    year=year,
                    url=arxiv_id,
                    source_api="arXiv",
                )
            )
        return docs
