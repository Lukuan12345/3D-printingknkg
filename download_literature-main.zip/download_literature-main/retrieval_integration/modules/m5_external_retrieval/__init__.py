"""模块5：外部检索。"""
from .executor import ExternalRetriever
from .deduplicator import dedupe_docs
from .api_clients import CLIENT_REGISTRY, ExternalDoc, ExternalAPIClient

__all__ = [
    "ExternalRetriever",
    "dedupe_docs",
    "CLIENT_REGISTRY",
    "ExternalDoc",
    "ExternalAPIClient",
]
