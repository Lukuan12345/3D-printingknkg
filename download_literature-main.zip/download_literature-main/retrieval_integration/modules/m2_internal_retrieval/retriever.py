#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
retriever.py —— 模块2：内部混合检索

通过 KBMVPAdapter 调用 kb_mvp 的三路混合检索（metadata + dense + sparse）。

2026-05-07 升级（F3）：在调 kb_mvp 之前先调 QueryStructurizer，目的有两个
  1. 生成**合规的 structured query_json**，让 kb_mvp 的 metadata 分支真正生效
     （此前手写 `{"matched_fields": [...]}` 不符合 kb_mvp 的 MetadataScorer 期望）
  2. 用 structured 里的 `search_keywords_cn/en + core_topic` 重构**关键词密集的
     query_text** 喂给 BM25 sparse，避免原始长 query 被 jieba 切得过碎导致 sparse=0
"""

from difflib import SequenceMatcher
import os
from pathlib import Path
import time
from typing import Any, Dict, List, Optional, Tuple

from ...core import BaseModule, RequestContext
from .kb_mvp_adapter import KBMVPAdapter
from .kg_path_adapter import KGPathAdapter
from .evidence_resolver import EvidenceResolver
from .confidence import compute_retrieval_confidence


def _safe_json_repr(obj: Any) -> str:
    """JSON 序列化，失败回退到 str()。"""
    import json
    try:
        return json.dumps(obj, ensure_ascii=False, indent=2, default=str)
    except Exception:  # noqa: BLE001
        return repr(obj)


def _ms(start: float) -> float:
    return round((time.perf_counter() - start) * 1000, 2)


class InternalRetriever(BaseModule):
    name = "m2_internal_retrieval"

    def __init__(
        self,
        config=None,
        adapter: Optional[KBMVPAdapter] = None,
        kg_adapter: Optional[KGPathAdapter] = None,
        evidence_resolver: Optional[EvidenceResolver] = None,
    ):
        super().__init__(config)

        weights = self._module_cfg.get("weights", {})
        self.adapter = adapter or KBMVPAdapter(weights=weights)

        # ----- KG 双轨 -----
        self.enable_kg_path = self._module_cfg.get("enable_kg_path", True)
        self.kg_adapter = kg_adapter  # 允许外部注入；下面 _ensure_kg_adapter 兜底
        kg_db = self._module_cfg.get(
            "kg_db_path", "scientific_kgqa/artifacts/kgqa.db"
        )
        kg_retr = self._module_cfg.get(
            "kg_retriever_path",
            "scientific_kgqa/artifacts/retriever.pkl",
        )
        self.kg_db_path = self.config.resolve_path(kg_db)
        self.kg_retriever_path = self.config.resolve_path(kg_retr)

        # 启动期自检：KG 开启但库文件缺失时，明确告警（最常见坑：配置库名与
        # build_kb_kg.py 产出名不一致，或还没建过 KG）。不中断启动——fast 通道
        # 不依赖 KG 仍可用；deep 通道会在 _kg_search 里走 error 分支并降级到外部兜底。
        if self.enable_kg_path:
            missing = [
                str(p) for p in (self.kg_db_path, self.kg_retriever_path)
                if not Path(p).exists()
            ]
            if missing:
                self.logger.warning(
                    "KG 库文件缺失 %s —— KG 推理轨将不可用（fast 模式无影响；deep 模式"
                    "降级到外部兜底）。请确认已跑 build_kb_kg.py，且 kg_db_path / "
                    "kg_retriever_path 与建库产出文件名一致（默认 kgqa.db / retriever.pkl）。",
                    missing,
                )

        # ----- 证据溯源 -----
        state_db = self._module_cfg.get(
            "state_db_path", "packages/aerospace.supermaterial/state.db"
        )
        self.state_db_path = self.config.resolve_path(state_db)
        self.evidence_resolver = evidence_resolver  # _ensure_resolver 兜底

        self.top_k = self._module_cfg.get("top_k", 10)
        recall = self._module_cfg.get("recall", {})
        self.top_k_each = max(
            recall.get("top_k_dense", 20),
            recall.get("top_k_sparse", 20),
        )

        self.confidence_strategy = self.config.get(
            "pipeline.m2_confidence_strategy", "reranker_top3_avg"
        )

        # F3: 是否用 QueryStructurizer 生成合规 query_json
        # 默认开启；关闭则退回 F1-F6 之前的"仅 dense 有效"行为
        self.use_structurizer = self._module_cfg.get("use_structurizer", True)

        # A2c (2026-05-09): 论文标题精确匹配 boost
        # 当 query 含完整论文标题前缀时，给该论文的所有 chunks 在 fused_score 上加 bonus
        # 解决根因：dense 信号无法区分"通用 FSS 论文"和"独特论文"，需要论文级独有指纹
        #
        # H1 (2026-05-10): 跨语言匹配
        # KB 标题为英文、query 标题前缀为中文时，SequenceMatcher 字符级相似度 = 0。
        # 升级为 hybrid 模式：
        #   - lexical：SequenceMatcher（保留同语言场景下的高精度）
        #   - semantic：BGE-M3 embedding cosine（中英跨语言原生支持）
        #   - hybrid：任一分支命中即视为匹配，排序时取 max(lex, sem) 作为强度
        # 任意分支命中阈值即视为 boost 候选；语义阈值通常低于字符相似度阈值
        # （跨语言 BGE-M3 同义对相似度典型在 0.55–0.75 区间）。
        boost_cfg = self._module_cfg.get("title_boost", {}) or {}
        self.title_boost_enabled = boost_cfg.get("enabled", True)
        self.title_boost_threshold = boost_cfg.get("threshold", 0.7)
        self.title_boost_bonus = boost_cfg.get("score_bonus", 0.3)
        self.title_boost_min_prefix_len = boost_cfg.get("min_prefix_len", 8)
        # H1: 新增字段
        self.title_boost_mode = boost_cfg.get("mode", "hybrid")  # lexical / semantic / hybrid
        self.title_boost_semantic_threshold = boost_cfg.get("semantic_threshold", 0.55)
        # H1.1 (Round 11 诊断修正)：FSS/FSR 同域 KB 中，semantic_threshold=0.55 会让 40+ 论文通过
        # 阈值，boost 失去区分度（hit_in_topk 反而下降）。cap 到 top-N 按相似度取最高，
        # 使 boost 只放大真正最像的几篇。设为 0 表示不封顶（旧行为）。
        self.title_boost_max_candidates = int(
            boost_cfg.get("max_candidates", 5) or 0
        )
        # H2 (Round 12, 2026-05-10): 解决 P093 等"通用 FSS 论文 dense 分超高，压制 P001 真正
        # 命中"的问题。两条互补改进：
        #   (a) inject_top_n：boost_papers 中若有论文未出现在 top-K，直接按 paper_id 反查并
        #       注入它们的 top-N best chunks（按 dense 相似度评分），保证目标论文有 chunk 可
        #       boost；解决"chunks 没在 top-K → boost 无用武之地"。
        #   (b) chunk_title_verify：对 boost 候选 chunk 计算 cosine(content, title_prefix)，
        #       将 score_bonus 按相似度调制，让真正讲该论文核心主题的 chunk 拿到更高 bonus，
        #       避免无差别给 paper 的所有 chunk 同等加分。
        #   (c) paper_level_rerank：boost 完成后按 paper-level 聚合分（max chunk score）做主排
        #       序，防止某篇 paper 的 5 个 chunk 占满 top-K 把另一篇有效论文挤掉。
        self.title_boost_inject_top_n = int(
            boost_cfg.get("inject_top_n", 2) or 0
        )
        self.title_boost_chunk_title_verify = bool(
            boost_cfg.get("chunk_title_verify", True)
        )
        # bonus 乘子下限：sim 再低也至少给 floor*bonus（避免数值噪声把 boost 完全打掉）
        self.title_boost_chunk_title_floor = float(
            boost_cfg.get("chunk_title_floor", 0.5)
        )
        self.title_boost_paper_level_rerank = bool(
            boost_cfg.get("paper_level_rerank", True)
        )
        # H2d (Round 12c): 分级 bonus —— 按 boost list 中论文排名赋予不同乘子
        # rank-1 paper（最相似，通常是 query 提及的目标论文）获最高 bonus，
        # 使其 injected chunk 能够超越 dense 基础分更高的通用 FSS 论文。
        self.title_boost_rank1_factor = float(
            boost_cfg.get("rank1_bonus_factor", 2.0)
        )
        self.title_boost_rank23_factor = float(
            boost_cfg.get("rank23_bonus_factor", 0.5)
        )
        self.title_boost_rank4plus_factor = float(
            boost_cfg.get("rank4plus_bonus_factor", 0.15)
        )

        # papers (paper_id, title) 缓存（首次需要时从 SQLite 加载）
        self._papers_titles_cache: Optional[List[Tuple[str, str]]] = None
        # H1: 标题向量缓存 (np.ndarray shape=(N, D), 与 _papers_titles_cache 顺序对齐)
        self._title_embeddings_cache = None
        # 语义分支不可用时记录一次性，后续直接降级到 lexical
        self._semantic_disabled = False

    # ------------------------------------------------------------
    def _run(self, ctx: RequestContext) -> RequestContext:
        # Step 1: 调 QueryStructurizer 生成合规 query_json
        structured = None
        query_text = ctx.query  # 默认用原始 query

        if self.use_structurizer:
            t = time.perf_counter()
            try:
                structured = self.adapter.structurize_query(ctx.query)
            except Exception as e:
                self.logger.warning(f"QueryStructurizer 失败，退回原始 query: {e}")
                structured = None
            ctx.fine_timings["m2.kb_structurize_ms"] = _ms(t)

            if structured:
                query_text = self._build_keyword_rich_query(ctx.query, structured)
                self.logger.info(
                    f"[{ctx.request_id}] Structurized → query_text={query_text[:80]!r}"
                )

        # Step 2: 调用 kb_mvp 三路融合
        t = time.perf_counter()
        try:
            result = self.adapter.search(
                query=query_text,
                query_json=structured,
                filters=None,
                top_k=self.top_k,
                top_k_each=self.top_k_each,
            )
        except Exception as e:
            self.logger.error(f"kb_mvp 检索失败: {e}")
            ctx.warnings.append(f"m2: 检索失败 {e}")
            ctx.retrieval_confidence = 0.0
            ctx.internal_chunks = []
            ctx.fine_timings["m2.kb_search_ms"] = _ms(t)
            return ctx
        ctx.fine_timings["m2.kb_search_ms"] = _ms(t)

        chunks = result.get("top_k", []) or []

        # Step 2.5: 论文标题精确匹配 boost（A2c + H1 + H2）
        # 若 query 含完整标题前缀，找到 KB 中标题高度匹配的论文，
        # 给这些论文的 chunks 在 fused_score 上加 bonus，重新排序
        if self.title_boost_enabled:
            boost_papers = self._find_boost_papers(ctx.query)
            if boost_papers:
                title_prefix = self._extract_paper_title(ctx.query)
                chunks = self._apply_title_boost(
                    chunks,
                    boost_papers,
                    query_text=query_text,
                    title_prefix=title_prefix,
                )
                injected = sum(1 for c in chunks if c.get("title_injected"))
                self.logger.info(
                    f"[{ctx.request_id}] title_boost: {boost_papers} "
                    f"(injected={injected})"
                )

        ctx.internal_chunks = chunks
        ctx.structured_query = structured

        # Step 3: 计算置信度
        ctx.retrieval_confidence = compute_retrieval_confidence(
            chunks, strategy=self.confidence_strategy
        )

        # ----- Step 4: KG 推理路径（需求 3b）-----
        if self.enable_kg_path:
            t = time.perf_counter()
            kg_result = self._kg_search(ctx.query)
            ctx.fine_timings["m2.kg_engine_ms"] = _ms(t)
            ctx.kg_reasoning_paths = kg_result.get("reasoning_paths", []) or []
            ctx.kg_evidence = kg_result.get("evidence", []) or []
            ctx.kg_retrieval_plan = kg_result.get("retrieval_plan", {}) or {}
            ctx.kg_summary = kg_result.get("summary", "") or ""
            ctx.kg_intent = kg_result.get("intent")
            ctx.kg_confidence = float(kg_result.get("confidence", 0.0) or 0.0)
            # 把 KG 内部分阶段耗时拍平到 fine_timings
            kg_timing = kg_result.get("timing") or {}
            for k, v in kg_timing.items():
                ctx.fine_timings[f"m2.kg_{k}"] = v
            if kg_result.get("error"):
                ctx.warnings.append(f"m2/kg: {kg_result['error']}")

        # ----- Step 5: 证据文献溯源（需求 3d）-----
        t = time.perf_counter()
        try:
            resolver = self._ensure_resolver()
            paper_uids = [c.get("paper_id") for c in chunks if c.get("paper_id")]
            # KG evidence 的 paper_id（来自 scientific_kgqa.paper.paper_id = sha1 paper_uid）
            for ev in ctx.kg_evidence:
                pid = ev.get("paper_id") or ev.get("paper_uid")
                if pid:
                    paper_uids.append(pid)
            # KG reasoning_paths 上的 support_papers（已带 paper_uid）
            for p in ctx.kg_reasoning_paths:
                if isinstance(p, dict):
                    for sp in p.get("support_papers", []) or []:
                        pid = sp.get("paper_id") or sp.get("paper_uid")
                        if pid:
                            paper_uids.append(pid)
            resolved = resolver.resolve(paper_uids)

            # paper_id 不命中时（kb_mvp demo 用 P001-P101，state.db 用 sha1），
            # 按 title 兜底匹配
            unresolved_titles = []
            seen_titles = set()
            for c in chunks:
                pid = c.get("paper_id")
                if pid and pid not in resolved:
                    title_str = (c.get("title") or "").strip()
                    if title_str and title_str not in seen_titles:
                        unresolved_titles.append(title_str)
                        seen_titles.add(title_str)
            if unresolved_titles:
                title_resolved = resolver.resolve_by_titles(unresolved_titles)
                for ttl, info in title_resolved.items():
                    resolved[info["paper_uid"]] = info

            ctx.evidence_papers = list(resolved.values())
        except Exception as e:  # noqa: BLE001
            self.logger.warning(f"EvidenceResolver failed: {e}")
            ctx.warnings.append(f"m2/evidence: {e}")
        ctx.fine_timings["m2.evidence_resolver_ms"] = _ms(t)

        # ----- Step 5.5: KB PDF 下载（通过 DOI，需配置启用）-----
        if self._module_cfg.get("kb_pdf_download", {}).get("enabled", False):
            t = time.perf_counter()
            try:
                self._download_kb_pdfs(ctx)
            except Exception as e:  # noqa: BLE001
                self.logger.warning(f"KB PDF download failed: {e}")
                ctx.warnings.append(f"m2/kb_pdf: {e}")
            ctx.fine_timings["m2.kb_pdf_download_ms"] = _ms(t)

        # ----- Step 6: 过程日志（需求 #2）-----
        plog = getattr(ctx, "_process_logger", None)
        if plog is not None:
            try:
                # 02_keypoints.log
                kp_lines = []
                if structured:
                    kp_lines.append(f"core_topic: {structured.get('core_topic', '')}")
                    for k in [
                        "search_keywords_cn", "search_keywords_en",
                        "structure_class", "substrate_material",
                        "dominant_mechanism", "operating_frequency_range",
                    ]:
                        v = structured.get(k)
                        if v:
                            kp_lines.append(f"{k}: {v}")
                kp_lines.append(f"keyword_rich_query: {query_text}")
                plog.log_text("keypoints", "\n".join(kp_lines))

                # 03_kg_paths.log
                kg_lines = [f"intent: {ctx.kg_intent}", f"summary: {ctx.kg_summary}"]
                for i, p in enumerate(ctx.kg_reasoning_paths[:10], 1):
                    kg_lines.append(f"--- path #{i} ---")
                    kg_lines.append(_safe_json_repr(p))
                plog.log_text("kg_paths", "\n".join(kg_lines))

                # 04_kb_chunks.json
                plog.log_json("kb_chunks", {
                    "structured_query": structured,
                    "query_text": query_text,
                    "top_k": chunks,
                    "evidence_papers": ctx.evidence_papers,
                    "retrieval_confidence": ctx.retrieval_confidence,
                })
            except Exception as e:  # noqa: BLE001
                self.logger.warning(f"process_log m2 failed: {e}")

        # 记录额外指标（供日志与诊断）
        ctx.module_metrics.setdefault(self.name, {})
        if result.get("stats"):
            ctx.module_metrics[self.name]["kb_mvp_stats"] = result["stats"]
        return ctx

    # ------------------------------------------------------------
    def _make_kg_llm_client(self):
        """KG 专用 LLMClient（中英翻译 + seed 扩展）。

        固定走 sohoyo 网关 + gpt-4o-mini（与 build 一致，支持 Anthropic 协议）。
        Embedding 服务在 35.220 网关上，两者必须分开，不共用 base_url。
        """
        try:
            from scientific_kgqa.llm_client import LLMClient as KGLLMClient
            base_url = os.environ.get("KG_LLM_BASE_URL", "https://api-zjlab.sohoyo.io")
            model = "gpt-4o-mini"
            api_key = os.environ.get("KG_LLM_API_KEY", "")
            if not api_key:
                self.logger.warning("KG_LLM_API_KEY not set, KG LLM client may fail")
            print(f"[KG_LLM] base_url={base_url} model={model}")
            return KGLLMClient(api_key=api_key, model=model, base_url=base_url)
        except Exception as e:  # noqa: BLE001
            self.logger.warning(f"KG LLMClient init failed: {e}")
            return None

    def _kg_search(self, query: str) -> Dict[str, Any]:
        """惰性初始化 KG adapter，并跑一次推理。"""
        if self.kg_adapter is None:
            try:
                self.kg_adapter = KGPathAdapter(
                    db_path=self.kg_db_path,
                    retriever_path=self.kg_retriever_path,
                    llm_client=self._make_kg_llm_client(),
                )
            except Exception as e:  # noqa: BLE001
                self.logger.warning(f"KGPathAdapter init failed: {e}")
                return {"error": f"kg_adapter_init: {e}"}
        try:
            return self.kg_adapter.search(query)
        except Exception as e:  # noqa: BLE001
            self.logger.warning(f"KG search failed: {e}")
            return {"error": f"kg_search: {e}"}

    def _ensure_resolver(self) -> EvidenceResolver:
        if self.evidence_resolver is None:
            # state.db 缺失时 EvidenceResolver 自动回退本仓库 knowledge_base.json
            # （默认 scientific_kgqa/data/knowledge_base.json，可用 evidence_kb_json 覆盖），
            # 源文/PDF 优先读步骤⑧物化的可移植内容库（默认 scientific_kgqa/data/content_store，
            # 可用 evidence_content_store 覆盖），跨机部署也能下源文，保证不降级。
            kb_json_cfg = self._module_cfg.get("evidence_kb_json")
            kb_json = self.config.resolve_path(kb_json_cfg) if kb_json_cfg else None
            store_cfg = self._module_cfg.get("evidence_content_store")
            store = self.config.resolve_path(store_cfg) if store_cfg else None
            self.evidence_resolver = EvidenceResolver(
                self.state_db_path, kb_json_path=kb_json, local_store_root=store,
            )
            self.logger.info(
                "EvidenceResolver 数据源: %s", self.evidence_resolver.source
            )
        return self.evidence_resolver

    # ------------------------------------------------------------
    # Step 5.5: KB PDF 下载
    # ------------------------------------------------------------
    def _download_kb_pdfs(self, ctx: RequestContext) -> None:
        """通过 autodownload.WorkerManager 下载 KB 论文 PDF。

        下载优先级：星河图书馆 → OA（Unpaywall/arXiv）→ Sci-Hub（可选）
        结果写入 process_log_dir/kb_pdfs/，并回写到 evidence_papers[].pdf_paths。
        """
        if not ctx.evidence_papers or not ctx.process_log_dir:
            return

        import os
        import sys

        # 动态导入 autodownload.WorkerManager（避免循环依赖）
        autodownload_dir = str(self.config.resolve_path("autodownload"))
        if autodownload_dir not in sys.path:
            sys.path.insert(0, autodownload_dir)
        try:
            from gui_downloader import WorkerManager  # noqa: PLC0415
        except ImportError as e:
            self.logger.warning(f"autodownload not available, KB PDF download skipped: {e}")
            return

        # 构建 WorkerManager 配置
        kb_pdf_dir = Path(ctx.process_log_dir) / "kb_pdfs"
        dl_cfg = self._module_cfg.get("kb_pdf_download", {})

        # 快速检查星河是否可达（3s TCP），不通则清空 key 让 WorkerManager 跳过星河直走 OA
        ros_key = os.environ.get("ROS_API_KEY", dl_cfg.get("ros_api_key", ""))
        if ros_key:
            import socket
            try:
                with socket.create_connection(("ros-api.ros.shlab.tech", 18443), timeout=3):
                    pass
            except OSError:
                self.logger.info("KB PDF: 星河不可达，跳过星河直走 OA 下载")
                ros_key = ""

        wm_config = {
            "output_dir": str(kb_pdf_dir),
            "ros_api_key":    ros_key,
            "xinghe_api_key": os.environ.get("XINGHE_API_KEY", dl_cfg.get("xinghe_api_key", "")),
            "use_scihub": dl_cfg.get("use_scihub", False),
        }
        wm = WorkerManager(wm_config, log_callback=self.logger.debug)

        # 逐篇下载（有 DOI、且本地无 PDF 的论文）
        candidates = [
            (i, ep) for i, ep in enumerate(ctx.evidence_papers)
            if (ep.get("doi") or "").strip() and not ep.get("pdf_paths")
        ]
        if not candidates:
            return

        from concurrent.futures import ThreadPoolExecutor, as_completed, TimeoutError as FuturesTimeout

        def _download_one(idx_ep):
            i, ep = idx_ep
            paper = {
                "doi":         (ep.get("doi") or "").strip(),
                "clean_title": ep.get("title", ""),
                "title":       ep.get("title", ""),
                "year":        ep.get("year", ""),
                "authors":     [],
            }
            # 星河优先（仅在 ros_key 存在时）
            if ros_key:
                xinghe_result = wm.download_via_xinghe(paper)
                if xinghe_result == "success":
                    filepath = kb_pdf_dir / wm._build_filename(paper)
                    if filepath.exists():
                        return i, str(filepath)
            # OA 检查 + 下载
            is_oa, pdf_urls, _ = wm.check_oa_status(paper)
            if is_oa and pdf_urls:
                paper["pdf_url"] = pdf_urls
                if wm.download_pdf(paper):
                    filepath = kb_pdf_dir / wm._build_filename(paper)
                    if filepath.exists():
                        return i, str(filepath)
            return i, None

        success = 0
        max_workers = min(8, len(candidates))
        # 整体限时 90s，避免卡住主流程
        total_timeout = dl_cfg.get("timeout_s", 90)
        with ThreadPoolExecutor(max_workers=max_workers) as pool:
            futures = {pool.submit(_download_one, c): c for c in candidates}
            try:
                for fut in as_completed(futures, timeout=total_timeout):
                    try:
                        i, path = fut.result()
                        if path:
                            ctx.evidence_papers[i]["pdf_paths"] = [path]
                            success += 1
                    except Exception as e:
                        self.logger.debug(f"KB PDF single download error: {e}")
            except FuturesTimeout:
                self.logger.warning(
                    "KB PDF download: 超过 %ds 总限时，已下载 %d 篇，剩余跳过",
                    total_timeout, success,
                )

        self.logger.info(
            "[%s] KB PDF download: %d/%d succeeded → %s",
            ctx.request_id, success, len(candidates), kb_pdf_dir,
        )

    # ------------------------------------------------------------
    # A2c: 论文标题精确匹配 boost
    # ------------------------------------------------------------
    def _get_papers_titles(self) -> List[Tuple[str, str]]:
        """惰性加载所有 (paper_id, title)。失败时返回空列表，不中断主流程。"""
        if self._papers_titles_cache is None:
            try:
                self._papers_titles_cache = self.adapter.get_papers_titles()
            except Exception as e:
                self.logger.warning(f"加载 papers titles 失败，title_boost 将无效: {e}")
                self._papers_titles_cache = []
        return self._papers_titles_cache

    def _find_boost_papers(self, query: str) -> List[str]:
        """
        找出标题与 query 标题前缀高度匹配的 paper_id 列表。

        匹配规则（H1: 支持跨语言）：
          - 字符级（lexical）：SequenceMatcher.ratio 或包含关系（视作 0.85）；
            阈值 self.title_boost_threshold（默认 0.7）。
          - 语义（semantic）：BGE-M3 embedding cosine similarity；
            阈值 self.title_boost_semantic_threshold（默认 0.55，跨语言通常更低）。
          - 模式 self.title_boost_mode：
            * "lexical"：仅字符级（旧行为，A2c）
            * "semantic"：仅语义
            * "hybrid"（默认）：任一分支命中即视为 boost；
              排序得分 = max(lexical_sim, semantic_sim_if_hit)。
          - 语义分支失败（embedding API 异常等）时自动降级到 lexical only。
        """
        title_prefix = self._extract_paper_title(query)
        if not title_prefix or len(title_prefix) < self.title_boost_min_prefix_len:
            return []

        papers = self._get_papers_titles()
        if not papers:
            return []

        mode = self.title_boost_mode
        use_lex = mode in ("lexical", "hybrid")
        use_sem = mode in ("semantic", "hybrid") and not self._semantic_disabled

        # ----- lexical 分支 -----
        lex_scores: Dict[str, float] = {}
        if use_lex:
            for pid, title in papers:
                if not title:
                    continue
                sim = SequenceMatcher(None, title_prefix, title).ratio()
                if title_prefix in title or title in title_prefix:
                    sim = max(sim, 0.85)
                if sim >= self.title_boost_threshold:
                    lex_scores[pid] = sim

        # ----- semantic 分支（含跨语言）-----
        sem_scores: Dict[str, float] = {}
        if use_sem:
            sem_pairs = self._semantic_title_similarities(title_prefix, papers)
            if sem_pairs is None:
                # 语义分支失败：本次仍可继续（lexical 分支已给出结果）
                pass
            else:
                for pid, sim in sem_pairs:
                    if sim >= self.title_boost_semantic_threshold:
                        sem_scores[pid] = sim

        # 纯 semantic 模式下 lexical 没结果也不做兜底（与配置语义保持一致）
        # 纯 lexical 模式下显式跳过 semantic
        # 命中：union；得分：取 max
        all_pids = set(lex_scores.keys()) | set(sem_scores.keys())
        if not all_pids:
            return []

        scored: List[Tuple[str, float]] = []
        for pid in all_pids:
            score = max(lex_scores.get(pid, 0.0), sem_scores.get(pid, 0.0))
            scored.append((pid, score))
        scored.sort(key=lambda x: -x[1])

        # H1.1: 按相似度封顶，防止 FSS 同域 KB 中 ~半数论文都被 boost 导致信号稀释
        if self.title_boost_max_candidates and len(scored) > self.title_boost_max_candidates:
            scored = scored[: self.title_boost_max_candidates]

        return [pid for pid, _ in scored]

    def _semantic_title_similarities(
        self,
        title_prefix: str,
        papers: List[Tuple[str, str]],
    ) -> Optional[List[Tuple[str, float]]]:
        """
        计算 title_prefix 与每篇论文标题的语义相似度（cosine）。

        实现：
          - 标题向量批量计算并缓存（与 papers 顺序一致），整个生命周期一次。
          - title_prefix 每次现算（query 维度）。
          - 任何异常 → 关闭语义分支并返回 None，调用方降级到 lexical。
        返回 List[(paper_id, sim)]，与 papers 同序。
        """
        title_embs = self._get_title_embeddings(papers)
        if title_embs is None or title_embs.size == 0:
            return None

        try:
            q_emb = self.adapter.embed_texts([title_prefix])
        except Exception as e:
            self.logger.warning(
                f"title_boost 语义分支：query embedding 失败，本次降级到 lexical: {e}"
            )
            return None

        if q_emb is None or q_emb.size == 0:
            return None

        # 已归一化 → inner product = cosine
        sims = (title_embs @ q_emb[0]).tolist()
        out: List[Tuple[str, float]] = []
        for (pid, _title), sim in zip(papers, sims):
            out.append((pid, float(sim)))
        return out

    def _get_title_embeddings(self, papers: List[Tuple[str, str]]):
        """惰性 + 一次性：把全部论文标题 embedding 起来。失败置 _semantic_disabled。"""
        if self._title_embeddings_cache is not None:
            return self._title_embeddings_cache
        if self._semantic_disabled:
            return None

        # 空标题用空字符串占位，embedding 客户端会回零向量；后续用零向量做 inner product 也是 0
        titles = [t or "" for _pid, t in papers]
        try:
            embs = self.adapter.embed_texts(titles)
        except Exception as e:
            self.logger.warning(
                f"title_boost 语义分支：批量 embedding 失败，整轮关闭语义匹配: {e}"
            )
            self._semantic_disabled = True
            return None

        self._title_embeddings_cache = embs
        return embs

    def _apply_title_boost(
        self,
        chunks: List[Dict[str, Any]],
        boost_papers: List[str],
        *,
        query_text: str = "",
        title_prefix: str = "",
    ) -> List[Dict[str, Any]]:
        """
        对 boost_papers 中的 chunks 在 fused_score 上加 bonus，重新排序。

        H2 (2026-05-10) 三步增强：
          (a) inject_top_n：boost_papers 中没出现在当前 chunks 的论文，按 paper_id 反查
              SQLite 拉它们的 chunks，按 dense(content, query_text) 评分，每篇取 top-N
              注入候选池。解决 P001 chunks 根本没进 top-K 时 boost 无效的问题。
          (b) chunk_title_verify：对 boost 候选 chunk 计算 cosine(content, title_prefix)，
              用相似度调制 bonus（floor 兜底）。让真正讲该论文核心主题的 chunk 拿到更高
              bonus，避免对 paper 内部 chunks 无差别加分。
          (c) paper_level_rerank：boost 完成后按 paper-level 聚合分（max chunk score）排序，
              防止某篇 dense 高分论文的多个 chunks 占满 top-K，把目标论文的唯一 chunk 挤掉。
        """
        boost_set = set(boost_papers)
        bonus_base = self.title_boost_bonus

        # ----- (a) 注入：missing boost_paper 直接拉 chunks -----
        if self.title_boost_inject_top_n > 0 and query_text:
            existing_pids = {c.get("paper_id") for c in chunks}
            missing = [
                pid for pid in boost_papers
                if pid and pid not in existing_pids
            ]
            if missing:
                injected = self._inject_paper_chunks(missing, query_text)
                if injected:
                    chunks = list(chunks) + injected

        # ----- (b) chunk × title 二次语义验证（对 boost 候选）-----
        chunk_title_sims: Dict[str, float] = {}
        if self.title_boost_chunk_title_verify and title_prefix:
            verify_chunks = [c for c in chunks if c.get("paper_id") in boost_set]
            if verify_chunks:
                chunk_title_sims = self._compute_chunk_title_sims(
                    verify_chunks, title_prefix
                )

        # ----- H2d: 分级 bonus —— rank-1 paper 拿最高乘子，rank 4+ 拿最低乘子 -----
        # boost_papers 已按相似度降序排列，index=0 为相似度最高的论文（rank-1）。
        # 加入 title_cn 后 P001/P002 自身 query 中 lexical sim≈1.0，升至 rank-1；
        # rank-1 bonus = score_bonus × rank1_factor，确保 injected chunk 超越通用 FSS 论文。
        pid_bonus: Dict[str, float] = {}
        for idx, pid in enumerate(boost_papers):
            if idx == 0:
                factor = self.title_boost_rank1_factor
            elif idx < 3:
                factor = self.title_boost_rank23_factor
            else:
                factor = self.title_boost_rank4plus_factor
            pid_bonus[pid] = self.title_boost_bonus * factor

        # ----- 应用 bonus -----
        for c in chunks:
            pid = c.get("paper_id")
            if pid not in boost_set:
                continue
            base = pid_bonus.get(pid, self.title_boost_bonus)
            if chunk_title_sims:
                sim = chunk_title_sims.get(c.get("chunk_id"), 0.0)
                multiplier = max(self.title_boost_chunk_title_floor, sim)
                bonus = base * multiplier
                c["title_boost_chunk_title_sim"] = round(float(sim), 4)
            else:
                bonus = base
            c["fused_score"] = (c.get("fused_score", 0) or 0) + bonus
            c["title_boost"] = round(float(bonus), 4)

        # ----- (c) paper-level 聚合排序 -----
        if self.title_boost_paper_level_rerank:
            paper_score: Dict[str, float] = {}
            for c in chunks:
                pid = c.get("paper_id")
                score = float(c.get("fused_score", 0) or 0)
                if score > paper_score.get(pid, float("-inf")):
                    paper_score[pid] = score
            chunks.sort(
                key=lambda c: (
                    -paper_score.get(c.get("paper_id"), 0.0),
                    -float(c.get("fused_score", 0) or 0),
                )
            )
        else:
            chunks.sort(key=lambda c: -float(c.get("fused_score", 0) or 0))

        # 截到 top_k（注入会临时撑大候选池）
        return chunks[: self.top_k]

    # ------------------------------------------------------------
    # H2 helpers
    # ------------------------------------------------------------
    def _inject_paper_chunks(
        self, paper_ids: List[str], query_text: str
    ) -> List[Dict[str, Any]]:
        """
        反查给定 paper_ids 的全部 chunks，按 dense(content, query_text) 取每篇 top-N。
        返回的 chunk 已带 fused_score（= dense_score）和 title_injected 标记。
        失败/embedding 异常 → 返回空列表，不阻塞主流程。
        """
        try:
            candidates = self.adapter.fetch_chunks_for_papers(paper_ids)
        except Exception as e:
            self.logger.warning(f"title_boost: fetch_chunks_for_papers 失败: {e}")
            return []
        if not candidates:
            return []

        try:
            contents = [c["content"] for c in candidates]
            indices = [c.get("embedding_idx") for c in candidates]
            # Fast path: look up pre-computed embeddings from npy (zero inference cost)
            chunk_embs = self.adapter.get_chunk_embeddings_by_idx(indices)
            if chunk_embs is None:
                chunk_embs = self.adapter.embed_texts(contents)
            q_embs = self.adapter.embed_texts([query_text])
        except Exception as e:
            self.logger.warning(f"title_boost: 注入 embedding 失败: {e}")
            return []
        if chunk_embs is None or chunk_embs.size == 0:
            return []
        if q_embs is None or q_embs.size == 0:
            return []

        sims = (chunk_embs @ q_embs[0]).tolist()
        by_paper: Dict[str, List[Dict[str, Any]]] = {}
        for c, sim in zip(candidates, sims):
            score = float(sim)
            c["dense_score"] = score
            c["fused_score"] = score
            c["title_injected"] = True
            by_paper.setdefault(c["paper_id"], []).append(c)

        n = self.title_boost_inject_top_n
        out: List[Dict[str, Any]] = []
        for pid, plist in by_paper.items():
            plist.sort(key=lambda c: -c["dense_score"])
            out.extend(plist[:n])
        return out

    def _compute_chunk_title_sims(
        self, chunks: List[Dict[str, Any]], title_prefix: str
    ) -> Dict[str, float]:
        """cosine(content_embedding, title_prefix_embedding)，chunks 从 npy 查表。"""
        if not chunks or not title_prefix:
            return {}
        chunk_ids = [c.get("chunk_id") for c in chunks]
        try:
            # Fast path: look up chunk embeddings from npy, only embed the 1-token title
            indices = [c.get("embedding_idx") for c in chunks]
            chunk_embs = self.adapter.get_chunk_embeddings_by_idx(indices)
            if chunk_embs is None:
                contents = [c.get("content", "") or "" for c in chunks]
                chunk_embs = self.adapter.embed_texts(contents + [title_prefix])
                if chunk_embs is None or chunk_embs.size == 0 or len(chunk_embs) < len(chunks) + 1:
                    return {}
                title_emb = chunk_embs[-1]
                chunk_embs = chunk_embs[:-1]
            else:
                title_emb_arr = self.adapter.embed_texts([title_prefix])
                if title_emb_arr is None or title_emb_arr.size == 0:
                    return {}
                title_emb = title_emb_arr[0]
        except Exception as e:
            self.logger.warning(f"title_boost: chunk×title verify embedding 失败: {e}")
            return {}
        sims = (chunk_embs @ title_emb).tolist()
        return {cid: float(s) for cid, s in zip(chunk_ids, sims) if cid}

    # ------------------------------------------------------------
    @staticmethod
    def _extract_paper_title(query: str) -> str:
        """
        从 golden_qa 格式的 query 中提取论文标题（第一个逗号前的部分）。
        例：「一种宽通带低插损的吸透一体FSS，无耗层采用什么单元结构？」
            → 「一种宽通带低插损的吸透一体FSS」

        只用逗号（中/英文）作为分隔符，问号/句号不算，避免把整个问题误判为标题。
        提取的标题直接加入 BM25 查询，使 sparse 分支能命中该论文的独特 chunk
        而不会被通用 FSS 关键词分散到其他论文。
        """
        for sep in ["，", ","]:
            idx = query.find(sep)
            if idx > 5:  # 标题至少 6 个字符
                candidate = query[:idx].strip()
                if len(candidate) >= 6:
                    return candidate
        return ""

    @staticmethod
    def _build_keyword_rich_query(
        original_query: str,
        structured: Dict[str, Any],
        max_chars: int = 200,
    ) -> str:
        """
        把 structured 里的核心实体与关键词拼成紧凑 query，改善 BM25 命中。

        实测（2026-05-07）：P001-Q1 原始 query 被 jieba 切成 15+ 碎 token 后 BM25=0；
        换成 "吸透一体 FSS 频率选择表面 低插损" 这类关键词密集 string，BM25 能命中。

        策略（A2 选项A，2026-05-09）：
          1. 提取原始 query 的论文标题部分（逗号前），前置加入；
             这样 BM25 能直接命中该论文独特 chunk（如 P001 的 "耶路撒冷缝隙单元"），
             而不会被通用 FSS 关键词稀释到 P029/P030 等泛化 FSS 论文。
          2. 追加 structured 关键词（增强密度，避免 sparse=0）。
        """
        parts: List[str] = []

        # A2 选项A：优先加入论文标题（论文级独特信号，改善 BM25 per-paper 命中）
        title_prefix = InternalRetriever._extract_paper_title(original_query)
        if title_prefix:
            parts.append(title_prefix)

        core_topic = structured.get("core_topic")
        if core_topic:
            parts.append(core_topic.strip())

        # 提取数组类关键词字段
        for field in [
            "search_keywords_cn",
            "search_keywords_en",
            "structure_class",
            "substrate_material",
            "dominant_mechanism",
        ]:
            val = structured.get(field)
            if isinstance(val, list):
                parts.extend(str(x).strip() for x in val if x)
            elif isinstance(val, str) and val.strip():
                parts.append(val.strip())

        # 频段等字符串字段
        for field in ["operating_frequency_range", "permittivity"]:
            val = structured.get(field)
            if isinstance(val, str) and val.strip():
                parts.append(val.strip())

        # 去重保持顺序
        seen = set()
        uniq = []
        for p in parts:
            key = p.lower()
            if key and key not in seen:
                seen.add(key)
                uniq.append(p)

        if not uniq:
            # structurizer 没返回任何字段，退回原始
            return original_query

        # 拼接（空格分隔，让 jieba / bm25 能分词）
        text = " ".join(uniq)

        # 避免 query 过长（BM25 对长 query 不敏感但增加计算成本）
        if len(text) > max_chars:
            text = text[:max_chars]

        return text
