#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
kg_path_adapter.py —— scientific_kgqa.QAEngine 适配器（带论文级溯源）

核心能力：
1. 调用 scientific_kgqa.QAEngine 拿 reasoning_paths + evidence
2. **paper-level provenance**：对每条 reasoning_path 上的节点反查
   `node_chunk_posting` 表，聚合得到「这条路径由哪些论文支撑」，
   带回 paper_id（= 主项目 state.db.papers.paper_uid sha1），
   后续 EvidenceResolver 可顺势溯源到 source_ref → md/pdf。
3. **per-stage timing**：把 翻译 / seed 映射 / PPR / beam / 整体 答应耗时都拆开返回，
   方便前端分阶段展示瓶颈。
"""

import sys
import time
import sqlite3
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# 主项目根
_RI_ROOT = Path(__file__).resolve().parent.parent.parent
_PROJECT_ROOT = _RI_ROOT.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))
_KGQA_SRC = _PROJECT_ROOT / "scientific_kgqa" / "src"
if _KGQA_SRC.exists() and str(_KGQA_SRC) not in sys.path:
    sys.path.insert(0, str(_KGQA_SRC))

logger = logging.getLogger(__name__)


class KGPathAdapter:
    """
    封装 scientific_kgqa.QAEngine。

    使用：
        adapter = KGPathAdapter(db_path, retriever_path)
        result = adapter.search(query)
        # result["reasoning_paths"] : List[{text, support_papers: [paper_id, ...]}]
        # result["evidence"] / result["retrieval_plan"]
        # result["timing"] : {translate_ms, seed_ms, ppr_ms, beam_ms, total_ms}
    """

    # 路径节点字符串解析：'Prototype:high transmission' → ('Prototype', 'high transmission')
    @staticmethod
    def _parse_path_text(text: str) -> List[Tuple[str, str]]:
        out: List[Tuple[str, str]] = []
        for tok in text.split(" -> "):
            tok = tok.strip()
            if not tok or ":" not in tok:
                continue
            ntype, _, name = tok.partition(":")
            out.append((ntype.strip(), name.strip()))
        return out

    def __init__(
        self,
        db_path: Path,
        retriever_path: Path,
        llm_client: Any = None,
    ):
        self.db_path = Path(db_path)
        self.retriever_path = Path(retriever_path)
        self.llm_client = llm_client
        self._engine = None
        # 直接打开一个只读连接做溯源查询（避免每次 search 重新连）
        self._con: Optional[sqlite3.Connection] = None

    # ------------------------------------------------------------
    def _ensure_engine(self):
        if self._engine is not None:
            return

        if not self.db_path.exists():
            raise FileNotFoundError(
                f"KGPathAdapter: db not found {self.db_path}"
            )
        if not self.retriever_path.exists():
            raise FileNotFoundError(
                f"KGPathAdapter: retriever not found {self.retriever_path}"
            )

        from scientific_kgqa.storage import SQLiteStore
        from scientific_kgqa.retriever import Retriever
        from scientific_kgqa.qa_engine import QAEngine

        store = SQLiteStore(self.db_path)
        # 懒加载：KGPathAdapter 在 deep 管道里只需要 KG 节点/路径，
        # 实际 chunk 检索由 kb_mvp HybridSearcher 完成，
        # 1.2 GB pkl 只有真正调用 QAEngine.retriever.search() 时才反序列化。
        retriever = Retriever.lazy_load(self.retriever_path)
        self._engine = QAEngine(store, retriever, llm_client=self.llm_client)
        # 绑一个共享的 timing dict；每次 search 前清空
        self._stage_timings: Dict[str, float] = {}
        _wrap_engine_for_timing(self._engine, self._stage_timings)

        try:
            self._con = sqlite3.connect(str(self.db_path), check_same_thread=False)
            self._con.row_factory = sqlite3.Row
        except Exception as e:  # noqa: BLE001
            logger.warning("KGPathAdapter: open provenance conn failed: %s", e)
            self._con = None

        logger.info("KGPathAdapter: engine initialized (db=%s)", self.db_path)

    # ------------------------------------------------------------
    def search(
        self,
        query: str,
        task_type: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        执行 KG 推理，返回结构化结果（带溯源 + 耗时）。

        Returns:
            {
              "reasoning_paths": [
                  {
                    "text": "Prototype:angle -> Prototype:stage 1 -> ...",
                    "nodes": [{"node_type":"Prototype","canonical_name":"angle","node_id":...}, ...],
                    "support_papers": [
                        {"paper_id":"...", "title":"...", "support_score":..., "year":...}
                    ]
                  }
              ],
              "evidence": [...],            # 同 QAEngine
              "retrieval_plan": {...},
              "evolution_context": [...],
              "summary": "...",
              "intent": "...",
              "confidence": 0.0-1.0,
              "timing": {                    # 每阶段耗时（毫秒）
                  "engine_total_ms": 3500.0,
                  "provenance_ms":   45.2
              }
            }
        """
        timing: Dict[str, float] = {}
        out_err: Dict[str, Any] = {
            "reasoning_paths": [],
            "evidence": [],
            "retrieval_plan": {},
            "evolution_context": [],
            "summary": "",
            "intent": None,
            "confidence": 0.0,
            "timing": timing,
        }

        try:
            self._ensure_engine()
        except FileNotFoundError as e:
            logger.warning("KGPathAdapter unavailable: %s", e)
            out_err["error"] = str(e)
            return out_err
        except Exception as e:  # noqa: BLE001
            logger.exception("KGPathAdapter init failed: %s", e)
            out_err["error"] = f"init: {e}"
            return out_err

        # ------- 调 QAEngine -------
        # 清空本轮分阶段计时
        self._stage_timings.clear()
        t0 = time.perf_counter()
        try:
            result = self._engine.answer(query, task_type_override=task_type)
        except Exception as e:  # noqa: BLE001
            logger.exception("KGPathAdapter.search failed: %s", e)
            out_err["error"] = f"search: {e}"
            timing["engine_total_ms"] = round((time.perf_counter() - t0) * 1000, 2)
            return out_err
        timing["engine_total_ms"] = round((time.perf_counter() - t0) * 1000, 2)
        # 把 monkeypatch 收集到的 stage 计时合并进 timing
        for k, v in self._stage_timings.items():
            timing[k] = v

        # ------- 溯源：在 reasoning_paths 上挂 support_papers -------
        t1 = time.perf_counter()
        try:
            enriched = self._enrich_paths_with_papers(
                result.get("reasoning_paths", []) or []
            )
            result["reasoning_paths"] = enriched
        except Exception as e:  # noqa: BLE001
            logger.warning("KGPathAdapter provenance failed: %s", e)
            # 退化：保留原字符串路径
            result["reasoning_paths"] = [
                {"text": p, "nodes": [], "support_papers": []}
                for p in (result.get("reasoning_paths", []) or [])
            ]
        timing["provenance_ms"] = round((time.perf_counter() - t1) * 1000, 2)

        result["timing"] = timing
        return result

    # ------------------------------------------------------------
    def _enrich_paths_with_papers(
        self, path_texts: List[str], top_k_papers: int = 5
    ) -> List[Dict[str, Any]]:
        """
        对每条 path 字符串：
          1. 拆出 (node_type, canonical_name) 列表
          2. 在 graph_node 表反查 node_id
          3. 在 node_chunk_posting 聚合 support_score by paper_id
          4. 取 top_k_papers 配 paper.paper_title / year
        """
        if not path_texts or self._con is None:
            return [{"text": p, "nodes": [], "support_papers": []}
                    for p in path_texts]

        # 一次性收集所有要查的 (type, name) 去重
        all_pairs: List[Tuple[str, str]] = []
        per_path_pairs: List[List[Tuple[str, str]]] = []
        for p in path_texts:
            pairs = self._parse_path_text(p)
            per_path_pairs.append(pairs)
            all_pairs.extend(pairs)
        # 去重
        unique_pairs = list(dict.fromkeys(all_pairs))

        # ---- 批量查 node_id ----
        pair_to_node: Dict[Tuple[str, str], Dict[str, Any]] = {}
        if unique_pairs:
            placeholders = ",".join(["(?, ?)"] * len(unique_pairs))
            params: List[Any] = []
            for nt, nn in unique_pairs:
                params.extend([nt, nn])
            try:
                rows = self._con.execute(
                    f"SELECT node_id, node_type, canonical_name "
                    f"FROM graph_node "
                    f"WHERE (node_type, canonical_name) IN ({placeholders})",
                    params,
                ).fetchall()
            except Exception as e:  # noqa: BLE001
                logger.warning("graph_node batch lookup failed: %s", e)
                rows = []
            for r in rows:
                pair_to_node[(r["node_type"], r["canonical_name"])] = {
                    "node_id": r["node_id"],
                    "node_type": r["node_type"],
                    "canonical_name": r["canonical_name"],
                }

        # ---- 把每条 path 还原 nodes 列表 ----
        out: List[Dict[str, Any]] = []
        for ptext, pairs in zip(path_texts, per_path_pairs):
            nodes_with_id = []
            node_ids_for_path: List[int] = []
            for pair in pairs:
                node_info = pair_to_node.get(pair)
                if node_info:
                    nodes_with_id.append(node_info)
                    node_ids_for_path.append(node_info["node_id"])
                else:
                    nodes_with_id.append({
                        "node_type": pair[0],
                        "canonical_name": pair[1],
                        "node_id": None,
                    })

            # ---- 聚合该 path 的支撑论文 ----
            support_papers = self._aggregate_papers_for_nodes(
                node_ids_for_path, top_k_papers
            )
            out.append({
                "text": ptext,
                "nodes": nodes_with_id,
                "support_papers": support_papers,
            })
        return out

    # ------------------------------------------------------------
    def _aggregate_papers_for_nodes(
        self, node_ids: List[int], top_k: int
    ) -> List[Dict[str, Any]]:
        """对一组 node_id 在 node_chunk_posting 聚合 support_score by paper_id。"""
        if not node_ids or self._con is None:
            return []

        placeholders = ",".join("?" * len(node_ids))
        try:
            rows = self._con.execute(
                f"SELECT paper_id, SUM(support_score) AS s, COUNT(DISTINCT node_id) AS hit_nodes "
                f"FROM node_chunk_posting "
                f"WHERE node_id IN ({placeholders}) "
                f"GROUP BY paper_id "
                f"ORDER BY s DESC "
                f"LIMIT ?",
                list(node_ids) + [top_k],
            ).fetchall()
        except Exception as e:  # noqa: BLE001
            logger.warning("node_chunk_posting aggregation failed: %s", e)
            return []

        if not rows:
            return []

        # 拉论文元信息
        pids = [r["paper_id"] for r in rows]
        meta_rows = self._con.execute(
            f"SELECT paper_id, paper_title, year, doi "
            f"FROM paper WHERE paper_id IN ({','.join('?' * len(pids))})",
            pids,
        ).fetchall()
        meta = {r["paper_id"]: r for r in meta_rows}

        out: List[Dict[str, Any]] = []
        for r in rows:
            m = meta.get(r["paper_id"])
            out.append({
                "paper_id": r["paper_id"],     # = 主项目 paper_uid
                "paper_uid": r["paper_id"],    # 显式别名，方便下游
                "title": m["paper_title"] if m else "",
                "year": m["year"] if m else None,
                "doi": m["doi"] if m else None,
                "support_score": round(float(r["s"]), 4),
                "hit_nodes": int(r["hit_nodes"]),
            })
        return out


# ============================================================
# QAEngine 计时包装（monkeypatch，方便分阶段诊断）
# ============================================================

def _wrap_engine_for_timing(engine: Any, timings: Dict[str, float]) -> None:
    """
    Monkeypatch scientific_kgqa.QAEngine 的关键方法，在每个阶段记录耗时。
    阶段:
      - translate_ms        :  _translate_query (中→英)
      - parse_query_ms      :  parse_query (识别意图、关键词)
      - map_seeds_ms        :  map_seeds (定位 KG 入口节点)
      - seed_expand_ms      :  _expand_seeds_with_llm
      - ppr_ms              :  personalized_ppr 调用
      - beam_ms             :  beam_search 调用
      - retrieve_ms         :  retriever.search 调用（chunk 检索 + 重排）
    """
    import functools, time as _time

    def _wrap(method_name: str, key: str):
        if not hasattr(engine, method_name):
            return
        orig = getattr(engine, method_name)

        @functools.wraps(orig)
        def wrapper(*a, **kw):
            t = _time.perf_counter()
            try:
                return orig(*a, **kw)
            finally:
                # 累加（同一个方法被多次调用时累加耗时）
                ms = (_time.perf_counter() - t) * 1000
                timings[key] = round(timings.get(key, 0.0) + ms, 2)
        setattr(engine, method_name, wrapper)

    _wrap("_translate_query", "translate_ms")
    _wrap("parse_query", "parse_query_ms")
    _wrap("map_seeds", "map_seeds_ms")
    _wrap("_expand_seeds_with_llm", "seed_expand_ms")

    # 包 retriever.search（属性方法）
    if hasattr(engine, "retriever") and hasattr(engine.retriever, "search"):
        orig_r = engine.retriever.search

        @functools.wraps(orig_r)
        def wrapped_retr(*a, **kw):
            t = _time.perf_counter()
            try:
                return orig_r(*a, **kw)
            finally:
                ms = (_time.perf_counter() - t) * 1000
                timings["retrieve_ms"] = round(
                    timings.get("retrieve_ms", 0.0) + ms, 2
                )
        engine.retriever.search = wrapped_retr

    # 包模块级函数 personalized_ppr / beam_search（在 walk 模块中）
    try:
        import scientific_kgqa.walk as _walk
        for fn_name, key in [("personalized_ppr", "ppr_ms"),
                             ("beam_search", "beam_ms")]:
            if not hasattr(_walk, fn_name):
                continue
            orig_fn = getattr(_walk, fn_name)
            if getattr(orig_fn, "__wrapped_by_kg_adapter__", False):
                continue

            @functools.wraps(orig_fn)
            def fn_wrapper(*a, _orig=orig_fn, _key=key, **kw):
                t = _time.perf_counter()
                try:
                    return _orig(*a, **kw)
                finally:
                    ms = (_time.perf_counter() - t) * 1000
                    timings[_key] = round(timings.get(_key, 0.0) + ms, 2)
            fn_wrapper.__wrapped_by_kg_adapter__ = True  # 防止重复包
            setattr(_walk, fn_name, fn_wrapper)
            # qa_engine.py 是 `from .walk import beam_search, personalized_ppr` 的，
            # 模块级 import 已经把函数对象绑定到 qa_engine 模块的 namespace 里
            # 所以也要替换 qa_engine 的引用
            try:
                import scientific_kgqa.qa_engine as _qe
                if hasattr(_qe, fn_name):
                    setattr(_qe, fn_name, fn_wrapper)
            except ImportError:
                pass
    except ImportError:
        pass
