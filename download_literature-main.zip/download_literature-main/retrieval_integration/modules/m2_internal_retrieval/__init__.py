"""模块2：内部混合检索（复用 kb_mvp）。"""
from .retriever import InternalRetriever
from .kb_mvp_adapter import KBMVPAdapter

__all__ = ["InternalRetriever", "KBMVPAdapter"]
