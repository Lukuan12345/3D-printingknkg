#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""evidence_resolver.py -- chunk -> source file lookup

两种数据源（按优先级）：
  A. 外部「抽取主项目」的 state.db（可选，跨机器溯源最精确）
       1. content_sha1 -> content_store/<xx>/<yy>/<sha1>.md
       2. source_ref fallback（绝对路径，跨机可能失效）
     + 同级 metadata/metadata.jsonl 补 doi/year
  B. 本仓库步骤⑦产出的 knowledge_base.json（默认兜底，无需外部库）
       每篇带 paper_id / paper_uid / title / doi / year / source.source_ref。
       源文定位优先级：
         1. 可移植内容库 scientific_kgqa/data/content_store/<paper_id>/full.md + *.pdf
            （步骤⑧ build_kb_kg.py 物化，随 artifacts 走，跨机/原目录被删也有效）
         2. source.source_ref 原始解析目录（绝对路径，仅同机有效，最后兜底）

设计原则：state.db 缺失时**不降级功能**——回退本地 knowledge_base.json + 可移植内容库，
evidence_papers 照常产出（md 全文路径 + doi/year + references 下载包），且**跨机部署、
原始解析目录被移走也照常可下源文 / PDF**。两源都没有时才返回空。
"""

import json
import logging
import sqlite3
from pathlib import Path
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)

# 本仓库步骤⑧把 step⑦ 的 knowledge_base.json 落到这里（kb_mvp/config.py 同款默认）
_PROJECT_ROOT = Path(__file__).resolve().parents[3]
_DEFAULT_KB_JSON = _PROJECT_ROOT / "scientific_kgqa" / "data" / "knowledge_base.json"
# 步骤⑧物化的可移植内容库（build_kb_kg.py 的 CONTENT_STORE_DEFAULT 同路径）
_DEFAULT_LOCAL_STORE = _PROJECT_ROOT / "scientific_kgqa" / "data" / "content_store"


class EvidenceResolver:

    def __init__(self, state_db_path: Optional[Path] = None,
                 content_store_root: Optional[Path] = None,
                 kb_json_path: Optional[Path] = None,
                 local_store_root: Optional[Path] = None):
        self.state_db_path = Path(state_db_path) if state_db_path else None
        self._conn: Optional[sqlite3.Connection] = None
        self._available = False
        self._has_sha1 = False
        # 本地 KB 兜底索引：paper_id/paper_uid -> {paper_id, paper_uid, title, doi, year, source_ref}
        self._kb_index: Dict[str, Dict[str, str]] = {}
        self._kb_title_index: Dict[str, str] = {}  # lower(title[:50]) -> paper_id
        # 步骤⑧物化的可移植内容库根目录（local_kb 模式下优先从这里取源文/PDF）
        self._local_store = Path(local_store_root) if local_store_root else _DEFAULT_LOCAL_STORE

        if content_store_root:
            self._content_store = Path(content_store_root)
        elif self.state_db_path:
            self._content_store = self.state_db_path.parent / "content_store"
        else:
            self._content_store = None

        if self.state_db_path and self.state_db_path.exists():
            try:
                conn = sqlite3.connect(str(self.state_db_path), check_same_thread=False)
                conn.row_factory = sqlite3.Row
                tables = {r[0] for r in conn.execute(
                    "SELECT name FROM sqlite_master WHERE type='table'"
                ).fetchall()}
                if "papers" not in tables:
                    conn.close()
                else:
                    self._conn = conn
                    self._available = True
                    col_names = {r["name"] for r in conn.execute(
                        "PRAGMA table_info(papers)"
                    ).fetchall()}
                    self._has_sha1 = "content_sha1" in col_names
                    logger.info("EvidenceResolver ready (state.db): sha1=%s store=%s",
                                self._has_sha1,
                                self._content_store.exists() if self._content_store else False)
            except Exception as e:
                logger.warning("EvidenceResolver open db failed: %s", e)

        # 加载 state.db 同级 metadata.jsonl 建立 paper_uid → doi/year 映射
        self._doi_map: Dict[str, Dict[str, str]] = {}
        if self.state_db_path:
            meta_path = self.state_db_path.parent / "metadata" / "metadata.jsonl"
            self._doi_map = self._load_doi_map(meta_path)

        # state.db 不可用 → 回退本地 knowledge_base.json（默认行为，保证不降级）
        if not self._available:
            kb_path = Path(kb_json_path) if kb_json_path else _DEFAULT_KB_JSON
            self._load_kb_fallback(kb_path)

    # ------------------------------------------------------------------
    @property
    def source(self) -> str:
        """当前生效的数据源：'state_db' / 'local_kb' / 'none'。"""
        if self._available:
            return "state_db"
        if self._kb_index:
            return "local_kb"
        return "none"

    # ------------------------------------------------------------------
    def resolve(self, paper_uids: List[str]) -> Dict[str, Dict]:
        if not paper_uids:
            return {}
        if self._available:
            return self._resolve_state_db(paper_uids)
        return self._resolve_local_kb(paper_uids)

    # ----- state.db 路径 ----------------------------------------------
    def _resolve_state_db(self, paper_uids: List[str]) -> Dict[str, Dict]:
        unique = list(dict.fromkeys(paper_uids))
        placeholders = ",".join("?" * len(unique))
        try:
            rows = self._conn.execute(
                f"SELECT paper_uid, title, source_ref FROM papers "
                f"WHERE paper_uid IN ({placeholders})",
                unique,
            ).fetchall()
        except Exception as e:
            logger.warning("EvidenceResolver.resolve failed: %s", e)
            return {}

        # 并发预取这批论文的远程文件
        self._prefetch_remote_batch([r["paper_uid"] for r in rows])

        out: Dict[str, Dict] = {}
        for r in rows:
            uid = r["paper_uid"]
            title = r["title"] or ""
            source_ref = r["source_ref"] or ""
            sha1 = self._fetch_sha1(uid)
            md_path, pdf_paths = self._find_files(sha1, source_ref)
            meta = self._doi_map.get(uid, {})
            out[uid] = {
                "paper_uid": uid,
                "title": title,
                "source_ref": source_ref,
                "md_path": md_path,
                "pdf_paths": pdf_paths,
                "doi": meta.get("doi", ""),
                "year": meta.get("year", ""),
            }
        return out

    def _prefetch_remote_batch(self, paper_ids: List[str]) -> None:
        """批量并发预取：对 _local_store 中仅有 _manifest.json 但缺实体文件的论文，
        一次性并发从远程 Ceph 桶拉回缓存，消除后续逐篇串行 fetch_file 开销。

        逻辑上等价于先对所有论文调 _resolve_from_store 的远程分支，但并发执行。
        典型提升：5 篇串行 rclone ~6300ms → 5 篇并发 boto3 ~75ms。
        """
        if not self._local_store or not self._local_store.exists():
            return
        try:
            import json as _json
            if str(_PROJECT_ROOT) not in __import__("sys").path:
                __import__("sys").path.insert(0, str(_PROJECT_ROOT))
            from content_store_remote import fetch_files_parallel
        except Exception:
            return

        tasks = []
        for pid in paper_ids:
            pdir = self._local_store / pid
            manifest = pdir / "_manifest.json"
            if not manifest.exists():
                continue
            md = pdir / "full.md"
            # 已有实体文件的跳过
            try:
                info = _json.loads(manifest.read_text(encoding="utf-8"))
            except Exception:
                continue
            if info.get("md") and not md.exists():
                tasks.append((pid, "full.md", md))
            for name in (info.get("pdfs") or []):
                dest = pdir / name
                if not dest.exists():
                    tasks.append((pid, name, dest))

        if tasks:
            fetch_files_parallel(tasks)

    # ----- 本地 knowledge_base.json 路径 ------------------------------
    def _resolve_local_kb(self, paper_uids: List[str]) -> Dict[str, Dict]:
        # 并发预取所有需要远程拉取的论文文件，消除串行逐篇 fetch 开销
        unique_ids = list(dict.fromkeys(paper_uids))
        paper_ids_for_prefetch = [
            (self._kb_index.get(uid) or {}).get("paper_id") or uid
            for uid in unique_ids if uid in self._kb_index
        ]
        self._prefetch_remote_batch(paper_ids_for_prefetch)

        out: Dict[str, Dict] = {}
        for uid in unique_ids:
            rec = self._kb_index.get(uid)
            if not rec:
                continue
            # 用记录里的规范 paper_uid（= 顶层键 P0001）做 key：同一篇被 P0001 与 sha1
            # 两种 id 分别查到时自动收敛成一条，不重复。
            canon = rec.get("paper_uid") or uid
            if canon in out:
                continue
            md_path, pdf_paths = self._find_local_kb_files(rec)
            out[canon] = {
                "paper_uid": canon,
                "title": rec.get("title", ""),
                "source_ref": rec.get("source_ref", ""),
                "md_path": md_path,
                "pdf_paths": pdf_paths,
                "doi": rec.get("doi", ""),
                "year": rec.get("year", ""),
            }
        return out

    # ------------------------------------------------------------------
    def resolve_by_titles(self, titles: List[str]) -> Dict[str, Dict]:
        if not titles:
            return {}
        if self._available:
            return self._resolve_by_titles_state_db(titles)
        return self._resolve_by_titles_local_kb(titles)

    def _resolve_by_titles_state_db(self, titles: List[str]) -> Dict[str, Dict]:
        out: Dict[str, Dict] = {}
        for title in titles:
            if not title or not title.strip():
                continue
            try:
                row = self._conn.execute(
                    "SELECT paper_uid, title, source_ref FROM papers "
                    "WHERE title=? LIMIT 1",
                    (title,),
                ).fetchone()
                if row is None:
                    needle = title.strip().lower()[:50]
                    row = self._conn.execute(
                        "SELECT paper_uid, title, source_ref FROM papers "
                        "WHERE LOWER(SUBSTR(title,1,50))=? LIMIT 1",
                        (needle,),
                    ).fetchone()
                if row is not None:
                    uid = row["paper_uid"]
                    sha1 = self._fetch_sha1(uid)
                    md_path, pdf_paths = self._find_files(sha1, row["source_ref"] or "")
                    meta = self._doi_map.get(uid, {})
                    out[title] = {
                        "paper_uid": uid,
                        "title": row["title"] or "",
                        "source_ref": row["source_ref"] or "",
                        "md_path": md_path,
                        "pdf_paths": pdf_paths,
                        "doi": meta.get("doi", ""),
                        "year": meta.get("year", ""),
                    }
            except Exception as e:
                logger.warning("EvidenceResolver.resolve_by_titles: %s", e)
        return out

    def _resolve_by_titles_local_kb(self, titles: List[str]) -> Dict[str, Dict]:
        out: Dict[str, Dict] = {}
        for title in titles:
            if not title or not title.strip():
                continue
            uid = self._kb_title_index.get(title.strip().lower()[:50])
            if not uid:
                continue
            rec = self._kb_index.get(uid, {})
            md_path, pdf_paths = self._find_local_kb_files(rec)
            out[title] = {
                "paper_uid": rec.get("paper_uid") or uid,
                "title": rec.get("title", ""),
                "source_ref": rec.get("source_ref", ""),
                "md_path": md_path,
                "pdf_paths": pdf_paths,
                "doi": rec.get("doi", ""),
                "year": rec.get("year", ""),
            }
        return out

    # ------------------------------------------------------------------
    def _fetch_sha1(self, uid: str) -> str:
        if not self._has_sha1 or not uid:
            return ""
        try:
            row = self._conn.execute(
                "SELECT content_sha1 FROM papers WHERE paper_uid=? LIMIT 1",
                (uid,),
            ).fetchone()
            return (row["content_sha1"] or "") if row else ""
        except Exception:
            return ""

    def _find_local_kb_files(self, rec: Dict[str, str]):
        """local_kb 模式定位源文：优先内容库（本地缓存→远程拉取），再回退原始 source_ref。

        优先级：
          1. content_store/<paper_id>/ 本地命中 full.md / *.pdf —— 步骤⑧物化，随 artifacts
             走，跨机部署 / 原始解析目录被移走也有效。
          2. 本地缺但有 _manifest.json（说明文件在远程，本地是清过的缓存目录）→ 经
             content_store_remote.fetch_file 从远程 Ceph 桶按需拉回本地缓存，再返回。
          3. source.source_ref 原始目录 —— 仅同机有效，最后兜底。
        """
        paper_id = rec.get("paper_id") or rec.get("paper_uid") or ""
        # Priority 1 + 2: 可移植内容库（本地缓存 / 远程按需拉取）
        if paper_id and self._local_store:
            md_path, pdf_paths = self._resolve_from_store(paper_id)
            if md_path or pdf_paths:
                return md_path, pdf_paths
        # Priority 3: 原始 source_ref（同机兜底）
        return self._find_files("", rec.get("source_ref", ""))

    def _resolve_from_store(self, paper_id: str):
        """从内容库取这篇的 full.md + pdf；本地缺失且 _manifest 标记有远程副本时拉回缓存。"""
        pdir = self._local_store / paper_id
        md = pdir / "full.md"
        md_path = str(md) if md.exists() else ""
        pdf_paths = [str(p) for p in sorted(pdir.glob("*.pdf"))]
        if md_path or pdf_paths:
            return md_path, pdf_paths

        # 本地没有实体文件：看 _manifest.json 是否指明远程有，有则按需拉取
        manifest = pdir / "_manifest.json"
        if not manifest.exists():
            return "", []
        try:
            import json as _json
            info = _json.loads(manifest.read_text(encoding="utf-8"))
        except Exception:
            return "", []

        try:
            import sys as _sys
            if str(_PROJECT_ROOT) not in _sys.path:
                _sys.path.insert(0, str(_PROJECT_ROOT))
            from content_store_remote import fetch_file
        except Exception:
            return "", []

        if info.get("md"):
            if fetch_file(paper_id, "full.md", md):
                md_path = str(md)
        for name in (info.get("pdfs") or []):
            dest = pdir / name
            if dest.exists() or fetch_file(paper_id, name, dest):
                pdf_paths.append(str(dest))
        return md_path, pdf_paths

    def _find_files(self, sha1: str, source_ref: str):
        md_path = ""
        pdf_paths: List[str] = []

        # Priority 1: content_store via sha1
        if sha1 and self._content_store and self._content_store.exists():
            prefix_dir = self._content_store / sha1[:2] / sha1[2:4]
            cs_md = prefix_dir / f"{sha1}.md"
            if not cs_md.exists() and prefix_dir.exists():
                candidates = list(prefix_dir.glob(f"{sha1}*.md"))
                if candidates:
                    cs_md = candidates[0]
            if cs_md.exists():
                md_path = str(cs_md)
                pdf_paths = [str(p) for p in cs_md.parent.glob("*.pdf")]

        # Priority 2: source_ref (may be stale cross-machine path)
        if not md_path and source_ref:
            src = Path(source_ref)
            try:
                if src.is_dir():
                    md = src / "full.md"
                    if md.exists():
                        md_path = str(md)
                    pdf_paths = [str(p) for p in src.glob("*.pdf")]
                elif src.is_file() and src.suffix.lower() == ".md" and src.exists():
                    md_path = str(src)
                    pdf_paths = [str(p) for p in src.parent.glob("*.pdf")]
            except OSError:
                pass

        return md_path, pdf_paths

    # ------------------------------------------------------------------
    @staticmethod
    def _load_doi_map(meta_path: Path) -> Dict[str, Dict[str, str]]:
        """从 metadata.jsonl 加载 paper_uid → {doi, year} 映射。"""
        if not meta_path or not meta_path.exists():
            return {}
        out: Dict[str, Dict[str, str]] = {}
        try:
            with open(meta_path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        d = json.loads(line)
                        uid = d.get("paper_uid") or ""
                        doi = d.get("doi") or ""
                        if uid:
                            out[uid] = {
                                "doi": doi,
                                "year": str(d.get("year") or ""),
                            }
                    except Exception:
                        pass
        except Exception as e:
            logger.warning("EvidenceResolver: load metadata.jsonl failed: %s", e)
        logger.info("EvidenceResolver: loaded doi_map with %d entries", len(out))
        return out

    # ------------------------------------------------------------------
    def _load_kb_fallback(self, kb_json_path: Path) -> None:
        """state.db 缺失时的兜底：从本仓库 knowledge_base.json 建索引。

        每篇取 paper_id / paper_uid / title / doi / year / source.source_ref；source_ref
        指向步骤④ MinerU 解析目录（含 full.md + pdf），交给 _find_files 走 Priority 2 定位。
        这样无外部 state.db 也能产出 evidence_papers（md 全文 + doi/year + 下载包）。

        ⚠️ 关键：下游 resolve() 传进来的 id **两种都有**——KB chunk 用 `paper_id`（=
        knowledge_base.json 顶层键 `P0001`），KG evidence 用 sha1 `paper_uid`。所以这里
        **同时按 paper_id 和 paper_uid 建索引**，两种 id 都能直接命中、不必依赖标题兜底。
        返回记录的 `paper_uid` 字段统一回填顶层键（与 server `_pdf_index` 的 uid 一致）。
        """
        if not kb_json_path or not kb_json_path.exists():
            logger.info("EvidenceResolver: no state.db and no local KB json (%s) — "
                        "evidence 溯源不可用", kb_json_path)
            return
        try:
            with open(kb_json_path, "r", encoding="utf-8") as f:
                kb = json.load(f)
        except Exception as e:
            logger.warning("EvidenceResolver: load knowledge_base.json failed: %s", e)
            return

        # kb 形如 {"P0001": {...}, ...}
        for top_key, paper in (kb.items() if isinstance(kb, dict) else []):
            if not isinstance(paper, dict):
                continue
            paper_id = paper.get("paper_id") or top_key
            paper_uid = paper.get("paper_uid") or ""
            if not paper_id and not paper_uid:
                continue
            source = paper.get("source") or {}
            source_ref = source.get("source_ref", "") if isinstance(source, dict) else ""
            title = paper.get("paper_title") or paper.get("title") or ""
            # 回填的 paper_uid 用顶层键 paper_id（server _build_references 以它做下载 uid，
            # 且 KB chunk 的 paper_id 也是它）；这样 references 与 chunk 能对上。
            rec = {
                "paper_id": paper_id,
                "paper_uid": paper_id,
                "title": title,
                "doi": paper.get("doi") or "",
                "year": str(paper.get("year") or ""),
                "source_ref": source_ref or "",
            }
            # 同时按 paper_id 与 sha1 paper_uid 建索引，两种 id 都能直接命中
            if paper_id:
                self._kb_index[paper_id] = rec
            if paper_uid:
                self._kb_index[paper_uid] = rec
            if title:
                self._kb_title_index[title.strip().lower()[:50]] = paper_id or paper_uid
        logger.info("EvidenceResolver ready (local KB): %d index keys from %s",
                    len(self._kb_index), kb_json_path)

    # ------------------------------------------------------------------
    def close(self) -> None:
        if self._conn:
            try:
                self._conn.close()
            except Exception:
                pass
            self._conn = None
            self._available = False
