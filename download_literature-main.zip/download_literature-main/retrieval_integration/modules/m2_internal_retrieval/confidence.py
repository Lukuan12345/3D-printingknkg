#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
confidence.py —— 模块2置信度计算

直接基于 Reranker（融合后）分数，避免额外 LLM 调用。
"""

from typing import List, Dict


def compute_retrieval_confidence(
    chunks: List[Dict],
    strategy: str = "reranker_top3_avg",
    score_key: str = "fused_score",
) -> float:
    """
    基于融合分数计算 retrieval_confidence。

    Args:
        chunks:   kb_mvp 返回的 top_k（每条含 fused_score）
        strategy: reranker_top1 | reranker_top3_avg | reranker_topk_weighted
        score_key: 分数字段名（fused_score / dense_score / etc.）

    Returns:
        0~1 的置信度
    """
    if not chunks:
        return 0.0

    scores = [float(c.get(score_key, 0.0) or 0.0) for c in chunks]
    scores = sorted(scores, reverse=True)

    if strategy == "reranker_top1":
        return _clip01(scores[0])

    if strategy == "reranker_top3_avg":
        top = scores[:3]
        return _clip01(sum(top) / len(top))

    if strategy == "reranker_topk_weighted":
        # 按排名加权：w_i = 1 / (rank+1)
        weights = [1.0 / (i + 1) for i in range(len(scores))]
        total_w = sum(weights)
        val = sum(s * w for s, w in zip(scores, weights)) / total_w
        return _clip01(val)

    # 兜底
    return _clip01(scores[0])


def _clip01(v: float) -> float:
    if v < 0.0:
        return 0.0
    if v > 1.0:
        return 1.0
    return v
