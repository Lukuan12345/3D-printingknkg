#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
kb_mvp_adapter.py —— kb_mvp.HybridSearcher 适配器

将 kb_mvp 的三路混合检索（Metadata + Dense + Sparse）接入本项目。
不重写检索逻辑，仅做参数传递与结果转换。
"""

import sys
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

# 主项目根 = retrieval_integration 的父目录（kb_mvp 在此目录下）
_RI_ROOT = Path(__file__).resolve().parent.parent.parent
_PROJECT_ROOT = _RI_ROOT.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

logger = logging.getLogger(__name__)


class KBMVPAdapter:
    """
    包装 kb_mvp.HybridSearcher。

    - 惰性初始化（首次调用时加载索引）
    - 支持 structured_query + filters
    - 统一返回 chunks 列表
    """

    def __init__(self, weights: Optional[Dict[str, float]] = None):
        self._searcher = None  # 惰性
        self.weights = weights or {}

    # ------------------------------------------------------------
    def _ensure_searcher(self):
        if self._searcher is not None:
            return

        # 动态 import，避免启动时就加载
        try:
            from kb_mvp.src.searcher import HybridSearcher
            from kb_mvp.src import config as kb_cfg
        except ImportError as e:
            raise ImportError(
                f"kb_mvp 导入失败: {e}. 确保 kb_mvp 已初始化（运行 kb_mvp/src/ingest.py）"
            )

        # 按本项目配置覆盖 kb_mvp 权重
        if self.weights:
            kb_cfg.WEIGHT_METADATA = self.weights.get(
                "metadata", kb_cfg.WEIGHT_METADATA
            )
            kb_cfg.WEIGHT_DENSE_V2 = self.weights.get(
                "dense", kb_cfg.WEIGHT_DENSE_V2
            )
            kb_cfg.WEIGHT_SPARSE_V2 = self.weights.get(
                "sparse", kb_cfg.WEIGHT_SPARSE_V2
            )

        self._searcher = HybridSearcher()
        logger.info("KBMVPAdapter: HybridSearcher initialized")

    # ------------------------------------------------------------
    def search(
        self,
        query: str,
        query_json: Optional[Dict[str, Any]] = None,
        filters: Optional[Dict[str, Any]] = None,
        top_k: int = 10,
        top_k_each: int = 20,
    ) -> Dict[str, Any]:
        """
        执行检索。

        Returns:
            {
              "top_k": List[chunk_dict],        # 富化后的 chunks
              "stats": {...},
              "metadata_scores": [...] | None,
            }
        """
        self._ensure_searcher()
        return self._searcher.search(
            query=query,
            query_json=query_json,
            filters=filters,
            top_k=top_k,
            top_k_each=top_k_each,
        )

    # ------------------------------------------------------------
    def structurize_query(self, query: str) -> Optional[Dict[str, Any]]:
        """
        可选：调用 kb_mvp.QueryStructurizer 生成结构化 JSON。
        若失败返回 None。
        """
        try:
            from kb_mvp.src.query_structurizer import QueryStructurizer
            structurizer = QueryStructurizer()
            return structurizer.structurize(query)
        except Exception as e:
            logger.warning(f"QueryStructurizer failed: {e}")
            return None

    # ------------------------------------------------------------
    def get_papers_titles(self) -> List[tuple]:
        """
        从 SQLite 拉 (paper_id, match_title) 列表，用于 M2 标题精确匹配 boost。
        优先返回 title_cn（中文标题），无中文标题时回退到英文 title。
        中文 title_cn 使得 lexical 分支对中文 query 给出 sim≈1.0，彻底解决跨语言误排。
        """
        self._ensure_searcher()
        conn = self._searcher.prefilter.conn
        try:
            rows = conn.execute(
                "SELECT paper_id, title, title_cn FROM papers_metadata"
            ).fetchall()
            return [
                (r["paper_id"], r["title_cn"] or r["title"] or "")
                for r in rows
            ]
        except Exception:
            # title_cn 列不存在时（旧库）退回纯英文
            rows = conn.execute(
                "SELECT paper_id, title FROM papers_metadata"
            ).fetchall()
            return [(r["paper_id"], r["title"] or "") for r in rows]

    # ------------------------------------------------------------
    def embed_texts(self, texts: List[str]):
        """
        批量 embedding（normalized）。供 title_boost 跨语言语义匹配使用。

        BGE-M3 原生支持中英双语，是跨语言相似度的最佳模型。
        返回 np.ndarray shape=(N, D)，行向量已 L2 归一化（与 dense_retrieval 一致），
        因此 inner product 即等价于 cosine similarity。
        失败时抛异常（调用方负责降级）。
        """
        import numpy as np  # 局部 import，避免冷启动开销
        from kb_mvp.src.embedding import get_client

        client = get_client()
        vecs = client.embed(texts)  # (N, D) float32，未归一化
        if vecs.size == 0:
            return vecs
        norms = np.linalg.norm(vecs, axis=1, keepdims=True)
        norms[norms == 0] = 1.0
        return (vecs / norms).astype(np.float32)

    # ------------------------------------------------------------
    def fetch_chunks_for_papers(self, paper_ids: List[str]) -> List[Dict[str, Any]]:
        """
        H2 (2026-05-10): 按 paper_id 反查所有 chunks，含 embedding_idx 用于 npy 查表。
        """
        self._ensure_searcher()
        if not paper_ids:
            return []
        conn = self._searcher.prefilter.conn
        placeholders = ",".join(["?"] * len(paper_ids))
        rows = conn.execute(
            f"SELECT chunk_id, paper_id, field_type, content, embedding_idx "
            f"FROM paper_chunks WHERE paper_id IN ({placeholders})",
            list(paper_ids),
        ).fetchall()
        return [
            {
                "chunk_id": r["chunk_id"],
                "paper_id": r["paper_id"],
                "field_type": r["field_type"],
                "content": r["content"] or "",
                "embedding_idx": r["embedding_idx"],
            }
            for r in rows
        ]

    def get_chunk_embeddings_by_idx(self, indices: List[int]):
        """
        从 embeddings.npy 按 embedding_idx 查表，返回 np.ndarray shape=(N, D)，已归一化。
        比实时推理快 1000x（无模型调用，纯 numpy 索引）。
        若 embeddings.npy 不可用则返回 None，调用方降级到 embed_texts。
        """
        self._ensure_searcher()
        emb_matrix = getattr(self._searcher.dense, "_embeddings", None)
        if emb_matrix is None or len(indices) == 0:
            return None
        import numpy as np
        valid_mask = [(i is not None and 0 <= i < len(emb_matrix)) for i in indices]
        if not any(valid_mask):
            return None
        result = np.zeros((len(indices), emb_matrix.shape[1]), dtype=np.float32)
        for j, (idx, ok) in enumerate(zip(indices, valid_mask)):
            if ok:
                result[j] = emb_matrix[idx]
        return result
