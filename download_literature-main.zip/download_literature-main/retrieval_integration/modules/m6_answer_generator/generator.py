#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
generator.py —— 模块6：答案生成

根据 ctx.state 分流：
- State.A: 纯外部文献总结
- State.B: 内外缝合

生成完成后可选触发知识回流。
"""

from typing import Any, Dict, List

from ...core import BaseModule, RequestContext, State
from ...llm import get_llm_client, get_prompt, extract_answer_and_meta
from ..kg_context import format_kg_context
from .backflow_trigger import maybe_push_backflow
from ..confidence_scorer import score_from_ctx


class FinalAnswerGenerator(BaseModule):
    name = "m6_answer_generator"

    def __init__(self, config=None):
        super().__init__(config)
        self.llm = get_llm_client()
        self.max_docs = self._module_cfg.get("max_docs_in_prompt", 15)
        self.max_chars_per_doc = self._module_cfg.get("max_chars_per_doc", 1200)
        self.max_internal_chunks = self._module_cfg.get("max_internal_chunks", 10)
        self.max_chars_per_chunk = self._module_cfg.get("max_chars_per_chunk", 800)
        self.include_kg_paths = self._module_cfg.get("include_kg_paths_in_prompt", True)
        self.max_kg_paths = self._module_cfg.get("max_kg_paths", 5)

        # NEW (融合需求 3a): 是否调用 LLM 生成回答
        # False 时跳过所有 LLM 调用，仅返回检索结果
        self.llm_response_enabled = self._module_cfg.get("llm_response", True)

        # 知识回流阈值
        self.hq_threshold = self.config.get(
            "pipeline.thresholds.m6_high_quality", 0.85
        )
        self.backflow_enabled = self.config.get(
            "knowledge_backflow.enabled", True
        )

    # ------------------------------------------------------------
    def _run(self, ctx: RequestContext) -> RequestContext:
        # ----- 短路 0：LLM 关闭（融合 m6.llm_response=False）-----
        if not self.llm_response_enabled:
            ctx.skipped_llm = True
            ctx.final_answer = ""
            ctx.final_confidence = 0.0
            ctx.warnings.append("m6: llm_response=false, LLM 跳过")
            return ctx

        # ----- 短路：内外资料都为空，跳过 LLM 调用 -----
        # 场景：状态A 走外部路径，但所有外部 API 都未配置/未返回
        # 此时调用 LLM 只会浪费 token 并很可能截断
        n_internal = len(ctx.internal_chunks or [])
        n_external = len(ctx.external_docs or [])
        if n_internal == 0 and n_external == 0:
            ctx.warnings.append(
                "m6: 内部 chunks 与外部文献均为空，已跳过 LLM 调用"
            )
            ctx.final_answer = self._empty_inputs_answer(ctx)
            ctx.final_confidence = 0.0
            ctx.key_findings = []
            ctx.references = []
            return ctx

        state = ctx.state or State.A
        system_prompt = get_prompt("m6_answer_generator", "system")
        external_text = self._format_external(ctx.external_docs)

        # query 过长（>500字）时截短到前 500 字，防止 LLM 超时
        query_for_prompt = ctx.query[:500] if len(ctx.query) > 500 else ctx.query

        # 把 KG 推理路径渲染为 prompt 上下文（融合双轨用：KG 提供逻辑骨架）
        kg_text = format_kg_context(
            ctx.kg_reasoning_paths,
            kg_summary=ctx.kg_summary,
            kg_intent=ctx.kg_intent or "",
        )

        # State A 但外部文献为空且有内部 chunks：降级为 State B 以避免 LLM 拿到空 context
        effective_state = state
        if state != State.B and n_external == 0 and n_internal > 0:
            effective_state = State.B

        if effective_state == State.B:
            internal_text = self._format_internal(ctx.internal_chunks)
            # KG 推理路径注入：优先用详细的 _format_kg_paths，
            # 再叠加 format_kg_context（含摘要和意图）
            kg_paths_text = (
                self._format_kg_paths(ctx.kg_reasoning_paths)
                if self.include_kg_paths and ctx.kg_reasoning_paths
                else ""
            )
            if kg_paths_text:
                internal_text = f"{kg_paths_text}\n\n[知识库物理证据]\n{internal_text}"
            elif kg_text:
                internal_text = f"{kg_text}\n\n[知识库证据]\n{internal_text}"

            # Critic 约束分析注入：告知 LLM 哪些约束有/无文献满足
            critic_block = self._format_critic_block(ctx)
            if critic_block:
                internal_text = f"{critic_block}\n\n{internal_text}"

            # 真实论文清单（evidence_papers）：限定 LLM 引用范围，防止编造 DOI
            papers_list_text = self._format_evidence_papers(ctx.evidence_papers)

            user_prompt = get_prompt("m6_answer_generator", "user_state_b").format(
                query=query_for_prompt,
                internal_context=internal_text,
                num_docs=len(ctx.external_docs),
                external_docs=external_text,
                papers_list=papers_list_text,
            )
        else:
            external_with_kg = external_text
            if kg_text:
                external_with_kg = f"{kg_text}\n\n[外部文献]\n{external_text}"
            # 真实论文清单也注入 state_a
            papers_list_text = self._format_evidence_papers(ctx.evidence_papers)
            user_prompt = get_prompt("m6_answer_generator", "user_state_a").format(
                query=query_for_prompt,
                num_docs=len(ctx.external_docs),
                external_docs=external_with_kg,
                papers_list=papers_list_text,
            )

        raw = self.llm.call(
            prompt=user_prompt,
            system_prompt=system_prompt,
            module="m6_generator",
        )
        result = extract_answer_and_meta(raw) if raw else None

        # 解析失败时精简重试：截短文档 + 截短 query，避免 LLM 超时截断
        if not result or not result.get("answer"):
            self.logger.warning("m6: 首次解析失败，尝试精简重试（top-3 docs, 300 chars each, query≤500字）")
            short_ext = self._format_external_short(ctx.external_docs, max_docs=3, max_chars=300)
            short_query = ctx.query[:500] if len(ctx.query) > 500 else ctx.query
            short_papers_list = self._format_evidence_papers(
                ctx.evidence_papers, max_papers=10
            )
            # 外部文献为空时退化为 State B（用 internal_chunks），避免 LLM 拿到全空 context
            has_ext = short_ext != "(未检索到外部文献)"
            has_int = bool(ctx.internal_chunks)
            if not has_ext and has_int:
                short_internal = self._format_internal(ctx.internal_chunks)
                retry_prompt = get_prompt("m6_answer_generator", "user_state_b").format(
                    query=short_query,
                    internal_context=short_internal,
                    num_docs=0,
                    external_docs="(未检索到外部文献)",
                    papers_list=short_papers_list,
                )
            else:
                retry_prompt = get_prompt("m6_answer_generator", "user_state_a").format(
                    query=short_query,
                    num_docs=min(3, len(ctx.external_docs or [])),
                    external_docs=short_ext if has_ext else
                        self._format_internal(ctx.internal_chunks),
                    papers_list=short_papers_list,
                )
            raw2 = self.llm.call(
                prompt=retry_prompt,
                system_prompt=system_prompt,
                module="m6_generator",
                use_cache=False,
            )
            result = extract_answer_and_meta(raw2) if raw2 else None

        if not result or not result.get("answer"):
            ctx.warnings.append("m6: LLM 输出解析失败（格式不符或内容为空）")
            ctx.final_answer = self._fallback_answer(ctx)
            ctx.final_confidence = 0.3
            return ctx

        ctx.final_answer = result.get("answer", "")
        ctx.key_findings = result.get("key_findings") or []
        ctx.references = result.get("references") or []
        ctx.conflicts = result.get("conflicts") or []
        ctx.limitations = result.get("limitations", "")

        # final_confidence 由加权公式计算，LLM 只提供 factual_grounding 和 completeness
        llm_scores = {
            "factual_grounding": result.get("factual_grounding", 0.0),
            "completeness":      result.get("completeness", 0.0),
        }
        ctx.final_confidence = score_from_ctx(ctx, llm_scores)

        # 知识回流触发
        if self.backflow_enabled and ctx.final_confidence >= self.hq_threshold:
            try:
                maybe_push_backflow(ctx, self.config)
                ctx.backflow_pushed = True
            except Exception as e:
                self.logger.warning(f"知识回流触发失败: {e}")

        return ctx

    # ------------------------------------------------------------
    @staticmethod
    def _empty_inputs_answer(ctx: RequestContext) -> str:
        """内外资料都为空时给用户的明确说明（替代 LLM 输出）。"""
        state = ctx.state.value if ctx.state else "?"
        miss = ", ".join(ctx.missing_aspects[:3]) if ctx.missing_aspects else ""
        miss_part = f"\n· 缺失方面: {miss}" if miss else ""
        return (
            f"⚠️ 本次未获得任何参考资料，无法生成可靠答案。\n\n"
            f"诊断信息:\n"
            f"· 路由状态: {state}\n"
            f"· M2 内部命中: 0 条 chunks\n"
            f"· M5 外部检索: 0 篇文献{miss_part}\n\n"
            f"可能原因与处理建议:\n"
            f"1. 外部 API 未配置 → 在 default_config.yaml 启用 PubMed/arXiv，"
            f"或为星河图书馆填入 base_url\n"
            f"2. 内部知识库该领域覆盖不足 → 扩充 KB 后重试\n"
            f"3. M1/M2 阈值过严 → 在前端调低 M1/M2 阈值再试"
        )

    # ------------------------------------------------------------
    def _format_external(self, docs: List[Dict[str, Any]]) -> str:
        parts = []
        for i, d in enumerate(docs[: self.max_docs], 1):
            abs_txt = (d.get("abstract") or "")[: self.max_chars_per_doc]
            parts.append(
                f"[{i}] {d.get('title', '')}\n"
                f"    作者: {', '.join(d.get('authors') or [])}\n"
                f"    来源: {d.get('source_api', '')} | 年份: {d.get('year', 'N/A')}\n"
                f"    链接: {d.get('url') or d.get('doi') or 'N/A'}\n"
                f"    摘要: {abs_txt}"
            )
        return "\n\n".join(parts) if parts else "(未检索到外部文献)"

    def _format_external_short(
        self,
        docs: List[Dict[str, Any]],
        max_docs: int = 3,
        max_chars: int = 300,
    ) -> str:
        """精简版外部文献格式，用于解析失败后的重试，避免 prompt 过长导致 LLM 超时。"""
        parts = []
        for i, d in enumerate(docs[:max_docs], 1):
            abs_txt = (d.get("abstract") or "")[:max_chars]
            parts.append(
                f"[{i}] {d.get('title', '')}\n"
                f"    来源: {d.get('source_api', '')} {d.get('year', '')}\n"
                f"    {abs_txt}"
            )
        return "\n\n".join(parts) if parts else "(未检索到外部文献)"

    def _format_internal(self, chunks: List[Dict[str, Any]]) -> str:
        parts = []
        for i, c in enumerate(chunks[:self.max_internal_chunks], 1):
            content = (c.get("content") or "")[:self.max_chars_per_chunk]
            title = c.get("title", "")
            field = c.get("field_type", "")
            score = c.get("fused_score", 0) or 0
            parts.append(f"[内部{i}] {title}（{field}，相关度={score:.3f}）\n  {content}")
        return "\n\n".join(parts) if parts else "(无内部知识库信息)"

    def _format_kg_paths(self, paths: List[Dict]) -> str:
        """把 KG 推理路径格式化为 prompt 可读的文字链条。"""
        if not paths:
            return ""
        lines = ["【知识图谱推理路径（设计知识演化链）】"]
        for i, p in enumerate(paths[:self.max_kg_paths], 1):
            text = p.get("text", "") if isinstance(p, dict) else str(p)
            sps = (p.get("support_papers") or []) if isinstance(p, dict) else []
            sp_str = "；".join(
                f"{sp.get('title','')[:50]}（{sp.get('year','')}）"
                for sp in sps[:3]
            )
            lines.append(f"链路{i}: {text}")
            if sp_str:
                lines.append(f"  └→ 关联文献: {sp_str}")
        return "\n".join(lines)

    def _format_evidence_papers(
        self,
        papers: List[Dict[str, Any]],
        max_papers: int = 30,
    ) -> str:
        """格式化 evidence_papers 为 LLM 可引用的"真实论文清单"。

        这是 LLM 写 references 字段时**唯一允许引用的论文集合**。
        prompt 端会强制约束 LLM 只能从此清单挑选 title 与 paper_uid，
        防止 LLM 根据 reasoning_paths 概念名编造伪 DOI。
        """
        if not papers:
            return "(本次未从内部知识库定位到具体论文。如需引用，请在 limitations 中声明)"

        lines = [
            f"【真实论文清单】（共 {len(papers)} 篇，本次允许引用的全部论文）",
            "说明：references 字段中的每条 title 和 paper_uid 必须严格来自本清单。",
        ]
        for i, p in enumerate(papers[:max_papers], 1):
            if not isinstance(p, dict):
                continue
            pid = p.get("paper_uid") or p.get("paper_id") or "?"
            title = (p.get("title") or p.get("paper_title") or "").strip()
            year = p.get("year") or ""
            year_str = f" [{year}]" if year else ""
            lines.append(f"  [{i}]{year_str} paper_uid={pid}")
            lines.append(f"      title: {title}")
        if len(papers) > max_papers:
            lines.append(f"  ... 另有 {len(papers) - max_papers} 篇省略")
        return "\n".join(lines)

    @staticmethod
    def _format_critic_block(ctx: RequestContext) -> str:
        """把 Critic 的约束分析格式化为 prompt 块，告知 LLM 哪些指标有无文献支撑。"""
        constraints = getattr(ctx, "critic_constraints", None)
        if not constraints:
            return ""

        scored = getattr(ctx, "critic_scored_papers", []) or []
        elimination_mode = getattr(ctx, "critic_elimination_mode", False)

        lines = ["【Critic 约束核查报告（Gemini 验证）】"]
        lines.append(f"用户查询包含 {len(constraints)} 项硬性约束：")
        for i, c in enumerate(constraints, 1):
            lines.append(f"  C{i}. {c}")

        if scored:
            # 找每个约束有哪些论文满足
            satisfied_map: dict = {c: [] for c in constraints}
            for p in scored:
                for sat in p.get("critic_satisfied", []):
                    for c in constraints:
                        if sat.strip().lower() in c.lower() or c.lower() in sat.strip().lower():
                            satisfied_map[c].append(p.get("title", "")[:60])
                            break

            lines.append("")
            lines.append("各约束文献覆盖情况：")
            for c, titles in satisfied_map.items():
                if titles:
                    lines.append(f"  ✓ {c}：有 {len(titles)} 篇文献满足")
                else:
                    lines.append(f"  ✗ {c}：【无文献满足，请在回答中说明此约束超出当前知识库范围】")

        if elimination_mode:
            note = getattr(ctx, "critic_elimination_note", {}) or {}
            if note.get("elimination_summary"):
                lines.append("")
                lines.append(f"排除法说明：{note['elimination_summary']}")
            suggestions = note.get("search_suggestions") or []
            if suggestions:
                lines.append("建议检索方向：" + "；".join(suggestions[:3]))

        lines.append("")
        lines.append("【重要】请在回答中明确说明哪些约束有文献支撑、哪些约束在知识库中缺乏覆盖。")
        return "\n".join(lines)

    @staticmethod
    def _fallback_answer(ctx: RequestContext) -> str:
        n = len(ctx.external_docs)
        return (
            f"（答案生成失败的降级输出）外部检索到 {n} 篇文献，请稍后重试或查看原始文献。"
        )

    @staticmethod
    def _clip(v) -> float:
        try:
            v = float(v)
        except (TypeError, ValueError):
            return 0.0
        return max(0.0, min(1.0, v))
