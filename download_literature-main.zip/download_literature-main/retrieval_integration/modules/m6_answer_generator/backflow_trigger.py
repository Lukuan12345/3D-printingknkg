#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
backflow_trigger.py —— 知识回流触发器

高质量答案 → 推送到候选池（由 knowledge_backflow 模块异步处理）
"""

import json
from datetime import datetime
from pathlib import Path
from typing import Any

from ...config import Config


def maybe_push_backflow(ctx, config: Config) -> None:
    """
    若 final_confidence 达到阈值，将答案写入候选池。
    """
    threshold = config.get(
        "knowledge_backflow.candidate_pool.min_confidence", 0.85
    )
    if ctx.final_confidence < threshold:
        return

    pool_rel = config.get(
        "knowledge_backflow.candidate_pool.path", "data/candidate_pool/"
    )
    pool_dir = config.resolve_path(pool_rel)
    pool_dir.mkdir(parents=True, exist_ok=True)

    record = {
        "request_id": ctx.request_id,
        "query": ctx.query,
        # ── M1 结构化解析快照 ──
        "query_parsed": {
            "matched_schema_fields": list(ctx.matched_schema_fields or []),
            "parse_confidence": float(ctx.parse_confidence or 0.0),
            "covered_aspects": list(ctx.covered_aspects or []),
            "missing_aspects": list(ctx.missing_aspects or []),
        },
        # ── M4 检索计划摘要 ──
        "search_plan_summary": _summarize_search_plan(ctx.search_plan),
        # ── 答案与引用 ──
        "answer": ctx.final_answer,
        "key_findings": ctx.key_findings,
        "references": ctx.references,
        # ── 融合新增：3b/3d/3e ──
        "kg_reasoning_paths": list(ctx.kg_reasoning_paths or [])[:5],
        "evidence_papers": list(ctx.evidence_papers or []),
        "external_refs": [
            {
                "title": d.get("title"),
                "doi": d.get("doi"),
                "url": d.get("url"),
                "source_api": d.get("source_api"),
                "local_pdf_path": d.get("local_pdf_path"),
            }
            for d in (ctx.external_docs or [])
        ],
        # ── v2 新增：KG↔KB 不一致诊断（§9）──
        "channel": getattr(ctx, "channel", None),
        "inconsistencies": list(getattr(ctx, "inconsistencies", []) or []),
        "kb_hints_debug": (getattr(ctx, "kb_hints", {}) or {}).get("debug", {}),
        # ── 四维评分明细 ──
        "confidence_breakdown": {
            "parse":     float(ctx.parse_confidence or 0.0),
            "retrieval": float(ctx.retrieval_confidence or 0.0),
            "answer":    float(ctx.answer_confidence or 0.0),
            "final":     float(ctx.final_confidence or 0.0),
        },
        "final_confidence": ctx.final_confidence,
        "state": ctx.state.value if ctx.state else None,
        "created_at": datetime.now().isoformat(),
    }

    date_str = datetime.now().strftime("%Y-%m-%d")
    path = pool_dir / f"candidates_{date_str}.jsonl"
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")


def _summarize_search_plan(plan: Any) -> Any:
    """从 ctx.search_plan 抽取审核/聚合最有用的几个字段，避免完整 plan 体积过大。"""
    if not plan or not isinstance(plan, dict):
        return None
    qr = plan.get("query_rewrites", {}) or {}
    sp = plan.get("source_priority", {}) or {}
    dt = qr.get("dual_track_queries", {}) or {}
    core_entities = qr.get("core_entities", []) or []
    # core_entities 可能是 [{"entity":..., "synonyms":[...]}] 结构，抽 entity 名简化
    if core_entities and isinstance(core_entities[0], dict):
        core_entities = [c.get("entity") for c in core_entities if c.get("entity")]
    return {
        "core_entities":   core_entities,
        "boolean_query":   qr.get("boolean_query", ""),
        "keywords_expand": qr.get("keywords_expand", []) or [],
        "strict_query":    dt.get("strict_query", ""),
        "expansive_query": dt.get("expansive_query", ""),
        "target_apis":     sp.get("target_apis", []) or [],
        "target_journals": sp.get("target_journals", []) or [],
    }
