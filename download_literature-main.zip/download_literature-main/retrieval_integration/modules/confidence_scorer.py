#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
confidence_scorer.py —— final_confidence 加权计算

将 final_confidence 从"LLM 主观一次给分"改为基于客观指标 + LLM 小范围评分的加权公式：

    final_confidence =
        source_score      × 0.40  （客观：数据来源质量，代码计算）
      + coverage_score    × 0.30  （客观：M3 覆盖率，covered/total）
      + factual_grounding × 0.25  （LLM：答案是否有参考来源支撑）
      + completeness      × 0.05  （LLM：核心问题是否得到回答）

约束原则：
  - 客观指标占 70%，LLM 只评估它能评估的（剩余 30%）
  - LLM 打分时必须给出依据，禁止无来源高分
  - 内外数据都空时 source_score=0，total 上限 ≈ 0.30（LLM 部分）
  - 禁止在代码里强行拉高 LLM 输出，让分数反映真实质量

Deep 模式补充说明：
  - Deep 模式下 KG whitelist chunks 的 fused_score 天然比 fast 模式低
    （fast 有 title_boost +0.3~0.6，deep 没有），所以 raw retr_conf 偏低
  - 通过 blend_kg_into_retrieval_confidence() 在 S5 后把 kg_confidence 与
    chain_chunk_ratio 混入 retr_conf，再传入此处，使 source_score 正确反映质量
"""

from typing import Any, Dict, List, Optional


# ============================================================
# Deep 模式：将 KG 信号混入 retrieval_confidence
# ============================================================

def blend_kg_into_retrieval_confidence(
    raw_retr_conf: float,
    kg_confidence: float,
    chain_chunk_ratio: float,
    alpha: float = 0.35,
) -> float:
    """
    Deep 模式专用：把 KG reasoning 质量混入 retrieval_confidence。

    原理：
      Deep 模式的 raw retr_conf 是基于 KG whitelist chunks 的 fused_score 均值。
      由于这些 chunks 没有 fast 模式的 title_boost，分数天然偏低（0.35~0.45）。
      但 kg_confidence（KG 推演质量）和 chain_chunk_ratio（链上 chunks 覆盖率）
      反映了检索的真实质量，应纳入 retr_conf。

      blended = alpha * raw_kb_score + (1-alpha) * kg_quality
      kg_quality = kg_confidence * min(1.0, chain_chunk_ratio * 1.1)

    Args:
        raw_retr_conf:     原始 KB fused_score 均值
        kg_confidence:     KG 推演得分（0~1）
        chain_chunk_ratio: S5 chain↔chunk 覆盖率（0~1）
        alpha:             KB 原始分的权重（0.35 = 35% 原始 KB，65% KG 信号）

    Returns:
        混合后的 retrieval_confidence (0~1)
    """
    if kg_confidence <= 0:
        return raw_retr_conf
    kg_quality = kg_confidence * min(1.0, chain_chunk_ratio * 1.1)
    blended = alpha * raw_retr_conf + (1.0 - alpha) * kg_quality
    return round(min(1.0, max(0.0, blended)), 4)


# ============================================================
# 源数据质量分（完全由代码计算，0 ~ 1.0）
# ============================================================

def compute_source_score(
    retrieval_confidence: float,
    n_internal_chunks: int,
    n_external_docs: int,
) -> float:
    """
    基于内部检索质量和外部文献数量计算数据来源质量分。

    分级规则（优先级从高到低）：
      内部命中质量高（≥0.6）+ 外部 ≥5 篇 → 1.0
      内部命中质量高（≥0.6）+ 无外部      → 0.7
      内部命中质量中（≥0.4）+ 外部 ≥5 篇 → 0.7
      内部命中质量中（≥0.4）+ 无外部      → 0.5
      内部命中质量低（<0.4） + 外部 ≥5 篇 → 0.4
      内部命中质量低（<0.4） + 外部 1~4   → 0.3
      内部有 chunks 但质量极低 + 无外部    → 0.1
      内外都空                             → 0.0
    """
    has_internal = n_internal_chunks > 0
    n_ext = n_external_docs

    if retrieval_confidence >= 0.6:
        if n_ext >= 5:
            return 1.0
        return 0.7

    if retrieval_confidence >= 0.4:
        if n_ext >= 5:
            return 0.7
        return 0.5

    # retrieval_confidence < 0.4（含 State A 情况 retrieval_confidence=0）
    if n_ext >= 5:
        return 0.4
    if n_ext >= 1:
        return 0.3
    if has_internal:
        return 0.1
    return 0.0


# ============================================================
# 覆盖率分（完全由代码计算，0 ~ 1.0）
# ============================================================

def compute_coverage_score(
    covered_aspects: List[str],
    missing_aspects: List[str],
) -> float:
    """
    基于 M3 的覆盖情况计算覆盖率。
    若 M3 未运行（covered + missing == 0），视为无覆盖数据，返回 0.0。
    """
    n_cov = len(covered_aspects or [])
    n_miss = len(missing_aspects or [])
    total = n_cov + n_miss
    if total == 0:
        return 0.0
    return n_cov / total


# ============================================================
# 加权汇总
# ============================================================

WEIGHTS = {
    "source":      0.40,
    "coverage":    0.30,
    "factual":     0.25,
    "completeness": 0.05,
}


def compute_final_confidence(
    retrieval_confidence: float,
    n_internal_chunks: int,
    n_external_docs: int,
    covered_aspects: List[str],
    missing_aspects: List[str],
    factual_grounding: float,   # LLM 评分 0~1
    completeness: float,         # LLM 评分 0~1
) -> float:
    """
    最终置信度加权计算。

    Args:
        factual_grounding: LLM 评估"答案每个声明是否有参考来源支撑"，0~1
        completeness:      LLM 评估"核心问题是否得到回答"，0~1

    Returns:
        final_confidence 0~1
    """
    source   = compute_source_score(retrieval_confidence, n_internal_chunks, n_external_docs)
    coverage = compute_coverage_score(covered_aspects, missing_aspects)

    fg = max(0.0, min(1.0, factual_grounding))
    cp = max(0.0, min(1.0, completeness))

    score = (
        source   * WEIGHTS["source"]      +
        coverage * WEIGHTS["coverage"]    +
        fg       * WEIGHTS["factual"]     +
        cp       * WEIGHTS["completeness"]
    )
    return round(max(0.0, min(1.0, score)), 3)


def score_from_ctx(ctx: Any, llm_scores: Dict[str, float]) -> float:
    """
    从 RequestContext 直接计算 final_confidence 的便捷函数。

    Args:
        ctx:        RequestContext 实例
        llm_scores: {"factual_grounding": 0~1, "completeness": 0~1}
    """
    return compute_final_confidence(
        retrieval_confidence=getattr(ctx, "retrieval_confidence", 0.0),
        n_internal_chunks=len(getattr(ctx, "internal_chunks", []) or []),
        n_external_docs=len(getattr(ctx, "external_docs", []) or []),
        covered_aspects=getattr(ctx, "covered_aspects", []),
        missing_aspects=getattr(ctx, "missing_aspects", []),
        factual_grounding=llm_scores.get("factual_grounding", 0.0),
        completeness=llm_scores.get("completeness", 0.0),
    )



# ============================================================
# 源数据质量分（完全由代码计算，0 ~ 1.0）
# ============================================================

def compute_source_score(
    retrieval_confidence: float,
    n_internal_chunks: int,
    n_external_docs: int,
) -> float:
    """
    基于内部检索质量和外部文献数量计算数据来源质量分。

    分级规则（优先级从高到低）：
      内部命中质量高（≥0.6）+ 外部 ≥5 篇 → 1.0
      内部命中质量高（≥0.6）+ 无外部      → 0.7
      内部命中质量中（≥0.4）+ 外部 ≥5 篇 → 0.7
      内部命中质量中（≥0.4）+ 无外部      → 0.5
      内部命中质量低（<0.4） + 外部 ≥5 篇 → 0.4
      内部命中质量低（<0.4） + 外部 1~4   → 0.3
      内部有 chunks 但质量极低 + 无外部    → 0.1
      内外都空                             → 0.0
    """
    has_internal = n_internal_chunks > 0
    n_ext = n_external_docs

    if retrieval_confidence >= 0.6:
        if n_ext >= 5:
            return 1.0
        return 0.7

    if retrieval_confidence >= 0.4:
        if n_ext >= 5:
            return 0.7
        return 0.5

    # retrieval_confidence < 0.4（含 State A 情况 retrieval_confidence=0）
    if n_ext >= 5:
        return 0.4
    if n_ext >= 1:
        return 0.3
    if has_internal:
        return 0.1
    return 0.0


# ============================================================
# 覆盖率分（完全由代码计算，0 ~ 1.0）
# ============================================================

def compute_coverage_score(
    covered_aspects: List[str],
    missing_aspects: List[str],
) -> float:
    """
    基于 M3 的覆盖情况计算覆盖率。
    若 M3 未运行（covered + missing == 0），视为无覆盖数据，返回 0.0。
    """
    n_cov = len(covered_aspects or [])
    n_miss = len(missing_aspects or [])
    total = n_cov + n_miss
    if total == 0:
        return 0.0
    return n_cov / total


# ============================================================
# 加权汇总
# ============================================================

WEIGHTS = {
    "source":      0.40,
    "coverage":    0.30,
    "factual":     0.25,
    "completeness": 0.05,
}


def compute_final_confidence(
    retrieval_confidence: float,
    n_internal_chunks: int,
    n_external_docs: int,
    covered_aspects: List[str],
    missing_aspects: List[str],
    factual_grounding: float,   # LLM 评分 0~1
    completeness: float,         # LLM 评分 0~1
) -> float:
    """
    最终置信度加权计算。

    Args:
        factual_grounding: LLM 评估"答案每个声明是否有参考来源支撑"，0~1
        completeness:      LLM 评估"核心问题是否得到回答"，0~1

    Returns:
        final_confidence 0~1
    """
    source   = compute_source_score(retrieval_confidence, n_internal_chunks, n_external_docs)
    coverage = compute_coverage_score(covered_aspects, missing_aspects)

    fg = max(0.0, min(1.0, factual_grounding))
    cp = max(0.0, min(1.0, completeness))

    score = (
        source   * WEIGHTS["source"]      +
        coverage * WEIGHTS["coverage"]    +
        fg       * WEIGHTS["factual"]     +
        cp       * WEIGHTS["completeness"]
    )
    return round(max(0.0, min(1.0, score)), 3)


def score_from_ctx(ctx: Any, llm_scores: Dict[str, float]) -> float:
    """
    从 RequestContext 直接计算 final_confidence 的便捷函数。

    Args:
        ctx:        RequestContext 实例
        llm_scores: {"factual_grounding": 0~1, "completeness": 0~1}
    """
    return compute_final_confidence(
        retrieval_confidence=getattr(ctx, "retrieval_confidence", 0.0),
        n_internal_chunks=len(getattr(ctx, "internal_chunks", []) or []),
        n_external_docs=len(getattr(ctx, "external_docs", []) or []),
        covered_aspects=getattr(ctx, "covered_aspects", []),
        missing_aspects=getattr(ctx, "missing_aspects", []),
        factual_grounding=llm_scores.get("factual_grounding", 0.0),
        completeness=llm_scores.get("completeness", 0.0),
    )
