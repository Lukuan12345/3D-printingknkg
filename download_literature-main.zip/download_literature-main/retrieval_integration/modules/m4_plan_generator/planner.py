#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
planner.py —— 模块4：动态检索计划生成

根据 ctx.state 分流：
- State.A（内部零知识）：从0构建完整检索计划
- State.B（内部部分知识）：基于 Gap Analysis 生成补充检索计划
"""

import json
from typing import Any, Dict, List, Optional

from ...core import BaseModule, RequestContext, State
from ...llm import get_llm_client, get_prompt
from .plan_schema import validate_search_plan, ensure_default_plan


class RetrievalPlanner(BaseModule):
    name = "m4_plan_generator"

    def __init__(self, config=None):
        super().__init__(config)
        self.llm = get_llm_client()

        entities_cfg = self._module_cfg.get("core_entities", {})
        self.min_entities = entities_cfg.get("min", 2)
        self.max_entities = entities_cfg.get("max", 3)

        syn_cfg = self._module_cfg.get("synonyms_per_entity", {})
        self.min_synonyms = syn_cfg.get("min", 2)
        self.max_synonyms = syn_cfg.get("max", 3)

        kw_cfg = self._module_cfg.get("keywords_expand", {})
        self.min_keywords = kw_cfg.get("min", 3)
        self.max_keywords = kw_cfg.get("max", 5)

        self.available_apis: List[str] = self._module_cfg.get(
            "available_apis",
            ["星河图书馆", "PubMed API", "Bing Search API", "arXiv"],
        )
        self.max_target_apis = self._module_cfg.get("max_target_apis", 3)

    # ------------------------------------------------------------
    def _run(self, ctx: RequestContext) -> RequestContext:
        state = ctx.state or State.A
        system_prompt = get_prompt("m4_plan_generator", "system")
        output_format = get_prompt("m4_plan_generator", "output_format")

        if state == State.A:
            user_prompt = get_prompt("m4_plan_generator", "user_state_a").format(
                query=ctx.query,
                available_apis=", ".join(self.available_apis),
                min_entities=self.min_entities,
                max_entities=self.max_entities,
                min_synonyms=self.min_synonyms,
                max_synonyms=self.max_synonyms,
                min_keywords=self.min_keywords,
                max_keywords=self.max_keywords,
                max_target_apis=self.max_target_apis,
                output_format=output_format,
            )
        else:
            # State.B: Gap Analysis
            internal_context = self._format_internal_chunks(ctx.internal_chunks)
            user_prompt = get_prompt("m4_plan_generator", "user_state_b").format(
                query=ctx.query,
                internal_context=internal_context,
                covered_aspects=", ".join(ctx.covered_aspects) or "(无)",
                missing_aspects=", ".join(ctx.missing_aspects) or "(未明确)",
                available_apis=", ".join(self.available_apis),
                output_format=output_format,
            )

        result = self.llm.call_json(
            prompt=user_prompt,
            system_prompt=system_prompt,
            module="m4_planner",
        )

        # 兜底
        default_apis = self.config.get(
            "m5_external_retrieval.default_apis", ["星河图书馆"]
        )
        plan = ensure_default_plan(result or {}, ctx.query, default_apis)

        missing = validate_search_plan(plan)
        if missing:
            ctx.warnings.append(f"m4: 计划缺失字段，已兜底补全: {missing}")

        # 收敛 target_apis 到可用集合
        apis = plan["source_priority"].get("target_apis", [])
        apis = [a for a in apis if a in self.available_apis]
        if not apis:
            apis = default_apis
        plan["source_priority"]["target_apis"] = apis[: self.max_target_apis]

        ctx.search_plan = plan
        return ctx

    # ------------------------------------------------------------
    @staticmethod
    def _format_internal_chunks(
        chunks: List[Dict[str, Any]], max_chunks: int = 5, max_chars: int = 400
    ) -> str:
        if not chunks:
            return "(无内部信息)"
        parts = []
        for i, c in enumerate(chunks[:max_chunks], 1):
            content = (c.get("content") or "")[:max_chars]
            title = c.get("title", "")
            parts.append(f"[内部{i}] {title}\n  {content}")
        return "\n\n".join(parts)
