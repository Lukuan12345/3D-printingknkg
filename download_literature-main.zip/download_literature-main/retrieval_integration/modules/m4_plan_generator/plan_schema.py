#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
plan_schema.py —— 模块4 输出 JSON 的校验与默认补全
"""

from typing import Any, Dict, List


REQUIRED_PATHS = [
    ["query_rewrites", "core_entities"],
    ["query_rewrites", "boolean_query"],
    ["query_rewrites", "keywords_expand"],
    ["query_rewrites", "dual_track_queries", "strict_query"],
    ["query_rewrites", "dual_track_queries", "expansive_query"],
    ["source_priority", "target_apis"],
]


def _get(d: Dict, path: List[str]):
    node = d
    for k in path:
        if not isinstance(node, dict) or k not in node:
            return None
        node = node[k]
    return node


def validate_search_plan(plan: Dict[str, Any]) -> List[str]:
    """
    校验搜索计划完整性。
    Returns:
        缺失字段列表（空 = 通过）
    """
    missing = []
    for p in REQUIRED_PATHS:
        if _get(plan, p) is None:
            missing.append(".".join(p))
    return missing


def ensure_default_plan(
    plan: Dict[str, Any],
    query: str,
    default_apis: List[str],
) -> Dict[str, Any]:
    """
    若 plan 缺失关键字段，尝试用 query 兜底填充，避免外部检索完全失败。
    """
    if not plan:
        plan = {}

    qr = plan.setdefault("query_rewrites", {})
    qr.setdefault("core_entities", [])
    if not qr.get("boolean_query"):
        qr["boolean_query"] = f'"{query}"'
    qr.setdefault("keywords_expand", [])

    dt = qr.setdefault("dual_track_queries", {})
    dt.setdefault("strict_query", qr["boolean_query"])
    dt.setdefault("expansive_query", qr["boolean_query"])

    sp = plan.setdefault("source_priority", {})
    if not sp.get("target_apis"):
        sp["target_apis"] = list(default_apis)
    sp.setdefault("target_journals", [])

    return plan
