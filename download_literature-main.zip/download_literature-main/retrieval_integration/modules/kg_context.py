#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
kg_context.py —— 把 KG 推理路径渲染成 LLM prompt 片段

让 M3 / M6 / DirectAnswer 在 prompt 里看到 KG 推理的「逻辑骨架」，
配合 KB chunks 的「事实证据」共同生成答案。

设计：保持简短，避免吃掉太多 token：
- 顶部展示 KG summary + intent
- 列举 top-N 路径，每条带 1-2 篇支撑论文
"""
from typing import Any, Dict, List


def format_kg_context(
    kg_paths: List[Any],
    kg_summary: str = "",
    kg_intent: str = "",
    *,
    max_paths: int = 6,
    max_papers_per_path: int = 2,
) -> str:
    """
    渲染 KG 推理上下文供 LLM 使用。
    输入 kg_paths 可能是字符串列表（旧）或 dict 列表（带 support_papers，新）。
    """
    if not kg_paths and not kg_summary:
        return ""

    lines: List[str] = ["[知识图谱推理]"]
    if kg_intent:
        lines.append(f"意图: {kg_intent}")
    if kg_summary:
        s = kg_summary.strip()
        if len(s) > 400:
            s = s[:400] + "..."
        lines.append(f"摘要: {s}")
    lines.append("候选推理路径:")

    for i, p in enumerate(kg_paths[:max_paths], 1):
        if isinstance(p, dict):
            text = p.get("text", "")
            sps = p.get("support_papers", []) or []
            sp_strs = []
            for sp in sps[:max_papers_per_path]:
                t = (sp.get("title") or "").strip()
                if not t:
                    continue
                if len(t) > 70:
                    t = t[:70] + "..."
                yr = sp.get("year")
                sp_strs.append(f"《{t}》" + (f"({yr})" if yr else ""))
            if sp_strs:
                lines.append(f"  {i}. {text}")
                lines.append(f"     ↳ 支撑文献: {' | '.join(sp_strs)}")
            else:
                lines.append(f"  {i}. {text}")
        else:
            lines.append(f"  {i}. {p}")

    return "\n".join(lines)
