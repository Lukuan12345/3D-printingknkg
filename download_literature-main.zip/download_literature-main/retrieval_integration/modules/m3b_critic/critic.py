#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
m3b_critic/critic.py  —— Critic 反思模块

在 KG+KB 检索完成后、M6 生成答案前，用独立 LLM（默认 gemini）逐一核查
候选文献是否真正满足用户的约束条件。

功能：
1. 把 query 拆解为约束子项（sub-constraints）
2. 对每篇候选文献打分：满足哪些子约束 / 不满足哪些
3. 过滤掉完全不相关的文献
4. 若没有文献完全满足，给出排除法说明
5. 把结果写回 ctx，供 M6 生成更准确的答案

设计原则：
- 作为软过滤（soft filter），不强制删除文献，只是标注相关度
- 不影响 pipeline 其他模块的接口
- 失败时静默降级（不影响原有答案流程）
"""

import json
import logging
import time
from typing import Any, Dict, List, Optional

from ...core import BaseModule, RequestContext
from ...llm import LLMClient

logger = logging.getLogger(__name__)


_DECOMPOSE_SYSTEM = """You are a precise scientific literature evaluator.

Given a user query, extract the key hard constraints the target paper must satisfy.
Output JSON: {"constraints": ["constraint1", "constraint2", ...]}

Rules:
- Extract only HARD constraints (must-have, not nice-to-have)
- Keep each constraint short (< 15 words)
- Focus on: structure type, frequency/band, angle, polarization, performance metrics, material
- Maximum 6 constraints
- Use English
"""

_VERIFY_SYSTEM = """You are a precise scientific literature relevance evaluator.

Given a user query, a list of hard constraints, and a paper's title + abstract excerpt,
assess how well the paper satisfies each constraint.

Output JSON:
{
  "overall_score": <0.0-1.0>,
  "satisfied": ["constraint text", ...],
  "unsatisfied": ["constraint text", ...],
  "partial": ["constraint text", ...],
  "reason": "<one sentence explanation>"
}

Be strict: only mark a constraint as satisfied if the paper explicitly addresses it.
"""

_ELIMINATION_SYSTEM = """You are a scientific literature search assistant.

None of the retrieved papers fully satisfy all the user's constraints.
Based on the partial matches found, provide an elimination-based recommendation.

Output JSON:
{
  "elimination_summary": "<explanation of what was NOT found>",
  "best_partial_matches": [
    {"paper_title": "...", "satisfied_constraints": [...], "why_useful": "..."}
  ],
  "search_suggestions": ["<suggested search direction 1>", "<suggested direction 2>"]
}
"""

_BATCH_VERIFY_SYSTEM = """You are a precise scientific literature relevance evaluator.

Given a user query, hard constraints, and a list of papers (each with an index, title, and excerpt),
score ALL papers in ONE response.

Output JSON:
{
  "results": [
    {
      "index": 0,
      "overall_score": <0.0-1.0>,
      "satisfied": ["constraint text", ...],
      "unsatisfied": ["constraint text", ...],
      "reason": "<one sentence>"
    }
  ]
}

Be strict: only mark a constraint satisfied if the paper explicitly addresses it.
Include ALL papers in "results", in the same order.
"""


class RetrievalCritic(BaseModule):
    """Critic 反思模块：在 M3 之后、M6 之前执行。"""

    name = "m3b_critic"

    def __init__(self, config=None):
        super().__init__(config)
        self._llm: Optional[Any] = None
        cfg = self._module_cfg
        self.enabled = cfg.get("enabled", True)
        self.critic_model = cfg.get(
            "model",
            self.config.get("llm.models.critic", "gemini-3.1-pro-preview"),
        )
        self.min_papers = cfg.get("min_papers_to_run", 3)
        self.score_threshold = cfg.get("score_threshold", 0.35)

    def _llm_client(self):
        if self._llm is None:
            self._llm = LLMClient(self.config)
        return self._llm

    # ------------------------------------------------------------------
    def _run(self, ctx: RequestContext) -> RequestContext:
        return self.run(ctx)

    def run(self, ctx: RequestContext) -> RequestContext:
        if not self.enabled:
            return ctx

        papers = self._collect_papers(ctx)
        if len(papers) < self.min_papers:
            logger.info("[%s] critic: only %d papers, skip", ctx.request_id, len(papers))
            return ctx

        t0 = time.perf_counter()
        try:
            constraints = self._decompose_query(ctx.query)
            if not constraints:
                return ctx

            scored = self._verify_papers(ctx.query, constraints, papers)
            self._apply_results(ctx, constraints, scored)

            ctx.fine_timings["m3b_critic_ms"] = round((time.perf_counter() - t0) * 1000, 2)
            logger.info(
                "[%s] critic: %d papers scored, threshold=%.2f, kept=%d",
                ctx.request_id, len(scored),
                self.score_threshold,
                sum(1 for p in scored if p.get("critic_score", 0) >= self.score_threshold),
            )
        except Exception as e:  # noqa: BLE001
            logger.warning("[%s] critic failed (degraded): %s", ctx.request_id, e)
            ctx.warnings.append(f"critic: {e}")

        return ctx

    # ------------------------------------------------------------------
    def _decompose_query(self, query: str) -> List[str]:
        """用 LLM 把 query 拆解为硬约束列表。"""
        llm = self._llm_client()
        try:
            result = llm.call_json(
                prompt=query,
                module="m3b_critic",
                system_prompt=_DECOMPOSE_SYSTEM,
                model=self.critic_model,
            )
            constraints = result.get("constraints") or []
            logger.info("critic decomposed %d constraints: %s", len(constraints), constraints)
            return [str(c) for c in constraints[:6]]
        except Exception as e:  # noqa: BLE001
            logger.warning("critic decompose failed: %s", e)
            return []

    # ------------------------------------------------------------------
    def _verify_papers(
        self,
        query: str,
        constraints: List[str],
        papers: List[Dict[str, Any]],
    ) -> List[Dict[str, Any]]:
        """批量打分：把所有论文合并成一个 prompt，一次调用返回全部结果。"""
        llm = self._llm_client()
        constraint_block = "\n".join(f"- {c}" for c in constraints)

        # 限制每批最多 10 篇，避免 prompt 超长
        batch_size = 10
        all_scored = []

        for batch_start in range(0, len(papers), batch_size):
            batch = papers[batch_start:batch_start + batch_size]

            papers_block = ""
            for i, p in enumerate(batch):
                title = p.get("title", "") or ""
                snippet = (p.get("content", "") or p.get("abstract", "") or "")[:300]
                papers_block += f"\n[{i}] Title: {title}\n    Excerpt: {snippet}\n"

            prompt = (
                f"User query:\n{query}\n\n"
                f"Hard constraints:\n{constraint_block}\n\n"
                f"Papers to evaluate:{papers_block}"
            )

            try:
                result = llm.call_json(
                    prompt=prompt,
                    module="m3b_critic",
                    system_prompt=_BATCH_VERIFY_SYSTEM,
                    model=self.critic_model,
                )
                results_list = (result or {}).get("results") or []
                idx_map = {r.get("index"): r for r in results_list}
            except Exception as e:  # noqa: BLE001
                logger.warning("critic batch verify failed: %s", e)
                idx_map = {}

            for i, paper in enumerate(batch):
                r = idx_map.get(i) or {}
                p = dict(paper)
                p["critic_score"] = float(r.get("overall_score") or 0.0)
                p["critic_satisfied"] = r.get("satisfied") or []
                p["critic_unsatisfied"] = r.get("unsatisfied") or []
                p["critic_reason"] = r.get("reason") or ""
                all_scored.append(p)

        all_scored.sort(key=lambda p: p.get("critic_score", 0.0), reverse=True)
        return all_scored

    # ------------------------------------------------------------------
    def _apply_results(
        self,
        ctx: RequestContext,
        constraints: List[str],
        scored: List[Dict[str, Any]],
    ) -> None:
        """把 critic 结果写回 ctx。"""
        ctx.critic_constraints = constraints  # type: ignore[attr-defined]
        ctx.critic_scored_papers = scored  # type: ignore[attr-defined]

        # 判断是否需要 elimination 模式
        high_score = [p for p in scored if p.get("critic_score", 0) >= self.score_threshold]
        if not high_score:
            ctx.critic_elimination_mode = True  # type: ignore[attr-defined]
            ctx.warnings.append(
                f"critic: 没有文献得分 >= {self.score_threshold}，将启用排除法说明"
            )
            self._build_elimination_note(ctx, constraints, scored)
        else:
            ctx.critic_elimination_mode = False  # type: ignore[attr-defined]

        # 重排 internal_chunks：把 critic_score 高的 paper 对应的 chunks 提前
        self._rerank_chunks_by_critic(ctx, scored)

    # ------------------------------------------------------------------
    def _build_elimination_note(
        self,
        ctx: RequestContext,
        constraints: List[str],
        scored: List[Dict[str, Any]],
    ) -> None:
        """生成排除法说明，附加到 ctx.warnings。"""
        llm = self._llm_client()
        summary_items = []
        for p in scored[:5]:
            summary_items.append({
                "paper_title": p.get("title", "")[:80],
                "satisfied_constraints": p.get("critic_satisfied", []),
                "unsatisfied_constraints": p.get("critic_unsatisfied", []),
            })

        prompt = (
            f"User query:\n{ctx.query}\n\n"
            f"Constraints:\n" + "\n".join(f"- {c}" for c in constraints) + "\n\n"
            f"Partial matches:\n{json.dumps(summary_items, ensure_ascii=False)}"
        )

        try:
            result = llm.call_json(
                prompt=prompt,
                module="m3b_critic",
                system_prompt=_ELIMINATION_SYSTEM,
                model=self.critic_model,
            )
            ctx.critic_elimination_note = result  # type: ignore[attr-defined]
        except Exception as e:  # noqa: BLE001
            logger.warning("critic elimination note failed: %s", e)
            ctx.critic_elimination_note = {}  # type: ignore[attr-defined]

    # ------------------------------------------------------------------
    def _rerank_chunks_by_critic(
        self,
        ctx: RequestContext,
        scored: List[Dict[str, Any]],
    ) -> None:
        """按 critic_score 重新排列 internal_chunks，让高分论文的 chunks 靠前。"""
        if not ctx.internal_chunks:
            return

        paper_score: Dict[str, float] = {}
        for p in scored:
            pid = p.get("paper_id") or p.get("paper_uid") or ""
            if pid:
                paper_score[pid] = float(p.get("critic_score", 0.0))

        def sort_key(chunk):
            pid = chunk.get("paper_id", "")
            critic = paper_score.get(pid, 0.0)
            fused = float(chunk.get("fused_score", 0.0))
            # 综合分：critic 权重 0.4 + fused 权重 0.6
            return critic * 0.4 + fused * 0.6

        ctx.internal_chunks = sorted(ctx.internal_chunks, key=sort_key, reverse=True)

    # ------------------------------------------------------------------
    @staticmethod
    def _collect_papers(ctx: RequestContext) -> List[Dict[str, Any]]:
        """从 internal_chunks 和 evidence_papers 聚合去重的论文列表（最多 15 篇）。"""
        seen: set = set()
        papers: List[Dict[str, Any]] = []

        # KB chunks 已按 fused_score 降序 → 直接取前几篇去重即可拿到最相关论文
        for chunk in ctx.internal_chunks or []:
            pid = chunk.get("paper_id", "")
            if pid and pid not in seen:
                seen.add(pid)
                papers.append({
                    "paper_id": pid,
                    "title": chunk.get("title", ""),
                    "content": chunk.get("content", ""),
                    "fused_score": chunk.get("fused_score", 0.0),
                })
            if len(papers) >= 15:   # 最多 15 篇，避免 prompt 过长
                break

        # 从 evidence_papers 补充 title
        for ep in ctx.evidence_papers or []:
            pid = ep.get("paper_uid") or ep.get("paper_id") or ""
            if pid and pid not in seen:
                seen.add(pid)
                papers.append({
                    "paper_id": pid,
                    "title": ep.get("title", ""),
                    "content": "",
                    "fused_score": 0.0,
                })
            elif pid in seen:
                # 补全 title
                for p in papers:
                    if p["paper_id"] == pid and not p.get("title"):
                        p["title"] = ep.get("title", "")
                        break

        return papers
