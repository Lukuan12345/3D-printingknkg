from .critic import RetrievalCritic

__all__ = ["RetrievalCritic"]
