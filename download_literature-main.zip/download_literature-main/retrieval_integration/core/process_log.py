#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
process_log.py —— 检索流水线的过程文件记录器（需求 #2）

每次 query 在 packages/retrieval/runs/{request_id}/ 下落盘：
  00_query.txt              原始 query
  01_m1_schema_parse.json   M1 命中字段 / parse_confidence
  02_keypoints.log          M2 阶段：kb_mvp QueryStructurizer 抽出的核心实体、关键词
  03_kg_paths.log           M2 阶段：KG 候选 reasoning paths（PPR top / beam search）
  04_kb_chunks.json         M2 阶段：top-K chunks + 三路分数
  05_m3_validate.json       覆盖度 / missing_aspects
  06_m4_plan.json           检索计划（若有）
  07_m5_external.json       外部 API 检索结果（若有）
  08_m6_response.json       最终回答 JSON
  pipeline.log              全流程文本日志（每模块开始/结束时间）

调用方式：在每个模块的 _run 内显式 log_*；模块不关心目录结构，
ProcessLogger 自身负责文件名与目录创建。
"""

from __future__ import annotations

import json
import logging
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger(__name__)


class ProcessLogger:
    """单次 query 的过程文件记录器。"""

    STAGE_FILENAMES = {
        "query":         "00_query.txt",
        "m1":            "01_m1_schema_parse.json",
        "keypoints":     "02_keypoints.log",
        "kg_paths":      "03_kg_paths.log",
        "kb_chunks":     "04_kb_chunks.json",
        "m3":            "05_m3_validate.json",
        "m4":            "06_m4_plan.json",
        "m5":            "07_m5_external.json",
        "m6":            "08_m6_response.json",
        "final_answer":  "09_final_answer.txt",
        "summary":       "10_summary.txt",
    }

    def __init__(self, run_root: Path, request_id: str):
        self.run_root = Path(run_root)
        self.request_id = request_id
        self.dir = self.run_root / request_id
        self.dir.mkdir(parents=True, exist_ok=True)
        self.pipeline_log = self.dir / "pipeline.log"
        self._start = time.time()
        self._info(f"== run start {datetime.now().isoformat()} request_id={request_id} ==")

    # ------------------------------------------------------------
    def _info(self, line: str) -> None:
        try:
            with open(self.pipeline_log, "a", encoding="utf-8") as f:
                f.write(line.rstrip() + "\n")
        except OSError as e:
            logger.warning("ProcessLogger: failed to append pipeline.log: %s", e)

    # ------------------------------------------------------------
    def log_text(self, stage: str, text: str) -> None:
        fname = self.STAGE_FILENAMES.get(stage, f"{stage}.log")
        path = self.dir / fname
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(text if text is not None else "")
            self._info(f"[stage:{stage}] wrote {fname} ({len(text or '')} chars)")
        except OSError as e:
            logger.warning("ProcessLogger.log_text(%s) failed: %s", stage, e)

    def log_json(self, stage: str, obj: Any) -> None:
        fname = self.STAGE_FILENAMES.get(stage, f"{stage}.json")
        path = self.dir / fname
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(obj, f, ensure_ascii=False, indent=2, default=_json_default)
            self._info(f"[stage:{stage}] wrote {fname}")
        except (OSError, TypeError, ValueError) as e:
            logger.warning("ProcessLogger.log_json(%s) failed: %s", stage, e)

    # ------------------------------------------------------------
    def log_module_start(self, module: str) -> None:
        self._info(f"[{_ts(self._start)}] >> {module} start")

    def log_module_end(self, module: str, ok: bool = True, extra: Optional[str] = None) -> None:
        tag = "ok" if ok else "ERR"
        suffix = f" {extra}" if extra else ""
        self._info(f"[{_ts(self._start)}] << {module} {tag}{suffix}")

    def warn(self, msg: str) -> None:
        self._info(f"[warn] {msg}")

    def finalize(self) -> None:
        self._info(f"== run end {datetime.now().isoformat()} total={_ts(self._start)} ==")


# ============================================================
# helpers
# ============================================================

def _ts(start: float) -> str:
    return f"+{(time.time() - start):.2f}s"


def _json_default(obj: Any):
    if isinstance(obj, Path):
        return str(obj)
    if hasattr(obj, "isoformat"):
        return obj.isoformat()
    try:
        from enum import Enum
        if isinstance(obj, Enum):
            return obj.value
    except ImportError:
        pass
    return str(obj)
