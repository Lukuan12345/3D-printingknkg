"""retrieval_integration 核心编排层。

注意：`RetrievalPipeline` 不在此处 eager 导出，避免循环导入：
  pipeline.py 需要导入 modules.m1_schema_parser，
  而 modules.m1_schema_parser 通过 BaseModule 反过来导入 core。
请用：`from retrieval_integration.core.pipeline import RetrievalPipeline`
"""

from .state import State, ExitReason
from .context import RequestContext
from .base_module import BaseModule

__all__ = [
    "State",
    "ExitReason",
    "RequestContext",
    "BaseModule",
]
