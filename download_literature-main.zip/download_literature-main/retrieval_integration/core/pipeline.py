#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
pipeline.py —— 主编排器（v2 重构版）

新增双通道：
- channel="fast"  (legacy 短路径): M1 → M2 (并行 KB) → M3 → DirectAnswer
- channel="deep"  (KG-first):       M1 → KG 推演 → S3 衔接 → KB(白名单) → S5 反向归并 → S6
- channel="auto"  按 query 复杂度自动决定（见 _choose_channel）

v2 §6.1 决策：保留 LLM 主路径（M1），S0/S1 留待 fallback（TODO-4）。
"""

import logging
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from ..config import Config, get_config
from ..monitoring import setup_logging, log_request
from ..core.context import RequestContext
from ..core.state import State, ExitReason
from ..core.process_log import ProcessLogger

# 阶段 2 模块
from ..modules.m1_schema_parser import SchemaParser
from ..modules.m2_internal_retrieval import InternalRetriever
from ..modules.m3_answer_validator import AnswerValidator
from ..modules.direct_answer import DirectAnswerGenerator
from ..modules.m3b_critic import RetrievalCritic

# 阶段 3 模块
from ..modules.m4_plan_generator import RetrievalPlanner
from ..modules.m5_external_retrieval import ExternalRetriever
from ..modules.m6_answer_generator import FinalAnswerGenerator

# v2 新阶段
from ..stages import (
    build_kb_hints_from_kg,
    render_chains_block, render_chunks_block, render_supplementary_block,
)

logger = logging.getLogger(__name__)


def _ms(start: float) -> float:
    return round((time.perf_counter() - start) * 1000, 2)


class RetrievalPipeline:
    """
    主编排器。

    用法:
        pipeline = RetrievalPipeline()
        result = pipeline.run("Rasorber 高透波宽角域 设计方法", channel="deep")
        print(result["llm_answer"])
    """

    def __init__(self, config: Optional[Config] = None):
        self.config = config or get_config()
        setup_logging()

        # 阈值
        self.t1 = self.config.get("pipeline.thresholds.m1_parse_confidence", 0.6)
        self.t2 = self.config.get("pipeline.thresholds.m2_retrieval_confidence", 0.55)
        self.t2_deep = self.config.get("pipeline.thresholds.m2_retrieval_confidence_deep", 0.40)
        self.t3 = self.config.get("pipeline.thresholds.m3_answer_confidence", 0.7)

        # 通道
        self.default_channel = self.config.get("pipeline.channel", "auto")
        chan_cfg = self.config.get("pipeline.channels", {}) or {}
        self.auto_route_cfg = chan_cfg.get("auto_route", {}) or {}

        # layered 子配置
        self.layered_cfg = self.config.get("pipeline.layered", {}) or {}
        self.s3_cfg = self.layered_cfg.get("s3", {}) or {}

        # 模块实例化
        self.m1 = SchemaParser(self.config)
        self.m2 = InternalRetriever(self.config)
        self.m3 = AnswerValidator(self.config)
        self.direct = DirectAnswerGenerator(self.config)
        self.m3b = RetrievalCritic(self.config)

        self._m4 = RetrievalPlanner(self.config)
        self._m5 = ExternalRetriever(self.config)
        self._m6 = FinalAnswerGenerator(self.config)

    # ------------------------------------------------------------
    def register_external_modules(self, m4=None, m5=None, m6=None) -> None:
        if m4 is not None: self._m4 = m4
        if m5 is not None: self._m5 = m5
        if m6 is not None: self._m6 = m6

    # ------------------------------------------------------------
    def run(self, query: str, log: bool = True,
            channel: Optional[str] = None) -> Dict[str, Any]:
        """
        Args:
            channel: "fast" | "deep" | "auto" | None
                     None 时用 config.pipeline.channel (默认 "auto")
        """
        ctx = RequestContext(query=query)

        # 过程日志
        run_root = self.config.resolve_path(
            self.config.get("monitoring.log_dir", "packages/retrieval/runs/")
        )
        plog = ProcessLogger(run_root, ctx.request_id)
        ctx.process_log_dir = str(plog.dir)
        ctx._process_logger = plog  # type: ignore[attr-defined]
        plog.log_text("query", query)

        # 决定通道
        requested = channel or self.default_channel
        logger.info(f"[{ctx.request_id}] Pipeline start: query='{query[:60]}' channel={requested}")

        try:
            self._run_pipeline(ctx, requested_channel=requested)
        except Exception as e:
            logger.exception(f"Pipeline error: {e}")
            ctx.error = str(e)
            ctx.exit_reason = ExitReason.ERROR
            plog.warn(f"pipeline_error: {e}")

        # references 里的论文全来自 KB，把 evidence_papers 里已下载的 pdf 路径写回去
        self._enrich_references_pdf_paths(ctx)

        try:
            response = ctx.to_response()
            plog.log_json("m6", response)
        except Exception as e:  # noqa: BLE001
            plog.warn(f"m6 log_json failed: {e}")
            response = None

        # 09_final_answer.txt —— 纯文本回答，专家直接读
        try:
            plog.log_text("final_answer", ctx.final_answer or "")
        except Exception as e:  # noqa: BLE001
            plog.warn(f"final_answer log failed: {e}")

        # 10_summary.txt —— 人类可读的全 return 摘要（不省略）
        try:
            plog.log_text("summary", _format_human_summary(ctx, response))
        except Exception as e:  # noqa: BLE001
            plog.warn(f"summary log failed: {e}")

        plog.finalize()

        if log:
            try:
                log_request(ctx.to_dict())
            except Exception as e:
                logger.warning(f"日志写入失败: {e}")

        return ctx.to_response()

    # ============================================================
    # 通道选择
    # ============================================================
    def _choose_channel(self, ctx: RequestContext) -> str:
        """auto 模式按复杂度决定 fast / deep（v2 §8.2）。"""
        q = ctx.query or ""
        # 显式指令优先
        if q.startswith("/deep"):
            ctx.query = q[len("/deep"):].strip()
            return "deep"
        if q.startswith("/fast"):
            ctx.query = q[len("/fast"):].strip()
            return "fast"

        ql_thresh = int(self.auto_route_cfg.get("query_len_threshold", 30))
        schema_thresh = int(self.auto_route_cfg.get("schema_hits_threshold", 1))

        if len(q) > ql_thresh:
            return "deep"
        if len(ctx.matched_schema_fields or []) >= schema_thresh:
            return "deep"
        # 机理 / 对比 / 演进类关键词
        deep_kws = ("对比", "演进", "为什么", "如何", "机理", "原理")
        if any(kw in q for kw in deep_kws):
            return "deep"
        return "fast"

    # ============================================================
    # 主流程
    # ============================================================
    def _run_pipeline(self, ctx: RequestContext,
                      requested_channel: str = "auto") -> None:
        plog = getattr(ctx, "_process_logger", None)

        # --- 模块 1（共用入口）---
        ctx = self.m1.run(ctx)
        if plog:
            plog.log_json("m1", {
                "parse_confidence": ctx.parse_confidence,
                "matched_schema_fields": ctx.matched_schema_fields,
                "m1_reason": ctx.m1_reason,
            })

        if ctx.parse_confidence < self.t1:
            # parse_conf 过低：尝试 LLM 拆解/简化 query 后重试一次
            simplified = self._try_simplify_query(ctx)
            if simplified and simplified != ctx.query:
                logger.info(f"[{ctx.request_id}] M1 miss → LLM query simplify → retry")
                ctx.query = simplified
                ctx = self.m1.run(ctx)
                if plog:
                    plog.log_json("m1_retry", {
                        "simplified_query": simplified,
                        "parse_confidence": ctx.parse_confidence,
                        "matched_schema_fields": ctx.matched_schema_fields,
                    })

            # 仍然不达标，走外部路径
            if ctx.parse_confidence < self.t1:
                ctx.state = State.A
                ctx.exit_reason = ExitReason.SCHEMA_MISS
                logger.info(f"[{ctx.request_id}] M1 miss → external")
                return self._go_external(ctx)

        # --- 通道分流 ---
        if requested_channel == "auto":
            chan = self._choose_channel(ctx)
        else:
            chan = requested_channel
        ctx.channel = chan
        logger.info(f"[{ctx.request_id}] channel resolved → {chan}")

        if chan == "fast":
            return self._run_fast(ctx)
        # chan == "deep" / "legacy" 走 KG-first 版本
        return self._run_deep(ctx)

    # ============================================================
    # Fast 通道（保留旧 DirectAnswer 路径，不走 KG）
    # ============================================================
    def _run_fast(self, ctx: RequestContext) -> None:
        """v2 §8.4：fast 不走 KG，仅 KB 三路融合 + DirectAnswer。"""
        plog = getattr(ctx, "_process_logger", None)

        # M2 但跳过 KG（临时关 enable_kg_path）
        prev_enable_kg = getattr(self.m2, "enable_kg_path", True)
        self.m2.enable_kg_path = False
        try:
            ctx = self.m2.run(ctx)
        finally:
            self.m2.enable_kg_path = prev_enable_kg

        if ctx.retrieval_confidence < self.t2:
            ctx.state = State.A
            ctx.exit_reason = ExitReason.RETRIEVAL_MISS
            logger.info(f"[{ctx.request_id}] fast M2 miss → external")
            return self._go_external(ctx)

        ctx = self.m3.run(ctx)
        if plog:
            plog.log_json("m3", {
                "answer_confidence": ctx.answer_confidence,
                "covered_aspects": ctx.covered_aspects,
                "missing_aspects": ctx.missing_aspects,
            })
        if ctx.answer_confidence >= self.t3:
            ctx.state = State.DIRECT
            ctx.exit_reason = ExitReason.DIRECT_ANSWER
            ctx = self.direct.run(ctx)
        else:
            ctx.state = State.B
            ctx.exit_reason = ExitReason.ANSWER_INSUFFICIENT
            logger.info(f"[{ctx.request_id}] fast M3 insufficient → external")
            return self._go_external(ctx)

    # ============================================================
    # Deep 通道（KG 先 + KB 后 + S5 反向归并 + S6 v2 prompt）
    # ============================================================
    def _run_deep(self, ctx: RequestContext) -> None:
        plog = getattr(ctx, "_process_logger", None)

        # ----- Step A: 让 M2 仅跑 KG（不跑 KB），拿到 KG 推演结果 -----
        # 复用 M2 InternalRetriever 内部的 _kg_search 等方法
        t = time.perf_counter()
        ctx = self._run_deep_kg_only(ctx)
        ctx.fine_timings["deep.kg_only_ms"] = _ms(t)
        if plog:
            plog.log_json("kg_paths", {
                "kg_reasoning_paths": ctx.kg_reasoning_paths,
                "kg_evidence": ctx.kg_evidence,
                "kg_intent": ctx.kg_intent,
                "kg_summary": ctx.kg_summary,
            })

        # ----- Step B: S3 BridgeKGtoKB —— 把 KG 节点转成 KB 白名单 -----
        t = time.perf_counter()
        hints = self._run_s3_bridge(ctx)
        ctx.fine_timings["deep.s3_bridge_ms"] = _ms(t)
        ctx.kb_hints = {
            "chunk_id_whitelist_size": len(hints.chunk_id_whitelist),
            "chunk_type_filter": list(hints.chunk_type_filter),
            "anchor_papers_top10": hints.anchor_papers[:10],
            "boost_keywords": hints.boost_keywords,
            "debug": hints.debug,
        }
        if plog:
            plog.log_json("kb_hints", ctx.kb_hints)

        # ----- Step C: S4 KBRetrieve —— 在白名单内跑三路融合 -----
        t = time.perf_counter()
        ctx = self._run_deep_kb_retrieve(ctx, hints)
        ctx.fine_timings["deep.s4_kb_search_ms"] = _ms(t)
        if plog:
            plog.log_json("kb_chunks", {
                "top_k": ctx.internal_chunks,
                "retrieval_confidence": ctx.retrieval_confidence,
            })

        # ----- Step D: S5 MatchKGKB —— chunks 反向归并到 chain + 不一致诊断 -----
        # （即便 retr_conf 不达标，也跑 S5：这正是诊断 chain↔chunks 不一致的最佳点）
        t = time.perf_counter()
        matched = self._run_s5_match(ctx)
        ctx.fine_timings["deep.s5_match_ms"] = _ms(t)
        ctx.matched_frame = matched.to_dict()
        ctx.inconsistencies = [i.to_dict() for i in matched.inconsistencies]
        if plog:
            plog.log_json("matched_frame", ctx.matched_frame)

        # ── KG 信号混入 retrieval_confidence ──────────────────────────────────
        # Deep 模式的 raw retr_conf 基于 KG whitelist chunks 的 fused_score 均值，
        # 天然比 fast 模式（含 title_boost +0.3~0.6）低。
        # 用 kg_confidence（KG 推演质量）+ chain_chunk_ratio（chain↔KB 覆盖率）
        # 修正这个偏差，使 deep 置信度真实反映两路证据的综合质量。
        chain_chunk_ratio = (matched.stats or {}).get("chain_chunk_ratio", 0.0) or 0.0
        raw_retr_conf = ctx.retrieval_confidence
        from ..modules.confidence_scorer import blend_kg_into_retrieval_confidence
        blended = blend_kg_into_retrieval_confidence(
            raw_retr_conf=raw_retr_conf,
            kg_confidence=ctx.kg_confidence or 0.0,
            chain_chunk_ratio=chain_chunk_ratio,
        )
        logger.info(
            f"[{ctx.request_id}] deep retr_conf: raw={raw_retr_conf:.3f} + "
            f"kg={ctx.kg_confidence:.3f} + chain_ratio={chain_chunk_ratio:.2f} "
            f"→ blended={blended:.3f}"
        )
        ctx.retrieval_confidence = blended
        ctx.fine_timings["deep.retr_conf_raw"] = raw_retr_conf
        ctx.fine_timings["deep.retr_conf_blended"] = blended
        # ──────────────────────────────────────────────────────────────────────

        if ctx.retrieval_confidence < self.t2_deep:
            ctx.state = State.A
            ctx.exit_reason = ExitReason.RETRIEVAL_MISS
            logger.info(
                f"[{ctx.request_id}] deep M2 miss "
                f"(retr_conf={ctx.retrieval_confidence:.3f} < t2_deep={self.t2_deep}) → external"
            )
            return self._go_external(ctx)

        # ----- Step E: M3 验证（沿用旧逻辑，让 LLM 评 coverage）-----
        ctx = self.m3.run(ctx)
        if plog:
            plog.log_json("m3", {
                "answer_confidence": ctx.answer_confidence,
                "covered_aspects": ctx.covered_aspects,
                "missing_aspects": ctx.missing_aspects,
            })

        # ----- Step E2: M3b Critic 反思（子约束验证 + 文献重排）-----
        t = time.perf_counter()
        ctx = self.m3b.run(ctx)
        ctx.fine_timings["deep.critic_ms"] = _ms(t)
        if plog:
            plog.log_json("m3b_critic", {
                "constraints": getattr(ctx, "critic_constraints", []),
                "elimination_mode": getattr(ctx, "critic_elimination_mode", False),
                "scored_count": len(getattr(ctx, "critic_scored_papers", [])),
            })

        if ctx.answer_confidence >= self.t3:
            ctx.state = State.DIRECT
            ctx.exit_reason = ExitReason.DIRECT_ANSWER
            # ----- Step F: S6 v2 用按 chain 组织的 prompt 出答 -----
            t = time.perf_counter()
            self._run_s6_v2(ctx, matched)
            ctx.fine_timings["deep.s6_v2_ms"] = _ms(t)
        else:
            ctx.state = State.B
            ctx.exit_reason = ExitReason.ANSWER_INSUFFICIENT
            logger.info(f"[{ctx.request_id}] deep M3 insufficient → external")
            return self._go_external(ctx)

    # ============================================================
    # Deep 子步骤实现
    # ============================================================
    def _run_deep_kg_only(self, ctx: RequestContext) -> RequestContext:
        """仅跑 KG 推演，不动 KB（复用 InternalRetriever 的 KG 子流程）。"""
        # 暂停 KB 路：把 adapter 当成传 None
        # 直接调 m2 的 _kg_search 接口
        kg_result = self.m2._kg_search(ctx.query)
        ctx.kg_reasoning_paths = kg_result.get("reasoning_paths", []) or []
        ctx.kg_evidence = kg_result.get("evidence", []) or []
        ctx.kg_retrieval_plan = kg_result.get("retrieval_plan", {}) or {}
        ctx.kg_summary = kg_result.get("summary", "") or ""
        ctx.kg_intent = kg_result.get("intent")
        ctx.kg_confidence = float(kg_result.get("confidence", 0.0) or 0.0)
        kg_timing = kg_result.get("timing") or {}
        for k, v in kg_timing.items():
            ctx.fine_timings[f"deep.kg_{k}"] = v
        if kg_result.get("error"):
            ctx.warnings.append(f"deep/kg: {kg_result['error']}")
        return ctx

    def _run_s3_bridge(self, ctx: RequestContext):
        """S3：从 KG paths 提取 node_ids，调 bridge.build_kb_hints_from_kg。"""
        anchor_ids: List[int] = []
        expanded_ids: List[int] = []
        for p in (ctx.kg_reasoning_paths or []):
            nodes = p.get("nodes", []) if isinstance(p, dict) else []
            for n in nodes:
                nid = n.get("node_id") if isinstance(n, dict) else None
                if nid is not None:
                    expanded_ids.append(nid)
        # 简化：把第一条 path 的 nodes 视作 anchor（更强权）
        if ctx.kg_reasoning_paths and isinstance(ctx.kg_reasoning_paths[0], dict):
            first_nodes = ctx.kg_reasoning_paths[0].get("nodes", [])
            anchor_ids = [n.get("node_id") for n in first_nodes if n.get("node_id")]

        # M1 命中的 schema 字段（影响 chunk_type_filter）
        entry_fields = list(ctx.matched_schema_fields or [])

        # KG db 路径
        kg_db = self.m2.kg_db_path

        return build_kb_hints_from_kg(
            db_path=kg_db,
            anchor_node_ids=list(set(anchor_ids)),
            expanded_node_ids=list(set(expanded_ids) - set(anchor_ids)),
            entry_field_names=entry_fields,
            total_budget=self.s3_cfg.get("total_budget", 200),
            whitelist_min=self.s3_cfg.get("whitelist_min", 50),
            whitelist_max=self.s3_cfg.get("whitelist_max", 500),
            softmax_temperature=float(self.s3_cfg.get("softmax_temperature", 1.0)),
            per_node_cap=int(self.s3_cfg.get("per_node_cap", 30)),
            boost_keyword_top_k=int(self.s3_cfg.get("boost_keyword_top_k", 12)),
            fetch_pool_per_node=int(self.s3_cfg.get("fetch_pool_per_node", 60)),
        )

    def _run_deep_kb_retrieve(self, ctx: RequestContext, hints) -> RequestContext:
        """S4: 在白名单内跑 kb_mvp.HybridSearcher。"""
        # 直接用 M2.adapter.search 但传 chunk_id_whitelist
        adapter = self.m2.adapter
        # TODO-NEW-3: 复用 M1/KG 阶段已结构化的 query，不重复调 LLM
        structured = ctx.structured_query
        if structured is None:
            t_struct = time.perf_counter()
            try:
                structured = adapter.structurize_query(ctx.query)
                ctx.structured_query = structured
            except Exception as e:
                logger.warning(f"deep structurize failed: {e}")
            ctx.fine_timings["deep.s4_structurize_ms"] = _ms(t_struct)
        else:
            ctx.fine_timings["deep.s4_structurize_ms"] = 0.0  # 复用

        # query_text：用 keyword-rich 拼接（M2 InternalRetriever 静态方法）
        t_qbuild = time.perf_counter()
        from ..modules.m2_internal_retrieval.retriever import InternalRetriever as _IR
        query_text = ctx.query
        if structured:
            query_text = _IR._build_keyword_rich_query(ctx.query, structured)
        # 把 boost_keywords 也拼进去
        if hints.boost_keywords:
            query_text = query_text + " " + " ".join(hints.boost_keywords)
        ctx.fine_timings["deep.s4_query_build_ms"] = _ms(t_qbuild)

        # 调 searcher.search 传 whitelist
        t_ensure = time.perf_counter()
        adapter._ensure_searcher()
        searcher = adapter._searcher
        ctx.fine_timings["deep.s4_searcher_load_ms"] = _ms(t_ensure)

        # paper_id → anchor_score
        # 注意: KG.paper_id 是 sha1 paper_uid，KB demo 是 P001-P101，
        # 直接传可能命中率为 0。用 title 做桥接：把 KG paper title 转成 KB paper_id。
        t_anchor = time.perf_counter()
        anchor_papers_map = dict(hints.anchor_papers)
        anchor_papers_map = self._translate_anchor_to_kb_pids(
            adapter, anchor_papers_map,
        )
        w_kg_anchor = float(self.s3_cfg.get("w_kg_anchor", 0.15))
        ctx.fine_timings["deep.s4_anchor_translate_ms"] = _ms(t_anchor)

        # ─── chunk_id 跨库桥接 ───
        # KG.chunk_id = "{paper_uid}::{field_type}"
        # KB.chunk_id = "{kb_paper_id}_{field_type}"
        # TODO-NEW-5: 桥表缓存到 ctx，避免 S4/S5 各算一次
        t_bridge = time.perf_counter()
        whitelist = hints.chunk_id_whitelist or set()
        kg_to_kb = self._get_or_build_kg_kb_map(ctx, adapter)
        bridged_whitelist = self._bridge_chunk_ids(
            whitelist, kg_to_kb_pid=kg_to_kb,
        )
        ctx.fine_timings["deep.s4_chunk_bridge_ms"] = _ms(t_bridge)
        if bridged_whitelist != whitelist:
            logger.info(
                "Chunk-id bridge: %d KG-style → %d KB-style chunks",
                len(whitelist), len(bridged_whitelist),
            )
            ctx.kb_hints["chunk_id_bridged_size"] = len(bridged_whitelist)

        t_search = time.perf_counter()
        result = searcher.search(
            query=query_text,
            query_json=structured,
            top_k=self.m2.top_k,
            top_k_each=self.m2.top_k_each,
            chunk_id_whitelist=bridged_whitelist or None,
            chunk_type_filter=hints.chunk_type_filter or None,
            kg_anchor_papers=anchor_papers_map or None,
            w_kg_anchor=w_kg_anchor,
        )
        ctx.fine_timings["deep.s4_hybrid_search_ms"] = _ms(t_search)
        chunks = result.get("top_k", []) or []
        ctx.internal_chunks = chunks

        # confidence
        from ..modules.m2_internal_retrieval.confidence import compute_retrieval_confidence
        ctx.retrieval_confidence = compute_retrieval_confidence(
            chunks, strategy=self.m2.confidence_strategy
        )
        # 同步更新 evidence_papers
        t_evid = time.perf_counter()
        try:
            resolver = self.m2._ensure_resolver()
            paper_ids = [c.get("paper_id") for c in chunks if c.get("paper_id")]
            paper_ids += [pid for pid, _ in hints.anchor_papers[:30]]
            resolved = resolver.resolve(list(set(paper_ids)))
            # title fallback
            unresolved_titles = []
            seen = set()
            for c in chunks:
                pid = c.get("paper_id")
                if pid and pid not in resolved:
                    title_str = (c.get("title") or "").strip()
                    if title_str and title_str not in seen:
                        unresolved_titles.append(title_str)
                        seen.add(title_str)
            if unresolved_titles:
                title_resolved = resolver.resolve_by_titles(unresolved_titles)
                for _ttl, info in title_resolved.items():
                    resolved[info["paper_uid"]] = info
            ctx.evidence_papers = list(resolved.values())
        except Exception as e:
            logger.warning(f"deep evidence_resolver failed: {e}")
        ctx.fine_timings["deep.s4_evidence_resolve_ms"] = _ms(t_evid)

        # KB PDF 下载（deep channel 里 evidence_papers 在此处才填充完毕）
        if self.m2._module_cfg.get("kb_pdf_download", {}).get("enabled", False):
            try:
                self.m2._download_kb_pdfs(ctx)
            except Exception as e:  # noqa: BLE001
                logger.warning(f"KB PDF download failed: {e}")
                ctx.warnings.append(f"m2/kb_pdf: {e}")

        return ctx

    def _get_or_build_kg_kb_map(self, ctx: RequestContext, adapter) -> Dict[str, str]:
        """TODO-NEW-5: 缓存 KG.paper_uid → KB.paper_id 桥表到 ctx，避免重复构造。"""
        cached = getattr(ctx, "_kg_kb_pid_map", None)
        if cached is not None:
            return cached
        m = self._kg_to_kb_pid_map(adapter)
        try:
            ctx._kg_kb_pid_map = m  # type: ignore[attr-defined]
        except Exception:
            pass
        return m

    def _kg_to_kb_pid_map(self, adapter) -> Dict[str, str]:
        """构造 KG.paper_uid → KB.paper_id 的桥接表（通过 title）。"""
        try:
            kb_pairs = adapter.get_papers_titles()  # [(kb_pid, title)]
        except Exception:
            return {}
        title_to_kb = {(t or "").strip().lower(): p for p, t in kb_pairs if t}

        kg_adapter = self.m2.kg_adapter
        if kg_adapter is None or kg_adapter._con is None:
            return {}
        rows = kg_adapter._con.execute(
            "SELECT paper_id, paper_title FROM paper WHERE paper_title IS NOT NULL"
        ).fetchall()
        mapping: Dict[str, str] = {}
        for r in rows:
            t = (r["paper_title"] or "").strip().lower()
            if t and t in title_to_kb:
                mapping[r["paper_id"]] = title_to_kb[t]
        return mapping

    def _bridge_chunk_ids(
        self, kg_chunk_ids: set,
        *, kg_to_kb_pid: Dict[str, str],
    ) -> set:
        """
        把 KG-style chunk_id 转成 KB-style：
          "<paper_uid>::<field_type>" → "<kb_paper_id>_<field_type>"
        无法桥接的 chunk_id 直接丢弃（保留原值若它本身就是 KB 格式）。
        """
        if not kg_chunk_ids:
            return set()
        if not kg_to_kb_pid:
            # 没有 KG-KB 桥表 → 同源场景，原样返回
            return set(kg_chunk_ids)
        out: set = set()
        for cid in kg_chunk_ids:
            if "::" in cid:
                pu, _, field = cid.partition("::")
                kb_pid = kg_to_kb_pid.get(pu)
                if kb_pid:
                    out.add(f"{kb_pid}_{field}")
            else:
                out.add(cid)  # 已经是 KB 格式
        return out

    def _run_s5_match(self, ctx: RequestContext):
        """S5 反向归并 + 不一致诊断。"""
        kg_db = self.m2.kg_db_path
        enable_diag = bool(self.layered_cfg.get("enable_diagnose", True))
        min_overlap = int(self.layered_cfg.get("s5_chain_match_min_overlap", 2))
        keep_supp = bool(self.layered_cfg.get("s5_keep_supplementary", True))

        anchor_ids = []
        expanded_ids = []
        for p in (ctx.kg_reasoning_paths or []):
            for n in (p.get("nodes", []) if isinstance(p, dict) else []):
                if n.get("node_id"):
                    expanded_ids.append(n["node_id"])

        # ─── KB chunks 的 chunk_id 是 KB-style，反查 KG node_chunk_posting 时
        # 需要桥接到 KG-style，否则 chain↔chunk 命中率永远 0 ───
        kb_chunks = ctx.internal_chunks or []
        # TODO-NEW-5: 复用 ctx 上缓存的 KG↔KB 桥表
        kg_to_kb = self._get_or_build_kg_kb_map(ctx, self.m2.adapter)
        # KB → KG paper_id（反向）
        kb_to_kg = {v: k for k, v in kg_to_kb.items()} if kg_to_kb else {}

        bridged_kb_chunks: List[Dict[str, Any]] = []
        for c in kb_chunks:
            cid = c.get("chunk_id") or ""
            new_cid = cid
            # KB-style "P001_design_method" → KG-style "<paper_uid>::design_method"
            if "_" in cid and "::" not in cid and kb_to_kg:
                kb_pid, _, field = cid.partition("_")
                kg_pid = kb_to_kg.get(kb_pid)
                if kg_pid:
                    new_cid = f"{kg_pid}::{field}"
            # 副本（不破坏原 chunk）保留原 chunk_id 字段供前端展示
            bridged = dict(c)
            bridged["chunk_id_for_kg"] = new_cid
            bridged_kb_chunks.append(bridged)

        # 用桥接后的 chunk_id 喂 S5
        # S5 内部用 chunk_id_for_kg 反查 node_chunk_posting，但 unit.kb_chunks
        # 仍保留原 chunk 字典（含 paper_id / fused_score / content 等）
        from ..stages import match as stage_match
        # 在 match 之前用 chunk_id_for_kg 暂时替换 chunk_id
        adjusted = []
        for c in bridged_kb_chunks:
            cc = dict(c)
            cc["__orig_chunk_id"] = cc.get("chunk_id")
            cc["chunk_id"] = c["chunk_id_for_kg"]
            adjusted.append(cc)

        result = stage_match(
            kg_db_path=kg_db,
            kg_paths=ctx.kg_reasoning_paths or [],
            kg_anchor_node_ids=anchor_ids,
            kg_expanded_node_ids=list(set(expanded_ids)),
            kb_hits=adjusted,
            min_overlap=min_overlap,
            keep_supplementary=keep_supp,
            enable_diagnose=enable_diag,
        )
        # 还原 chunk_id 到原始（KB-style）方便前端
        for u in result.answer_units:
            for c in u.kb_chunks:
                if "__orig_chunk_id" in c:
                    c["chunk_id"] = c.pop("__orig_chunk_id")
        for c in result.supplementary_chunks:
            if "__orig_chunk_id" in c:
                c["chunk_id"] = c.pop("__orig_chunk_id")
        return result

    def _run_s6_v2(self, ctx: RequestContext, matched) -> None:
        """S6 v2: 按 chain 组织 prompt → LLM 一次出答。"""
        from ..llm import get_llm_client, get_prompt, extract_answer_and_meta
        from ..modules.confidence_scorer import score_from_ctx

        chains_block = render_chains_block(matched.answer_units, max_chains=6)
        chunks_block = render_chunks_block(matched.answer_units,
                                            matched.supplementary_chunks,
                                            max_chunks_per_chain=3,
                                            max_chars_per_chunk=400)
        supplementary_block = render_supplementary_block(matched.supplementary_chunks,
                                                         max_chunks=5)

        llm = get_llm_client()
        system_prompt = get_prompt("m6_answer_generator_v2", "system")
        user_prompt = get_prompt("m6_answer_generator_v2", "user").format(
            query=ctx.query,
            num_chains=len(matched.answer_units),
            chains_block=chains_block,
            chunks_block=chunks_block,
            supplementary_block=supplementary_block,
        )

        raw = llm.call(
            prompt=user_prompt,
            system_prompt=system_prompt,
            module="m6_generator",
        )
        result = extract_answer_and_meta(raw) if raw else None
        if not result or not result.get("answer"):
            ctx.warnings.append("s6_v2: LLM 输出解析失败")
            ctx.final_answer = "（v2 答案生成失败，请重试）"
            ctx.final_confidence = 0.3
            return

        ctx.final_answer = result.get("answer", "")
        ctx.key_findings = result.get("key_findings") or []
        ctx.references = result.get("references") or []
        ctx.conflicts = result.get("conflicts") or []
        ctx.limitations = result.get("limitations", "")

        # 记录答案引用的 chain
        cited = result.get("cited_chains") or []
        if cited:
            ctx.matched_frame.setdefault("cited_chains", cited)

        llm_scores = {
            "factual_grounding": result.get("factual_grounding", 0.0),
            "completeness":      result.get("completeness", 0.0),
        }
        ctx.final_confidence = score_from_ctx(ctx, llm_scores)

    # ============================================================
    # 外部路径（沿用旧 M4+M5+M6）
    # ============================================================
    def _translate_anchor_to_kb_pids(
        self, adapter, anchor_map: Dict[str, float]
    ) -> Dict[str, float]:
        """
        KG.paper_id (sha1) → KB.paper_id (P001-P101) 通过 title 桥接。
        若 KB 与 KG 共用 sha1（重建索引后）则该函数 noop。
        """
        if not anchor_map:
            return anchor_map
        try:
            kb_pid_to_title = dict(adapter.get_papers_titles())  # [(pid, title), ...]
        except Exception:
            return anchor_map
        # 反向：title → kb_pid
        title_to_kbpid = {t.strip().lower(): pid for pid, t in kb_pid_to_title.items() if t}

        # 拉 KG paper title（用 m2.kg_adapter 的 db_path 直查）
        from ..modules.m2_internal_retrieval.kg_path_adapter import KGPathAdapter
        kg_adapter = self.m2.kg_adapter
        if kg_adapter is None or kg_adapter._con is None:
            return anchor_map  # KG 未初始化，noop
        kg_pids = list(anchor_map.keys())
        if not kg_pids:
            return anchor_map
        ph = ",".join("?" * len(kg_pids))
        rows = kg_adapter._con.execute(
            f"SELECT paper_id, paper_title FROM paper WHERE paper_id IN ({ph})",
            kg_pids,
        ).fetchall()
        kg_pid_to_title = {r["paper_id"]: (r["paper_title"] or "").strip().lower()
                           for r in rows}

        merged: Dict[str, float] = {}
        for kg_pid, score in anchor_map.items():
            # 1. 直接 hash 命中？
            if kg_pid in kb_pid_to_title:
                merged[kg_pid] = max(merged.get(kg_pid, 0.0), score)
                continue
            # 2. title 桥接
            ktitle = kg_pid_to_title.get(kg_pid, "")
            if ktitle and ktitle in title_to_kbpid:
                kb_pid = title_to_kbpid[ktitle]
                merged[kb_pid] = max(merged.get(kb_pid, 0.0), score)
                continue
            # 3. fallback 前 30 字模糊
            if ktitle:
                head = ktitle[:30]
                for tt, pid in title_to_kbpid.items():
                    if tt.startswith(head):
                        merged[pid] = max(merged.get(pid, 0.0), score * 0.9)
                        break
        return merged

    def _try_simplify_query(self, ctx: RequestContext) -> Optional[str]:
        """
        M1 schema parse 不达标时，用 LLM 把长工程描述 query 拆解/简化成核心技术问句。
        目的：让 M1 能命中 schema，进入内部检索路径而非直接走外部。
        失败时静默返回 None（不影响主流程）。
        """
        try:
            from ..llm import get_llm_client
            llm = get_llm_client()
            prompt = (
                "请将以下查询简化为一句核心技术问句（不超过30字），聚焦于材料/结构/频段/性能等技术要素，"
                "去掉工程约束描述和输出格式要求：\n\n"
                f"{ctx.query[:800]}\n\n"
                "只输出简化后的问句，不要解释。"
            )
            result = llm.call(
                prompt=prompt,
                module="m1_parser",
                thinking_mode=False,
            )
            if result:
                simplified = result.strip().split("\n")[0].strip()
                if len(simplified) >= 5:
                    return simplified
        except Exception as e:
            logger.debug(f"query simplify failed: {e}")
        return None

    def _enrich_references_pdf_paths(self, ctx: RequestContext) -> None:
        """把 evidence_papers 里已下载的 PDF 路径写回到 references 列表。

        references 里每条的 url_or_doi 格式是 'paper_uid=xxx'，
        与 evidence_papers 的 paper_uid 对应，直接查映射即可。
        """
        if not ctx.references:
            return

        # 建立 paper_uid → first pdf_path 的映射
        uid_to_pdf: dict = {}
        for ep in ctx.evidence_papers or []:
            uid = ep.get("paper_uid") or ""
            paths = ep.get("pdf_paths") or []
            if uid and paths:
                uid_to_pdf[uid] = paths[0]

        if not uid_to_pdf:
            return

        for ref in ctx.references:
            raw = ref.get("url_or_doi") or ""
            if raw.startswith("paper_uid="):
                uid = raw[len("paper_uid="):]
                if uid in uid_to_pdf:
                    ref["local_pdf_path"] = uid_to_pdf[uid]

    def _go_external(self, ctx: RequestContext) -> None:
        plog = getattr(ctx, "_process_logger", None)
        if self._m4 is None or self._m5 is None or self._m6 is None:
            ctx.warnings.append("外部路径模块未注册")
            ctx.final_answer = (
                f"[当前仅内部路径可用] 状态={ctx.state.value if ctx.state else 'N/A'}。"
            )
            ctx.final_confidence = 0.0
            return

        ctx = self._m4.run(ctx)
        if plog:
            plog.log_json("m4", {"search_plan": ctx.search_plan})
        ctx = self._m5.run(ctx)
        if plog:
            plog.log_json("m5", {
                "external_docs": ctx.external_docs,
                "external_docs_stats": ctx.external_docs_stats,
            })
        ctx = self._m6.run(ctx)
        ctx.exit_reason = ExitReason.EXTERNAL_SUCCESS


# ============================================================
# 人类可读的全 return 摘要（专家审计用，不省略）
# ============================================================

def _format_human_summary(ctx: RequestContext, response: Optional[Dict[str, Any]]) -> str:
    """把整次 query 的关键产物按 7 段渲染为可读文本。

    专家直接阅读 10_summary.txt 即可核查：
      1) 原始 query
      2) 图谱初始 seed 节点（含 type/name）
      3) 图谱拓展后的 soft 节点全集
      4) 图谱推理路径（每条带支撑论文）
      5) 知识库证据（不截断）
      6) 参考文献本地化路径（内部 md/pdf + 外部 pdf）
      7) LLM 最终回答
    """
    def _line(s: str = "") -> str:
        return s + "\n"

    parts: List[str] = []
    parts.append(_line("=" * 80))
    parts.append(_line(f"request_id : {ctx.request_id}"))
    parts.append(_line(f"channel    : {ctx.channel}"))
    parts.append(_line(f"final_confidence : {ctx.final_confidence}"))
    parts.append(_line("=" * 80))

    # 1) 原始 query
    parts.append(_line("\n[1] 原始 query"))
    parts.append(_line("-" * 80))
    parts.append(_line(ctx.query or ""))

    # 2/3) seed + soft nodes（来自 kg_retrieval_plan）
    plan = ctx.kg_retrieval_plan or {}
    seed_nodes = plan.get("seed_nodes") or []
    soft_nodes = plan.get("soft_nodes") or []
    parts.append(_line(f"\n[2] 图谱初始 seed 节点（共 {len(seed_nodes)} 个）"))
    parts.append(_line("-" * 80))
    if seed_nodes:
        for n in seed_nodes:
            parts.append(_line(
                f"  - [{n.get('node_type')}] {n.get('canonical_name')}  (id={n.get('node_id')})"
            ))
    else:
        parts.append(_line("  (无)"))

    parts.append(_line(f"\n[3] 图谱拓展后的 soft 节点（共 {len(soft_nodes)} 个）"))
    parts.append(_line("-" * 80))
    if soft_nodes:
        for n in soft_nodes:
            parts.append(_line(
                f"  - [{n.get('node_type')}] {n.get('canonical_name')}  (id={n.get('node_id')})"
            ))
    else:
        parts.append(_line("  (无)"))

    # 4) 推理路径
    paths = ctx.kg_reasoning_paths or []
    parts.append(_line(f"\n[4] 图谱推理路径（共 {len(paths)} 条）"))
    parts.append(_line("-" * 80))
    for i, p in enumerate(paths, 1):
        if isinstance(p, dict):
            parts.append(_line(f"  路径#{i}: {p.get('text', '')}"))
            sps = p.get("support_papers") or []
            for sp in sps:
                parts.append(_line(
                    f"      支撑文献: 《{sp.get('title','')}》"
                    f" ({sp.get('year','')})  paper_id={sp.get('paper_id','')}"
                    f"  support_score={sp.get('support_score','')}"
                ))
        else:
            parts.append(_line(f"  路径#{i}: {p}"))
    if not paths:
        parts.append(_line("  (无)"))

    # 5) KB 证据（不截断）
    chunks = ctx.internal_chunks or []
    parts.append(_line(f"\n[5] 知识库证据 chunks（共 {len(chunks)} 条，全文）"))
    parts.append(_line("-" * 80))
    for i, c in enumerate(chunks, 1):
        parts.append(_line(
            f"  [{i}] paper_id={c.get('paper_id','')}  title={c.get('title','')}"
            f"  field_type={c.get('field_type','')}  fused_score={c.get('fused_score','')}"
        ))
        content = c.get("content") or ""
        parts.append(_line(f"      {content}"))

    # 6) 参考文献本地化
    ev_papers = ctx.evidence_papers or []
    parts.append(_line(f"\n[6a] 内部文献本地路径（共 {len(ev_papers)} 篇）"))
    parts.append(_line("-" * 80))
    for ep in ev_papers:
        parts.append(_line(
            f"  - paper_uid={ep.get('paper_uid','')}  《{ep.get('title','')}》"
        ))
        if ep.get("md_path"):
            parts.append(_line(f"      md : {ep['md_path']}"))
        for p in ep.get("pdf_paths") or []:
            parts.append(_line(f"      pdf: {p}"))
    if not ev_papers:
        parts.append(_line("  (无)"))

    ext_docs = ctx.external_docs or []
    parts.append(_line(f"\n[6b] 外部文献本地 PDF（共 {len(ext_docs)} 篇）"))
    parts.append(_line("-" * 80))
    for d in ext_docs:
        parts.append(_line(
            f"  - 《{d.get('title','')}》  source={d.get('source_api','')}  "
            f"doi={d.get('doi','')}  year={d.get('year','')}"
        ))
        if d.get("local_pdf_path"):
            parts.append(_line(f"      pdf: {d['local_pdf_path']}"))
        elif d.get("download_error"):
            parts.append(_line(f"      download_error: {d['download_error']}"))
    if not ext_docs:
        parts.append(_line("  (无)"))

    # 7) 最终 LLM 回答
    parts.append(_line("\n[7] LLM 最终回答"))
    parts.append(_line("-" * 80))
    parts.append(_line(ctx.final_answer or "(空)"))

    # 额外：警告与错误
    if ctx.warnings:
        parts.append(_line("\n[!] warnings"))
        parts.append(_line("-" * 80))
        for w in ctx.warnings:
            parts.append(_line(f"  - {w}"))
    if ctx.error:
        parts.append(_line("\n[!!] error"))
        parts.append(_line("-" * 80))
        parts.append(_line(ctx.error))

    return "".join(parts)
