#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
context.py —— 跨模块传递的请求上下文

所有模块读写同一个 RequestContext，避免接口参数爆炸。
模块的输入/输出都在此处声明，相当于一份数据契约。
"""

import uuid
import time
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional

from .state import State, ExitReason


@dataclass
class RequestContext:
    """单次请求的完整上下文。"""

    # ================== 输入 ==================
    query: str = ""
    request_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    created_at: float = field(default_factory=time.time)

    # ================== 模块1：Schema 解析 ==================
    parse_confidence: float = 0.0
    matched_schema_fields: List[str] = field(default_factory=list)
    m1_reason: str = ""

    # ================== 模块2：内部检索 ==================
    retrieval_confidence: float = 0.0
    internal_chunks: List[Dict[str, Any]] = field(default_factory=list)
    # kb_mvp 返回的结构化查询 JSON（用于三路融合）
    structured_query: Optional[Dict[str, Any]] = None

    # KG 推理路径（来自 scientific_kgqa.QAEngine）
    kg_reasoning_paths: List[Dict[str, Any]] = field(default_factory=list)
    kg_evidence: List[Dict[str, Any]] = field(default_factory=list)
    kg_retrieval_plan: Dict[str, Any] = field(default_factory=dict)
    kg_summary: str = ""
    kg_intent: Optional[str] = None
    kg_confidence: float = 0.0

    # 文献溯源（EvidenceResolver 反查主项目 state.db.papers.source_ref）
    # 每条形如 {paper_uid, title, source_ref, md_path, pdf_paths: [...]}
    evidence_papers: List[Dict[str, Any]] = field(default_factory=list)

    # 过程日志目录（ProcessLogger 在外部填入）
    process_log_dir: str = ""

    # M6 是否调了 LLM 生成（False = 配置 m6.llm_response=false 跳过）
    skipped_llm: bool = False

    # 知识回流是否触发（M6 写入候选池后置 True）
    backflow_pushed: bool = False

    # 细粒度耗时（ms）：键如 "m2.kb_structurize" / "m2.kb_search" / "m2.kg_engine" / "m2.kg_provenance" / "m2.evidence_resolver"
    fine_timings: Dict[str, float] = field(default_factory=dict)

    # ================== v2: KG-first 中间状态 ==================
    # S3 BridgeKGtoKB 产物
    kb_hints: Dict[str, Any] = field(default_factory=dict)
    # S5 MatchKGKB 产物
    matched_frame: Dict[str, Any] = field(default_factory=dict)
    # S5 不一致诊断（v2 §9）
    inconsistencies: List[Dict[str, Any]] = field(default_factory=list)
    # 通道: fast | deep | legacy
    channel: str = "legacy"

    # ================== 模块3：答案验证 ==================
    answer_confidence: float = 0.0
    covered_aspects: List[str] = field(default_factory=list)
    missing_aspects: List[str] = field(default_factory=list)
    can_answer_directly: bool = False

    # ================== 状态 ==================
    state: Optional[State] = None
    exit_reason: Optional[ExitReason] = None

    # ================== 模块4：检索计划 ==================
    search_plan: Dict[str, Any] = field(default_factory=dict)

    # ================== 模块5：外部检索 ==================
    external_docs: List[Dict[str, Any]] = field(default_factory=list)
    external_docs_stats: Dict[str, Any] = field(default_factory=dict)

    # ================== 模块6：最终答案 ==================
    final_answer: str = ""
    final_confidence: float = 0.0
    key_findings: List[str] = field(default_factory=list)
    references: List[Dict[str, Any]] = field(default_factory=list)
    conflicts: List[str] = field(default_factory=list)
    limitations: str = ""

    # ================== 指标与追踪 ==================
    # 每个模块的耗时(ms)和跳转信息：{"m1": {"latency_ms": 450, "jumped": false}, ...}
    module_metrics: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    # 完整的执行路径（按模块顺序追加）
    execution_path: List[str] = field(default_factory=list)
    # 任何模块产生的警告
    warnings: List[str] = field(default_factory=list)
    # 错误信息（若有）
    error: Optional[str] = None

    # ------------------------------------------------------------
    # 便捷方法
    # ------------------------------------------------------------
    def record_module(
        self,
        module_name: str,
        latency_ms: float,
        jumped: bool = False,
        extra: Optional[Dict[str, Any]] = None,
    ) -> None:
        """记录一个模块的执行情况。"""
        self.module_metrics[module_name] = {
            "latency_ms": round(latency_ms, 2),
            "jumped": jumped,
            **(extra or {}),
        }
        self.execution_path.append(module_name)

    def total_latency_ms(self) -> float:
        return sum(m.get("latency_ms", 0.0) for m in self.module_metrics.values())

    def to_dict(self) -> Dict[str, Any]:
        """转成 JSON-friendly 字典（用于日志与返回）。"""
        d = asdict(self)
        # Enum → str
        if self.state is not None:
            d["state"] = self.state.value
        if self.exit_reason is not None:
            d["exit_reason"] = self.exit_reason.value
        return d

    def to_response(self) -> Dict[str, Any]:
        """
        转成对外返回的字典。

        字段映射到需求图 (3a-3e)：
          - llm_answer        ← 3a  (LLM 推理回答，skipped_llm=True 时为空串)
          - kg_reasoning_paths ← 3b  (KG 推理路径)
          - kb_evidence       ← 3c  (KB 三路融合 chunks)
          - evidence_papers   ← 3d  (与文献夹关联的 md/pdf 路径)
          - external_refs     ← 3e  (外部 API 检索结果 + local_pdf_path)
        """
        return {
            "request_id": self.request_id,
            "query": self.query,
            "process_log_dir": self.process_log_dir,

            # 3a
            "llm_answer": self.final_answer,
            "llm_skipped": self.skipped_llm,
            # 3b
            "kg_reasoning_paths": self.kg_reasoning_paths,
            "kg_summary": self.kg_summary,
            "kg_retrieval_plan": self.kg_retrieval_plan,
            # 3c
            "kb_evidence": self.internal_chunks,
            # 3d
            "evidence_papers": self.evidence_papers,
            # 3e
            "external_refs": self.external_docs,

            # 兼容旧字段
            "answer": self.final_answer,
            "key_findings": self.key_findings,
            "references": self.references,
            "conflicts": self.conflicts,
            "limitations": self.limitations,

            "metrics": {
                "parse_confidence": self.parse_confidence,
                "retrieval_confidence": self.retrieval_confidence,
                "answer_confidence": self.answer_confidence,
                "final_confidence": self.final_confidence,
                "state": self.state.value if self.state else None,
                "exit_reason": self.exit_reason.value if self.exit_reason else None,
                "execution_path": self.execution_path,
                "total_latency_ms": self.total_latency_ms(),
                "kg_confidence": self.kg_confidence,
                "fine_timings": self.fine_timings,
                "channel": self.channel,
            },

            # v2 新增：KG 引导面板
            "kb_hints":         self.kb_hints,
            "matched_frame":    self.matched_frame,
            "inconsistencies":  self.inconsistencies,

            "backflow_pushed": self.backflow_pushed,
            "warnings": self.warnings,
            "error": self.error,
        }
