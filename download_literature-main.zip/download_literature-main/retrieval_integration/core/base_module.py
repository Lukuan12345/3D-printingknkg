#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
base_module.py —— 模块抽象基类

所有业务模块继承 BaseModule，对外暴露统一的 run(ctx) 接口。
基类负责：
- 统一的配置注入
- 自动计时
- 异常捕获 + 降级
"""

import time
import logging
from abc import ABC, abstractmethod
from typing import Any, Dict, Optional

from ..config import Config, get_config
from .context import RequestContext


class BaseModule(ABC):
    """所有业务模块的抽象基类。"""

    # 子类必须设置
    name: str = "base_module"

    def __init__(self, config: Optional[Config] = None):
        self.config = config or get_config()
        self.logger = logging.getLogger(f"RI.{self.name}")
        self._module_cfg = self._load_module_config()

    def _load_module_config(self) -> Dict[str, Any]:
        """读取本模块在 default_config.yaml 下的专属配置。"""
        cfg = self.config.get(self.name, {})
        return cfg if isinstance(cfg, dict) else {}

    def run(self, ctx: RequestContext) -> RequestContext:
        """
        模块入口。自动计时 + 异常捕获。
        不建议子类重写此方法，应重写 _run()。
        """
        start = time.perf_counter()
        plog = getattr(ctx, "_process_logger", None)
        if plog is not None:
            try:
                plog.log_module_start(self.name)
            except Exception:  # noqa: BLE001
                pass
        try:
            self.logger.info(f"[{ctx.request_id}] {self.name} start")
            ctx = self._run(ctx)
            latency_ms = (time.perf_counter() - start) * 1000
            ctx.record_module(self.name, latency_ms, jumped=False)
            self.logger.info(
                f"[{ctx.request_id}] {self.name} done ({latency_ms:.1f}ms)"
            )
            if plog is not None:
                try:
                    plog.log_module_end(self.name, ok=True,
                                        extra=f"{latency_ms:.1f}ms")
                except Exception:  # noqa: BLE001
                    pass
            return ctx
        except Exception as e:
            latency_ms = (time.perf_counter() - start) * 1000
            ctx.warnings.append(f"{self.name} error: {e}")
            ctx.record_module(
                self.name,
                latency_ms,
                jumped=False,
                extra={"error": str(e)},
            )
            self.logger.exception(
                f"[{ctx.request_id}] {self.name} failed: {e}"
            )
            if plog is not None:
                try:
                    plog.log_module_end(self.name, ok=False, extra=str(e))
                except Exception:  # noqa: BLE001
                    pass
            # 降级策略由子类通过 _on_error 实现
            return self._on_error(ctx, e)

    @abstractmethod
    def _run(self, ctx: RequestContext) -> RequestContext:
        """子类实现核心逻辑。"""
        raise NotImplementedError

    def _on_error(self, ctx: RequestContext, err: Exception) -> RequestContext:
        """
        默认异常处理：让流程继续（不抛异常）。
        子类可覆盖此方法实现更精细的降级。
        """
        return ctx
