#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
state.py —— 状态机定义

对应方案中的两个状态：
- STATE_A: 内部零知识（模块1或模块2失败）
- STATE_B: 内部部分知识（模块3失败）
- DIRECT:  直接输出（模块3高分）
"""

from enum import Enum


class State(str, Enum):
    """Pipeline 状态标识。继承 str 便于 JSON 序列化。"""

    A = "A"              # 内部零知识
    B = "B"              # 内部部分知识
    DIRECT = "DIRECT"    # 直接输出高分答案（不进模块4）


class ExitReason(str, Enum):
    """Pipeline 退出原因。"""

    DIRECT_ANSWER = "direct_answer"              # 模块3高分 → 直接输出
    EXTERNAL_SUCCESS = "external_success"        # 走完外部路径
    SCHEMA_MISS = "schema_miss"                  # 模块1 Schema 不契合
    RETRIEVAL_MISS = "retrieval_miss"            # 模块2 检索无结果
    ANSWER_INSUFFICIENT = "answer_insufficient"  # 模块3 内容不足
    ERROR = "error"                              # 异常终止
