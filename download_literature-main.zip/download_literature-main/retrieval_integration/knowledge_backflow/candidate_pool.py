#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
candidate_pool.py —— 待入库候选池管理

管理由模块6推送的高质量答案候选。
管理员可通过 admin_interface 批量审核 / 入库 / 拒绝。
"""

import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from ..config import get_config


class CandidatePool:
    """候选池：基于 JSONL 文件系统。"""

    def __init__(self, config=None):
        cfg = config or get_config()
        self.pool_dir = cfg.resolve_path(
            cfg.get("knowledge_backflow.candidate_pool.path", "data/candidate_pool/")
        )
        self.pool_dir.mkdir(parents=True, exist_ok=True)

        # 子目录
        self.pending_dir = self.pool_dir          # JSONL 文件直接存在 pool_dir
        self.approved_dir = self.pool_dir / "approved"
        self.rejected_dir = self.pool_dir / "rejected"
        for d in [self.approved_dir, self.rejected_dir]:
            d.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------
    def list_pending(self, date: Optional[str] = None) -> List[Dict[str, Any]]:
        """列出待审核的候选。"""
        records = []
        for f in sorted(self.pool_dir.glob("candidates_*.jsonl")):
            if date and date not in f.name:
                continue
            with open(f, "r", encoding="utf-8") as fh:
                for line in fh:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        records.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue
        return records

    # ------------------------------------------------------------
    def approve(self, request_id: str) -> bool:
        """批准某条候选，移入 approved/。"""
        return self._move(request_id, self.approved_dir)

    def reject(self, request_id: str) -> bool:
        """拒绝某条候选，移入 rejected/。"""
        return self._move(request_id, self.rejected_dir)

    def _move(self, request_id: str, target_dir: Path) -> bool:
        """从 pending 找到 request_id，追加到 target_dir/YYYY-MM-DD.jsonl，并从原文件剔除。"""
        found_record = None
        source_file = None

        for f in sorted(self.pool_dir.glob("candidates_*.jsonl")):
            new_lines = []
            with open(f, "r", encoding="utf-8") as fh:
                for line in fh:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        rec = json.loads(line)
                    except json.JSONDecodeError:
                        new_lines.append(line)
                        continue
                    if rec.get("request_id") == request_id and found_record is None:
                        found_record = rec
                        source_file = f
                    else:
                        new_lines.append(line)
            if found_record and source_file == f:
                # 重写原文件（剔除已移动的记录）
                with open(f, "w", encoding="utf-8") as fw:
                    for line in new_lines:
                        fw.write(line + "\n")
                break

        if not found_record:
            return False

        date_str = datetime.now().strftime("%Y-%m-%d")
        target_path = target_dir / f"{date_str}.jsonl"
        with open(target_path, "a", encoding="utf-8") as fw:
            fw.write(json.dumps(found_record, ensure_ascii=False) + "\n")
        return True

    # ------------------------------------------------------------
    def stats(self) -> Dict[str, int]:
        def _count_lines(directory: Path, pattern: str) -> int:
            total = 0
            for f in directory.glob(pattern):
                with open(f, "r", encoding="utf-8") as fh:
                    total += sum(1 for line in fh if line.strip())
            return total

        return {
            "pending": _count_lines(self.pool_dir, "candidates_*.jsonl"),
            "approved": _count_lines(self.approved_dir, "*.jsonl"),
            "rejected": _count_lines(self.rejected_dir, "*.jsonl"),
        }
