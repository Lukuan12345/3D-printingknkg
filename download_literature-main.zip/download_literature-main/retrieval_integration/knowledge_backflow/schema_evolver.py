#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
schema_evolver.py —— Schema 演进分析

功能：
1. 收集 m1 记录的解析失败 Query（schema_miss_log/miss_*.jsonl）
2. 达到最小样本量后，调用 LLM 做聚类分析
3. 输出建议的新 Schema 字段，供管理员确认
"""

import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional

from ..config import get_config
from ..llm import get_llm_client, get_prompt


class SchemaEvolver:
    """基于 LLM 的 Schema 演进建议器。"""

    def __init__(self, config=None):
        cfg = config or get_config()
        self.config = cfg
        self.miss_dir = cfg.resolve_path(
            cfg.get(
                "knowledge_backflow.schema_evolver.schema_miss_log_path",
                "data/schema_miss_log/",
            )
        )
        self.min_cluster_size = cfg.get(
            "knowledge_backflow.schema_evolver.min_cluster_size", 10
        )
        self.llm = get_llm_client()

    # ------------------------------------------------------------
    def collect_failed_queries(
        self,
        days: int = 7,
        limit: int = 500,
    ) -> List[Dict[str, Any]]:
        """收集近 N 天的失败 Query。"""
        cutoff = datetime.now() - timedelta(days=days)
        records = []

        for f in sorted(self.miss_dir.glob("miss_*.jsonl")):
            # 简单按文件名日期过滤
            try:
                date_str = f.stem.replace("miss_", "")
                file_date = datetime.strptime(date_str, "%Y-%m-%d")
                if file_date < cutoff:
                    continue
            except ValueError:
                pass

            with open(f, "r", encoding="utf-8") as fh:
                for line in fh:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        records.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue

        return records[-limit:]  # 只保留最近 limit 条

    # ------------------------------------------------------------
    def cluster_and_suggest(
        self, queries: Optional[List[Dict[str, Any]]] = None
    ) -> Dict[str, Any]:
        """
        调用 LLM 聚类分析，输出 Schema 字段建议。

        Returns:
            {
              "clusters": [
                {
                  "theme": "...",
                  "frequency": N,
                  "sample_queries": [...],
                  "suggested_schema_field": "...",
                  "rationale": "..."
                }
              ],
              "n_analyzed": N,
              "meets_threshold": bool,
            }
        """
        if queries is None:
            queries = self.collect_failed_queries()

        if len(queries) < self.min_cluster_size:
            return {
                "clusters": [],
                "n_analyzed": len(queries),
                "meets_threshold": False,
                "message": f"失败 Query 数量 ({len(queries)}) 未达阈值 ({self.min_cluster_size})",
            }

        # 准备 Prompt
        failed_text = "\n".join(
            [f"- [{i + 1}] {r.get('query', '')}" for i, r in enumerate(queries)]
        )
        system_prompt = get_prompt("schema_evolver", "system")
        user_prompt = get_prompt("schema_evolver", "user").format(
            num_queries=len(queries),
            failed_queries=failed_text,
        )

        result = self.llm.call_json(
            prompt=user_prompt,
            system_prompt=system_prompt,
            module="m4_planner",  # 复用规划模型
        )

        if not result or "clusters" not in result:
            return {
                "clusters": [],
                "n_analyzed": len(queries),
                "meets_threshold": True,
                "message": "LLM 聚类失败",
            }

        return {
            "clusters": result["clusters"],
            "n_analyzed": len(queries),
            "meets_threshold": True,
        }
