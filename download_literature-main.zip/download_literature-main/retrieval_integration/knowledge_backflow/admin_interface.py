#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
admin_interface.py —— 管理员 CLI 接口

用于：
1. 查看候选池状态
2. 批准 / 拒绝候选
3. 触发 Schema 演进分析
"""

import json
import argparse
from typing import Optional

from .candidate_pool import CandidatePool
from .schema_evolver import SchemaEvolver


def cli_status():
    pool = CandidatePool()
    stats = pool.stats()
    print("=== 候选池状态 ===")
    for k, v in stats.items():
        print(f"  {k}: {v}")


def cli_list(date: Optional[str] = None, limit: int = 20):
    pool = CandidatePool()
    records = pool.list_pending(date=date)
    print(f"=== 待审核候选 ({len(records)} 条) ===")
    for r in records[:limit]:
        print(
            f"- {r.get('request_id')} | conf={r.get('final_confidence', 0):.3f} | "
            f"state={r.get('state')} | {r.get('query', '')[:60]}"
        )


def cli_approve(request_id: str):
    pool = CandidatePool()
    ok = pool.approve(request_id)
    print("✅ 已批准" if ok else "❌ 未找到该 request_id")


def cli_reject(request_id: str):
    pool = CandidatePool()
    ok = pool.reject(request_id)
    print("✅ 已拒绝" if ok else "❌ 未找到该 request_id")


def cli_schema_suggest(days: int = 7):
    evolver = SchemaEvolver()
    result = evolver.cluster_and_suggest(
        queries=evolver.collect_failed_queries(days=days)
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))


def main():
    parser = argparse.ArgumentParser(description="知识回流管理员 CLI")
    sub = parser.add_subparsers(dest="cmd")

    sub.add_parser("status")

    p_list = sub.add_parser("list")
    p_list.add_argument("--date", default=None)
    p_list.add_argument("--limit", type=int, default=20)

    p_approve = sub.add_parser("approve")
    p_approve.add_argument("request_id")

    p_reject = sub.add_parser("reject")
    p_reject.add_argument("request_id")

    p_schema = sub.add_parser("schema-suggest")
    p_schema.add_argument("--days", type=int, default=7)

    args = parser.parse_args()

    if args.cmd == "status":
        cli_status()
    elif args.cmd == "list":
        cli_list(args.date, args.limit)
    elif args.cmd == "approve":
        cli_approve(args.request_id)
    elif args.cmd == "reject":
        cli_reject(args.request_id)
    elif args.cmd == "schema-suggest":
        cli_schema_suggest(args.days)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
