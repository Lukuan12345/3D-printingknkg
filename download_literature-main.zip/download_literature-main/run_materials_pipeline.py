#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""run_materials_pipeline.py —— 通用合金文献入库前处理流水线（步骤 1-3）。

把 `materials/` 下的原始 PDF 教程批量处理成「拆分 → 上传 S3 → MinerU 解析 → 写回 S3」，
为后续 gen_key 的知识库 / 图谱构建（build_kb_kg.py、fast_ingest.py）准备好解析产物。

────────────────────────────────────────────────────────────────────────────
三个步骤
────────────────────────────────────────────────────────────────────────────
1. split  : 每个 PDF 按 20 页切成 part_001.pdf / part_002.pdf …，
            放到 materials_peocess/<原PDF名>/ 文件夹下（文件夹以原 PDF 名命名）。
2. upload : 用 rclone 把拆分后的整棵目录树增量同步到 S3（remote=ai4cmp）。
3. parse  : 用 MinerU 解析（复用本仓库 mineru.py 的云端 API），
            解析完的 Markdown 结果按 <书名>/<part_xxx>/ 结构写回 S3（remote=ai4cmp）。

用法
────
    # 一把梭：1→2→3
    python run_materials_pipeline.py all

    # 单步执行
    python run_materials_pipeline.py split
    python run_materials_pipeline.py upload
    python run_materials_pipeline.py parse

    # 常用覆盖项
    python run_materials_pipeline.py split  --pages-per-part 20
    python run_materials_pipeline.py upload --dest "ai4cmp:ai4cmp/suyulin/materials/pdf_split"
    python run_materials_pipeline.py parse  --mineru-key k1
    python run_materials_pipeline.py all    --dry-run        # 只打印计划，不动手

说明
────
• MinerU 的云端解析会把同名 basename（如各书的 part_001.pdf）混在一起，
  因此 parse 步骤会先把拆分件以全局唯一短名（doc0001_p001.pdf）做一份 staging，
  解析后再按 manifest 还原回 <书名>/<part_xxx>/ 结构，最后整体 rclone 写回 S3，
  保证不同书的 part 不串台。
• MINERU_API_KEY / S3(ai4cmp) 凭据均由仓库现成机制提供：
  - MinerU key：.env 里的 MINERU_API_KEY（env_bootstrap 自动加载），或 --mineru-key。
  - rclone：%APPDATA%/rclone/rclone.conf 里的 [ai4cmp] 远端（已配置）。
"""

from __future__ import annotations

import argparse
import json
import math
import os
import shutil
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace

import fitz  # PyMuPDF —— 仓库 requirements 已声明

# 复用现成 mineru 云端解析逻辑（导入时会 load_env() 把 .env 灌进环境变量）
import mineru

# ─── 默认路径 / 远端 ─────────────────────────────────────────────────────────
SRC_DIR_DEFAULT   = r"C:/Users/suyulin/Downloads/materials/materials"
OUT_DIR_DEFAULT   = r"C:/Users/suyulin/Downloads/materials/materials_peocess"
PAGES_PER_PART    = 20

# S3 远端（rclone remote 名 = ai4cmp，桶名也叫 ai4cmp，已存在 suyulin/ 前缀）
S3_SPLIT_DEST_DEFAULT  = "ai4cmp:ai4cmp/suyulin/materials/pdf_split"
S3_PARSED_DEST_DEFAULT = "ai4cmp:ai4cmp/suyulin/materials/parsed"

# parse 阶段的本地工作目录（staging / 任务记录 / 下载 / 还原）
WORK_ROOT_DEFAULT = r"C:/Users/suyulin/Downloads/materials/_mineru_work"

RCLONE_BIN = os.environ.get("RCLONE_BIN", "rclone")


# ═══════════════════════════════════════════════════════════════════════════
# 步骤 1：拆分
# ═══════════════════════════════════════════════════════════════════════════

def _expected_parts(page_count: int, pages_per_part: int) -> int:
    return max(1, math.ceil(page_count / pages_per_part))


def split_pdf(src_pdf: Path, book_dir: Path, pages_per_part: int) -> int:
    """把单个 PDF 按 pages_per_part 页切片到 book_dir/part_xxx.pdf，返回切片数。"""
    doc = fitz.open(str(src_pdf))
    try:
        total = doc.page_count
        parts = _expected_parts(total, pages_per_part)
        book_dir.mkdir(parents=True, exist_ok=True)
        for i in range(parts):
            start = i * pages_per_part
            end = min(start + pages_per_part, total) - 1  # to_page 含端点
            out_path = book_dir / f"part_{i + 1:03d}.pdf"
            sub = fitz.open()
            try:
                sub.insert_pdf(doc, from_page=start, to_page=end)
                sub.save(str(out_path))
            finally:
                sub.close()
        return parts
    finally:
        doc.close()


def cmd_split(args) -> None:
    src = Path(args.src_dir)
    out = Path(args.out_dir)
    ppp = args.pages_per_part

    pdfs = sorted(p for p in src.glob("*.pdf") if p.is_file())
    if not pdfs:
        print(f"[split][ERROR] {src} 下没有找到 PDF")
        return
    print(f"[split] 源目录 {src} 共 {len(pdfs)} 个 PDF，按每 {ppp} 页拆分 → {out}")

    done = skipped = failed = 0
    for pdf in pdfs:
        book_dir = out / pdf.stem  # 文件夹以原 PDF 名命名（保留空格/原字符）
        try:
            page_count = fitz.open(str(pdf)).page_count
        except Exception as e:
            print(f"  [FAIL] 打不开 {pdf.name}: {e}")
            failed += 1
            continue
        expected = _expected_parts(page_count, ppp)

        # 幂等：已切好（part 数对得上）就跳过
        existing = sorted(book_dir.glob("part_*.pdf")) if book_dir.exists() else []
        if len(existing) == expected:
            print(f"  [SKIP] {pdf.name}  ({expected} 片已存在)")
            skipped += 1
            continue

        if args.dry_run:
            print(f"  [PLAN] {pdf.name}  {page_count} 页 → {expected} 片")
            continue

        # 重新切：先清掉残留的不完整切片
        if existing:
            for f in existing:
                f.unlink()
        n = split_pdf(pdf, book_dir, ppp)
        print(f"  [OK]   {pdf.name}  {page_count} 页 → {n} 片  ({book_dir.name}/)")
        done += 1

    print(f"[split] 完成：新切 {done}，跳过 {skipped}，失败 {failed}")


# ═══════════════════════════════════════════════════════════════════════════
# 步骤 2：上传拆分件到 S3
# ═══════════════════════════════════════════════════════════════════════════

def _rclone_copy(local: Path, dest: str, dry_run: bool, transfers: int = 16) -> bool:
    if shutil.which(RCLONE_BIN) is None:
        print(f"[rclone][ERROR] 找不到 {RCLONE_BIN}，请先安装并配好 [ai4cmp] 远端")
        return False
    cmd = [RCLONE_BIN, "copy", str(local), dest, "--transfers", str(transfers), "--progress"]
    if dry_run:
        cmd.append("--dry-run")
    print(f"[rclone] {' '.join(cmd)}")
    proc = subprocess.run(cmd)
    if proc.returncode != 0:
        print(f"[rclone][WARN] 返回码 {proc.returncode}")
        return False
    return True


def cmd_upload(args) -> None:
    out = Path(args.out_dir)
    if not out.exists() or not any(out.iterdir()):
        print(f"[upload][ERROR] {out} 为空，先跑 split")
        return
    print(f"[upload] 同步拆分件 {out}  →  {args.dest}")
    ok = _rclone_copy(out, args.dest, args.dry_run)
    print("[upload] 完成" if ok else "[upload] 未完成（见上方告警）")


# ═══════════════════════════════════════════════════════════════════════════
# 步骤 3：MinerU 解析 → 写回 S3
# ═══════════════════════════════════════════════════════════════════════════

def _build_stage(out: Path, stage_dir: Path) -> list[dict]:
    """把 materials_peocess/<book>/part_xxx.pdf 以全局唯一短名映射进 stage_dir。

    返回 manifest 列表，元素 {id, book, part}；
    用硬链接（同盘秒级、不占额外空间），失败再退回复制。
    """
    stage_dir.mkdir(parents=True, exist_ok=True)
    manifest: list[dict] = []
    books = sorted([d for d in out.iterdir() if d.is_dir()])
    for bi, book in enumerate(books, 1):
        parts = sorted(book.glob("part_*.pdf"))
        for part in parts:
            pno = part.stem.split("_")[-1]  # '001'
            uid = f"doc{bi:04d}_p{pno}"
            staged = stage_dir / f"{uid}.pdf"
            if not staged.exists():
                try:
                    os.link(part, staged)          # 硬链接
                except OSError:
                    shutil.copy2(part, staged)     # 跨盘/不支持时复制
            manifest.append({"id": uid, "book": book.name, "part": part.stem})
    return manifest


def _reorg_parsed(md_local: Path, parsed_local: Path, manifest: list[dict]) -> int:
    """把 MinerU 下载的 <uid>/ 结果还原成 parsed_local/<book>/<part_xxx>/。"""
    by_id = {m["id"]: m for m in manifest}
    moved = 0
    for sub in md_local.iterdir():
        if not sub.is_dir():
            continue
        m = by_id.get(sub.name)  # mineru._safe_name(uid) == uid（无特殊字符）
        if not m:
            continue
        target = parsed_local / m["book"] / m["part"]
        if target.exists():
            shutil.rmtree(target)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(sub, target)
        moved += 1
    return moved


def cmd_parse(args) -> None:
    out = Path(args.out_dir)
    if not out.exists() or not any(out.iterdir()):
        print(f"[parse][ERROR] {out} 为空，先跑 split")
        return

    work = Path(args.work_dir)
    stage_dir   = work / "stage"
    tasks_dir   = work / "tasks"
    md_local    = work / "md"
    parsed_local = work / "parsed"
    for d in (stage_dir, tasks_dir, md_local, parsed_local):
        d.mkdir(parents=True, exist_ok=True)

    # 1) 唯一短名 staging + manifest
    print(f"[parse] 准备 staging：{stage_dir}")
    manifest = _build_stage(out, stage_dir)
    (work / "manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[parse] 待解析切片 {len(manifest)} 个")

    if args.dry_run:
        print("[parse][dry-run] 跳过 MinerU 提交 / 下载 / 写回")
        return

    api_key = args.mineru_key  # None → mineru 内部回退到 env MINERU_API_KEY

    # 2) 提交 → 等待 → 下载（复用 mineru.py 云端流程）
    print("[parse] MinerU submit …")
    mineru.cmd_submit(SimpleNamespace(
        pdf_dir=str(stage_dir), start=0, end=0,
        tasks_dir=str(tasks_dir), api_key=api_key))

    print("[parse] MinerU status --wait …")
    mineru.cmd_status(SimpleNamespace(
        tasks_dir=str(tasks_dir), api_key=api_key,
        wait=True, interval=args.interval))

    print("[parse] MinerU download …")
    mineru.cmd_download(SimpleNamespace(
        tasks_dir=str(tasks_dir), api_key=api_key,
        output_dir=str(md_local)))

    # 3) 还原结构 → 写回 S3
    n = _reorg_parsed(md_local, parsed_local, manifest)
    print(f"[parse] 还原 {n} 个解析结果到 {parsed_local}（<书名>/<part_xxx>/）")
    if n == 0:
        print("[parse][WARN] 没有可写回的结果，检查 MinerU 解析状态")
        return
    print(f"[parse] 写回 S3 {args.parsed_dest}")
    _rclone_copy(parsed_local, args.parsed_dest, dry_run=False)
    print("[parse] 完成")


# ═══════════════════════════════════════════════════════════════════════════
# all：1→2→3
# ═══════════════════════════════════════════════════════════════════════════

def cmd_all(args) -> None:
    cmd_split(args)
    cmd_upload(args)
    cmd_parse(args)


# ═══════════════════════════════════════════════════════════════════════════
# CLI
# ═══════════════════════════════════════════════════════════════════════════

def _add_common(p: argparse.ArgumentParser) -> None:
    p.add_argument("--src-dir", default=SRC_DIR_DEFAULT, help="原始 PDF 目录")
    p.add_argument("--out-dir", default=OUT_DIR_DEFAULT, help="拆分输出目录 materials_peocess")
    p.add_argument("--pages-per-part", type=int, default=PAGES_PER_PART, help="每片页数（默认20）")
    p.add_argument("--dest", default=S3_SPLIT_DEST_DEFAULT, help="拆分件上传的 S3 目标")
    p.add_argument("--parsed-dest", default=S3_PARSED_DEST_DEFAULT, help="解析结果写回的 S3 目标")
    p.add_argument("--work-dir", default=WORK_ROOT_DEFAULT, help="parse 阶段本地工作目录")
    p.add_argument("--mineru-key", default=None, help="MinerU key 别名/完整 key（默认用 env MINERU_API_KEY）")
    p.add_argument("--interval", type=int, default=20, help="MinerU 轮询间隔秒")
    p.add_argument("--dry-run", action="store_true", help="只打印计划，不实际执行")


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        description="通用合金文献入库前处理：拆分 → 上传 S3 → MinerU 解析 → 写回 S3",
        formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = parser.add_subparsers(dest="command", required=True)
    for name, fn in (("split", cmd_split), ("upload", cmd_upload),
                     ("parse", cmd_parse), ("all", cmd_all)):
        sp = sub.add_parser(name, help=fn.__doc__)
        _add_common(sp)
        sp.set_defaults(func=fn)

    args = parser.parse_args(argv)
    args.func(args)
    return 0


if __name__ == "__main__":
    sys.exit(main())
