#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""content_store_remote.py —— 可移植内容库的远程后端（Ceph S3 桶）。

设计原则
--------
• 建库期 push_store：用 rclone copy（增量、幂等、断点续传、--transfers 16 并发），
  一次性批量上传，rclone 进程启动开销 ~1s 在整批传输中可忽略不计。
• 查询期 fetch_file：用 boto3 直连 Ceph S3（连接池复用，热路径 ~10-35ms/文件），
  绕过 rclone subprocess 每次 ~1.1s 的进程启动开销（实测 boto3 比 rclone 快 17-120x）。
• fetch_files_parallel：对一批 paper_id 并发拉取（ThreadPoolExecutor），
  5 篇并发约 75ms，同等 rclone 串行需 ~6300ms。

凭据优先级
----------
1. 环境变量（CEPH_ENDPOINT / CEPH_ACCESS_KEY / CEPH_SECRET_KEY）—— CI/云部署首选。
2. rclone.conf 自动解析（xlc-hdd2 远端，零额外配置，复用步骤⑤已有设置）。
3. rclone subprocess fallback（boto3 不可用时）。

远程布局（与本地 content_store 镜像）
--------------------------------------
  <bucket>/<remote_prefix>/<paper_id>/full.md
  <bucket>/<remote_prefix>/<paper_id>/<原名>.pdf

默认 bucket = hangtian-kxfx，prefix = content_store，rclone remote name = xlc-hdd2。
"""
from __future__ import annotations

import configparser
import os
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# ─── 默认值 ───────────────────────────────────────────────────────────────────
DEFAULT_REMOTE_BASE    = os.environ.get("CONTENT_STORE_REMOTE", "xlc-hdd2:hangtian-kxfx")
DEFAULT_REMOTE_PREFIX  = os.environ.get("CONTENT_STORE_REMOTE_PREFIX", "content_store")
DEFAULT_RCLONE_BIN     = os.environ.get("RCLONE_BIN", "rclone")
DEFAULT_RCLONE_REMOTE  = os.environ.get("RCLONE_REMOTE_NAME", "xlc-hdd2")

# ─── boto3 S3 客户端（延迟初始化，模块级单例，线程安全）──────────────────────
import threading as _threading
_s3_client = None
_s3_bucket: Optional[str] = None
_s3_lock = _threading.Lock()


def _rclone_conf_path() -> str:
    """返回 rclone.conf 路径（跨平台）。"""
    # Windows: %APPDATA%\rclone\rclone.conf
    appdata = os.environ.get("APPDATA", "")
    win_path = os.path.join(appdata, "rclone", "rclone.conf") if appdata else ""
    if win_path and os.path.exists(win_path):
        return win_path
    # Linux/Mac: ~/.config/rclone/rclone.conf
    xdg = os.environ.get("XDG_CONFIG_HOME", os.path.expanduser("~/.config"))
    return os.path.join(xdg, "rclone", "rclone.conf")


def _parse_rclone_s3_creds(remote_name: str = DEFAULT_RCLONE_REMOTE
                            ) -> Tuple[str, str, str, str]:
    """从 rclone.conf 读取 S3 凭据：(endpoint, bucket, access_key, secret_key)。

    返回空字符串表示未找到。
    """
    conf = configparser.ConfigParser()
    conf.read(_rclone_conf_path(), encoding="utf-8")
    if remote_name not in conf:
        return "", "", "", ""
    sect = conf[remote_name]
    endpoint   = sect.get("endpoint", "").rstrip("/")
    access_key = sect.get("access_key_id", "")
    secret_key = sect.get("secret_access_key", "")
    # bucket 可从 DEFAULT_REMOTE_BASE 解出
    base = DEFAULT_REMOTE_BASE
    bucket = base.split(":", 1)[1].lstrip("/") if ":" in base else ""
    return endpoint, bucket, access_key, secret_key


def _get_s3_client():
    """返回复用的 boto3 S3 client（含连接池）；不可用时返回 None。线程安全单例。"""
    global _s3_client, _s3_bucket
    if _s3_client is not None:
        return _s3_client, _s3_bucket
    with _s3_lock:
        if _s3_client is not None:  # double-checked locking
            return _s3_client, _s3_bucket

    # 1. 环境变量
    endpoint   = os.environ.get("CEPH_ENDPOINT", "")
    access_key = os.environ.get("CEPH_ACCESS_KEY", "")
    secret_key = os.environ.get("CEPH_SECRET_KEY", "")
    bucket     = os.environ.get("CEPH_BUCKET", "")

    # 2. rclone.conf fallback
    if not (endpoint and access_key and secret_key):
        ep2, bk2, ak2, sk2 = _parse_rclone_s3_creds()
        endpoint   = endpoint   or ep2
        access_key = access_key or ak2
        secret_key = secret_key or sk2
        bucket     = bucket     or bk2

    if not (endpoint and access_key and secret_key and bucket):
        return None, None

    try:
        import boto3
        _s3_client = boto3.client(
            "s3",
            endpoint_url=endpoint,
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key,
            region_name="us-east-1",
        )
        _s3_bucket = bucket
        return _s3_client, _s3_bucket
    except Exception:
        return None, None


def _s3_key(paper_id: str, filename: str,
            remote_prefix: str = DEFAULT_REMOTE_PREFIX) -> str:
    prefix = remote_prefix.strip("/")
    return f"{prefix}/{paper_id}/{filename}" if prefix else f"{paper_id}/{filename}"


# ─── 公共 API ────────────────────────────────────────────────────────────────

def rclone_available(rclone_bin: str = DEFAULT_RCLONE_BIN) -> bool:
    if shutil.which(rclone_bin) is None:
        return False
    try:
        subprocess.run([rclone_bin, "version"],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                       check=True, timeout=20)
        return True
    except (subprocess.SubprocessError, OSError):
        return False


def remote_dir(paper_id: str,
               remote_base: str = DEFAULT_REMOTE_BASE,
               remote_prefix: str = DEFAULT_REMOTE_PREFIX) -> str:
    prefix = remote_prefix.strip("/")
    base = remote_base.rstrip("/")
    return f"{base}/{prefix}/{paper_id}" if prefix else f"{base}/{paper_id}"


def push_store(local_store: Path,
               remote_base: str = DEFAULT_REMOTE_BASE,
               remote_prefix: str = DEFAULT_REMOTE_PREFIX,
               rclone_bin: str = DEFAULT_RCLONE_BIN,
               transfers: int = 16,
               extra_args: Optional[List[str]] = None) -> bool:
    """建库期：把本地 content_store 整目录增量同步到远程（rclone copy）。

    一次性批量传输，rclone 的断点续传和 --transfers 并发适合这个场景；
    进程启动开销 ~1s 在 GB 级传输中可忽略不计。
    """
    if not local_store.exists() or not any(local_store.iterdir()):
        print(f"[remote][warn] 本地内容库为空，无需上传: {local_store}")
        return False
    if not rclone_available(rclone_bin):
        print("[remote][warn] 找不到可用的 rclone，跳过远程上传。"
              "装好 rclone 并配好远端后重跑（见 README 步骤⑤ (5b)）。")
        return False

    prefix = remote_prefix.strip("/")
    base = remote_base.rstrip("/")
    dest = f"{base}/{prefix}" if prefix else base
    cmd = [rclone_bin, "copy", str(local_store), dest,
           "--transfers", str(transfers), "--progress"]
    if extra_args:
        cmd += extra_args
    print(f"[remote] rclone copy {local_store}  →  {dest}")
    try:
        proc = subprocess.run(cmd)
    except OSError as e:
        print(f"[remote][warn] rclone 执行失败: {e}")
        return False
    if proc.returncode != 0:
        print(f"[remote][warn] rclone copy 返回码 {proc.returncode}，远程上传未完成")
        return False
    print(f"[remote] 上传完成 → {dest}")
    return True


def fetch_file(paper_id: str, filename: str, dest_path: Path,
               remote_prefix: str = DEFAULT_REMOTE_PREFIX,
               timeout_s: int = 60,
               # 以下参数保留供 rclone fallback 使用
               remote_base: str = DEFAULT_REMOTE_BASE,
               rclone_bin: str = DEFAULT_RCLONE_BIN) -> bool:
    """查询期：把远程单个文件拉到本地缓存路径 dest_path。

    优先 boto3（~10-70ms，复用连接池），不可用时退回 rclone subprocess（~1.2s）。
    成功且文件落地返回 True；远程无此文件 / 网络失败 → 返回 False（调用方决定回退）。
    """
    if not paper_id or not filename:
        return False

    dest_path.parent.mkdir(parents=True, exist_ok=True)

    # ── 路径 1：boto3 直连（推荐，连接池复用，热路径 ~10-35ms）──────────────────
    s3, bucket = _get_s3_client()
    if s3 is not None:
        key = _s3_key(paper_id, filename, remote_prefix)
        try:
            s3.download_file(bucket, key, str(dest_path))
            return dest_path.exists()
        except Exception:
            # 文件不存在（404 NoSuchKey）或网络问题 → 静默返回 False
            return False

    # ── 路径 2：rclone subprocess fallback（~1.2s，boto3 不可用时）──────────────
    if not rclone_available(rclone_bin):
        return False
    src = f"{remote_dir(paper_id, remote_base, remote_prefix)}/{filename}"
    try:
        proc = subprocess.run(
            [rclone_bin, "copyto", src, str(dest_path)],
            stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
            timeout=timeout_s,
        )
    except (subprocess.SubprocessError, OSError):
        return False
    return proc.returncode == 0 and dest_path.exists()


def fetch_files_parallel(
    tasks: List[Tuple[str, str, Path]],
    remote_prefix: str = DEFAULT_REMOTE_PREFIX,
    max_workers: int = 8,
) -> Dict[Tuple[str, str], bool]:
    """并发拉取多个文件（查询期批量预热缓存）。

    tasks: [(paper_id, filename, dest_path), ...]
    返回 {(paper_id, filename): success_bool}

    典型用法：查询结果含 top-k=5 篇论文时，并发拉取而非串行，
    实测 5 文件并发约 75ms（vs 串行 boto3 ~250ms，vs 串行 rclone ~6300ms）。
    """
    results: Dict[Tuple[str, str], bool] = {}
    if not tasks:
        return results

    def _fetch(paper_id: str, filename: str, dest: Path) -> Tuple[Tuple[str, str], bool]:
        ok = fetch_file(paper_id, filename, dest, remote_prefix=remote_prefix)
        return (paper_id, filename), ok

    with ThreadPoolExecutor(max_workers=min(max_workers, len(tasks))) as pool:
        futs = {pool.submit(_fetch, pid, fn, dp): (pid, fn)
                for pid, fn, dp in tasks}
        for fut in as_completed(futs):
            try:
                key, ok = fut.result()
            except Exception:
                key = futs[fut]
                ok = False
            results[key] = ok
    return results


# ─────────────────────────────────────────────────────────────────────────────
# 构建产物远程存储（向量索引 / 图谱 DB / 知识库 DB）
# ─────────────────────────────────────────────────────────────────────────────
# 与 content_store（源文 full.md + PDF）使用同一个桶，但用不同前缀隔离：
#   <bucket>/content_store/<paper_id>/full.md   ← 源文（前者已有）
#   <bucket>/artifacts/kb_index/faiss.index     ← 向量索引（本节新增）
#   <bucket>/artifacts/kb_data/kb.db            ← 知识库 SQLite
#   <bucket>/artifacts/kgqa/kgqa.db             ← 图谱 SQLite
#   <bucket>/artifacts/kgqa/retriever.pkl       ← 图谱检索器
#   ...

DEFAULT_ARTIFACTS_PREFIX = os.environ.get("ARTIFACTS_REMOTE_PREFIX", "artifacts")


def _artifact_s3_key(subpath: str,
                     remote_prefix: str = DEFAULT_ARTIFACTS_PREFIX) -> str:
    """构造产物文件的 S3 key，如 'artifacts/kb_index/faiss.index'。"""
    prefix = remote_prefix.strip("/")
    subpath = subpath.lstrip("/")
    return f"{prefix}/{subpath}" if prefix else subpath


class _ProgressBar:
    """boto3 download_file 回调：大文件下载进度显示（MB 级别）。"""

    def __init__(self, label: str, total_bytes: int):
        self._label = label
        self._seen = 0
        self._total = total_bytes

    def __call__(self, n: int) -> None:
        self._seen += n
        mb = self._seen / 1_048_576
        if self._total:
            pct = min(100, self._seen * 100 // self._total)
            tmb = self._total / 1_048_576
            print(f"\r  [{self._label}] {mb:.0f}/{tmb:.0f} MB ({pct}%)",
                  end="", flush=True)
        else:
            print(f"\r  [{self._label}] {mb:.0f} MB", end="", flush=True)

    def done(self) -> None:
        print()  # 换行


def push_artifacts(
    local_dirs: List[Tuple[Path, str]],
    remote_base: str = DEFAULT_REMOTE_BASE,
    remote_prefix: str = DEFAULT_ARTIFACTS_PREFIX,
    rclone_bin: str = DEFAULT_RCLONE_BIN,
    transfers: int = 8,
    extra_args: Optional[List[str]] = None,
) -> bool:
    """建库后把产物目录批量推到远程 Ceph（rclone copy 增量幂等）。

    local_dirs: [(本地目录路径, 远程子目录名), ...]
      例：[(Path("kb_mvp/index"), "kb_index"),
           (Path("kb_mvp/data"),  "kb_data"),
           (Path("scientific_kgqa/artifacts"), "kgqa")]

    远程目标 = <remote_base>/<remote_prefix>/<remote_subdir>/
    e.g. xlc-hdd2:hangtian-kxfx/artifacts/kb_index/

    rclone 适合 GB 级批量传输（断点续传、--transfers 并发），进程只启动一次。
    返回所有目录是否均上传成功（任一失败即返回 False）。
    """
    if not rclone_available(rclone_bin):
        print("[artifacts][warn] 找不到可用的 rclone，跳过产物上传。")
        return False

    prefix = remote_prefix.strip("/")
    base = remote_base.rstrip("/")
    all_ok = True

    for local_dir, subdir in local_dirs:
        if not Path(local_dir).exists():
            print(f"[artifacts][warn] 本地目录不存在，跳过: {local_dir}")
            continue
        dest = f"{base}/{prefix}/{subdir}" if prefix else f"{base}/{subdir}"
        cmd = [rclone_bin, "copy", str(local_dir), dest,
               "--transfers", str(transfers), "--progress"]
        if extra_args:
            cmd += extra_args
        print(f"[artifacts] rclone copy {local_dir}  →  {dest}")
        try:
            proc = subprocess.run(cmd)
        except OSError as e:
            print(f"[artifacts][warn] rclone 执行失败: {e}")
            all_ok = False
            continue
        if proc.returncode != 0:
            print(f"[artifacts][warn] rclone copy 返回码 {proc.returncode}: {local_dir}")
            all_ok = False
        else:
            print(f"[artifacts] 上传完成 → {dest}")

    return all_ok


def pull_artifact(
    remote_subpath: str,
    dest_path: Path,
    remote_base: str = DEFAULT_REMOTE_BASE,
    remote_prefix: str = DEFAULT_ARTIFACTS_PREFIX,
    show_progress: bool = True,
    timeout_s: int = 1800,
    rclone_bin: str = DEFAULT_RCLONE_BIN,
) -> bool:
    """从 Ceph 拉单个产物文件（boto3 multipart 自动分片，适合 GB 级大文件）。

    remote_subpath: 相对 remote_prefix 的路径，如 "kb_index/faiss.index"
    boto3 TransferManager 默认对 > 8 MB 文件自动启用多分片并发下载。
    boto3 不可用时回退 rclone copyto（启动开销 ~1s，大文件可接受）。
    """
    if not remote_subpath:
        return False
    dest_path = Path(dest_path)
    dest_path.parent.mkdir(parents=True, exist_ok=True)

    # ── 路径 1：boto3 直连（多分片自动并发，大文件首选）──────────────────────
    s3, bucket = _get_s3_client()
    if s3 is not None:
        key = _artifact_s3_key(remote_subpath, remote_prefix)
        try:
            # 获取文件大小以显示进度
            total_bytes = 0
            if show_progress:
                try:
                    head = s3.head_object(Bucket=bucket, Key=key)
                    total_bytes = head.get("ContentLength", 0)
                except Exception:
                    pass
            cb = None
            if show_progress:
                label = Path(remote_subpath).name
                cb = _ProgressBar(label, total_bytes)
            s3.download_file(bucket, key, str(dest_path),
                             Callback=cb if cb else None)
            if cb:
                cb.done()
            return dest_path.exists()
        except Exception as e:
            # NoSuchKey / 网络失败 → 静默返回 False
            if dest_path.exists():
                dest_path.unlink(missing_ok=True)
            return False

    # ── 路径 2：rclone copyto fallback ────────────────────────────────────────
    if not rclone_available(rclone_bin):
        return False
    prefix = remote_prefix.strip("/")
    base = remote_base.rstrip("/")
    src = (f"{base}/{prefix}/{remote_subpath.lstrip('/')}"
           if prefix else f"{base}/{remote_subpath.lstrip('/')}")
    try:
        proc = subprocess.run(
            [rclone_bin, "copyto", src, str(dest_path)],
            stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
            timeout=timeout_s,
        )
    except (subprocess.SubprocessError, OSError):
        return False
    return proc.returncode == 0 and dest_path.exists()


def pull_artifacts_parallel(
    tasks: List[Tuple[str, Path]],
    remote_base: str = DEFAULT_REMOTE_BASE,
    remote_prefix: str = DEFAULT_ARTIFACTS_PREFIX,
    max_workers: int = 4,
    show_progress: bool = True,
) -> Dict[str, bool]:
    """server 启动时并发拉取多个产物文件。

    tasks: [(remote_subpath, dest_path), ...]
    返回 {remote_subpath: success_bool}

    max_workers=4：产物文件 GB 级，网络带宽是瓶颈，4 并发即可打满；
    多开反而会产生 TCP 拥塞。
    """
    results: Dict[str, bool] = {}
    if not tasks:
        return results

    def _pull(subpath: str, dest: Path) -> Tuple[str, bool]:
        ok = pull_artifact(subpath, dest,
                           remote_base=remote_base,
                           remote_prefix=remote_prefix,
                           show_progress=show_progress)
        return subpath, ok

    with ThreadPoolExecutor(max_workers=min(max_workers, len(tasks))) as pool:
        futs = {pool.submit(_pull, sp, dp): sp for sp, dp in tasks}
        for fut in as_completed(futs):
            try:
                subpath, ok = fut.result()
            except Exception:
                subpath = futs[fut]
                ok = False
            results[subpath] = ok
    return results

