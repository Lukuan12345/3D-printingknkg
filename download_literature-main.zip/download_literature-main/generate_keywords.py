"""
Keyword Generator

Steps:
1. Read query (+ optional reference), call LLM to generate compound search query.
2. Parse LLM output into dimensions (each dimension = ordered list of AND-connected terms).
3. Print dimensions to console.

Usage:
    python generate_keywords.py \
        --prompt prompt/keyword_generate.txt \
        --query query/try1.txt \
        --reference reference/ \
        [--api-key ...] [--base-url ...] [--model ...]
"""

import os
import re
import sys
import glob
import argparse
from typing import List, Optional

from openai import OpenAI
from tenacity import retry, stop_after_attempt, wait_random_exponential, retry_if_exception_type

from env_bootstrap import load_env
load_env()


def read_text_file(file_path: str) -> str:
    with open(file_path, "r", encoding="utf-8") as f:
        return f.read().strip()


def parse_file_to_markdown(file_path: str) -> str:
    ext = os.path.splitext(file_path)[1].lower()
    if ext == ".pdf":
        try:
            import pymupdf4llm
            return pymupdf4llm.to_markdown(file_path)
        except ImportError:
            import fitz
            doc = fitz.open(file_path)
            text_parts = []
            for page in doc:
                text_parts.append(page.get_text())
            doc.close()
            return "\n\n".join(text_parts)
    elif ext in (".md", ".txt", ".text"):
        return read_text_file(file_path)
    elif ext == ".docx":
        try:
            import docx
            doc = docx.Document(file_path)
            return "\n\n".join(p.text for p in doc.paragraphs if p.text.strip())
        except ImportError:
            print(f"[WARN] python-docx not installed, skipping {file_path}", file=sys.stderr)
            return ""
    else:
        try:
            return read_text_file(file_path)
        except Exception:
            print(f"[WARN] Cannot parse {file_path}, skipping", file=sys.stderr)
            return ""


def load_references(ref_dir: str) -> str:
    if not os.path.isdir(ref_dir):
        print(f"[WARN] Reference directory does not exist: {ref_dir}", file=sys.stderr)
        return ""

    ref_files = sorted(glob.glob(os.path.join(ref_dir, "*")))
    ref_files = [f for f in ref_files if os.path.isfile(f)]

    if not ref_files:
        return ""

    parts: List[str] = []
    for fpath in ref_files:
        fname = os.path.basename(fpath)
        content = parse_file_to_markdown(fpath)
        if content:
            parts.append(f"### {fname}\n\n{content}")

    return "\n\n---\n\n".join(parts)


def build_prompt(template: str, question: str, reference: str) -> str:
    if reference:
        return template.replace("{question}", question).replace("{reference}", reference)
    else:
        return template.replace("{question}", question).replace("{reference}", "N/A")


@retry(
    stop=stop_after_attempt(3),
    wait=wait_random_exponential(multiplier=1, max=60),
    retry=retry_if_exception_type(Exception),
    reraise=True,
)
def call_llm(client: OpenAI, model: str, prompt_content: str, max_tokens: int) -> str:
    messages = [{"role": "user", "content": prompt_content}]
    result = client.chat.completions.create(
        model=model,
        messages=messages,
        max_tokens=max_tokens,
    )
    return result.choices[0].message.content.strip()


# ===================== LLM 输出解析 =====================

_DIM_BRACKET_RE = re.compile(
    r"Dimension\s+\d+\s*:\s*\[([^\]]+)\]",
    re.IGNORECASE,
)
_TERM_QUOTED_RE = re.compile(r'["\']([^"\']+)["\']')
_FINAL_QUERY_RE = re.compile(
    r"(?:\*+\s*)?final\s*query\s*:?(?:\s*\*+)?\s*",
    re.IGNORECASE,
)
_DIM_HEADER_RE = re.compile(
    r"^\s*(?:\*+\s*)?Dimension\s+(\d+)\s*:?\s*([^\n*]*?)\s*\**\s*$",
    re.IGNORECASE | re.MULTILINE,
)
_NUM_ITEM_RE = re.compile(r"^\s*\d+\s*[.)、]\s*(.+?)\s*$")


def _clean_term(term: str) -> str:
    """Normalize a term: strip, collapse whitespace, keep letters/digits/CJK/space only."""
    t = term.strip().strip('"').strip("'").strip()
    # 去除 markdown 标记和常见前后缀
    t = re.sub(r"^[\-\*\d\.\)\(\s]+", "", t)
    t = re.sub(r"[\*`]+", "", t)
    t = re.sub(r"\s+", " ", t)
    # 只保留字母/数字/CJK/空格
    t = re.sub(r"[^A-Za-z0-9一-鿿 ]+", " ", t)
    t = re.sub(r"\s+", " ", t).strip()
    return t


def _parse_dim_bracket_block(block: str) -> List[str]:
    """Parse contents inside `[...]`, preferring quoted terms, else comma-split."""
    quoted = _TERM_QUOTED_RE.findall(block)
    if quoted:
        return [t for t in (_clean_term(q) for q in quoted) if t]
    parts = [p for p in (s.strip() for s in block.split(",")) if p]
    return [t for t in (_clean_term(p) for p in parts) if t]


def _parse_final_query(text: str) -> List[List[str]]:
    """Find `Final query:` label and parse `(A AND B) OR (C AND D)` expression."""
    m = _FINAL_QUERY_RE.search(text)
    if not m:
        return []
    tail = text[m.end():].lstrip()
    if not tail:
        return []
    # 取到下一个空行（段落）为止
    paragraph = re.split(r"\n\s*\n", tail, maxsplit=1)[0].strip()
    # 去除行尾 markdown 包装
    paragraph = paragraph.replace("`", "").strip()
    if not paragraph:
        return []
    # 按顶层 ") OR (" 切分；若无括号则按 " OR " 切
    if ") OR (" in paragraph.upper():
        groups = re.split(r"\)\s*OR\s*\(", paragraph, flags=re.IGNORECASE)
    else:
        groups = re.split(r"\s+OR\s+", paragraph, flags=re.IGNORECASE)
    dims: List[List[str]] = []
    for g in groups:
        g = g.strip().strip("()").strip()
        if not g:
            continue
        terms = re.split(r"\s+AND\s+|\s*&&\s*", g, flags=re.IGNORECASE)
        cleaned = [_clean_term(x) for x in terms]
        cleaned = [t for t in cleaned if t]
        if len(cleaned) >= 1:
            dims.append(cleaned)
    return dims


def _parse_bracket_dims(text: str) -> List[List[str]]:
    """Fallback 1: `Dimension N: [\"a\", \"b\"]` style."""
    dims: List[List[str]] = []
    for m in _DIM_BRACKET_RE.finditer(text):
        terms = _parse_dim_bracket_block(m.group(1))
        if len(terms) >= 2:
            dims.append(terms)
    return dims


def _parse_markdown_dims(text: str) -> List[List[str]]:
    """Fallback 2: `*Dimension N: Name*\\n1. term\\n2. term\\n...` style."""
    # 收集所有 Dimension 标题行的位置
    headers = list(_DIM_HEADER_RE.finditer(text))
    if not headers:
        return []
    dims: List[List[str]] = []
    for i, h in enumerate(headers):
        start = h.end()
        end = headers[i + 1].start() if i + 1 < len(headers) else len(text)
        block = text[start:end]
        terms: List[str] = []
        for line in block.splitlines():
            # 遇到下一节标题/空行后的非列表行就停
            if line.strip().startswith("**") and "dimension" not in line.lower():
                break
            m = _NUM_ITEM_RE.match(line)
            if m:
                t = _clean_term(m.group(1))
                if t:
                    terms.append(t)
        if len(terms) >= 2:
            dims.append(terms)
    return dims


def parse_dimensions(llm_output: str) -> List[List[str]]:
    """
    Extract ordered dimensions -> list of term lists.
    Try in order:
      1. `Final query: (A AND B) OR (C AND D)` (primary, most explicit)
      2. `Dimension N: [\"a\", \"b\"]` bracket style
      3. `*Dimension N: Name*` + `1. term` numbered list
    """
    for parser in (_parse_final_query, _parse_bracket_dims, _parse_markdown_dims):
        dims = parser(llm_output)
        # 过滤掉空维度
        dims = [d for d in dims if d]
        if dims:
            return dims
    return []


# ===================== 主流程 =====================

def main():
    parser = argparse.ArgumentParser(
        description="LLM 生成检索关键词并输出维度结果"
    )
    parser.add_argument("--prompt", required=True, help="Path to the prompt template file")
    parser.add_argument("--query", required=True, help="Path to the query file")
    parser.add_argument("--reference", default=None, help="Path to the reference directory (optional)")
    parser.add_argument("--api-key", default=os.environ.get("LLM_API_KEY", ""),
                        help="LLM API key (or set LLM_API_KEY env var)")
    parser.add_argument("--base-url", default=os.environ.get("LLM_BASE_URL", "http://43.153.42.7:3001/v1"),
                        help="LLM API base URL (or set LLM_BASE_URL env var)")
    parser.add_argument("--model", default=os.environ.get("LLM_MODEL", "gemini-3.1-pro-preview"),
                        help="Model name (or set LLM_MODEL env var)")
    parser.add_argument("--max-tokens", type=int, default=8192, help="Max tokens for LLM response")
    args = parser.parse_args()

    if not args.api_key:
        print("[ERROR] LLM API key is missing. Pass --api-key or set LLM_API_KEY env var.", file=sys.stderr)
        sys.exit(1)

    if not os.path.isfile(args.query):
        print(f"[ERROR] Query file not found: {args.query}", file=sys.stderr)
        sys.exit(1)
    question = read_text_file(args.query)
    print(f"[INFO] Loaded query ({len(question)} chars)")

    if not os.path.isfile(args.prompt):
        print(f"[ERROR] Prompt template not found: {args.prompt}", file=sys.stderr)
        sys.exit(1)
    template = read_text_file(args.prompt)
    print(f"[INFO] Loaded prompt template ({len(template)} chars)")

    reference = ""
    if args.reference:
        reference = load_references(args.reference)
        if reference:
            print(f"[INFO] Loaded references ({len(reference)} chars)")
        else:
            print("[INFO] No reference content found, proceeding without references")
    else:
        print("[INFO] No reference directory provided, proceeding without references")

    final_prompt = build_prompt(template, question, reference)

    client = OpenAI(api_key=args.api_key, base_url=args.base_url, timeout=600)

    print(f"[INFO] Calling LLM (model={args.model}, max_tokens={args.max_tokens}) ...")
    response = call_llm(client, args.model, final_prompt, args.max_tokens)

    dimensions = parse_dimensions(response)
    if not dimensions:
        print("[ERROR] 无法从 LLM 输出中解析出 dimensions。", file=sys.stderr)
        sys.exit(2)

    print("\n" + "=" * 60)
    print(f"已生成 {len(dimensions)} 个检索维度:")
    print("=" * 60)
    for i, terms in enumerate(dimensions, 1):
        and_expr = " AND ".join(terms)
        print(f"  Dimension {i}: [{', '.join(terms)}]")
        print(f"    => ({and_expr})")
    print("=" * 60)


if __name__ == "__main__":
    main()
