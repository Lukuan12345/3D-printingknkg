"""
维度关键词 SQL 检索

用法:
    python dim_search.py --dims-file dims/q2.txt --output ./results

配置文件支持两种段:

1) Journals (期刊白名单, 可选):
       Journals:
       [
           "Acta Materialia",
           "Nature Materials",
           ...
       ]
   - 若存在,则把它作为 WHERE 中的期刊过滤条件 (LOWER(journal) IN (...))
   - library 表使用 magazine 字段, meta 表使用 journal_name 字段

2) Dimensions (维度,逐个生成一个 CSV):
   2a) 简写:
       Dimension N: [term1, term2, term3, ...]
       - 1-2 个词: 直接 AND 查询一次
       - 3+ 个词: 两两组合分别查询, 每次最多 ROW_LIMIT 条, 最终合并去重

   2b) 多层复合:
       Dimension N:
           layer1: [t1, t2, t3] M
           layer2: [t1, t2] M
           ...
       - 每层 [] 后的数字 M = 该层至少要命中的关键词数 (at-least-M of N)
       - 层与层之间是 AND 关系, 所有层都必须满足
       - at-least-M 展开为: 所有 C(N, M) 大小为 M 的组合 AND 起来再 OR
         M = N 时退化为简单 AND, M = 1 时退化为简单 OR

输出: 每个维度生成 dim{N}.csv
"""

import argparse
import json
import os
import re
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from itertools import combinations
from typing import List, Optional, Tuple
from urllib.parse import quote_plus

import pandas as pd
from sqlalchemy import create_engine, text

from env_bootstrap import load_env
load_env()

# ===================== 数据库配置 =====================

STARROCKS_CONFIG = {
    "host": os.environ.get("STARROCKS_HOST", "10.12.105.139"),
    "port": int(os.environ.get("STARROCKS_PORT", "30030")),
    "user": os.environ.get("STARROCKS_USER", "ai4phys"),
    "password": os.environ.get("STARROCKS_PASSWORD", ""),
    "database": os.environ.get("STARROCKS_DATABASE", "ads"),
}

if not STARROCKS_CONFIG["password"]:
    raise RuntimeError(
        "STARROCKS_PASSWORD is not set. Export it before running, e.g.\n"
        "  export STARROCKS_PASSWORD=...  (Linux/macOS)\n"
        "  $env:STARROCKS_PASSWORD = '...'  (PowerShell)"
    )

ROW_LIMIT = 200000

# 简写维度 3+ 词时的两两查询并发数（受 SQLAlchemy 连接池 pool_size+max_overflow=16 约束）
SEARCH_WORKERS = 8

_ENGINE = None


def get_engine():
    global _ENGINE
    if _ENGINE is None:
        cfg = STARROCKS_CONFIG
        user = quote_plus(cfg["user"])
        pwd = quote_plus(cfg["password"])
        url = (
            f"mysql+pymysql://{user}:{pwd}"
            f"@{cfg['host']}:{cfg['port']}/{cfg['database']}"
            "?charset=utf8mb4"
        )
        _ENGINE = create_engine(
            url,
            pool_recycle=3600,
            pool_pre_ping=True,
            pool_size=8,
            max_overflow=8,
        )
    return _ENGINE


# ===================== 配置文件解析 =====================

# Dimension 简写:  Dimension N: [a, b, c]
_DIM_SIMPLE_RE = re.compile(
    r"Dimension\s+(\d+)\s*[:：]\s*\**\s*\[([^\]]+)\]",
    re.IGNORECASE,
)
# Dimension 多层头: Dimension N:   (后面不跟 [)
_DIM_LAYERED_HEADER_RE = re.compile(
    r"^\s*Dimension\s+(\d+)\s*[:：]\s*\**\s*$",
    re.IGNORECASE | re.MULTILINE,
)
# layer 行: layerK: [a, b, c] M
_LAYER_LINE_RE = re.compile(
    r"^\s*layer\s*(\d+)\s*[:：]\s*\[([^\]]+)\]\s*(\d+)\s*$",
    re.IGNORECASE | re.MULTILINE,
)
_QUOTED_RE = re.compile(r'["\']([^"\']+)["\']')


def _split_terms(block: str) -> List[str]:
    quoted = _QUOTED_RE.findall(block)
    if quoted:
        return [q.strip() for q in quoted if q.strip()]
    return [p.strip() for p in block.split(",") if p.strip()]


def _parse_journals(content: str) -> List[str]:
    """从 `Journals:` 段提取 JSON list, 返回字符串列表; 找不到返回 []."""
    m = re.search(r"Journals?\s*[:：]\s*", content, re.IGNORECASE)
    if not m:
        return []
    # 从 ':' 之后第一个 '[' 开始,做括号配对
    start = content.find("[", m.end())
    if start == -1:
        return []
    depth = 0
    end = -1
    for i in range(start, len(content)):
        ch = content[i]
        if ch == "[":
            depth += 1
        elif ch == "]":
            depth -= 1
            if depth == 0:
                end = i
                break
    if end == -1:
        return []
    raw = content[start : end + 1]
    try:
        return [str(x).strip() for x in json.loads(raw) if str(x).strip()]
    except Exception:
        # 容错: 按引号抓取
        return _split_terms(raw[1:-1])


def parse_config(path: str) -> Tuple[List[str], List[dict]]:
    """
    返回 (journals, dimensions)
    每个 dimension 是 dict:
      简写:  {"kind": "simple", "index": N, "terms": [...]}
      多层:  {"kind": "layered", "index": N, "layers": [{"terms": [...], "min": M}, ...]}
    维度按出现顺序排列。
    """
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()

    journals = _parse_journals(content)

    # 1) 先把"简写维度"全部抓出来 -> (start_pos, dim_dict)
    occurrences: List[Tuple[int, dict]] = []
    consumed_spans: List[Tuple[int, int]] = []

    for m in _DIM_SIMPLE_RE.finditer(content):
        idx = int(m.group(1))
        terms = _split_terms(m.group(2))
        if terms:
            occurrences.append(
                (m.start(), {"kind": "simple", "index": idx, "terms": terms})
            )
            consumed_spans.append((m.start(), m.end()))

    # 2) 找"多层维度"的头, 后续紧接的 layer 行组成 layers
    headers = list(_DIM_LAYERED_HEADER_RE.finditer(content))
    for i, h in enumerate(headers):
        # 跳过已被简写匹配吃掉的位置
        if any(s <= h.start() < e for s, e in consumed_spans):
            continue
        block_start = h.end()
        block_end = headers[i + 1].start() if i + 1 < len(headers) else len(content)
        # 也要在遇到下一个 Dimension 简写时截止
        for ms, me in consumed_spans:
            if h.end() <= ms < block_end:
                block_end = ms
        block = content[block_start:block_end]

        layers = []
        for lm in _LAYER_LINE_RE.finditer(block):
            terms = _split_terms(lm.group(2))
            try:
                min_n = int(lm.group(3))
            except ValueError:
                continue
            if terms:
                min_n = max(1, min(min_n, len(terms)))
                layers.append({"terms": terms, "min": min_n})
        if layers:
            idx = int(h.group(1))
            occurrences.append(
                (h.start(), {"kind": "layered", "index": idx, "layers": layers})
            )

    occurrences.sort(key=lambda x: x[0])
    dimensions = [d for _, d in occurrences]
    return journals, dimensions


# ===================== SQL 构建 =====================

def _escape(s: str) -> str:
    return s.replace("\\", "\\\\").replace("'", "''")


def _term_clause(term: str) -> str:
    """
    单个关键词 -> WHERE 子串匹配子句。
    若 term 含 '|',视为同义变体,任意一个变体出现即算命中。
    例: "C-H | C–H | C—H" -> 任一连字符形式都行
    """
    variants = [v.strip() for v in term.split("|") if v.strip()]
    if not variants:
        return "1=0"
    parts = []
    for v in variants:
        t = _escape(v.lower())
        parts.append(f"LOWER(title) LIKE '%{t}%'")
        parts.append(f"LOWER(abstract) LIKE '%{t}%'")
    return "(" + " OR ".join(parts) + ")"


def _and_clause(terms: List[str]) -> str:
    return "(" + " AND ".join(_term_clause(t) for t in terms) + ")"


def _layer_clause(terms: List[str], min_n: int) -> str:
    """
    at-least-M of N => OR of all C(N, M) AND-combinations.
    M == N: 单一 AND
    M == 1: 单一 OR
    """
    n = len(terms)
    min_n = max(1, min(min_n, n))
    if min_n == 1:
        return "(" + " OR ".join(_term_clause(t) for t in terms) + ")"
    if min_n == n:
        return _and_clause(terms)
    combos = [list(c) for c in combinations(terms, min_n)]
    parts = [_and_clause(c) for c in combos]
    return "(" + " OR ".join(parts) + ")"


def _journal_clause(journals: List[str], field: str) -> str:
    if not journals:
        return ""
    lowered = ", ".join("'" + _escape(j.lower()) + "'" for j in journals)
    return f"LOWER({field}) IN ({lowered})"


def _build_union_sql(where_meta: str, where_lib: str) -> str:
    return f"""\
(SELECT doi, title,
        journal_name AS magazine,
        publication_date AS pub_time,
        origin_path
 FROM ads.ads_meta_xinghe_journal_paper_data_acc
 WHERE {where_meta}
 LIMIT {ROW_LIMIT})

UNION

(SELECT doi, title,
        magazine,
        pub_time,
        origin_path
 FROM ads.ads_xinghe_library_acc
 WHERE {where_lib}
 LIMIT {ROW_LIMIT})"""


def _wrap_where(keyword_where: str, journals: List[str], journal_field: str) -> str:
    j = _journal_clause(journals, journal_field)
    return f"({j}) AND ({keyword_where})" if j else keyword_where


# ===================== 查询执行 =====================

EMPTY_COLUMNS = ["doi", "title", "magazine", "pub_time", "origin_path"]


def _run_sql(sql: str) -> pd.DataFrame:
    try:
        df = pd.read_sql(text(sql), get_engine())
        return df.fillna("")
    except Exception as e:
        print(f"  [ERROR] SQL 失败: {e}")
        return pd.DataFrame()


def _run_keyword_where(keyword_where: str, journals: List[str]) -> pd.DataFrame:
    where_meta = _wrap_where(keyword_where, journals, "journal_name")
    where_lib = _wrap_where(keyword_where, journals, "magazine")
    sql = _build_union_sql(where_meta, where_lib)
    return _run_sql(sql)


def _dedup(frames: List[pd.DataFrame]) -> pd.DataFrame:
    if not frames:
        return pd.DataFrame(columns=EMPTY_COLUMNS)
    combined = pd.concat(frames, ignore_index=True).fillna("")
    combined["_key"] = combined.apply(
        lambda r: r["doi"] if r["doi"] else r["title"], axis=1
    )
    combined = (
        combined[combined["_key"] != ""]
        .drop_duplicates(subset=["_key"])
        .drop(columns=["_key"])
        .reset_index(drop=True)
    )
    return combined


def search_simple(terms: List[str], journals: List[str]) -> pd.DataFrame:
    if len(terms) <= 2:
        pairs = [terms]
    else:
        pairs = [list(combo) for combo in combinations(terms, 2)]

    # 单次查询：直接跑，无需起线程池
    if len(pairs) == 1:
        pair = pairs[0]
        df = _run_keyword_where(_and_clause(pair), journals)
        print(f"  -> 查询: {' AND '.join(pair)}  =>  {len(df)} 条")
        return _dedup([df]) if not df.empty else pd.DataFrame(columns=EMPTY_COLUMNS)

    # 多对两两组合：并发查询（各查询相互独立，engine 连接池线程安全）
    frames = []
    workers = min(SEARCH_WORKERS, len(pairs))
    with ThreadPoolExecutor(max_workers=workers) as executor:
        future_map = {
            executor.submit(_run_keyword_where, _and_clause(pair), journals): pair
            for pair in pairs
        }
        for future in as_completed(future_map):
            pair = future_map[future]
            label = " AND ".join(pair)
            try:
                df = future.result()
            except Exception as e:
                print(f"  -> 查询: {label}  =>  [ERROR] {e}")
                continue
            print(f"  -> 查询: {label}  =>  {len(df)} 条")
            if not df.empty:
                frames.append(df)
    return _dedup(frames)


def search_layered(layers: List[dict], journals: List[str]) -> pd.DataFrame:
    parts = []
    for i, layer in enumerate(layers, 1):
        terms, m = layer["terms"], layer["min"]
        print(f"  -> layer{i}: at-least-{m} of {len(terms)} {terms}")
        parts.append(_layer_clause(terms, m))
    where = "(" + " AND ".join(parts) + ")"
    df = _run_keyword_where(where, journals)
    print(f"     {len(df)} 条")
    return _dedup([df]) if not df.empty else pd.DataFrame(columns=EMPTY_COLUMNS)


# ===================== 主程序 =====================

def main():
    parser = argparse.ArgumentParser(description="多维度关键词 SQL 检索，输出 dimN.csv")
    parser.add_argument(
        "--dims-file", required=True,
        help="维度配置文件路径 (支持 Journals + Dimension 简写/分层)",
    )
    parser.add_argument("--output", default=".", help="CSV 输出目录 (默认当前目录)")
    args = parser.parse_args()

    if not os.path.isfile(args.dims_file):
        print(f"[ERROR] 配置文件不存在: {args.dims_file}")
        return

    journals, dimensions = parse_config(args.dims_file)

    if not dimensions:
        print(f"[ERROR] 未能从 {args.dims_file} 解析出任何维度")
        return

    print(f"[INFO] 期刊白名单: {len(journals)} 本")
    if journals:
        for j in journals:
            print(f"       - {j}")
    print(f"[INFO] 从 {args.dims_file} 解析出 {len(dimensions)} 个维度")

    os.makedirs(args.output, exist_ok=True)

    for d in dimensions:
        idx = d["index"]
        print(f"\n{'='*60}")
        if d["kind"] == "simple":
            terms = d["terms"]
            print(f"Dimension {idx} (simple): {terms}")
            if len(terms) > 2:
                pairs = list(combinations(terms, 2))
                print(f"  3+ 词，共 {len(pairs)} 次两两查询")
            print(f"{'='*60}")
            t0 = time.time()
            df = search_simple(terms, journals)
        else:
            print(f"Dimension {idx} (layered): {len(d['layers'])} 层")
            for i, layer in enumerate(d["layers"], 1):
                print(f"  layer{i}: {layer['terms']}  (at-least {layer['min']})")
            print(f"{'='*60}")
            t0 = time.time()
            df = search_layered(d["layers"], journals)

        elapsed = time.time() - t0
        out_path = os.path.join(args.output, f"dim{idx}.csv")
        df.to_csv(out_path, index=False, encoding="utf-8-sig")
        print(f"\n  合计 {len(df)} 条（去重后），已保存: {out_path}  ({elapsed:.2f}s)")

    print("\n全部完成。")


if __name__ == "__main__":
    main()
