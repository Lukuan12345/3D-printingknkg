#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
server.py —— KB/KG 查询服务 FastAPI 入口

启动:
    uvicorn server:app --host 0.0.0.0 --port 8000 --workers 1

后台运行:
    nohup uvicorn server:app --host 0.0.0.0 --port 8000 > server.log 2>&1 &

接口:
    POST /query          → 阻塞等待完整结果（JSON）
    POST /query/stream   → SSE 流式进度 + 最终结果
    GET  /health         → 健康检查
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import queue
import sys
import threading
import time
from pathlib import Path
from typing import Any, AsyncIterator, Dict, Optional

# ── 加载 .env ─────────────────────────────────────────────────────────────────
_ENV_PATH = Path(__file__).resolve().parent / ".env"
if _ENV_PATH.exists():
    with open(_ENV_PATH, encoding="utf-8") as _f:
        for _line in _f:
            _line = _line.strip()
            if "=" in _line and not _line.startswith("#"):
                _k, _v = _line.split("=", 1)
                os.environ.setdefault(_k.strip(), _v.strip())

# ── sys.path ──────────────────────────────────────────────────────────────────
_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(_ROOT))

# ── FastAPI ───────────────────────────────────────────────────────────────────
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, FileResponse
from pydantic import BaseModel, Field

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s  %(message)s",
)
logger = logging.getLogger("kgqa_server")

app = FastAPI(title="KGQA Query Service", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── 单例 Pipeline ─────────────────────────────────────────────────────────────
_pipeline = None
_pipeline_lock: Optional[asyncio.Lock] = None
_init_error: Optional[str] = None

# ── PDF 下载映射 paper_uid → 本地 pdf 绝对路径 ─────────────────────────────────
# 每次请求结束后由 _build_response 填充；下载时从中查
_pdf_index: Dict[str, str] = {}

# 对外的下载 URL 前缀（H 集群上配成公网域名 / 内网 IP）
DOWNLOAD_BASE_URL = os.environ.get("DOWNLOAD_BASE_URL", "").rstrip("/")

# 可移植内容库根目录（与 EvidenceResolver._DEFAULT_LOCAL_STORE 保持一致）
_LOCAL_STORE: Path = (
    Path(os.environ.get("CONTENT_STORE_PATH", ""))
    if os.environ.get("CONTENT_STORE_PATH")
    else _ROOT / "scientific_kgqa" / "data" / "content_store"
)

# 是否在 server 启动时自动从 Ceph 拉取缺失的构建产物（索引/DB）
# 设置方式：PULL_ARTIFACTS=1  或  PULL_ARTIFACTS=true
_PULL_ARTIFACTS: bool = os.environ.get("PULL_ARTIFACTS", "").lower() in ("1", "true", "yes")


def _pull_missing_artifacts() -> None:
    """server 启动时检查所有查询期必需产物，缺失则从 Ceph 按需拉取。

    必需产物（query-time required）：
      kb_mvp/index/faiss.index / bm25.pkl / chunk_ids.json
      kb_mvp/data/kb.db
      scientific_kgqa/artifacts/kgqa.db / retriever.pkl

    触发条件：PULL_ARTIFACTS=1 且对应文件不存在。
    已存在的文件跳过，不重复下载。
    """
    try:
        from kb_mvp.src import config as kb_cfg
        from content_store_remote import pull_artifacts_parallel, DEFAULT_ARTIFACTS_PREFIX
    except Exception as e:
        logger.warning("[artifacts] 无法导入依赖，跳过产物拉取: %s", e)
        return

    # 构建 (remote_subpath, local_path) 映射表
    artifact_prefix = os.environ.get("ARTIFACTS_REMOTE_PREFIX", DEFAULT_ARTIFACTS_PREFIX)
    required: list[tuple[str, Path]] = [
        ("kb_index/faiss.index",    Path(kb_cfg.FAISS_INDEX_PATH)),
        ("kb_index/bm25.pkl",       Path(kb_cfg.BM25_INDEX_PATH)),
        ("kb_index/chunk_ids.json", Path(kb_cfg.CHUNK_IDS_PATH)),
        ("kb_data/kb.db",           Path(kb_cfg.DB_PATH)),
        ("kgqa/kgqa.db",            _ROOT / "scientific_kgqa" / "artifacts" / "kgqa.db"),
        ("kgqa/retriever.pkl",      _ROOT / "scientific_kgqa" / "artifacts" / "retriever.pkl"),
    ]

    missing = [(rp, lp) for rp, lp in required if not lp.exists()]
    if not missing:
        logger.info("[artifacts] 所有产物文件已在本地，无需拉取")
        return

    logger.info("[artifacts] 检测到 %d 个产物文件缺失，从 Ceph 拉取...", len(missing))
    for rp, lp in missing:
        logger.info("  缺失: %s", lp)

    results = pull_artifacts_parallel(
        missing,
        remote_prefix=artifact_prefix,
        max_workers=4,
        show_progress=True,
    )

    failed = [rp for rp, ok in results.items() if not ok]
    succeeded = len(results) - len(failed)
    logger.info("[artifacts] 拉取完成: %d 成功 / %d 失败", succeeded, len(failed))
    if failed:
        logger.warning("[artifacts] 以下产物拉取失败，server 部分功能可能受限: %s", failed)


def _build_pipeline():
    from retrieval_integration.config import (
        load_config,
        inherit_llm_from,
        PROJECT_ROOT as RI_ROOT,
        reset_config,
    )
    from retrieval_integration.core.pipeline import RetrievalPipeline

    if _PULL_ARTIFACTS:
        logger.info("[artifacts] PULL_ARTIFACTS=1，检查并拉取远程产物...")
        _pull_missing_artifacts()

    cfg = load_config()
    cfg = inherit_llm_from(RI_ROOT / "configs" / "extract_config_aero.yaml", cfg)
    reset_config(cfg)
    return RetrievalPipeline(cfg)


@app.on_event("startup")
async def _startup():
    global _pipeline, _init_error, _pipeline_lock
    _pipeline_lock = asyncio.Lock()
    logger.info("Initializing RetrievalPipeline ...")
    t0 = time.perf_counter()
    try:
        loop = asyncio.get_event_loop()
        _pipeline = await loop.run_in_executor(None, _build_pipeline)
        logger.info("Pipeline ready in %.1fs", time.perf_counter() - t0)

        # 预热：只加载 KB 索引（FAISS + BM25 + embedding model），不跑 LLM
        logger.info("Warming up KB indexes (FAISS + BM25 + embedding) ...")
        await loop.run_in_executor(None, _warmup_indexes)
        logger.info("Warmup done in %.1fs, service ready.", time.perf_counter() - t0)
    except Exception as e:
        _init_error = str(e)
        logger.exception("Pipeline init failed: %s", e)


def _warmup_indexes():
    """只加载 KB / KG 索引，不调 LLM、不跑完整 pipeline。"""
    # 1. KB 三路检索器（FAISS + BM25 + embedding）
    try:
        m2 = _pipeline.m2
        if hasattr(m2, "adapter") and hasattr(m2.adapter, "_ensure_searcher"):
            t = time.perf_counter()
            m2.adapter._ensure_searcher()
            logger.info("  [warmup] KB HybridSearcher loaded (%.1fs)", time.perf_counter() - t)
    except Exception as e:
        logger.warning("  [warmup] KB searcher load failed: %s", e)

    # 2. KG retriever pkl（如果配置启用 deep 通道，提前 load 1.2GB pkl）
    try:
        m2 = _pipeline.m2
        kg = getattr(m2, "kg_adapter", None)
        if kg is not None:
            t = time.perf_counter()
            retr = getattr(kg, "retriever", None)
            if retr is not None and hasattr(retr, "_load"):
                retr._load()
                logger.info("  [warmup] KG retriever.pkl loaded (%.1fs)", time.perf_counter() - t)
    except Exception as e:
        logger.warning("  [warmup] KG retriever load failed: %s", e)


# ── 请求 / 响应模型 ───────────────────────────────────────────────────────────
class QueryRequest(BaseModel):
    query: str = Field(..., description="用户问题")
    mode: str  = Field("fast", description="查询模式：fast | deep | auto")
    top_k: int = Field(10,     description="返回 KB chunk 数量上限")


class QueryResponse(BaseModel):
    request_id: str
    query: str
    mode: str
    state: Optional[str]
    answer: str
    kg_reasoning_paths: list
    kb_evidence: list
    evidence_papers: list
    external_refs: list
    references: list  # [{paper_uid, title, source, download_url}]
    confidence: Optional[float]
    warnings: list
    error: Optional[str]
    timings: Dict[str, Any]


# ── 公共：校验 + 构造响应 ─────────────────────────────────────────────────────
def _check_ready():
    if _init_error:
        raise HTTPException(status_code=503, detail=f"Pipeline init failed: {_init_error}")
    if _pipeline is None:
        raise HTTPException(status_code=503, detail="Pipeline not ready yet, please retry")


def _build_response(req: QueryRequest, result: Dict[str, Any], elapsed_ms: float) -> QueryResponse:
    metrics = result.get("metrics") or {}
    references = _build_references(result)
    return QueryResponse(
        request_id=result.get("request_id", ""),
        query=result.get("query", req.query),
        mode=req.mode,
        state=metrics.get("state"),
        answer=result.get("llm_answer") or result.get("answer") or "",
        kg_reasoning_paths=result.get("kg_reasoning_paths") or [],
        kb_evidence=(result.get("kb_evidence") or [])[:req.top_k],
        evidence_papers=result.get("evidence_papers") or [],
        external_refs=result.get("external_refs") or [],
        references=references,
        confidence=metrics.get("final_confidence"),
        warnings=result.get("warnings") or [],
        error=result.get("error"),
        timings={
            **(metrics.get("fine_timings") or {}),
            "total_ms": elapsed_ms,
            "pipeline_total_ms": metrics.get("total_latency_ms"),
        },
    )


def _build_references(result: Dict[str, Any]) -> list:
    """汇总 KB / 外部论文 → references，注册 paper_uid → 本地文件映射。

    KB 论文：返回 markdown 全文（content_store 里现成的 .md 文件）。
    外部 API 论文：返回下载到本地的 PDF（local_pdf_path），或原始 URL。
    """
    refs: list = []
    seen: set = set()

    # 1) KB 文献：用 md_path（markdown 全文）
    for ep in result.get("evidence_papers") or []:
        uid = ep.get("paper_uid") or ep.get("paper_id") or ""
        if not uid or uid in seen:
            continue
        seen.add(uid)
        # 优先 md_path（content_store 里的 markdown），其次再尝试 pdf_paths（一般为空）
        md_path = ep.get("md_path") or ""
        download_url = None
        file_type = None
        if md_path and Path(md_path).exists():
            _pdf_index[uid] = md_path
            download_url = (f"{DOWNLOAD_BASE_URL}/files/{uid}.md"
                            if DOWNLOAD_BASE_URL else f"/files/{uid}.md")
            file_type = "md"
        else:
            pdf_paths = ep.get("pdf_paths") or []
            local_pdf = next((p for p in pdf_paths if p and Path(p).exists()), None)
            if local_pdf:
                _pdf_index[uid] = local_pdf
                download_url = (f"{DOWNLOAD_BASE_URL}/files/{uid}.pdf"
                                if DOWNLOAD_BASE_URL else f"/files/{uid}.pdf")
                file_type = "pdf"
        refs.append({
            "paper_uid": uid,
            "title": ep.get("title") or "",
            "source": ["kb"],
            "doi": ep.get("doi") or "",
            "year": ep.get("year"),
            "file_type": file_type,
            "download_url": download_url,
        })

    # 2) 外部检索文献：用 local_pdf_path 或原始 URL
    for ext in result.get("external_refs") or []:
        doi = ext.get("doi") or ""
        url = ext.get("url") or ""
        import hashlib
        # 用 sha1(doi or url or title) 做 paper_uid（保证不含 / \ . 等特殊字符）
        seed_str = doi or url or ext.get("title", "")
        if not seed_str:
            continue
        key = hashlib.sha1(seed_str.encode("utf-8")).hexdigest()[:16]
        if key in seen:
            continue
        seen.add(key)
        local_pdf = ext.get("local_pdf_path")
        download_url = None
        file_type = None
        if local_pdf and Path(local_pdf).exists():
            _pdf_index[key] = local_pdf
            download_url = (f"{DOWNLOAD_BASE_URL}/files/{key}.pdf"
                            if DOWNLOAD_BASE_URL else f"/files/{key}.pdf")
            file_type = "pdf"
        elif url:
            download_url = url
            file_type = "external_url"
        refs.append({
            "paper_uid": key,
            "title": ext.get("title") or "",
            "source": ["external", ext.get("source_api", "")],
            "doi": doi,
            "year": ext.get("year"),
            "file_type": file_type,
            "download_url": download_url,
        })

    return refs


# ── SSE 进度推送 ──────────────────────────────────────────────────────────────
_PROGRESS_KEYWORDS = [
    ("Pipeline start",         "Pipeline 启动"),
    ("m1_schema_parser",       "M1 解析查询意图"),
    ("m2_internal_retrieval",  "M2 内部知识库检索"),
    ("KGPathAdapter",          "KG 图谱推理"),
    ("m4_plan_generator",      "M4 生成检索计划"),
    ("m5_external_retrieval",  "M5 外部文献检索"),
    ("m6_answer_generator",    "M6 生成回答"),
    ("Three-way recall",       "KB 三路融合召回完成"),
    ("HybridSearcher ready",   "KB 检索器就绪"),
]


class _ProgressHandler(logging.Handler):
    def __init__(self, q: queue.Queue):
        super().__init__()
        self._q = q

    def emit(self, record: logging.LogRecord):
        import re
        msg = record.getMessage()
        for keyword, label in _PROGRESS_KEYWORDS:
            if keyword in msg:
                suffix = ""
                m = re.search(r"done \((\d+(?:\.\d+)?)ms\)", msg)
                if m:
                    suffix = f" ({float(m.group(1))/1000:.1f}s)"
                self._q.put_nowait({"type": "progress", "step": label + suffix})
                break


def _sse(data: dict) -> str:
    return f"data: {json.dumps(data, ensure_ascii=False)}\n\n"


async def _stream_pipeline(req: QueryRequest) -> AsyncIterator[str]:
    q: queue.Queue = queue.Queue()
    result_holder: dict = {}
    error_holder: dict = {}

    handler = _ProgressHandler(q)
    handler.setLevel(logging.INFO)
    root_logger = logging.getLogger()
    root_logger.addHandler(handler)

    t0 = time.perf_counter()

    def _run():
        try:
            result_holder["result"] = _pipeline.run(req.query, log=True, channel=req.mode)
        except Exception as e:
            error_holder["error"] = str(e)
        finally:
            q.put_nowait(None)

    thread = threading.Thread(target=_run, daemon=True)
    thread.start()

    yield _sse({"type": "start", "query": req.query, "mode": req.mode})

    loop = asyncio.get_event_loop()
    while True:
        try:
            item = await loop.run_in_executor(None, lambda: q.get(timeout=2))
        except Exception:
            yield _sse({"type": "heartbeat", "elapsed_s": round(time.perf_counter() - t0, 1)})
            continue
        if item is None:
            break
        yield _sse(item)

    root_logger.removeHandler(handler)
    thread.join(timeout=5)

    elapsed_ms = round((time.perf_counter() - t0) * 1000, 1)

    if error_holder:
        yield _sse({"type": "error", "detail": error_holder["error"]})
        return

    resp = _build_response(req, result_holder["result"], elapsed_ms)
    yield _sse({"type": "result", "data": resp.model_dump()})
    yield _sse({"type": "done", "total_ms": elapsed_ms})


# ── 接口 ──────────────────────────────────────────────────────────────────────
@app.post("/query", response_model=QueryResponse)
async def query_blocking(req: QueryRequest):
    """阻塞等待完整结果。"""
    _check_ready()
    if req.mode not in ("fast", "deep", "auto"):
        raise HTTPException(status_code=400, detail="mode must be fast | deep | auto")

    async with _pipeline_lock:  # type: ignore[union-attr]
        loop = asyncio.get_event_loop()
        t0 = time.perf_counter()
        try:
            result: Dict[str, Any] = await loop.run_in_executor(
                None,
                lambda: _pipeline.run(req.query, log=True, channel=req.mode),
            )
        except Exception as e:
            logger.exception("Pipeline run error")
            raise HTTPException(status_code=500, detail=str(e))
        elapsed_ms = round((time.perf_counter() - t0) * 1000, 1)

    return _build_response(req, result, elapsed_ms)


@app.post("/query/stream")
async def query_stream(req: QueryRequest):
    """SSE 流式接口，实时推送各阶段进度，最后推完整结果。

    每条事件格式（text/event-stream）：
        data: {"type": "progress", "step": "M2 内部知识库检索 (3.2s)"}
        data: {"type": "heartbeat", "elapsed_s": 12.5}
        data: {"type": "result",   "data": {...完整结果...}}
        data: {"type": "done",     "total_ms": 45200}
    """
    _check_ready()
    if req.mode not in ("fast", "deep", "auto"):
        raise HTTPException(status_code=400, detail="mode must be fast | deep | auto")

    return StreamingResponse(
        _stream_pipeline(req),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


@app.get("/health")
async def health():
    return {
        "status": "ok" if _pipeline is not None else "initializing",
        "pipeline_ready": _pipeline is not None,
        "init_error": _init_error,
    }


def _resolve_file_path(uid: str, ext: str) -> Optional[Path]:
    """uid + ext → 本地绝对路径，按优先级依次查找：
    1. _pdf_index（本次会话已注册的路径，如存在则直接用）
    2. content_store/<uid>/full.md 或 *.pdf（服务重启后的持久缓存兜底）
    3. 远程按需拉取（_manifest.json 指示有远程副本时）
    找不到返回 None。
    """
    # 1. 会话缓存
    cached = _pdf_index.get(uid)
    if cached and Path(cached).exists():
        return Path(cached)

    # 2. 持久本地内容库
    pdir = _LOCAL_STORE / uid
    if ext == "md":
        candidate = pdir / "full.md"
        if candidate.exists():
            _pdf_index[uid] = str(candidate)
            return candidate
    else:  # pdf
        pdfs = sorted(pdir.glob("*.pdf"))
        if pdfs:
            _pdf_index[uid] = str(pdfs[0])
            return pdfs[0]

    # 3. 远程按需拉取（需要 _manifest.json）
    manifest = pdir / "_manifest.json"
    if not manifest.exists():
        return None
    try:
        import json as _json
        info = _json.loads(manifest.read_text(encoding="utf-8"))
    except Exception:
        return None
    try:
        from content_store_remote import fetch_file
    except Exception:
        return None
    if ext == "md" and info.get("md"):
        dest = pdir / "full.md"
        if fetch_file(uid, "full.md", dest):
            _pdf_index[uid] = str(dest)
            return dest
    elif ext == "pdf":
        for name in (info.get("pdfs") or []):
            dest = pdir / name
            if dest.exists() or fetch_file(uid, name, dest):
                _pdf_index[uid] = str(dest)
                return dest
    return None


@app.get("/files/{filename}")
async def download_file(filename: str):
    """下载论文全文。filename 形如 '{paper_uid}.md' 或 '{paper_uid}.pdf'。

    优先命中会话缓存；服务重启后兜底到本地内容库，本地缺失时从远程 Ceph 桶按需拉取。
    """
    if "/" in filename or "\\" in filename or ".." in filename:
        raise HTTPException(status_code=400, detail="invalid filename")
    uid, _, ext = filename.rpartition(".")
    if not uid or ext.lower() not in ("md", "pdf"):
        raise HTTPException(status_code=400, detail="invalid filename")
    local = await asyncio.get_event_loop().run_in_executor(
        None, _resolve_file_path, uid, ext.lower()
    )
    if local is None:
        raise HTTPException(status_code=404, detail="file not found")
    media = "text/markdown; charset=utf-8" if ext.lower() == "md" else "application/pdf"
    return FileResponse(
        str(local),
        media_type=media,
        filename=filename,
    )


if __name__ == "__main__":
    # 直接 `python server.py` 启动（等价于 uvicorn server:app）。
    # 可用环境变量覆盖监听地址：HOST / PORT（默认 0.0.0.0:8000）。
    import uvicorn

    host = os.environ.get("HOST", "0.0.0.0")
    port = int(os.environ.get("PORT", "8000"))
    logger.info("Launching uvicorn on %s:%d (server:app)", host, port)
    uvicorn.run(app, host=host, port=port, workers=1)
