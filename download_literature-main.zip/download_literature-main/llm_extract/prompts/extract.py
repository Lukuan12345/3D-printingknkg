#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
extract.py — 按域动态组装的提取 prompt（仅 claude-haiku 系列）。

Categories（值域词典）按 domain 拆分为独立片段，
在 extractor.build_extract_prompt 中根据 filter 确定的 domains 动态拼接。
"""

# ===================================================================
# 按域拆分的 Category 片段（值域词典）
# ===================================================================

# 通用（所有论文都带）
CATEGORY_COMMON = """
### Application Context (extract from paper)
**Platform** (if mentioned): aircraft / missile / satellite / spacecraft / ground radar / UAV / hypersonic vehicle / other
**Component** (if mentioned): radome / absorber / antenna / primary structure / bracket / thermal protection / solar array / propulsion / payload / other
**Mission environment** (if mentioned):
  Frequency band: L/S/C/X/Ku/Ka/mmWave/THz — center frequency (GHz)
  Thermal: operating temperature range (°C); thermal cycling
  Mechanical: load type (quasi-static g / vibration / shock / acoustic); load magnitude
  Space: orbit altitude (km); radiation dose; atomic oxygen
  Aerodynamic: Mach number; dynamic pressure
**Constraints**: mass budget; volume envelope; lifetime; qualification standard (MIL-STD/GJB/ESA)

### Design Methodology & Physical Mechanism
**Design approach**: analytical (TMM/ECM/quarter-wave/CLT/effective medium) / semi-analytical (CMA) / full-wave (FEM-HFSS/FDTD-CST/MoM-FEKO/COMSOL) / optimization (GA/PSO/DE/Bayesian/topology/adjoint)
**ML approach** (if used): forward/inverse/tandem/GAN/PINN, architecture, training size, prediction R², speedup
**Process-structure-property link**: process variable → microstructure → property (quantitative chain)
**Cross-domain coupling**: structure-EM / process-microstructure-property / multi-objective trade-offs
"""

# metamaterial 域
CATEGORY_METAMATERIAL = """
### EM Structural Parameters (Metamaterial / FSS / Absorber)
**Unit topology**: patch / ring / cross / Jerusalem cross / fractal (Koch/Sierpinski/Minkowski) / slot / SRR / mushroom / checkerboard / coding unit / 3D lattice — state exact name
**Geometric dimensions** (list ALL numeric values):
  Unit period P (mm); metal linewidth w (mm); gap width g (mm)
  Patch side/diameter (mm); ring inner/outer radius (mm)
  Metal thickness (μm); substrate thickness per layer (mm)
  Air gap/foam spacer thickness (mm); inter-layer distance (mm)
  Total thickness (mm); fractal iteration level; tilt/rotation angle (°)
  Duty ratio (%); coding bit depth; phase gradient (°/mm)
**Array**: periodic/quasi-periodic/aperiodic; square/hexagonal lattice; supercell size

### EM Structural Geometry → Schema field mapping
When the paper discusses these topics, extract into the corresponding Schema field:
  - Symmetry (C4/C2/mirror/rotational/centrosymmetric/asymmetric) → `spatial_symmetry`
  - Multi-layer coupling (vertical coupling, inter-layer phase gradient, stacked resonators) → `multilayer_coupled`
  - Gradient design (size gradient, shape gradient, orientation gradient, graded index) → `gradient_geometry`
  - Connectivity (fully connected, partially connected, isolated, bridged, network topology) → `connectivity`
  - Topological properties (genus, holes, Euler number, Betti numbers) → `topological_features`

### EM Material Parameters
**Substrate/dielectric** (per layer): material name (FR4 / Rogers RO3003/RO4350B/RO5880 / PTFE / polyimide / PDMS / ceramic / foam / honeycomb), εr, tanδ, thickness (mm)
**Metal/conductor**: material (Cu/Al/Au/Ag/ITO), thickness (μm), conductivity σ (S/m)
**Resistive layer**: sheet resistance Rs (Ω/sq), material (NiCr / graphene / CNT / ITO)
**Tunable materials**: VO₂ (transition temp, conductivity states), GST, liquid crystal (Δn), graphene (μc eV)
**Active elements**: PIN diode (Ron, Coff), varactor (C range, bias V), MEMS switch

### EM Performance Metrics → Schema field mapping
When the paper reports these metrics, extract into the corresponding Schema field:
  - Bandwidth properties (relative/absolute BW, frequency selectivity, out-of-band suppression) → `frequency_performance`
  - Incident angle stability (small-angle 0°–30°, large-angle 30°–60° performance) → `angular_performance`
  - Phase characteristics (insertion phase shift, group delay flatness) → `time_performance`
  - Polarization conversion (linear-circular, cross-pol suppression, PCE) → `polarization_conversion`
  - Evaluation criteria used for optimization/DOE/parameter sweeps → `response_metrics`
  - Optimization target (minimize mass, maximize BW, reduce loss) → `optimization_objective`
**Absorber**: reflection loss RL (dB), -10/-20dB bandwidth (GHz), peak absorption (%), angle stability (°), polarization, thickness/λ ratio, thickness-bandwidth product
**FSS**: center freq (GHz), insertion loss (dB), stopband attenuation (dB), 3dB BW (GHz), selectivity, roll-off rate
**Polarization**: PCE (%), PCE≥90% BW (GHz), cross-pol ratio (dB), axial ratio (dB), AR≤3dB BW (GHz)
**Beam steering**: phase coverage (°), deflection angle (°), aperture efficiency (%), gain (dBi), sidelobe level (dB)
**RCS**: reduction (dB), -10dB bandwidth (GHz), scattering type
**Tunable**: tuning range (GHz), modulation depth (dB), switching time (μs), bias voltage (V), phase tuning range (°)

### EM Physical Mechanism → Schema field mapping
When the paper discusses these mechanisms, also check the corresponding Schema fields:
  - Maxwell's equations, boundary conditions, periodic BC → `maxwell_equations_and_boundary_conditions`
  - Effective medium theory, homogenization, parameter retrieval → `constitutive_relations_and_effective_medium_theory`
  - Surface impedance/admittance tensor design → `surface_impedance_tensor`
  - Electric/magnetic polarizability control → `surface_polarizability`
  - Dispersion engineering, band structure design → `dispersion_engineering`
  - Impedance gradient distribution → `wave_impedance_gradient`
  - Generalized Brewster effect (Zs = Z0) → `generalized_brewster`
**Resonance mechanism**: LC/multi-mode/Fano/EIT/Mie/Fabry-Pérot/SPR/SSPP
**Loss mechanism**: dielectric/ohmic/magnetic/interference cancellation/impedance matching/gradient impedance
**Phase mechanism**: resonance phase/PB geometric phase/combined/transmission phase
"""

# radome 域
CATEGORY_RADOME = """
### Radome Wall Parameters
**Wall construction**: A/B/C-sandwich / solid laminate / half-wave / Chebyshev-matched
  Face skin: material, εr, tanδ, thickness (mm)
  Core: material, εr, tanδ, thickness (mm), density (kg/m³)
  Mid-skin (C-sandwich): material, thickness (mm)

### Antenna Parameters
**Antenna type**: microstrip patch / horn / dipole / slot / helix / MIMO / phased array / reflectarray / conformal
**Dimensions**: aperture size (mm), patch L/W (mm), element spacing (mm), element count, polarization
**Feed**: coaxial probe / microstrip line / aperture-coupled / waveguide; matching network

### Radome & Antenna Performance
**Radome**: transmission T (%) at 0°/30°/45°/60°, BSE (°), insertion loss (dB), VSWR, transmission BW (GHz)
**Antenna**: gain (dBi), efficiency (%), HPBW (°), sidelobe (dB), XPD (dB), S11 BW (GHz), scan range (°), mutual coupling (dB)
"""

# manufacturing 域
CATEGORY_MANUFACTURING = """
### Process Parameters
**Additive manufacturing**: laser power (W), scan speed (mm/s), layer thickness (μm), hatch spacing (mm), VED (J/mm³), build platform temp (°C), atmosphere, powder D50 (μm), scan strategy
**Machining**: cutting speed (m/min), feed rate (mm/rev), depth of cut (mm), tool material, coolant
**Composite fabrication**: cure temp (°C), pressure (MPa), time (h), fiber orientation, injection pressure (bar) for RTM
**Welding/joining**: heat input (J/mm), speed (mm/min), current (A), voltage (V), FSW rotation (rpm)
**Heat treatment**: solution (°C/h), aging (°C/h), HIP (°C/MPa/h), cooling rate (°C/h)
**Surface treatment**: PVD/CVD coating (material, thickness μm), shot peening (Almen intensity), anodizing
**PCB/EM fabrication**: photolithography, screen printing, inkjet, laser ablation, 3D printing (SLA/FDM/SLS), LTCC, lamination (temp/pressure)

### Manufacturing Quality Metrics
**Quality**: porosity (%), surface roughness Ra (μm), residual stress (MPa), dimensional tolerance
**Fabricated sample**: size (mm×mm), measurement method (free-space/waveguide/NRL arch/VNA/anechoic chamber)
"""

# supermaterial 域
CATEGORY_SUPERMATERIAL = """
### Structural Material Properties
**Alloy/composite**: material name (IN718/Ti-6Al-4V/Al7075/CMSX-4) — density, E, σy, UTS, elongation, CTE
**Composite**: fiber (T300/T700/T800/IM7), resin (epoxy/BMI/PEEK), Vf (%), layup, void content (%)
**Superalloy composition** (wt%): Ni, Cr, Co, Al, Ti, Mo, W, Re, Ta, Nb — γ' fraction (%), γ' size (nm), PDAS/SDAS (μm)
**CMC**: fiber architecture, Vf (%), interphase (BN/PyC, thickness nm), CVI/PIP cycles, matrix porosity (%)
**Lattice topology**: BCC/FCC/octet/TPMS (Gyroid/Schwartz P/Diamond)/re-entrant/chiral — relative density, strut diameter, unit cell size

### Mechanical & Thermal Performance
**Mechanical — RT**: UTS (MPa), yield (MPa), elongation (%), E (GPa), hardness, fatigue life (cycles), KIC (MPa√m), ILSS (MPa), SEA (J/g)
**Mechanical — HT**: creep rupture life (h) at T°C/σMPa, creep rate (s⁻¹), HT tensile strength (MPa)
**Thermal**: conductivity (W/m·K), CTE (ppm/°C), max service temp (°C), oxidation rate, ablation rate, TBC cycling life
"""

# satellite 域
CATEGORY_SATELLITE = """
### Structural Optimization Parameters
**Topology optimization**: SIMP / BESO / level-set — penalty factor, volume fraction, filter radius, convergence criterion
**Load cases**: quasi-static g (axial/lateral), sine vibration (Hz, g), random vibration (grms), acoustic (dB), thermal range (°C)
**FEM**: solver (Nastran/Abaqus/Optistruct), element count, design variable count

### Structural Performance
**Structural**: mass (kg), mass reduction (%), fundamental freq (Hz), compliance, max displacement (mm), safety margin
**FEM-test correlation**: frequency error (%), MAC value, test type (modal survey/sine sweep/random/shock)
"""

# pinn 域
CATEGORY_PINN = """
### PINN / Scientific ML Parameters
**Physics problem**: governing PDE (Navier-Stokes/heat/elasticity/Maxwell/wave), spatial dimension (1D/2D/3D), regime (steady/unsteady, laminar/turbulent), domain geometry, Re/Ma/Pr numbers, boundary conditions
**Architecture**: MLP/ResNet/FourierMLP/SIREN/DeepONet/FNO/FBPINN/XPINN — depth × width, activation function, input/output variables
**Training**: collocation points (count + sampling method), supervised data (count + type + noise level), loss terms (PDE/BC/IC/data) + weights + adaptation strategy, optimizer (Adam/L-BFGS/two-phase), total iterations, framework (PyTorch/TF/JAX/DeepXDE), hardware (GPU type)
**Inverse problem** (if applicable): unknown parameter type, sensor count, noise level

### PINN/ML Accuracy
**Accuracy**: L2 error (%) per variable, MAE, max pointwise error, reference method, training time (h), inference time (ms), speedup factor
"""

# titanium_alloy 域（基础库：VAR 凝固 / β-Ti 热加工 / TiAl 凝固与相场 /
#                   马氏体相变热力学 / Ti-6Al-4V 织构与晶体塑性）
CATEGORY_TITANIUM_ALLOY = """
### Titanium Alloy System & Composition
**Alloy class**: α / near-α / α+β / metastable-β / near-β / β / Ti-Al / γ-TiAl / Ti-6Al-4V / Ti64 / TC4 / Ti-5553 / Ti-17 / Ti-6242 — state exact designation
**Composition** (wt%): Al / V / Mo / Nb / Cr / Fe / Sn / Zr / O / N / C — report Mo-eq, Al-eq when given
**Interstitials**: O / N / C / H content (ppm or wt%)

### Research Direction Tags
VAR_solidification | hot_deformation_DRX | TiAl_phase_field | martensitic_transformation | Ti64_texture_CP

### Process / Modeling Parameters
**VAR**: current (kA); voltage (V); melt rate (kg/min); stirring frequency (Hz); Lorentz force density (N/m³); melt pool depth (mm); macrosegregation index
**Hot-working**: temperature (°C); strain rate (s⁻¹); total strain; pass schedule; cooling rate (K/s); quench medium; rolling/forging route
**Phase-field / CALPHAD**: interface energy (J/m²); interface mobility; CALPHAD database (TCTI / Pandat-Ti); free-energy formulation; grid resolution
**CPFEM / texture**: slip systems activated; CRSS per system (MPa); hardening law; twinning activation; Taylor factor; EBSD step size

### Microstructure Features
prior β grain size (μm); α morphology (lamellar / acicular / globular / basketweave); α lamellae thickness (μm); α/β interface density; α₂/γ lamellar spacing (nm); dendrite arm spacing SDAS (μm); texture components (basal / prismatic / pyramidal) and intensity (MRD); DRX volume fraction (%); twin volume fraction (%)

### Mechanical & Thermodynamic Metrics
UTS / YS (MPa); elongation (%); fatigue life (cycles); fracture toughness KIC (MPa√m); Ms / Mf temperature (°C); transformation driving force ΔG (J/mol); elastic strain energy Ee (J/m³); energy barrier (J/mol); β→α'/α'' transformation pathway
"""

# titanium_am 域（增材制造子库：11 子类 — 材料体系 / 工艺 / 参数与热历史 /
#                 凝固与组织 / 缺陷 / 后处理 / 力学性能 / 机理 / 建模 /
#                 表征 / 高强异质组织）
CATEGORY_TITANIUM_AM = """
### Material System (AM)
metastable-β / near-β / α+β high-strength / γ-TiAl / Ti-Al / Ti-6Al-4V / TC4 / Ti64 / Ti-5553 / Ti-17 / Ti-6242 — state exact alloy designation

### AM Process
LPBF (SLM) / EBM / DED / L-DED / LMD / WAAM — note machine model and powder/wire feedstock

### Process Parameters (extract ALL numeric values)
laser/beam power (W); scan speed (mm/s); layer thickness (μm); hatch spacing (mm); VED (J/mm³); scan strategy (bidirectional / island / meander / stripe); rotation angle between layers (°); build orientation (XY / Z / 45°); deposition rate (kg/h); inter-layer time (s); preheat temperature (°C); chamber atmosphere (Ar / vacuum / He); powder D50 (μm); wire feed rate (m/min)

### Thermal History & Melt Pool
melt pool width / depth / length (μm); melt pool dynamics (Marangoni / keyhole mode); cooling rate (10³–10⁶ K/s); thermal gradient (K/mm); solidification rate (mm/s); cyclic reheating cycles; as-built residual stress (MPa, +tensile / −compressive)

### Solidification & Microstructure
prior β grain morphology (columnar / equiaxed); prior β grain size (μm); α' martensite plate thickness (nm); α'' orthorhombic martensite fraction; α lamellae width (μm); acicular α aspect ratio; basketweave fraction (%); bimodal / heterogeneous microstructure descriptors; recrystallization fraction (%); texture component + intensity (MRD); anisotropic microstructure descriptors

### Defects & Quality
porosity (%) — gas pore / keyhole pore; pore size distribution; lack-of-fusion area fraction (%); unmelted particles; balling frequency; surface roughness Ra / Rz (μm); hot cracking density; oxygen pickup (ppm); N pickup (ppm); contamination; dimensional accuracy (mm)

### Post-Processing
stress relief: T (°C) × time (h); solution treatment: T (°C) × time (h) ± cooling medium; aging / precipitation: T (°C) × time (h), single / duplex; duplex annealing schedule; STA (solution + aging) combo; HIP: T (°C) / P (MPa) / time (h); thermo-mechanical post-processing (rolling / forging after AM)

### Mechanical Properties (report XY vs Z for anisotropy)
UTS (MPa); yield strength σ₀.₂ (MPa); elongation (%); hardness (HV / HRC); fatigue strength at N cycles (MPa); HCF / LCF life; fracture toughness KIC (MPa√m); anisotropy ratio (Z/XY); wear rate (mm³/N·m); creep rupture life (h) @ T/σ

### Mechanisms & Modeling
process-structure-property chain; phase-transformation mechanism (martensite / massive / Widmanstätten); strengthening mechanism (grain / solute / dislocation / precipitation / transformation); deformation mechanism (slip / twinning / TRIP / TWIP); texture-property link; residual-stress evolution; modeling: phase-field, CALPHAD, CPFEM, processing map, ML surrogate, multiscale

### Characterization (auxiliary filter)
EBSD; XRD; SEM; TEM; fractography; in-situ observation

### High-Intensity Markers
heterogeneous microstructure + ultra-strong; interstitial O + ultra-fine grain; multi-step thermal processing + TRIP / TWIP
"""

# domain → category 映射
DOMAIN_CATEGORIES = {
    "metamaterial": CATEGORY_METAMATERIAL,
    "radome": CATEGORY_RADOME,
    "manufacturing": CATEGORY_MANUFACTURING,
    "supermaterial": CATEGORY_SUPERMATERIAL,
    "satellite": CATEGORY_SATELLITE,
    "pinn": CATEGORY_PINN,
    "titanium_alloy": CATEGORY_TITANIUM_ALLOY,
    "titanium_am": CATEGORY_TITANIUM_AM,
}


# ===================================================================
# 单 Track Prompt 模板（去掉 Track B，Categories 动态注入）
# ===================================================================

UNIFIED_PROMPTS = {

# =====================================================================
# Haiku 专用 Prompt（MVP 仅支持 claude-haiku 系列）
# =====================================================================

"extract_mechanism_haiku": """You are a scientific literature extraction expert. Extract structured knowledge from this paper based on the Schema fields below.
ALL output MUST be in English, even if the source paper is written in Chinese or another language. Translate all descriptions and values into English.

## ★ Extraction Principles (strict priority order) ★

**Priority 1 — Schema fields with values found in paper**:
If the paper explicitly mentions a value for a Schema field, you MUST extract it using the exact Schema field name as the key. Scan ALL sections: abstract, methods, parameter tables (every row), results tables, figure captions, equations, and discussion. For fields with multiple values (e.g., parameter sweeps), collect ALL values into a list.

**Priority 2 — Schema fields without values (ABSOLUTE RULE — zero exceptions)**:
If a Schema field is not relevant to or not found in this paper, the field key MUST NOT appear in extracted_data at all. Delete the key entirely.
This is the single most important formatting rule. Violating it ruins the database.
Forbidden values (case-insensitive, in any field — if you would write ANY of these, DELETE THE ENTIRE KEY):
  `[]`, `null`, `"N/A"`, `"n/a"`, `"None"`, `"none"`,
  `"Not mentioned"`, `"not mentioned"`, `"Not applicable"`, `"not applicable"`,
  `"Not explicitly stated"`, `"not explicitly stated"`,
  `"Not reported"`, `"not reported"`, `"Not specified"`, `"not specified"`,
  `"Not quantified"`, `"not quantified"`, `"Not measured"`, `"not measured"`,
  `"Not explicitly reported"`, `"not explicitly reported"`,
  `"Not explicitly measured"`, `"not explicitly measured"`,
  `"Unknown"`, `"unknown"`, or ANY phrase meaning "this paper does not discuss X"
```
WRONG: "operating_frequency_range": []
WRONG: "bandwidth_regime": "not applicable"
WRONG: "polarization_condition": ["not explicitly stated"]
WRONG: "resonant_frequencies": ["Not mentioned"]
WRONG: "thermal_conductivity": ["Not reported"]
WRONG: "porosity": ["not quantified"]
WRONG: "insertion_loss": ["not explicitly reported"]
CORRECT: (do not include the key at all — if a field is irrelevant, it simply does not exist in your output)
```
SELF-CHECK before outputting: scan your extracted_data and DELETE any key whose value is an empty array or contains a placeholder string.

**Priority 3 — Custom fields for paper-specific discoveries (aim for 2–5 per paper, max 20)**:
Create a `_` prefixed custom field when the paper reports ANY of:
  (a) A novel metric or record-breaking quantitative result not covered by any Schema field
  (b) A first-of-its-kind demonstration, technique, or material combination
  (c) A quantitative finding that is the paper's PRIMARY contribution or breakthrough
Each custom field MUST include:
  - `"value"`: the specific result with numbers, MAX 15 words, no long explanations
  - `"why_notable"`: one sentence explaining significance, MAX 25 words
Example: `"_first_thermionic_emission_in_superlattice": {{"value": "Seebeck reversed from +4 to -140 uV/K", "why_notable": "First experimental thermionic emission in metal/semiconductor superlattices"}}`

**Priority 4 — Domain Knowledge section is a VALUE DICTIONARY only (NOT field names)**:
The Domain Knowledge section lists EXAMPLE VALUES organized by topic. Terms like "patch / ring / cross" are possible VALUES for Schema fields like `unit_cell_topology`, NOT field names themselves. Use it ONLY to recognize what values look like in the paper text.
NEVER create a field named after a category header (e.g., "Unit topology", "Geometric dimensions", "EM Performance Metrics"). All field names must come from the Schema or be `_` prefixed custom fields.

## ★ HAIKU-SPECIFIC: NO PARENTHETICAL ANNOTATIONS (CRITICAL) ★
You MUST NOT add parenthetical text to extracted_data values. This is your most common error pattern.
Parenthetical text includes: process labels, functional descriptions, specification details, sample descriptions, acronym expansions.

WRONG examples from YOUR past outputs (DO NOT repeat these):
  "700 °C (annealing)"                        → CORRECT: "700 °C"
  "PEEK (polyetheretherketone)"                → CORRECT: "PEEK"
  "1–4 GHz (target low-frequency band)"        → CORRECT: "1–4 GHz"
  "H₂/Ar mixture (annealing)"                 → CORRECT: "H₂/Ar"
  "spherical powder (−200 to +300 mesh)"       → CORRECT: "spherical powder"
  "5 mm (composite panels)"                    → CORRECT: "5 mm"
  "coaxial ring sample (3 mm ID, 7 mm OD)"    → CORRECT: "coaxial ring sample"
  "CST Microwave Studio (implied from VNA)"    → OMIT THIS FIELD (fabricated value)

The ONLY allowed parentheses contain:
  - Crystallographic orientations: "(0001)", "(111)"
  - Chemical formulas: "(SiC/SiC)", "(Al₂O₃)"
  - Frequency ranges embedded in bandwidth values: "4.0 GHz (8–12 GHz)"

SELF-CHECK: Before outputting, scan EVERY value in extracted_data. If any value contains "(...)" where the parenthetical is more than one word of description, REMOVE the parenthetical portion.

## ★ HAIKU-SPECIFIC: SEMANTIC FIELD-VALUE MATCH ★
Before assigning a value to a Schema field, verify the value ACTUALLY matches the field's definition.
If the value describes a DIFFERENT physical property, DO NOT force-fill. Omit the field entirely.

WRONG examples from YOUR past outputs:
  "unit_cell_topology": ["flake particles"]      → WRONG: particle morphology ≠ unit cell topology. OMIT the field.
  "elastic_modulus": ["~70 MPa (tensile strength)"] → WRONG: tensile strength ≠ elastic modulus. OMIT the field.
  "array_periodicity": ["random distribution in PEEK matrix"] → WRONG: random distribution ≠ periodic array. OMIT the field.
  "unit_cell_dimensions": ["10–60 μm diameter"]   → WRONG: particle size ≠ unit cell dimensions. OMIT the field.

Rule: If you must add a qualifier to explain why the value fits the field, it does NOT fit. Omit the field.

## ★ HAIKU-SPECIFIC: NO INFERENCE OR SPECULATION ★
NEVER use words like "implied", "inferred", "assumed", "likely", "probably", "estimated" in extracted_data values.
If the paper does not EXPLICITLY state a value, DO NOT fabricate it.

WRONG examples from YOUR past outputs:
  "CST Microwave Studio (implied from VNA measurements)"  → OMIT (paper never mentioned CST)
  "finite-element simulation (implied)"                    → OMIT (fabricated)
  "normal incidence (implied)"                             → OMIT (fabricated)

If the paper does not explicitly name a software tool, analysis method, or test condition, that field key must NOT appear in your output.

## ★ HAIKU-SPECIFIC: SCHEMA-ONLY KEYS (CRITICAL) ★
Every bare (non-underscore) key in extracted_data MUST be an EXACT MATCH of a field name in the Schema list below.
If the information you want to record has no matching Schema field:
  — Either fit it into an existing schema field (see DO-NOT-ENUMERATE RULE below and any domain-specific rules in the domain overlay), OR
  — Put it into a `_` prefixed custom field (Priority 3).
NEVER invent a new bare key.

WRONG examples from YOUR past outputs (every one is a bug you must stop doing):
  "ni_content": ["0.5 wt%"]                         → WRONG: schema has no ni_content. For alloy-family schemas, fold it into other_alloying_elements per the domain overlay
  "wire_feed_speed": ["8 m/min"]                     → WRONG: not in schema. Use a `_` custom field or fold into varied_parameter/processing_route
  "double_ellipsoid_heat_source_front": ["3 mm"]     → WRONG: one key per geometry param. Use ONE `_heat_source_geometry` custom field
  "publication_year": ["2023"]                        → WRONG: paper-level metadata. DO NOT emit (handled separately)
  "journal": ["Acta Mater."]                          → WRONG: paper-level metadata. DO NOT emit
  "author": ["S. Sadeghpour"]                         → WRONG: paper-level metadata. DO NOT emit
  "title": ["A new multi-element β Ti alloy..."]     → WRONG: paper-level metadata. DO NOT emit
  "doi": ["10.1016/j.xxx"]                            → WRONG: paper-level metadata. DO NOT emit

SELF-CHECK before outputting: for every bare key in extracted_data, confirm the exact string appears in the Schema list. If not, either remap the value into a schema field OR convert the entry to a `_` custom field.

## ★ HAIKU-SPECIFIC: SCHEMA-FIRST LOOKUP BEFORE CREATING `_` FIELDS (CRITICAL) ★
Before creating ANY `_` prefixed field, you MUST first scan the Schema list for a field whose **description** (not just name) covers the same concept. If ONE exists, use the schema field instead of inventing a `_` field.

Mechanism / response-control fields are the most frequently misrouted. Before minting `_<something>_mechanism` or `_<something>_enhancement`, check these commonly-missed schema fields:

  - `angle_polarization_robustness_cause`  — mechanistic reason a design keeps stable under oblique / cross-polarized incidence. Covers "angular-stability mechanism", "polarization-insensitivity reason".
  - `scattering_control_cause`             — mechanism for beam steering, anomalous reflection, grating-lobe suppression, RCS redistribution.
  - `dominant_mechanism`                   — the single principal physical mechanism driving the reported response (LC resonance, Brewster effect, Huygens, etc.).
  - `causal_mechanism_summary`             — authors' cause→effect chain; covers "multi-mechanism synergy", "why X leads to Y".
  - `impedance_matching`                   — generalized Brewster / impedance-gradient matching to free space. COVERS "impedance-matching validation", "Z≈Z₀ at resonance".
  - `generalized_brewster`                 — Brewster-angle enhancement by permittivity engineering. COVERS "Brewster-angle enhancement".
  - `huygens_principle`                    — electric/magnetic dipole co-excitation → full transmission.
  - `dispersion_engineering` / `wave_impedance_gradient` / `surface_polarizability` — for dispersion / gradient-impedance / polarizability-tuning claims.
  - `angular_stability`                    — QUANTITATIVE angular-stability metric (e.g., "up to 50°"), not a mechanism; covers "angular-stability record".
  - `polarization_conversion`              — linear-circular / cross-pol conversion efficiency metric.

NEGATIVE EXAMPLES (from real audits — DO NOT repeat):
  WRONG: "_angular_stability_mechanism": {{...}}        → CORRECT: use `angle_polarization_robustness_cause` (list-of-strings)
  WRONG: "_angular_stability_record":    {{...}}        → CORRECT: use `angular_stability` (numeric range)
  WRONG: "_grating_lobe_suppression_technique": {{...}} → CORRECT: use `scattering_control_cause`
  WRONG: "_brewster_angle_enhancement":  {{...}}        → CORRECT: use `generalized_brewster`
  WRONG: "_impedance_matching_validation": {{...}}      → CORRECT: use `impedance_matching`
  WRONG: "_permittivity_tailoring_mechanism": {{...}}   → CORRECT: use `dominant_mechanism` or `causal_mechanism_summary`
  WRONG: "_harmonic_suppression_mechanism": {{...}}     → CORRECT: use `dominant_mechanism`
  WRONG: "_multimechanism_synergy":      {{...}}        → CORRECT: use `causal_mechanism_summary`

RULE OF THUMB: if the `_` name contains "mechanism", "enhancement", "suppression", "matching", "validation", "technique", "stability", "synergy", "principle", or "effect" — STOP and re-check the Schema list first. A mechanism-related schema field almost always exists.

A `_` field is ONLY appropriate when the finding:
  (1) is quantitative (has numbers) AND (2) is a paper-specific RECORD / FIRST / breakthrough claim that cannot be captured by a generic schema field.
Good examples: "_first_parallel_lc_atfss", "_band_ratio_achievement", "_fabrication_sensitivity_epoxy_adhesive".

SELF-CHECK before outputting: for every `_` field, (a) confirm no schema field in the list above matches its concept; (b) confirm the content is not duplicated by an already-populated schema field. If either check fails, delete the `_` field and use the schema field.

{domain_overlay}

## ★ HAIKU-SPECIFIC: DO NOT ENUMERATE MEASUREMENTS AS KEYS ★
Do NOT create one key per individual measurement value. Group related measurements under a single field.

WRONG examples (from past outputs where a single paper ballooned to 80+ keys):
  "dendrite_tip_concentration_favorable": [...]
  "dendrite_tip_concentration_unfavorable": [...]
  "interface_instability_time_baseline": [...]
  "interface_instability_time_s9b1": [...]
  "interface_instability_time_s9b3": [...]
  "interface_instability_time_s33b1": [...]
  ... (one key per experimental variant) ...

CORRECT: use ONE `_` custom field that summarizes the trend, e.g.
  "_dendrite_tip_concentration_anisotropy": {{
    "value": "favorable ~12 wt%, unfavorable ~8 wt%",
    "why_notable": "Quantifies competitive-growth anisotropy vs baseline"
  }}

Cap: at most 3 `_` custom fields per distinct phenomenon. If you are creating a 4th variant of the same concept, STOP and consolidate.

## 1. Core Inputs
The following Schema defines the EXACT field names to use as keys in `extracted_data`. The **bold English names** (e.g., `conductor_material`, `substrate_material`) are the EXACT JSON keys you must use.

**Paper Title**: {paper_title}
**Level 1 — Problem Definition & Physical Framework** (use these as extracted_data keys): {context_text}
**Level 2 — Study Variables & Parameters** (use these as extracted_data keys): {variables_text}
**Level 3 — Performance Metrics & Validation** (use these as extracted_data keys): {targets_text}
**Level 4 — Optimization Logic & Knowledge Discovery** (use these as extracted_data keys): {mechanism_text}
**Document Content**: {markdown_content}

## 2. Domain Knowledge (VALUE DICTIONARY — for recognizing values only, NOT field names)
{domain_categories}

## ★ MANDATORY FIELDS CHECKLIST — verify before output ★
After generating extracted_data, verify these CUSTOM-DISCOVERY fields ARE PRESENT when content exists in the paper. They live in the `_` prefix namespace (per-paper originality, max 20 `_` fields) and use {{value, why_notable}} structure — not list-of-strings:

  □ _advancement — HOW this work advances the state of the art (quantitative preferred).
    NOTE: "_advancement" is DIFFERENT from "_novelty" and "_contribution":
      - _novelty = what is NEW about the approach
      - _contribution = what the paper ADDS to the field
      - _advancement = quantitative improvement over prior state-of-the-art
    If you wrote _novelty/_contribution but NOT _advancement, you MUST add _advancement.
  □ _sensitivity_result — parameter-performance dependencies WITH numbers
  □ tradeoff_summary — key design trade-offs (usually in discussion/optimization sections)
  □ _comparison_baseline — what the authors compared against
  □ _improvement_over_baseline — quantitative improvement over baseline
  □ causal_mechanism_summary — physical cause → observed effect chain

Each `_` field MUST be a dict `{{"value": "<concise statement>", "why_notable": "<what makes it noteworthy>"}}`, NOT a list of strings.

DO NOT emit `publication_year`, `journal`, `doi`, `title`, or `author` in extracted_data — these are paper-level metadata that the pipeline injects separately. Including them here creates duplicates.

## ★ SCHEMA COVERAGE GOAL — aim for 60+ fields per paper ★
The Schema defines 200+ fields spanning problem context, variables, metrics, and mechanisms. A well-extracted paper typically fills 50–100 schema fields; only 20–30 fields indicates you are under-scanning.

WALK THROUGH EVERY Schema field below. For each one, ask: "Does the paper explicitly state a value for this?" If yes → extract it. If no → omit it (per Priority 2 rule). Do NOT stop at 30 fields; do NOT stop at 50. Your target is complete coverage of what the paper actually reports.

Sections to re-scan for easy wins (commonly missed):
  - alloy_aliases — every synonym used for the main alloy (e.g., "Ti64", "TC4", "Ti-6Al-4V")
  - prior_beta_grain_size / final_grain_size — typical in microstructure tables
  - beta_transus_temperature / liquidus_temperature / solidus_temperature — in thermodynamic sections
  - heat_treatment_schedule / heat_extraction_path / atmosphere_condition — in processing sections
  - slip_system_set / twin_system_set — in deformation/plasticity discussion
  - ms_temperature / mf_temperature — in martensitic-transformation papers
  - elongation / ultimate_tensile_strength / hardness — in mechanical-property tables (not only yield_strength)
  - dendrite_arm_spacing / mushy_zone_thickness / interface_mobility — in solidification/phase-field papers

## ★ CONTROLLED VOCABULARY FOR ENUM FIELDS (STRICT) ★
For these fields use EXACTLY one of the listed lowercase canonical values. Do NOT invent variants, do NOT capitalize, do NOT paraphrase.

- study_type: {{experiment, simulation, theory, data-driven, coupled experiment-simulation, coupled theory-simulation}}
- study_scale: {{atomic-scale, interface-scale, microstructure-scale, grain-scale, mesoscale, ingot-scale, macroscale}}
  (you MAY list multiple; do NOT compound with "and", put each as a separate list item)
- composition_basis: {{wt.%, at.%, ppm, mole fraction, mixed basis}}
  (lowercase "wt.%" and "at.%" with the period; never "Wt.%" or "atomic fraction" or bare "wt%" without period)
- data_source_mode: {{direct experimental measurement, phase-field simulation, CALPHAD prediction, finite-element simulation, CFD simulation, molecular dynamics simulation, DFT calculation, CPFE simulation, machine-learning prediction, literature compilation, theoretical calculation}}
  (one or more from this list; do NOT write "experimental measurement" — use the canonical "direct experimental measurement")
- simulation_method: {{phase-field, multiphase-field, molecular dynamics, CALPHAD, finite-element, finite-difference, CFD, CPFE, DFT, machine learning, multiphysics, constitutive modeling, analytical, empirical fitting, spectral}}
  (use the BARE family name only; NEVER "phase-field model" / "phase-field method" / "phase-field modeling" / "phase-field simulation" — they all collapse to "phase-field". List multiple entries if the paper combines methods.)

If a value from the paper does not fit any of the above, pick the closest canonical form. Do NOT create new enum values.

## ★ NUMERIC VALUES: USE HYBRID {{raw, value_num, unit}} OBJECT FORMAT ★
For numeric Schema fields — anything ending with `_temperature`, `_rate`, `_strength`, `_size`, `_fraction`, `_time`, `_pressure`, `_content`, `_modulus`, `_energy`, `_density`, `_spacing`, `_width`, `_depth`, `_thickness`, `_gradient`, `_velocity`, `_current`, `_voltage`, `_power`, `_coefficient`, `_tension`, `_mobility`, or any field whose description says "temperature / rate / fraction / etc." — every array element MUST be an object with THREE keys:

```
{{"raw": "<exact text as written by the author>", "value_num": <single float or null>, "unit": "<canonical unit>"}}
```

Rules for each key:
  - `raw`: MUST always be filled with the LITERAL author phrasing — lossless; preserves ranges, approximations, sci-notation characters, everything. Example: "2×10⁸ s⁻¹", "1.40–7.00 nm", "~300 MPa".
  - `value_num`: a SINGLE float when `raw` is one unambiguous number; `null` otherwise (ranges, approximations, qualitative, placeholders). Use scientific e-notation for extreme magnitudes: `2e8`, `3.5e-9`. Never put strings here.
  - `unit`: canonical unit string (`K/s`, `wt.%`, `MPa`, `μm`, `s⁻¹`, `J/m²`, `K·m`, `N/m`). Empty string `""` only for dimensionless quantities; use `"dimensionless"` as the explicit marker.

Examples (CORRECT):
  "test_temperature": [{{"raw": "300 K", "value_num": 300, "unit": "K"}}]
  "strain_rate": [{{"raw": "2×10⁸ s⁻¹", "value_num": 2e8, "unit": "s⁻¹"}}]
  "yield_strength": [{{"raw": "500 MPa", "value_num": 500, "unit": "MPa"}}, {{"raw": "720 MPa", "value_num": 720, "unit": "MPa"}}]
  "heating_rate": [{{"raw": "2.0 K/s", "value_num": 2.0, "unit": "K/s"}}]
  "test_temperature": [{{"raw": "room temperature (≈298 K)", "value_num": 298, "unit": "K"}}]
  "tb_spacing": [{{"raw": "1.40–7.00 nm", "value_num": null, "unit": "nm"}}]

Examples (WRONG):
  [{{"value": "2.0", "unit": "K/s"}}]                                ← legacy format, MUST include raw and value_num
  [{{"raw": "500 MPa", "value_num": "500", "unit": "MPa"}}]         ← value_num must be a number, not string
  [{{"raw": "variable", "value_num": 0, "unit": "K/s"}}]            ← placeholder/qualitative → value_num MUST be null
  [{{"raw": "1.40–7.00 nm", "value_num": 1.40, "unit": "nm"}}]      ← range → value_num MUST be null (pick one endpoint is wrong)

Unit conventions (STRICT):
  - Temperature: ALWAYS canonical Kelvin. Convert any °C to K (K = °C + 273.15). Convert "room temperature" → value_num=298, unit="K". Never leave "Room temperature" as raw-only. Applies to: test_temperature, heat_treatment_temperature, deformation_temperature, homogenization_temperature, solution_treatment_temperature, aging_temperature, beta_transus_temperature, liquidus_temperature, solidus_temperature, ms_temperature, mf_temperature, transformation_temperature.
  - Time: ALWAYS canonical hours (h) for heat_treatment_time, soaking_time_before_deformation, aging_time, solution_treatment_time. Convert seconds → ÷3600; minutes → ÷60; ks → ÷3.6.
  - Rates (heating_rate, cooling_rate): canonical K/s. Convert K/min → ÷60. Strain_rate: s⁻¹. Solidification_rate: mm/s or μm/s (keep paper unit). A bare "K" or "mm" is WRONG for rate fields.
  - Strength / Stress (yield_strength, ultimate_tensile_strength, peak_flow_stress): MPa. Convert GPa → ×1000 and use MPa. (Exception: keep GPa for modulus fields like elastic_modulus.)
  - Elastic modulus: GPa
  - Elongation / any fraction field: %
  - Grain / feature size: μm or nm (keep what the paper uses)
  - Composition: element contents (ti_content, al_content, etc.) use the basis stated in composition_basis ("wt.%" with the period — never bare "wt%"; "at.%" with the period; or "ppm" for interstitials).
  - Diffusion coefficient: m²/s (convert cm²/s → ×10⁻⁴)
  - Interface energy: J/m² (convert J/cm² → ×10⁴; convert mJ/m² to J/m² ONLY if paper uses both, otherwise keep paper's chosen scale)
  - Gibbs-Thomson coefficient: K·m (write with middle dot, not "K*m" or "m·K")
  - Surface tension σ_sl: N/m (convert dyne/cm → ×10⁻³)
  - Vacuum pressure: Pa (convert kPa → ×1000, MPa → ×10⁶)
  - Thermal gradient: K/mm (convert K/cm → ×0.1, K/μm → ×1000)

If the paper reports a qualitative value only (e.g., "high yield strength" with no number), OMIT the field — do not invent.

## ★ FIELD NAME RULES (STRICT) ★
Use ONLY exact Schema field names for non-`_` entries. These substitutions are FORBIDDEN:
  WRONG: "dominate_mechanism"                 →  CORRECT: "dominant_mechanism"
  WRONG: "fabrication_method_note"            →  (include in fabrication_process narrative)
  WRONG: "influence_analysis_custom_factor"   →  (use _ prefixed custom field instead)

Eight legacy cross-domain fields have been MIGRATED to the `_` prefix namespace. Use the new names and the {{value, why_notable}} structure:
  WRONG: "advancement"                        →  CORRECT: "_advancement": {{"value": ..., "why_notable": ...}}
  WRONG: "novelty"                            →  CORRECT: "_novelty": {{"value": ..., "why_notable": ...}}
  WRONG: "contribution"                       →  CORRECT: "_contribution": {{"value": ..., "why_notable": ...}}
  WRONG: "comparison_baseline"                →  CORRECT: "_comparison_baseline": {{"value": ..., "why_notable": ...}}
  WRONG: "improvement_over_baseline"          →  CORRECT: "_improvement_over_baseline": {{"value": ..., "why_notable": ...}}
  WRONG: "sensitivity_result"                 →  CORRECT: "_sensitivity_result": {{"value": ..., "why_notable": ...}}
  WRONG: "study_validation_method"            →  CORRECT: "_study_validation_method": {{"value": ..., "why_notable": ...}}
  WRONG: "functional_role"                    →  CORRECT: "_functional_role": {{"value": ..., "why_notable": ...}}
  WRONG: "sensitivity_or_tolerance_analysis"  →  CORRECT: "_sensitivity_result": {{"value": ..., "why_notable": ...}}
  WRONG: "advanced"                           →  CORRECT: "_advancement": {{"value": ..., "why_notable": ...}}
  WRONG: "function_role"                      →  CORRECT: "_functional_role": {{"value": ..., "why_notable": ...}}

## 3. Task Steps
1. **Extract Schema fields**: scan the ENTIRE paper. For each Schema field found, extract its value(s) as a list. Collect ALL values across all design variants/experiments. Aim for ≥50 schema fields per paper (see SCHEMA COVERAGE GOAL above).
2. **Identify custom discoveries**: if the paper has original breakthroughs not covered by any Schema field, create `_` prefixed fields (max 20) with value + why_notable.
3. **Write descriptions** (SYNTHESIZE, do NOT copy paragraphs verbatim from the paper. Each field has a DISTINCT focus — avoid repeating the same content across fields.
   TARGET THE UPPER HALF of each word range. Shallow, telegraphic descriptions that merely name techniques without explaining HOW they were applied are insufficient.):

   - `problem_context` (200–250 words): WHAT problem + WHY it matters. Cover governing physics, boundary conditions, constraints, standards. Include the specific physical setting (material system, frequency range, operating environment) and what performance gap motivated the work. Do NOT describe methods or results here.

   - `study_process_description` (300–400 words): HOW the study was conducted. Cover the COMPLETE experimental/simulation workflow including ALL design variants, ALL parameter sweeps, ALL characterization steps, and ALL measurement conditions. List every distinct sample/configuration tested. Name every instrument, every software tool, every boundary condition. Do NOT explain physics or optimization logic here.

   - `design_optimization_logic` (200–300 words): WHY this design was chosen; HOW it was optimized. Describe the FULL optimization trajectory: initial concept, parametric exploration, final selection. State ALL trade-offs explicitly. Do NOT repeat fabrication details.

   - `physical_mechanism` (200–300 words): Causal chain connecting parameters to performance. Explain the COMPLETE mechanism chain from input stimulus, through intermediate physical process, to output response. Include supporting evidence (field maps, impedance curves, mode analysis). Do NOT re-describe experimental setup.

   - `fabrication_process` (180–300 words): ONLY physical fabrication/manufacturing steps. Include ALL process parameters: temperatures, pressures, times, atmospheres, tooling, layer sequences. Do NOT include characterization, simulation, or analysis methods.

   - `design_method` (150–200 words): Design WORKFLOW from requirements to validation. Describe the complete methodology pipeline including tool chain. Do NOT repeat fabrication or characterization details.

   - `influence_analysis` (220–300 words): ONLY quantitative parameter-to-performance sensitivities WITH specific numbers.
     MANDATORY: include AT LEAST 5 distinct quantitative relationships, each with specific numeric values. Structure as: "When [parameter] changed from [value A] to [value B], [metric] changed from [value C] to [value D] (delta = [value], [percentage]%)."
     Cover ALL key parameters varied in the study. If the paper reports more than 5, include ALL of them. Every sentence in this section MUST contain at least one number.

## 4. Value Formatting Rules for extracted_data
- Each array element = ONE distinct value. Do NOT merge multiple values into one string.
  CORRECT: ["SLM", "EBM"]   WRONG: ["SLM and EBM"]   WRONG: ["SLM/EBM"]
- Include units inline: ["500 °C", "800 °C"], NOT ["500", "800"]
- **NO parenthetical explanations in values.** Do NOT add descriptions, roles, or context in parentheses.
  WRONG: "FR4 (printed patch dielectric)"  →  CORRECT: "FR4"
  WRONG: "50 Ω (SMA connector/feed impedance)"  →  CORRECT: "50 Ω"
  WRONG: "Hf (electrode/back metal, metal layers)"  →  CORRECT: "Hf"
  WRONG: "Al2O3 (0001) (sapphire substrate)"  →  CORRECT: "Al2O3 (0001)"
  The ONLY allowed parenthetical is a crystallographic orientation like "(0001)" or a chemical formula like "(SiC/SiC)". All other parenthetical text must be removed.
- Numeric ranges use en-dash: ["300–500 K"], NOT ["300 K to 500 K"]
- **STRICT 10-word limit per array element.** Count your words before writing each value.
  If a value exceeds 10 words, you are adding unnecessary explanation — shorten it.
  Exception: `abstract` and all `_` prefixed discovery fields (the value inside {{value, why_notable}}) may contain longer text.
  WRONG: "flake FeSiAl/PEEK: −14.5 dB at 2.1 GHz vs. −1.5 dB pure PEEK; ~13 dB improvement" (16 words)
  CORRECT: "−14.5 dB at 2.1 GHz"
- For values with conditions, use "at" or "@": ["95% at 10 GHz", "85% at 45 deg incidence"]
- REMINDER: Do NOT include empty arrays `[]` or placeholder values. If a field has no values, omit it.

## 5. Output Format (JSON)
Output exactly ONE JSON object per paper. Schema field values MUST be arrays. Custom fields use object format with value + why_notable.
Only include fields that have actual extracted values — every key in extracted_data must have a non-empty array or a valid custom-field object.
```
WRONG examples (DO NOT do these):
  "operating_frequency_range": []              <- empty array, omit instead
  "polarization_condition": ["not applicable"] <- placeholder, omit instead
  "bandwidth_regime": ["not explicitly stated"] <- placeholder, omit instead
  "manufacturing_method": ["SLM and EBM used for both samples"] <- sentence, split into separate values
  "software_tool": ["CST (implied from VNA)"]  <- fabricated value, omit instead
```
```json
{{
  "paper_title": "consistent with input paper_title",
  "problem_context": "natural language (200-250 words)...",
  "study_process_description": "natural language covering ALL variants (300-400 words)...",
  "design_optimization_logic": "natural language (200-300 words)...",
  "physical_mechanism": "natural language with complete causal chain (200-300 words)...",
  "fabrication_process": "natural language with ALL process parameters (180-300 words)...",
  "design_method": "natural language (150-200 words)...",
  "influence_analysis": "AT LEAST 5 quantitative relationships with numbers (220-300 words)...",
  "extracted_data": {{
    "alloy_name_normalized": ["Ti-6Al-4V"],
    "alloy_system": ["α+β Ti alloy"],
    "simulation_method": ["phase-field", "CALPHAD"],
    "study_type": ["coupled experiment-simulation"],
    "composition_basis": ["wt.%"],
    "al_content": [{{"raw": "6.0 wt.%", "value_num": 6.0, "unit": "wt.%"}}],
    "test_temperature": [{{"raw": "298 K", "value_num": 298, "unit": "K"}}],
    "strain_rate": [{{"raw": "2×10⁸ s⁻¹", "value_num": 2e8, "unit": "s⁻¹"}}],
    "yield_strength": [{{"raw": "500 MPa", "value_num": 500, "unit": "MPa"}}, {{"raw": "720 MPa", "value_num": 720, "unit": "MPa"}}],
    "tb_spacing": [{{"raw": "1.40–7.00 nm", "value_num": null, "unit": "nm"}}],
    "interface_energy": [{{"raw": "0.35 J/m²", "value_num": 0.35, "unit": "J/m²"}}],
    "gibbs_thomson_coefficient": [{{"raw": "2.4×10⁻⁷ K·m", "value_num": 2.4e-7, "unit": "K·m"}}],
    "dominant_mechanism": ["LC resonance coupled with magnetic resonance"],
    "_advancement": {{
      "value": "yield strength +18% vs. baseline AM alloy while preserving 12% elongation",
      "why_notable": "First demonstration of this strength-ductility balance in duplex titanium via interstitial-mediated nano-precipitate design"
    }},
    "_comparison_baseline": {{
      "value": "conventional SLM-processed Ti-6Al-4V heat-treated to duplex morphology",
      "why_notable": "Chosen because it represents the current aerospace production standard"
    }},
    "_novel_metric_name": {{
      "value": "3.2x enhancement of fracture toughness over conventional design",
      "why_notable": "First demonstration of twinning-mediated toughening in γ-TiAl at room temperature"
    }}
  }}
}}
```
Please output only the JSON, without any other text.""",

}


# ===================================================================
# Haiku prompt — domain overlays
# ===================================================================
# 主 haiku 模板包含一个 {domain_overlay} 占位符。根据领域家族注入对应文本：
#   - titanium_alloy / titanium_am → HAIKU_OVERLAY_ALLOY（元素含量、合金名归一、界面能/Gibbs-Thomson 分流、alloy_system 枚举）
#   - aerospace                    → HAIKU_OVERLAY_AEROSPACE（EM/radome/antenna/manufacturing 字段提示）

HAIKU_OVERLAY_ALLOY = """## ★ HAIKU-SPECIFIC: ELEMENT-CONTENT RULE ★
The Schema has dedicated element fields ONLY for: ti_content, al_content, v_content, mo_content, nb_content,
cr_content, fe_content, sn_content, zr_content, o_content, n_content, c_content, h_content.
For ANY OTHER element (Ni, Cu, Mg, Mn, Si, B, Y, Ta, W, rare-earths, etc.), DO NOT create a `<element>_content` key.
Instead, append "<Element>: <value>" items to other_alloying_elements.

CORRECT: "other_alloying_elements": ["Ni: 0.5 wt%", "Cu: 0.3 wt%", "Si: 0.1 wt%"]
WRONG:   "ni_content": ["0.5 wt%"], "cu_content": ["0.3 wt%"], "si_content": ["0.1 wt%"]

## ★ FIELD-SPECIFIC UNIT WHITELIST (STRICT — interfaces physics family) ★
These four fields are easy to confuse because authors use overlapping terminology. Route by UNIT, not by how the author labels it:

  - interface_energy (σ): ACCEPTS ONLY J/m² or mJ/m² or erg/cm². Solid-liquid or inter-phase interfacial free energy per unit area.
  - gibbs_thomson_coefficient (Γ = σT_m/L): ACCEPTS ONLY K·m or m·K. Couples curvature to local undercooling. Capillary length d₀ also goes here.
  - surface_tension_sl (σ_sl): ACCEPTS ONLY N/m or dyne/cm. Solid-liquid surface tension.
  - gradient_energy_coefficient (ε₀): ACCEPTS ONLY J·m or normalized/dimensionless. Phase-field gradient energy coefficient.

If the paper reports K·m, put it in `gibbs_thomson_coefficient` — NEVER in `interface_energy`.
If the paper reports N/m, put it in `surface_tension_sl` — NEVER in `interface_energy` (even though the SI units J/m² and N/m are numerically equal, keep them separate so downstream consumers can trust the unit whitelist).
If the paper reports normalized ε₀, put it in `gradient_energy_coefficient`.

## ★ ALLOY NAME NORMALIZATION + ALIASES ★
- `alloy_designation_reported`: EVERY alloy name variant written by the authors, verbatim (do NOT normalize here).
- `alloy_name_normalized`: pick exactly ONE canonical form per distinct alloy from this controlled list:
    Ti-6Al-4V (covers Ti64, TC4, Ti6Al4V, Ti 6-4)
    γ-TiAl (covers TiAl, gamma-TiAl, g-TiAl)
    α2-Ti3Al (covers Ti3Al, alpha2-Ti3Al)
    α-Ti (covers α-titanium, alpha-titanium, high-purity α-titanium)
    β-Ti (covers β-titanium, beta-titanium)
    CP-Ti (covers pure titanium, commercially pure Ti, Ti grade 2, TA2)
    Ti-5553 / Ti-17 / Ti-6242 / Ti-55511 (use the trade designation)
    IN718 / IN625 (covers Inconel 718 / 625)
  For alloys outside this list, use the most concise compositional form (e.g., "Ti-30Zr-5Mo", "Mg-17.5Gd").
- `alloy_aliases`: ALL synonyms the authors used for the SAME alloy, as a list.
  Example: if the paper writes "Ti-6Al-4V (also referred to as Ti64 or TC4)", output
    "alloy_designation_reported": ["Ti-6Al-4V", "Ti64", "TC4"]
    "alloy_name_normalized": ["Ti-6Al-4V"]
    "alloy_aliases": ["Ti64", "TC4"]
  If the paper only uses ONE name, `alloy_aliases` should be OMITTED (do not output an empty list).

## ★ ALLOY-SPECIFIC CONTROLLED VOCABULARY (STRICT) ★
- alloy_system: use canonical forms: "α-Ti alloy", "near-α Ti alloy", "α+β Ti alloy", "β-Ti alloy", "near-β Ti alloy", "metastable β-Ti alloy", "γ-TiAl intermetallic", or compositional form ("Al-Cu binary", "Ni-based superalloy"). Always spell "α-Ti alloy" WITH hyphen; never "α titanium alloy" / "α-titanium" / "alpha titanium"."""


HAIKU_OVERLAY_AEROSPACE = """## ★ AEROSPACE-SPECIFIC: BARE SCHEMA FIELDS (OVERRIDES THE _-PREFIX MIGRATION RULE) ★
For the aerospace schema, the following 6 fields are FORMAL SCHEMA FIELDS (机理库) and MUST be emitted with their BARE names as list-of-strings — NOT with the `_` prefix and NOT with the {{value, why_notable}} structure.
This OVERRIDES the "Eight legacy cross-domain fields have been MIGRATED to the `_` prefix namespace" instruction above.

  CORRECT (aerospace):
    "advancement": ["dual-band FSS with 60° angular stability and minimal far-field aberration"]
    "novelty": ["flower-shaped miniaturized element FSS for conformal radome applications"]
    "contribution": ["novel conformal FSS achieving dual reflection bands with low pattern aberration"]
    "comparison_baseline": ["traditional concentric double-ring FSS"]
    "improvement_over_baseline": ["60° angular stability vs. 45° for traditional rings"]
    "sensitivity_result": ["outer loop perimeter 30→35.78 mm shifts f1 by -0.7 GHz"]

  WRONG (DO NOT do these in aerospace):
    "_advancement": {{"value": "...", "why_notable": "..."}}     ← migration rule does NOT apply here
    "_novelty": {{"value": "...", "why_notable": "..."}}
    "_contribution": {{"value": "...", "why_notable": "..."}}
    "_comparison_baseline": {{"value": "...", "why_notable": "..."}}
    "_improvement_over_baseline": {{"value": "...", "why_notable": "..."}}
    "_sensitivity_result": {{"value": "...", "why_notable": "..."}}

These 6 fields are list-of-strings, follow the same value-formatting rules as other schema fields (≤10 words per item, no parenthetical annotations, no placeholders). Reserve the `_` prefix namespace for genuinely paper-specific discoveries that have no matching schema field.

## ★ AEROSPACE-SPECIFIC: KEY FIELDS — EXTRACT WHEN PRESENT, NEVER FABRICATE ★
The schema flags certain fields as "重点字段" (key fields). Extract them aggressively WHEN the paper actually reports them. If the paper does not explicitly state a value, OMIT the field entirely — never invent, never infer, never paraphrase.

## ★ AEROSPACE-SPECIFIC: NUMERIC RANGES → value_min / value_max (not null) ★
For range-valued numeric entries, the hybrid object MUST carry `value_min` and `value_max` instead of `value_num: null`.

  CORRECT: {{"raw": "6–18 GHz", "value_min": 6, "value_max": 18, "unit": "GHz"}}
  CORRECT: {{"raw": "12 ± 0.2 GHz", "value_min": 11.8, "value_max": 12.2, "unit": "GHz"}}
  WRONG:   {{"raw": "6–18 GHz", "value_num": null, "unit": "GHz"}}
  WRONG:   {{"raw": "9.8 ± 0.2 GHz", "value_num": null, "unit": "GHz"}}

If the value is genuinely qualitative (no numbers), OMIT the field rather than emit value_num=null.

## ★ AEROSPACE-SPECIFIC COVERAGE HINTS ★
This paper belongs to the aerospace schema family (metamaterial / radome / manufacturing / supermaterial / satellite / pinn).
Focus on these commonly-missed schema fields when they are reported in the paper:

  - Materials: conductor_material, substrate_material, core_material, matrix_type, reinforcement_material, material_designation, material_system, starting_material_form
  - EM parameters: operating_frequency_range, center_frequency, bandwidth, polarization_condition, incidence_angle_range, permittivity, dielectric_loss_tangent, electrical_conductivity
  - Structural topology: unit_cell_topology, unit_cell_period, metal_linewidth, gap_width, substrate_thickness, total_thickness, array_periodicity
  - Structural geometry (metamaterial): spatial_symmetry (C4/mirror/rotational/asymmetric), gradient_geometry (size/shape/orientation gradient), connectivity (fully connected/isolated/bridged), multilayer_coupled (vertical coupling, inter-layer phase gradient), topological_features (genus, holes, Euler number)
  - Performance domains (metamaterial): frequency_performance (bandwidth, selectivity, out-of-band suppression), angular_performance (small/large angle stability), time_performance (group delay, insertion phase), polarization_conversion (linear-circular conversion efficiency)
  - Theory & mechanism (metamaterial): maxwell_equations_and_boundary_conditions, constitutive_relations_and_effective_medium_theory, surface_impedance_tensor, surface_polarizability, dispersion_engineering, wave_impedance_gradient, generalized_brewster
  - Optimization (metamaterial): optimization_objective, response_metrics, optimization_problem_formulation_equations
  - Performance: reflection_loss, absorption_peak, transmission_coefficient, insertion_loss, sidelobe_level, gain, efficiency, bore_sight_error, axial_ratio, rcs_reduction
  - Manufacturing: laser_power, scan_speed, layer_thickness, hatch_spacing, volumetric_energy_density, scan_strategy, atmosphere, porosity, surface_roughness, residual_stress
  - Superalloy / composite: fiber_volume_fraction, phase_constituents, tensile_strength, elongation, creep_rupture_life, fracture_toughness, elastic_modulus, thermal_conductivity
  - Satellite / topology-opt: topology_optimization_method, volume_fraction, penalty_factor, load_case, fundamental_frequency, mass_reduction
  - PINN / scientific ML: governing_pde, neural_network_architecture, collocation_points, loss_terms, training_data_size, l2_error, inference_speedup
  - Mechanism / design: dominant_mechanism, coupling_behavior, equivalent_model, impedance_matching_strategy, loss_engineering_strategy, characterization_method, design_workflow, causal_mechanism_summary

DO NOT invent titanium-alloy-specific field names that do not exist in the aerospace schema. Fields like
`alloy_system`, `alloy_name_normalized`, `alloy_aliases`, `ti_content`, `al_content`, `beta_transus_temperature`,
`prior_beta_grain_size`, `interface_energy`, `gibbs_thomson_coefficient`, `martensite_fraction` belong to a
separate titanium-alloy schema and MUST NOT be emitted here. If the paper is about a titanium alloy in the
aerospace context, record it via `material_designation` or `material_system` instead."""


HAIKU_OVERLAY_DEFAULT = ""  # 未知家族时留空（不注入任何域特定约束）


def _haiku_overlay_for(domain_family: str) -> str:
    """根据领域家族选择 haiku prompt 的 domain overlay 片段。"""
    if domain_family in ("titanium_alloy", "titanium_am"):
        return HAIKU_OVERLAY_ALLOY
    if domain_family == "aerospace":
        return HAIKU_OVERLAY_AEROSPACE
    return HAIKU_OVERLAY_DEFAULT


def build_prompt(domains: list, model: str = "", domain_family: str = "") -> str:
    """
    根据论文的 domains、模型名称、领域家族动态组装 prompt。

    MVP 仅支持 claude haiku 系列模型，其他模型会被拒绝。

    Args:
        domains:       filter 阶段确定的域列表，如 ["metamaterial", "radome"]
        model:         模型名称（必须包含 "haiku"，否则 ValueError）
        domain_family: 领域家族（"aerospace" / "titanium_alloy" / "titanium_am"）；
                       haiku 模板会据此注入对应的 overlay 片段。

    Returns:
        组装好的 prompt 模板（仍含 {paper_title} 等占位符待填充）
    """
    if model and "haiku" not in model.lower():
        raise ValueError(
            f"MVP 仅支持 claude haiku 模型，收到: {model!r}。"
            "请把 --models / configs 里的提取模型改成 claude-haiku-* 系列。"
        )

    parts = [CATEGORY_COMMON]

    if domains:
        for d in domains:
            if d in DOMAIN_CATEGORIES:
                parts.append(DOMAIN_CATEGORIES[d])
    else:
        for cat in DOMAIN_CATEGORIES.values():
            parts.append(cat)

    domain_categories = "\n".join(parts)

    template = UNIFIED_PROMPTS["extract_mechanism_haiku"]

    result = template.replace("{domain_categories}", domain_categories)
    result = result.replace("{domain_overlay}", _haiku_overlay_for(domain_family))
    return result
