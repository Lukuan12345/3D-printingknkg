"""prompts — LLM 提示词子包。

包含两类 prompt 模板：
  - extract.build_prompt           : 结构化知识提取 prompt（按 domain × model 组装）
  - classify.build_classify_prompt : 相关性过滤 + 领域分类 prompt
"""

from .extract import build_prompt
from .classify import (
    DOMAIN_LIBRARY,
    DEFAULT_VALID_DOMAINS,
    DOMAIN_FAMILY_SETS,
    infer_domain_family,
    register_domain_family,
    collect_valid_domains_from_schema,
    build_classify_prompt,
)

__all__ = [
    "build_prompt",
    "DOMAIN_LIBRARY",
    "DEFAULT_VALID_DOMAINS",
    "DOMAIN_FAMILY_SETS",
    "infer_domain_family",
    "register_domain_family",
    "collect_valid_domains_from_schema",
    "build_classify_prompt",
]
