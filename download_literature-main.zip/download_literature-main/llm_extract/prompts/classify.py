#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
prompts.classify — 相关性过滤 + 领域分类的 prompt 模板与 domain library。

从 extract_test.py 抽出，集中管理分类 prompt 及其支持数据：
  - DOMAIN_LIBRARY        各领域标签 → 自然语言描述
  - DEFAULT_VALID_DOMAINS 默认 aerospace 6 域（回退用）
  - DOMAIN_FAMILY_SETS    领域家族 → 域集合映射
  - _infer_domain_family  从域集合反推领域家族
  - _collect_valid_domains_from_schema  从 schema CSV 收集可用域
  - build_classify_prompt 动态构造分类 prompt
"""

import logging
import re
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


# ===================================================================
# Domain Library — 支持多套 schema 的动态域集合
# ===================================================================
# 说明：不同 schema CSV 的 "适用领域" 列使用不同的域标签体系：
#   aerospace      : manufacturing / metamaterial / pinn / radome / satellite / supermaterial
#   titanium_alloy : VAR_solidification / hot_deformation_DRX / TiAl_phase_field /
#                    martensitic_transformation / Ti64_texture_CP
#   titanium_am    : material_system / AM_process / process_parameters /
#                    solidification_microstructure / defects_quality / post_processing /
#                    mechanical_properties / mechanisms_relationships /
#                    advanced_modeling / characterization / high_intensity_markers

DOMAIN_LIBRARY: dict = {
    # --- aerospace 6 ---
    "manufacturing":  "additive manufacturing, machining, composite fabrication, welding, heat treatment, surface treatment, process optimization, any fabrication process",
    "metamaterial":   "metamaterials, metasurfaces, FSS, absorbers, coding metasurfaces, polarization converters, beam-steering, EM engineered structures, photonic crystals",
    "pinn":           "physics-informed neural networks, scientific ML, operator learning, data-driven PDE solvers, computational modeling with neural networks",
    "radome":         "radome wall design, antenna-radome integration, standalone antenna design, phased arrays, FSS-embedded radomes, any antenna engineering",
    "satellite":      "spacecraft structures, satellite subsystems, topology/structural optimization, lightweight design, orbit/mission engineering",
    "supermaterial":  "superalloys, CMC, high-performance CFRP, lattice/architected structures, mechanical/acoustic metamaterials, TBC/EBC coatings, advanced functional materials",

    # --- titanium_alloy 5 research directions ---
    "VAR_solidification":         "vacuum arc remelting (VAR) of titanium alloys, melt pool evolution, macrosegregation, fluid flow/heat transfer, electromagnetic stirring, Lorentz force, multiphase flow, FE/multiphysics ingot-scale simulation",
    "hot_deformation_DRX":        "high-strength β / metastable-β / near-β titanium alloy hot deformation, hot compression/forging/rolling, dynamic recrystallization (DRX), flow behavior/softening, thermo-mechanical processing, deformation twinning",
    "TiAl_phase_field":           "Ti-Al alloys / titanium aluminides / γ-TiAl, solidification microstructure, dendrite growth, peritectic solidification, phase-field simulation, CALPHAD thermodynamics, interfacial energy",
    "martensitic_transformation": "martensitic or deformation-induced phase transformation in Ti alloys, thermodynamic driving force, elastic strain energy, energy barrier, β→α' / β→α'' transformation pathway, microstructural stability",
    "Ti64_texture_CP":            "Ti-6Al-4V / Ti64 / TC4 texture and crystal plasticity, texture evolution, mechanical anisotropy, deformation mechanism, twinning, crystal plasticity finite element (CPFE / CPFEM)",

    # --- titanium_am 11 sub-topic groups ---
    "material_system":               "titanium-AM material system: β/near-β, α+β high-strength, γ-TiAl / Ti-Al, Ti-6Al-4V, Ti-5553, Ti-6242 — alloy class / composition / interstitials",
    "AM_process":                    "AM process families for titanium: LPBF/SLM, powder bed fusion (PBF), electron beam melting (EBM), directed energy deposition (DED/L-DED), laser metal deposition (LMD), wire arc additive manufacturing (WAAM)",
    "process_parameters":            "AM process parameters and thermal history: laser/beam power, scan speed, hatch spacing, layer thickness, VED, scan strategy, rotation angle, build orientation, preheat, melt pool dynamics, cooling rate, thermal gradient",
    "solidification_microstructure": "AM titanium solidification and microstructure: prior β grain morphology, α'/α'' martensite, α lamellae, basketweave/bimodal/heterogeneous microstructure, recrystallization, texture evolution",
    "defects_quality":               "AM defects and quality: porosity (gas/keyhole), lack of fusion, unmelted particles, balling, cracking, surface roughness, dimensional accuracy, oxygen/nitrogen pickup, contamination",
    "post_processing":               "post-processing / heat treatment of AM titanium: stress relief, annealing, solution treatment, aging (including duplex/STA), HIP, thermo-mechanical post-processing",
    "mechanical_properties":         "mechanical properties of AM titanium: tensile (UTS/YS), elongation, hardness, fatigue, fracture toughness, creep, wear, anisotropy, XY vs Z directionality",
    "mechanisms_relationships":      "process-structure-property relationships, strengthening / deformation / phase-transformation / texture-property mechanisms, residual stress evolution, causal explanations",
    "advanced_modeling":             "advanced modeling for AM titanium: FEM/multiphysics thermal, phase-field, CALPHAD, crystal plasticity (CPFE), constitutive models, processing map, ML surrogate, multiscale",
    "characterization":              "characterization methods: EBSD, XRD, SEM, TEM, fractography, in-situ monitoring of AM processes",
    "high_intensity_markers":        "titanium high-intensity markers: heterogeneous + ultra-strong microstructure, interstitial oxygen + ultra-fine grain, multi-step TMP + TRIP/TWIP",
}

# 默认（aerospace 6）— 当 schema CSV 没有"适用领域"列时回退使用
DEFAULT_VALID_DOMAINS = {"manufacturing", "metamaterial", "pinn", "radome", "satellite", "supermaterial"}

# 领域家族对应的域集合（用于从 VALID_DOMAINS 反推 domain_family）
DOMAIN_FAMILY_SETS = {
    "aerospace": {"manufacturing", "metamaterial", "pinn", "radome", "satellite", "supermaterial"},
    "titanium_alloy": {"VAR_solidification", "hot_deformation_DRX", "TiAl_phase_field",
                        "martensitic_transformation", "Ti64_texture_CP"},
    "titanium_am": {"material_system", "AM_process", "process_parameters",
                    "solidification_microstructure", "defects_quality", "post_processing",
                    "mechanical_properties", "mechanisms_relationships",
                    "advanced_modeling", "characterization", "high_intensity_markers"},
}


def infer_domain_family(valid_domains: set) -> Optional[str]:
    """根据 VALID_DOMAINS 判断 domain_family。多家族/未知返回 None。"""
    best_family = None
    best_overlap = 0
    for family, fset in DOMAIN_FAMILY_SETS.items():
        overlap = len(valid_domains & fset)
        if overlap > best_overlap:
            best_overlap = overlap
            best_family = family
    return best_family


def register_domain_family(family: str, subdomains: set,
                           descriptions: Optional[dict] = None) -> None:
    """运行时把 mg.txt 等 domain_prefer 文件里的子域注册进 DOMAIN_LIBRARY /
    DOMAIN_FAMILY_SETS，以便 collect_valid_domains_from_schema 把它们识别为合法标签。
    """
    if not family or not subdomains:
        return
    DOMAIN_FAMILY_SETS.setdefault(family, set()).update(subdomains)
    descriptions = descriptions or {}
    for sd in subdomains:
        if sd in DOMAIN_LIBRARY:
            continue
        DOMAIN_LIBRARY[sd] = descriptions.get(sd, f"{family} sub-domain: {sd}")


def collect_valid_domains_from_schema(schema_csv: str) -> set:
    """
    从 Schema CSV 的"适用领域"列收集所有合法域标签。
    - 支持 .csv 和 .xlsx
    - 返回值 ∩ DOMAIN_LIBRARY 过滤掉未知标签
    - 未找到该列 / 空结果 → 返回空集合（调用方需回退到 DEFAULT_VALID_DOMAINS）

    任何"静默失败"的路径都会打 warning，避免 domain_family 与实际分类域不一致。
    """
    path = Path(schema_csv)
    collected: set = set()
    if not path.exists():
        logger.warning("schema CSV 不存在，将回退到 DEFAULT_VALID_DOMAINS: %s", schema_csv)
        return collected

    COL_DOMAINS = "适用领域"

    if path.suffix.lower() in (".xlsx", ".xls"):
        try:
            import pandas as _pd
        except ImportError:
            logger.warning("读取 .xlsx 需要 pandas/openpyxl，跳过域收集")
            return collected
        df = _pd.read_excel(schema_csv)
        if COL_DOMAINS not in df.columns:
            logger.warning("schema CSV 中未找到 '%s' 列（可用列: %s），将回退到 DEFAULT_VALID_DOMAINS",
                           COL_DOMAINS, list(df.columns))
            return collected
        values = (str(v) for v in df[COL_DOMAINS].tolist())
    else:
        import csv as _csv
        with open(schema_csv, encoding="utf-8-sig", newline="") as f:
            reader = _csv.DictReader(f)
            fieldnames = reader.fieldnames or []
            if COL_DOMAINS not in fieldnames:
                logger.warning("schema CSV 中未找到 '%s' 列（可用列: %s），将回退到 DEFAULT_VALID_DOMAINS",
                               COL_DOMAINS, fieldnames)
                return collected
            values = [str(row.get(COL_DOMAINS, "") or "") for row in reader]

    unknown_tags: set = set()
    for val in values:
        if not val or val.strip() == "" or val.strip().lower() == "nan":
            continue
        for tag in re.split(r"[,，;；]\s*", val):
            tag = tag.strip()
            if not tag:
                continue
            if tag in DOMAIN_LIBRARY:
                collected.add(tag)
            else:
                unknown_tags.add(tag)

    if not collected and unknown_tags:
        logger.warning(
            "schema CSV '%s' 列含标签 %s，但没有一个匹配 DOMAIN_LIBRARY；"
            "若这是新领域族，请在 prompts/classify.py 的 DOMAIN_LIBRARY / DOMAIN_FAMILY_SETS 中注册。",
            COL_DOMAINS, sorted(unknown_tags),
        )
    return collected


def build_classify_prompt(valid_domains: set, excerpt: str) -> str:
    """根据当前生效的域集合动态构造分类 prompt。"""
    dlist = sorted(valid_domains)
    desc_lines = [f"- **{d}**: {DOMAIN_LIBRARY[d]}" for d in dlist if d in DOMAIN_LIBRARY]
    desc_block = "\n".join(desc_lines)
    domain_enum = ", ".join(dlist)

    return f"""You are a scientific literature classifier. Read the excerpt below and determine:
1. Whether this paper is relevant to **materials science, metallurgy, engineering, or industrial technology** (broadly: any paper about materials, alloys, structures, electromagnetic devices, manufacturing processes, metallurgical processes, computational simulation of physical systems, or engineering design).
2. If relevant, which specific sub-domains it belongs to (can be multiple).

## Relevance criteria (INCLUSIVE — keep if ANY applies)
- Materials / metallurgy: metals, **titanium alloys (Ti-6Al-4V, TC4, β-Ti, γ-TiAl)**, superalloys, composites, ceramics, polymers, metamaterials, coatings, thin films
- Processing / manufacturing: additive manufacturing (LPBF/EBM/DED/LMD/WAAM), vacuum arc remelting (VAR), casting/solidification, hot deformation, heat treatment, welding, machining, surface treatment, fabrication
- Microstructure / phase transformation: solidification, martensitic transformation, phase-field, CALPHAD, recrystallization, texture, crystal plasticity (CPFE)
- Mechanical & thermal: tensile / fatigue / creep / fracture, defects/porosity, residual stress, thermo-mechanical processing
- Structures: antennas, radomes, absorbers, FSS, lattice structures, sandwich panels, aerospace structures
- Electromagnetic: EM design, wave propagation, microwave, THz, optics, photonics
- Computational: PINN, FEM, CFD, ML for engineering/materials, simulation, optimization
- Engineering systems: spacecraft, satellite, radar, communication systems
- ONLY reject if the paper is purely about: biology, medicine, social science, economics, pure mathematics, or humanities with NO engineering/material/metallurgical content

## Sub-domain classification (assign ALL that apply)
{desc_block}

### How to choose the number of labels

Label count should reflect the paper's actual scope. Do NOT force a single label, and do NOT inflate the label list.

1. **Clearly single-domain** → ONE label.
   The paper focuses on one sub-domain; other sub-domains are not materially studied, only briefly cited or absent.
   Example: a paper purely on Ti-6Al-4V CPFE texture with no discussion of martensite or phase-field → `[Ti64_texture_CP]`.
   Example: a paper purely on hot-deformation DRX of Ti-6Al-4V with no phase-field content → `[hot_deformation_DRX]`.

2. **Clearly multi-domain** → MULTIPLE labels.
   The paper materially investigates two or more sub-domains (distinct methods, dedicated sections, or shared governing physics across domains).
   Example: a paper simulating γ-TiAl solidification via phase-field AND analyzing β→α' martensitic pathway → `[TiAl_phase_field, martensitic_transformation]`.
   Example: a γ-TiAl hot-deformation study that uses TiAl-specific thermodynamics for DRX modeling → `[hot_deformation_DRX, TiAl_phase_field]`.

3. **Borderline — lean toward multi-label**.
   If you are uncertain whether a secondary sub-domain is "material enough", include it rather than drop it. A secondary sub-domain qualifies when the paper has any of:
     (a) explicit keywords/methods matching that sub-domain's description, OR
     (b) ≥1 paragraph of analysis on phenomena belonging to that sub-domain, OR
     (c) a target material or governing physics shared with that sub-domain.
   It does NOT need to be the main topic. When in doubt, add the label.

4. Output `[]` only when NO listed sub-domain has any meaningful presence in the excerpt.

## Paper Excerpt
{excerpt}

## Output (JSON)
```json
{{
  "is_relevant": true/false,
  "domains": ["domain1", "domain2"],
  "reason": "brief explanation — if multiple domains, state the evidence for EACH"
}}
```
`domains` MUST be a subset of: {domain_enum}.
If the paper is relevant but none of the listed sub-domains match, return `"domains": []`.
If the paper is not relevant at all, return `"is_relevant": false` and `"domains": []`."""
