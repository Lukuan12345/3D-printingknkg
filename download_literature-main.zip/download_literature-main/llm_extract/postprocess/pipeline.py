#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
postprocess.py — 模型分支后处理 + Schema 验证 + 编码后处理管道。

提供四层清洗管线：
  1. 输入预处理  preprocess_paper_input()   — 所有模型共享，LLM 调用前
  2. 输出后处理  postprocess()              — 按模型分支，LLM 输出后
  3. 编码后处理  fix_encoding()             — 所有模型共享，修复编码/类型问题
  4. Schema 验证 validate_extraction()      — 所有模型共享，写入前质量门禁

用法：
  from postprocess import preprocess_paper_input, postprocess, fix_encoding, validate_extraction
"""

import re
import csv
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


# ===================================================================
# Schema 白名单加载（供 _enforce_schema_whitelist 使用）
# ===================================================================

_SCHEMA_FIELDS_CACHE: Optional[frozenset] = None
_SCHEMA_CSV_OVERRIDE: Optional[str] = None
# 默认兜底路径：历史版本（titanium_alloy）。新代码通过 set_schema_csv() 覆盖。
_SCHEMA_CSV_PATH_DEFAULT = (
    Path(__file__).parent
    / "titanium_schema_output"
    / "gpt-5.4-pro"
    / "titanium_alloy"
    / "schema"
    / "final_schema_with_domains.csv"
)

# 领域家族（aerospace / titanium_alloy / titanium_am）
# 控制 _postprocess_haiku 中哪些 alloy 专用步骤会执行
_DOMAIN_FAMILY: str = "titanium_alloy"

# 使用范围过滤（机理库 / 通用 / None）。None 表示不过滤。
# 只影响 _enforce_schema_whitelist：与 usage_scope 不匹配的字段被丢弃。
_USAGE_SCOPE: Optional[str] = None

# alloy 系列家族集合（需要跑 alloy 专用后处理步骤）
_ALLOY_FAMILIES = frozenset({"titanium_alloy", "titanium_am"})

# 在 aerospace schema 中以「机理库」正式存在的跨域字段；LLM 若误输出为 _ 前缀，
# 需要在 _postprocess_haiku 中还原为裸名 list 形式。
_AEROSPACE_BARE_SCHEMA_FIELDS = frozenset({
    "advancement",
    "novelty",
    "contribution",
    "comparison_baseline",
    "improvement_over_baseline",
    "sensitivity_result",
})


def set_schema_csv(path: str) -> None:
    """由 extract_test.py 在启动时调用，指定本次运行使用的 schema CSV 路径。
    重置 _SCHEMA_FIELDS_CACHE，下一次 _load_schema_fields() 会重新读取。"""
    global _SCHEMA_CSV_OVERRIDE, _SCHEMA_FIELDS_CACHE
    _SCHEMA_CSV_OVERRIDE = path
    _SCHEMA_FIELDS_CACHE = None
    logger.info("postprocess schema CSV set to: %s", path)


def set_domain_family(family: str) -> None:
    """由 extract_test.py 在启动时调用，指定本次运行的领域家族。
    alloy 专用步骤只在 titanium_alloy / titanium_am 下执行。"""
    global _DOMAIN_FAMILY
    _DOMAIN_FAMILY = family
    logger.info("postprocess domain family set to: %s", family)


def set_usage_scope(scope: Optional[str]) -> None:
    """由 extract_test.py 在启动时调用，指定本次运行的使用范围（如 "机理库"）。
    与 config.schema.usage_scope 同值。重置 _SCHEMA_FIELDS_CACHE 以便重新读取并过滤。"""
    global _USAGE_SCOPE, _SCHEMA_FIELDS_CACHE
    _USAGE_SCOPE = scope or None
    _SCHEMA_FIELDS_CACHE = None
    logger.info("postprocess usage scope set to: %s", _USAGE_SCOPE)


def _is_alloy_family(family: Optional[str] = None) -> bool:
    return (family or _DOMAIN_FAMILY) in _ALLOY_FAMILIES

# 允许进入 extracted_data 但不在 schema CSV 里的字段
# - publication_year / author / title / data_source / domain：由 md_header 解析后由 inject_fields 注入
# - 历史上曾白名单的 8 个跨域字段（contribution / novelty / advancement / study_validation_method /
#   comparison_baseline / improvement_over_baseline / sensitivity_result / functional_role）
#   已按策略迁移到 _ 前缀（见 _FIELD_RENAME_TO_UNDERSCORE）。它们现在作为 {value, why_notable}
#   结构的独特发现字段出现，受 20 条/篇的上限约束；_enforce_schema_whitelist 不再放行它们的
#   裸名形式。离线 patch 时会由 _apply_underscore_rename 自动改名 + 重构。
_EXTRA_ALLOWED_FIELDS = frozenset({
    # md header 解析后 inject
    "author", "publication_year", "title",
    # extract_config_alloy.yaml 的 inject_fields
    "data_source", "domain",
})


# 离线迁移：老字段裸名 → 新的 _ 前缀名。配合 _apply_underscore_rename 把 list-of-strings
# 重构成 {value, why_notable}。prompt 自 2025-Q2 起直接要求 LLM 输出 _ 前缀。
_FIELD_RENAME_TO_UNDERSCORE = {
    "advancement": "_advancement",
    "sensitivity_result": "_sensitivity_result",
    "comparison_baseline": "_comparison_baseline",
    "improvement_over_baseline": "_improvement_over_baseline",
    "novelty": "_novelty",
    "contribution": "_contribution",
    "study_validation_method": "_study_validation_method",
    "functional_role": "_functional_role",
}


def _load_schema_fields() -> frozenset:
    """首次调用时从 CSV 读取 schema 英文字段名并缓存。
    若 set_schema_csv() 已调用，使用覆盖路径；否则使用默认（alloy）路径。
    若 set_usage_scope() 已设置，过滤掉使用范围与之不匹配的字段
    （使用范围为空 / "nan" 的行一律保留，视作无约束）。"""
    global _SCHEMA_FIELDS_CACHE
    if _SCHEMA_FIELDS_CACHE is None:
        fields = set()
        schema_path = Path(_SCHEMA_CSV_OVERRIDE) if _SCHEMA_CSV_OVERRIDE else _SCHEMA_CSV_PATH_DEFAULT
        scope_filter = _USAGE_SCOPE
        skipped_by_scope = 0
        try:
            if schema_path.suffix.lower() in (".xlsx", ".xls"):
                import pandas as _pd
                df = _pd.read_excel(schema_path)
                col = "字段名（英文）"
                col_scope = "使用范围"
                if col in df.columns:
                    for _, row in df.iterrows():
                        v = str(row.get(col, "")).strip()
                        if not v or v.lower() == "nan":
                            continue
                        if scope_filter:
                            rs = str(row.get(col_scope, "")).strip()
                            if rs and rs.lower() != "nan" and rs != scope_filter:
                                skipped_by_scope += 1
                                continue
                        fields.add(v)
            else:
                with open(schema_path, "r", encoding="utf-8-sig") as f:
                    for row in csv.DictReader(f):
                        fn = row.get("字段名（英文）", "").strip()
                        if not fn:
                            continue
                        if scope_filter:
                            rs = row.get("使用范围", "").strip()
                            if rs and rs.lower() != "nan" and rs != scope_filter:
                                skipped_by_scope += 1
                                continue
                        fields.add(fn)
        except FileNotFoundError:
            logger.error(
                "Schema CSV not found at %s; whitelist disabled", schema_path
            )
            fields = set()
        _SCHEMA_FIELDS_CACHE = frozenset(fields | _EXTRA_ALLOWED_FIELDS)
        if fields:
            logger.info(
                "Loaded %d schema fields from %s (+%d extra allowed%s)",
                len(fields), schema_path.name,
                len(_EXTRA_ALLOWED_FIELDS),
                f", scope={scope_filter}, skipped {skipped_by_scope}"
                if scope_filter else "",
            )
    return _SCHEMA_FIELDS_CACHE


# ===================================================================
# A. 输入预处理（所有模型共享）
# ===================================================================

def preprocess_paper_input(paper: dict) -> dict:
    """
    LLM 调用前的输入清洗。修复 PDF 解析残留，所有模型受益。

    处理项：
      - 标题：去除 [P0xx] 编号前缀、文件名格式前缀、CamelCase 粘连、截断末尾
      - 正文：去除脚注上标残留符号
    """
    paper = paper.copy()
    title = paper.get("title", "")

    # 1. 去除论文编号前缀 [P001]
    title = re.sub(r"^\[P\d+\]\s*", "", title)

    # 2. 去除文件名格式前缀 unknown-Journal_Name- 或 Author-Year-Title 格式
    #    匹配 "unknown-Xxx_Yyy_Zzz-" 开头
    title = re.sub(
        r"^unknown-[A-Za-z0-9_]+(?:-[A-Za-z0-9_]+)*-(?=[A-Z])", "", title
    )
    #    匹配 Author-Year- 前缀格式 (如 Bharathi-2026-)
    title = re.sub(
        r"^[A-Z][a-z]+-\d{4}-", "", title
    )

    # 3. 修复 CamelCase 粘连 (ThermionicEmission → Thermionic Emission)
    #    仅在连续字母中拆分 lowercase→Uppercase
    #    排除化学式（前面仅1-2字母，如 SiO, AlN, TiO2）
    title = re.sub(r"(?<=[a-z]{3})([A-Z])", r" \1", title)

    # 3b. 修复 OCR 遗留的同大小写粘连 (Emissionin → Emission in, Methodfor → Method for)
    #     策略：对标题中每个无空格的长词段（>15字符），尝试在常见介词处拆分
    def _split_stuck_word(match):
        word = match.group(0)
        if len(word) <= 15:
            return word  # 短段不处理，避免误拆 "broadband" 等正常词
        # 在常见介词前拆分
        result = re.sub(
            r"([a-z]{4,})(in|of|for|and|with|from|based|using|via)(?=[A-Z]|$)",
            r"\1 \2", word,
        )
        return result

    title = re.sub(r"[A-Za-z-]{16,}", _split_stuck_word, title)

    # 4. 清理文件名下划线 (Inverse_Design_of → Inverse Design of)
    title = title.replace("_", " ")

    # 5. 修复截断末尾
    title = title.rstrip("_-. ")

    # 6. 清理多余空格
    title = re.sub(r"\s+", " ", title).strip()

    paper["title"] = title

    # 7. Markdown 正文清洗
    md = paper.get("markdown_content", "")
    if md:
        # 去除 PDF 脚注上标残留 (紧跟字母后的 ¹²³ 等)
        md = re.sub(r"(?<=[a-zA-Z])[¹²³⁴⁵⁶⁷⁸⁹⁰]+", "", md)
        paper["markdown_content"] = md

    return paper


# ===================================================================
# C. 输出后处理（模型分支）
# ===================================================================

def postprocess(result: dict, model: str, domain_family: Optional[str] = None) -> dict:
    """
    模型分支后处理入口。

    Args:
        result:        LLM 返回的单篇提取结果 dict
        model:         模型名称字符串（如 "claude-haiku-4-5-20251001"）
        domain_family: 领域家族（aerospace / titanium_alloy / titanium_am）
                       None 时使用模块级 _DOMAIN_FAMILY（由 set_domain_family 设置）

    Returns:
        清洗后的 result dict
    """
    if not isinstance(result, dict):
        return result

    family = domain_family or _DOMAIN_FAMILY

    # 模型专用后处理
    if "nano" in model:
        result = _postprocess_nano(result)
    elif "mini" in model:
        result = _postprocess_mini(result)
    elif "haiku" in model:
        result = _postprocess_haiku(result, family)

    # 所有模型共享的通用后处理
    result = _postprocess_common(result)
    return result


# ── 共享后处理 ──

_PLACEHOLDER_RE = re.compile(
    r"^(not\s+(available|extracted|provided|applicable|mentioned|reported|specified|"
    r"quantified|measured|determined|characterized|"
    r"explicitly\s+(stated|reported|mentioned|measured|provided|given|quantified))"
    r"(\s.*)?|n/?a|none|unknown|nil|—|-)$",
    re.IGNORECASE,
)


def _postprocess_common(result: dict) -> dict:
    """所有模型共享的轻量清洗：清除占位符漏网之鱼。"""
    ext = result.get("extracted_data", {})
    if not isinstance(ext, dict):
        return result

    keys_to_delete = []
    for key, val in ext.items():
        if isinstance(val, list):
            cleaned = [
                v for v in val
                if not (isinstance(v, str) and _PLACEHOLDER_RE.match(v.strip()))
            ]
            if not cleaned:
                keys_to_delete.append(key)
            elif len(cleaned) != len(val):
                ext[key] = cleaned

    for key in keys_to_delete:
        del ext[key]

    result["extracted_data"] = ext
    return result


# ── Nano 专用后处理（深度清洗） ──

# 字段名纠错映射
_NANO_FIELD_ALIASES = {
    "sensitivity_or_tolerance_analysis": "sensitivity_result",
    "advanced": "advancement",
    "function_role": "functional_role",
    "dominate_mechanism": "dominant_mechanism",
    "fabrication_method_note": None,           # 丢弃，应在叙述中
    "influence_analysis_custom_factor": None,   # 丢弃，应为 _ 前缀
}

# 关键词常见 OCR 拼写修正
_KEYWORD_FIXES = {
    "Ill-nitride": "III-nitride",
    "superlattces": "superlattices",
    "coeficient": "coefficient",
    "transformationoptics": "transformation optics",
    "Rasorber": "Rasorber",  # 保留原词（这是领域术语 Radome+Absorber）
}


def _postprocess_nano(result: dict) -> dict:
    """Nano 专用深度清洗。"""
    ext = result.get("extracted_data", {})
    if not isinstance(ext, dict):
        return result

    # ── C1: 类型归一化 (bare string/dict → list) ──
    for key in list(ext.keys()):
        if key.startswith("_"):
            continue  # custom fields 允许 dict 格式
        val = ext[key]
        if isinstance(val, str):
            ext[key] = [val]
        elif isinstance(val, dict):
            # 误判为 custom field 的标准字段
            if "value" in val:
                ext[key] = [str(val["value"])]
            else:
                ext[key] = [str(val)]
        elif isinstance(val, (int, float)):
            ext[key] = [str(val)]

    # ── C2: 字段名规范化 ──
    for wrong_name, correct_name in _NANO_FIELD_ALIASES.items():
        if wrong_name in ext:
            if correct_name and correct_name not in ext:
                ext[correct_name] = ext[wrong_name]
            del ext[wrong_name]

    # ── C3: _advancement 自动合成 ──
    _apply_underscore_rename(ext)
    if "_advancement" not in ext:
        src_values = []
        for src_key in ("_improvement_over_baseline", "_novelty", "_contribution"):
            src = ext.get(src_key)
            if isinstance(src, dict):
                v = src.get("value")
                if v:
                    src_values.append(str(v))
        if src_values:
            ext["_advancement"] = {
                "value": " | ".join(src_values[:3]),
                "why_notable": "Synthesized from _improvement_over_baseline / _novelty / _contribution",
            }

    # ── C4: 关键词清洗 ──
    if "keywords" in ext and isinstance(ext["keywords"], list):
        ext["keywords"] = [_clean_keyword(kw) for kw in ext["keywords"]]

    # ── C5: 作者清洗 ──
    if "author" in ext and isinstance(ext["author"], list):
        cleaned_authors = []
        for a in ext["author"]:
            cleaned = _clean_author(a)
            if cleaned:
                cleaned_authors.append(cleaned)
        ext["author"] = cleaned_authors

    result["extracted_data"] = ext
    return result


def _clean_keyword(kw: str) -> str:
    """关键词拼写修正。"""
    if not isinstance(kw, str):
        return str(kw)
    for wrong, right in _KEYWORD_FIXES.items():
        kw = kw.replace(wrong, right)
    # 修复粘连关键词 (transformationoptics → transformation optics)
    kw = re.sub(r"([a-z])([A-Z])", r"\1 \2", kw)
    return kw


def _clean_author(author: str) -> str:
    """作者字段清洗：去除脚注上标、通讯标记、引号残留。"""
    if not isinstance(author, str):
        return str(author)
    # 去除首尾引号残留
    author = author.strip("'\"  ")
    # 去除尾部脚注号和通讯标记 (如 "Smith1*", "Lee²")
    author = re.sub(r"[\d¹²³⁴⁵⁶⁷⁸⁹⁰,\s]+\*?$", "", author).strip()
    # 去除中间的上标数字 (如 "Yang Y u²" → "Yang Yu")
    author = re.sub(r"[¹²³⁴⁵⁶⁷⁸⁹⁰]+", "", author)
    # 修复因 PDF 解析导致的空格断裂 (如 "Y u" → "Yu")
    author = re.sub(r"\b(\w)\s(\w)\b", r"\1\2", author)
    # 清理多余空格
    author = re.sub(r"\s+", " ", author).strip()
    return author


# ── Mini 专用后处理（轻量防御性校验） ──

_MINI_FIELD_ALIASES = {
    "sensitivity_or_tolerance_analysis": "sensitivity_result",
    "dominate_mechanism": "dominant_mechanism",
}


def _postprocess_mini(result: dict) -> dict:
    """Mini 输出已经很干净，仅做防御性校验 + 字段名别名合并。"""
    ext = result.get("extracted_data", {})
    if not isinstance(ext, dict):
        return result

    # 字段名规范化（与 Nano 同逻辑：合并到正确字段名，去除错误字段名）
    for wrong_name, correct_name in _MINI_FIELD_ALIASES.items():
        if wrong_name in ext:
            if correct_name not in ext:
                ext[correct_name] = ext[wrong_name]
            elif isinstance(ext[correct_name], list) and isinstance(ext[wrong_name], list):
                # 两个都存在时，合并去重
                merged = ext[correct_name] + [
                    v for v in ext[wrong_name] if v not in ext[correct_name]
                ]
                ext[correct_name] = merged
            del ext[wrong_name]

    result["extracted_data"] = ext
    return result


# ── Haiku 专用后处理（深度清洗 — 括号注解 + 推测值 + 长度限制） ──

# 字段名纠错映射（复用 nano 的完整集合）
_HAIKU_FIELD_ALIASES = {
    "sensitivity_or_tolerance_analysis": "sensitivity_result",
    "advanced": "advancement",
    "function_role": "functional_role",
    "dominate_mechanism": "dominant_mechanism",
    "fabrication_method_note": None,           # 丢弃，应在叙述中
    "influence_analysis_custom_factor": None,   # 丢弃，应为 _ 前缀
    # 论文级元数据：title/author/publication_year 由 md header 解析注入到 extracted_data，
    # 若 LLM 仍然输出到 extracted_data，直接丢弃避免重复；journal/doi 彻底丢弃
    "journal": None,
    "doi": None,
    "publication_year": None,
}

# 括号注解匹配：尾部 (8+ 字符内容)，保留晶体学方向 (0001) 和化学式 (SiC/SiC)
_PAREN_ANNOTATION_RE = re.compile(r"\s*\([^()]{8,}\)\s*$")

# 推测性/臆造值检测
_SPECULATIVE_RE = re.compile(
    r"\b(implied|inferred|assumed|speculated|hypothesized|estimated\s+from)\b",
    re.IGNORECASE,
)

# 允许长文本的字段（不做截断）
# 注：原来的 contribution/novelty/advancement/improvement_over_baseline/sensitivity_result
# 已迁移到 _ 前缀并存为 dict，天然跳过 list 截断逻辑，无需在此列出
_HAIKU_LONG_TEXT_FIELDS = frozenset({
    "abstract",
    "causal_mechanism_summary", "tradeoff_summary",
    "layer_stack_description", "coupling_behavior", "mechanism_evidence",
    "angular_stability", "polarization_performance",
    "advancement", "novelty", "contribution",
    "comparison_baseline", "improvement_over_baseline", "sensitivity_result",
    "design_guideline", "challenges", "techniques",
})

# 值长度安全上限（词数）
_HAIKU_MAX_VALUE_WORDS = 35


# ── Haiku 新增流水线辅助函数 ──

_SCHEMA_DEDICATED_ELEMENT_FIELDS = frozenset({
    "ti_content", "al_content", "v_content", "mo_content", "nb_content",
    "cr_content", "fe_content", "sn_content", "zr_content",
    "o_content", "n_content", "c_content", "h_content",
})
_ELEMENT_CONTENT_RE = re.compile(r"^([a-z]{1,3})_content$")


def _merge_off_schema_element_contents(ext: dict) -> None:
    """把 schema 没有专字段的元素含量（如 ni_content）合并进 other_alloying_elements，
    以 'Ni: 0.5 wt%' 形式保留元素符号。"""
    merged = list(ext.get("other_alloying_elements", []))
    keys_to_pop = []
    for key in list(ext.keys()):
        if key.startswith("_") or key in _SCHEMA_DEDICATED_ELEMENT_FIELDS:
            continue
        m = _ELEMENT_CONTENT_RE.match(key)
        if not m:
            continue
        symbol = m.group(1).capitalize()
        vals = ext[key] if isinstance(ext[key], list) else [ext[key]]
        for v in vals:
            if isinstance(v, str) and v.strip():
                merged.append(f"{symbol}: {v.strip()}")
        keys_to_pop.append(key)
    for k in keys_to_pop:
        ext.pop(k, None)
    if merged:
        seen = set()
        dedup = []
        for v in merged:
            if v not in seen:
                seen.add(v)
                dedup.append(v)
        ext["other_alloying_elements"] = dedup


_ALLOY_CANONICAL_MAP = {
    # γ-TiAl 族
    "gamma-tial": "γ-TiAl", "γ-tial": "γ-TiAl", "g-tial": "γ-TiAl", "tial": "γ-TiAl",
    "β-solidified γ-tial": "γ-TiAl", "β/γ-tial alloy": "γ-TiAl",
    "beta-solidified gamma-tial": "γ-TiAl", "β/γ-tial": "γ-TiAl",
    # α2-Ti3Al
    "ti3al": "α2-Ti3Al", "α2-ti3al": "α2-Ti3Al", "alpha2-ti3al": "α2-Ti3Al",
    "α₂-ti₃al": "α2-Ti3Al", "alpha-2-ti3al": "α2-Ti3Al",
    # Ti-6Al-4V 族
    "ti6al4v": "Ti-6Al-4V", "ti-6al-4v": "Ti-6Al-4V",
    "ti64": "Ti-6Al-4V", "ti-64": "Ti-6Al-4V", "tc4": "Ti-6Al-4V",
    "ti 6-4": "Ti-6Al-4V", "ti6-4": "Ti-6Al-4V",
    "ti-6 al-4 v": "Ti-6Al-4V",
    # α-Ti（纯 α 钛 / 高纯 α 钛等）
    "α-ti": "α-Ti", "alpha-ti": "α-Ti",
    "α-titanium": "α-Ti", "alpha-titanium": "α-Ti",
    "α titanium": "α-Ti", "alpha titanium": "α-Ti",
    "high-purity α-titanium": "α-Ti", "high purity α-titanium": "α-Ti",
    "high-purity alpha-titanium": "α-Ti", "high-purity α-ti": "α-Ti",
    # β-Ti
    "β-ti": "β-Ti", "beta-ti": "β-Ti",
    "β-titanium": "β-Ti", "beta-titanium": "β-Ti",
    # 纯钛（CP-Ti）
    "cp-ti": "CP-Ti", "pure titanium": "CP-Ti", "pure ti": "CP-Ti",
    "commercially pure titanium": "CP-Ti", "commercially-pure titanium": "CP-Ti",
    "commercially pure ti": "CP-Ti", "titanium": "CP-Ti",
    "pure titanium (cp-ti)": "CP-Ti", "pure titanium (ta2)": "CP-Ti",
    "commercially pure titanium grade 2": "CP-Ti",
    "ta2": "CP-Ti", "ta1": "CP-Ti",
    "pure titanium with oxygen": "CP-Ti",
    # IN 族
    "in718": "IN718", "inconel 718": "IN718", "inconel-718": "IN718",
    "in625": "IN625", "inconel 625": "IN625",
    # 其他常见 β/近 β 钛合金（保留原名，只做大小写/短横统一）
    "ti-5553": "Ti-5553", "ti5553": "Ti-5553",
    "ti-17": "Ti-17", "ti17": "Ti-17",
    "ti-6242": "Ti-6242", "ti6242": "Ti-6242",
    "ti-55511": "Ti-55511", "ti55511": "Ti-55511",
}

# 公共前缀/后缀，遇到就剥离后再匹配 canonical map
_ALLOY_STRIP_PREFIXES = (
    "high-purity ", "high purity ", "highly pure ", "ultra-pure ", "ultra pure ",
    "nanotwinned ", "nano-twinned ",
    "as-cast ", "as-received ", "as-deposited ", "as-built ",
)


def _canonicalize_alloy_names(ext: dict) -> None:
    """把 alloy_name_normalized 里的异写形式统一成规范名；剥离修饰前缀后再查表。"""
    field = "alloy_name_normalized"
    if field not in ext or not isinstance(ext[field], list):
        return
    out = []
    seen = set()
    for v in ext[field]:
        if not isinstance(v, str):
            out.append(v)
            continue
        key = v.strip().lower().replace("–", "-").replace("—", "-")
        # 剥离修饰前缀重试
        stripped = key
        for pfx in _ALLOY_STRIP_PREFIXES:
            if stripped.startswith(pfx):
                stripped = stripped[len(pfx):].strip()
                break
        canon = (
            _ALLOY_CANONICAL_MAP.get(key)
            or _ALLOY_CANONICAL_MAP.get(stripped)
            or v.strip()
        )
        if canon and canon not in seen:
            seen.add(canon)
            out.append(canon)
    ext[field] = out


def _derive_alloy_aliases(ext: dict) -> None:
    """从 alloy_designation_reported 里把作者原文用过的同义写法抽出成 alloy_aliases，
    排除已经是 canonical 名的那一个。若作者只用了一种写法则删除空 alloy_aliases。"""
    reported = ext.get("alloy_designation_reported", [])
    canonical = ext.get("alloy_name_normalized", [])
    if not isinstance(reported, list) or not isinstance(canonical, list):
        return
    if not reported:
        return

    canon_lower = {
        c.strip().lower().replace("–", "-").replace("—", "-")
        for c in canonical if isinstance(c, str)
    }
    aliases = []
    seen = set()
    for r in reported:
        if not isinstance(r, str):
            continue
        r_stripped = r.strip()
        r_key = r_stripped.lower().replace("–", "-").replace("—", "-")
        if r_key in canon_lower:
            continue
        # 若这个 reported 经 canonical map 映射后 = 某个 canonical 名，也跳过
        if _ALLOY_CANONICAL_MAP.get(r_key) in canonical:
            continue
        if r_stripped and r_stripped not in seen:
            seen.add(r_stripped)
            aliases.append(r_stripped)

    existing = ext.get("alloy_aliases", [])
    if isinstance(existing, list):
        for v in existing:
            if isinstance(v, str) and v.strip() and v.strip() not in seen:
                seen.add(v.strip())
                aliases.append(v.strip())

    if aliases:
        ext["alloy_aliases"] = aliases
    elif "alloy_aliases" in ext:
        # 空列表则删除（schema 政策：不保留空占位）
        del ext["alloy_aliases"]


# ── 枚举字段受控词表（与 Haiku prompt "CONTROLLED VOCABULARY" 对齐） ──

_ENUM_CANONICAL = {
    "study_type": {
        "experiment": "experiment",
        "experimental": "experiment",
        "experimental study": "experiment",
        "simulation": "simulation",
        "numerical simulation": "simulation",
        "theory": "theory",
        "theoretical": "theory",
        "theoretical analysis": "theory",
        "data-driven": "data-driven",
        "data driven": "data-driven",
        "data-driven analysis": "data-driven",
        "theory and data-driven analysis": "data-driven",
        "coupled experiment-simulation": "coupled experiment-simulation",
        "coupled experiment simulation": "coupled experiment-simulation",
        "experiment-simulation": "coupled experiment-simulation",
        "experimental-simulation": "coupled experiment-simulation",
        "coupled theory-simulation": "coupled theory-simulation",
        "theory-simulation": "coupled theory-simulation",
    },
    "study_scale": {
        "atomic-scale": "atomic-scale",
        "atomic scale": "atomic-scale",
        "atomic": "atomic-scale",
        "diffusion-scale": "atomic-scale",
        "atomic/diffusion-scale": "atomic-scale",
        "atomic-scale diffusion kinetics": "atomic-scale",
        "molecular scale": "atomic-scale",
        "molecular-scale": "atomic-scale",
        "nanoscale": "atomic-scale",
        "nano-scale": "atomic-scale",
        "interface-scale": "interface-scale",
        "interface scale": "interface-scale",
        "microstructure-scale": "microstructure-scale",
        "microstructure scale": "microstructure-scale",
        "grain-scale": "grain-scale",
        "grain scale": "grain-scale",
        "mesoscale": "mesoscale",
        "meso-scale": "mesoscale",
        "ingot-scale": "ingot-scale",
        "ingot scale": "ingot-scale",
        "macroscale": "macroscale",
        "macro-scale": "macroscale",
        "macroscopic": "macroscale",
        "polycrystalline aggregate": "macroscale",
        "polycrystalline aggregate / macroscopic": "macroscale",
    },
    "composition_basis": {
        "wt.%": "wt.%",
        "wt%": "wt.%",
        "weight percent": "wt.%",
        "mass fraction": "wt.%",
        "at.%": "at.%",
        "at%": "at.%",
        "atomic percent": "at.%",
        "atomic fraction": "at.%",
        "mol fraction": "mole fraction",
        "mole fraction": "mole fraction",
        "molar fraction": "mole fraction",
        "ppm": "ppm",
        "dimensionless concentration": "mole fraction",
        "mixed basis": "mixed basis",
    },
    "data_source_mode": {
        "direct experimental measurement": "direct experimental measurement",
        "experimental measurement": "direct experimental measurement",
        "experimental metallography": "direct experimental measurement",
        "experimental validation": "direct experimental measurement",
        "sem measurement": "direct experimental measurement",
        "ebsd analysis": "direct experimental measurement",
        "tem characterization": "direct experimental measurement",
        "phase-field simulation": "phase-field simulation",
        "phase field simulation": "phase-field simulation",
        "phase-field generation": "phase-field simulation",
        "phase-field crystal simulation": "phase-field simulation",
        "calphad prediction": "CALPHAD prediction",
        "calphad thermodynamic prediction": "CALPHAD prediction",
        "calphad thermodynamic calculation": "CALPHAD prediction",
        "thermodynamic calculation": "CALPHAD prediction",
        "dictra simulation": "CALPHAD prediction",
        "finite-element thermal simulation": "finite-element simulation",
        "finite-element simulation": "finite-element simulation",
        "fem/cfd simulation": "finite-element simulation",
        "cfd simulation": "CFD simulation",
        "cfd/multiphysics simulation": "CFD simulation",
        "molecular dynamics simulation": "molecular dynamics simulation",
        "molecular-dynamics calculation": "molecular dynamics simulation",
        "molecular dynamics comparison": "molecular dynamics simulation",
        "md simulation": "molecular dynamics simulation",
        "density-functional-theory calculation": "DFT calculation",
        "dft calculation": "DFT calculation",
        "cpfe simulation": "CPFE simulation",
        "constitutive model simulation": "CPFE simulation",
        "constitutive model calculation": "CPFE simulation",
        "machine learning prediction": "machine-learning prediction",
        "machine-learning prediction": "machine-learning prediction",
        "literature experimental data compilation": "literature compilation",
        "literature compilation and critical evaluation": "literature compilation",
        "literature synthesis": "literature compilation",
        "theoretical modeling": "theoretical calculation",
        "theoretical calculation": "theoretical calculation",
        "sharp interface model comparison": "theoretical calculation",
        "monte carlo comparison": "theoretical calculation",
    },
    "simulation_method": {
        "phase-field": "phase-field",
        "phase field": "phase-field",
        "phase-field model": "phase-field",
        "phase field model": "phase-field",
        "phase-field method": "phase-field",
        "phase field method": "phase-field",
        "phase-field modeling": "phase-field",
        "phase field modeling": "phase-field",
        "phase-field simulation": "phase-field",
        "phase-field crystal": "phase-field",
        "multiphase-field": "multiphase-field",
        "multi-phase-field": "multiphase-field",
        "multiphase field": "multiphase-field",
        "multiphase-field model": "multiphase-field",
        "multiphase-field method": "multiphase-field",
        "multiphase-field modeling": "multiphase-field",
        "molecular dynamics": "molecular dynamics",
        "molecular-dynamics": "molecular dynamics",
        "md": "molecular dynamics",
        "md simulation": "molecular dynamics",
        "calphad": "CALPHAD",
        "calphad modeling": "CALPHAD",
        "calphad coupling": "CALPHAD",
        "calphad thermodynamics": "CALPHAD",
        "calphad thermodynamic modeling": "CALPHAD",
        "dictra modeling": "CALPHAD",
        "finite element": "finite-element",
        "finite-element": "finite-element",
        "finite-element method": "finite-element",
        "finite-element simulation": "finite-element",
        "finite element simulation": "finite-element",
        "fem": "finite-element",
        "finite difference": "finite-difference",
        "cfd": "CFD",
        "cfd simulation": "CFD",
        "computational fluid dynamics": "CFD",
        "eulerian-eulerian multiphase model": "CFD",
        "two-phase flow": "CFD",
        "discrete phase model": "CFD",
        "cpfe": "CPFE",
        "crystal plasticity fe": "CPFE",
        "cp-fem": "CPFE",
        "dft": "DFT",
        "density functional theory": "DFT",
        "density-functional theory": "DFT",
        "machine learning": "machine learning",
        "ml": "machine learning",
        "machine-learning": "machine learning",
        "multiphysics": "multiphysics",
        "multiphysics coupling": "multiphysics",
        "multi-physics": "multiphysics",
        "spectral methods": "spectral",
        "thermodynamic modeling": "CALPHAD",
        "constitutive modeling": "constitutive modeling",
        "physically-based constitutive modeling": "constitutive modeling",
        "constitutive model": "constitutive modeling",
        "arrhenius equation fitting": "empirical fitting",
        "hollomon equation fitting": "empirical fitting",
        "least-squares analysis": "empirical fitting",
        "semi-empirical correlation": "empirical fitting",
        "schmid factor calculation": "analytical",
        "crystallographic analysis": "analytical",
        "theoretical modeling": "analytical",
        "theoretical calculation": "analytical",
        "confined-layer-slip model": "analytical",
        "d-electron alloy design method": "analytical",
        "not used": None,  # 删除占位符
    },
    "alloy_system": {
        # α-titanium 族
        "α-titanium": "α-Ti alloy",
        "α titanium alloy": "α-Ti alloy",
        "α titanium": "α-Ti alloy",
        "alpha-titanium": "α-Ti alloy",
        "alpha titanium": "α-Ti alloy",
        "α-ti alloy": "α-Ti alloy",
        "pure titanium": "α-Ti alloy",
        "hexagonal close-packed metal": "α-Ti alloy",
        # near-α
        "near-α titanium alloy": "near-α Ti alloy",
        "near α titanium alloy": "near-α Ti alloy",
        # α+β
        "α+β titanium alloy": "α+β Ti alloy",
        "α+β duplex titanium alloy": "α+β Ti alloy",
        "α/β titanium alloy": "α+β Ti alloy",
        # β
        "β titanium alloy": "β-Ti alloy",
        "β-titanium alloy": "β-Ti alloy",
        "beta titanium alloy": "β-Ti alloy",
        "beta-titanium alloy": "β-Ti alloy",
        "bcc titanium alloy": "β-Ti alloy",
        "β high-strength titanium alloy": "β-Ti alloy",
        # near-β
        "near-β titanium alloy": "near-β Ti alloy",
        "near β titanium alloy": "near-β Ti alloy",
        # metastable β
        "metastable β titanium alloy": "metastable β-Ti alloy",
        "metastable-β titanium alloy": "metastable β-Ti alloy",
        "metastable beta titanium alloy": "metastable β-Ti alloy",
        "high-zr-containing titanium alloy": "metastable β-Ti alloy",
        # γ-TiAl 族
        "γ-tial": "γ-TiAl intermetallic",
        "γ-tial intermetallic": "γ-TiAl intermetallic",
        "γ-tial intermetallic alloy": "γ-TiAl intermetallic",
        "ti-al intermetallic": "γ-TiAl intermetallic",
        "ti-al alloy": "γ-TiAl intermetallic",
        "β-solidified γ-tial based alloy": "γ-TiAl intermetallic",
        "β/γ-tial intermetallic alloy": "γ-TiAl intermetallic",
        "polysynthetically twinned tial": "γ-TiAl intermetallic",
        "ternary titanium alloy": "ternary Ti alloy",
        "ti-al binary system": "γ-TiAl intermetallic",
    },
}


def _normalize_enum_fields(ext: dict, family: Optional[str] = None) -> None:
    """对受控枚举字段做大小写+同义词合并。映射值为 None 表示删除该占位符。

    跨域通用的枚举（study_type / study_scale / composition_basis /
    data_source_mode / simulation_method）在所有家族下运行；
    alloy_system 仅在 alloy 家族下运行（aerospace schema 无该字段）。
    """
    alloy_only_fields = {"alloy_system"}
    run_alloy = _is_alloy_family(family)
    for field, mapping in _ENUM_CANONICAL.items():
        if field in alloy_only_fields and not run_alloy:
            continue
        if field not in ext:
            continue
        val = ext[field]
        if not isinstance(val, list):
            continue
        out = []
        seen = set()
        for v in val:
            if not isinstance(v, str):
                out.append(v)
                continue
            key = v.strip().lower().replace("–", "-").replace("—", "-")
            # 复合值：如 "Microstructure-scale and grain-scale" → 拆成两个
            parts = re.split(r"\s+and\s+|,\s*|/\s*", key) if " and " in key or "," in key or "/" in key else [key]
            for p in parts:
                p_clean = p.strip()
                if not p_clean:
                    continue
                if p_clean in mapping:
                    canon = mapping[p_clean]
                    if canon is None:  # 明确标记为删除
                        continue
                else:
                    canon = v.strip()  # 未命中映射时保留原文
                if canon and canon not in seen:
                    seen.add(canon)
                    out.append(canon)
        if out:
            ext[field] = out
        else:
            # 全部被删，彻底移除字段
            del ext[field]


# ── 数值单位校验/修正（与 Haiku prompt "NUMERIC VALUES" 段对齐） ──

# heating_rate / cooling_rate / solidification_rate 必须带时间分母
_RATE_FIELDS = frozenset({
    "heating_rate", "cooling_rate", "solidification_rate",
})

# 这些字段默认单位（当条目缺 unit 时的兜底）
_DEFAULT_UNITS = {
    "test_temperature": "K",
    "heat_treatment_temperature": "K",
    "deformation_temperature": "K",
    "homogenization_temperature": "K",
    "solution_treatment_temperature": "K",
    "aging_temperature": "K",
    "beta_transus_temperature": "K",
    "liquidus_temperature": "K",
    "solidus_temperature": "K",
    "ms_temperature": "K",
    "mf_temperature": "K",
    "yield_strength": "MPa",
    "ultimate_tensile_strength": "MPa",
    "peak_flow_stress": "MPa",
    "flow_stress": "MPa",
    "residual_stress": "MPa",
    "elongation": "%",
    "drx_fraction": "%",
    "twin_volume_fraction": "%",
    "martensite_fraction": "%",
}

_ROOM_TEMP_RE = re.compile(
    r"^(room|ambient)\s*(temperature|temp)\.?(\s+.*)?$|^rt$", re.IGNORECASE,
)

# 数字紧贴单位的紧凑格式：'8.2%', '500MPa', '298K', '15.44GPa', '~200MPa'
# 不要求数字和单位之间有空格。`(?:\b|$)` 让 '%' 这类非字母数字结尾也能匹配。
_TIGHT_VALUE_UNIT_RE = re.compile(
    r"^\s*[~≈]?\s*([+-]?\d+(?:\.\d+)?(?:\s*[×xX]\s*10[⁰¹²³⁴⁵⁶⁷⁸⁹\-+\d]*)?(?:[eE][+-]?\d+)?)"
    r"\s*(%|°C|°F|μm|nm|mm|cm|m|MPa|GPa|kPa|Pa|K|J|kJ|eV|s|ms|μs|ns|min|hr|h)"
    r"(?:\b|$)\s*$"
)

_GPA_IN_UNIT_RE = re.compile(r"^\s*GPa\b", re.IGNORECASE)


def _split_tight_value_unit(s: str) -> Optional[dict]:
    """紧贴格式拆分：'8.2%' → hybrid dict。"""
    if not isinstance(s, str):
        return None
    m = _TIGHT_VALUE_UNIT_RE.match(s.strip())
    if not m:
        return None
    return _make_hybrid(raw=s.strip(), value=m.group(1).strip(), unit=m.group(2).strip())


# ── Hybrid {raw, value_num, unit} 结构辅助 ──

# 上标数字到普通数字的映射（用于解析 2×10⁸ 这类科学计数法）
_SUPERSCRIPT_MAP = str.maketrans(
    "⁰¹²³⁴⁵⁶⁷⁸⁹⁻⁺", "0123456789-+"
)
# 全角/花样乘号归一
_MULT_CHARS = "×xX*"


def _parse_num(value: str) -> Optional[float]:
    """把 '2×10⁸' / '3 × 10⁻⁹' / '1.4e-5' 等字符串解析为 float。
    无法解析（范围、占位符、含文本）返回 None。"""
    if value is None:
        return None
    s = str(value).strip()
    if not s:
        return None
    # 占位符 / 定性描述
    low = s.lower()
    if any(w in low for w in ("variable", "not ", "n/a", "unknown",
                              "assumed", "implied", "derived",
                              "emergent", "controlled by")):
        return None
    # 范围
    if "–" in s or "—" in s or "~" in s or "≈" in s:
        return None
    # 归一上标和乘号
    s = s.translate(_SUPERSCRIPT_MAP)
    for c in _MULT_CHARS:
        s = s.replace(c, "*")
    s = s.replace(" ", "")
    # 科学计数法：2*10^8 / 2*108 / 2e8
    # 先把 '*10-9' 这种转成 'e-9'
    s = re.sub(r"\*10([+-]?\d+)", r"e\1", s)
    try:
        return float(s)
    except (ValueError, TypeError):
        return None


def _make_hybrid(raw: str, value: str, unit: str) -> dict:
    """构造 hybrid 条目 {raw, value_num, unit}。
    raw 保留原文；value_num 尽力解析，失败留 None；unit 去首尾空白。"""
    return {
        "raw": raw,
        "value_num": _parse_num(value),
        "unit": (unit or "").strip(),
    }


def _migrate_legacy_value_unit(entry: dict) -> dict:
    """把老的 {value, unit} dict 迁移为 {raw, value_num, unit}。已是新结构则原样返回。"""
    if "raw" in entry and "value_num" in entry:
        # 已是新结构，但兜底一次确保 value_num 反映 raw
        if entry.get("value_num") is None:
            entry["value_num"] = _parse_num(entry.get("raw", ""))
        return entry
    if "value" not in entry:
        return entry
    v = str(entry.get("value", "")).strip()
    u = str(entry.get("unit", "")).strip()
    raw = v if not u else f"{v} {u}" if not v.endswith(u) else v
    return {
        "raw": raw,
        "value_num": _parse_num(v),
        "unit": u,
    }


def _coerce_entry_to_value_unit(entry, default_unit: Optional[str] = None):
    """把一个 list element 尽量转成 hybrid {raw, value_num, unit} dict。
    无法解析/非数值语义时原样返回。"""
    if isinstance(entry, dict):
        # 老结构 → 新结构
        if "raw" not in entry and ("value" in entry or "unit" in entry):
            return _migrate_legacy_value_unit(entry)
        return entry
    if not isinstance(entry, str):
        return entry
    s = entry.strip()
    if not s:
        return entry
    # room / ambient temperature → 298 K
    if _ROOM_TEMP_RE.match(s):
        return _make_hybrid(raw=s, value="298", unit=default_unit or "K")
    # 数字 + 空格 + 单位（'500 MPa'）
    parsed = _split_value_unit(s)
    if parsed:
        return parsed
    # 数字紧贴单位（'8.2%', '500MPa', '298K'）
    parsed = _split_tight_value_unit(s)
    if parsed:
        return parsed
    # 只有数字、无单位 → 配 default_unit
    if default_unit and re.fullmatch(r"[+-]?\d+(\.\d+)?", s):
        return _make_hybrid(raw=s, value=s, unit=default_unit)
    return entry


def _fix_rate_unit(entry):
    """heating_rate/cooling_rate 单位缺 '/s' 时补上。（兼容 hybrid 结构）"""
    if not isinstance(entry, dict):
        return entry
    unit = str(entry.get("unit", "")).strip()
    if not unit:
        return entry
    low = unit.lower()
    # 已带分母或时间单位的放过
    if "/" in unit or any(t in low for t in (" per ", "sec", "min", "hour", "hr", " h ", " s ")):
        return entry
    # 仅温度单位（K / °C）→ 补 /s
    if low in ("k", "°c", "c"):
        entry = dict(entry)
        new_unit = f"{unit}/s"
        entry["unit"] = new_unit
        # 同步更新 raw（若存在）
        if "raw" in entry and isinstance(entry["raw"], str):
            # 简单替换：把末尾单位替换成新单位
            if entry["raw"].rstrip().endswith(unit):
                entry["raw"] = entry["raw"].rstrip()[:-len(unit)].rstrip() + " " + new_unit
    return entry


def _convert_gpa_to_mpa(entry):
    """yield_strength 等强度字段：GPa → MPa × 1000（保留三位有效数）。（兼容 hybrid 结构）"""
    if not isinstance(entry, dict):
        return entry
    unit = str(entry.get("unit", "")).strip()
    if not _GPA_IN_UNIT_RE.match(unit):
        return entry
    # 优先用 value_num，退化到老的 value
    num = entry.get("value_num")
    if num is None:
        try:
            num = float(str(entry.get("value", "")).replace(",", "").strip())
        except (ValueError, TypeError):
            return entry
    if num is None:
        return entry
    new_val = num * 1000.0
    formatted = f"{new_val:.3f}".rstrip("0").rstrip(".")
    entry = dict(entry)
    new_unit = unit.replace("GPa", "MPa").replace("gpa", "MPa")
    entry["value_num"] = new_val
    entry["unit"] = new_unit
    entry["raw"] = f"{formatted} {new_unit}"
    # 清理老键以免残留歧义
    entry.pop("value", None)
    return entry


def _enforce_numeric_units(ext: dict) -> None:
    """对关键数值字段做单位校验和归一：
      - test_temperature 等：裸数字/room-temperature 补单位
      - heating_rate/cooling_rate：单位缺分母则补 /s
      - yield_strength/UTS：GPa → MPa
    （所有输出使用 hybrid {raw, value_num, unit} 结构）
    """
    for key, default_unit in _DEFAULT_UNITS.items():
        if key not in ext or not isinstance(ext[key], list):
            continue
        out = []
        for item in ext[key]:
            coerced = _coerce_entry_to_value_unit(item, default_unit=default_unit)
            if key in ("yield_strength", "ultimate_tensile_strength",
                      "peak_flow_stress", "flow_stress"):
                coerced = _convert_gpa_to_mpa(coerced)
            out.append(coerced)
        ext[key] = out

    for key in _RATE_FIELDS:
        if key not in ext or not isinstance(ext[key], list):
            continue
        ext[key] = [_fix_rate_unit(x) for x in ext[key]]


# ── interface_energy 及相关字段的单位分流 ──

# 每个字段的单位白名单 + 不匹配时的目标字段路由
_FIELD_UNIT_ROUTING = {
    "interface_energy": {
        "accept": {"J/m²", "J/m^2", "j/m²", "j/m^2", "mJ/m²", "mJ/m^2",
                   "erg/cm²", "erg/cm^2"},
        "reroute": {
            "K·m": "gibbs_thomson_coefficient",
            "K*m": "gibbs_thomson_coefficient",
            "m·K": "gibbs_thomson_coefficient",
            "m*K": "gibbs_thomson_coefficient",
            "K m": "gibbs_thomson_coefficient",
            "N/m": "surface_tension_sl",
            "dyne/cm": "surface_tension_sl",
            "normalized": "gradient_energy_coefficient",
            "dimensionless": "gradient_energy_coefficient",
        },
    },
    "gibbs_thomson_coefficient": {
        "accept": {"K·m", "K*m", "m·K", "m*K", "K m"},
        "reroute": {
            "J/m²": "interface_energy",
            "J/m^2": "interface_energy",
            "N/m": "surface_tension_sl",
            "dyne/cm": "surface_tension_sl",
        },
    },
    "surface_tension_sl": {
        "accept": {"N/m", "dyne/cm"},
        "reroute": {
            "J/m²": "interface_energy",
            "J/m^2": "interface_energy",
            "K·m": "gibbs_thomson_coefficient",
            "K*m": "gibbs_thomson_coefficient",
        },
    },
    "gradient_energy_coefficient": {
        "accept": {"J·m", "J*m", "normalized", "dimensionless", ""},
        "reroute": {
            "J/m²": "interface_energy",
            "K·m": "gibbs_thomson_coefficient",
        },
    },
}


def _reroute_unit_mismatched_fields(ext: dict) -> None:
    """对关键数值字段按单位白名单分流。不在 accept 也不在 reroute 里的条目
    留在原字段但打 _unit_review=True 标记；reroute 命中的条目迁移到目标字段。"""
    for field, rule in _FIELD_UNIT_ROUTING.items():
        entries = ext.get(field)
        if not isinstance(entries, list):
            continue
        accept = rule.get("accept", set())
        reroute = rule.get("reroute", {})
        kept = []
        moved = {}  # target_field -> [entry, ...]
        for it in entries:
            if not isinstance(it, dict):
                kept.append(it)
                continue
            u = str(it.get("unit", "")).strip()
            if u in accept:
                kept.append(it)
            elif u in reroute:
                target = reroute[u]
                moved.setdefault(target, []).append(it)
                logger.info(
                    "[unit-reroute] %s(unit=%s) → %s", field, u, target,
                )
            else:
                it = dict(it)
                it["_unit_review"] = True
                kept.append(it)
                logger.warning(
                    "[unit-review] %s has unknown unit=%s raw=%s",
                    field, u, it.get("raw") or it.get("value"),
                )
        if kept:
            ext[field] = kept
        else:
            del ext[field]
        for target, items in moved.items():
            ext.setdefault(target, []).extend(items)


# ── 单位规范化：字面统一 + 同物理量数值转换 + 噪声单位标记 ──

# 字面统一表（仅字面不同，不涉及数值变更）
_UNIT_LITERAL_MAP = {
    "wt%": "wt.%",
    "Wt.%": "wt.%",
    "WT%": "wt.%",
    "at%": "at.%",
    "AT.%": "at.%",
    "μm·s⁻¹": "μm/s",
    "μm s⁻¹": "μm/s",
    "um/s": "μm/s",
    "W/m²·K": "W/(m²·K)",
    "W/m2·K": "W/(m²·K)",
    "W/m^2·K": "W/(m²·K)",
    "W/(m2·K)": "W/(m²·K)",
    "K*m": "K·m",
    "m·K": "K·m",
    "m*K": "K·m",
    "K m": "K·m",
    "J/m^2": "J/m²",
    "J/m2": "J/m²",
    "mJ/m^2": "mJ/m²",
    "mJ/m2": "mJ/m²",
    "erg/cm^2": "erg/cm²",
    "erg/cm2": "erg/cm²",
    "cm²/s": "cm²/s",
    "cm^2/s": "cm²/s",
    "m²/s": "m²/s",
    "m^2/s": "m²/s",
    "s^-1": "s⁻¹",
    "s-1": "s⁻¹",
    "1/s": "s⁻¹",
    "m^3": "m³",
    "m^4": "m⁴",
    "m³/(Js)": "m³/(J·s)",
    "m⁴/(Js)": "m⁴/(J·s)",
    "m⁴/s·J": "m⁴/(J·s)",
    "m^4/(J·s)": "m⁴/(J·s)",
    "μm-1": "μm⁻¹",
    "nm-1": "nm⁻¹",
    "mT": "mT",
    "degrees": "°",
    "degree": "°",
    "deg": "°",
    "°C": "°C",
    "degC": "°C",
    "deg C": "°C",
    "Celsius": "°C",
    "Kelvin": "K",
}

# 温度字段统一到 K
_TEMPERATURE_FIELDS_TO_K = frozenset({
    "test_temperature",
    "heat_treatment_temperature",
    "deformation_temperature",
    "homogenization_temperature",
    "solution_treatment_temperature",
    "aging_temperature",
    "beta_transus_temperature",
    "liquidus_temperature",
    "solidus_temperature",
    "ms_temperature",
    "mf_temperature",
    "transformation_temperature",
})
_CELSIUS_UNIT_ALIASES = frozenset({"°C", "C", "Celsius", "celsius", "degC", "deg C"})

# 时间字段统一到 h（小时）
_TIME_FIELDS_TO_HOURS = frozenset({
    "heat_treatment_time",
    "soaking_time_before_deformation",
    "aging_time",
    "solution_treatment_time",
})
_TIME_TO_HOURS_FACTOR = {
    "s": 1 / 3600.0, "sec": 1 / 3600.0, "second": 1 / 3600.0, "seconds": 1 / 3600.0,
    "min": 1 / 60.0, "minute": 1 / 60.0, "minutes": 1 / 60.0,
    "h": 1.0, "hr": 1.0, "hrs": 1.0, "hour": 1.0, "hours": 1.0,
    "ks": 1000.0 / 3600.0,
    "ms": 1 / 3600000.0,
}

# 字段特定的同物理量数值转换：{field: {source_unit: (target_unit, multiplier)}}
_SAME_QUANTITY_CONVERSIONS = {
    "interface_energy": {
        "J/cm²": ("J/m²", 1e4),
    },
    "diffusion_coefficient_set": {
        "cm²/s": ("m²/s", 1e-4),
    },
    "vacuum_level": {
        "kPa": ("Pa", 1000.0),
        "MPa": ("Pa", 1e6),
        "atm": ("Pa", 101325.0),
        "bar": ("Pa", 1e5),
        "mbar": ("Pa", 100.0),
        "Torr": ("Pa", 133.322),
    },
    "thermal_gradient": {
        "K/cm": ("K/mm", 0.1),
        "K/μm": ("K/mm", 1000.0),
        "K/m": ("K/mm", 0.001),
    },
    "cooling_rate": {
        "K/min": ("K/s", 1 / 60.0),
        "°C/min": ("K/s", 1 / 60.0),
        "°C/s": ("K/s", 1.0),
    },
    "heating_rate": {
        "K/min": ("K/s", 1 / 60.0),
        "°C/min": ("K/s", 1 / 60.0),
        "°C/s": ("K/s", 1.0),
    },
    "melt_rate": {
        "kg/min": ("kg/s", 1 / 60.0),
    },
}

# 噪声"单位"（其实是语义描述，不是真正的物理量单位）→ 打 _unit_review 标记
_NOISE_UNIT_PATTERNS = (
    "qualitative", "relative", "controlled",
    "kinetic", "static",
    "true strain", "thickness reduction fraction",
    "ratio", "weight", "mass",
    "diameter", "long", "radius",
    "dendrite tip", "front velocity", "deposition",
    "mean relative error", "percent error", "deviation",
    "reduction in", "improvement in", "versus",
    "times higher", "% relative increase",
    "tension RD", "TT", "RD vs",
)


def _apply_literal_unit_map(unit: str) -> str:
    if not isinstance(unit, str):
        return unit
    key = unit.strip()
    if not key:
        return key
    return _UNIT_LITERAL_MAP.get(key, key)


def _convert_celsius_to_kelvin(entry: dict) -> dict:
    unit = str(entry.get("unit", "")).strip()
    if unit not in _CELSIUS_UNIT_ALIASES:
        return entry
    vn = entry.get("value_num")
    entry = dict(entry)
    if vn is None:
        # 无数值只归一 unit 字面
        entry["unit"] = "°C"
        return entry
    try:
        entry["value_num"] = float(vn) + 273.15
    except (ValueError, TypeError):
        return entry
    entry["unit"] = "K"
    return entry


def _convert_time_entry_to_hours(entry: dict) -> dict:
    unit = str(entry.get("unit", "")).strip()
    factor = _TIME_TO_HOURS_FACTOR.get(unit.lower())
    if factor is None:
        return entry
    vn = entry.get("value_num")
    entry = dict(entry)
    if vn is None:
        entry["unit"] = "h"
        return entry
    try:
        entry["value_num"] = float(vn) * factor
    except (ValueError, TypeError):
        return entry
    entry["unit"] = "h"
    return entry


def _convert_same_quantity(entry: dict, rules: dict) -> dict:
    unit = str(entry.get("unit", "")).strip()
    if unit not in rules:
        return entry
    target_unit, factor = rules[unit]
    vn = entry.get("value_num")
    entry = dict(entry)
    if vn is None:
        entry["unit"] = target_unit
        return entry
    try:
        entry["value_num"] = float(vn) * factor
    except (ValueError, TypeError):
        return entry
    entry["unit"] = target_unit
    return entry


def _flag_noise_unit(entry: dict) -> dict:
    unit_raw = entry.get("unit", "")
    if not isinstance(unit_raw, str):
        return entry
    low = unit_raw.strip().lower()
    if not low:
        return entry
    # 若 unit 里含有噪声 token，打标记
    for tok in _NOISE_UNIT_PATTERNS:
        if tok in low:
            entry = dict(entry)
            entry["_unit_review"] = True
            return entry
    return entry


def _canonicalize_units(ext: dict) -> None:
    """对所有 hybrid 条目应用：
      1. unit 字面统一（wt% → wt.% 等）
      2. 温度字段 °C → K
      3. 时间字段 → h
      4. 字段特定同物理量转换（J/cm² → J/m² 等）
      5. 噪声单位打 _unit_review
      6. 若转换后 unit 已回到白名单，清除 _unit_review 标记
    raw 字段始终不变；value_num 和 unit 可能被改写为规范形式。
    """
    for field, val in list(ext.items()):
        if field.startswith("_"):
            continue

        # 支持两种容器：list of entries；parameter_range 的 {values: [...], min, max, unit}
        if isinstance(val, list):
            entries = val
            in_range_struct = False
        elif isinstance(val, dict) and "values" in val:
            entries = val.get("values", [])
            in_range_struct = True
        else:
            continue

        new_entries = []
        accept_units = set(_FIELD_UNIT_ROUTING.get(field, {}).get("accept", set()))
        for it in entries:
            if not isinstance(it, dict):
                new_entries.append(it)
                continue
            # 1. 字面统一
            if "unit" in it:
                it = dict(it)
                it["unit"] = _apply_literal_unit_map(it.get("unit", ""))
            # 2. 温度 → K
            if field in _TEMPERATURE_FIELDS_TO_K:
                it = _convert_celsius_to_kelvin(it)
            # 3. 时间 → h
            if field in _TIME_FIELDS_TO_HOURS:
                it = _convert_time_entry_to_hours(it)
            # 4. 同物理量转换
            if field in _SAME_QUANTITY_CONVERSIONS:
                it = _convert_same_quantity(it, _SAME_QUANTITY_CONVERSIONS[field])
            # 5. 噪声单位标记
            it = _flag_noise_unit(it)
            # 6. 若转换后 unit 回到白名单，清 _unit_review（reroute 步留下的误标）
            if accept_units and it.get("_unit_review") and it.get("unit") in accept_units:
                it = dict(it)
                it.pop("_unit_review", None)
            new_entries.append(it)

        if in_range_struct:
            val["values"] = new_entries
            nums = [x.get("value_num") for x in new_entries
                    if isinstance(x, dict) and x.get("value_num") is not None]
            if nums:
                val["min"] = min(nums)
                val["max"] = max(nums)
            # 若转换后所有单位一致，更新顶层 unit
            units = {x.get("unit") for x in new_entries
                     if isinstance(x, dict) and x.get("unit")}
            if len(units) == 1:
                val["unit"] = next(iter(units))
        else:
            ext[field] = new_entries


def _apply_underscore_rename(ext: dict, skip_fields: Optional[frozenset] = None) -> None:
    """把老的裸名跨域字段（advancement/novelty/...）迁移到 _ 前缀，
    并把 list-of-strings 重构成 {value, why_notable} 结构（每个字符串当作一个发现）。
    若目标 _ 字段已存在则合并。

    skip_fields:  legacy 裸名集合，出现在其中的字段不参与迁移（用于 aerospace 这类
                  在 schema 中保留裸名的家族，避免把正式 schema 字段错误地变成 _ 前缀）。
    """
    skip_fields = skip_fields or frozenset()
    for old, new in _FIELD_RENAME_TO_UNDERSCORE.items():
        if old in skip_fields:
            continue
        if old not in ext:
            continue
        old_val = ext.pop(old)
        existing = ext.get(new)
        # 把 old_val 标准化为 list
        if isinstance(old_val, str):
            items = [old_val]
        elif isinstance(old_val, list):
            items = [v for v in old_val if isinstance(v, str) and v.strip()]
        elif isinstance(old_val, dict):
            # 已经是 {value, why_notable}
            ext[new] = old_val if not existing else existing
            continue
        else:
            continue
        if not items:
            continue
        # 合成 {value, why_notable}
        # 如果只有 1 条：value=该条，why_notable 留空
        # 如果多条：合成一个 "• 条1\n• 条2" 列表
        if len(items) == 1:
            synthesized = {"value": items[0], "why_notable": ""}
        else:
            synthesized = {
                "value": " | ".join(items),
                "why_notable": f"{len(items)} items merged from legacy {old} field",
            }
        if existing is None:
            ext[new] = synthesized
        elif isinstance(existing, dict):
            # 合并：把新内容附加到 value
            merged_val = str(existing.get("value", "")).strip()
            if merged_val:
                merged_val = merged_val + " | " + synthesized["value"]
            else:
                merged_val = synthesized["value"]
            existing["value"] = merged_val
            if not existing.get("why_notable"):
                existing["why_notable"] = synthesized["why_notable"]
        # 其它情况（list/str 冲突）保留 existing 不覆盖


def _demigrate_underscore_to_bare(ext: dict, bare_fields: frozenset) -> None:
    """把 _X 的 {value, why_notable} dict 还原为裸名 X 的 list-of-strings。

    用途: aerospace schema 中 advancement / novelty / contribution 等是正式字段，
    但 LLM 在 prompt 指引下把它们输出成了 _X dict。此函数把这些条目还原回 X 裸名，
    并以 " — " 衔接可用的 why_notable 以避免信息丢失。

    规则：
      - 若 bare 字段已存在（list），合并进去；否则新建 list。
      - value 为空时跳过；why_notable 为空时只保留 value。
      - 多条 "|" 分隔的 value 会拆分为多个 list 项。
    """
    for bare in bare_fields:
        under = "_" + bare
        if under not in ext:
            continue
        entry = ext.pop(under)
        items: list[str] = []
        if isinstance(entry, dict):
            value_s = str(entry.get("value", "")).strip()
            why_s = str(entry.get("why_notable", "")).strip()
            if not value_s:
                continue
            parts = [p.strip() for p in value_s.split("|") if p.strip()]
            if not parts:
                parts = [value_s]
            if why_s and len(parts) == 1:
                items.append(f"{parts[0]} — {why_s}")
            else:
                items.extend(parts)
        elif isinstance(entry, list):
            for v in entry:
                if isinstance(v, str) and v.strip():
                    items.append(v.strip())
                elif isinstance(v, dict):
                    vv = str(v.get("value", "")).strip()
                    if vv:
                        items.append(vv)
        elif isinstance(entry, str) and entry.strip():
            items.append(entry.strip())

        if not items:
            continue
        existing = ext.get(bare)
        if isinstance(existing, list):
            merged = list(existing)
            for it in items:
                if it not in merged:
                    merged.append(it)
            ext[bare] = merged
        else:
            ext[bare] = items


def _fill_missing_why_notable(ext: dict) -> None:
    """为所有 _ 前缀 dict 字段补齐空 why_notable：避免下游看到 `why_notable: ""`。

    策略：
      - value 存在 + why_notable 缺失/空 → 用 "Paper-specific finding: <前 80 字 value>" 合成
      - value 和 why_notable 都空 → 整条删除
    """
    for key in list(ext.keys()):
        if not key.startswith("_"):
            continue
        val = ext.get(key)
        if not isinstance(val, dict):
            continue
        v = str(val.get("value", "")).strip()
        w = str(val.get("why_notable", "")).strip()
        if not v and not w:
            del ext[key]
            continue
        if v and not w:
            preview = v if len(v) <= 80 else (v[:77] + "...")
            label = key.lstrip("_").replace("_", " ")
            val["why_notable"] = (
                f"Paper-specific {label} (auto-synthesized): {preview}"
            )


# --- Range parsing for value_num=null entries (issue 3) ------------------
_SUPERSCRIPT_NUM_MAP = str.maketrans("⁰¹²³⁴⁵⁶⁷⁸⁹⁻⁺", "0123456789-+")
_RANGE_DASH_RE = re.compile(
    r"^\s*[~≈]?\s*([+-]?\d+(?:\.\d+)?)\s*[–—]\s*([+-]?\d+(?:\.\d+)?)"
)
_RANGE_HYPHEN_RE = re.compile(
    r"^\s*[~≈]?\s*([+-]?\d+(?:\.\d+)?)-([+-]?\d+(?:\.\d+)?)(?:\s|$)"
)
_RANGE_TO_SPLIT_RE = re.compile(r"\sto\s", re.IGNORECASE)
_RAW_NUM_RE = re.compile(r"[+-]?\d+(?:\.\d+)?")
_RANGE_THRESHOLD_RE = re.compile(r"^\s*[~≈≤≥<>]\s*([+-]?\d+(?:\.\d+)?)")
_RANGE_LEAD_NUM_RE = re.compile(r"^\s*[~≈≤≥<>]?\s*([+-]?\d+(?:\.\d+)?)")
_RANGE_QUALITATIVE_TOKENS = (
    "highest", "lowest", "not ", "n/a", "unknown", "variable",
    "qualitative", "emergent", "implied", "assumed",
)


def _parse_range_from_raw(raw: str) -> dict:
    """解析 raw 字符串，返回 {value_num?, value_min?, value_max?} 的子集。
    解析失败返回 {}。覆盖 normalize_knowledge_base.parse_raw_to_numeric 的核心能力：
      - en/em-dash 范围:     "1.40–7.00 nm" → min/max
      - 纯数字连字符范围:    "0-50 μm"       → min/max
      - "a to b" 范围:       "305 K to 85 K" → min/max
      - 阈值前缀:            "≤0.08 wt.%"    → value_num
      - 首数字兜底:          "~1580 MPa"     → value_num
    """
    if not isinstance(raw, str):
        return {}
    s = raw.translate(_SUPERSCRIPT_NUM_MAP).strip()
    if not s:
        return {}
    low = s.lower()
    if any(tok in low for tok in _RANGE_QUALITATIVE_TOKENS):
        return {}
    # 含等号且右侧非纯数字视为公式，跳过
    if "=" in s:
        m_eq = re.search(r"=\s*(.+)$", s)
        if m_eq and re.search(r"[A-Za-zα-ωΑ-Ω]", m_eq.group(1)):
            return {}

    m = _RANGE_DASH_RE.match(s)
    if m:
        a, b = float(m.group(1)), float(m.group(2))
        return {"value_min": min(a, b), "value_max": max(a, b)}

    m = _RANGE_HYPHEN_RE.match(s)
    if m:
        a, b = float(m.group(1)), float(m.group(2))
        if a <= b:
            return {"value_min": a, "value_max": b}

    if _RANGE_TO_SPLIT_RE.search(s):
        parts = _RANGE_TO_SPLIT_RE.split(s, maxsplit=1)
        if len(parts) == 2:
            ml = _RAW_NUM_RE.search(parts[0])
            mr = _RAW_NUM_RE.search(parts[1])
            if ml and mr:
                a, b = float(ml.group(0)), float(mr.group(0))
                return {"value_min": min(a, b), "value_max": max(a, b)}

    m = _RANGE_THRESHOLD_RE.match(s)
    if m:
        return {"value_num": float(m.group(1))}

    m = _RANGE_LEAD_NUM_RE.match(s)
    if m:
        return {"value_num": float(m.group(1))}
    return {}


def _backfill_ranges_on_entries(ext: dict) -> None:
    """遍历 ext 中 list[dict] 和 parameter_range.values[]，给 value_num=None 的
    hybrid 条目回填 value_num 或 value_min/value_max。"""
    for field, val in ext.items():
        if field.startswith("_"):
            continue
        if isinstance(val, list):
            entries = val
        elif isinstance(val, dict) and isinstance(val.get("values"), list):
            entries = val["values"]
        else:
            continue
        for item in entries:
            if not isinstance(item, dict):
                continue
            if "raw" not in item:
                continue
            if item.get("value_num") is not None:
                continue
            if "value_min" in item or "value_max" in item:
                continue
            parsed = _parse_range_from_raw(str(item.get("raw", "")))
            if parsed:
                item.update(parsed)


_VALUE_UNIT_RE = re.compile(
    r"^\s*([+-]?\d+(?:\.\d+)?(?:\s*[×xX]\s*10[⁰¹²³⁴⁵⁶⁷⁸⁹\-+\d]*)?(?:[eE][+-]?\d+)?)"
    r"\s+([^\s].*?)\s*$"
)

# 这些字段的值是分类枚举 / 长文本，不要尝试数值+单位拆分
_VALUE_UNIT_SKIP_FIELDS = frozenset({
    "research_theme", "study_type", "study_scale", "data_source_mode",
    "alloy_designation_reported", "alloy_name_normalized", "alloy_aliases",
    "alloy_system", "phase_stability_regime", "composition_basis",
    "material_form", "initial_material_condition", "processing_route",
    "heat_treatment_schedule", "atmosphere_condition",
    "electromagnetic_field_condition", "heat_extraction_path",
    "furnace_or_equipment", "mold_or_die_material", "characterization_method",
    "simulation_method", "software_or_platform", "simulation_dimension",
    "specimen_geometry", "specimen_orientation", "loading_direction",
    "mechanical_test_type", "nominal_composition_text", "initial_microstructure",
    "grain_morphology_descriptor", "interface_type", "multiphysics_coupling_type",
    "varied_parameter", "target_response", "optimization_objective",
    "observed_trend", "dominant_mechanism", "composition_effect_summary",
    "process_microstructure_causality", "microstructure_property_causality",
    "validation_status", "improvement_magnitude",
    "author", "title", "publication_year", "data_source", "domain",
    "boundary_condition_summary", "sampling_location",
    "potential_type", "boundary_conditions", "other_alloying_elements",
    "mold_or_die_geometry", "electrode_or_ingot_size",
})


def _split_value_unit(s: str) -> Optional[dict]:
    """尝试把 '4.001 Å' 拆成 hybrid {raw, value_num, unit}。拆不干净返回 None。"""
    if not isinstance(s, str):
        return None
    m = _VALUE_UNIT_RE.match(s)
    if not m:
        return None
    val = m.group(1).strip()
    unit = m.group(2).strip()
    if not any(c.isdigit() for c in val):
        return None
    # 避免把 '5 minutes total at 800 C' 这种长描述误拆
    lowered = unit.lower()
    if any(w in f" {lowered} " for w in (" at ", " and ", " for ", " of ", " with ", " total ", " per ")):
        return None
    # 单位第一字符不应是 ASCII 数字（避免 '2.8 nm spacing' 这种半句话把 'spacing' 当单位）
    first_tok = unit.split()[0] if unit.split() else ""
    if first_tok and first_tok[0].isdigit():
        return None
    return _make_hybrid(raw=s.strip(), value=val, unit=unit)


def _apply_value_unit_split(ext: dict) -> None:
    """对非分类字段的列表元素，把 '数值 单位' 字符串拆成 hybrid dict；
    老的 {value, unit} 结构无论在哪个字段都迁移到 hybrid（避免跳过字段里遗留老格式）。"""
    for key, val in list(ext.items()):
        if key.startswith("_"):
            continue
        if not isinstance(val, list):
            continue
        out = []
        is_skip = key in _VALUE_UNIT_SKIP_FIELDS
        for item in val:
            if isinstance(item, dict) and "value" in item and "raw" not in item:
                # 无论是否 skip 字段，老的 {value, unit} 都迁移
                out.append(_migrate_legacy_value_unit(item))
            elif isinstance(item, str) and not is_skip:
                parsed = _split_value_unit(item)
                out.append(parsed if parsed else item)
            else:
                out.append(item)
        ext[key] = out


# ── 整数计数字段格式归一化 ──

_COUNT_FIELDS = frozenset({
    "layer_count", "antenna_element_count", "element_count",
    "design_variable_count",
})


def _normalize_count_fields(ext: dict) -> None:
    """把 layer_count 等计数字段的裸字符串 '2' 归一为 hybrid dict
    {"raw": "2", "value_num": 2, "unit": "dimensionless"}。"""
    for field in _COUNT_FIELDS:
        if field not in ext or not isinstance(ext[field], list):
            continue
        out = []
        for item in ext[field]:
            if isinstance(item, dict) and "raw" in item:
                out.append(item)
            elif isinstance(item, str):
                s = item.strip()
                num_match = re.match(r"^(\d+)\s*(layers?|层)?$", s, re.IGNORECASE)
                if num_match:
                    out.append({
                        "raw": s,
                        "value_num": int(num_match.group(1)),
                        "unit": "dimensionless",
                    })
                else:
                    out.append(_make_hybrid(raw=s, value=s, unit="dimensionless"))
            elif isinstance(item, (int, float)):
                out.append({
                    "raw": str(item),
                    "value_num": int(item) if float(item).is_integer() else float(item),
                    "unit": "dimensionless",
                })
            else:
                out.append(item)
        ext[field] = out


# ── unit 字段污染清洗 ──

_UNIT_MAX_LEN = 20  # 合法物理单位不会超过 20 字符


def _sanitize_hybrid_units(ext: dict) -> None:
    """清洗 hybrid dict 中 unit 字段被塞入描述性文字的情况。
    如 unit='GHz broadband ... vs. ~400 MHz in prior work' → unit='GHz'。"""
    for field, val in ext.items():
        if field.startswith("_"):
            continue
        entries = None
        if isinstance(val, list):
            entries = val
        elif isinstance(val, dict) and isinstance(val.get("values"), list):
            entries = val["values"]
        if not entries:
            continue
        for item in entries:
            if not isinstance(item, dict) or "unit" not in item:
                continue
            unit = item["unit"]
            if not isinstance(unit, str) or len(unit) <= _UNIT_MAX_LEN:
                continue
            # 取第一个 token 作为真实单位
            first_token = unit.split()[0] if unit.split() else ""
            # 去掉尾部标点
            first_token = first_token.rstrip(",;:")
            item["unit"] = first_token


def _structure_parameter_range(ext: dict) -> None:
    """parameter_range 从 ['1.40 nm', '2.01 nm', ...] 变成
    {values: [{raw, value_num, unit}...], min, max, count, unit}。
    单位不统一或无法解析为数字时保留原始列表。"""
    key = "parameter_range"
    if key not in ext or not isinstance(ext[key], list):
        return
    parsed_items = []
    numbers = []
    units = set()
    for item in ext[key]:
        if isinstance(item, dict) and "raw" in item:
            p = item
        elif isinstance(item, dict) and "value" in item:
            p = _migrate_legacy_value_unit(item)
        elif isinstance(item, str):
            p = _split_value_unit(item)
            if not p:
                return
        else:
            return
        num = p.get("value_num")
        if num is None:
            return
        numbers.append(float(num))
        units.add(p.get("unit", ""))
        parsed_items.append(p)
    if not numbers or len(units) != 1:
        return
    ext[key] = {
        "values": parsed_items,
        "min": min(numbers),
        "max": max(numbers),
        "count": len(numbers),
        "unit": next(iter(units)),
    }


def _enforce_schema_whitelist(ext: dict, paper_id: str = "?") -> list:
    """最后一道守门：把非 schema 的裸 key 全部砍掉（保留 _ 前缀的自定义发现字段）。"""
    schema_fields = _load_schema_fields()
    if not schema_fields:
        return []
    dropped = []
    for key in list(ext.keys()):
        if key.startswith("_"):
            continue
        if key not in schema_fields:
            dropped.append(key)
            del ext[key]
    if dropped:
        logger.warning(
            "[%s] schema_whitelist dropped %d off-schema fields: %s",
            paper_id, len(dropped), dropped[:15],
        )
    return dropped


# ── 核心机理字段后处理回填（从已有字段 + 叙述文本派生） ──

# 叙述字段关键词 → schema 字段的映射规则
# 每条规则: (target_field, source_extracted_fields, narrative_keywords)
#   - 若 target_field 已存在 → 跳过
#   - 若 source_extracted_fields 中有字段存在 → 从中合成
#   - 否则从叙述文本中用 narrative_keywords 正则匹配提取摘要
_BACKFILL_RULES: list = [
    # frequency_performance ← working_band_range + fractional_bandwidth + insertion_loss
    {
        "target": "frequency_performance",
        "sources": ["working_band_range", "fractional_bandwidth", "insertion_loss"],
        "compose": lambda src: _compose_list_summary(src, "frequency_performance"),
    },
    # angular_performance ← angular_stability
    {
        "target": "angular_performance",
        "sources": ["angular_stability"],
        "compose": lambda src: src.get("angular_stability", [])[:],
    },
    # multilayer_coupled ← layer_count + layer_stack_description + coupling_behavior
    {
        "target": "multilayer_coupled",
        "sources": ["layer_count", "layer_stack_description", "coupling_behavior"],
        "min_sources": 2,
        "compose": lambda src: _compose_list_summary(src, "multilayer_coupled"),
    },
    # spatial_symmetry ← unit_cell_symmetry + angle_polarization_robustness_cause
    {
        "target": "spatial_symmetry",
        "sources": ["unit_cell_symmetry", "angle_polarization_robustness_cause"],
        "compose": lambda src: _compose_list_summary(src, "spatial_symmetry"),
    },
    # optimization_objective ← objective_function_or_design_criterion
    {
        "target": "optimization_objective",
        "sources": ["objective_function_or_design_criterion"],
        "compose": lambda src: src.get("objective_function_or_design_criterion", [])[:],
    },
    # response_metrics ← performance + design_constraints_or_allowable_limits
    {
        "target": "response_metrics",
        "sources": ["performance", "design_constraints_or_allowable_limits"],
        "compose": lambda src: _compose_list_summary(src, "response_metrics"),
    },
]

# 叙述文本关键词回填规则（仅当 extracted_data 中完全无来源字段时使用）
_NARRATIVE_BACKFILL_RULES: list = [
    {
        "target": "frequency_performance",
        "keywords": [
            r"bandwidth\s+(?:of\s+)?[\d.]+",
            r"frequency\s+selectivity",
            r"out-of-band\s+(?:suppression|rejection)",
            r"roll-off",
            r"passband.*stopband",
        ],
        "narrative_fields": ["influence_analysis", "design_optimization_logic"],
    },
    {
        "target": "angular_performance",
        "keywords": [
            r"angular\s+stability",
            r"oblique\s+incidence.*(?:\d+°|\d+\s*deg)",
            r"angle.*(?:stable|insensitive)",
            r"incident\s+angle.*(?:up\s+to|from.*to)\s+\d+",
        ],
        "narrative_fields": ["influence_analysis", "physical_mechanism"],
    },
    {
        "target": "spatial_symmetry",
        "keywords": [
            r"(?:C[24]|four-fold|two-fold)\s+symmetr",
            r"(?:mirror|rotational|centrosymmetric)\s+symmetr",
            r"polarization\s+insensitiv.*(?:due\s+to|because\s+of).*symmetr",
        ],
        "narrative_fields": ["physical_mechanism", "design_optimization_logic"],
    },
    {
        "target": "multilayer_coupled",
        "keywords": [
            r"(?:multi|dual|triple)-layer.*coupl",
            r"inter-layer\s+(?:coupling|phase)",
            r"vertical\s+coupling",
            r"stacked.*(?:FSS|layer|resonator).*coupl",
        ],
        "narrative_fields": ["physical_mechanism", "design_optimization_logic"],
    },
]


def _compose_list_summary(sources: dict, target: str) -> list:
    """从多个源字段的值列表中合成目标字段的值列表。"""
    out = []
    for field, vals in sources.items():
        if not isinstance(vals, list):
            continue
        for v in vals:
            if isinstance(v, str):
                out.append(v)
            elif isinstance(v, dict) and "raw" in v:
                out.append(v["raw"])
    return out[:5]


def _extract_narrative_snippet(text: str, patterns: list, max_len: int = 120) -> Optional[str]:
    """从叙述文本中用正则匹配提取第一个命中的句子片段。"""
    for pat in patterns:
        m = re.search(pat, text, re.IGNORECASE)
        if m:
            start = max(0, text.rfind(".", 0, m.start()) + 1)
            end = text.find(".", m.end())
            if end == -1:
                end = min(len(text), m.end() + 80)
            else:
                end = min(end + 1, m.start() + max_len)
            snippet = text[start:end].strip()
            if len(snippet) > 15:
                return snippet
    return None


def _backfill_derived_fields(ext: dict, result: dict) -> None:
    """从已有 extracted_data 字段和叙述文本中派生缺失的核心机理字段。"""
    # Phase 1: 从已有 extracted_data 字段合成
    for rule in _BACKFILL_RULES:
        target = rule["target"]
        if target in ext:
            continue
        sources_present = {
            s: ext[s] for s in rule["sources"] if s in ext
        }
        min_sources = rule.get("min_sources", 1)
        if len(sources_present) >= min_sources:
            composed = rule["compose"](sources_present)
            if composed:
                ext[target] = composed

    # Phase 2: 从叙述文本中关键词回填
    for rule in _NARRATIVE_BACKFILL_RULES:
        target = rule["target"]
        if target in ext:
            continue
        for nf in rule["narrative_fields"]:
            text = result.get(nf, "")
            if not isinstance(text, str) or not text:
                continue
            snippet = _extract_narrative_snippet(text, rule["keywords"])
            if snippet:
                ext[target] = [snippet]
                break


def _postprocess_haiku(result: dict, family: Optional[str] = None) -> dict:
    """Haiku 专用深度清洗。

    处理 5 类 Haiku 特有问题：
      H-C1: 类型归一化（防御性，复用 nano 逻辑）
      H-C2: 字段别名纠正（复用 nano 映射）
      H-C3: _advancement 自动合成（从 _novelty/_contribution/_improvement_over_baseline）
      H1:   括号注解剥离（773 处）
      H3:   推测性/臆造值清除（implied 等）
      H4:   值长度截断（超 15 词）

    新增流水线（在 H4 之后、删空键之前）：
      HN0: 8 跨域字段裸名 → _ 前缀迁移 + {value, why_notable} 重构
      HN1: 元素含量合并（ni_content → other_alloying_elements）   [alloy only]
      HN2: alloy_name_normalized / alloy_system 规范化              [alloy only]
      HN3: value+unit 拆分（hybrid {raw, value_num, unit}）
      HN3b: 数值字段单位校验
      HN3c: interface_energy 等字段按单位分流                        [alloy only]
      HN4: parameter_range 结构化
      HN5: schema 白名单过滤
    """
    run_alloy = _is_alloy_family(family)
    ext = result.get("extracted_data", {})
    if not isinstance(ext, dict):
        return result

    # ── H-C1: 类型归一化 (bare string/dict → list) ──
    for key in list(ext.keys()):
        if key.startswith("_"):
            continue
        val = ext[key]
        if isinstance(val, str):
            ext[key] = [val]
        elif isinstance(val, dict):
            if "value" in val:
                ext[key] = [str(val["value"])]
            else:
                ext[key] = [str(val)]
        elif isinstance(val, (int, float)):
            ext[key] = [str(val)]

    # ── H-C2: 字段名规范化 ──
    for wrong_name, correct_name in _HAIKU_FIELD_ALIASES.items():
        if wrong_name in ext:
            if correct_name and correct_name not in ext:
                ext[correct_name] = ext[wrong_name]
            del ext[wrong_name]

    # ── HN0: 8 跨域字段迁移到 _ 前缀（必须在 H-C3 之前，之后 advancement 已是 _advancement） ──
    # aerospace family: 6 个字段是正式 schema 字段，不参与迁移；
    # 同时把 LLM 误输出的 _前缀形式还原为裸名 list。
    is_aerospace = (family or _DOMAIN_FAMILY) == "aerospace"
    if is_aerospace:
        _apply_underscore_rename(ext, skip_fields=_AEROSPACE_BARE_SCHEMA_FIELDS)
        _demigrate_underscore_to_bare(ext, _AEROSPACE_BARE_SCHEMA_FIELDS)
    else:
        _apply_underscore_rename(ext)

    # ── H-C3: _advancement 自动合成 ──
    # 如果还没有 _advancement，从 _novelty / _contribution / _improvement_over_baseline 合成
    # aerospace 家族跳过：advancement/novelty/contribution 已是裸名 schema 字段。
    if not is_aerospace and "_advancement" not in ext:
        src_values = []
        for src_key in ("_improvement_over_baseline", "_novelty", "_contribution"):
            src = ext.get(src_key)
            if isinstance(src, dict):
                v = src.get("value")
                if v:
                    src_values.append(str(v))
        if src_values:
            ext["_advancement"] = {
                "value": " | ".join(src_values[:3]),
                "why_notable": "Synthesized from _improvement_over_baseline / _novelty / _contribution",
            }

    # ── H3: 推测性/臆造值清除（必须在括号剥离前运行，否则 "implied" 被剥离后漏检） ──
    keys_to_delete = []
    for key in list(ext.keys()):
        if key.startswith("_"):
            continue
        val = ext.get(key)
        if not isinstance(val, list):
            continue
        cleaned = [
            v for v in val
            if not (isinstance(v, str) and _SPECULATIVE_RE.search(v))
        ]
        if not cleaned:
            keys_to_delete.append(key)
        elif len(cleaned) != len(val):
            ext[key] = cleaned

    # ── H1: 括号注解剥离 ──
    for key, val in ext.items():
        if key.startswith("_"):
            continue
        if not isinstance(val, list):
            continue
        cleaned = []
        for v in val:
            if not isinstance(v, str):
                cleaned.append(v)
                continue
            stripped = _PAREN_ANNOTATION_RE.sub("", v).strip()
            if stripped:
                cleaned.append(stripped)
        if cleaned:
            ext[key] = cleaned
        else:
            keys_to_delete.append(key)

    # ── H4: 值长度截断 ──
    for key, val in ext.items():
        if key.startswith("_"):
            continue
        if key in _HAIKU_LONG_TEXT_FIELDS:
            continue
        if not isinstance(val, list):
            continue
        truncated = []
        for v in val:
            if isinstance(v, str) and len(v.split()) > _HAIKU_MAX_VALUE_WORDS:
                words = v.split()[:_HAIKU_MAX_VALUE_WORDS]
                truncated.append(" ".join(words))
                logger.debug("Haiku value truncated [%s]: %d→%d words",
                             key, len(v.split()), _HAIKU_MAX_VALUE_WORDS)
            else:
                truncated.append(v)
        ext[key] = truncated

    # ── 新增流水线：顺序关键 ──
    # HN1: 合并非 schema 的 <element>_content 到 other_alloying_elements（alloy only）
    if run_alloy:
        _merge_off_schema_element_contents(ext)
    # HN2a: alloy_name_normalized 规范化（alloy only）
    if run_alloy:
        _canonicalize_alloy_names(ext)
    # HN2b: 从 alloy_designation_reported 派生 alloy_aliases（alloy only）
    if run_alloy:
        _derive_alloy_aliases(ext)
    # HN2c: 枚举字段受控词表归一（alloy_system 仅 alloy 家族执行；其余跨域运行）
    _normalize_enum_fields(ext, family)
    # HN3: 把 '4.001 Å' 这类字符串拆成 hybrid {raw, value_num, unit}
    _apply_value_unit_split(ext)
    # HN3a-fix: 整数计数字段格式归一化（layer_count 等裸字符串 → hybrid dict）
    _normalize_count_fields(ext)
    # HN3b: 数值字段单位校验（temperature / rate / strength …）
    _enforce_numeric_units(ext)
    # HN3c: interface_energy / gibbs_thomson_coefficient 等按单位分流（alloy only —
    # 这些字段存在于 titanium_alloy schema，aerospace schema 无此字段）
    if run_alloy:
        _reroute_unit_mismatched_fields(ext)
    # HN4: parameter_range 结构化（必须在 HN3 之后）
    _structure_parameter_range(ext)
    # HN4b: 单位规范化（字面统一 + °C→K + time→h + 同物理量数值转换 + 噪声标记）
    #       放在 _structure_parameter_range 之后，以便 parameter_range 的 values 也被处理
    _canonicalize_units(ext)
    # HN4b-fix: unit 字段污染清洗（描述性文字误入 unit → 只保留首 token）
    _sanitize_hybrid_units(ext)
    # HN4c: 范围回填（value_num=null 的 hybrid 条目 → value_min/value_max）
    _backfill_ranges_on_entries(ext)
    # HN4d: 为剩余的 _ 前缀 dict 字段补齐空 why_notable
    _fill_missing_why_notable(ext)
    # HN4e: 从已有字段派生缺失的核心机理字段（零 LLM 成本）
    _backfill_derived_fields(ext, result)
    # HN5: schema 白名单过滤（放最后，保证前面所有变换的结果只保留合法 key）
    _enforce_schema_whitelist(ext, paper_id=result.get("paper_id", "?"))

    # 删除空键
    for key in set(keys_to_delete):
        if key in ext:
            del ext[key]

    result["extracted_data"] = ext
    return result


# ===================================================================
# D. Schema 验证（所有模型共享，质量门禁）
# ===================================================================

# 当论文内容中存在相关信息时，这些字段应该被提取
# 注：author / title / publication_year 已改由 extract_test.py 的 _parse_md_header()
# 从 full.md 头部解析后 inject 进 extracted_data。md 解析失败时允许缺失，不再报 MISSING
# 原来的 contribution / novelty / advancement / study_validation_method 已迁移到 _ 前缀
# 空间，作为论文级独特发现字段；validate_extraction 不再强制要求它们出现。
_MANDATORY_IF_CONTENT_EXISTS = [
    "dominant_mechanism",
]

# 7 个叙述字段
_NARRATIVE_FIELDS = [
    "problem_context",
    "study_process_description",
    "design_optimization_logic",
    "physical_mechanism",
    "fabrication_process",
    "design_method",
    "influence_analysis",
]

# 模型特定的叙述最低字数
_NARRATIVE_MIN_WORDS = {
    "mini": {
        "problem_context": 180,
        "study_process_description": 260,
        "design_optimization_logic": 180,
        "physical_mechanism": 180,
        "fabrication_process": 150,
        "design_method": 130,
        "influence_analysis": 180,
    },
    "nano": {
        "problem_context": 150,
        "study_process_description": 200,
        "design_optimization_logic": 150,
        "physical_mechanism": 150,
        "fabrication_process": 100,
        "design_method": 100,
        "influence_analysis": 150,
    },
    "haiku": {
        "problem_context": 180,
        "study_process_description": 260,
        "design_optimization_logic": 180,
        "physical_mechanism": 180,
        "fabrication_process": 150,
        "design_method": 130,
        "influence_analysis": 180,
    },
}


def validate_extraction(result: dict, model: str) -> List[str]:
    """
    Schema 质量验证，返回 warnings 列表。不修改数据，仅记录问题。

    Args:
        result: 后处理完成的单篇提取结果
        model:  模型名称

    Returns:
        警告字符串列表（空 = 通过）
    """
    warnings = []
    ext = result.get("extracted_data", {})
    if not isinstance(ext, dict):
        warnings.append("FATAL:extracted_data is not dict")
        return warnings

    # 1. 关键字段缺失检查
    for field in _MANDATORY_IF_CONTENT_EXISTS:
        if field not in ext:
            warnings.append(f"MISSING:{field}")

    # 2. 类型一致性检查
    # parameter_range 被 _structure_parameter_range 转为 dict，属于合法例外
    _STRUCTURED_DICT_FIELDS = {"parameter_range"}
    for key, val in ext.items():
        if key.startswith("_"):
            if not isinstance(val, dict):
                warnings.append(f"CUSTOM_TYPE:{key}=should_be_dict")
        elif key in _STRUCTURED_DICT_FIELDS:
            if not isinstance(val, (list, dict)):
                warnings.append(f"TYPE:{key}={type(val).__name__}")
        else:
            if not isinstance(val, list):
                warnings.append(f"TYPE:{key}={type(val).__name__}")

    # 3. 叙述字段字数检查
    model_key = next(
        (k for k in _NARRATIVE_MIN_WORDS if k in model), None
    )
    min_words_map = _NARRATIVE_MIN_WORDS.get(model_key, {})
    for field in _NARRATIVE_FIELDS:
        text = result.get(field, "")
        wc = len(text.split()) if isinstance(text, str) else 0
        min_wc = min_words_map.get(field, 100)
        if 0 < wc < min_wc:
            warnings.append(f"SHORT:{field}={wc}words<{min_wc}")

    # 4. influence_analysis 数值密度检查
    ia = result.get("influence_analysis", "")
    if isinstance(ia, str):
        num_count = len(re.findall(r"-?[\d]+\.?[\d]*", ia))
        if "mini" in model and num_count < 15:
            warnings.append(f"LOW_NUMS:influence_analysis={num_count}<15")
        elif "haiku" in model and num_count < 10:
            warnings.append(f"LOW_NUMS:influence_analysis={num_count}<10")
        elif "nano" in model and num_count < 8:
            warnings.append(f"LOW_NUMS:influence_analysis={num_count}<8")

    return warnings


# ===================================================================
# E. 编码后处理管道（所有模型共享）
# ===================================================================

# 顶层叙述字段（应为 str 类型）
_TOP_LEVEL_STR_FIELDS = [
    "paper_title", "problem_context", "study_process_description",
    "design_optimization_logic", "physical_mechanism", "fabrication_process",
    "design_method", "influence_analysis",
]

# [P0XX] 前缀模式
_PID_PREFIX_RE = re.compile(r"^\[P\d{2,4}\]\s*")

# 常见 mojibake 编码恢复尝试序列
_MOJIBAKE_DECODERS = [
    ("latin-1", "utf-8"),
    ("cp1252", "utf-8"),
    ("iso-8859-1", "utf-8"),
]


def _try_fix_mojibake(text: str) -> str:
    """尝试修复 mojibake（UTF-8 被错误解码为 Latin-1/CP1252 等）。

    检测策略：如果字符串包含 \\u00C0-\\u00FF 范围内的 Latin 扩展字符
    且不含有效 CJK 字符，则尝试 re-encode → re-decode 恢复。
    """
    if not text or text.isascii():
        return text

    has_cjk = any("\u4e00" <= c <= "\u9fff" for c in text)
    has_latin_ext = any("\u00c0" <= c <= "\u00ff" for c in text)

    # 如果已包含有效 CJK，不太可能是 mojibake
    if has_cjk and not has_latin_ext:
        return text

    # 如果包含 Latin 扩展字符但无 CJK，尝试恢复
    if has_latin_ext:
        for src_enc, tgt_enc in _MOJIBAKE_DECODERS:
            try:
                raw = text.encode(src_enc)
                recovered = raw.decode(tgt_enc)
                # 验证恢复结果：应该包含 CJK 或至少看起来更合理
                if any("\u4e00" <= c <= "\u9fff" for c in recovered):
                    return recovered
            except (UnicodeEncodeError, UnicodeDecodeError):
                continue

    return text


def _normalize_to_str(value: Any) -> str:
    """将 list/dict/其他类型归一化为 str。"""
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        # 取第一个非空字符串元素
        for item in value:
            s = str(item).strip()
            if s:
                return s
        return ""
    if isinstance(value, dict):
        return str(value.get("value", value))
    return str(value)


def _strip_pid_prefix(text: str) -> str:
    """去除 [P001] 等编号前缀。"""
    return _PID_PREFIX_RE.sub("", text).strip()


def _deep_fix_encoding(obj: Any) -> Any:
    """递归遍历 dict/list/str，对所有字符串尝试 mojibake 修复。"""
    if isinstance(obj, str):
        return _try_fix_mojibake(obj)
    if isinstance(obj, list):
        return [_deep_fix_encoding(item) for item in obj]
    if isinstance(obj, dict):
        return {k: _deep_fix_encoding(v) for k, v in obj.items()}
    return obj


def fix_encoding(paper_data: dict) -> dict:
    """编码后处理管道：修复单篇论文数据中的编码和类型问题。

    处理项：
      E1: 顶层叙述字段类型归一化（list/dict → str）
      E2: paper_title 的 [P0XX] 前缀清理
      E3: 全字段递归 mojibake 修复（UTF-8/GBK/Latin-1 兼容）
      E4: extracted_data 内 [P0XX] 前缀清理
      E5: Unicode 规范化（NFC），确保 CJK 字符一致性

    Args:
        paper_data: 单篇论文的 dict

    Returns:
        修复后的 paper_data dict
    """
    if not isinstance(paper_data, dict):
        return paper_data

    # ── E1: 顶层叙述字段类型归一化 ──
    for field in _TOP_LEVEL_STR_FIELDS:
        if field in paper_data and not isinstance(paper_data[field], str):
            paper_data[field] = _normalize_to_str(paper_data[field])

    # ── E2: paper_title [P0XX] 前缀清理 ──
    if "paper_title" in paper_data:
        paper_data["paper_title"] = _strip_pid_prefix(paper_data["paper_title"])

    # ── E3: 全字段递归 mojibake 修复 ──
    paper_data = _deep_fix_encoding(paper_data)

    # ── E4: extracted_data 内 [P0XX] 前缀清理 ──
    ext = paper_data.get("extracted_data", {})
    if isinstance(ext, dict):
        # 清理 title 字段中的前缀
        if "title" in ext and isinstance(ext["title"], list):
            ext["title"] = [_strip_pid_prefix(t) if isinstance(t, str) else t
                            for t in ext["title"]]
        # 清理所有 list 字段中可能残留的 [P0XX] 前缀
        for key, val in ext.items():
            if isinstance(val, list):
                ext[key] = [
                    _strip_pid_prefix(v) if isinstance(v, str) and _PID_PREFIX_RE.match(v) else v
                    for v in val
                ]
        paper_data["extracted_data"] = ext

    # ── E5: Unicode NFC 规范化 ──
    import unicodedata

    def _nfc_normalize(obj):
        if isinstance(obj, str):
            return unicodedata.normalize("NFC", obj)
        if isinstance(obj, list):
            return [_nfc_normalize(item) for item in obj]
        if isinstance(obj, dict):
            return {k: _nfc_normalize(v) for k, v in obj.items()}
        return obj

    paper_data = _nfc_normalize(paper_data)

    return paper_data


# ===================================================================
# F. 离线补救：对已有 JSON 执行后处理
# ===================================================================

def patch_existing_knowledge_base(kb_path: str, model: str, output_path: str = None,
                                   domain_family: Optional[str] = None):
    """
    对已生成的 knowledge_base.json 做离线后处理补救。

    管线顺序：fix_encoding → postprocess → validate_extraction

    Args:
        kb_path:       现有 knowledge_base.json 路径
        model:         模型名称 (如 "claude-haiku-4-5-20251001")
        output_path:   输出路径，默认覆盖原文件
        domain_family: 领域家族；None 时使用模块级默认（由 set_domain_family 设置）
    """
    import json

    with open(kb_path, "r", encoding="utf-8") as f:
        kb = json.load(f)

    total_warnings = []
    encoding_fixes = {"type_fixes": 0, "prefix_fixes": 0, "mojibake_fixes": 0, "nfc_normalized": 0}

    for paper_id, paper_data in kb.items():
        # 记录修复前状态，用于统计
        old_title = paper_data.get("paper_title", "")
        old_title_type = type(old_title).__name__

        # Step 1: 编码后处理
        paper_data = fix_encoding(paper_data)

        # Step 2: 模型分支后处理（带域家族）
        paper_data = postprocess(paper_data, model, domain_family=domain_family)

        kb[paper_id] = paper_data

        # 统计修复
        new_title = paper_data.get("paper_title", "")
        if old_title_type != "str":
            encoding_fixes["type_fixes"] += 1
        if isinstance(old_title, str) and _PID_PREFIX_RE.match(old_title):
            encoding_fixes["prefix_fixes"] += 1
        if new_title != (old_title if isinstance(old_title, str) else ""):
            encoding_fixes["mojibake_fixes"] += 1

        # Step 3: Schema 验证
        warnings = validate_extraction(paper_data, model)
        if warnings:
            total_warnings.append((paper_id, warnings))

    out = output_path or kb_path
    with open(out, "w", encoding="utf-8") as f:
        json.dump(kb, f, ensure_ascii=False, indent=2)

    logger.info(
        "离线补救完成: %d 篇论文, %d 篇有警告 | 编码修复: type=%d, prefix=%d, mojibake=%d",
        len(kb), len(total_warnings),
        encoding_fixes["type_fixes"],
        encoding_fixes["prefix_fixes"],
        encoding_fixes["mojibake_fixes"],
    )
    for pid, warns in total_warnings:
        logger.warning("[%s] %s", pid, warns)

    return total_warnings, encoding_fixes


def patch_all_models(base_dir: str, models: List[str] = None,
                     schema_csv: Optional[str] = None,
                     domain_family: Optional[str] = None):
    """
    批量对多个模型的 knowledge_base.json 执行编码后处理。

    Args:
        base_dir:      包含各模型子目录的根目录
        models:        模型名称列表，默认自动检测子目录
        schema_csv:    schema CSV 路径（若提供则调用 set_schema_csv）
        domain_family: 领域家族（若提供则调用 set_domain_family）
    """
    import json
    from pathlib import Path

    if schema_csv:
        set_schema_csv(schema_csv)
    if domain_family:
        set_domain_family(domain_family)

    base = Path(base_dir)
    if models is None:
        models = [
            d.name for d in base.iterdir()
            if d.is_dir() and (d / "knowledge_base.json").exists()
        ]

    report = {}
    for model in sorted(models):
        kb_path = base / model / "knowledge_base.json"
        if not kb_path.exists():
            logger.warning("跳过 %s: knowledge_base.json 不存在", model)
            continue

        logger.info("=" * 60)
        logger.info("处理模型: %s", model)
        logger.info("=" * 60)

        warnings, enc_fixes = patch_existing_knowledge_base(
            str(kb_path), model, domain_family=domain_family
        )
        report[model] = {
            "papers": len(json.load(open(kb_path, encoding="utf-8"))),
            "warnings_count": len(warnings),
            "encoding_fixes": enc_fixes,
            "warning_details": {pid: w for pid, w in warnings},
        }

    # 写入汇总报告
    report_path = base / "encoding_fix_report.json"
    with open(report_path, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)

    logger.info("编码后处理汇总报告已写入: %s", report_path)
    return report


if __name__ == "__main__":
    import sys

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
    )

    if len(sys.argv) < 2:
        print("用法:")
        print("  单模型: python postprocess.py <knowledge_base.json> <model_name> [output.json]")
        print("  批量:   python postprocess.py --batch <base_dir> [model1 model2 ...]")
        print()
        print("示例:")
        print("  python postprocess.py ./claude-haiku-4-5-20251001/knowledge_base.json claude-haiku-4-5-20251001")
        print("  python postprocess.py --batch ./extract_test_output2")
        print("  python postprocess.py --batch ./extract_test_output2 claude-haiku-4-5-20251001")
        sys.exit(1)

    if sys.argv[1] == "--batch":
        base_directory = sys.argv[2]
        model_list = sys.argv[3:] if len(sys.argv) > 3 else None
        patch_all_models(base_directory, model_list or None)
    else:
        kb_file = sys.argv[1]
        model_name = sys.argv[2]
        out_file = sys.argv[3] if len(sys.argv) > 3 else None
        patch_existing_knowledge_base(kb_file, model_name, out_file)
