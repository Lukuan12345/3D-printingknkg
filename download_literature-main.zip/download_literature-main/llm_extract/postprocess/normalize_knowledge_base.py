#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
normalize_knowledge_base.py — 对已抽取的 knowledge_base.json 做离线归一化。

三个归一化模块：
  A. _ 前缀字段受控词表（8 个规范 key）+ 变体归并
  B. 数值/范围回填（value_num → value_min/value_max）
  C. 字符串数组近义聚类归一化（target_response / dominant_mechanism 等）

输入: knowledge_base.json
输出:
  - knowledge_base.normalized.json
  - normalize_report.json

用法:
  python normalize_knowledge_base.py
  python normalize_knowledge_base.py --input <path> --output <path>
  python normalize_knowledge_base.py --dry-run           # 不写文件，仅打印报告
"""

from __future__ import annotations

import argparse
import io
import json
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any


# Windows 控制台 utf-8
if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")


# ===================================================================
# 默认路径
# ===================================================================

DEFAULT_KB = Path(
    "C:/Users/suyulin/Desktop/utils/literature_knowledge_extractor/"
    "extract_alloy_output4/claude-haiku-4-5-20251001/knowledge_base.json"
)


# ===================================================================
# 模块 A — _ 前缀受控词表 + 变体归并
# ===================================================================

CANONICAL_UNDERSCORE = {
    "_advancement",
    "_novelty",
    "_contribution",
    "_comparison_baseline",
    "_improvement_over_baseline",
    "_sensitivity_result",
    "_novel_metric_name",
    "_novel_mechanism",
}

# 静态映射：已知变体 → 规范 key
VARIANT_TO_CANONICAL = {
    # _sensitivity_result 族
    "_sensitivity_tb_spacing": "_sensitivity_result",
    "_sensitivity_analysis": "_sensitivity_result",
    # _novel_metric_name 族（两头互指，以 _novel_metric_name 为规范）
    "_novel_metric": "_novel_metric_name",
    # _novel_mechanism 族
    "_novel_mechanism_hierarchical_twins": "_novel_mechanism",
    "_novel_deformation_mechanism": "_novel_mechanism",
    "_mechanism_insight": "_novel_mechanism",
    "_mechanism_validation": "_novel_mechanism",
    "_mechanism_discovery": "_novel_mechanism",
}


def _dynamic_variant_target(key: str) -> str | None:
    """对没在静态表里的变体，按前缀动态归一。"""
    if key in CANONICAL_UNDERSCORE:
        return None
    # _sensitivity_xxx → _sensitivity_result
    if key.startswith("_sensitivity_"):
        return "_sensitivity_result"
    # _novel_mechanism_xxx / _mechanism_xxx → _novel_mechanism
    if key.startswith("_novel_mechanism_") or key.startswith("_mechanism_"):
        return "_novel_mechanism"
    # _novel_metric_xxx → _novel_metric_name
    if key.startswith("_novel_metric"):
        return "_novel_metric_name"
    return None


def _merge_underscore_dict(existing: dict, incoming: dict) -> dict:
    """合并两条 {value, why_notable}。value 用 ' | ' 拼接；why_notable 取较长者。"""
    ev = str(existing.get("value", "")).strip()
    iv = str(incoming.get("value", "")).strip()
    merged_value = ev if ev == iv else (f"{ev} | {iv}" if ev and iv else (ev or iv))

    ew = str(existing.get("why_notable", "")).strip()
    iw = str(incoming.get("why_notable", "")).strip()
    if ew == iw:
        merged_why = ew
    elif not ew:
        merged_why = iw
    elif not iw:
        merged_why = ew
    else:
        merged_why = ew if len(ew) >= len(iw) else iw

    return {"value": merged_value, "why_notable": merged_why}


def consolidate_underscore_keys(paper_id: str, ed: dict, renames_log: dict) -> None:
    """A 模块：把 ed 里的 _ 变体 key 归到规范 key。就地修改 ed。"""
    to_delete: list[str] = []
    for key in list(ed.keys()):
        if not key.startswith("_"):
            continue
        target = VARIANT_TO_CANONICAL.get(key) or _dynamic_variant_target(key)
        if not target or target == key:
            continue

        val = ed[key]
        if not isinstance(val, dict):
            # 非 {value, why_notable} 结构不碰（防御性）
            continue

        if target in ed and isinstance(ed[target], dict):
            ed[target] = _merge_underscore_dict(ed[target], val)
        else:
            ed[target] = val

        to_delete.append(key)
        renames_log.setdefault(paper_id, {})[key] = target

    for k in to_delete:
        del ed[k]


# ===================================================================
# 模块 B — 数值/范围回填
# ===================================================================

_SUPERSCRIPT_MAP = str.maketrans("⁰¹²³⁴⁵⁶⁷⁸⁹⁻⁺", "0123456789-+")
_NUM_RE = re.compile(r"[+-]?\d+(?:\.\d+)?")
_DASH_RANGE_RE = re.compile(
    r"^\s*[~≈]?\s*([+-]?\d+(?:\.\d+)?)\s*[–—]\s*([+-]?\d+(?:\.\d+)?)"
)
# a-b 只有在两端都是纯数字时接受，避免匹配 "2024-2026" 之外的非范围
_HYPHEN_RANGE_RE = re.compile(
    r"^\s*[~≈]?\s*([+-]?\d+(?:\.\d+)?)-([+-]?\d+(?:\.\d+)?)(?:\s|$)"
)
# 阈值前缀：≤ ≥ < > ~ ≈
_THRESHOLD_RE = re.compile(r"^\s*[~≈≤≥<>]\s*([+-]?\d+(?:\.\d+)?)")
# 首数字兜底
_LEAD_NUM_RE = re.compile(r"^\s*[~≈≤≥<>]?\s*([+-]?\d+(?:\.\d+)?)")
# 公式/定性描述识别
_FORMULA_RE = re.compile(r"[=≈]\s*[^\d]")  # "x = something non-numeric"
_QUALITATIVE_TOKENS = (
    "highest", "lowest", "not ", "n/a", "unknown", "variable",
    "qualitative", "emergent", "implied", "assumed", "controlled by",
    "before remelting", "after remelting",  # 状态描述
)
# 含以下词时，逗号分隔的多数字不视为范围（3D 尺寸 / 多轴规格）
_DIMENSION_TOKENS = (
    " long", " wide", " high", " thick", " deep",
    " diameter", " radius", " length", " width", " height",
    " forward", " rear", " front", " back",
    " x axis", " y axis", " z axis",
)


def _strip_subscript_sup(s: str) -> str:
    return s.translate(_SUPERSCRIPT_MAP)


def _has_formula(raw: str) -> bool:
    """含等号且右边不是纯数字+单位的视为公式。"""
    # 简单启发：含 '=' 且后面跟字母/希腊字母
    if "=" in raw:
        # 允许 "Δ = 0.1" 这种纯数字赋值；但 "Δt = 0.1h²/D" 也当公式
        m = re.search(r"=\s*[^\s]+", raw)
        if m and re.search(r"[a-zA-Zα-ωΑ-Ω]", m.group(0)[1:]):
            return True
    return False


def _is_qualitative(raw: str) -> bool:
    low = raw.lower()
    return any(tok in low for tok in _QUALITATIVE_TOKENS)


def parse_raw_to_numeric(raw: str) -> dict:
    """解析 raw 字符串，返回 {value_num?, value_min?, value_max?} 的子集。
    解析失败返回 {}（调用方维持现状，value_num 仍为 None）。"""
    if not isinstance(raw, str):
        return {}
    s = _strip_subscript_sup(raw.strip())
    if not s:
        return {}
    if _is_qualitative(s) or _has_formula(s):
        return {}

    # 1. dash 范围：1.40–7.00 nm
    m = _DASH_RANGE_RE.match(s)
    if m:
        return {"value_min": float(m.group(1)), "value_max": float(m.group(2))}

    # 2. hyphen 范围（两端都是纯数字）：0-50 μm
    m = _HYPHEN_RANGE_RE.match(s)
    if m:
        a, b = float(m.group(1)), float(m.group(2))
        if a <= b:  # 合理范围
            return {"value_min": a, "value_max": b}

    # 3. "a ... to b ..." 范围：305 K/mm at bottom to 85 K/mm at top
    if " to " in s:
        left, right = s.split(" to ", 1)
        ml = _NUM_RE.search(left)
        mr = _NUM_RE.search(right)
        if ml and mr:
            a, b = float(ml.group(0)), float(mr.group(0))
            lo, hi = min(a, b), max(a, b)
            return {"value_min": lo, "value_max": hi}

    # 4. 逗号/分号列表：1g, 5g, 10g, 15g, 20g（需要至少 3 个数字）
    #    但含维度描述词（long/wide/high/…）时跳过，避免把 3D 尺寸误当范围
    nums = [float(x) for x in _NUM_RE.findall(s)]
    has_dim = any(tok in f" {s.lower()} " for tok in _DIMENSION_TOKENS)
    if "," in s and len(nums) >= 3 and not has_dim:
        return {"value_min": min(nums), "value_max": max(nums)}

    # 5. 阈值前缀：≤0.08 wt.%
    m = _THRESHOLD_RE.match(s)
    if m:
        return {"value_num": float(m.group(1))}

    # 6. 首数字兜底（只有 1 个数字的简单 case，或多维描述如 "8 mm diameter, 165 mm long"）
    m = _LEAD_NUM_RE.match(s)
    if m:
        return {"value_num": float(m.group(1))}

    return {}


def backfill_numeric_ranges(paper_id: str, ed: dict, log: list) -> None:
    """B 模块：遍历 ed 所有 list/dict-of-values 字段，给 value_num=null 的 hybrid 条目
    回填 value_num 或 value_min/value_max。就地修改。"""
    for field, val in ed.items():
        if field.startswith("_"):
            continue

        # 两种容器：list[dict] 和 {values: [...]}
        if isinstance(val, list):
            entries = val
        elif isinstance(val, dict) and isinstance(val.get("values"), list):
            entries = val["values"]
        else:
            continue

        for item in entries:
            if not isinstance(item, dict):
                continue
            if "raw" not in item:
                continue
            if item.get("value_num") is not None:
                continue
            # 已经有 min/max 的跳过
            if "value_min" in item or "value_max" in item:
                continue
            raw = item.get("raw", "")
            parsed = parse_raw_to_numeric(raw)
            if not parsed:
                continue

            item.update(parsed)
            item["_parsed_by"] = "postprocess_range_parser"
            log.append({
                "paper": paper_id,
                "field": field,
                "raw": raw,
                **{k: v for k, v in parsed.items()},
            })


# ===================================================================
# 模块 C — 字符串数组近义聚类归一化
# ===================================================================

DEFAULT_CLUSTER_FIELDS = (
    "target_response",
    "dominant_mechanism",
    "observed_trend",
    "optimization_objective",
    "deformation_mode",
    "slip_system_set",
    "transformation_pathway_identifier",
    "validation_status",
)


def _signature(s: str) -> str:
    """字面规范化签名：lowercase，破折号→空格，去外部标点，压缩空格。
    保留内部符号 < > + / . 以区分 '<c+a>' 这类术语。"""
    t = s.strip().lower()
    t = t.replace("–", "-").replace("—", "-")
    t = t.replace("-", " ")
    # 保留字母数字/空白/内部结构符；去掉句号、逗号等外部标点
    t = re.sub(r"[^\w\s<>+/.]", " ", t)
    t = re.sub(r"\s+", " ", t).strip(" ,.;:")
    return t


def _is_plural_of(singular: str, plural: str) -> bool:
    """判断 plural 是否是 singular 的复数形式（简单英语复数规则）。"""
    if plural == singular + "s":
        return True
    if plural == singular + "es":
        return True
    if singular.endswith("y") and plural == singular[:-1] + "ies":
        return True
    return False


def _plural_equivalent(a: str, b: str) -> bool:
    """a、b 两个签名只差 token 级复数形式（逐 token 对应）视为等价。"""
    if a == b:
        return True
    toks_a = a.split()
    toks_b = b.split()
    if len(toks_a) != len(toks_b):
        return False
    for x, y in zip(toks_a, toks_b):
        if x == y:
            continue
        if not (_is_plural_of(x, y) or _is_plural_of(y, x)):
            return False
    return True


def _build_clusters(strings: list[str]) -> dict[str, list[str]]:
    """最保守聚类：仅合并字面等价变体（大小写/破折号/标点/空白/单复数）。
    不做 SequenceMatcher 模糊匹配，避免短字符串上的语义反合并。
    返回 {canonical: [原始1, 原始2, ...]}。"""
    freq = Counter(strings)
    unique_originals = list(freq.keys())

    # Step 1: 按签名分组
    sig_groups: dict[str, list[str]] = defaultdict(list)
    for s in unique_originals:
        sig_groups[_signature(s)].append(s)

    # Step 2: 签名之间的单复数并查集合并
    sig_keys = list(sig_groups.keys())
    parent: dict[str, str] = {k: k for k in sig_keys}

    def find(x: str) -> str:
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a: str, b: str) -> None:
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[rb] = ra

    for i in range(len(sig_keys)):
        for j in range(i + 1, len(sig_keys)):
            a, b = sig_keys[i], sig_keys[j]
            if _plural_equivalent(a, b):
                union(a, b)

    # Step 3: 在每个并查集里挑 canonical（频次高 > 短 > 字典序）
    cluster_members: dict[str, list[str]] = defaultdict(list)
    for sig in sig_keys:
        root = find(sig)
        cluster_members[root].extend(sig_groups[sig])

    out: dict[str, list[str]] = {}
    for _root, originals in cluster_members.items():
        scored = sorted(originals, key=lambda s: (-freq[s], len(s), s))
        canonical = scored[0]
        out[canonical] = originals
    return out


def cluster_and_rewrite_strings(
    kb: dict, target_fields: tuple[str, ...]
) -> dict:
    """C 模块：对每个目标字段做全局聚类并重写每篇论文。返回聚类报告。"""
    report: dict[str, dict[str, list[str]]] = {}

    for field in target_fields:
        # 收集全量
        all_vals: list[str] = []
        for p in kb.values():
            ed = p.get("extracted_data", {})
            lst = ed.get(field)
            if isinstance(lst, list):
                all_vals.extend([v for v in lst if isinstance(v, str)])

        if not all_vals:
            continue

        clusters = _build_clusters(all_vals)
        # 只保留有合并（成员数 > 1 或成员签名 ≠ canonical 签名）的簇进报告
        field_report: dict[str, list[str]] = {}
        for canon, members in clusters.items():
            unique_members = sorted(set(members))
            if len(unique_members) > 1 or (
                unique_members and _signature(unique_members[0]) != _signature(canon)
            ):
                field_report[canon] = unique_members
        if field_report:
            report[field] = field_report

        # 建反查表：原始串 → canonical
        remap: dict[str, str] = {}
        for canon, members in clusters.items():
            for m in members:
                remap[m] = canon

        # 全局重写
        for p in kb.values():
            ed = p.get("extracted_data", {})
            lst = ed.get(field)
            if not isinstance(lst, list):
                continue
            new_lst: list[Any] = []
            seen: set = set()
            for v in lst:
                if isinstance(v, str) and v in remap:
                    canon = remap[v]
                    if canon not in seen:
                        seen.add(canon)
                        new_lst.append(canon)
                else:
                    key = v if isinstance(v, str) else id(v)
                    if key not in seen:
                        seen.add(key)
                        new_lst.append(v)
            ed[field] = new_lst

    return report


# ===================================================================
# 主流程
# ===================================================================

def normalize_kb(kb: dict, cluster_fields: tuple[str, ...]) -> dict:
    """三模块顺序执行：A → B → C。返回报告字典。"""
    renames_log: dict[str, dict[str, str]] = {}
    range_parses: list[dict] = []

    for pid, paper in kb.items():
        ed = paper.get("extracted_data")
        if not isinstance(ed, dict):
            continue
        # A
        consolidate_underscore_keys(pid, ed, renames_log)
        # B
        backfill_numeric_ranges(pid, ed, range_parses)

    # C（需要全局视角，所以放最后）
    string_clusters = cluster_and_rewrite_strings(kb, cluster_fields)

    # 统计
    n_merges = sum(len(v) for v in renames_log.values())
    n_ranges = len(range_parses)
    n_replacements = sum(
        max(0, len(members) - 1)
        for field_map in string_clusters.values()
        for members in field_map.values()
    )

    return {
        "underscore_renames": renames_log,
        "range_parses": range_parses,
        "string_clusters": string_clusters,
        "summary": {
            "papers": len(kb),
            "underscore_merges": n_merges,
            "range_parses": n_ranges,
            "string_replacements": n_replacements,
            "cluster_strategy": "literal_variants_only (case/dash/punct/plural)",
            "clustered_fields": list(cluster_fields),
        },
    }


def _print_report(report: dict, max_samples: int = 20) -> None:
    s = report["summary"]
    print("=" * 60)
    print("Normalization summary")
    print("=" * 60)
    print(f"papers:              {s['papers']}")
    print(f"_ variant merges:    {s['underscore_merges']}")
    print(f"range/value parses:  {s['range_parses']}")
    print(f"string replacements: {s['string_replacements']}")
    print(f"cluster strategy:    {s['cluster_strategy']}")
    print()

    if report["underscore_renames"]:
        print(f"--- _ renames (first {max_samples}) ---")
        flat = [
            (pid, old, new)
            for pid, mp in report["underscore_renames"].items()
            for old, new in mp.items()
        ]
        for pid, old, new in flat[:max_samples]:
            print(f"  {pid}: {old}  →  {new}")
        if len(flat) > max_samples:
            print(f"  ... +{len(flat)-max_samples} more")
        print()

    if report["range_parses"]:
        print(f"--- range/value parses (first {max_samples}) ---")
        for r in report["range_parses"][:max_samples]:
            parsed = {k: v for k, v in r.items() if k in ("value_num", "value_min", "value_max")}
            print(f"  {r['paper']}.{r['field']}: {r['raw']!r}  →  {parsed}")
        if len(report["range_parses"]) > max_samples:
            print(f"  ... +{len(report['range_parses'])-max_samples} more")
        print()

    if report["string_clusters"]:
        print("--- string clusters ---")
        for field, mapping in report["string_clusters"].items():
            merged = {c: m for c, m in mapping.items() if len(m) > 1}
            if not merged:
                continue
            print(f"  [{field}] {len(merged)} clusters with merges:")
            for canon, members in list(merged.items())[:10]:
                others = [m for m in members if m != canon]
                print(f"    {canon!r}  ← {others}")
            if len(merged) > 10:
                print(f"    ... +{len(merged)-10} more")
        print()


# ===================================================================
# Self-test
# ===================================================================

def _self_test() -> bool:
    ok = True

    # --- A: underscore consolidation
    ed = {
        "_sensitivity_tb_spacing": {"value": "non-monotonic", "why_notable": "tb"},
        "_sensitivity_result": {"value": "Base", "why_notable": ""},
        "_mechanism_insight": {"value": "insight A", "why_notable": "why A"},
        "_novel_mechanism_hierarchical_twins": {"value": "hier twins", "why_notable": "notable"},
        "_coarsening_kinetics": {"value": "LSW", "why_notable": "kept as-is"},
    }
    renames: dict = {}
    consolidate_underscore_keys("PX", ed, renames)
    a_ok = (
        "_sensitivity_tb_spacing" not in ed
        and "_sensitivity_result" in ed
        and "Base" in ed["_sensitivity_result"]["value"]
        and "non-monotonic" in ed["_sensitivity_result"]["value"]
        and "_mechanism_insight" not in ed
        and "_novel_mechanism" in ed
        and "_coarsening_kinetics" in ed  # paper-specific unchanged
    )
    print(f"[self-test A] underscore consolidation: {'PASS' if a_ok else 'FAIL'}")
    if not a_ok:
        print("  state:", ed)
        print("  renames:", renames)
    ok &= a_ok

    # --- B: numeric parsing
    cases = [
        ("1.40–7.00 nm", {"value_min": 1.40, "value_max": 7.00}),
        ("17–21 wt.%", {"value_min": 17, "value_max": 21}),
        ("0-50 μm depending on laser power", {"value_min": 0, "value_max": 50}),
        ("305 K/mm at bottom to 85 K/mm at top", {"value_min": 85, "value_max": 305}),
        ("≤0.08 wt.%", {"value_num": 0.08}),
        ("~1580 MPa", {"value_num": 1580}),
        ("1g, 5g, 10g, 15g, 20g", {"value_min": 1, "value_max": 20}),
        ("8 mm diameter, 165 mm long", {"value_num": 8}),
        # 3D 尺寸不应被当作范围：
        ("300 mm long, 100 mm wide, 10 mm high", {"value_num": 300}),
        ("highest at 4.20 nm TB spacing", {}),
        ("Δt = 0.1h²/D", {}),
        ("not quantified in 2D tests", {}),
    ]
    b_ok = True
    for raw, expected in cases:
        got = parse_raw_to_numeric(raw)
        if got != expected:
            b_ok = False
            print(f"  FAIL: {raw!r} → got {got}, expected {expected}")
    print(f"[self-test B] numeric parsing: {'PASS' if b_ok else 'FAIL'}")
    ok &= b_ok

    # --- C: clustering
    kb = {
        "P1": {"extracted_data": {
            "target_response": [
                "competitive grain growth", "dendrite tip position",
                "dislocation-twin interactions",
            ]
        }},
        "P2": {"extracted_data": {
            "target_response": [
                "competitive growth", "Dendrite tip position",
                "dislocation-twin interaction",
            ]
        }},
        "P3": {"extracted_data": {
            "target_response": ["creep rate"]
        }},
    }
    report = cluster_and_rewrite_strings(kb, target_fields=("target_response",))
    c_ok = True
    # "dendrite tip position" 大小写差异 → 应合并
    flat1 = set(kb["P1"]["extracted_data"]["target_response"])
    flat2 = set(kb["P2"]["extracted_data"]["target_response"])
    dendrite_overlap = [v for v in flat1 & flat2 if v.lower() == "dendrite tip position"]
    if len(dendrite_overlap) != 1:
        c_ok = False
        print(f"  FAIL (case merge): P1={flat1} P2={flat2}")
    # plural: "dislocation-twin interaction(s)" 应合并
    dt_overlap = [v for v in flat1 & flat2 if "dislocation" in v]
    if len(dt_overlap) != 1:
        c_ok = False
        print(f"  FAIL (plural merge): P1={flat1} P2={flat2}")
    # 但 "competitive growth" 和 "competitive grain growth" 不应被合并
    if "competitive grain growth" not in flat1 or "competitive growth" not in flat2:
        c_ok = False
        print(f"  FAIL (should-not-merge): P1={flat1} P2={flat2}")
    print(f"[self-test C] clustering: {'PASS' if c_ok else 'FAIL'}")
    ok &= c_ok

    return ok


# ===================================================================
# CLI
# ===================================================================

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--input", type=Path, default=DEFAULT_KB,
                        help="输入 knowledge_base.json 路径（默认 extract_alloy_output4/claude-haiku-4-5-20251001）")
    parser.add_argument("--output", type=Path, default=None,
                        help="输出路径（默认 <input 目录>/knowledge_base.normalized.json）")
    parser.add_argument("--report", type=Path, default=None,
                        help="报告 JSON 路径（默认 <input 目录>/normalize_report.json）")
    parser.add_argument("--cluster-fields", nargs="+", default=list(DEFAULT_CLUSTER_FIELDS),
                        help="需要聚类的字符串数组字段（空格分隔）")
    parser.add_argument("--dry-run", action="store_true",
                        help="不写文件，仅打印报告")
    parser.add_argument("--self-test", action="store_true",
                        help="只跑内置单元测试")
    args = parser.parse_args()

    if args.self_test:
        ok = _self_test()
        return 0 if ok else 1

    inp: Path = args.input
    if not inp.exists():
        print(f"ERROR: input not found: {inp}", file=sys.stderr)
        return 2
    out = args.output or inp.with_name("knowledge_base.normalized.json")
    rep = args.report or inp.with_name("normalize_report.json")

    print(f"[input ] {inp}")
    print(f"[output] {out}")
    print(f"[report] {rep}")
    print()

    with inp.open("r", encoding="utf-8") as f:
        kb = json.load(f)

    report = normalize_kb(kb, cluster_fields=tuple(args.cluster_fields))
    _print_report(report)

    if args.dry_run:
        print("[dry-run] files NOT written.")
        return 0

    with out.open("w", encoding="utf-8") as f:
        json.dump(kb, f, ensure_ascii=False, indent=2)
    with rep.open("w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)

    print(f"[done] wrote {out.name} and {rep.name}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
