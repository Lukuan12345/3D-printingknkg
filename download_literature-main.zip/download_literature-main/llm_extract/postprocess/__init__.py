"""postprocess — 编码修复 + Schema 验证 + 模型分支后处理。

对 extract 结果做完整的后处理管线：
  - fix_encoding()          : 类型归一化 + mojibake 修复 + NFC 规范化
  - postprocess()           : 模型分支后处理（占位符清理、字段重命名、单位规范化等）
  - validate_extraction()   : Schema 白名单 + 字段质量验证
  - patch_all_models()      : 批量修复某个输出目录下所有模型的 knowledge_base.json
  - preprocess_paper_input(): 提取前的输入清洗（在提取阶段前调用）
  - set_schema_csv() / set_domain_family() : 运行时配置注入
"""

from .pipeline import (
    preprocess_paper_input,
    postprocess,
    fix_encoding,
    validate_extraction,
    patch_all_models,
    set_schema_csv,
    set_domain_family,
    set_usage_scope,
)

__all__ = [
    "preprocess_paper_input",
    "postprocess",
    "fix_encoding",
    "validate_extraction",
    "patch_all_models",
    "set_schema_csv",
    "set_domain_family",
    "set_usage_scope",
]
