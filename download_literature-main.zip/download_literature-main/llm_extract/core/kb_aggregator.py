"""kb_aggregator.py — JSONL 提取结果 + metadata → knowledge_base.json。

目标产物完全契合 `server_package/kb_mvp/src/ingest.py` 与
`scientific_kgqa` 的读法：

    {
      "P0001": {
          "paper_id":   "P0001",
          "paper_uid":  "...",
          "paper_title": "...",
          "doi":   "10.xxxx/xxx",
          "year":  1988,
          "journal": "Tribology Transactions",
          "authors": [...],
          "domains": [...],
          "extracted_data": {...},          ← ingest.py 读这里
          "problem_context": "...",         ← 7 大叙述字段（CHUNK_FIELDS）
          "study_process_description": "...",
          "design_method": "...",
          "design_optimization_logic": "...",
          "fabrication_process": "...",
          "physical_mechanism": "...",
          "influence_analysis": "...",
          "references": [...],               ← references_extractor / OpenAlex 合并
          "citation_info": {                 ← extract_paper_meta 读这里
              "merged": {...},
              "sources": {...},
          }
      },
      ...
    }
"""
from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

import orjson

logger = logging.getLogger(__name__)


CHUNK_FIELDS = [
    "problem_context",
    "study_process_description",
    "design_optimization_logic",
    "physical_mechanism",
    "fabrication_process",
    "design_method",
    "influence_analysis",
]


def _iter_jsonl(path: Path):
    if not path.exists():
        return
    with open(path, "rb") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                yield orjson.loads(line)
            except Exception as exc:
                logger.warning("跳过损坏行 %s: %s", path, exc)


def _coerce_str(x: Any) -> str:
    if not x:
        return ""
    if isinstance(x, str):
        return x.strip()
    if isinstance(x, list):
        return "\n".join(str(v).strip() for v in x if v)
    return str(x)


def _merge_metadata(meta: Dict[str, Any], local_refs: List[Dict]) -> Dict[str, Any]:
    """合并 metadata_fetcher 的输出 + references_extractor 的本地解析。"""
    online_refs = list(meta.get("references") or [])
    seen_doi = {(r.get("doi") or "").lower() for r in online_refs if r.get("doi")}
    extra: List[Dict] = []
    for r in local_refs:
        d = (r.get("doi") or "").lower()
        if d and d in seen_doi:
            continue
        extra.append({
            "title": r.get("title") or r.get("raw"),
            "year": r.get("year"),
            "doi": d or None,
            "source": "local_md",
        })

    sources = dict(meta.get("sources") or {})
    # 把 refs/cites 还原回 sources，下游 utils.extract_citation_links 期望从这里读
    if "openalex" in sources and sources["openalex"].get("matched"):
        sources["openalex"] = {**sources["openalex"], "references": online_refs,
                               "citations": meta.get("citations") or []}
    if "semanticscholar" in sources and sources["semanticscholar"].get("matched"):
        sources["semanticscholar"] = {**sources["semanticscholar"],
                                       "references": online_refs,
                                       "citations": meta.get("citations") or []}

    citation_info = {
        "merged": meta.get("merged") or {},
        "sources": sources,
    }
    return citation_info, online_refs + extra


def build_knowledge_base(
    results_jsonl: Path,
    output_path: Path,
    metadata_jsonl: Optional[Path] = None,
    local_refs_jsonl: Optional[Path] = None,
    paper_id_prefix: str = "P",
) -> Dict[str, Any]:
    """聚合 JSONL → knowledge_base.json。"""
    # 1) 读 metadata + local refs（按 paper_uid 索引）
    metadata: Dict[str, Dict] = {}
    if metadata_jsonl and metadata_jsonl.exists():
        for rec in _iter_jsonl(metadata_jsonl):
            uid = rec.get("paper_uid")
            if uid:
                metadata[uid] = rec

    local_refs_map: Dict[str, List[Dict]] = {}
    if local_refs_jsonl and local_refs_jsonl.exists():
        for rec in _iter_jsonl(local_refs_jsonl):
            uid = rec.get("paper_uid")
            if uid:
                local_refs_map[uid] = rec.get("references") or []

    # 2) 遍历提取结果，按 paper_uid 去重（多模型仅取首条）
    seen_uids: set = set()
    kb: Dict[str, Dict] = {}
    idx = 1
    for rec in _iter_jsonl(results_jsonl):
        uid = rec.get("paper_uid")
        if not uid or uid in seen_uids:
            continue
        seen_uids.add(uid)

        paper_id = f"{paper_id_prefix}{idx:04d}"
        idx += 1

        mech = rec.get("mechanism") or {}
        if not isinstance(mech, dict):
            mech = {}
        ed = mech.get("extracted_data") or {}
        if not isinstance(ed, dict):
            ed = {}

        domains = rec.get("domains") or []
        source = rec.get("source") or {}
        title = rec.get("title", "")

        meta_rec = metadata.get(uid, {})
        merged = (meta_rec.get("merged") or {}) if meta_rec else {}
        doi = merged.get("doi") or (source.get("doi") if isinstance(source, dict) else None)
        year = merged.get("year") or (source.get("year") if isinstance(source, dict) else None)
        journal = merged.get("venue") or (
            source.get("journal") if isinstance(source, dict) else None
        )
        authors = merged.get("authors") or []

        local_refs = local_refs_map.get(uid, [])
        citation_info, references = _merge_metadata(meta_rec, local_refs) if meta_rec \
            else ({"merged": {"doi": doi, "year": year, "title": title,
                              "authors": authors, "venue": journal,
                              "matched_sources": []},
                   "sources": {}},
                  [{"title": r.get("title") or r.get("raw"),
                    "year": r.get("year"),
                    "doi": (r.get("doi") or "").lower() or None,
                    "source": "local_md"}
                   for r in local_refs])

        paper_obj: Dict[str, Any] = {
            "paper_id": paper_id,
            "paper_uid": uid,
            "paper_title": title,
            "title": title,
            "doi": doi,
            "year": year,
            "journal": journal,
            "authors": authors,
            "domains": domains,
            "extracted_data": ed,
            "references": references,
            "citation_info": citation_info,
            "source": source,
        }
        for fld in CHUNK_FIELDS:
            paper_obj[fld] = _coerce_str(mech.get(fld, ""))

        kb[paper_id] = paper_obj

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        json.dumps(kb, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    logger.info("knowledge_base.json 写入 %d 篇 → %s", len(kb), output_path)
    return kb
