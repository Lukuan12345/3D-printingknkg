"""jsonl_writer.py — 后台 JSONL 流式 writer，用 asyncio.Queue 解耦生产/消费。

设计：
  - 单独一个 writer task 消费 queue，避免协程并发写文件。
  - orjson 序列化（比 json.dumps 快 ~3x）。
  - 通过 sentinel(None) 通知收尾。
  - flush 间隔可控（默认每 50 行 flush 一次），保证崩溃时丢失最少。
"""
from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import Any, Optional

import orjson

logger = logging.getLogger(__name__)

_FLUSH_INTERVAL = 50  # 每 N 行 flush 一次


class JsonlWriter:
    """后台 writer 协程；多个生产者通过 put() 投递，单消费者落盘。"""

    def __init__(self, path: Path, maxsize: int = 200):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._q: asyncio.Queue = asyncio.Queue(maxsize=maxsize)
        self._task: Optional[asyncio.Task] = None
        self._written = 0

    async def __aenter__(self):
        self._task = asyncio.create_task(self._run())
        return self

    async def __aexit__(self, exc_type, exc, tb):
        await self._q.put(None)  # sentinel
        if self._task:
            await self._task

    async def put(self, record: Any):
        await self._q.put(record)

    @property
    def written(self) -> int:
        return self._written

    async def _run(self):
        # append 模式打开（断点续跑时不覆盖）
        loop = asyncio.get_running_loop()
        f = await loop.run_in_executor(None, lambda: open(self.path, "ab"))
        try:
            buf = 0
            while True:
                rec = await self._q.get()
                if rec is None:
                    break
                line = orjson.dumps(rec, option=orjson.OPT_NON_STR_KEYS)
                await loop.run_in_executor(None, f.write, line + b"\n")
                buf += 1
                self._written += 1
                if buf >= _FLUSH_INTERVAL:
                    await loop.run_in_executor(None, f.flush)
                    buf = 0
            await loop.run_in_executor(None, f.flush)
        finally:
            await loop.run_in_executor(None, f.close)
            logger.info("JsonlWriter 关闭: %s (written=%d)", self.path, self._written)
