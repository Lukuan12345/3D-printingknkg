"""config_loader.py — YAML 配置加载。"""
from __future__ import annotations

import os
import logging
from pathlib import Path
from typing import Any, Dict, Optional

import yaml

logger = logging.getLogger(__name__)


def load_yaml(path: str) -> Dict[str, Any]:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"配置文件不存在: {p}")
    with open(p, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def resolve_llm_settings(config: Dict[str, Any]) -> Dict[str, str]:
    llm = config.get("llm", {}) or {}
    base_url = llm.get("base_url") or os.environ.get("LLM_BASE_URL", "")
    api_key = llm.get("api_key") or os.environ.get("LLM_API_KEY", "")
    if not base_url or not api_key:
        raise ValueError(
            "LLM base_url / api_key 未配置（YAML 也没有，环境变量 LLM_BASE_URL/LLM_API_KEY 也没有）"
        )
    return {"base_url": base_url.rstrip("/"), "api_key": api_key}


def resolve_schema_settings(
    config: Dict[str, Any], config_path: str, default_schema: Optional[str] = None
) -> Dict[str, Any]:
    schema_cfg = config.get("schema", {}) or {}
    path = schema_cfg.get("path") or default_schema
    if path and not Path(path).is_absolute():
        path = str((Path(config_path).parent / path).resolve())

    key_focus = schema_cfg.get("key_focus")
    if key_focus and isinstance(key_focus, str):
        looks_like_path = (
            "/" in key_focus or "\\" in key_focus
            or key_focus.endswith((".txt", ".md", ".py"))
        )
        if looks_like_path and not Path(key_focus).is_absolute():
            key_focus = str((Path(config_path).parent / key_focus).resolve())

    domain_prefer_file = schema_cfg.get("domain_prefer_file")
    if domain_prefer_file and not Path(domain_prefer_file).is_absolute():
        domain_prefer_file = str(
            (Path(config_path).parent / domain_prefer_file).resolve()
        )

    return {
        "path": path,
        "domain_family": schema_cfg.get("domain_family"),
        "usage_scope": schema_cfg.get("usage_scope"),
        "key_focus": key_focus,
        "domain_prefer_file": domain_prefer_file,
    }


def validate_data_sources(config: Dict[str, Any]) -> list:
    sources = config.get("data_sources", [])
    if not sources:
        raise ValueError("data_sources 为空")
    for src in sources:
        if "type" not in src or "path" not in src:
            raise ValueError(f"data_source 缺少 type/path: {src}")
        if src["type"] not in ("md_dir", "jsonl"):
            raise ValueError(f"不支持的 type: {src['type']}")
    return sources
