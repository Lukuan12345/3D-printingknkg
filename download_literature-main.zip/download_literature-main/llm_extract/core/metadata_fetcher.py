"""metadata_fetcher.py — 异步元数据抓取（按 DOI / title 查 OpenAlex + S2）。

  - 单进程 httpx.AsyncClient(http2=True) + TokenBucket 限流
  - 仅返回 citation_info dict 供 aggregator 写入
    knowledge_base.json，与 scientific_kgqa.utils.extract_paper_meta 的
    读法保持兼容

环境变量优先级：
  S2_API_KEY        — 有则 80 req/s，无则 1 req/s
  OPENALEX_MAILTO   — polite pool 入场券
"""
from __future__ import annotations

import asyncio
import logging
import os
import re
import time
from datetime import datetime
from typing import Any, Dict, List, Optional

import httpx

logger = logging.getLogger(__name__)


CITATIONS_CAP = 200
OA_BATCH = 50
S2_PAGE = 100
HTTP_TIMEOUT = 30.0
HTTP_CONNECT_TIMEOUT = 15.0


class TokenBucket:
    def __init__(self, rate: float, capacity: Optional[int] = None):
        self.rate = float(rate)
        self.capacity = float(capacity if capacity else max(1, int(rate)))
        self.tokens = self.capacity
        self.last = time.monotonic()
        self.lock = asyncio.Lock()

    async def acquire(self, n: float = 1.0):
        async with self.lock:
            now = time.monotonic()
            self.tokens = min(self.capacity, self.tokens + (now - self.last) * self.rate)
            self.last = now
            if self.tokens < n:
                wait = (n - self.tokens) / self.rate
                await asyncio.sleep(wait)
                self.last = time.monotonic()
                self.tokens = 0.0
            else:
                self.tokens -= n


def _norm_text(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", (s or "").lower()).strip()


def _title_match(a: str, b: str, jaccard: float = 0.7) -> bool:
    na, nb = _norm_text(a), _norm_text(b)
    if not na or not nb:
        return False
    if na == nb or na in nb or nb in na:
        return True
    ta, tb = set(na.split()), set(nb.split())
    if not ta or not tb:
        return False
    return len(ta & tb) / len(ta | tb) >= jaccard


def _strip_doi(doi: Optional[str]) -> Optional[str]:
    if not doi:
        return None
    return (doi.replace("https://doi.org/", "")
                .replace("http://doi.org/", "")
                .lower()
                .strip() or None)


def _strip_oa_id(uri: Optional[str]) -> Optional[str]:
    if not uri:
        return None
    return uri.rsplit("/", 1)[-1]


def _oa_item(w: Dict) -> Dict:
    return {
        "title": w.get("title") or w.get("display_name"),
        "year": w.get("publication_year"),
        "doi": _strip_doi(w.get("doi")),
    }


def _s2_item(p: Dict) -> Dict:
    ext = p.get("externalIds") or {}
    doi = ext.get("DOI")
    return {
        "title": p.get("title"),
        "year": p.get("year"),
        "doi": (doi or "").lower() or None,
    }


def _dedup_papers(items: List[Dict]) -> List[Dict]:
    seen_doi: set = set()
    seen_title: set = set()
    out: List[Dict] = []
    for it in items:
        if not isinstance(it, dict):
            continue
        d = (it.get("doi") or "").lower()
        if d:
            if d in seen_doi:
                continue
            seen_doi.add(d)
            out.append(it)
            continue
        t = _norm_text(it.get("title") or "")
        if not t or t in seen_title:
            continue
        seen_title.add(t)
        out.append(it)
    return out


class MetadataFetcher:
    def __init__(
        self,
        s2_api_key: Optional[str] = None,
        mailto: Optional[str] = None,
        openalex_rate: float = 8.0,
        s2_rate: Optional[float] = None,
        citations_cap: int = CITATIONS_CAP,
        skip_s2: bool = False,
    ):
        self.s2_api_key = s2_api_key or os.environ.get("S2_API_KEY")
        self.mailto = (mailto
                       or os.environ.get("OPENALEX_MAILTO")
                       or os.environ.get("CROSSREF_MAILTO")
                       or "")
        self.skip_s2 = bool(skip_s2)
        if s2_rate is None:
            s2_rate = 80.0 if self.s2_api_key else 1.0
        self.oa_bucket = TokenBucket(openalex_rate, int(openalex_rate * 2))
        self.s2_bucket = TokenBucket(s2_rate, max(2, int(s2_rate * 2)))
        self.citations_cap = citations_cap

        ua = "llm-extract-mvp/0.1"
        if self.mailto:
            ua += f" (mailto:{self.mailto})"
        self._ua = ua
        self._client: Optional[httpx.AsyncClient] = None

    async def __aenter__(self):
        self._client = httpx.AsyncClient(
            http2=True,
            timeout=httpx.Timeout(HTTP_TIMEOUT, connect=HTTP_CONNECT_TIMEOUT),
            limits=httpx.Limits(max_connections=64, max_keepalive_connections=32),
            headers={"User-Agent": self._ua, "Accept": "application/json"},
        )
        logger.info("MetadataFetcher 启动: S2=%s mailto=%s",
                    "skipped" if self.skip_s2 else ("key" if self.s2_api_key else "anon"),
                    self.mailto or "(none)")
        return self

    async def __aexit__(self, exc_type, exc, tb):
        if self._client:
            await self._client.aclose()
            self._client = None

    async def _get_json(
        self, url: str, params: Optional[Dict] = None,
        bucket: Optional[TokenBucket] = None,
        extra_headers: Optional[Dict] = None,
        max_retries: int = 4,
    ) -> Optional[Dict]:
        assert self._client is not None
        for attempt in range(max_retries):
            if bucket:
                await bucket.acquire()
            try:
                r = await self._client.get(url, params=params, headers=extra_headers)
            except (httpx.TimeoutException, httpx.NetworkError) as e:
                logger.debug("network %s: %s", url, e)
                await asyncio.sleep(min(15, 2 ** attempt))
                continue
            if r.status_code == 200:
                try:
                    return r.json()
                except Exception:
                    return None
            if r.status_code == 404:
                return None
            if r.status_code == 429:
                retry_after = r.headers.get("Retry-After") or r.headers.get("retry-after")
                try:
                    wait = float(retry_after) if retry_after else None
                except ValueError:
                    wait = None
                wait = min(120, wait or 5 * (2 ** attempt))
                logger.warning("429 on %s (attempt %d/%d), sleep %.1fs",
                               url, attempt + 1, max_retries, wait)
                await asyncio.sleep(wait)
                continue
            if r.status_code in (401, 403):
                logger.error("auth error %d on %s: %s", r.status_code, url, r.text[:200])
                return None
            if r.status_code >= 500:
                await asyncio.sleep(min(30, 3 * (attempt + 1)))
                continue
            logger.warning("HTTP %d %s: %s", r.status_code, url, r.text[:200])
            return None
        return None

    # ---------- OpenAlex ----------

    def _oa_params(self, extra: Optional[Dict] = None) -> Dict:
        p = dict(extra or {})
        if self.mailto:
            p["mailto"] = self.mailto
        return p

    async def openalex_lookup_by_doi(self, doi: str) -> Optional[Dict]:
        return await self._get_json(
            f"https://api.openalex.org/works/doi:{doi}",
            params=self._oa_params(), bucket=self.oa_bucket,
        )

    async def openalex_search_by_title(self, title: str) -> Optional[Dict]:
        data = await self._get_json(
            "https://api.openalex.org/works",
            params=self._oa_params({"search": title, "per-page": 5}),
            bucket=self.oa_bucket,
        )
        if not data or not data.get("results"):
            return None
        for w in data["results"]:
            if _title_match(title, w.get("title") or w.get("display_name") or ""):
                return w
        return data["results"][0]

    async def openalex_fetch_works_by_ids(self, ids: List[str]) -> List[Dict]:
        out: List[Dict] = []
        for i in range(0, len(ids), OA_BATCH):
            chunk = ids[i:i + OA_BATCH]
            data = await self._get_json(
                "https://api.openalex.org/works",
                params=self._oa_params({
                    "filter": "openalex:" + "|".join(chunk),
                    "per-page": OA_BATCH,
                    "select": "id,title,display_name,doi,publication_year",
                }),
                bucket=self.oa_bucket,
            )
            if not data:
                continue
            for w in data.get("results") or []:
                out.append(_oa_item(w))
        return out

    async def openalex_fetch_citations(self, work_id: str, cap: int) -> List[Dict]:
        out: List[Dict] = []
        cursor = "*"
        while len(out) < cap:
            per_page = min(200, cap - len(out))
            data = await self._get_json(
                "https://api.openalex.org/works",
                params=self._oa_params({
                    "filter": f"cites:{work_id}",
                    "per-page": per_page, "cursor": cursor,
                    "select": "id,title,display_name,doi,publication_year",
                }),
                bucket=self.oa_bucket,
            )
            if not data:
                break
            results = data.get("results") or []
            if not results:
                break
            for w in results:
                out.append(_oa_item(w))
                if len(out) >= cap:
                    break
            cursor = (data.get("meta") or {}).get("next_cursor")
            if not cursor:
                break
        return out

    async def query_openalex(self, title: str, doi: Optional[str]) -> Dict:
        res: Dict = {
            "source": "openalex", "matched": False, "lookup": None,
            "id": None, "title": None, "doi": None, "year": None,
            "authors": [], "venue": None,
            "references": [], "citations": [],
        }
        work: Optional[Dict] = None
        if doi:
            work = await self.openalex_lookup_by_doi(doi)
            if work:
                res["lookup"] = "doi"; res["matched"] = True
        if not work and title:
            work = await self.openalex_search_by_title(title)
            if work:
                res["lookup"] = "title"
                res["matched"] = _title_match(
                    title, work.get("title") or work.get("display_name") or ""
                )
        if not work:
            return res

        res["id"] = _strip_oa_id(work.get("id"))
        res["title"] = work.get("title") or work.get("display_name")
        res["doi"] = _strip_doi(work.get("doi"))
        res["year"] = work.get("publication_year")
        authorships = work.get("authorships") or []
        res["authors"] = [
            (a.get("author") or {}).get("display_name") for a in authorships[:50]
            if (a.get("author") or {}).get("display_name")
        ]
        primary_loc = work.get("primary_location") or {}
        source_obj = primary_loc.get("source") or {}
        res["venue"] = source_obj.get("display_name")

        ref_ids = [x for x in (_strip_oa_id(u) for u in (work.get("referenced_works") or []))
                   if x]
        if ref_ids:
            res["references"] = await self.openalex_fetch_works_by_ids(ref_ids)
        if res["id"]:
            res["citations"] = await self.openalex_fetch_citations(
                res["id"], self.citations_cap
            )
        return res

    # ---------- Semantic Scholar ----------

    def _s2_headers(self) -> Dict:
        return {"x-api-key": self.s2_api_key} if self.s2_api_key else {}

    async def s2_lookup_by_doi(self, doi: str) -> Optional[Dict]:
        return await self._get_json(
            f"https://api.semanticscholar.org/graph/v1/paper/DOI:{doi}",
            params={"fields": "title,year,citationCount,externalIds,authors,venue"},
            extra_headers=self._s2_headers(), bucket=self.s2_bucket,
        )

    async def s2_search_by_title(self, title: str) -> Optional[Dict]:
        data = await self._get_json(
            "https://api.semanticscholar.org/graph/v1/paper/search",
            params={
                "query": title, "limit": 5,
                "fields": "title,year,citationCount,externalIds,authors,venue",
            },
            extra_headers=self._s2_headers(), bucket=self.s2_bucket,
        )
        if not data or not data.get("data"):
            return None
        for p in data["data"]:
            if _title_match(title, p.get("title") or ""):
                return p
        return data["data"][0]

    async def s2_paginate(self, endpoint: str, paper_id: str,
                          cap: Optional[int]) -> List[Dict]:
        out: List[Dict] = []
        offset = 0
        while True:
            if cap is not None:
                remaining = cap - len(out)
                if remaining <= 0:
                    break
                limit = min(S2_PAGE, remaining)
            else:
                limit = S2_PAGE
            data = await self._get_json(
                f"https://api.semanticscholar.org/graph/v1/paper/{paper_id}/{endpoint}",
                params={"fields": "title,year,externalIds",
                        "limit": limit, "offset": offset},
                extra_headers=self._s2_headers(), bucket=self.s2_bucket,
            )
            if not data:
                break
            items = data.get("data") or []
            if not items:
                break
            for it in items:
                inner = it.get("citedPaper") or it.get("citingPaper") or it
                out.append(_s2_item(inner))
                if cap is not None and len(out) >= cap:
                    break
            if "next" not in data:
                break
            offset = data["next"]
        return out

    async def query_semanticscholar(self, title: str, doi: Optional[str]) -> Dict:
        res: Dict = {
            "source": "semanticscholar", "matched": False, "lookup": None,
            "paperId": None, "title": None, "doi": None, "year": None,
            "authors": [], "venue": None,
            "references": [], "citations": [],
        }
        paper: Optional[Dict] = None
        if doi:
            paper = await self.s2_lookup_by_doi(doi)
            if paper:
                res["lookup"] = "doi"; res["matched"] = True
        if not paper and title:
            paper = await self.s2_search_by_title(title)
            if paper:
                res["lookup"] = "title"
                res["matched"] = _title_match(title, paper.get("title") or "")
        if not paper:
            return res

        res["paperId"] = paper.get("paperId")
        res["title"] = paper.get("title")
        ext = paper.get("externalIds") or {}
        res["doi"] = (ext.get("DOI") or "").lower() or None
        res["year"] = paper.get("year")
        authors = paper.get("authors") or []
        res["authors"] = [a.get("name") for a in authors[:50] if a.get("name")]
        venue = paper.get("venue")
        if isinstance(venue, dict):
            venue = venue.get("name")
        res["venue"] = venue or None

        if res["paperId"]:
            res["references"] = await self.s2_paginate(
                "references", res["paperId"], cap=None,
            )
            res["citations"] = await self.s2_paginate(
                "citations", res["paperId"], cap=self.citations_cap,
            )
        return res

    # ---------- 单篇 ----------

    async def fetch_one(self, paper_uid: str, title: str,
                        doi_hint: Optional[str] = None) -> Dict:
        title = (title or "").strip()
        doi = _strip_doi(doi_hint)

        if self.skip_s2:
            try:
                oa = await self.query_openalex(title, doi)
            except Exception as exc:
                logger.warning("[%s] OpenAlex 异常: %s", paper_uid, exc)
                oa = self._empty_source("openalex")
            s2 = self._empty_source("semanticscholar")
        else:
            oa, s2 = await asyncio.gather(
                self.query_openalex(title, doi),
                self.query_semanticscholar(title, doi),
                return_exceptions=True,
            )
            if isinstance(oa, Exception):
                logger.warning("[%s] OpenAlex 异常: %s", paper_uid, oa)
                oa = self._empty_source("openalex")
            if isinstance(s2, Exception):
                logger.warning("[%s] S2 异常: %s", paper_uid, s2)
                s2 = self._empty_source("semanticscholar")

        return self._merge(paper_uid, title, doi, {"openalex": oa, "semanticscholar": s2})

    @staticmethod
    def _empty_source(name: str) -> Dict:
        return {
            "source": name, "matched": False, "lookup": None,
            "id": None, "paperId": None, "title": None, "doi": None,
            "year": None, "authors": [], "venue": None,
            "references": [], "citations": [],
        }

    @staticmethod
    def _merge(paper_uid: str, title: str, doi_hint: Optional[str],
               sources: Dict[str, Dict]) -> Dict:
        matched = [s for s in sources.values() if s.get("matched")]
        pool = matched + [s for s in sources.values() if not s.get("matched")]

        doi = doi_hint
        if not doi:
            for s in pool:
                if s.get("doi"):
                    doi = s["doi"]; break

        year = next((s["year"] for s in pool if s.get("year")), None)
        title_canon = next((s["title"] for s in pool if s.get("title")), title)
        authors = next((s["authors"] for s in pool if s.get("authors")), [])
        venue = next((s["venue"] for s in pool if s.get("venue")), None)

        merged_refs = _dedup_papers(
            (sources.get("openalex", {}).get("references") or []) +
            (sources.get("semanticscholar", {}).get("references") or [])
        )
        merged_cites = _dedup_papers(
            (sources.get("openalex", {}).get("citations") or []) +
            (sources.get("semanticscholar", {}).get("citations") or [])
        )

        # 与 scientific_kgqa.utils.extract_paper_meta 期望的 schema 对齐
        merged = {
            "doi": doi,
            "year": year,
            "title": title_canon,
            "authors": authors,
            "venue": venue,
            "references_count": {k: len(v.get("references") or [])
                                 for k, v in sources.items()},
            "citations_count": {k: len(v.get("citations") or [])
                                for k, v in sources.items()},
            "matched_sources": [s["source"] for s in matched],
        }
        return {
            "paper_uid": paper_uid,
            "merged": merged,
            "sources": {
                "openalex": {**sources["openalex"], "references": [], "citations": []},
                "semanticscholar": {**sources["semanticscholar"], "references": [], "citations": []},
            },
            # 把 refs/cites 单独放外层，避免 sources 过大
            "references": merged_refs,
            "citations": merged_cites,
            "fetched_at": datetime.utcnow().isoformat() + "Z",
        }
