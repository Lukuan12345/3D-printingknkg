"""references_extractor.py — 从已解析文件夹里抽 references。

输入：年份-期刊-DOI 命名的目录，目录下含
  - `full.md` （markdown 化的全文，REFERENCES 段在末尾）
  - `*_content_list.json` 或 `*_content_list_v2.json`（PDF 结构化块）

输出：每条 reference 的最小元数据 dict
  {
    "raw":   "...",                # 原文引用串
    "index": "[1]" 或 "(1)" 等,    # 论文内编号（可为空）
    "title": Optional[str],
    "authors": Optional[List[str]],
    "year":  Optional[int],
    "doi":   Optional[str],
    "venue": Optional[str],
  }

策略（无 LLM、纯正则）：
  1. 取 full.md 最后一个 `# REFERENCES` / `## References` 段；
     找不到时回退到 content_list*.json 中 `text_level==1` 的 References 段。
  2. 按编号 `[1] / (1) / 1.` 或 paragraph 切条。
  3. 每条用宽松启发式抽出 year / doi / title / authors / venue。
"""
from __future__ import annotations

import json
import logging
import re
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


_REF_HEADING_RE = re.compile(
    r"(?:^|\n)\s*#{1,3}\s*(references|reference|bibliography|参考文献)\b\s*\n",
    re.IGNORECASE,
)
_ACK_TAIL_RE = re.compile(
    r"\n\s*#{1,3}\s*(appendix|acknowledg(?:e?ment)?s?|supplementary)\b",
    re.IGNORECASE,
)
_DOI_RE = re.compile(
    r"\b10\.\d{3,9}/[^\s,;)\]]+",
    re.IGNORECASE,
)
_YEAR_RE = re.compile(r"\b(19|20)\d{2}\b")
_REF_INDEX_RE = re.compile(r"^\s*(?:\[(\d{1,4})\]|\((\d{1,4})\)|(\d{1,4})\.)\s+")
_AUTHORS_LEAD_RE = re.compile(
    r"^([A-Z][^.,\n]{0,80}?(?:,\s*[A-Z][^.,\n]{0,80}?){0,8})\s*[.,]"
)


def _grab_references_block(md_text: str) -> Optional[str]:
    """取 markdown 中最后一个 REFERENCES 段落（到下一个 H1/H2 或 Acknowledgement 为止）。"""
    matches = list(_REF_HEADING_RE.finditer(md_text))
    if not matches:
        return None
    start = matches[-1].end()
    tail = md_text[start:]
    # cut at next H1/H2 if present
    next_head = re.search(r"\n#{1,3}\s+\S", tail)
    if next_head:
        tail = tail[: next_head.start()]
    ack = _ACK_TAIL_RE.search(tail)
    if ack:
        tail = tail[: ack.start()]
    return tail.strip() or None


def _grab_references_block_from_content_list(items: list) -> Optional[str]:
    seen_ref_header = False
    captured: List[str] = []
    for it in items:
        if not isinstance(it, dict):
            continue
        text = (it.get("text") or "").strip()
        if not text:
            continue
        if not seen_ref_header:
            if it.get("text_level") == 1 and text.lower().startswith(
                ("reference", "bibliography", "参考文献")
            ):
                seen_ref_header = True
            continue
        if it.get("text_level") == 1:
            # next top-level heading after REFERENCES → stop
            break
        captured.append(text)
    if not captured:
        return None
    return "\n".join(captured)


def _split_into_entries(block: str) -> List[str]:
    """按编号切条；找不到编号则按段落切。"""
    lines = [ln.rstrip() for ln in block.splitlines()]
    entries: List[str] = []
    cur: List[str] = []
    for ln in lines:
        if _REF_INDEX_RE.match(ln):
            if cur:
                entries.append(" ".join(cur).strip())
                cur = []
            cur.append(ln)
        elif ln.strip():
            cur.append(ln)
        else:
            if cur:
                entries.append(" ".join(cur).strip())
                cur = []
    if cur:
        entries.append(" ".join(cur).strip())
    # 编号切法没切出多条 → 退化为段落切
    if len(entries) <= 1:
        entries = [p.strip() for p in re.split(r"\n\s*\n+", block) if p.strip()]
    return entries


def _strip_index(entry: str) -> tuple[str, str]:
    """返回 (index_label, body)。"""
    m = _REF_INDEX_RE.match(entry)
    if not m:
        return "", entry.strip()
    idx_num = m.group(1) or m.group(2) or m.group(3)
    return f"[{idx_num}]", entry[m.end():].strip()


def _parse_one(entry: str) -> Optional[Dict[str, Any]]:
    entry = entry.strip()
    if len(entry) < 8:
        return None
    idx, body = _strip_index(entry)

    doi = None
    dm = _DOI_RE.search(body)
    if dm:
        doi = dm.group(0).rstrip(".,;)")

    year = None
    ym = _YEAR_RE.search(body)
    if ym:
        try:
            year = int(ym.group(0))
        except ValueError:
            year = None

    authors: List[str] = []
    am = _AUTHORS_LEAD_RE.match(body)
    if am:
        authors_raw = am.group(1)
        authors = [a.strip() for a in re.split(r",\s*", authors_raw) if a.strip()]

    # title heuristic: 第一个被引号或斜体包裹的子串；否则取 authors 之后到 year 之前
    title = None
    qm = re.search(r"[\"“]([^\"”]{8,250})[\"”]", body)
    if qm:
        title = qm.group(1).strip()
    elif am and ym:
        between = body[am.end():ym.start()].strip(" .,()")
        if 8 < len(between) < 300:
            title = between

    venue = None
    if ym:
        after_year = body[ym.end():].strip(" ,.()")
        # venue 常在 year 之前的最后一段 italic 串里；这里只做兜底
        vm = re.search(r"([A-Z][A-Za-z .&\-]{3,80})(?:,|\s+\d|\s*\.)", after_year)
        if vm:
            venue = vm.group(1).strip(" ,.")

    return {
        "raw": body,
        "index": idx,
        "title": title,
        "authors": authors,
        "year": year,
        "doi": doi.lower() if doi else None,
        "venue": venue,
    }


def extract_references_from_dir(paper_dir: Path,
                                content_text: Optional[str] = None,
                                ) -> List[Dict[str, Any]]:
    """从解析后的文件夹里抽 references；调用方应传入 `full.md` 的文本（如已读过则复用）。"""
    md_text = content_text
    if md_text is None:
        md_path = paper_dir / "full.md"
        if md_path.exists():
            try:
                md_text = md_path.read_text(encoding="utf-8")
            except Exception as exc:
                logger.warning("读取 full.md 失败 %s: %s", md_path, exc)
                md_text = None

    block: Optional[str] = None
    if md_text:
        block = _grab_references_block(md_text)

    if not block:
        for cand in sorted(paper_dir.glob("*content_list*.json")):
            try:
                items = json.loads(cand.read_text(encoding="utf-8"))
            except Exception as exc:
                logger.debug("解析 %s 失败: %s", cand, exc)
                continue
            if isinstance(items, list):
                block = _grab_references_block_from_content_list(items)
                if block:
                    break

    if not block:
        return []

    out: List[Dict[str, Any]] = []
    for entry in _split_into_entries(block):
        parsed = _parse_one(entry)
        if parsed:
            out.append(parsed)
    return out
