"""schema_loader.py — refined_schema CSV 解析 + 按论文域筛选子集。
"""
from __future__ import annotations

import csv
import logging
import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


_COL_NAME_EN = "字段名（英文）"
_COL_NAME_CN = "字段名（中文）"
_COL_DESC = "完整描述"
_COL_LEVEL = "层级"
_COL_HINT = "提取提示"
_COL_DOMAINS = "适用领域"
_COL_USAGE = "使用范围"

LEVEL_HEADERS = {
    "Level 1": "### 1. Problem Definition & Physical Framework Material",
    "Level 2": "### 2. Study Variables Material",
    "Level 3": "### 3. Targets and Evaluation Metrics Material",
    "Level 4": "### 4. Design Logic and Optimization Material",
}

LEVEL_TO_ROLE = {
    "Level 1": "context",
    "Level 2": "variable",
    "Level 3": "target",
    "Level 4": "mechanism",
}


def _read_rows(schema_csv: str) -> List[Dict]:
    p = Path(schema_csv)
    if p.suffix.lower() in (".xlsx", ".xls"):
        import pandas as pd
        df = pd.read_excel(schema_csv)
        return df.to_dict(orient="records")
    with open(schema_csv, mode="r", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def build_schema_subsets(
    schema_csv: str,
    valid_domains: set,
    usage_scope: Optional[str] = None,
) -> Dict[str, List[Tuple[str, set]]]:
    """
    按 Level 分组，每行返回 (formatted_line, applicable_domains)。
    供后续 filter_schema_for_domains 按论文域筛选。
    """
    rows_by_level: Dict[str, List[Tuple[str, set]]] = {
        "Level 1": [], "Level 2": [], "Level 3": [], "Level 4": [],
    }
    skipped_by_scope = 0

    for row in _read_rows(schema_csv):
        field_en = str(row.get(_COL_NAME_EN, "")).strip()
        if not field_en:
            continue

        if usage_scope:
            row_scope = str(row.get(_COL_USAGE, "")).strip()
            if row_scope and row_scope != "nan" and row_scope != usage_scope:
                skipped_by_scope += 1
                continue

        field_cn = str(row.get(_COL_NAME_CN, "")).strip()
        desc = str(row.get(_COL_DESC, "")).strip()
        level = str(row.get(_COL_LEVEL, "")).strip()
        hint = str(row.get(_COL_HINT, "")).strip()
        domains_str = str(row.get(_COL_DOMAINS, "")).strip()

        field_domains: set = set()
        if domains_str and domains_str != "nan":
            for d in re.split(r"[,，\s]+", domains_str):
                d = d.strip()
                if d in valid_domains:
                    field_domains.add(d)

        line = f"- **{field_en}** ({field_cn}): {desc}"
        if hint and hint != "nan":
            line += f" [提示: {hint}]"
        if level and level != "nan":
            line += f" [层级: {level}]"

        for lv in rows_by_level:
            if lv in level:
                rows_by_level[lv].append((line, field_domains))
                break

    total = sum(len(v) for v in rows_by_level.values())
    if usage_scope:
        logger.info("Schema 加载 %d 字段 (usage_scope=%s, 跳过 %d)",
                    total, usage_scope, skipped_by_scope)
    else:
        logger.info("Schema 加载 %d 字段 (全量)", total)
    return rows_by_level


def filter_schema_for_domains(
    rows_by_level: Dict[str, List[Tuple[str, set]]],
    paper_domains: List[str],
) -> Tuple[str, str, str, str]:
    """按论文域筛选 4 段 schema 文本（Level 1~4）。
    paper_domains 为空时返回全量（兜底）。"""
    paper_set = set(paper_domains)
    use_full = len(paper_set) == 0

    texts: Dict[str, str] = {}
    for lv in ("Level 1", "Level 2", "Level 3", "Level 4"):
        lines = []
        for line, field_domains in rows_by_level.get(lv, []):
            if use_full or not field_domains or (field_domains & paper_set):
                lines.append(line)
        texts[lv] = LEVEL_HEADERS[lv] + "\n" + "\n".join(lines)
    return texts["Level 1"], texts["Level 2"], texts["Level 3"], texts["Level 4"]


def field_role_index(schema_csv: str) -> Dict[str, str]:
    """生成 {field_en: role}（context/variable/target/mechanism），用于 mentions 长表标注 role。"""
    role_index: Dict[str, str] = {}
    for row in _read_rows(schema_csv):
        field_en = str(row.get(_COL_NAME_EN, "")).strip()
        level = str(row.get(_COL_LEVEL, "")).strip()
        if not field_en:
            continue
        for lv, role in LEVEL_TO_ROLE.items():
            if lv in level:
                role_index[field_en] = role
                break
    return role_index
