"""paper_scanner.py — 文件夹版数据源扫描。

扫描结果是 PaperRecord 列表，后续 classify/extract 在内存里消费。

支持两类目录命名：
  1) `year-journal-doi`（解析后的标准目录，例如
     `1988-Tribology Transactions-10.1080_10402008808981837`），
     会解析出 year/journal/doi，跳过 title→DOI 流程。
  2) 其他（legacy）目录：仍按 markdown header 解析 title / year / authors。

每个 paper 还会顺手把 references_extractor 跑一遍，结果挂在
`PaperRecord.references` 上，下游聚合阶段消费。
"""
from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterator, List, Optional

from .fingerprint import compute_paper_uid
from .references_extractor import extract_references_from_dir

logger = logging.getLogger(__name__)


_MD_TITLE_RE = re.compile(r"^#\s+([^#].{5,})$", re.MULTILINE)
_MD_YEAR_RE = re.compile(
    r"(?:Received|Accepted|Published|Available\s+online|©|\bCopyright\b)"
    r"[^\n]{0,100}?\b(19|20)(\d{2})\b",
    re.IGNORECASE,
)

# year-journal-doi 命名识别（DOI 中的 `/` 已被替换为 `_`）
_FOLDER_YEAR_JOURNAL_DOI_RE = re.compile(
    r"^(?P<year>(?:18|19|20)\d{2})-(?P<journal>.+?)-(?P<doi>10\.[0-9]{3,9}_.+)$"
)


@dataclass
class PaperRecord:
    paper_uid: str
    title: str
    source_type: str
    source_dir: str
    source_ref: str
    content: str
    inject_fields: Dict = field(default_factory=dict)
    doi: Optional[str] = None
    year: Optional[int] = None
    journal: Optional[str] = None
    references: List[Dict] = field(default_factory=list)


def _parse_folder_name(folder: str) -> Optional[Dict[str, str]]:
    m = _FOLDER_YEAR_JOURNAL_DOI_RE.match(folder.strip())
    if not m:
        return None
    doi_raw = m.group("doi")
    # 把首个 `_` 还原为 `/`，DOI 形如 `10.1080/10402008808981837`
    doi = doi_raw.replace("_", "/", 1)
    return {
        "year": m.group("year"),
        "journal": m.group("journal").strip(),
        "doi": doi.strip().lower(),
    }


def _parse_md_header(md_path: Path, max_lines: int = 80) -> Dict[str, str]:
    try:
        with open(md_path, "r", encoding="utf-8") as f:
            head = "".join(f.readlines()[:max_lines])
    except Exception as exc:
        logger.debug("read md header failed: %s: %s", md_path, exc)
        return {}

    meta: Dict[str, str] = {}
    m = _MD_TITLE_RE.search(head)
    if m:
        t = m.group(1).strip().rstrip("*").strip()
        if 5 < len(t) < 300:
            meta["title"] = t

    m = _MD_YEAR_RE.search(head)
    if m:
        meta["publication_year"] = f"{m.group(1)}{m.group(2)}"

    if "title" in meta:
        after = head.split(meta["title"], 1)[-1]
        for raw in after.splitlines()[:12]:
            line = raw.strip()
            if not line or line.startswith("#") or ":" in line[:20]:
                continue
            if line.lower().startswith(
                ("abstract", "keywords", "article", "received", "regular ")
            ):
                continue
            if "," in line and len(line) < 400 and line[0].isupper():
                tokens = [t for t in line.split(",") if t.strip()]
                cap_tokens = sum(
                    1 for t in tokens if t.strip() and t.strip()[0].isupper()
                )
                if cap_tokens >= max(2, len(tokens) // 2):
                    meta["author"] = line[:500]
                    break
    return meta


def _iter_md_dir(src: Dict) -> Iterator[PaperRecord]:
    dir_path = Path(src["path"])
    src_name = src.get("name", dir_path.name)
    inject = dict(src.get("inject_fields", {}) or {})
    extract_refs = bool(src.get("extract_references", True))

    if not dir_path.exists():
        logger.warning("md_dir 不存在: %s", dir_path)
        return

    for sub in sorted(dir_path.iterdir()):
        if not sub.is_dir():
            continue
        md_path = sub / "full.md"
        if not md_path.exists():
            continue
        try:
            content = md_path.read_text(encoding="utf-8")
        except Exception as exc:
            logger.error("读 md 失败 %s: %s", md_path, exc)
            continue
        if not content.strip():
            continue

        folder_meta = _parse_folder_name(sub.name) or {}
        header_meta = _parse_md_header(md_path)

        # 标题策略：优先 markdown header；否则用 doi 后半段或文件夹名
        title = header_meta.get("title")
        if not title:
            if folder_meta:
                # 兜底：用 journal-doi 拼出可读字符串
                title = f"{folder_meta['journal']} {folder_meta['doi']}"
            else:
                title = sub.name
        if len(title) > 300:
            title = title[:300]

        paper_inject = dict(inject)
        if header_meta.get("author"):
            paper_inject["author"] = header_meta["author"]

        year_str = folder_meta.get("year") or header_meta.get("publication_year")
        try:
            year_int = int(year_str) if year_str else None
        except (TypeError, ValueError):
            year_int = None
        if year_str:
            paper_inject["publication_year"] = year_str
        if folder_meta.get("journal"):
            paper_inject["journal"] = folder_meta["journal"]
        if folder_meta.get("doi"):
            paper_inject["doi"] = folder_meta["doi"]

        refs: List[Dict] = []
        if extract_refs:
            try:
                refs = extract_references_from_dir(sub, content_text=content)
            except Exception as exc:
                logger.warning("references 抽取失败 %s: %s", sub, exc)

        yield PaperRecord(
            paper_uid=compute_paper_uid(title, content),
            title=title,
            source_type="md_dir",
            source_dir=src_name,
            source_ref=str(sub),
            content=content,
            inject_fields=paper_inject,
            doi=folder_meta.get("doi"),
            year=year_int,
            journal=folder_meta.get("journal"),
            references=refs,
        )


def _iter_jsonl(src: Dict) -> Iterator[PaperRecord]:
    file_path = Path(src["path"])
    src_name = src.get("name", file_path.name)
    inject = dict(src.get("inject_fields", {}) or {})
    field_mapping = src.get("field_mapping", {}) or {}
    title_field = field_mapping.get("title", "title")
    content_field = field_mapping.get("content", "content")
    id_field = field_mapping.get("id", "id")

    if not file_path.exists():
        logger.warning("jsonl 不存在: %s", file_path)
        return

    with open(file_path, "r", encoding="utf-8") as f:
        for line_num, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                record = json.loads(line)
            except json.JSONDecodeError as exc:
                logger.warning("[%s] line %d JSON 解析失败: %s",
                               src_name, line_num, exc)
                continue
            title = str(record.get(title_field, f"record_{line_num}"))
            content = str(record.get(content_field, ""))
            record_id = str(record.get(id_field, f"line_{line_num}"))
            if not content.strip():
                continue
            if len(title) > 300:
                title = title[:300]

            extra_meta = {k: v for k, v in record.items()
                          if k not in (title_field, content_field)}
            paper_inject = dict(inject)
            paper_inject["_jsonl_record_id"] = record_id
            paper_inject["_jsonl_metadata"] = extra_meta

            yield PaperRecord(
                paper_uid=compute_paper_uid(title, content),
                title=title,
                source_type="jsonl",
                source_dir=src_name,
                source_ref=f"{file_path}#{record_id}",
                content=content,
                inject_fields=paper_inject,
                doi=record.get("doi"),
                year=record.get("year"),
                journal=record.get("journal"),
            )


def scan_data_sources(
    data_sources: List[Dict],
    skip_uids: Optional[set] = None,
) -> List[PaperRecord]:
    """扫描所有 data_sources 并去重（paper_uid 维度）。"""
    seen: set = set()
    skip_uids = skip_uids or set()
    papers: List[PaperRecord] = []
    n_skipped = 0
    for src in data_sources:
        if src["type"] == "md_dir":
            iterator = _iter_md_dir(src)
        elif src["type"] == "jsonl":
            iterator = _iter_jsonl(src)
        else:
            logger.warning("未知 source type: %s", src["type"])
            continue
        for paper in iterator:
            if paper.paper_uid in seen:
                continue
            seen.add(paper.paper_uid)
            if paper.paper_uid in skip_uids:
                n_skipped += 1
                continue
            papers.append(paper)
    logger.info(
        "扫描完成: 共 %d 篇唯一论文（已跳过 %d 篇 — 已在历史 JSONL 中）",
        len(papers), n_skipped,
    )
    return papers
