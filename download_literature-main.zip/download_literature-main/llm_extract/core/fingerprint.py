"""fingerprint.py — paper_uid 计算（内容指纹，跨 run 稳定）。

paper_uid = sha1( norm_title + "\\x1f" + content[:2000] )[:16]

设计点：
  - 同一篇论文从不同数据源/不同扫描顺序进来都拿到相同 ID。
  - 包含 hash_version 字段，便于以后改算法时迁移。
  - 单独提供 sha1_full() 用于内容寻址（content_store）。
"""
from __future__ import annotations

import hashlib
import re
import unicodedata


HASH_VERSION = "v1"
_PAPER_UID_LEN = 16
_TITLE_PREVIEW_LEN = 2000  # 内容前缀长度（参与 paper_uid 计算）

_WS_RE = re.compile(r"\s+")
_PUNCT_RE = re.compile(r"[^\w\s一-鿿]+")  # 保留字母/数字/中文，去标点


def normalize_title(title: str) -> str:
    """标题归一化：NFC + 小写 + 去标点 + 空白合并。"""
    if not title:
        return ""
    t = unicodedata.normalize("NFC", title).strip().lower()
    t = _PUNCT_RE.sub(" ", t)
    t = _WS_RE.sub(" ", t).strip()
    return t


def normalize_content_preview(content: str, n: int = _TITLE_PREVIEW_LEN) -> str:
    """内容前 n 字符归一化（去多余空白）；用于补强 title 不稳的情况。"""
    if not content:
        return ""
    c = content[:n]
    c = unicodedata.normalize("NFC", c)
    c = _WS_RE.sub(" ", c).strip()
    return c


def compute_paper_uid(title: str, content: str) -> str:
    """计算 paper_uid（短哈希，16 hex chars = 64 bit）。"""
    norm_title = normalize_title(title)
    norm_preview = normalize_content_preview(content)
    blob = f"{norm_title}\x1f{norm_preview}".encode("utf-8")
    return hashlib.sha1(blob).hexdigest()[:_PAPER_UID_LEN]


def sha1_full(content: str) -> str:
    """全文 sha1（40 hex chars），用于 content_store 内容寻址。"""
    return hashlib.sha1(content.encode("utf-8")).hexdigest()
