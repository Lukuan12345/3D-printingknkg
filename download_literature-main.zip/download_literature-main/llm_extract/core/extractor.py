"""extractor.py — classify + extract 单篇函数。

prompts / postprocess 包从 llm_extract 包根目录引用（已与本目录同级复制）。
"""
from __future__ import annotations

import logging
import re
from typing import Any, Dict, List, Optional, Tuple

from .llm_client import AsyncLLMClient
from .domain_prefer import (
    DomainPreferences,
    build_classify_overlay,
    build_extract_overlay,
)

logger = logging.getLogger(__name__)


# ---------- 占位符清洗 ----------

_PLACEHOLDER_RE = re.compile(
    r"^("
    r"not\s+(mentioned|applicable|specified|reported|stated|"
    r"quantified|measured|determined|characterized|"
    r"explicitly\s+(stated|reported|mentioned|measured|provided|given|quantified))"
    r"(\s.*)?"
    r"|n/?a"
    r"|none"
    r"|unknown"
    r")$",
    re.IGNORECASE,
)


def clean_extracted_data(mech: Dict) -> Dict:
    ed = mech.get("extracted_data")
    if not isinstance(ed, dict):
        return mech
    keys_to_delete = []
    for key, val in ed.items():
        if isinstance(val, list):
            cleaned = [v for v in val
                       if not (isinstance(v, str) and _PLACEHOLDER_RE.match(v.strip()))]
            if not cleaned:
                keys_to_delete.append(key)
            elif len(cleaned) != len(val):
                ed[key] = cleaned
    for key in keys_to_delete:
        del ed[key]
    return mech


# ---------- 分类 ----------

async def classify_paper_async(
    client: AsyncLLMClient,
    paper_uid: str,
    title: str,
    content: str,
    valid_domains: set,
    classifier_model: str = "claude-haiku-4-5-20251001",
    domain_prefs: Optional[DomainPreferences] = None,
) -> Dict[str, Any]:
    """对单篇做相关性 + 域分类。失败时保守标为相关 + 无特定域（全量提取兜底）。"""
    from prompts import build_classify_prompt

    excerpt = content[:3000]
    prompt = build_classify_prompt(valid_domains, excerpt)

    if domain_prefs is not None:
        overlay = build_classify_overlay(domain_prefs)
        if overlay:
            prompt = f"{prompt}\n{overlay}"

    try:
        result = await client.call_json(
            prompt, classifier_model,
            temperature=0.0, max_tokens=32768,
        )
    except Exception as exc:
        logger.warning("[%s] 分类调用异常: %s", paper_uid, exc)
        return {"paper_uid": paper_uid, "is_relevant": True, "domains": [],
                "reason": "classification_failed_fallback"}

    if isinstance(result, dict):
        domains = [d for d in result.get("domains", []) if d in valid_domains]
        is_rel = result.get("is_relevant", result.get("is_aerospace_relevant", False))
        return {
            "paper_uid": paper_uid,
            "is_relevant": bool(is_rel),
            "domains": domains,
            "reason": result.get("reason", ""),
        }

    return {"paper_uid": paper_uid, "is_relevant": True, "domains": [],
            "reason": "classification_no_json"}


# ---------- 提取 ----------

EXTRACT_SYSTEM_PROMPT = (
    "You are a professional literature information extraction expert. "
    "Please strictly follow the requirements to extract information, "
    "and only output valid JSON format."
)


def _normalize_mech(mech: Any) -> Dict:
    if isinstance(mech, list):
        if len(mech) == 1 and isinstance(mech[0], dict):
            return mech[0]
        if len(mech) > 1:
            merged = mech[0] if isinstance(mech[0], dict) else {}
            merged_ed = dict(merged.get("extracted_data", {})) \
                if isinstance(merged.get("extracted_data"), dict) else {}
            for extra in mech[1:]:
                if not isinstance(extra, dict):
                    continue
                extra_ed = extra.get("extracted_data", {})
                if isinstance(extra_ed, dict):
                    for k, v in extra_ed.items():
                        if k not in merged_ed:
                            merged_ed[k] = v
                        elif isinstance(merged_ed[k], list) and isinstance(v, list):
                            merged_ed[k] = list(set(merged_ed[k] + v))
                for tf in ("study_process_description", "design_optimization_logic",
                           "influence_analysis", "physical_mechanism"):
                    ev = extra.get(tf, "")
                    if ev and isinstance(ev, str):
                        mv = merged.get(tf, "") or ""
                        if ev not in mv:
                            merged[tf] = f"{mv}\n\n{ev}".strip()
            merged["extracted_data"] = merged_ed
            return merged
        return {}
    if not isinstance(mech, dict):
        return {}
    return mech


def build_extract_prompt(
    paper_uid: str,
    title: str,
    content: str,
    domains: List[str],
    model_name: str,
    schema_texts: Tuple[str, str, str, str],
    domain_family: str = "",
    max_tokens: Optional[int] = None,
    key_focus: Optional[str] = None,
    domain_prefs: Optional[DomainPreferences] = None,
) -> Tuple[str, str, int]:
    from prompts import build_prompt
    from postprocess import preprocess_paper_input
    from .key_extract_prompt import get_key_overlay

    paper_obj = {
        "paper_id": paper_uid,
        "paper_uid": paper_uid,
        "title": title,
        "markdown_content": content,
        "domains": domains,
    }
    paper_obj = preprocess_paper_input(paper_obj)

    ctx, var, tgt, mech_text = schema_texts
    prompt_template = build_prompt(domains, model=model_name, domain_family=domain_family)
    user_prompt = prompt_template.format(
        paper_title=f"[{paper_uid}] {title}",
        context_text=ctx,
        variables_text=var,
        targets_text=tgt,
        mechanism_text=mech_text,
        markdown_content=paper_obj.get("markdown_content", content),
    )

    overlay = get_key_overlay(key_focus)
    if overlay:
        user_prompt = (
            f"{user_prompt}\n\n"
            f"{overlay}\n"
            f"请严格按上述 KEY FOCUS 规则补强提取，并按之前要求只输出合法 JSON。"
        )

    if domain_prefs is not None:
        dom_overlay = build_extract_overlay(domain_prefs)
        if dom_overlay:
            user_prompt = f"{user_prompt}\n\n{dom_overlay}"

    return user_prompt, EXTRACT_SYSTEM_PROMPT, (max_tokens or 64000)


def parse_extract_response(
    raw: Any,
    paper_uid: str,
    model_name: str,
    domain_family: str = "",
    inject_fields: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    from postprocess import (
        fix_encoding, postprocess as legacy_postprocess, validate_extraction,
    )

    mech = _normalize_mech(raw)
    mech["paper_uid"] = paper_uid
    mech["paper_id"] = paper_uid

    mech = clean_extracted_data(mech)
    mech = fix_encoding(mech)
    mech = legacy_postprocess(mech, model_name, domain_family=domain_family)
    warnings = validate_extraction(mech, model_name)
    if warnings:
        logger.warning("[%s][%s] quality warnings: %s",
                       model_name, paper_uid, warnings)

    if inject_fields:
        ed = mech.get("extracted_data")
        if not isinstance(ed, dict):
            ed = {}
            mech["extracted_data"] = ed
        for key, val in inject_fields.items():
            if key.startswith("_"):
                continue
            if isinstance(val, str):
                ed[key] = [val]
            elif isinstance(val, list):
                ed[key] = val
            else:
                ed[key] = [str(val)]

    return mech


async def extract_paper_async(
    client: AsyncLLMClient,
    paper_uid: str,
    title: str,
    content: str,
    domains: List[str],
    model_name: str,
    schema_texts: Tuple[str, str, str, str],
    domain_family: str = "",
    inject_fields: Optional[Dict[str, Any]] = None,
    key_focus: Optional[str] = None,
    domain_prefs: Optional[DomainPreferences] = None,
) -> Dict[str, Any]:
    prompt, system_prompt, max_tokens = build_extract_prompt(
        paper_uid=paper_uid, title=title, content=content,
        domains=domains, model_name=model_name,
        schema_texts=schema_texts, domain_family=domain_family,
        key_focus=key_focus,
        domain_prefs=domain_prefs,
    )
    raw = await client.call_json(
        prompt, model_name,
        system_prompt=system_prompt,
        max_tokens=max_tokens,
    )
    return parse_extract_response(
        raw=raw,
        paper_uid=paper_uid,
        model_name=model_name,
        domain_family=domain_family,
        inject_fields=inject_fields,
    )
