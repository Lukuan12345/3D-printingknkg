"""domain_prefer.py — 解析领域偏好文件（如 mg.txt）。

文件格式（与 mg.txt 兼容）：
    Subdomains: [casting magnesium alloys; corrosion-resistant magnesium alloys; ...]

    # ====== Keywords ======
    Dimension 1: [keyword1 | keyword2, keyword3 | keyword4]
    Dimension 2: [...]
    Dimension 3: [...]

    # ====== Queries ======
    Queries:
    自然语言描述的研究问题 ...

`DomainPreferences.subdomains` 即为该领域族下生效的 valid_domains
（与 schema CSV "适用领域" 列对齐）。

`DomainPreferences.keyword_dimensions` 用于 classify / extract 的引导。
`DomainPreferences.queries` 用于 extract prompt 的研究目标提示。
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

logger = logging.getLogger(__name__)


_SUBDOMAIN_RE = re.compile(r"^\s*Subdomains?\s*:\s*\[(.+?)\]\s*$",
                           re.IGNORECASE | re.MULTILINE)
_DIMENSION_RE = re.compile(r"^\s*Dimension\s*\d+\s*:\s*\[(.+?)\]\s*$",
                           re.IGNORECASE | re.MULTILINE | re.DOTALL)
_QUERY_BLOCK_RE = re.compile(r"=+\s*Queries\s*=+\s*", re.IGNORECASE)


def _split_terms(raw: str, sep_pattern: str = r"[;；,，]") -> List[str]:
    return [t.strip().strip("\"'") for t in re.split(sep_pattern, raw) if t.strip()]


def _parse_dimension(raw: str) -> List[str]:
    """一个 Dimension 内的内容形如 `a | b, c | d, e`，返回 [a|b, c|d, e]。
    我们以逗号切，每段保留 `|` 让下游做 OR 匹配。"""
    items = []
    # 兼容 JSON 风格的换行 + 逗号（mg.txt Dimension 3 即为该格式）
    cleaned = raw.replace("\n", " ")
    for chunk in re.split(r",\s*(?![^|]*\])", cleaned):
        chunk = chunk.strip().strip("\"'")
        if chunk:
            items.append(chunk)
    return items


@dataclass
class DomainPreferences:
    path: Optional[str] = None
    domain_family: str = ""
    subdomains: List[str] = field(default_factory=list)
    keyword_dimensions: List[List[str]] = field(default_factory=list)
    queries: List[str] = field(default_factory=list)

    @property
    def valid_domains(self) -> set:
        return set(self.subdomains)

    def has_content(self) -> bool:
        return bool(self.subdomains or self.keyword_dimensions or self.queries)


def load_domain_prefer(path: Optional[str],
                       domain_family: str = "") -> DomainPreferences:
    """读取 domain prefer 文件；路径为空或不存在则返回空对象。"""
    prefs = DomainPreferences(path=path, domain_family=domain_family)
    if not path:
        return prefs
    p = Path(path)
    if not p.exists():
        logger.warning("domain_prefer_file 不存在: %s", path)
        return prefs

    text = p.read_text(encoding="utf-8")

    # 1) Subdomains —— 多行只取最后一条非注释行（mg.txt 顶部第一行被 # 注释掉）
    sub_lines: List[str] = []
    for raw_line in text.splitlines():
        s = raw_line.strip()
        if not s or s.startswith("#"):
            continue
        m = _SUBDOMAIN_RE.match(s)
        if m:
            sub_lines.append(m.group(1))
    if sub_lines:
        prefs.subdomains = _split_terms(sub_lines[-1])

    # 2) Dimensions
    for m in _DIMENSION_RE.finditer(text):
        prefs.keyword_dimensions.append(_parse_dimension(m.group(1)))

    # 3) Queries —— 只取 ====== Queries ====== 之后的非空行
    parts = _QUERY_BLOCK_RE.split(text, maxsplit=1)
    if len(parts) == 2:
        tail = parts[1]
        for raw_line in tail.splitlines():
            line = raw_line.strip()
            if not line:
                continue
            if line.lower().startswith("queries"):
                line = re.sub(r"^[Qq]ueries\s*[:：]\s*", "", line)
            if line and not line.startswith("#"):
                prefs.queries.append(line)

    logger.info(
        "DomainPreferences 加载: subdomains=%d, dims=%d, queries=%d (from %s)",
        len(prefs.subdomains), len(prefs.keyword_dimensions),
        len(prefs.queries), path,
    )
    return prefs


# ---------------------------------------------------------------------
# Prompt overlay 构造
# ---------------------------------------------------------------------

def build_classify_overlay(prefs: DomainPreferences) -> str:
    """注入到 classify prompt 末尾的引导块。"""
    if not prefs.has_content():
        return ""
    lines: List[str] = []
    lines.append("\n## Domain prior (from domain_prefer_file)")
    if prefs.domain_family:
        lines.append(f"- domain_family: **{prefs.domain_family}**")
    if prefs.subdomains:
        lines.append("- 可选 sub-domain（必须从中挑选，不要新造）：")
        for s in prefs.subdomains:
            lines.append(f"  - `{s}`")
    if prefs.keyword_dimensions:
        lines.append("- 关键词维度（命中任意一维即可视为相关）：")
        for i, dim in enumerate(prefs.keyword_dimensions, 1):
            joined = " ; ".join(dim)
            lines.append(f"  - Dim {i}: {joined}")
    if prefs.queries:
        lines.append("- 研究目标：")
        for q in prefs.queries:
            lines.append(f"  - {q}")
    return "\n".join(lines)


def build_extract_overlay(prefs: DomainPreferences) -> str:
    """注入到 extract prompt 的引导块（重点字段筛选范围）。"""
    if not prefs.has_content():
        return ""
    lines: List[str] = []
    lines.append("================================================================")
    lines.append("# Domain prior (from domain_prefer_file)")
    lines.append("================================================================")
    if prefs.domain_family:
        lines.append(f"- domain_family: **{prefs.domain_family}**")
    if prefs.subdomains:
        lines.append("- Sub-domains under this family:")
        for s in prefs.subdomains:
            lines.append(f"  - `{s}`")
    if prefs.keyword_dimensions:
        lines.append("- Keyword dimensions — these are the LITERAL phrases to "
                     "look for in the paper text. Wherever you find quantitative "
                     "values associated with these terms, extract them rigorously:")
        for i, dim in enumerate(prefs.keyword_dimensions, 1):
            for term in dim:
                lines.append(f"  - Dim{i}: {term}")
    if prefs.queries:
        lines.append("- Research goals (must be answerable from extracted_data; "
                     "fields tied to these goals have HIGHEST priority):")
        for q in prefs.queries:
            lines.append(f"  - {q}")
    lines.append("================================================================")
    return "\n".join(lines)
