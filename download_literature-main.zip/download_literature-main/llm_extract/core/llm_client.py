"""llm_client.py — httpx.AsyncClient 异步 LLM 客户端 + tenacity 重试。
  - 全局共享一个 AsyncClient（连接池复用 + http2 多路复用）
  - tenacity 指数退避 + 不可恢复错误短路（model_not_found / invalid_api_key 等）
  - JSON 提取逻辑搬过来（_extract_json_from_text + _try_repair_truncated_json）

接口与老版保持兼容：
  - call_llm_async(...)  → str | None  （等价于老版 call_llm）
  - call_llm_json_async(...) → Any | None  （等价于老版 call_llm_json）
"""
from __future__ import annotations

import json
import logging
import re
from typing import Any, Optional

import httpx
from tenacity import (
    AsyncRetrying,
    retry_if_exception,
    stop_after_attempt,
    wait_exponential_jitter,
)

logger = logging.getLogger(__name__)


_FATAL_CODES = (
    "model_not_found", "invalid_api_key",
    "insufficient_quota", "permission_denied",
)


class LLMFatalError(Exception):
    """不可恢复错误（不重试）。"""
    pass


class LLMRetryableError(Exception):
    """可重试的网关/网络错误。"""
    pass


# ---------------------------------------------------------------------
# JSON 提取（与老版保持一致）
# ---------------------------------------------------------------------

def _try_repair_truncated_json(text: str) -> Any:
    """尝试修复被 max_tokens 截断的 JSON：找最后一个完整 } 或 ]，砍掉残片补全。"""
    last_brace = max(text.rfind("}"), text.rfind("]"))
    if last_brace < 0:
        return None
    candidate = text[:last_brace + 1]
    for cut in range(len(candidate), 0, -1):
        try:
            return json.loads(candidate[:cut])
        except Exception:
            continue
    return None


def extract_json_from_text(text: str) -> Any:
    """稳健地从 LLM 输出中提取 JSON。"""
    if not text or not text.strip():
        return None
    text = text.strip()
    text = re.sub(r"<think(?:ing)?>\s*[\s\S]*?</think(?:ing)?>", "", text).strip()

    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    matches = list(re.finditer(r"```(?:json|JSON)?\s*\n?([\s\S]*?)\n?\s*```", text))
    for match in reversed(matches):
        candidate = match.group(1).strip()
        if not candidate:
            continue
        try:
            return json.loads(candidate)
        except json.JSONDecodeError:
            continue

    truncated = _try_repair_truncated_json(text)
    if truncated is not None:
        return truncated

    candidates = []
    for open_ch, close_ch in [("{", "}"), ("[", "]")]:
        end = text.rfind(close_ch)
        if end == -1:
            continue
        depth = 0
        for i in range(end, -1, -1):
            if text[i] == close_ch:
                depth += 1
            elif text[i] == open_ch:
                depth -= 1
            if depth == 0:
                try:
                    parsed = json.loads(text[i: end + 1])
                    candidates.append((i, parsed))
                except json.JSONDecodeError:
                    pass
                break
    if candidates:
        for _, parsed in candidates:
            if isinstance(parsed, dict) and any(
                k in parsed for k in ("fields", "new_fields", "clusters")
            ):
                return parsed
        for _, parsed in candidates:
            if isinstance(parsed, list) and len(parsed) > 1:
                return parsed
        candidates.sort(key=lambda x: x[0])
        return candidates[0][1]
    return None


# ---------------------------------------------------------------------
# AsyncLLMClient
# ---------------------------------------------------------------------

class AsyncLLMClient:
    """全局共享一个实例（连接池复用）。用 async with 包住生命周期。"""

    def __init__(
        self,
        base_url: str,
        api_key: str,
        max_connections: int = 64,
        max_keepalive: int = 32,
        timeout_seconds: float = 1800.0,
        connect_timeout: float = 15.0,
        http2: bool = True,
    ):
        clean_base = base_url.rstrip("/")
        if clean_base.endswith("/v1"):
            clean_base = clean_base[:-3]
        self.base = clean_base
        self.api_key = api_key
        self.timeout = httpx.Timeout(timeout_seconds, connect=connect_timeout)
        self.limits = httpx.Limits(
            max_connections=max_connections,
            max_keepalive_connections=max_keepalive,
        )
        self.http2 = http2
        self._client: Optional[httpx.AsyncClient] = None

    async def __aenter__(self):
        self._client = httpx.AsyncClient(
            limits=self.limits,
            timeout=self.timeout,
            http2=self.http2,
            headers={
                "Accept": "application/json",
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            },
        )
        return self

    async def __aexit__(self, exc_type, exc, tb):
        if self._client:
            await self._client.aclose()
            self._client = None

    # -----------------------------------------------------------------

    async def call_text(
        self,
        prompt: str,
        model_name: str,
        system_prompt: Optional[str] = None,
        temperature: Optional[float] = None,
        response_format: Optional[dict] = None,
        max_retries: int = 5,
        max_tokens: Optional[int] = None,
    ) -> Optional[str]:
        """调用 LLM 返回纯文本（仅 /v1/chat/completions 路径）。"""
        assert self._client is not None, "AsyncLLMClient must be used with `async with`"

        api_url = f"{self.base}/v1/chat/completions"

        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})
        payload: dict = {"model": model_name, "messages": messages}
        if temperature is not None:
            payload["temperature"] = temperature
        if response_format is not None:
            payload["response_format"] = response_format
        payload["max_tokens"] = max_tokens or 64000

        async def _post() -> str:
            try:
                resp = await self._client.post(api_url, json=payload)
            except (httpx.TimeoutException, httpx.NetworkError) as e:
                raise LLMRetryableError(f"network: {e!r}") from e

            if resp.status_code == 200:
                rj = resp.json()
                finish = rj.get("choices", [{}])[0].get("finish_reason")
                if finish == "length":
                    logger.warning("LLM 输出截断 (finish_reason=length) model=%s",
                                   model_name)
                return rj["choices"][0]["message"]["content"]

            body = resp.text
            if resp.status_code == 400:
                logger.error("400 client error: %s", body[:500])
                raise LLMFatalError(f"400: {body[:500]}")

            if resp.status_code in (401, 403):
                raise LLMFatalError(f"{resp.status_code}: {body[:500]}")

            if resp.status_code >= 500 or resp.status_code == 429:
                # 不可恢复错误短路（new-api 网关把 model_not_found 包装成 503）
                if any(f'"code":"{c}"' in body or f"'code': '{c}'" in body
                       for c in _FATAL_CODES):
                    raise LLMFatalError(f"fatal {resp.status_code}: {body[:500]}")
                raise LLMRetryableError(
                    f"{resp.status_code}: {body[:500]}"
                )

            raise LLMFatalError(f"{resp.status_code}: {body[:500]}")

        async for attempt in AsyncRetrying(
            reraise=True,
            stop=stop_after_attempt(max_retries),
            wait=wait_exponential_jitter(initial=2, max=60),
            retry=retry_if_exception(lambda e: isinstance(e, LLMRetryableError)),
        ):
            with attempt:
                return await _post()

        return None  # unreachable

    async def call_json(
        self, prompt: str, model_name: str, **kwargs
    ) -> Any:
        """调用 LLM 并稳健解析 JSON。失败返回 None。"""
        text = await self.call_text(prompt, model_name, **kwargs)
        if text is None:
            return None
        return extract_json_from_text(text)
