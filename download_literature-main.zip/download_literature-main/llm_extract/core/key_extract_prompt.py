"""key_extract_prompt.py — 重点关注主题的 prompt overlay。

被 build_extract_prompt 在 user_prompt 末尾（markdown 内容之前）注入，
用于强调某些重点字段必须深挖。本模块不替换原有 schema 提取逻辑，
而是**叠加**一层主题相关的提取要求。

预置主题：
  - transmission_fss : 增透（high transmission）+ 透波（wave-transparent）+ 频率选择表面（FSS）

用法：
  在 YAML 里：
    schema:
      key_focus: transmission_fss          # 内置主题名
      # 或
      key_focus: ./prompts/my_focus.txt    # 自定义 txt 路径

  CLI：
    python extract.py extract --config ... --output ... --key-focus transmission_fss

如要新增主题，在 TOPICS dict 里加一条即可；
也可以传入 .txt 文件路径来用任意自定义文本。
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


# ============================================================
# 主题 1：增透 / 透波 / 频率选择表面（航天 EM 透过/滤波关键三件套）
# ============================================================
TRANSMISSION_FSS_OVERLAY = """\
================================================================
# 重点关注主题（KEY FOCUS — 高优先级提取要求）
================================================================

如本论文涉及以下任一主题，请**特别仔细**抽取相关字段；
这些字段优先级 **高于** schema 中的一般字段：

----------------------------------------------------------------
## A. 增透 / High Transmission（高透过率 / 抗反射涂层）
----------------------------------------------------------------

适用情形：研究透过率（transmittance T、回波损耗 return loss、
插入损耗 insertion loss）的提升、匹配层（matching layer）、
四分之一波长结构、宽带抗反射涂层、Salisbury / Jaumann 屏、
吸-透协同结构、阻抗匹配设计等。

必须抽取的字段：
  1. **frequency_band**：起止频率（GHz / THz / nm 波长）；
     **center_frequency** f0；**fractional_bandwidth** FBW = ΔF/F0
  2. **transmittance_peak** T_max、**transmittance_min** T_min（工作频段内）；
     **return_loss_dB** S11、**insertion_loss_dB** S21
  3. **incidence_angle_range**：法向 / 斜入射；TE / TM 偏振稳定性
  4. **layer_count**、各层 **material_composition**、各层 **layer_thickness**、
     各层 **dielectric_constant** ε_r 与 **loss_tangent** tan δ
  5. **design_method**：quarter-wave matching / 传输线模型 / 阻抗匹配
     Z = √(Z_freespace × Z_substrate) / GA / 拓扑优化 / PINN
  6. **process_constraints**：层数 vs 工艺成本、层间附着力、
     热膨胀系数失配、CTE mismatch

----------------------------------------------------------------
## B. 透波 / Wave-Transparent（雷达罩、电磁窗、射频透明结构）
----------------------------------------------------------------

适用情形：雷达天线罩 radome、导引头窗口 seeker window、卫星舱口、
低损耗介质材料、机/弹载天线护罩、导弹头罩、FSS-loaded radome。

必须抽取的字段：
  1. **insertion_loss_dB** IL、**boresight_error_mrad** BSE、
     **boresight_error_slope** BSER、**transmission_efficiency**
  2. **wall_structure**：solid（实心）/ A-sandwich（A 夹层）/
     B-sandwich / C-sandwich / foam-core / tapered / FSS-loaded
  3. **dielectric_material**：石英 quartz / 熔融石英 fused silica /
     氧化铝 alumina / 氮化硼 BN / 氮化硅 Si3N4 / 聚四氟乙烯 PTFE /
     氰酸酯 cyanate ester / 环氧 epoxy / 聚酰亚胺 PI；
     给出 ε_r、tan δ、密度 ρ、热导率 k、抗弯强度
  4. **frequency_band**：L/S/C/X/Ku/Ka/W/THz 波段、起止频率
  5. **incidence_angle_range**：典型 0~70°；扫描天线给方位角范围
  6. **thermo_em_coupling**：高速气动加热、烧蚀（ablation）、
     热应力下 ε_r 漂移、外形热变形对透波的影响、Mach 数
  7. **environmental_durability**：抗冲击、抗雨蚀（rain erosion）、
     抗沙蚀、抗紫外、抗热震（thermal shock）

----------------------------------------------------------------
## C. 频率选择表面 / Frequency Selective Surface (FSS)
----------------------------------------------------------------

适用情形：FSS、metasurface 滤波层、超材料雷达罩、低 RCS 带通罩、
天线反射板、自适应/可调 FSS、3D-FSS、AFSS（Active FSS）。

必须抽取的字段：
  1. **unit_cell_geometry**：square loop 方环 / Jerusalem cross 耶路撒冷十字 /
     slot 缝隙 / patch 贴片 / double square loop 双方环 /
     fractal 分形 / 3D-FSS 立体 / hexagonal 六边形
  2. **lattice_periodicity** p（mm）、**period_to_wavelength_ratio** p/λ
  3. **unit_cell_dimensions**：金属线宽 w、缝隙宽 g、
     外环边长 L、内环边长 L_in、其它关键尺寸
  4. **substrate_layers**：层数、各层 ε_r、各层 tan δ、各层厚度
  5. **filter_type**：passband 通带 / stopband 阻带 / BPF 带通 /
     BSF 带阻 / LPF 低通 / HPF 高通
  6. **center_frequency** f0、**bandwidth_3dB** -3dB 带宽、
     **out_of_band_rejection_dB**、**passband_insertion_loss_dB**
  7. **angular_stability**：0~60° 时频偏 Δf0/f0、TE / TM 一致性
  8. **polarization**：linear / circular / dual-polarized /
     polarization-converting
  9. **active_tuning**：varactor 变容 / PIN diode / 液晶 LC /
     VO2 相变 / 石墨烯 graphene；调谐范围 Δf、偏置电压/电流
 10. **fabrication_process**：PCB / photolithography / inkjet printing /
     3D printing；尺寸公差容许度 tolerance

----------------------------------------------------------------
## 抽取规则（KEY FOCUS 严格规则）
----------------------------------------------------------------

1. 上述每个字段**必须给具体数值 + 单位**（如 "10.5 GHz"、"1.2 mm"、
   "ε_r = 3.4"）。论文给出范围（如 "8~12 GHz"）则保留范围。
2. 论文以图表（curves / plots）形式给出的关键数据，**优先读图取数**
   而非保留文字描述。例如 figure 上读出 T_max=0.95 @ 10 GHz，
   就写进 extracted_data；不要只写 "high transmission performance"。
3. 缩写第一次出现时给全称（FSS = Frequency Selective Surface）。
4. 论文未明确出现的字段**严格留空**，不要瞎猜。
5. 字段名映射：
   - 与 schema 已有字段同义 → **使用 schema 字段名**（参考前文 schema 定义）
   - schema 没有的字段 → 用 `_` 前缀放进 extracted_data 作为自定义字段，
     例如 `_unit_cell_geometry`、`_passband_center_freq`、
     `_boresight_error_mrad`
6. 若论文同时涉及多个主题（例如 FSS-loaded radome），
   **三个主题的字段都要抽**，不要只挑其一。
================================================================
"""


# ============================================================
# 主题注册表
# ============================================================
TOPICS = {
    "transmission_fss": TRANSMISSION_FSS_OVERLAY,
    # 之后可以再加：
    # "stealth_metamaterial": ...,
    # "absorber_design": ...,
}


def get_key_overlay(spec: Optional[str]) -> str:
    """根据 spec 解析出 overlay 文本。

    spec 可以是：
      - None / "" / "none"     → 返回空串（不注入）
      - 内置主题名（如 "transmission_fss"）→ 返回 TOPICS[spec]
      - 文件路径（.txt / .md / .py 也行）→ 读文件返回内容

    无法识别时返回空串，并打 warning。
    """
    if not spec or str(spec).strip().lower() in ("none", "off", "false", ""):
        return ""

    spec = str(spec).strip()

    # 1) 内置主题
    if spec in TOPICS:
        return TOPICS[spec]

    # 2) 文件路径
    p = Path(spec)
    if p.exists() and p.is_file():
        try:
            return p.read_text(encoding="utf-8")
        except Exception as exc:
            logger.warning("读取 key_focus 文件失败 %s: %s", p, exc)
            return ""

    logger.warning(
        "key_focus=%r 既不是内置主题（%s）也不是存在的文件路径，已忽略",
        spec, ", ".join(TOPICS.keys()),
    )
    return ""


def list_topics() -> list:
    """供 CLI 输出可选主题。"""
    return sorted(TOPICS.keys())
