#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""extract.py — llm_extract MVP 入口（haiku-only）。

流水线（一次 run 完成）：
  1. 读 YAML 配置
  2. 加载 domain_prefer_file（可选）：动态扩展 DOMAIN_LIBRARY / DOMAIN_FAMILY_SETS
  3. 解析 Schema CSV → valid_domains + 4 段 schema 文本
  4. paper_scanner 扫 data_sources：
       - `year-journal-doi/` 命名直接走 doi/year/journal/refs 解析
       - 其他目录退化到 md_header 解析
  5. classify（可选）→ extract（仅 haiku 系列模型）
  6. metadata_fetcher（OpenAlex + S2，可关闭）
  7. kb_aggregator → knowledge_base.json （直接喂给 server_package/kb_mvp/src/ingest.py）

输出目录布局：
  output/
    run_logs/<ts>.log
    filter_results.jsonl
    references.jsonl
    metadata.jsonl
    per_model/<model>/results.jsonl
    knowledge_base.json        ← server_package 入口
"""
from __future__ import annotations

import argparse
import asyncio
import io
import json
import logging
import random
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# 仓库根目录上 sys.path，加载 .env（让 YAML 留空的 base_url/api_key 回退到 .env）
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from env_bootstrap import load_env
load_env()

from core.config_loader import (
    load_yaml,
    resolve_llm_settings,
    resolve_schema_settings,
    validate_data_sources,
)
from core.domain_prefer import DomainPreferences, load_domain_prefer
from core.extractor import classify_paper_async, extract_paper_async
from core.jsonl_writer import JsonlWriter
from core.kb_aggregator import build_knowledge_base
from core.llm_client import AsyncLLMClient
from core.metadata_fetcher import MetadataFetcher
from core.paper_scanner import PaperRecord, scan_data_sources
from core.schema_loader import (
    build_schema_subsets,
    filter_schema_for_domains,
)

from prompts import (
    DEFAULT_VALID_DOMAINS,
    collect_valid_domains_from_schema,
    infer_domain_family,
    register_domain_family,
)
from postprocess import set_domain_family, set_schema_csv, set_usage_scope


# ---------------------------------------------------------------------
# Windows stdout UTF-8 兜底（与 server_package 保持一致）
# ---------------------------------------------------------------------
if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
if sys.stderr.encoding and sys.stderr.encoding.lower() != "utf-8":
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")


HAIKU_ONLY_DEFAULT_MODEL = "claude-haiku-4-5-20251001"
logger = logging.getLogger("llm_extract")


# =====================================================================
# 工具
# =====================================================================

def _ensure_haiku(model_name: str) -> str:
    """MVP 仅支持 claude haiku 系列模型，命中其他模型直接报错。"""
    if not model_name or "haiku" not in model_name.lower():
        raise ValueError(
            f"MVP 仅支持 claude haiku 模型，收到: {model_name!r}。"
            "请把 --models / --classifier / configs 里的模型改成 claude-haiku-* 系列。"
        )
    return model_name


def _setup_logging(output_dir: Path, verbose: bool) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    log_dir = output_dir / "run_logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_path = log_dir / f"run_{ts}.log"

    handlers: List[logging.Handler] = [
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(log_path, encoding="utf-8"),
    ]
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        handlers=handlers,
        force=True,
    )
    return log_path


def _load_seen_uids(jsonl_path: Path) -> set:
    seen: set = set()
    if not jsonl_path.exists():
        return seen
    with open(jsonl_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
            except Exception:
                continue
            uid = rec.get("paper_uid")
            if uid:
                seen.add(uid)
    return seen


def _load_seen_classify(jsonl_path: Path) -> Tuple[set, Dict[str, Any]]:
    """加载已分类记录：返回 (uid_set, {uid: {"domains": [...], "is_relevant": bool}})。"""
    seen: set = set()
    cache: Dict[str, Any] = {}
    if not jsonl_path.exists():
        return seen, cache
    with open(jsonl_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
            except Exception:
                continue
            uid = rec.get("paper_uid")
            if uid:
                seen.add(uid)
                cache[uid] = {
                    "domains": rec.get("domains") or [],
                    "is_relevant": bool(rec.get("is_relevant", True)),
                }
    return seen, cache


def _resolve_valid_domains(
    schema_csv: Optional[str],
    prefs: DomainPreferences,
    declared_family: Optional[str],
) -> Tuple[set, str]:
    """合并 schema CSV 与 domain_prefer 的子域。"""
    if prefs.subdomains and (declared_family or prefs.domain_family):
        family = declared_family or prefs.domain_family
        register_domain_family(family, set(prefs.subdomains))

    collected: set = set()
    if schema_csv:
        try:
            collected = collect_valid_domains_from_schema(schema_csv) or set()
        except Exception as exc:
            logger.warning("解析 schema CSV 域失败: %s", exc)

    if prefs.subdomains:
        collected.update(prefs.subdomains)

    if not collected:
        logger.warning("未能从 schema/domain_prefer 收集到任何域，回退到 DEFAULT_VALID_DOMAINS")
        collected = set(DEFAULT_VALID_DOMAINS)

    family = declared_family or prefs.domain_family or (infer_domain_family(collected) or "")
    return collected, family


# =====================================================================
# 单篇 worker
# =====================================================================

async def _process_paper(
    paper: PaperRecord,
    client: AsyncLLMClient,
    model_name: str,
    schema_rows_by_level: Dict,
    domain_family: str,
    valid_domains: set,
    classifier_model: Optional[str],
    do_classify: bool,
    key_focus: Optional[str],
    domain_prefs: DomainPreferences,
    classify_writer: Optional[JsonlWriter],
    results_writer: JsonlWriter,
    refs_writer: Optional[JsonlWriter],
    metadata_fetcher: Optional["MetadataFetcher"],
    metadata_writer: Optional[JsonlWriter],
    seen_metadata: set,
    seen_classify: set,
    classify_cache: Dict[str, Any],
    seen_results: set,
    sem: asyncio.Semaphore,
    metadata_sem: Optional[asyncio.Semaphore],
) -> None:
    if paper.paper_uid in seen_results:
        return

    async with sem:
        t0 = time.monotonic()
        domains: List[str] = []

        # ---- classify ----
        if do_classify and classifier_model:
            if paper.paper_uid in seen_classify:
                cached = classify_cache.get(paper.paper_uid, {})
                domains = cached.get("domains") or []
                if not cached.get("is_relevant", True):
                    logger.debug("[%s] 分类缓存命中（不相关），跳过 extract", paper.paper_uid)
                    return
            else:
                classify_rec = await classify_paper_async(
                    client=client,
                    paper_uid=paper.paper_uid,
                    title=paper.title,
                    content=paper.content,
                    valid_domains=valid_domains,
                    classifier_model=classifier_model,
                    domain_prefs=domain_prefs,
                )
                domains = classify_rec.get("domains") or []
                if classify_writer is not None:
                    await classify_writer.put(classify_rec)
                seen_classify.add(paper.paper_uid)
                classify_cache[paper.paper_uid] = {
                    "domains": domains,
                    "is_relevant": bool(classify_rec.get("is_relevant", True)),
                }
                if not classify_rec.get("is_relevant", True):
                    logger.info("[%s] 分类判为不相关，跳过 extract: %s",
                                paper.paper_uid, classify_rec.get("reason", ""))
                    return

        # ---- extract / metadata / references 三路并行 ----
        # classify 通过后三者相互独立，并发以缩短端到端时间；异常彼此隔离。
        schema_texts = filter_schema_for_domains(schema_rows_by_level, domains)

        async def _do_refs():
            if refs_writer is not None and paper.references:
                await refs_writer.put({
                    "paper_uid": paper.paper_uid,
                    "title": paper.title,
                    "doi": paper.doi,
                    "references": paper.references,
                })

        async def _do_extract():
            return await extract_paper_async(
                client=client,
                paper_uid=paper.paper_uid,
                title=paper.title,
                content=paper.content,
                domains=domains,
                model_name=model_name,
                schema_texts=schema_texts,
                domain_family=domain_family,
                inject_fields=paper.inject_fields,
                key_focus=key_focus,
                domain_prefs=domain_prefs,
            )

        async def _do_metadata():
            if metadata_fetcher is None or metadata_writer is None:
                return None
            if paper.paper_uid in seen_metadata:
                return None
            assert metadata_sem is not None
            async with metadata_sem:
                rec = await metadata_fetcher.fetch_one(
                    paper.paper_uid, paper.title, paper.doi,
                )
            await metadata_writer.put(rec)
            seen_metadata.add(paper.paper_uid)
            return rec

        refs_result, extract_result, metadata_result = await asyncio.gather(
            _do_refs(),
            _do_extract(),
            _do_metadata(),
            return_exceptions=True,
        )

        if isinstance(refs_result, Exception):
            logger.warning("[%s] references 写出异常: %s",
                           paper.paper_uid, refs_result)

        if isinstance(metadata_result, Exception):
            logger.warning("[%s] metadata 抓取异常: %s",
                           paper.paper_uid, metadata_result)

        if isinstance(extract_result, Exception):
            logger.exception("[%s] extract 失败: %s",
                             paper.paper_uid, extract_result)
            return

        mech = extract_result

        await results_writer.put({
            "paper_uid": paper.paper_uid,
            "title": paper.title,
            "model": model_name,
            "domains": domains,
            "source": {
                "source_type": paper.source_type,
                "source_dir": paper.source_dir,
                "source_ref": paper.source_ref,
                "doi": paper.doi,
                "year": paper.year,
                "journal": paper.journal,
            },
            "mechanism": mech,
            "elapsed_ms": int((time.monotonic() - t0) * 1000),
        })
        seen_results.add(paper.paper_uid)


# =====================================================================
# 主流程
# =====================================================================

async def run_pipeline(args: argparse.Namespace) -> None:
    config = load_yaml(args.config)
    llm_settings = resolve_llm_settings(config)
    schema_settings = resolve_schema_settings(config, args.config)
    data_sources = validate_data_sources(config)

    output_dir = Path(args.output).resolve()
    log_path = _setup_logging(output_dir, args.verbose)
    logger.info("日志写入 %s", log_path)

    # ---- 模型：仅 haiku ----
    extract_models: List[str] = [
        _ensure_haiku(m) for m in (args.models or [HAIKU_ONLY_DEFAULT_MODEL])
    ]
    classifier_model: Optional[str] = None
    if not args.skip_classify:
        classifier_model = args.classifier or "gpt-5-nano"

    # ---- domain prefer 文件 ----
    domain_prefer_file = (
        args.domain_prefer_file
        or schema_settings.get("domain_prefer_file")
        or ""
    )
    domain_prefs = load_domain_prefer(
        domain_prefer_file, domain_family=schema_settings.get("domain_family") or "",
    )

    # ---- schema 域 + 4 段文本 ----
    schema_csv = schema_settings.get("path")
    if not schema_csv:
        raise ValueError("schema.path 未配置")
    valid_domains, domain_family = _resolve_valid_domains(
        schema_csv, domain_prefs, schema_settings.get("domain_family"),
    )
    schema_rows_by_level = build_schema_subsets(
        schema_csv=schema_csv,
        valid_domains=valid_domains,
        usage_scope=schema_settings.get("usage_scope"),
    )
    logger.info("生效 valid_domains=%s | domain_family=%s",
                sorted(valid_domains), domain_family or "(unset)")

    # postprocess 模块全局配置注入
    set_schema_csv(schema_csv)
    if domain_family:
        set_domain_family(domain_family)
    if schema_settings.get("usage_scope"):
        set_usage_scope(schema_settings["usage_scope"])

    # ---- 扫描数据源 ----
    skip_uids: set = set()
    # 把所有模型的 results.jsonl 都视为已完成
    per_model_dir = output_dir / "per_model"
    for m in extract_models:
        results_jsonl = per_model_dir / m / "results.jsonl"
        skip_uids |= _load_seen_uids(results_jsonl)
    papers = scan_data_sources(data_sources, skip_uids=skip_uids)
    if not papers:
        logger.warning("没有需要处理的论文，退出")
        return

    # ---- 可选：随机采样 ----
    if args.sample is not None and args.sample > 0 and args.sample < len(papers):
        rng = random.Random(args.sample_seed)
        papers = rng.sample(papers, args.sample)
        logger.info("--sample %d：随机采样 %d 篇（seed=%s）",
                    args.sample, len(papers), args.sample_seed)
    elif args.sample is not None and args.sample >= len(papers):
        logger.info("--sample %d ≥ 可用论文数 %d，使用全量",
                    args.sample, len(papers))

    # ---- 输出文件 ----
    classify_path = output_dir / "filter_results.jsonl"
    refs_path = output_dir / "references.jsonl"
    metadata_path = output_dir / "metadata.jsonl"
    seen_classify, classify_cache = _load_seen_classify(classify_path)
    seen_refs = _load_seen_uids(refs_path)
    seen_metadata = _load_seen_uids(metadata_path)

    sem = asyncio.Semaphore(args.concurrency)
    # metadata 走外部 HTTP（OpenAlex / S2），自身已有 TokenBucket 限流，
    # 这里再叠一层信号量避免与 extract 抢 LLM 并发槽位。
    metadata_sem = asyncio.Semaphore(max(2, args.concurrency // 2))

    do_metadata = not args.skip_metadata
    if not do_metadata:
        logger.info("--skip-metadata：跳过 OpenAlex/S2 抓取")

    async with AsyncLLMClient(
        base_url=llm_settings["base_url"],
        api_key=llm_settings["api_key"],
    ) as client:
        # MetadataFetcher 与 LLM client 同生命周期，便于与 extract 并发。
        if do_metadata:
            metadata_fetcher_cm = MetadataFetcher(skip_s2=not args.run_s2)
        else:
            metadata_fetcher_cm = None

        async def _run_models(metadata_fetcher: Optional[MetadataFetcher]):
            for model_name in extract_models:
                model_dir = per_model_dir / model_name
                model_dir.mkdir(parents=True, exist_ok=True)
                results_jsonl = model_dir / "results.jsonl"
                seen_results = _load_seen_uids(results_jsonl)

                async with JsonlWriter(results_jsonl) as results_writer, \
                           JsonlWriter(classify_path) as classify_writer, \
                           JsonlWriter(refs_path) as refs_writer_obj, \
                           JsonlWriter(metadata_path) as metadata_writer_obj:

                    refs_writer = refs_writer_obj
                    metadata_writer = metadata_writer_obj if do_metadata else None

                    tasks = []
                    for paper in papers:
                        # 不重复写 references
                        paper_refs_writer = refs_writer if paper.paper_uid not in seen_refs else None
                        if paper_refs_writer is not None:
                            seen_refs.add(paper.paper_uid)

                        tasks.append(asyncio.create_task(_process_paper(
                            paper=paper,
                            client=client,
                            model_name=model_name,
                            schema_rows_by_level=schema_rows_by_level,
                            domain_family=domain_family,
                            valid_domains=valid_domains,
                            classifier_model=classifier_model,
                            do_classify=not args.skip_classify,
                            key_focus=args.key_focus or schema_settings.get("key_focus"),
                            domain_prefs=domain_prefs,
                            classify_writer=classify_writer,
                            results_writer=results_writer,
                            refs_writer=paper_refs_writer,
                            metadata_fetcher=metadata_fetcher,
                            metadata_writer=metadata_writer,
                            seen_metadata=seen_metadata,
                            seen_classify=seen_classify,
                            classify_cache=classify_cache,
                            seen_results=seen_results,
                            sem=sem,
                            metadata_sem=metadata_sem,
                        )))

                    logger.info(
                        "[model=%s] 启动 %d 个 paper 任务（并发 %d, metadata=%s）",
                        model_name, len(tasks), args.concurrency,
                        "on" if do_metadata else "off",
                    )
                    done = 0
                    for fut in asyncio.as_completed(tasks):
                        try:
                            await fut
                        except Exception as exc:
                            logger.exception("paper task 失败: %s", exc)
                        done += 1
                        if done % 5 == 0:
                            logger.info("[model=%s] 进度 %d/%d (results=%d)",
                                        model_name, done, len(tasks), results_writer.written)
                    logger.info("[model=%s] 完成 (results=%d 行)",
                                model_name, results_writer.written)

        if metadata_fetcher_cm is not None:
            async with metadata_fetcher_cm as metadata_fetcher:
                await _run_models(metadata_fetcher)
        else:
            await _run_models(None)

    # ---- aggregate to knowledge_base.json ----
    primary_results = per_model_dir / extract_models[0] / "results.jsonl"
    kb_path = Path(args.kb_output).resolve() if args.kb_output else output_dir / "knowledge_base.json"
    build_knowledge_base(
        results_jsonl=primary_results,
        output_path=kb_path,
        metadata_jsonl=metadata_path if metadata_path.exists() else None,
        local_refs_jsonl=refs_path if refs_path.exists() else None,
    )
    logger.info("✅ knowledge_base.json 写出: %s", kb_path)
    logger.info("   ↳ 可直接喂给 server_package: "
                "kb_mvp/src/ingest.py 指向该 JSON 即可")


# =====================================================================
# CLI
# =====================================================================

def _build_argparser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="llm_extract MVP — scan → classify → extract → metadata → KB.json (haiku-only)",
    )
    parser.add_argument("--config", required=True, help="YAML 配置文件路径")
    parser.add_argument("--output", required=True, help="输出目录")
    parser.add_argument("--kb-output", default=None,
                        help="knowledge_base.json 写出路径（默认 <output>/knowledge_base.json）")
    parser.add_argument(
        "--models", nargs="+", default=None,
        help=f"提取模型列表（必须是 claude haiku 系列，默认 {HAIKU_ONLY_DEFAULT_MODEL}）",
    )
    parser.add_argument(
        "--classifier", default=None,
        help="分类模型（默认 gpt-5-nano；不限 haiku，可传任意模型名）",
    )
    parser.add_argument("--skip-classify", action="store_true",
                        help="跳过 classify，所有论文都送 extract")
    parser.add_argument("--skip-metadata", action="store_true",
                        help="跳过 metadata fetcher（OpenAlex + S2）")
    parser.add_argument("--run-s2", action="store_true",
                        help="metadata fetcher 同时跑 Semantic Scholar（默认只跑 OpenAlex）")
    parser.add_argument("--key-focus", default=None,
                        help="覆盖 YAML schema.key_focus（如 transmission_fss）")
    parser.add_argument("--domain-prefer-file", default=None,
                        help="覆盖 YAML schema.domain_prefer_file（如 mg.txt）")
    parser.add_argument("--concurrency", type=int, default=16,
                        help="并发数（每个模型独立 semaphore）")
    parser.add_argument("--sample", type=int, default=None,
                        help="从扫描到的论文中随机采样 N 篇（不指定或 <=0 则全量）")
    parser.add_argument("--sample-seed", type=int, default=42,
                        help="--sample 的随机种子（默认 42，便于复现）")
    parser.add_argument("--verbose", action="store_true", help="开 DEBUG 日志")
    return parser


def main() -> None:
    args = _build_argparser().parse_args()
    try:
        asyncio.run(run_pipeline(args))
    except KeyboardInterrupt:
        print("\n[interrupted]")


if __name__ == "__main__":
    main()
