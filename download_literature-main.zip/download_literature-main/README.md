# gen_key

一个从「研究问题」到「LLM 抽取 Schema」再到「结构化知识库 → KB+KG 双轨知识底座 → RAG 问答 API」的端到端文献处理工具链 —— 从一句科学问题开始，自动跑完检索词生成 → 文献筛选 → PDF 下载 → Markdown 解析 → 对象存储入库 → 多 Agent 协作产出结构化抽取 Schema → LLM 批量结构化提取 → 向量库/图谱构建 → 检索增强问答：

1. **生成关键词**（步骤 ①）：把研究问题（+可选参考文献，支持 `pdf/md/txt/docx`）交给 LLM，自动产出多维度检索词。默认模型 `gemini-3.1-pro-preview`。
2. **多维度 SQL 检索**（步骤 ②）：按维度 / 多层关键词（支持 at-least-M-of-N、`|` 同义变体）+ 期刊白名单，去星河 StarRocks 数据源里筛文献，每个 Dimension 输出一份 CSV。
3. **批量下载 PDF**（步骤 ③）：根据 CSV 里的 `origin_path` 调 S3 接口并发下载（默认 15 线程），文件名 `年份-期刊-DOI.pdf`，**断点续传** —— 已存在的同 key 直接跳过。
4. **PDF 转 Markdown**（步骤 ④）：用 MinerU API 把 PDF 批量解析成 Markdown。**多账号配额轮转**（`k1/k2/...`），支持 `--start/--end` 切片分配给不同 key 并行跑，每个 key 单独的任务状态文件，断点续跑安全。
5. **回传对象存储**（步骤 ⑤）：用 rclone 把 MinerU 解析好的目录增量同步到 `xlc-hdd2:hangtian-kxfx`，供后续 RAG / 训练使用。
6. **生成提取 Schema**（步骤 ⑥）：`schema_gen/` 独立模块。根据领域偏好（关键词 + 子领域 + 科学问题）跑 **5+1 步多 Agent 协作流水线**（拆解 → 并发架构师生成 → 归纳 → 发散扩展 → 反思 → 聚类 → 子领域归类），产出一份 CSV 列出 LLM 应从文献里抽哪些字段、为什么、怎么抽。
7. **LLM 结构化提取**（步骤 ⑦）：`llm_extract/` 独立模块。输入 Markdown 文献目录 + Schema CSV + 领域偏好文件，经 classify → extract → metadata 三步流水线，产出可直接喂给 RAG / 知识库服务的 `knowledge_base.json`。
8. **KB+KG 双轨知识底座**（步骤 ⑧）：`build_kb_kg.py` 一键脚本把 `knowledge_base.json` + Schema CSV 同步喂给 **KB**（`kb_mvp/`：BGE-M3 embedding + FAISS 向量索引 + jieba BM25 倒排）和 **KG**（`scientific_kgqa/`：实体/关系抽取 + 子图存 SQLite + retriever）。换领域只需改 `scientific_kgqa/configs/` 下的引导词 + task-aware 重排配置（专家填权重配比、LLM 草拟词典/字段映射）。
9. **检索增强问答 API**（步骤 ⑨）：`retrieval_integration/` + `server.py` / `_test_server.py` 把 KB + KG 双轨检索 + 重排 + 生成式问答封装成 HTTP / SSE 接口，并附带 `knowledge_backflow/`（候选新知识池 → schema 演化）、`monitoring/`（指标 / 结构化日志）。
10. **图谱测评与优化**（步骤 ⑩）：`kg_eval/` 自包含模块。 QAG 出题/审题系统整体内置在 `kg_eval/qag/`，用出好的题反向测评图谱，按四维框架（KG / Retrieval / Reasoning / Answer）打分，诊断**图谱哪一维 / 哪个子项最需要优化**并给出针对性优化建议。指标公式移植自 bench、LLM-Judge 复用 `scientific_kgqa.llm_client`，图谱查询复用 `scientific_kgqa.QAEngine`。

> **凭据约定**：所有外部凭据（StarRocks 密码 / LLM API Key / Embedding Key / MinerU Key / Workbench Key / Ceph S3）都从环境变量读取，**源码与示例配置里不放明文密钥**。真实值集中写在仓库根目录的 `.env`（从 `.env.example` 拷贝填写），各入口脚本启动时通过 `env_bootstrap.load_env()` 自动加载它（已存在的环境变量不覆盖）。内网服务地址（embedding/LLM 网关）作为非密钥的兜底默认值保留，可被 `.env` 的 `EMBED_BASE_URL` / `LLM_BASE_URL` 覆盖。

---

## 技术底座

### kb_mvp —— 向量 + 关键词双路检索，全自研

无 LlamaIndex / LangChain / Chroma / Weaviate 等框架依赖，核心三层完全手写：

| 层 | 实现 | 关键参数 |
|----|------|---------|
| **Dense 向量检索** | FAISS `IndexHNSWFlat`（内积度量）+ BGE-M3 embedding（1024 维）| m=32, efConstruction=200, efSearch=64 |
| **Sparse 关键词检索** | jieba 分词 + `rank_bm25` BM25Okapi，序列化为 `bm25.pkl` | — |
| **元数据 + chunk 存储** | SQLite `kb.db`（`papers_metadata` + `paper_chunks` 两表）| — |
| **三路融合** | `fusion.py` 自实现加权融合（metadata 0.2 / dense 0.6 / sparse 0.2，可配置）| min-max 归一化后加权求和 |

每篇论文的 **7 个叙述字段**（`problem_context` / `study_process_description` / `design_optimization_logic` / `physical_mechanism` / `fabrication_process` / `design_method` / `influence_analysis`）分别切成独立 chunk 存储，既保留语义完整性，又使向量检索粒度精确到字段级别。

### scientific_kgqa —— LLM 抽取 → SQLite 存图 → 自研游走检索，全自研

无 Neo4j / NetworkX（主存储）/ GraphRAG / LightRAG 等图谱中间件依赖，端到端自研：

| 层 | 实现 | 关键参数 |
|----|------|---------|
| **图谱存储** | SQLite `kgqa.db`（`graph_node` 节点、`graph_edge` 边、`node_chunk_posting` 倒排，外加 paper/concept/alias 等多张表）| — |
| **图谱构建** | `builder.py` 调 LLM 从 7 个叙述字段抽 4-8 个 Concept 节点写入 SQLite；概念间的共现/演化（`CONCEPT_EVOLVES`）边由论文引用关系（paper_link）推导；LLM 缓存 `llm_cache.json` 支持断点续建 | ThreadPoolExecutor, `--llm-workers` 并发 |
| **PPR 游走** | `walk.py` 自实现 query-aware Personalized PageRank：从 seed 出发，每跳转移概率额外乘 query 语义相似度，抑制无关共现扩散 | α=0.15, steps=10, prune_top_n=3000 |
| **Beam 路径搜索** | 多 seed 独立 beam，按 `边权×0.5 + intent偏好×0.3 + 节点稀有度×0.2` 打分，产出可解释推理链 | beam_width=24, per_seed=8, max_hops=5 |
| **子图检索索引** | `retriever.pkl`（BM25 0.55 + TF-IDF 0.45 混合打分），支持 posting chunk 召回 + 论文集合输出 | — |

### 自研的核心优势

1. **零框架锁定，完全可移植**：整个知识底座就是几个文件（`kb.db` / `faiss.index` / `bm25.pkl` / `kgqa.db` / `retriever.pkl`），`rsync` 一下即可迁移到任意机器，无需启动数据库服务进程，无托管服务费。
2. **检索逻辑全透明可调**：三路融合权重、PPR α/步数、beam 宽度、task-aware 重排配置（`expert_weights_em.yaml`）均外置可配，不依赖任何黑盒中间件。
3. **增量更新友好**：KB 支持 `--incremental`（只 embed 新增 chunk，旧向量缓存复用）；KG 建图有 `llm_cache.json` 断点续建，已抽过的论文零 LLM 调用。
4. **可解释推理链**：KG `deep` 通道输出 beam 路径游走的推理链（实体 → 关系 → 实体），答案溯源不依赖黑盒嵌入相似度。
5. **跨机部署不失效**：`content_store/<paper_id>/full.md` + `_manifest.json` 机制（见步骤⑧(8f)）把源文全文归档进 artifacts，查询期源文 / PDF 下载不依赖原始解析路径；配合 Ceph 远端存储可弹性扩缩。

### 规模适配：20–30 万篇文献

| 规模 | Chunks | FAISS HNSW RAM | BM25 RAM | KG SQLite 估算 | 主要瓶颈 |
|------|--------|---------------|---------|---------------|---------|
| **10 万篇**（当前验证规模）| 70 万 | ~3.0 GB | ~1 GB | ~1 GB（150万节点）| embedding API 吞吐 |
| **20 万篇** | 140 万 | ~5.9 GB | ~2.5 GB | ~2 GB（300万节点）| **BM25 内存**（需 ≥16 GB） |
| **30 万篇** | 210 万 | **~8.9 GB** | **~4 GB** | ~3 GB（450万节点）| **BM25 + FAISS 合计 ≥13 GB，需 ≥32 GB 服务器** |


**20 万篇可直接跑（≥16 GB RAM 服务器）；30 万篇需两处调整：**

> **① FAISS 切换 IVF-PQ + mmap 加载**：`IndexHNSWFlat` 在 210 万向量时需 ~8.9 GB，且不支持 mmap。换用 `IndexIVFPQ`（nlist=4096, PQ m=64）后索引文件约 130 MB，以 `IO_FLAG_MMAP` 加载时 RSS 接近零（OS 按页缓存，冷启动后首批查询略慢），召回率损失 < 3%，需重建索引（改 `kb_mvp/src/config.py` 的索引类型 + `kb_mvp/src/dense_retrieval.py` 的 `read_index` 加 flag + 一次性跑 `--force` 重建）。
>
> **② BM25 改磁盘懒加载或分片**：当前 `bm25.pkl` 整体 load 进内存；210 万 chunk 约 4 GB，可通过减少 BM25 的 `top_k_sparse`（默认 20）缩短检索时间，或用 SQLite FTS5 全文索引替代（改动仅限 `kb_mvp/src/sparse_retrieval.py`）。
>
> **KG 游走**在 30 万篇规模（~450 万节点、~2250 万边）时，`prune_top_n=3000` 的 PPR 截断已足够抑制扩散（当前注释中测试过 "80k 节点" 场景），SQLite 加好索引（`idx_edges_src / idx_edges_dst`）后多跳查询仍在 100 ms 量级。LLM 建图是时间瓶颈（30万篇 × 16并发约 7-10小时），有 `llm_cache.json` 断点续建。

---

## 目录结构

```
gen_key/
├── generate_keywords.py      # ① LLM 生成检索关键词
├── dim_search.py             # ② 按关键词 + 期刊筛选,产出 dimN.csv
├── s3_download_csv.py        # ③ 根据 CSV 批量下载 PDF
├── mineru.py                 # ④ 用 MinerU API 把 PDF 解析成 Markdown
├── prompt/                   # LLM 提示模板
│   ├── keyword_generate.txt
│   └── keyword_generate2.txt
├── query/                    # 研究问题文本(LLM 输入)
│   └── try1.txt, try2.txt ...
├── reference/                # 参考文献(可选, LLM 输入, 支持 pdf/md/txt/docx)
├── dims/                     # 检索维度配置(LLM 输出 或 手写)
│   ├── q1.txt                # 纯简写示例
│   └── q2.txt                # 带期刊 + 多层复合示例
├── domain_prefer/            # ⑥⑦ schema_gen + llm_extract 用 — 关键词 + 子领域 + 科学问题合并文件
│   └── allylic_amination.txt # 示例：把 dims/qN.txt + query/tryN.txt 合并粘进来
├── schema_gen/               # ⑥ Schema 生成 (独立模块, 可单独使用)
│   ├── __main__.py           #   CLI 入口: python -m schema_gen --config ...
│   ├── configs/
│   │   └── example.yaml      #   配置示例: 模型 / 路径 / 流水线参数
│   └── core/                 #   配置加载 + 领域偏好解析 + 多 Agent 流水线
├── llm_extract/              # ⑦ LLM 结构化提取 (独立模块, haiku-only)
│   ├── extract.py            #   CLI 入口: python extract.py --config ... --output ...
│   ├── configs/
│   │   └── extract_config_aero_p1_local.yaml   # 配置示例
│   ├── core/                 #   config_loader / llm_client / extractor / metadata_fetcher 等
│   ├── prompts/              #   classify + extract 提示模板
│   ├── postprocess/          #   pipeline + normalize_knowledge_base
│   └── requirements.txt      #   llm_extract 独立依赖（已合并进顶层 requirements.txt）
├── build_kb_kg.py            # ⑧ 一键把 knowledge_base.json + schema 喂给 KB+KG 双轨底座
├── content_store_remote.py   # ⑧⑨ 远程存储桥接层：content_store 源文（boto3 按需拉取）+ artifacts 产物（push/pull）
├── kb_mvp/                   # ⑧ KB / 向量库（dense FAISS + sparse BM25 + 元数据 SQLite）
│   ├── src/                  #   embedding / ingest / dense_retrieval / sparse_retrieval / fusion 等
│   ├── tests/                #   测试 query 集合
│   ├── data/                 #   运行时产物（kb.db），git-ignored
│   ├── index/                #   运行时产物（faiss.index / bm25.pkl / chunk_ids.json），git-ignored
│   ├── quick_start.py
│   └── run_batch_test.py
├── scientific_kgqa/          # ⑧ KG / 知识图谱（实体 + 关系 → SQLite 子图 + retriever）
│   ├── src/scientific_kgqa/  #   builder / llm_extractor / retriever / qa_engine / pipeline / walk
│   ├── configs/              #   KG 引导词 + task-aware 重排配置
│   │   ├── prompts_em.yaml             #   建图/查询期 LLM 引导词（航天电磁示例 = 默认）
│   │   ├── expert_template_expert.yaml #   ★专家填：功能类型/维度子项/任务权重配比
│   │   ├── expert_template_auto.yaml   #   LLM 草拟：词典 + schema 字段映射
│   │   ├── draft_auto_from_schema.py   #   读 schema + 专家骨架 → LLM 草拟上面的 _auto
│   │   ├── build_expert_config.py      #   合成 expert + auto → expert_weights_em.yaml
│   │   └── expert_weights_em.yaml      #   自动生成，代码真正读取（勿手改）
│   ├── data/                 #   build_kb_kg.py 自动落 knowledge_base.json + schema.csv
│   ├── artifacts/            #   运行时产物（kgqa.db / retriever.pkl），git-ignored
│   ├── pyproject.toml
│   └── readme.md
├── retrieval_integration/    # ⑨ 双轨检索 + RAG + 知识回流（KB+KG 上层）
│   ├── core/                 #   pipeline / state / context / process_log
│   ├── modules/              #   m1..m6（schema 解析 / 内部检索 / 答案验证 / critic / 计划生成 / 外部检索 / 答案生成）
│   ├── stages/               #   bridge / match / render / cluster_naming
│   ├── llm/                  #   llm_client + 缓存
│   ├── knowledge_backflow/   #   候选新知识池 + schema 演化（admin_interface / candidate_pool / schema_evolver）
│   ├── monitoring/           #   metrics / logger / bottleneck_analyzer
│   ├── scripts/              #   run_query.py / batch_test.py / analyze_metrics.py / xinghe_search_cli.py
│   ├── config/               #   config_loader
│   ├── data/                 #   schema_miss_log + 运行时 logs / candidate_pool（git-ignored）
│   └── tests/
├── retrieval_weights/        # ⑧⑨ 本地 BGE-M3 embedding 模型（fast_ingest 本地模式读取）
│   └── models/
├── configs/retrieval/        # ⑨ retrieval_integration 主配置（default_config.yaml + prompts.yaml）
├── fast_ingest.py            # ⑧ KB 快速摄入（本地 BGE-M3 模型，省 embedding API 配额）
├── server.py                 # ⑨ HTTP / SSE 检索 + 问答 API 主服务
├── server_stub.py            # ⑨ 简化版本（无 LLM 依赖，方便联调前端）
├── _test_server.py           # ⑨ server.py 冒烟测试脚本
├── env_bootstrap.py          # .env 自动加载器（各入口脚本启动时调用）
├── kg_eval/                  # ⑩ 图谱测评与优化（内置 QAG 出题/审题网页 + 四维测评 + 多人部署/鉴权）
│   ├── qag/                  #   整套 QAG 出题/审题系统（网页 qag_ui_server.py + auth.py 登录鉴权）
│   ├── eval/                 #   四维测评：config / metrics / kg_inspector / qa_runner / judge / scorer / diagnose / report
│   ├── scripts/              #   bootstrap_deploy.sh / push_to_remote.sh / egress_relay.py
│   ├── run_kg_eval.py        #   CLI 入口: python -m kg_eval.run_kg_eval ...
│   └── 部署运行说明.md        #   多人分发 + 共享权重 + 鉴权说明
├── kg_v2/                    # 升级版图谱（并行子包）：两层 Schema × 四类语义节点 × 观测/因果/引用
│   ├── meta_schema/          #   Layer1 12 模块骨架 + layered_schema.json（P1 产物）
│   ├── schema/               #   P1 两层 Schema 注入（cluster_router / enrich_fieldspec / build_layered_schema）
│   ├── extract/              #   P2 Haiku 单调用分层抽取 + 观测质检 + 确定性表格解析
│   ├── graph/                #   P3 图谱组装 graph_v2.json + P4 落库 to_scientific_kgqa
│   ├── postprocess/          #   清洗 / 关系治理 / 导出 / 统计（clean_record / relation_gov / export / stats）
│   ├── release/              #   冻结发布 + 抽样 QA（freeze_release / sample_qa / qa_*）
│   └── build_kg_v2.py        #   一键编排 P1→P4
├── requirements.txt
└── README.md
```

---

## 一键部署

```bash
# 推荐用 venv / conda 隔离环境
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS / Linux
source .venv/bin/activate

pip install -r requirements.txt
```

> StarRocks / 下载接口的网络可达性需要 VPN 或办公网；若 `pip install pymupdf4llm` 失败，可单独装 `PyMuPDF`，二者只需其一即可解析 PDF 参考文献。

---

## 使用流程

整体两种用法：

- **A. 没有具体关键词**：先用 LLM 生成关键词 → 再筛选 → 再下载 → 再解析 → 再回传（步骤 ①②③④⑤）。
- **B. 已有关键词和期刊白名单**：直接手写 `dims/qX.txt` → 筛选 → 下载 → 解析 → 回传（步骤 ②③④⑤，跳过 ①）。

### 步骤 ①（可选）：从研究问题生成关键词

把你的研究问题写到 `query/<name>.txt`，可选地把相关参考文献放进 `reference/`（支持 `.pdf / .md / .txt / .docx`）。

```bash
python generate_keywords.py \
    --prompt prompt/keyword_generate.txt \
    --query  query/try1.txt \
    --reference reference/
```

可选参数：

| 参数 | 默认 | 说明 |
| ---- | ---- | ---- |
| `--api-key` | 读环境变量 `LLM_API_KEY`（未设置则报错退出） | LLM API Key |
| `--base-url` | `LLM_BASE_URL` 或内置默认 endpoint | LLM API Base URL |
| `--model` | `gemini-3.1-pro-preview`（或 `LLM_MODEL`） | 模型名 |
| `--max-tokens` | `8192` | 最大输出 token |

终端会打印每个 `Dimension N` 的关键词列表。**把这些 Dimension 行整理到 `dims/qX.txt` 里**作为下一步输入（或直接复制成那种格式）。

> 小贴士：LLM 输出有时含若干同义变体，可手动用 `|` 合成一个 term（详见步骤 ② 的 q2.txt 说明）。

### 步骤 ②：维度筛选 → CSV

把关键词和期刊白名单写到 `dims/qX.txt` 里。**支持两种维度写法**，可在同一份文件里混用：

#### (2a) 简写

```
Dimension 1: [allylic amination, photocatalysis, regioselective]
```

- 1–2 个词：直接 AND 一次。
- 3+ 个词：两两组合分别查询，最终合并去重。

#### (2b) 多层复合

```
Dimension 1:
layer1: [allylic amination, photocatalysis, regioselective] 1
layer2: [allylic C-H functionalization | allylic C–H functionalization, amination, photoredox] 2
```

- 每层 `[...]` 后的数字 `M` = 该层至少命中的关键词数（at-least-M of N）。
- 层与层之间是 **AND**，所有层都必须满足。
- 单个 term 内可用 `|` 列同义变体，任一变体出现即算命中（例如不同连字符 `- / – / —`，或英美拼写差异）。

#### 期刊白名单（可选）

文件顶端可加 `Journals: [...]`，使用 JSON 数组：

```
Journals:
[
    "Acta Materialia",
    "Materials & Design",
    "Nature Materials",
    "航空学报"
]
```

- 不写 / 空数组 ⇒ 不做期刊过滤。
- 写了 ⇒ 同时作用于两张源表：`ads_meta_xinghe_journal_paper_data_acc.journal_name` 与 `ads_xinghe_library_acc.magazine`，大小写不敏感。

完整示例见 `dims/q2.txt`。

#### 运行

```bash
python dim_search.py --dims-file dims/q2.txt --output ./results
```

| 参数 | 默认 | 说明 |
| ---- | ---- | ---- |
| `--dims-file` | (必填) | 维度配置文件路径 |
| `--output` | `.` | CSV 输出目录 |

每个 `Dimension N` 会产出一个 `dim{N}.csv`，列固定为：

```
doi, title, magazine, pub_time, origin_path
```

---

### 步骤 ③：根据 CSV 批量下载 PDF

```bash
python s3_download_csv.py \
    --csv-file "./results/dim1.csv" \
    --save-dir "./pdf/dim1/"
```

- 文件名规则：`{年份}-{期刊}-{DOI}.pdf`。
- **断点续传**：以 `年份-期刊-DOI` 为唯一键，已存在同 key 的 PDF 直接跳过。
- 默认 15 个并发线程（脚本顶部 `MAX_WORKERS` 可调）。
- 需要 S3 下载 API Key。脚本内置了 demo key，**建议通过环境变量覆盖**：

  ```bash
  # Windows PowerShell
  $env:WORKBENCH_API_KEY = "你的真实API KEY"
  # macOS / Linux
  export WORKBENCH_API_KEY="你的真实API KEY"
  ```

---

### 步骤 ④：用 MinerU API 把 PDF 解析成 Markdown

下载完 PDF 后，用 MinerU 批量解析成 `.md`，方便后续 LLM/RAG 使用。

#### (4a) 申请 MinerU API Key

1. 进入 [https://mineru.net/](https://mineru.net/) ，点击 **登录注册**，可用手机号或邮箱号注册（注册多个账号可获得多个独立配额）。
2. 在控制台点击 **API 申请 key**，复制生成的 key。
3. 打开 `mineru.py`，把 key 填到 `API_KEYS` 字典里：

   ```python
   API_KEYS = {
       "k1": "你的第一个key",
       "k2": "你的第二个key",   # 注册了多个账号就继续往下加 k3, k4 ...
   }
   ```

   也可以通过环境变量 `MINERU_API_KEY` 或命令行 `--api-key` 覆盖。

#### (4b) 提交 → 查询 → 下载

整体三步走，每个 key 的任务状态会落到 `tasks-dir` 下的 `mineru_tasks_{别名}.json`，互不干扰：

```bash
# 1) 提交：上传 PDF 目录里的文件，拿到 batch_id
python mineru.py --api-key k1 --tasks-dir ./tasks submit --pdf-dir ./pdf/dim1

# 可选：只提交某个区间（例如分配给不同 key 跑）
python mineru.py --api-key k1 --tasks-dir ./tasks submit --pdf-dir ./pdf/dim1 --start 0 --end 333
python mineru.py --api-key k2 --tasks-dir ./tasks submit --pdf-dir ./pdf/dim1 --start 333 --end 666

# 2) 查询解析进度（加 --wait 持续轮询直到全部完成）
python mineru.py --api-key k1 --tasks-dir ./tasks status --wait

# 3) 下载并自动解压 Markdown 结果
python mineru.py --api-key k1 --tasks-dir ./tasks download --output-dir ./md/dim1
```

| 参数 | 默认 | 说明 |
| ---- | ---- | ---- |
| `--api-key` | 环境变量 `MINERU_API_KEY` 或 `k1` | 支持别名（k1/k2/...）或完整 key |
| `--tasks-dir` | (必填) | 任务状态文件目录，断点续跑靠它 |
| `submit --pdf-dir` | (必填) | PDF 所在目录，递归扫描 `*.pdf` |
| `submit --start/--end` | `0 / 0` | 文件索引区间，`end=0` 表示到末尾 |
| `status --wait` | 关 | 持续轮询直到全部完成 |
| `status --interval` | `15` | 轮询间隔秒数 |
| `download --output-dir` | (必填) | 解析结果（Markdown + 图片）解压目录 |

- 单批最多 50 个文件，批与批之间默认间隔 30 秒避免限流；遇到 429 自动指数退避重试。
- 每个 PDF 的结果解压到 `output-dir/{文件名}/` 下，已存在且非空的目录会跳过，可放心重跑。
- 上传失败的文件下次 `submit` 会被重新尝试；上传成功的不会重复提交。

---

### 步骤 ⑤：回传到对象存储（rclone → `xlc-hdd2:hangtian-kxfx`）

MinerU 解析完后，把整份 Markdown 目录上传到内部的 Ceph S3 桶 `xlc-hdd2:hangtian-kxfx`，供后续 RAG / 训练使用。直接用命令行 `rclone` 操作。

#### (5a) 安装 rclone

| 平台 | 安装方式 |
| ---- | -------- |
| Windows | 去 [rclone.org/downloads](https://rclone.org/downloads/) 下 `rclone-vX.Y.Z-windows-amd64.zip`，解压把 `rclone.exe` 放进 `PATH`（或丢到 `C:\Windows\System32`） |
| macOS | `brew install rclone` |
| Linux | `curl https://rclone.org/install.sh \| sudo bash` |

装完用 `rclone version` 验一下。

#### (5b) 配置远端 `xlc-hdd2`

rclone 用独立的 ini 配置文件，**不读 `.env`**。

**Windows PowerShell：**

```powershell
# 第 1 步：创建配置文件目录
mkdir "$env:APPDATA\rclone" -Force

# 第 2 步：用记事本打开配置文件
notepad "$env:APPDATA\rclone\rclone.conf"
```

**macOS / Linux：**

```bash
mkdir -p ~/.config/rclone
${EDITOR:-vi} ~/.config/rclone/rclone.conf
```

第 3 步：在编辑器里粘贴以下内容，保存并关闭：

```ini
[xlc-hdd2]
type = s3
provider = Other
access_key_id = BDFA0C0D015B1326456F
secret_access_key = dxGmsPtvX75V2SW83ewHB0BI98UAAAGeAVsTJgb3
endpoint = http://d-ceph-ssd2-inside.pjlab.org.cn
acl = private
location_constraint =
region =
force_path_style = true
```

第 4 步：验证配置生效，应该能列出桶里现有的目录：

```bash
rclone lsd xlc-hdd2:hangtian-kxfx
```

#### (5c) 上传 MinerU 解析结果

把步骤 ④ `download --output-dir` 产出的目录整目录 `copy` 到桶里：

```bash
# 把 ./md/dim1 上传到 xlc-hdd2:hangtian-kxfx/dim1
rclone copy ./md/dim1 xlc-hdd2:hangtian-kxfx/dim1 --progress --transfers 16

# 想分项目存：
rclone copy ./md/dim1 xlc-hdd2:hangtian-kxfx/projectA/dim1 --progress --transfers 16

# 演练不真传：
rclone copy ./md/dim1 xlc-hdd2:hangtian-kxfx/dim1 --dry-run
```

常用参数：

| 参数 | 说明 |
| ---- | ---- |
| `--progress` | 显示实时进度 |
| `--transfers N` | 并发传输数，大目录建议 16+ |
| `--dry-run` | 只演练，不真传 |
| `--checksum` | 用 MD5 校验而不是只比大小+时间（更慢但更稳） |
| `--exclude "*.zip"` | 排除某些文件 |

`rclone copy` 是增量的：源端已经传过、和目标端 size+mtime 一致的文件会自动跳过，所以可放心重跑。

---

### 步骤 ⑥：根据领域偏好生成提取 Schema —— `schema_gen/`

`schema_gen/` 跟 ①~⑤ 没有强耦合：
你只要告诉它「我的文献库是用什么关键词检索来的（dims/qN.txt）+ 我想解决什么科学问题（query/tryN.txt）」，它就跑一个 5+1 步多 Agent 流水线，吐一份 CSV 列出后续 LLM 抽取应该提取哪些字段、为什么、怎么抽。

CSV 列：
```
字段名（英文）, 字段名（中文）, 完整描述, 提取提示, 层级, 标签,
重点字段, 聚类ID, 聚类名称, 聚类名称（英文）, 适用领域, 使用范围
```

#### (6a) 写一份领域偏好文件 `domain_prefer/<project>.txt`

把 `dims/qN.txt` 的 `Dimension N:` 段 + `query/tryN.txt` 的问题原样粘进去：

```
# ====== Subdomains ======
Subdomains: [photocatalysis; allylic amination; organic synthesis]

# ====== Keywords ======
Keywords:
Dimension 1:
layer1: [allylic amination, photocatalysis, regioselective] 1
layer2: [allylic C-H functionalization | allylic C–H functionalization, amination, photoredox] 2

Dimension 2:
layer1: [dual catalysis, allylic substitution, regiocontrol] 2

Dimension 3: [nitrogen radical, allylic, visible light]

# ====== Queries ======
Queries:
如何实现光化学条件下苯胺参与的位点选择性烯丙位胺化  反应物1：...  产物：...
```

三段都**必填**（缺任意一段 `python -m schema_gen` 会拒绝执行）：

- **Subdomains** —— 子领域闭合列表，决定 CSV「适用领域」列的取值范围。
- **Keywords** —— 直接复制 `dims/qN.txt` 的 `Dimension N:` 段，让 LLM 围绕这些关键词偏向取材。
- **Queries** —— 直接复制 `query/tryN.txt` 的科学问题，作为驱动 schema 生成的 user_query。

完整示例：`domain_prefer/allylic_amination.txt`。

#### (6b) 写一份 YAML 配置

复制 `schema_gen/configs/example.yaml` 改成 `schema_gen/configs/<project>.yaml`：

```yaml
project_name: allylic_amination
usage_scope: 机理库

domain_prefer_file: ../../domain_prefer/allylic_amination.txt
output_dir: ../../schema_output/allylic_amination
csv_filename: refined_schema_allylic_amination.csv

llm:
  api_key:   # 留空，私信发
  base_url: http://43.153.42.7:3001/v1
  schema_model: gpt-5.4-pro      # 主模型（Step 1/3/3.5/4/5/6 都用它）
  architect_models: []           # 留空 → 3 个架构师线程也全用 gpt-5.4-pro
  endpoint: responses            # gpt-5.4-pro 是 reasoning 模型，必须走 Responses API
  temperature: 0.2

pipeline:
  num_architects: 3              # Step 2 并行架构师数，YAML 唯一来源；不写则默认 3
  enable_clustering: true
  resume: true
```

相对路径基于 YAML 自身目录解析；`${ENV_VAR}` 自动展开。

> **关于 `num_architects`**：架构师并发数完全由 YAML `pipeline.num_architects` 驱动（代码无硬编码默认），缺省 3 个。调整这个值会同步改变 Step 2 并发线程数和 `_intermediate/step2_architect_{1..N}.json` 中间产物数量。

#### (6c) 跑

```bash
# 安装额外依赖（pyyaml 已加进 requirements.txt）
pip install -r requirements.txt

# 跑
python -m schema_gen --config schema_gen/configs/example.yaml
```

常用覆盖（无需改 YAML）：

| 参数 | 说明 |
| ---- | ---- |
| `-c / --config <path>` | （必填）YAML 配置路径 |
| `--schema-models <m>` | 覆盖 LLM。第一个 = 主模型（跑 Step 1/3/3.5/4/5/6），其余 = 架构师池（仅跑 Step 2，按序循环分给 `num_architects` 个并发线程）。每项可写 `model` 或 `model:endpoint` |
| `--output-dir <path>` | 覆盖输出目录 |
| `--csv-filename <name>` | 覆盖 CSV 文件名 |
| `--domain-prefer-file <path>` | 覆盖领域偏好文件 |
| `-v / --verbose` | 打开 DEBUG 日志 |

> **主模型 vs 架构师**：主模型决定整条流水线的"主干"质量（拆解 / 归纳 / 反思 / 聚类都靠它）；架构师只在 Step 2 并发生成字段建议，由主模型在 Step 3 取并集。默认 `architect_models: []` 时所有架构师线程也用 `schema_model`，本仓库当前统一用 `gpt-5.4-pro`（走 Responses API）。

示例 —— 命令行覆盖把主模型 + 全部架构师都强制成 gpt-5.4-pro:responses（等价于 YAML 里 `schema_model: gpt-5.4-pro` + `architect_models: []` + `endpoint: responses`）：
```bash
python -m schema_gen \
    --config schema_gen/configs/example.yaml \
    --schema-models "gpt-5.4-pro:responses"
```

#### (6d) 输出

```
schema_output/allylic_amination/
├── refined_schema_allylic_amination.csv   # 最终对外产物
└── _intermediate/                          # 各 step 的 checkpoint(供断点续跑/排查)
    ├── step1_decomposition.txt
    ├── step2_architect_1.json ... step2_architect_3.json
    ├── step3_aggregation.json
    ├── step3_5_expansion.json
    ├── step4_reflection.json
    ├── step5_clustering.json
    └── step6_subdomain_classification.json
```

`resume: true`（默认）时，重跑会跳过已完成的 step；想完全重新生成就删掉 `_intermediate/`。

---

### 步骤 ⑦：LLM 结构化提取 —— `llm_extract/`

`llm_extract/` 承接步骤 ④ 产出的 Markdown 文献目录和步骤 ⑥ 产出的 Schema CSV，
`extract.py`: 串起 **config_loader → domain_prefer → schema_loader → paper_scanner → classify → extract/ metadata_fetcher /reference_fetcher三路并发 → kb_aggregator → knowledge_base.json** 完整流水线，断点续跑（按 paper_uid）、并发，输出可直接供 RAG / 知识库服务消费的结构化 JSON。


#### (7a) 写一份 YAML 配置

复制 `llm_extract/configs/extract_config_aero_p1_local.yaml` 改成 `llm_extract/configs/<project>.yaml`：

```yaml
llm:
  base_url: "http://43.153.42.7:3001"
  api_key:  "sk-..."             # 或通过环境变量传入

schema:
  path:               "/path/to/refined_schema_allylic_amination.csv"   # 步骤 ⑥ 产物
  domain_prefer_file: "/path/to/mg.txt"                                  # 同 domain_prefer/
  domain_family:      "magnesium_alloy"
  # usage_scope:      "机理库"           # 可选，按 CSV 里的 usage_scope 列过滤字段
  # key_focus:        "transmission_fss" # 可选，启用内置 KEY FOCUS overlay

data_sources:
  - name: "my_corpus_md"
    type: "md_dir"
    path: "/path/to/md/dim1"     # 步骤 ④ download --output-dir 产出目录
    extract_references: true
    inject_fields:
      data_source: "LocalLib"
      domain: "magnesium_alloy"
```

数据源 `path` 支持 `year-journal-doi/` 命名（含 `full.md` + `*_content_list.json`），也支持普通 Markdown 目录；`extract_references: true` 会额外解析每篇论文的参考文献列表。除 `type: md_dir` 外还支持 `type: jsonl`（配 `field_mapping` 把 JSONL 字段映射到论文标题/正文）。

#### (7b) 运行方式

```bash
# 基本运行（在 gen_key/ 目录下执行）
python llm_extract/extract.py \
    --config llm_extract/configs/my_extract.yaml \
    --output ./output \
    --concurrency 16 \
    --sample 20
```

完整参数说明：

| 参数 | 默认 | 说明 |
| ---- | ---- | ---- |
| `--config` | （必填） | YAML 配置文件路径 |
| `--output` | （必填） | 输出目录 |
| `--kb-output` | `<output>/knowledge_base.json` | 自定义最终 KB 路径 |
| `--models` | `claude-haiku-4-5-20251001` | 提取模型（必须是 claude haiku 系列） |
| `--classifier` | `gpt-5-nano` | 分类模型（不限 haiku，可用任意模型） |
| `--skip-classify` | 关 | 跳过 classify，所有论文都送 extract |
| `--skip-metadata` | 关 | 跳过 OpenAlex / S2 抓取 |
| `--run-s2` | 关 | metadata 阶段同时跑 Semantic Scholar（默认只跑 OpenAlex） |
| `--key-focus` | 无 | 注入专题提取 overlay，详见下文 |
| `--domain-prefer-file` | 无 | 覆盖 YAML `schema.domain_prefer_file` |
| `--concurrency` | `16` | 并发 paper 任务数 |
| `--sample` | 无 | 随机采样 N 篇（调试用） |
| `--sample-seed` | `42` | `--sample` 随机种子 |
| `--verbose` | 关 | 打开 DEBUG 日志 |

#### (7b-1) `--key-focus` 说明

`--key-focus` 在每篇论文的 extract prompt **末尾叠加**一段额外提取要求，不替换 schema，而是强调某些专题字段必须深挖（优先级高于 schema 一般字段）。

**内置主题：`transmission_fss`**（航天 EM 透过/滤波关键三件套）

| 子主题 | 适用场景 | 必须抽取的代表字段 |
| ------ | -------- | ------------------ |
| **A. 增透 / High Transmission** | 透过率提升、匹配层、抗反射涂层 | `frequency_band`、`transmittance_peak`、`return_loss_dB`、各层 `layer_thickness` / `dielectric_constant` / `loss_tangent` |
| **B. 透波 / Wave-Transparent（雷达罩）** | 雷达罩、导引头窗口、低损耗介质 | `insertion_loss_dB`、`boresight_error_mrad`、`wall_structure`、介质 `ε_r` / `tan δ`、热-电磁耦合 |
| **C. FSS / 频率选择表面** | FSS、metasurface、超材料滤波层 | `unit_cell_geometry`、`lattice_periodicity`、`filter_type`、`angular_stability`、`active_tuning` |

严格规则：每个字段**必须给具体数值 + 单位**（图表数据优先读图取数，如 `T_max=0.95 @ 10 GHz`）；论文未明确出现的字段严格留空，不瞎猜。

用法：

```bash
# 使用内置主题
python llm_extract/extract.py --config ... --output ... --key-focus transmission_fss

# 使用自定义 txt（内容格式自由）
python llm_extract/extract.py --config ... --output ... --key-focus ./prompts/my_focus.txt
```

也可在 YAML 里固化：
```yaml
schema:
  key_focus: ./prompts/my_focus.txt
```

新增主题只需在 `llm_extract/core/key_extract_prompt.py` 的 `TOPICS` dict 里加一条即可。

#### (7c) 输出结构

```
output/
├── run_logs/                            # 每次运行的日志（按时间戳分文件）
├── filter_results.jsonl                 # classify 阶段结果（is_relevant / domains / reason）
├── references.jsonl                     # 每篇论文的本地参考文献解析结果
├── metadata.jsonl                       # OpenAlex + S2 的 citation_info
├── per_model/<model_name>/results.jsonl # 每模型每篇 paper 的结构化提取
└── knowledge_base.json                  # ★ 最终产物，可直接喂给 RAG / kb_mvp
```

**`results.jsonl` 每行结构：**

```json
{
  "paper_uid": "abcd1234...",
  "title": "...",
  "model": "claude-haiku-4-5-20251001",
  "domains": ["casting magnesium alloys"],
  "source": {
    "source_type": "md_dir",
    "source_dir": "my_corpus_md",
    "source_ref": "C:/.../1988-Applied Physics Letters-10.1063_1.99097",
    "doi": "10.1063/1.99097",
    "year": 1988,
    "journal": "Applied Physics Letters"
  },
  "mechanism": {
    "paper_uid": "...",
    "paper_id": "...",
    "problem_context": "...",
    "study_process_description": "...",
    "design_optimization_logic": "...",
    "physical_mechanism": "...",
    "fabrication_process": "...",
    "design_method": "...",
    "influence_analysis": "...",
    "extracted_data": { "...": ["..."] }
  },
  "elapsed_ms": 12345
}
```

**`knowledge_base.json` 结构：**

`paper_id`（`P0001` 起编号）→ `{ paper_uid, paper_title, doi, year, journal, authors, domains, extracted_data, problem_context, study_process_description, design_method, design_optimization_logic, fabrication_process, physical_mechanism, influence_analysis, references, citation_info }`

> 📌 **引用 / DOI / 年份从这里来**：上面的 `doi` / `year` / `references` / `citation_info` 正是"extract / metadata / references **三路并行**"里后两路的产物（references 纯正则抽本地参考文献，metadata 走 OpenAlex/S2 补 doi/year/citations）。步骤⑧建库时一并入库，所以下游问答的答案**本来就带引用、年份、DOI**——无需依赖步骤⑨ (9a) 那个可选的外部 `state_db_path`（后者只是额外的"按 content_sha1 精确定位源 .md 全文"增强，本工具链不产出它）。

#### (7d) 抽取字段规格

每篇论文的 `mechanism` 对象包含以下 7 个自然语言字段：

| 字段名 | 字数要求 | 内容定位 |
| ------ | -------- | -------- |
| `problem_context` | 200–250 词 | 问题是什么、为什么重要、物理背景、性能缺口 |
| `study_process_description` | 300–400 词 | 完整实验/仿真流程、所有参数扫描、表征步骤 |
| `design_optimization_logic` | 200–300 词 | 设计选择理由、优化轨迹、权衡取舍 |
| `physical_mechanism` | 200–300 词 | 参数→物理过程→性能的完整因果链 |
| `fabrication_process` | 180–300 词 | 纯制备步骤，含温度/压力/时间等工艺参数 |
| `design_method` | 150–200 词 | 从需求到验证的设计工作流 |
| `influence_analysis` | 220–300 词 | ≥5 个定量参数-性能灵敏度关系（必须含数值） |

完整 JSON 输出示例：

```json
{
  "paper_title": "...",
  "problem_context":           "<200-250 词自然语言>",
  "study_process_description": "<300-400 词自然语言>",
  "design_optimization_logic": "<200-300 词自然语言>",
  "physical_mechanism":        "<200-300 词自然语言>",
  "fabrication_process":       "<180-300 词自然语言>",
  "design_method":             "<150-200 词自然语言>",
  "influence_analysis":        "<220-300 词自然语言>",
  "extracted_data": { ... }
}
```

#### (7e) 断点续跑

- 启动时自动读取 `per_model/<model>/results.jsonl` / `filter_results.jsonl` / `metadata.jsonl` / `references.jsonl` 中已有的 `paper_uid`，再次运行只处理增量。
- `paper_uid` = SHA1(norm_title + content[:2000])[:16]，跨 run 稳定。

---

### 步骤 ⑧：构建 KB + KG 双轨知识底座 —— `build_kb_kg.py`

步骤 ⑦ 产出的 `knowledge_base.json` 是「结构化知识列表」，但要支持下游 RAG 问答还需要：

- **KB 轨道**（`kb_mvp/`）：把每篇论文的 7 个叙述字段切成 chunks → BGE-M3 dense embedding → FAISS HNSW 索引 + jieba BM25 倒排，用于"问什么 → 找最相关的段落"。
- **KG 轨道**（`scientific_kgqa/`）：从 `extracted_data` + 7 个叙述字段里抽实体/关系，构建子图存 SQLite，用于"问 X → 推 Y / 找 X 关联到的所有论文"。

`build_kb_kg.py` 把这两条轨道一键串起来。

#### (8a) 准备输入与换领域

| 输入 | 来源 | 必需 |
| ---- | ---- | ---- |
| `knowledge_base.json` | 步骤 ⑦ `llm_extract` 产出 | ✅ KB / KG 都要 |
| `refined_schema_*.csv` | 步骤 ⑥ `schema_gen` 产出 | ✅ 仅 KG 必需（KB 暂未用 schema 约束）|

> `build_kb_kg.py` 会把这两份文件**自动拷到默认位置**（`scientific_kgqa/data/knowledge_base.json`、`scientific_kgqa/data/schema.csv`）——因为 `kb_mvp/src/config.py` 不支持 CLI 覆盖路径，只认默认位置。

**换领域：建图引导词只有一处要改**。建图时抽概念用的 system 引导词放在 `scientific_kgqa/configs/prompts_em.yaml` 的 `concept_extraction.system` 字段（当前内容是航天电磁示例）：

- 不传 `--kg-prompts`：默认加载 `prompts_em.yaml`；连该 key 都缺时回退代码内置的领域中立模板（仍能跑，只是没有领域偏向）。
- 换领域：把 `concept_extraction.system` 的措辞改成你的领域——直接改 `prompts_em.yaml`，或复制成新文件用 `--kg-prompts 你的文件.yaml` 指定。**`--schema` 与 `--kg-prompts` 必须是同一领域。**
- 同一份 `prompts_em.yaml` 还有 `qa.*` 段（查询期 5 段引导词），归步骤 ⑨ 用，见 ⑨「查询期领域配置」。

#### (8b) 凭据

KB 需要 embedding 服务、KG 需要 LLM 网关，两对凭据**默认从 `.env` 读**（入口脚本启动自动加载，见顶部「凭据约定」），也可用 CLI 临时覆盖：

| CLI 参数 | `.env` 兜底 | 用途 |
| ---- | ---- | ---- |
| `--embed-base-url` / `--embed-api-key` | `EMBED_BASE_URL` / `EMBED_API_KEY` | BGE-M3 embedding 服务（建 KB 必需）|
| `--llm-base-url` / `--llm-api-key` | `LLM_BASE_URL` / `LLM_API_KEY` | LLM 网关（KG 概念/关系抽取）|
| `--llm-model` | `LLM_MODEL`（默认 `gemini-3.1-pro-preview`）| LLM 模型名 |

> `scientific_kgqa.cli_build` 内部读的 `ANTHROPIC_BASE_URL` / `ANTHROPIC_AUTH_TOKEN` 会**自动复用** `--llm-base-url` / `--llm-api-key`，无需另配。

#### (8c) 跑

> ⚠️ 下面命令是**演示参数形态**，混了两个领域：`--schema` 是化学库（allylic_amination），默认引导词却是航天电磁示例。正式换领域时 `--schema` 与建图引导词要同领域（见 (8a)）。

构建本身**永远在本地完成**（embedding / FAISS / 建图都在本机算）；区别只在「建完要不要顺手推 Ceph、要不要清本地」。三种常见跑法：

**① 只在本地建（默认，最常用）**

```bash
# 全量重建 KB + KG（首次跑用 --force 清掉空白库；--kg-prompts 不写则默认用 prompts_em.yaml）
python build_kb_kg.py \
    --kb-json ./output/knowledge_base.json \
    --schema  ./schema_output/allylic_amination/refined_schema_allylic_amination.csv \
    --force

# 只建 KB（不需要 schema）—— 先把向量检索跑通
python build_kb_kg.py --kb-json ./output/knowledge_base.json --skip-kg --force

# 只建 KG（KB 已建过）
python build_kb_kg.py --kb-json ./output/knowledge_base.json --schema ./.../refined_schema.csv --skip-kb

# 无网 / embedding API 不稳：改用本地 BGE-M3 模型（缺模型自动从 HuggingFace 拉 BAAI/bge-m3）
#   也可一次性预下：huggingface-cli download BAAI/bge-m3 --local-dir retrieval_weights/models/bge-m3
python build_kb_kg.py --kb-json ./output/knowledge_base.json --skip-kg --use-fast-ingest --force
```

**② 本地建 + 同时推远程（本地、远程各留一份）**

```bash
python build_kb_kg.py \
    --kb-json ./output/knowledge_base.json \
    --schema  ./schema_output/.../refined_schema.csv \
    --force \
    --content-store-remote \   # 源文 full.md / PDF 推 Ceph
    --push-artifacts            # 向量索引 / 图谱 DB 等大产物推 Ceph
```

**③ 本地建 + 推远程 + 清本地大文件（构建机 / 服务机分离，省磁盘）**

```bash
python build_kb_kg.py \
    --kb-json ./output/knowledge_base.json \
    --schema  ./schema_output/.../refined_schema.csv \
    --force \
    --content-store-remote --prune-local \    # 推完删本地 full.md/PDF，只留 _manifest.json 骨架
    --push-artifacts       --prune-artifacts   # 推完删本地大产物，保留 *_cache.json 供下次增量
# 服务机随后用 PULL_ARTIFACTS=1 python server.py 自动拉回（见 (8f)）
```

> **推送是接在构建之后的尾部动作，没有「纯推送」模式**：库已建好只想重传，就去掉 `--force`（不清库、走 `embedding_cache.json` / `llm_cache.json` 缓存重跑、不重调 API，再上传）。②③ 用到的远程参数（桶布局 / 凭据 / `--*-remote` / `--prune-*` 全解）见 (8f)。
>
> `fast_ingest.py` 也能单独调用，额外接受 `--concurrency`（默认 4）、`--batch-size`（默认 64，二者仅 API 模式生效；本地模式 batch_size 自动 CPU=128 / GPU=256）、`--use-api`（强制走远程 API）、`--bm25-only`（只重建 BM25 倒排）。

**核心参数**（远程存储相关参数见 (8f)）：

| 参数 | 说明 |
| ---- | ---- |
| `--kb-json` | （必填）`knowledge_base.json` 路径 |
| `--schema` | `refined_schema_*.csv` 路径，建 KG 必需 |
| `--domain-prefer-file` | `domain_prefer/<project>.txt`；建 KG 时把领域上下文（Subdomains/Keywords/Queries）注入抽取 prompt 做偏向。**缺省用通用 prompt，跨领域可直接跑** |
| `--kg-prompts` | KG 引导词 YAML，不传默认 `prompts_em.yaml`，缺 key 回退内置中立模板（见 (8a)）|
| `--skip-kb` / `--skip-kg` | 跳过 KB / KG 构建 |
| `--force` | 全量重建，清空旧库（与 `--incremental` 互斥）|
| `--incremental` | KB 增量：只 embed 新增 chunk、复用旧向量缓存，再重建 FAISS+BM25（见 (8e)）|
| `--use-fast-ingest` | KB 走本地 BGE-M3（`fast_ingest.py`）替代远程 embedding API |
| `--embed-base-url` / `--embed-api-key` / `--llm-base-url` / `--llm-api-key` / `--llm-model` | 凭据覆盖，见 (8b) |
| `--kg-db` / `--kg-retriever` | KG 输出路径，默认 `scientific_kgqa/artifacts/` 下的 `kgqa.db` / `retriever.pkl` |
| `--kg-reset` | 只重置 KG（独立于 `--force`）|
| `--no-llm` | KG 跳过 LLM 抽取，只走规则抽取（快但召回低）|
| `--llm-workers` | KG LLM 抽取并发数，默认 1，API 配额够时调大 |

#### (8d) 输出结构

```
gen_key/
├── kb_mvp/
│   ├── data/
│   │   └── kb.db                      # 论文元数据 + chunks（SQLite + JSON1）
│   └── index/
│       ├── faiss.index                # FAISS HNSW 向量索引
│       ├── embeddings.npy             # 归一化向量矩阵
│       ├── bm25.pkl                   # jieba 分词 BM25 倒排
│       └── chunk_ids.json             # FAISS idx → chunk_id 映射
└── scientific_kgqa/
    ├── data/
    │   ├── knowledge_base.json              # build_kb_kg.py 自动落
    │   ├── schema.csv                       # build_kb_kg.py 自动落
    │   └── content_store/                   # 可移植内容库（git-ignored）
    │       └── <paper_id>/
    │           ├── full.md                  #   Markdown 全文（--prune-local 后删除）
    │           ├── *.pdf                    #   原始 PDF（--prune-local 后删除）
    │           └── _manifest.json           #   文件清单（始终保留，远程拉取的索引）
    └── artifacts/
        ├── kgqa.db                    # 实体 + 关系 + 子图（SQLite）
        ├── retriever.pkl              # 离线检索器（BM25 + TF-IDF 混合）
        └── llm_cache.json             # LLM 抽取响应缓存（断点续跑）
```

> **构建后快速抽查**：可用 `scientific_kgqa` 自带的命令行直接问 KG（不经步骤 ⑨ 的完整管线），验证图谱可用：
> ```bash
> # 直接构建（独立于 build_kb_kg.py 的等价底层入口）
> python -m scientific_kgqa.cli_build --reset --schema data/schema.csv \
>   --kb data/knowledge_base_new.json --db artifacts/kgqa.db --retriever artifacts/retriever.pkl
> # 直接问答抽查（机理 / 参数影响 / 演化 / 引用链 四类典型问题）
> python -m scientific_kgqa.cli_ask --query "哪些机制有助于提升 angular stability 并保持较低 insertion loss？"
> python -m scientific_kgqa.cli_ask --query "air gap thickness 对 transmission resonance 有什么影响？"
> ```
> 构建日志会打印 `papers / nodes / edges` 统计；人工抽查重点：**论文回链率**（证据能否定位到本地 paper）、**Concept 粒度**（是否过碎）、**数值字段单位**（dB/%/mm 是否混用）、**演化边质量**（`CONCEPT_EVOLVES` 是否合理）。抽查不理想 → 回步骤 ⑥/⑦ 调 schema / 抽取逻辑再刷库。

#### (8e) 断点续跑 / 增量

- **KB 增量**（远程 API 与本地 fast_ingest 两条路径都支持）：加 `--incremental` —— DB 里已建过的 chunk 跳过，只对**新增 chunk** 调 embedding（旧向量走 `index/embedding_cache.json` 缓存复用，零额外 API），再用全量 chunks 重建 FAISS + BM25。`--incremental` 与 `--force` 互斥。
  ```bash
  # 远程 embedding API 路径（默认）
  python build_kb_kg.py --kb-json ./output/knowledge_base.json --skip-kg --incremental
  # 本地 BGE-M3 路径
  python build_kb_kg.py --kb-json ./output/knowledge_base.json --skip-kg --use-fast-ingest --incremental
  ```
  不加任何标志重跑 = 全量重建但不清库（`INSERT OR REPLACE` 幂等）；首次建库或想彻底清空用 `--force`。
- **KG 续跑**：`scientific_kgqa.cli_build` 默认 **续跑友好** —— 已抽过的论文走 `llm_cache.json` 命中，跳过 LLM 调用；要重新抽传 `--kg-reset` / `--force`。

---

#### (8f) 可选：把源文 / 大产物存到 Ceph（远程存储）

默认建库只落本地，磁盘够用就不必管这节。需要**磁盘瘦身**（10 万篇源文约 35 GB）或**构建机 / 服务机分离**（构建完推桶里就销毁构建环境，服务机启动按需拉）时，可把文件推到步骤⑤同一个 Ceph 桶。桶里存两类数据，靠前缀隔离、共用一次 rclone 配置：

```
xlc-hdd2:hangtian-kxfx/
├── content_store/<paper_id>/   ← 源文：full.md + PDF + _manifest.json
└── artifacts/                  ← 大产物：向量索引 / BM25 / 图谱 DB
    ├── kb_index/   (faiss.index, bm25.pkl, chunk_ids.json)
    ├── kb_data/    (kb.db)
    └── kgqa/       (kgqa.db, retriever.pkl)
```

**为什么需要 content_store（解决跨机溯源失效）**：`knowledge_base.json` 里每篇的 `source.source_ref` 是步骤④解析目录的**绝对路径**，跨机部署 / 原目录被移走后查询期就定位不到源文。建库时（语料还在）把每篇 `full.md` + PDF 按 `paper_id` 归档进 `content_store/`，artifacts 自包含、可随部署搬走；查询期 [EvidenceResolver](search/gen_key/retrieval_integration/modules/m2_internal_retrieval/evidence_resolver.py) 优先读它，`source_ref` 仅作同机兜底。`_manifest.json`（每篇 ~60 B，**始终保留**）记录有哪些文件在远端，省去每次 list。该目录已 git-ignored。

##### 凭据：自动读 rclone.conf，零额外配置

`content_store_remote.py` 自动从步骤⑤配好的 `rclone.conf`（`~/.config/rclone/`，Windows `%APPDATA%\rclone\`）的 `xlc-hdd2` 远端提取 endpoint / access / secret 初始化 boto3。CI / 多桶部署可用环境变量覆盖：

| 环境变量 | 默认 | 说明 |
| -------- | ------ | ---- |
| `CEPH_ENDPOINT` / `CEPH_ACCESS_KEY` / `CEPH_SECRET_KEY` | 自动读 rclone.conf | 显式指定 S3 端点 / 凭据 |
| `CEPH_BUCKET` | 从 `CONTENT_STORE_REMOTE` 解析 | 桶名，如 `hangtian-kxfx` |
| `CONTENT_STORE_REMOTE` | `xlc-hdd2:hangtian-kxfx` | rclone 远端+桶 |
| `CONTENT_STORE_REMOTE_PREFIX` | `content_store` | 源文在桶内前缀 |
| `ARTIFACTS_REMOTE_PREFIX` | `artifacts` | 大产物在桶内前缀 |
| `RCLONE_REMOTE_NAME` / `RCLONE_BIN` | `xlc-hdd2` / `rclone` | rclone 远端名 / 可执行路径 |
| `CONTENT_STORE_PATH` | `scientific_kgqa/data/content_store` | 服务端本地缓存根目录 |
| `PULL_ARTIFACTS` | 关 | 设 `1`/`true`/`yes` → server 启动自动拉缺失大产物 |

##### 远程存储相关 CLI 参数

| 参数 | 说明 |
| ---- | ---- |
| `--content-store` | 本地内容库目录，默认 `scientific_kgqa/data/content_store`（建库默认就物化到这里）|
| `--skip-content-store` | 不物化内容库（查询期溯源回退 `source_ref` 绝对路径，跨机可能失效）|
| `--content-store-remote` | 物化后用 rclone copy（`--transfers 16`）把内容库增量上传 Ceph |
| `--push-artifacts` | 把向量索引 / 图谱 DB / 知识库 DB 等大产物推 Ceph |
| `--prune-local` | 配合 `--content-store-remote`：上传成功后删本地 `full.md`/PDF，只留 `_manifest.json` 骨架 |
| `--prune-artifacts` | 配合 `--push-artifacts`：上传成功后删本地大产物（`faiss.index`/`bm25.pkl`/`embeddings.npy`/`kb.db`/`kgqa.db`/`retriever.pkl`），保留 `*_cache.json` 供增量构建 |
| `--remote-base` | rclone 远端+桶，默认 `xlc-hdd2:hangtian-kxfx`（或 `CONTENT_STORE_REMOTE`）|
| `--remote-prefix` | 源文桶内前缀，默认 `content_store`（或 `CONTENT_STORE_REMOTE_PREFIX`）|
| `--artifacts-prefix` | 大产物桶内前缀，默认 `artifacts`（或 `ARTIFACTS_REMOTE_PREFIX`）|

##### 构建机：推

基本推送命令（建库时顺手 `--content-store-remote` 推源文、`--push-artifacts` 推大产物，各自加 `--prune-*` 省磁盘）见 (8c) 的 ②③。这里只补一个**非默认桶 / 前缀**（多项目隔离）的例子：

```bash
python build_kb_kg.py ... --content-store-remote --push-artifacts \
    --remote-base xlc-hdd2:my-bucket \
    --remote-prefix projectA/content_store --artifacts-prefix projectA/artifacts
```

> rclone 须在 PATH 里（步骤⑤已装）；不传 `--content-store-remote` / `--push-artifacts` 时只建本地库，rclone 不可用只 warn 不报错。

##### 服务机：拉

`PULL_ARTIFACTS=1` 时 server 启动检查 6 个大产物（`faiss.index` / `bm25.pkl` / `chunk_ids.json` / `kb.db` / `kgqa.db` / `retriever.pkl`），**缺几个拉几个**（`pull_artifacts_parallel`，boto3 multipart 分片并发），已存在的跳过：

```bash
PULL_ARTIFACTS=1 python server.py
# 大产物从 Ceph 拉；查询期 /files 端点再按需拉 full.md（首次 ~70ms，之后命中本地缓存）
# 非默认前缀：PULL_ARTIFACTS=1 ARTIFACTS_REMOTE_PREFIX=projectA/artifacts python server.py
```

> **推远端但保留不删的文件**（供下次增量构建）：`embedding_cache.json`（`kb_mvp/index/`，embedding 缓存）、`chunk_ids.json`（`kb_mvp/index/`，FAISS→chunk_id 映射）、`llm_cache.json`（`scientific_kgqa/artifacts/`，KG 抽取缓存）。

##### 性能（实测，本机 → pjlab Ceph）

| 操作 | 延迟 |
| ---- | ---- |
| `rclone copy` 全库上传（10 万篇 ~35 GB，`--transfers 16`）| ~12 分钟 |
| boto3 冷连接首次 GET | ~64 ms |
| boto3 热连接 GET（连接池复用）| ~10–35 ms |
| 5 篇并发拉取（热连接）| ~70–140 ms |
| 旧方案 rclone subprocess 逐篇拉（已废弃）| ~1267 ms/篇 |

查询期 EvidenceResolver 解析一批论文时会**一次性并发预拉**所有需远端拉取的文件（`fetch_files_parallel`，`ThreadPoolExecutor max_workers=8`），对每次查询延迟影响约 70–140 ms（缓存命中后 < 1 ms）。`/files/{uid}.md` 三级查找（会话内 `_pdf_index` → 本地 `content_store` → 远端 boto3）**服务重启后依然可用**，不依赖本次会话是否跑过 `/query`。

---

### 步骤 ⑨：检索增强问答 API —— `retrieval_integration/` + `server.py`

KB+KG 建好之后，`retrieval_integration/` 把两条轨道融合成一个 RAG 流水线，对外是 HTTP / SSE 接口。

#### 原理 ①：6 模块管线（带回环）

```
            用户 query
                │
                ▼
  ┌─ m1_schema_parser ─────────────────────────────────────────────┐
  │   解析 query → 抽取「意图字段 / 任务类型 / 功能类型」             │  配置：schema CSV（约束抽哪些字段）
  │   命中 schema 之外的字段 → 丢进知识回流候选池(new_fields)        │        prompts.yaml（m1 提示）
  └────────────────────────────────┬───────────────────────────────┘
                                   ▼
  ┌─ m2_internal_retrieval ── 双轨检索 ──────────────────────────────┐
  │   ├─ KB 三路融合：metadata + dense(FAISS) + sparse(BM25) → top-k   │  数据：步骤⑧ kb_mvp/index/*
  │   │     chunks（权重默认 0.2 / 0.6 / 0.2，见 kb_mvp/config.py）  │
  │   └─ KG：seed 映射 → LLM 扩种 → query-aware PPR → beam 路径游走     │        步骤⑧ kgqa.db + retriever.pkl
  │          → posting chunks → 论文集合（详见下方「KG 路径游走」）     │
  │   ▼ 两轨结果汇合后，对论文做 task-aware 重排 ★                    │  配置：(9b) expert_weights_em.yaml
  │     （按 m1 抽出的 task/功能类型，用专家权重给论文打分；          │        （查询期读取；graph_walk 段还驱动 KG 游走）
  │      该配置字段与当前 schema 无交集时自动降级回通用打分）          │
  └────────────────────────────────┬───────────────────────────────┘
                                   ▼
  ┌─ m3_answer_validator + m3b_critic ── 答案验证 / 反驳 ─────────────┐
  │   证据够不够、自洽不自洽；判定 KB 内容不足 → 候选池(new_papers)   │  配置：prompts.yaml（m3 / critic）
  └───────────────┬─────────────────────────────┬───────────────────┘
          够 │ 直接合成                  不够 │
             │                                ▼
             │                ┌─ m4_plan_generator ── 生成新检索计划 ─┐
             │                └──────────────┬───────────────────────┘
             │                               ▼
             │                ┌─ m5_external_retrieval（可选）────────┐
             │                │   星河 ROS / OpenAlex 等外部 API 兜底  │
             │                └──────────────┬───────────────────────┘
             ▼                               ▼
  ┌─ m6_answer_generator ── 合成最终答案 + 引用 ─────────────────────┐
  │                                                                  │  配置：prompts.yaml（m6 persona）
  └──────────────────────────────────────────────────────────────────┘

  知识回流闭环：m1/m3 落到候选池的 new_fields / new_papers
    → new_fields  审核后演化 schema CSV → 回步骤⑦ 重抽 → 回步骤⑧ 刷库
    → new_papers  回步骤②/③ 补检索 + 下载            （详见 (9g)）
```

要点：

- **m1 是"配置驱动"的入口**：它既抽常规意图字段（受 schema CSV 约束），也抽**任务类型 / 功能类型**——这两样正是查询期 (9b) `expert_weights_em.yaml` 打分要用的输入。
- **两轨在 m2 汇合**：KB 三路融合（metadata 精确匹配 + dense 向量 + sparse BM25）给"最相关段落"、KG 路径游走给"X 关联到的论文集合"，融合后用 (9b) 的专家权重做 **task-aware 重排**。接缝在于：重排配置引用的字段池来自步骤⑧建图产物的 `schema.csv`，但配置本身在查询期 (9b) 填写、查询期生效。
  > **"三路"指哪三路**：早期是 dense+sparse 两路，现默认开启 `ENABLE_THREE_WAY_FUSION`（[kb_mvp/src/config.py](search/gen_key/kb_mvp/src/config.py)），再加一路 **metadata 精确匹配**（标题/字段命中打分）。三路权重默认 `metadata 0.2 / dense 0.6 / sparse 0.2`，融合方式为各路分数 min-max 归一化后加权求和（非 RRF）。
- **m3→m4→m5 是"不够才走"的兜底链**：证据充分就直接到 m6；不足才生成新计划、调外部 API。
  > **m3b_critic 默认关闭**：`default_config.yaml` 里 `m3b_critic.enabled: false`，默认部署下 critic（LLM 反驳打分）不参与；需要时在配置里打开并重启 server。
- **m1/m3 同时是回流入口**：问到 schema 没有的字段、或判定本地知识不足，分别沉淀成新字段 / 新文献候选，喂回 (9g) 的演化闭环。


#### 原理 ②：KG 路径游走（`deep` 通道核心）

`fast` 通道只跑 KB 三路融合就直接合成；**`deep` 通道才会启动 KG 路径游走**——这也是"问机理 / 演进 / 多跳"类问题更准的原因。游走全过程在 [scientific_kgqa/src/scientific_kgqa/qa_engine.py](search/gen_key/scientific_kgqa/src/scientific_kgqa/qa_engine.py) 的 `answer()` 里，分 7 步：

```
  query（中文）
    │
    ▼  ① 翻译：_translate_query → 英文（KG 节点 / retriever 都是英文）
    ▼  ② 解析：parse_query → intent（mechanism/optimization/evolution/...）
    │        + task_type + functional_type + 年份范围 + chunk_types
    ▼  ③ 种子映射 map_seeds（三级兜底）：
    │      a. 别名/精确名直接命中 graph 节点
    │      b. LLM 抽 query 核心术语 → 各术语单独 embedding 匹配节点（主路径）
    │      c. seed < 3 时整段 query embedding 语义兜底（min_sim=0.40）
    ▼  ④ query-aware PPR（personalized_ppr）：
    │      从 seed 出发带重启随机游走，mass 偏向「与 query 语义相似」的概念
    │      （alpha=0.15 重启概率，steps=10 跳，prune_top_n=3000）
    │      → 取 PPR top-250 节点
    ▼  ⑤ 候选节点 = PPR top-250 ∪ 种子 2 跳邻居
    ▼  ⑥ beam 路径游走（beam_search）：
    │      每个 seed 独立 beam（per_seed_width=8，beam_width=24，max_hops=5），
    │      按 path_score（边权 0.5 + intent 偏好 0.3 + 目标节点稀有度 0.2）排序，
    │      避免单条高分主干垄断 → 产出 reasoning_paths（推理链）
    ▼  ⑦ 落 chunk：路径节点的 posting → candidate_chunk_ids
           → retriever 在候选内检索（primary topk=60）+ 高优 chunk_type 全库兜底（secondary topk=40）
           → 合并去重 → rerank → 论文集合 + evidence
```

**这些参数都在 `scientific_kgqa/configs/expert_weights_em.yaml` 的 `graph_walk` 段**（由 (9b) 的模板合成，缺失则回退 [walk.py](search/gen_key/scientific_kgqa/src/scientific_kgqa/walk.py) 内置默认；换领域一般不用动）：

| 参数 | 默认 | 作用 |
| ---- | ---- | ---- |
| `ppr.alpha` | `0.15` | PPR 重启概率，越大越贴着种子（越小越发散） |
| `ppr.steps` | `10` | PPR 迭代跳数（alpha=0.15 时 ~10 跳收敛） |
| `ppr.prune_top_n` | `3000` | 每跳保留的最高 mass 节点数（防超节点垄断） |
| `beam.beam_width` | `24` | 全局 beam 宽度 |
| `beam.per_seed_width` | `8` | 每个 seed 内部 beam 宽度（鼓励探索深度而非广度） |
| `beam.max_hops` | `5` | 路径最大跳数 |
| `path_score.{edge_weight,intent_bonus,dst_specificity}` | `0.5/0.3/0.2` | 路径打分三项系数 |

> `fast` 与 `deep` 由 `mode` 决定（见 (9d)）：`fast` 跳过 ③~⑥，只走 KB；`deep` 先跑完整 KG 游走，再把路径节点桥接成 KB 白名单二次检索（pipeline 的 `_run_deep`：KG-only → S3 桥接 → S4 白名单内三路融合 → S5 反向归并 → S6 出答）。


#### (9·换领域必读)：换新领域要改哪些文件

> **换到新领域**（化学/材料/生物…）建新图谱时，按下表逐项处理——**「必改」的不改会跑错领域，「可选」的影响效果不影响能跑，「不用管」的有默认/自动降级**。

| 文件 | 所属步骤 | 换领域 | 改什么 / 为什么 |
| ---- | ---- | :--: | ---- |
| `domain_prefer/<项目>.txt` | ⑥⑦⑧ | **必改** | 你的关键词 + 子领域 + 科学问题；驱动 schema 生成、抽取、建图的领域偏向 |
| `schema_gen` 产出的 `refined_schema_*.csv` | ⑥ | **必改** | 换领域=换一套抽取字段；KG/KB/重排全靠它 |
| `scientific_kgqa/configs/prompts_em.yaml` | ⑧ | **可选** | 建图概念抽取的 system 引导词；不改用内置中立模板也能跑，改了召回更准。建库时 `--kg-prompts` 指定 |
| `scientific_kgqa/configs/expert_template_expert.yaml` | ⑨(9b) | **必改** | 专家评分表：本领域功能类型 / 维度子项 / 任务权重配比 |
| `scientific_kgqa/configs/expert_template_auto.yaml` | ⑨(9b) | **必改** | 词典 + schema 字段映射；先 `draft_auto_from_schema.py` 草拟，再人工审核 |
| `scientific_kgqa/configs/expert_weights_em.yaml` | ⑨(9b) | **勿手改** | 上面两份模板经 `build_expert_config.py` 合成；server 启动自动读，改了要重生成 + 重启 |
| `configs/retrieval/default_config.yaml` | ⑨(9a) | **看情况** | `kg_db_path` / `kg_retriever_path` 默认已对齐步骤⑧产出（`kgqa.db`/`retriever.pkl`），用默认库名**不用改**；只有建库时 `--kg-db` 改过名才要同步。`state_db_path` 是**外部可选增强、按本代码跑完不需要**（非步骤⑧产物，换领域不用管，留默认即可，缺失自动回退本地 KB、无功能降级）；融合权重 / LLM 模型 / 外部 API 开关可选调 |
| `configs/retrieval/prompts.yaml` | ⑨(9a) | **可选** | 按 `# >>> DOMAIN-SPECIFIC` 标记改 m6 persona、举例措辞；不改也能跑 |
| `retrieval_weights/models/` | ⑧ | **不用管** | 本地 BGE-M3 embedding 模型目录（仅步骤⑧ `--use-fast-ingest` 本地模式读取）；用 embedding API 模式则用不到，缺失自动回退 HF 下载 |

> 顺序建议：先把 ⑥⑦⑧ 的领域文件备齐建好库，再回到 ⑨ 配 (9b) 重排 + (9a) 路径，最后 (9c) 启服务。

#### (9a) 配置

`configs/retrieval/default_config.yaml` 是检索 + 重排 + 生成的总开关（top-k 各路、融合权重、LLM 模型 / 温度、外部 API 启用与否）；`configs/retrieval/prompts.yaml` 是 m1..m6 的提示模板。

**换领域必改：`default_config.yaml` 里这 2 条库路径**（都带 `# >>> DOMAIN/DEPLOY-SPECIFIC` 标记）：

| 配置项 | 来源（怎么找）| 默认值 | 改成 | 没有会怎样 |
| ---- | ---- | ---- | ---- | ---- |
| `kg_db_path` | ✅ **步骤⑧产物**：`build_kb_kg.py` 跑完落在 `scientific_kgqa/artifacts/kgqa.db`（建库时 `--kg-db` 可改名）| `scientific_kgqa/artifacts/kgqa.db` | 你建库的 KG 路径 | **读不到图谱**，KG 推理轨失效（启动会打 WARNING）|
| `kg_retriever_path` | ✅ **步骤⑧产物**：同上目录的 `retriever.pkl`（建库时 `--kg-retriever` 可改名）| `scientific_kgqa/artifacts/retriever.pkl` | 你的 retriever 路径 | 同上 |
| `state_db_path`（可选）| ❌ 外部旧项目的库，本仓库不产出 | `packages/aerospace.supermaterial/state.db` | **换领域不用管，留默认** | **无功能降级**：缺失时自动回退本仓库 `knowledge_base.json` + 步骤⑧的 `content_store/`，evidence_papers（md 全文 + PDF + doi/year + 引用）照常产出 |

> ✅ **前两条默认已与 `build_kb_kg.py` 产出对齐**（`kgqa.db` / `retriever.pkl`），用默认库**开箱即用**；只有建库时 `--kg-db` / `--kg-retriever` 改过名才要同步。库缺失时 [m2 retriever](search/gen_key/retrieval_integration/modules/m2_internal_retrieval/retriever.py) 打 `KG 库文件缺失` WARNING（fast 模式无影响；deep 模式自动降级外部兜底，不崩）。`state_db_path` 是旧代码产物、本仓库不生成，缺失自动回退本地 KB，**跨机部署 / 原目录被移走也不失效**。

`configs/retrieval/prompts.yaml` 里 m6 persona、概念举例等少数领域措辞用 `# >>> DOMAIN-SPECIFIC` 标出，**可选**按标记改（不改也能跑，只是答案口吻/举例仍是 EM 领域）。

> ℹ️ **关于"重排"**：当前查询期的"重排"全是**纯逻辑打分**——三路 `fused_score` 加权排序、[qa_engine.rerank()](search/gen_key/scientific_kgqa/src/scientific_kgqa/qa_engine.py) 的启发式（seed 命中 / 年份 / chunk_type / 专家权重）、m3b critic 的 LLM 打分——**不加载任何神经网络重排模型**。`retrieval_weights/models/` 只放**本地 BGE-M3 embedding 模型**（步骤⑧ `--use-fast-ingest` 本地模式才读）。

#### (9b) 查询期领域配置：task-aware 重排 + KG 游走（`expert_weights_em.yaml`）

查询期 QAEngine 在 m2 两轨汇合后，会对论文做 **task-aware 重排**（按 m1 抽出的「任务类型 + 功能类型」，用专家权重给论文打分），打分配置外置在 `scientific_kgqa/configs/expert_weights_em.yaml`（同一份的 `graph_walk` 段还驱动 KG 游走）。**这份文件由代码读取、但不手写**——它由两份人填模板经合成脚本产出。换领域只动下面三份文件：

| 文件 | 谁填 | 功能 | LLM 草拟? | 人工要检查/修改的 |
| ---- | ---- | ---- | --------- | ---------------- |
| `expert_template_expert.yaml` | **领域专家** | 有哪几类功能类型(+消歧顺序)、每个维度细分成哪些子项、每种任务的**权重配比**、图游走偏好 | ❌ 纯价值判断，LLM 无依据 | 自己填**相对重要度整数**（脚本自动归一化），决定"看重什么" |
| `expert_template_auto.yaml` | **LLM 草拟 → 人工删改** | 功能类型的 keywords/patterns 词典、维度子项 → schema 字段映射、任务的 query keywords / chunk_types | ✅ `draft_auto_from_schema.py` | 核对 keywords/patterns 是否贴合领域、字段映射是否对、chunk_types 是否合理 |
| `expert_weights_em.yaml` | **自动生成，勿手改** | 代码真正读取的归一化权重配置（小数权重，和=1.0） | — 由 `expert` + `auto` 两份模板经 `build_expert_config.py --split` 合成 | 不手改；要改配置请回头改上面两份模板再重跑合成脚本 |

两份模板都是**中文问卷 / 审核表风格**（每个 key 旁带中文名、填写说明、示例），照着填 / 审即可：

- **`expert_template_expert.yaml` = 专家评分表**：只回答三件事 —— ①本领域有哪些功能类型（越具体越靠前）；②每类任务更看重性能/材料/结构/机理哪个；③每个维度内部哪些子项更重要。权重**只填整数**（相对大小，不用凑 100、不用归一化），脚本自动归一化。
- **`expert_template_auto.yaml` = LLM 草稿审核表**：不用从零填，`draft_auto_from_schema.py` 会先草拟，专家只做四件审核 —— ①功能类型关键词是否贴合本领域；②有无明显错词/漏词；③子项对应的 schema 字段是否明显不对；④每个任务优先看的 chunk_type 是否合理。

##### 专家配置三步流水线

**先理解一个关键分工**：「有哪些子项」和「子项对应哪些 schema 字段」是两件事，分在两个文件——

| 内容 | 在哪个文件 | 谁负责 |
| ---- | ---- | ---- |
| 子项的**名字**（如 `transmissivity` / `bandwidth`） | `expert_template_expert.yaml` 的 `dimension_subitems` | **专家手填** |
| 子项 → schema 字段**映射**（如 `transmissivity → [electromagnetic_transmittance, insertion_loss]`） | `expert_template_auto.yaml` 的 `dimensions` | **LLM 草拟、专家审核** |

两份文件靠**同名 key** 对应：专家在 `_expert` 里列了 `transmissivity`，`draft_auto_from_schema.py` 就在 `_auto` 里给同名的 `transmissivity` 填字段。**不是手工粘贴，是脚本读 `_expert` 的子项名 + `schema.csv` 的字段池，调 LLM 自动配对生成**。

```
  专家手填                                          代码 + LLM 生成
  ┌─────────────────────────────┐                  ┌──────────────────────────┐
  │ expert_template_expert.yaml │                  │      schema.csv          │
  │  · 功能类型 + 顺序          │                  │  （步骤⑥/⑦ 产物，字段池）│
  │  · 维度子项「名字」         │                  └────────────┬─────────────┘
  │  · 任务权重配比             │                               │
  └──────────────┬──────────────┘                               │
                 │  子项名字 + 类型名 + 任务名                   │ 字段池
                 │                                               │
                 └───────────────┬───────────────────────────────┘
                                 ▼
                 ① python draft_auto_from_schema.py
                    （读上面两者 → 调 LLM 自动配对）
                                 │
                                 ▼
                 ┌────────────────────────────────────┐
                 │ expert_template_auto.yaml          │  ← 专家审核：删错词/补漏词/
                 │  · 功能类型 keywords / patterns    │     确认字段映射对不对
                 │  · 子项 → schema 字段「映射」      │
                 │  · 任务 keywords / chunk_types     │
                 └──────────────┬─────────────────────┘
                                │
   expert_template_expert.yaml  │  expert_template_auto.yaml
   （权重配比）────────┐        │        （词典 + 字段映射）
                       ▼        ▼
                 ② python build_expert_config.py --split
                    （两份模板归一化合成一份）
                                 │
                                 ▼
                 ┌────────────────────────────────────┐
                 │ expert_weights_em.yaml             │  ← 代码读取，勿手改
                 │  （归一化后的小数权重，和=1.0）    │
                 └──────────────┬─────────────────────┘
                                ▼
                 ③ 步骤⑨ QAEngine task-aware 重排（m2 之后）
                    本配置引用的 schema 字段若与当前 schema
                    无交集 → 自动降级回通用打分，不报错
```

```bash
# ① LLM 草拟 _auto（词典 + 字段映射）——凭据同 build_kb_kg.py，缺省读 .env
python scientific_kgqa/configs/draft_auto_from_schema.py \
    --schema scientific_kgqa/data/schema.csv \
    --expert scientific_kgqa/configs/expert_template_expert.yaml \
    --out    scientific_kgqa/configs/expert_template_auto.yaml
#    先看 prompt、不调 LLM：加 --dry-run

# ②（人工检查改好 _auto 后）合成代码真正读取的 yaml
python scientific_kgqa/configs/build_expert_config.py --split \
    scientific_kgqa/configs/expert_template_expert.yaml \
    scientific_kgqa/configs/expert_template_auto.yaml \
    scientific_kgqa/configs/expert_weights_em.yaml
```

> **`draft_auto_from_schema.py` 的护栏**：只草拟 `_auto`，绝不碰 `_expert` 的权重配比；输出自动**删掉 schema 里不存在的字段**（防 LLM 幻觉字段误触发降级）、**过滤非法 chunk_type**、把 key 与专家骨架对齐（缺的留空、多的丢弃并打 warning）。
>
> **硬约束（代码写死）**：维度名固定 5 个 `functional_type / performance / material / structure / mechanism`；某 task 里 `functional_type` 的归一化权重 ≥ 0.80 → 该 task 启用**强 gating**（功能类型不匹配的论文直接丢弃），合成脚本命中时会打印提示。
>
> 另：查询期的 5 段引导词在 `scientific_kgqa/configs/prompts_em.yaml` 的 `qa.*` 段（与步骤⑧ 建图共用同一份文件的不同 key）。

#### (9c) 启服务

配置就绪后（用默认航天电磁库可直接启；换领域先按 (9b) 备好 `expert_weights_em.yaml`、(9a) 对齐 2 条 KG 库路径）启动 HTTP / SSE 服务：

```bash
# 主服务（FastAPI + SSE）
python server.py
# 默认监听 http://0.0.0.0:8000（本机用 http://localhost:8000 访问）
# 可用环境变量改地址：HOST=127.0.0.1 PORT=9000 python server.py
# 等价的 uvicorn 写法（多 worker / 热重载时用）：
#   uvicorn server:app --host 0.0.0.0 --port 8000 --workers 1

# 构建产物全在 Ceph 的情况（用 --push-artifacts --prune-artifacts 构建后）：
# 启动时自动检测并拉取缺失的 faiss.index / bm25.pkl / kgqa.db 等
PULL_ARTIFACTS=1 python server.py
# 也可叠加非默认产物前缀：
PULL_ARTIFACTS=1 ARTIFACTS_REMOTE_PREFIX=projectA/artifacts python server.py

# 简化版 stub（不调 LLM，只测前端联调）
python server_stub.py

# 冒烟测试已启动的 server.py（脚本默认连 http://localhost:8000）
python _test_server.py
```

> **配置何时加载**：`server.py` **启动时一次性**把上述所有配置读进内存（`default_config.yaml` / `prompts.yaml` / `expert_weights_em.yaml` 走 QAEngine 默认路径自动加载，无需手动 `--参数` 指定）。**跑起来后改任何 yaml 都不热生效**——改完必须重启 `server.py`。`expert_weights_em.yaml` 还要先重跑 `build_expert_config.py` 重新合成。

#### (9d) 调接口

```bash
# 同步问答
curl -X POST http://localhost:8000/query \
     -H "Content-Type: application/json" \
     -d '{"query":"苯胺参与的位点选择性烯丙位胺化怎么做？","mode":"auto","top_k":5}'

# 流式问答（SSE，逐步看进度）
curl -N -X POST http://localhost:8000/query/stream \
     -H "Content-Type: application/json" \
     -d '{"query":"...","mode":"auto","top_k":5}'
```

`mode` 取值（对应 pipeline channel，服务默认 `fast`，**推荐 `auto`**；也可在 query 前加 `/deep ` / `/fast ` 前缀强制，优先级高于 `mode`）：

| mode | 行为（对照「原理 ①」流程图）|
| ---- | ---- |
| `fast` | KB 短路径：M1 → M2(并行 KB) → M3 → 直接合成（证据够时跳过 m4/m5 兜底）。快，适合事实/单跳问题 |
| `deep` | KG-first：M1 → KG 推演 → 衔接 KB(白名单) → 反向归并 → 走完 m3→m4→m5 → 合成。适合机理/对比/多跳问题 |
| `auto` | 把「证据够不够」的判断前移到入口，按 query 复杂度自动选：长 query、命中多个 schema 字段、或含「对比/演进/为什么/如何/机理/原理」等词 → 走 `deep` |

##### 请求参数（POST body）

| 字段 | 类型 | 默认 | 说明 |
| ---- | ---- | ---- | ---- |
| `query` | string | （必填） | 用户问题，支持中文 |
| `mode` | string | `fast` | `fast` / `deep` / `auto`，见上方 mode 表 |
| `top_k` | int | `10` | 返回给前端的 KB 证据 chunk 数上限（只截断响应，不影响内部召回）|

##### 返回字段（`/query` 的 JSON / `/query/stream` 末尾 `result` 事件）

> 字段定义见 [server.py](search/gen_key/server.py) 的 `QueryResponse`，两种模式返回结构一致，差别只在哪些字段有值。

| 字段 | 含义 | fast | deep |
| ---- | ---- | :--: | :--: |
| `answer` | LLM 合成的最终答案（带行内引用）| ✅ | ✅ |
| `kg_reasoning_paths` | KG 路径游走产出的推理链（实体→关系→实体）| ✗ 空 | ✅ |
| `kb_evidence` | KB 三路融合命中的 top-k chunk（段落级证据，受 `top_k` 截断）| ✅ | ✅ |
| `evidence_papers` | 支撑答案的本地库论文（含 schema 数值证据字段）| ✅ | ✅ |
| `external_refs` | m5 外部 API 兜底检索到的文献（仅证据不足时才有）| 视情况 | 视情况 |
| `references` | **参考文献下载包**：`[{paper_uid, title, source, download_url, file_type}]`；`download_url` 指向 `/files/{uid}.md`（KB 论文）或外部 PDF | ✅ | ✅ |
| `confidence` | 最终答案置信度 | ✅ | ✅ |
| `state` / `error` / `warnings` | 退出状态 / 错误 / 告警 | ✅ | ✅ |
| `timings` | 各 stage 耗时（ms）| ✅ | ✅ |

> **参考文献下载**：拿到 `references[].download_url` 后 `GET /files/{paper_uid}.md`（或 `.pdf`）即可下原文。三级查找与远端拉取细节见 (8f)；**服务重启后链接依然有效**，不依赖本次会话是否跑过 `/query`。

##### 影响"返回多少 / 下载多少"的参数

这些都在 [configs/retrieval/default_config.yaml](search/gen_key/configs/retrieval/default_config.yaml)，改完**重启 server** 生效：

| 配置项 | 默认 | 作用 |
| ---- | ---- | ---- |
| `m2_internal_retrieval.top_k` | `10` | 进入 m3/m6 的 KB chunk 数（请求里的 `top_k` 只截断响应，这个才影响内部）|
| `pipeline.recall.top_k_{metadata,dense,sparse}` | `30 / 20 / 20` | 三路各自召回多少 chunk 再融合 |
| `pipeline.kb_pdf_download.enabled` | `true` | 是否给 KB 论文走 DOI 下原始 PDF（星河→OA→可选 Sci-Hub）|
| `m5_external_retrieval.enabled` | `true` | 证据不足时是否调外部 API 兜底 |
| `m5_external_retrieval.dual_track.max_docs_per_track` | `20` | 外部检索每轨最多取多少篇 |
| `m5_external_retrieval.min_docs_threshold` / `max_expand_rounds` | `5` / `2` | 累计 < 5 篇时扩展查询词，最多 2 轮 |
| KG 游走 `beam.*` / `ppr.*`（上方表） | 见上 | 影响 `kg_reasoning_paths` 的条数 / 深度（top-k 路径）|



#### (9e) 命令行单条问答

```bash
python -m retrieval_integration.scripts.run_query "苯胺参与的位点选择性烯丙位胺化怎么做？"
#   可选：--channel fast|deep|auto 指定通道、--json 输出原始 JSON、--no-log 不落日志

# 批量（--test-file 指向 test_cases 下的 JSON，含 test_cases:[{id, query, expected_exit_reason, ...}]）
python -m retrieval_integration.scripts.batch_test \
    --test-file retrieval_integration/tests/test_cases/type_A_full_coverage.json \
    --output ./qa_runs/batch_report.json
```

#### (9f) 监控 & 指标

`retrieval_integration/monitoring/` 默认对每条 query 落 **结构化日志**（`retrieval_integration/data/logs/`）+ 指标（`metrics.py` 累加 latency / 命中率 / 各 stage 耗时）。

```bash
# 跑过一批后看汇总
python -m retrieval_integration.scripts.analyze_metrics \
    --log-dir retrieval_integration/data/logs \
    --output  ./metrics_report.md
#   可选：--slow-threshold-ms 10000 标记慢请求阈值（默认 10s）
```

#### (9g) 知识回流 —— `retrieval_integration/knowledge_backflow/`

问答过程中，如果 m1_schema_parser 命中了 schema 之外的字段（"用户问到 X，但 schema 没这字段"），或 m3_critic 判定现有 KB 内容不足，会把候选的新字段 / 新文献塞进 **候选池** `data/candidate_pool/`：

```
candidate_pool/
├── new_fields/          # schema 演化候选（admin_interface 审核后回填到 schema CSV）
└── new_papers/          # 缺失文献候选（可回流给 step ②/③ 补检索 + 下载）
```

管理员介入流程（`admin_interface` 是带子命令的 CLI）：

```bash
# 看候选池概况（各类候选数量）
python -m retrieval_integration.knowledge_backflow.admin_interface status

# 列出候选（可选 --date YYYYMMDD / --limit N）
python -m retrieval_integration.knowledge_backflow.admin_interface list --limit 20

# 审核单条候选：通过 / 驳回（request_id 来自 list 输出）
python -m retrieval_integration.knowledge_backflow.admin_interface approve <request_id>
python -m retrieval_integration.knowledge_backflow.admin_interface reject  <request_id>

# schema 演化建议：聚类近 N 天失败 query → 产出新增字段建议（默认 7 天）
python -m retrieval_integration.knowledge_backflow.admin_interface schema-suggest --days 7
```

> `schema-suggest` 内部用 `SchemaEvolver`（`schema_evolver.py`）：先 `collect_failed_queries(days)` 收集失败 query，再 `cluster_and_suggest` 聚类成候选新字段，打印 JSON 建议。`SchemaEvolver` 本身是类、无独立 CLI，统一经此子命令调用。

演化产出的新 schema CSV 可以直接喂回步骤 ⑦（`llm_extract`）让它重抽，再回到步骤 ⑧（`build_kb_kg.py`）刷库 —— 完成 **schema 自适应进化** 闭环。

---
### 步骤 ⑩：图谱测评与优化 —— `kg_eval/`

步骤 ⑧ 建好图谱、步骤 ⑨ 能问答之后，怎么判断**这张图谱建得好不好、哪一层最该优化**？步骤 ⑩ 用「出题」反向测评：QAG 网页出好领域题目 → 用 `scientific_kgqa` 图谱逐题问答 → 按固定四维框架打分 → 诊断最弱维并给优化建议。

`kg_eval/` **自包含**：把整套 QAG 出题/审题系统（前端网页 + 脚本）内置在 `kg_eval/qag/`；图谱查询复用 `scientific_kgqa.QAEngine`；LLM-Judge 复用 `scientific_kgqa.llm_client.LLMClient`。

**四维框架（均归一到 [0,1]）**

```
KG Quality       = 0.35·L0 + 0.25·L1 + 0.25·L2 + 0.15·Coupling
Retrieval Quality= 0.35·EvidenceRecall + 0.25·PathRecall + 0.20·NumericGrounding + 0.20·Traceability
Reasoning Quality= 0.30·PathNodeGrounding + 0.25·CrossLayerUse + 0.25·MultiHopCoherence + 0.20·ConceptBackboneUse
Answer Quality   = 0.45·FactualCorrectness + 0.25·SemanticCoverage + 0.15·DesignUsefulness + 0.15·InnovationScore
```

- **确定性指标**：EvidenceRecall（Top-K 证据命中）、PathRecall（关键节点+关系召回）、NumericGrounding（数值幻觉检测）、Traceability（证据可溯到 Paper/chunk）、PathNodeGrounding（路径节点可在图谱定位）、CrossLayerUse（跨 ≥2 节点类型）、MultiHopCoherence（方向+跳数一致性）、ConceptBackboneUse（是否走 Concept/CONCEPT_* 骨干）。
- **LLM-Judge**：FactualCorrectness、SemanticCoverage、DesignUsefulness、InnovationScore（后两者**仅 L3/L4** 有效，否则该子项权重重归一）、MultiHopCoherence/跨层使用语义判断。
- **KG Quality**：per-DB 结构统计（节点/边规模、属性完整度、边权质量）+ 跨题节点命中 macro-F1 + 抽样三元组 LLM 事实核查融合。

> **只按已构建的层计分（默认）**：KG Quality 自适应——只对图谱里有底层数据的分量计分（如纯概念图谱只算 L2），权重在这些分量间重归一；图谱**未实现的层**（没建 SchemaField/Measurement 节点、Global Registry、跨域边等）**从评分剔除、不计 0 拖分**，仅作"未实现（不计分）"信息列出。想回到"缺失层即缺口、计 0"的严格语义（把未建层当优化信号、接回步骤 ⑥/⑦/⑧ 改 schema/抽取/建图），加 `--strict-layers`。

**用法 A（网页，推荐）**

```bash
python kg_eval/qag/qag_ui_server.py      # 默认 http://127.0.0.1:5000
```
先在「出题」标签页正常出题（QAG 原流程不变），再切到新增的「**图谱测评**」标签页，填图谱 DB / Retriever（留空用 `scientific_kgqa/artifacts/` 默认），点「开始测评」，完成后「刷新报告」即可看到四维分、最弱维（红字）诊断与优化建议。

![QAG 知识图谱出题与图谱测评平台 —— 网页界面](kg_eval/docs/web_ui.png)

> 网页顶部导航：**配置 / 出题 / 审核 / 专家审查 / 任务 / 结果 / 质量报告 / 图谱测评 / 使用说明**。出题、审题（含 LLM 八维评审 + 专家审查 + LLM 自纠）全程可视化；「图谱测评」标签页一键跑四维测评并展示诊断。

**用法 B（CLI）**

```bash
python -m kg_eval.run_kg_eval \
  --db scientific_kgqa/artifacts/kgqa.db \
  --retriever scientific_kgqa/artifacts/retriever.pkl \
  --questions-dir kg_eval/qag/output \
  --out kg_eval/output
# 可选：--no-judge（仅确定性指标）/ --limit N / --judge-model <m> / --feed-backflow
#       --mode fast|deep / --no-graph / --no-kg-llm / --no-semantic-match / --keep-degenerate
```
> **答案生成（fast/deep 共用）**：检索到证据后 → LLM 基于证据综合答案（RAG）→ LLM-Judge 评分，才反映真实「检索 + LLM 推理」的答案质量（`QAEngine` 自身只给检索摘要，不调 LLM 生成答案）。模型链（如 `gpt-5.5,claude-sonnet-4-6`）取链首作实际模型，链尾作空响应时的降级备用。
> **跨语言节点匹配**（默认开）：gold 期望节点多为中文、pred 路径节点是英文 Concept，token 重叠≈0 会让 path_recall/multihop 假性偏低；用 BGE-M3 语义相似度兜底匹配，`--no-semantic-match` 可关。
> **剔除无区分度子项**（默认开，需≥3题）：某些子项在当前图谱形态下结构性恒定（如纯概念图谱的 `path_node_grounding`≈1、`concept_backbone_use`≈1、`cross_layer_use`≈0.5），跨题方差≈0、无鉴别力；默认把它们从所属维度评分剔除、按剩余子项重归一（报告标 ⚠️ 仍展示其值），换多层图谱时自动恢复计分。`--keep-degenerate` 回到 spec 完整子项。

| 项 | 说明 |
|---|---|
| 输入 | 步骤 ⑧ 产物 `kgqa.db` / `retriever.pkl` + QAG 网页出的题（`kg_eval/qag/output`）|
| LLM 配置 | 复用 `LLM_API_KEY` / `LLM_BASE_URL` / `LLM_MODEL`（仓库根 `.env`，与图谱构建同款）|
| 产物 | `kg_eval/output/{answers.json, report.json, report.md}` |
| 读诊断 | `report.md` 的 `weakest_dimension` / `weakest_submetric` + 优化建议 → 接回步骤 ⑥/⑦/⑧ |
| 换领域 | 改 `.env` 的 LLM 配置；题目领域由出题网页侧 domains 决定 |

**命令行做消融、网页端做可视化展示**：CLI 固定同一批题、只改单一开关，落到不同 `--out` 目录横向对比；网页端把单次结果以四维卡片 + 红字最弱维 + 建议清单可视化。常见消融：

```bash
# ① 不同 LLM 推理接入：不接 vs 模型甲 vs 模型乙
python -m kg_eval.run_kg_eval --questions-dir kg_eval/qag/output --no-kg-llm                 --out kg_eval/out/no_llm
python -m kg_eval.run_kg_eval --questions-dir kg_eval/qag/output --kg-llm-model gpt-5.5       --out kg_eval/out/llm_a
# ② fast / deep 检索深度：知识库检索 vs 知识图谱+知识库检索（两者都接 LLM 推理）
python -m kg_eval.run_kg_eval --questions-dir kg_eval/qag/output --mode fast                  --out kg_eval/out/fast
python -m kg_eval.run_kg_eval --questions-dir kg_eval/qag/output --mode deep                  --out kg_eval/out/deep
# ③ w/o 图谱检索模块（纯 LLM baseline，无检索） vs 完整图谱问答
python -m kg_eval.run_kg_eval --questions-dir kg_eval/qag/output --no-graph                   --out kg_eval/out/no_graph
python -m kg_eval.run_kg_eval --questions-dir kg_eval/qag/output --mode deep                  --out kg_eval/out/with_graph
```
跑完对比各 `report.json` 的 `dimension_scores`：消融 ② 量化「图谱检索/推理」相对纯知识库的增益（Retrieval/Reasoning/Answer 三维的差），消融 ③ 量化「有无检索」、消融 ① 量化推理模型增益。

> **三档检索深度**：`--no-graph` = 纯 LLM 无检索（baseline）；`--mode fast` = 知识库检索（retriever 全库 BM25+向量）+ LLM 推理，**绕过图谱游走**（无推理路径，Reasoning 趋零）；`--mode deep`（默认）= 知识图谱游走 + 知识库检索 + LLM 推理。三者都接 LLM 推理与 Judge；LLM/Judge 开关（`--no-kg-llm`/`--no-judge`）正交于检索深度。

**内置 QAG 出题/审题网页（`kg_eval/qag/qag_ui_server.py`）四步操作**：① **配置**——填 API 地址/密钥、拖动「出题 / Judge / 推理」三条模型优先级链、题目/报告输出目录；② **出题**——选难度（L1–L4，Ctrl 多选）+ 领域（FABS/HCFG/MECH/POPT）+ 每领域题数 → 开始出题；③ **审核**——默认启用 LLM 八维评审 + 本地结构/证据/数值检查，产出带风险等级（CRITICAL→PASS）的题目；④ **专家审查**——逐题填决策（accept 保留 / reject 删去 / rewrite 重写），可先点「LLM 自纠」自动修风险题，提交后自动重审刷新。出题完成后切「**图谱测评**」标签页一键评测。

**多人部署 / 鉴权 / 共享权重**（详见 [`kg_eval/部署运行说明.md`](kg_eval/部署运行说明.md)）：把整个 `gen_key/` 分发到各机器即可，**几个 G 的图谱权重不用人手拷贝**——`kg_eval/eval/config.py` 的 `_resolve_artifacts_dir()` 与 `qag_ui_server.py` 按优先级解析图谱目录：① 环境变量 `KGQA_ARTIFACTS_DIR` → ② 团队共享挂载（存在即零拷贝自动用，默认图谱为**航天版** `kgqa_aerospace.db`）→ ③ 仓库内 `scientific_kgqa/artifacts/` 回退。网页新增 `kg_eval/qag/auth.py`（登录鉴权 + 每用户独立工作区/上传），`kg_eval/scripts/` 含一键部署 `bootstrap_deploy.sh`、推送 `push_to_remote.sh`、外网代理 `egress_relay.py`。

---
## 升级版图谱 `kg_v2/` —— 两层 Schema × 四类语义节点 × 观测/因果/引用

`kg_v2/` 是在 **gen_key 骨架**上吸收 Scholar-KG_v2 设计的**并行升级子包**，**保留 Haiku 单调用抽取**，不改动现有 `llm_extract/` 与 `scientific_kgqa/` 产线（验证满意后再切换）。完整说明见 [`kg_v2/README.md`](kg_v2/README.md)。相对步骤 ⑦⑧ 的常规抽取建图，升级点：

- **两层 Schema（Meta + 领域）注入机制**：稳定的 Meta 骨架（12 模块，跨领域不变）× 步骤 ⑥ schema_gen 产出的领域 schema，逐字段派生 `node_type / module / role / value_type / unit / bind_keys / quality_check`，**嵌套进 Scholar-KG 的 A–E 模块**注入抽取 prompt（`kg_v2/schema/`）。
- **四类特定语义节点**：**Narrative**（叙事/需求）、**Measurement**（实测量）、**Discovery**（机理/优化结论）、**Concept**（概念原子）——单篇单次 Haiku 调用直接产出六键 JSON（`kg_v2/extract/`）。
- **Observation Pattern**：**强制把实测数值绑定到实验条件**（material_system / material_state / test_condition…），并以 `condition_binding_rate` 作质检 KPI，杜绝"裸数值"幻觉。
- **文献引用关系层 + 机理因果链**：新增 `CITES`（strength 1–5）引用层，Discovery 的 `causal_chain` 落成 Entity 链 + `CAUSES/ENABLES/INHIBITS…` 因果边（关系经 `relation_gov` 治理分级），**便于后续图谱游走**与因果推理（`kg_v2/graph/`）。

```bash
# 一键编排 P1→P4：两层 schema → Haiku 单调用抽取 → graph_v2.json → 落库 kgqa_v2.db（独立库，不覆盖 kgqa.db）
python -m kg_v2.build_kg_v2 \
    --domain schema_output/general_alloy/refined_schema_general_alloy.csv \
    --content-store scientific_kgqa/data/content_store \
    [--limit 20] [--concurrency 8] [--skip-schema|--skip-extract|--skip-graph|--skip-db]
```

> 下游高置信数值库只取 `_tier=main` 记录；图谱按 `relation_tier`（core/semantic/causal_candidate）分层检索：数值用 core、语义检索用 core+semantic、因果推理默认排除 causal_candidate。抽取/图谱/落库/导出等大体量产物（`kb_v2*/`、`graph_out/`、`exports/`、`_qc_backup_*/`、`runs/`）均为**运行时数据，已在 `.gitignore` 排除**，不入库。

---
## 端到端最小示例

```bash
# 0) 装依赖
pip install -r requirements.txt

# 1) (可选) 生成关键词,看终端输出,整理进 dims/my.txt
python generate_keywords.py \
    --prompt prompt/keyword_generate.txt \
    --query  query/try1.txt \
    --reference reference/

# 2) 按 dims/my.txt 跑筛选,输出到 results/
python dim_search.py --dims-file dims/my.txt --output ./results

# 3) 把感兴趣的 dimN.csv 喂给下载脚本
python s3_download_csv.py --csv-file ./results/dim1.csv --save-dir ./pdf/dim1/

# 4) 用 MinerU 把 PDF 批量解析成 Markdown
python mineru.py --api-key k1 --tasks-dir ./tasks submit   --pdf-dir ./pdf/dim1
python mineru.py --api-key k1 --tasks-dir ./tasks status   --wait
python mineru.py --api-key k1 --tasks-dir ./tasks download --output-dir ./md/dim1

# 5) 把解析结果上传到对象存储 xlc-hdd2:hangtian-kxfx/dim1
rclone copy ./md/dim1 xlc-hdd2:hangtian-kxfx/dim1 --progress --transfers 16

# 6) 根据领域偏好生成 LLM 抽取 Schema CSV
#    a. 写好 domain_prefer/my.txt (把 dims/qN.txt + query/tryN.txt 粘进去)
#    b. 复制 schema_gen/configs/example.yaml 改成 schema_gen/configs/my.yaml
#    c. 跑:
python -m schema_gen --config schema_gen/configs/my.yaml

# 7) 用 llm_extract 把 Markdown 文献结构化提取成 knowledge_base.json
#    a. 复制 llm_extract/configs/extract_config_aero_p1_local.yaml 改成自己的配置
#    b. 跑:
python llm_extract/extract.py \
    --config llm_extract/configs/my_extract.yaml \
    --output ./output \
    --concurrency 16

# 8) 把 knowledge_base.json + schema CSV 喂给 KB+KG 双轨底座（向量库 + 图谱）
python build_kb_kg.py \
    --kb-json ./output/knowledge_base.json \
    --schema  ./schema_output/allylic_amination/refined_schema_allylic_amination.csv \
    --force

# 9) 启 HTTP 检索 + 问答 API
#    换领域提示：启服务前先按 (9b) 备好 expert_weights_em.yaml（task-aware 重排配置），
#    并按 (9a) 把 default_config.yaml 的 kg_db_path / kg_retriever_path 指向本次建的库；
#    用默认航天电磁库跑通则无需改，直接启。
python server.py
# 另开终端冒烟:
python _test_server.py
# 或命令行单条问答:
python -m retrieval_integration.scripts.run_query "苯胺参与的位点选择性烯丙位胺化怎么做？"
```

---
## 数据流总览

```
                  ┌─────────── ① generate_keywords ──────────┐
                  │                                          │
研究问题 query ─→ ② dim_search (StarRocks) ─→ dimN.csv (DOI 列表)
                                                          │
                       ③ s3_download_csv ─→ ./pdf/*.pdf
                                                          │
                       ④ mineru             ─→ ./md/*/full.md
                                                          │
                       ⑤ rclone copy        ─→ S3:hangtian-kxfx
                                                          │
                  ⑥ schema_gen (5+1 Agent)  ─→ refined_schema_*.csv
                                                          │
                  ⑦ llm_extract             ─→ knowledge_base.json
                                                          │
                                ┌─────── ⑧ build_kb_kg.py ───────┐
                                ▼                                ▼
                       kb_mvp/ (KB 向量库)            scientific_kgqa/ (KG 图谱)
                       data/kb.db + index/*           artifacts/kgqa.db + retriever.pkl
                                └────────────────┬───────────────┘
                                                 ▼
                          ⑨ retrieval_integration / server.py / _test_server.py
                          双轨融合检索 + RAG 生成式问答 + 知识回流
                                                 ▼
                                          HTTP / SSE API
                                                 ▼
                                       前端 / 下游应用
```

---