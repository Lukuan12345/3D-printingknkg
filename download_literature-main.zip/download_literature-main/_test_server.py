#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""本地 server 冒烟测试（SSE 流式进度版 + PDF 下载）"""
import io, sys, json, time, urllib.request
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

BASE = "http://localhost:8000"
DOWNLOAD_DIR = Path(__file__).parent / "_test_downloads"
DOWNLOAD_DIR.mkdir(exist_ok=True)


def get(path):
    with urllib.request.urlopen(BASE + path, timeout=10) as r:
        return json.loads(r.read().decode())


def stream_query(query, mode, top_k=5):
    body = json.dumps({"query": query, "mode": mode, "top_k": top_k}).encode()
    req = urllib.request.Request(
        BASE + "/query/stream",
        data=body,
        headers={"Content-Type": "application/json", "Accept": "text/event-stream"},
        method="POST",
    )
    result = None
    t0 = time.perf_counter()
    with urllib.request.urlopen(req) as resp:
        for raw in resp:
            line = raw.decode("utf-8", errors="replace").rstrip("\r\n")
            if not line.startswith("data:"):
                continue
            try:
                event = json.loads(line[5:].strip())
            except json.JSONDecodeError:
                continue
            etype = event.get("type")
            if etype == "progress":
                print(f"  [{time.perf_counter()-t0:5.1f}s] {event['step']}", flush=True)
            elif etype == "heartbeat":
                print(f"  [{time.perf_counter()-t0:5.1f}s] ... (running)", flush=True)
            elif etype == "error":
                print(f"  ERROR: {event.get('detail')}", flush=True)
            elif etype == "start":
                print(f"  [  0.0s] 开始查询: {event.get('query')} ({event.get('mode')})", flush=True)
            elif etype == "result":
                result = event.get("data", {})
            elif etype == "done":
                print(f"  完成，总耗时 {event.get('total_ms',0)/1000:.1f}s", flush=True)
    return result


def download_pdf(url, save_name):
    """下载 PDF 到本地 _test_downloads/"""
    if not url:
        return None
    # 相对路径转绝对
    full_url = url if url.startswith("http") else BASE + url
    save_path = DOWNLOAD_DIR / save_name
    try:
        with urllib.request.urlopen(full_url, timeout=60) as resp:
            data = resp.read()
        save_path.write_bytes(data)
        return save_path, len(data)
    except Exception as e:
        return None, str(e)


def show_result(r, mode):
    if not r:
        print(f"  没有结果")
        return
    print(f"\n  ── {mode} 结果 ──")
    print(f"  state={r.get('state')}  confidence={r.get('confidence')}")
    print(f"  kb={len(r.get('kb_evidence',[]))}  kg={len(r.get('kg_reasoning_paths',[]))}  "
          f"refs={len(r.get('references',[]))}")
    print(f"  答案({len(r.get('answer',''))}字): {r.get('answer','')[:150]}...")
    if r.get("error"):
        print(f"  ERROR: {r['error']}")

    refs = r.get("references") or []
    if refs:
        print(f"\n  参考文献 ({len(refs)}):")
        for i, ref in enumerate(refs[:10], 1):
            print(f"    {i}. {(ref.get('title') or '')[:70]}")
            print(f"       source={ref.get('source')}  doi={ref.get('doi') or '-'}")
            print(f"       download_url={ref.get('download_url') or '(无)'}")

        # 下载有 download_url 的文件（KB→md，外部→pdf）
        print(f"\n  下载文件 →  {DOWNLOAD_DIR}")
        downloaded = 0
        for ref in refs:
            url = ref.get("download_url")
            if not url:
                continue
            uid = ref.get("paper_uid") or "unknown"
            ftype = ref.get("file_type") or "pdf"
            # external_url 不下载，由用户自己点击
            if ftype == "external_url":
                print(f"    → {(ref.get('title') or '')[:50]}  外链: {url[:80]}")
                continue
            ext = "md" if ftype == "md" else "pdf"
            save_name = f"{uid}.{ext}"
            res = download_pdf(url, save_name)
            if isinstance(res, tuple) and isinstance(res[0], Path):
                size_kb = max(1, res[1] // 1024)
                print(f"    ✓ {save_name}  ({size_kb} KB)")
                downloaded += 1
            else:
                err = res[1] if isinstance(res, tuple) else "unknown"
                print(f"    ✗ {save_name}  失败: {err}")
        print(f"  共下载 {downloaded} 个文件")


# 1. health
print("=== /health ===")
h = get("/health")
print(json.dumps(h, ensure_ascii=False, indent=2))
if not h.get("pipeline_ready"):
    print("Pipeline 还没 ready，请等 Warmup done 后再跑")
    sys.exit(1)

# 2. fast
print("\n=== /query/stream  mode=fast ===")
r = stream_query("C波段透波超材料的设计方法", "fast")
show_result(r, "fast")

# 3. deep
print("\n=== /query/stream  mode=deep ===")
r = stream_query("C波段透波超材料的设计方法", "deep")
show_result(r, "deep")
