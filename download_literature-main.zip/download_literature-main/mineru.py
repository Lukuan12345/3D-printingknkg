"""
MinerU 批量 PDF 解析工具

用法:
    # 提交 PDF 目录中的文件
    python mineru.py --api-key k1 --tasks-dir "./tasks" submit --pdf-dir "/path/to/pdfs"

    # 提交并指定范围
    python mineru.py --api-key k1 --tasks-dir "./tasks" submit --pdf-dir "/path/to/pdfs" --start 0 --end 333

    # 查询已提交批次的状态
    python mineru.py --api-key k1 --tasks-dir "./tasks" status

    # 下载已完成的解析结果
    python mineru.py --api-key k1 --tasks-dir "./tasks" download --output-dir "./output"

流程:
    1. submit: 上传 PDF → 获取 batch_id → 保存到 tasks.json
    2. status: 轮询 batch 状态，等待全部完成
    3. download: 下载所有完成的 zip 并解压 Markdown 到指定目录
"""

import os
import sys
import json
import time
import glob
import zipfile
import argparse
import re
import subprocess
import requests
import urllib3
import random

from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

from env_bootstrap import load_env
load_env()

# 禁止 verify=False 产生的警告
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ── MinerU API 配置 ──────────────────────────────────────────────────────
API_URL = "https://mineru.net/api/v4"
API_KEYS = {
    "k1": "",
    "k2": "",
}
DEFAULT_API_KEY = API_KEYS["k1"]
BATCH_SIZE = 50  # MinerU 单批次文件数上限
BATCH_INTERVAL = 30  # 每批次之间的等待秒数
MAX_RETRIES = 5  # 429 错误最大重试次数


def _resolve_api_key(key_input: str) -> str:
    """支持别名 k1/k2/k3，也支持直接传完整 key"""
    if key_input in API_KEYS:
        return API_KEYS[key_input]
    return key_input


def _key_tag(api_key: str) -> str:
    """用别名作为标识，找不到别名则用最后8位"""
    for alias, full_key in API_KEYS.items():
        if full_key == api_key:
            return alias
    return api_key[-8:] if api_key else "default"


def _tasks_file(api_key: str, tasks_dir: Path) -> Path:
    """根据 API Key 返回对应的 tasks 文件路径"""
    tag = _key_tag(api_key)
    return tasks_dir / f"mineru_tasks_{tag}.json"


def get_headers(api_key: str) -> dict:
    return {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "Accept": "*/*",
    }


# ── 任务持久化 ────────────────────────────────────────────────────────────

def load_tasks(api_key: str, tasks_dir: Path) -> dict:
    tasks_file = _tasks_file(api_key, tasks_dir)
    if tasks_file.exists():
        with open(tasks_file, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"batches": []}


def save_tasks(tasks: dict, api_key: str, tasks_dir: Path):
    tasks_file = _tasks_file(api_key, tasks_dir)
    tasks_file.parent.mkdir(parents=True, exist_ok=True)
    with open(tasks_file, "w", encoding="utf-8") as f:
        json.dump(tasks, f, indent=2, ensure_ascii=False)
    print(f"[INFO] 任务信息已保存到 {tasks_file}")


# ── 带重试的 API 请求 ────────────────────────────────────────────────────

def _request_with_retry(method, url, headers, json_data=None, max_retries=MAX_RETRIES):
    """发送 HTTP 请求，遇到 429 时自动指数退避重试"""
    for attempt in range(max_retries):
        if method == "POST":
            resp = requests.post(url, headers=headers, json=json_data)
        elif method == "GET":
            resp = requests.get(url, headers=headers)
        else:
            raise ValueError(f"不支持的 HTTP 方法: {method}")

        if resp.status_code == 429:
            retry_after = resp.headers.get("Retry-After")
            if retry_after:
                wait_time = int(retry_after)
            else:
                wait_time = min(30 * (2 ** attempt) + random.uniform(0, 10), 600)

            print(f"  [RATE LIMIT] 429 Too Many Requests，第 {attempt+1}/{max_retries} 次重试，等待 {wait_time:.0f} 秒...")
            time.sleep(wait_time)
            continue

        resp.raise_for_status()
        return resp

    # 所有重试用完，最后一次直接抛异常
    resp.raise_for_status()
    return resp


# ── Submit: 上传 PDF 并获取 batch_id ──────────────────────────────────────

def upload_batch(pdf_paths: list, api_key: str) -> dict:
    """上传一批 PDF 文件，返回 {batch_id, file_map}"""
    headers = get_headers(api_key)

    # Step 1: 获取上传 URL
    file_names = [os.path.basename(p) for p in pdf_paths]
    data = {"files": [{"name": name} for name in file_names]}

    resp = _request_with_retry("POST", f"{API_URL}/file-urls/batch", headers=headers, json_data=data)
    result = resp.json()
    if result.get("code") != 0:
        raise RuntimeError(f"获取上传 URL 失败: {result.get('msg')}")

    upload_info = result["data"]
    file_urls = upload_info["file_urls"]
    batch_id = upload_info["batch_id"]

    if len(file_urls) != len(pdf_paths):
        raise RuntimeError(f"上传 URL 数量不匹配: {len(file_urls)} vs {len(pdf_paths)}")

    # Step 2: 并行上传文件
    def _upload_one(pdf_path, upload_url):
        with open(pdf_path, "rb") as f:
            r = requests.put(upload_url, data=f)
            r.raise_for_status()
        return os.path.basename(pdf_path)

    uploaded = []
    failed = []
    with ThreadPoolExecutor(max_workers=8) as executor:
        futures = {
            executor.submit(_upload_one, p, u): p
            for p, u in zip(pdf_paths, file_urls)
        }
        for future in as_completed(futures):
            pdf_path = futures[future]
            try:
                name = future.result()
                uploaded.append(name)
                print(f"  [OK] {name}")
            except Exception as e:
                failed.append(os.path.basename(pdf_path))
                print(f"  [FAIL] {os.path.basename(pdf_path)}: {e}")

    # Step 3: 上传完成后系统自动开始解析
    file_map = {os.path.basename(p): p for p in pdf_paths}

    return {
        "batch_id": batch_id,
        "file_map": file_map,
        "uploaded": uploaded,
        "failed": failed,
        "submitted_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "status": "submitted",
    }


def cmd_submit(args):
    pdf_dir = args.pdf_dir
    start = args.start
    end = args.end
    tasks_dir = Path(args.tasks_dir)
    api_key = _resolve_api_key(args.api_key) if args.api_key else os.environ.get("MINERU_API_KEY", DEFAULT_API_KEY)

    # 收集 PDF 文件
    pdf_paths = sorted(glob.glob(os.path.join(pdf_dir, "**", "*.pdf"), recursive=True))
    if not pdf_paths:
        print(f"[ERROR] 在 {pdf_dir} 中未找到 PDF 文件")
        return

    print(f"[INFO] 目录中共 {len(pdf_paths)} 个 PDF 文件")
    pdf_paths = pdf_paths[start:end] if end > 0 else pdf_paths[start:]
    print(f"[INFO] 选取范围 [{start}:{end if end > 0 else len(pdf_paths)+start}]，共 {len(pdf_paths)} 个文件")

    # 跳过已提交的文件时，只跳过成功上传的（不跳过上传失败的）
    tasks = load_tasks(api_key, tasks_dir)
    already_submitted = set()
    for batch_info in tasks["batches"]:
        already_submitted.update(batch_info.get("uploaded", []))

    before = len(pdf_paths)
    pdf_paths = [p for p in pdf_paths if os.path.basename(p) not in already_submitted]
    skipped = before - len(pdf_paths)
    if skipped > 0:
        print(f"[INFO] 跳过 {skipped} 个已成功提交的文件")

    if not pdf_paths:
        print("[DONE] 所有文件已提交，无需重复上传")
        return

    print(f"[INFO] 需要上传 {len(pdf_paths)} 个 PDF 文件...")

    # 按 BATCH_SIZE 分批上传
    total_batches = (len(pdf_paths) + BATCH_SIZE - 1) // BATCH_SIZE

    for i in range(0, len(pdf_paths), BATCH_SIZE):
        chunk = pdf_paths[i : i + BATCH_SIZE]
        batch_num = i // BATCH_SIZE + 1
        print(f"\n[BATCH {batch_num}/{total_batches}] 上传 {len(chunk)} 个文件...")

        try:
            batch_info = upload_batch(chunk, api_key)
            tasks["batches"].append(batch_info)
            save_tasks(tasks, api_key, tasks_dir)
            print(f"  batch_id: {batch_info['batch_id']}")
            print(f"  成功: {len(batch_info['uploaded'])}, 失败: {len(batch_info['failed'])}")
        except Exception as e:
            print(f"  [ERROR] 批次上传失败: {e}")

        # 批次之间等待，避免触发限流
        if batch_num < total_batches:
            print(f"  [WAIT] 等待 {BATCH_INTERVAL} 秒后继续下一批...")
            time.sleep(BATCH_INTERVAL)

    print(f"\n[DONE] 共提交 {len(tasks['batches'])} 个批次")
    print(f"  运行 `python mineru.py --tasks-dir {tasks_dir} status` 查看解析进度")


# ── Status: 查询批次解析状态 ──────────────────────────────────────────────

def check_batch_status(batch_id: str, api_key: str) -> dict:
    headers = get_headers(api_key)
    resp = _request_with_retry("GET", f"{API_URL}/extract-results/batch/{batch_id}", headers=headers)
    return resp.json()["data"]


def cmd_status(args):
    tasks_dir = Path(args.tasks_dir)
    api_key = _resolve_api_key(args.api_key) if args.api_key else os.environ.get("MINERU_API_KEY", DEFAULT_API_KEY)
    wait = args.wait
    interval = args.interval

    tasks = load_tasks(api_key, tasks_dir)
    if not tasks["batches"]:
        print("[INFO] 没有已提交的任务，请先运行 submit")
        return

    print(f"[INFO] 使用 tasks 文件: {_tasks_file(api_key, tasks_dir)}")

    while True:
        all_done = True
        print(f"\n{'='*60}")
        print(f"[{time.strftime('%H:%M:%S')}] 检查 {len(tasks['batches'])} 个批次的状态...")

        for batch_info in tasks["batches"]:
            batch_id = batch_info["batch_id"]

            if batch_info.get("status") == "done":
                print(f"  [{batch_id[:12]}...] ✓ 已完成")
                continue

            try:
                status = check_batch_status(batch_id, api_key)
                results = status.get("extract_result", [])

                done_count = sum(1 for r in results if r.get("state") == "done")
                fail_count = sum(1 for r in results if r.get("state") == "failed")
                pending_count = len(results) - done_count - fail_count

                print(f"  [{batch_id[:12]}...] 完成: {done_count}, 失败: {fail_count}, 进行中: {pending_count}")

                if pending_count == 0 and len(results) > 0:
                    batch_info["status"] = "done"
                    batch_info["results"] = results
                else:
                    all_done = False

            except Exception as e:
                print(f"  [{batch_id[:12]}...] 查询失败: {e}")
                all_done = False

        save_tasks(tasks, api_key, tasks_dir)

        if all_done:
            print(f"\n[DONE] 全部批次已完成！运行 download 下载结果")
            break

        if not wait:
            print(f"\n[INFO] 部分任务未完成，加 --wait 参数可持续等待")
            break

        print(f"  等待 {interval} 秒后重新检查...")
        time.sleep(interval)


def _safe_name(name: str, max_len: int = 80) -> str:
    """去除特殊字符，截断过长文件名"""
    name = re.sub(r'[\[\]\(\)&\'\",;!@#$%^{}~`]', '', name)
    name = re.sub(r'\s+', '_', name)
    if len(name) > max_len:
        name = name[:max_len]
    return name


# ── Download: 下载并解压解析结果 ──────────────────────────────────────────

def download_and_extract(result: dict, file_map: dict, output_dir: Path):
    """下载单个文件的解析结果 zip 并解压"""
    curl_cmd = "curl.exe" if os.name == "nt" else "curl"
    state = result.get("state")
    file_name = result.get("file_name", "unknown")
    base_name = _safe_name(os.path.splitext(file_name)[0])

    if state != "done":
        return file_name, False, f"状态: {state}, 错误: {result.get('err_msg', 'N/A')}"

    zip_url = result.get("full_zip_url")
    if not zip_url:
        return file_name, False, "无下载 URL"

    target_dir = output_dir / base_name
    zip_path = target_dir / f"{base_name}.zip"

    # 已成功下载过则跳过（目录存在且非空）
    if target_dir.exists() and any(target_dir.iterdir()):
        return file_name, True, f"已存在，跳过"

    target_dir.mkdir(parents=True, exist_ok=True)

    try:
        # 用 curl 下载，绕过 Python SSL 问题
        curl_result = subprocess.run(
            [curl_cmd, "-k", "-s", "--show-error", "-o", str(zip_path), zip_url],
            capture_output=True, text=True, timeout=300
        )
        if curl_result.returncode != 0 or not zip_path.exists() or zip_path.stat().st_size == 0:
            raise RuntimeError(f"curl 下载失败: {curl_result.stderr}")

        # 解压
        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extractall(target_dir)
        zip_path.unlink()

        return file_name, True, str(target_dir)

    except Exception as e:
        if zip_path.exists():
            zip_path.unlink()
        if target_dir.exists():
            try:
                import shutil
                shutil.rmtree(target_dir)
            except FileNotFoundError:
                pass
        return file_name, False, str(e)


def cmd_download(args):
    tasks_dir = Path(args.tasks_dir)
    api_key = _resolve_api_key(args.api_key) if args.api_key else os.environ.get("MINERU_API_KEY", DEFAULT_API_KEY)
    output_dir = Path(args.output_dir)

    tasks = load_tasks(api_key, tasks_dir)
    if not tasks["batches"]:
        print("[INFO] 没有已提交的任务")
        return

    print(f"[INFO] 使用 tasks 文件: {_tasks_file(api_key, tasks_dir)}")

    # 先刷新状态
    for batch_info in tasks["batches"]:
        if batch_info.get("status") != "done":
            try:
                status = check_batch_status(batch_info["batch_id"], api_key)
                results = status.get("extract_result", [])
                pending = sum(1 for r in results if r.get("state") not in ("done", "failed"))
                if pending == 0 and results:
                    batch_info["status"] = "done"
                    batch_info["results"] = results
            except Exception as e:
                print(f"[WARN] 刷新状态失败 [{batch_info['batch_id'][:12]}...]: {e}")

    save_tasks(tasks, api_key, tasks_dir)

    # 收集所有已完成的结果
    all_results = []
    for batch_info in tasks["batches"]:
        if batch_info.get("status") == "done" and batch_info.get("results"):
            file_map = batch_info.get("file_map", {})
            for r in batch_info["results"]:
                all_results.append((r, file_map))

    if not all_results:
        print("[INFO] 没有已完成的解析结果可下载，请先运行 status --wait")
        return

    output_dir.mkdir(parents=True, exist_ok=True)
    print(f"[INFO] 开始下载 {len(all_results)} 个解析结果到 {output_dir}...")

    success_count = 0
    fail_count = 0

    with ThreadPoolExecutor(max_workers=15) as executor:
        futures = {
            executor.submit(download_and_extract, r, fm, output_dir): r
            for r, fm in all_results
        }
        for future in as_completed(futures):
            file_name, ok, msg = future.result()
            if ok:
                success_count += 1
                print(f"  [OK] {file_name} → {msg}")
            else:
                fail_count += 1
                print(f"  [FAIL] {file_name}: {msg}")

    print(f"\n[DONE] 成功: {success_count}, 失败: {fail_count}")
    print(f"  结果保存在: {output_dir}")


# ── CLI 入口 ──────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="MinerU 批量 PDF 解析工具",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--api-key", type=str, default=None, help="MinerU API Key (支持别名 k1/k2 或完整 key)")
    parser.add_argument("--tasks-dir", type=str, required=True, help="任务文件存储目录")

    subparsers = parser.add_subparsers(dest="command", help="子命令")

    # submit
    p_submit = subparsers.add_parser("submit", help="上传 PDF 文件并提交解析")
    p_submit.add_argument("--pdf-dir", type=str, required=True, help="PDF 文件所在目录")
    p_submit.add_argument("--start", type=int, default=0, help="起始文件索引 (默认0)")
    p_submit.add_argument("--end", type=int, default=0, help="结束文件索引 (0=到末尾)")

    # status
    p_status = subparsers.add_parser("status", help="查询解析状态")
    p_status.add_argument("--wait", action="store_true", help="持续等待直到全部完成")
    p_status.add_argument("--interval", type=int, default=15, help="轮询间隔秒数 (默认15)")

    # download
    p_download = subparsers.add_parser("download", help="下载已完成的解析结果")
    p_download.add_argument("--output-dir", type=str, required=True, help="下载目标目录")

    args = parser.parse_args()

    if args.command == "submit":
        cmd_submit(args)
    elif args.command == "status":
        cmd_status(args)
    elif args.command == "download":
        cmd_download(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()