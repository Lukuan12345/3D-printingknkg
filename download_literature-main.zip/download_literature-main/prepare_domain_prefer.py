#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""prepare_domain_prefer.py —— 生成「前置领域偏好准备文件」（衔接步骤 4）。

步骤 4 = 用 gen_key 的 schema_gen 从「领域偏好文件」生成提取 schema、再喂给
build_kb_kg.py 建知识库/图谱。本脚本只负责生产 schema_gen 的输入——
一个通用合金（镁/钛/铝 + 增材制造）逆合成分析用的 domain_prefer 文件，
并顺手写出配套的 schema_gen YAML 配置。

产出
────
1. domain_prefer/<project>.txt        Subdomains + Keywords + Queries 三段（schema_gen 必读）
2. schema_gen/configs/<project>.yaml  指向上面这份 txt 的配置，可直接 `python -m schema_gen -c` 跑
3. （可选）reference_schema_<project>.csv  若用 --merge-reference-schemas 指向放着
   附件三份参考 schema CSV（钛/钛增材/镁）的目录，则按英文字段名去重合并成一份参考表。

设计原则
────────
• 附件内容「必须包含」：附件里的 subdomains、关键词维度、科学问题已全部折叠进本文件——
  - 镁合金（砂铸/耐蚀/变形/Mg-RE-LPSO/时效/DRX/织构/腐蚀表面）
  - 钛合金（VAR 凝固偏析、高强β热加工/DRX、Ti-Al/γ-TiAl 相场、马氏体热力学、Ti-6Al-4V 织构/CPFE）
  - 钛增材（LPBF/EBM/DED/WAAM、缺陷质量、后处理热机械、组织/相/织构）
  - 铝合金（Al alloy 通用、铝腐蚀）
  - 通用冶金（成分设计、凝固、形变热处理、相变、强化机制、工艺-组织-性能因果链）
• 通用 + 逆合成：Queries 段统一围绕「给定目标性能 → 逆推 成分/工艺/组织」展开。

用法
────
    python prepare_domain_prefer.py
    python prepare_domain_prefer.py --project-name general_alloy
    python prepare_domain_prefer.py --merge-reference-schemas C:/path/to/attached_csvs
"""

from __future__ import annotations

import argparse
import csv
import glob
import os
from pathlib import Path

BASE = Path(__file__).resolve().parent


# ═══════════════════════════════════════════════════════════════════════════
# 1) Subdomains —— 闭合子领域列表（驱动 schema 每个字段打「适用领域」标签）
# ═══════════════════════════════════════════════════════════════════════════
SUBDOMAINS = [
    # —— 镁合金（doc5 / doc6）——
    "casting magnesium alloys",
    "corrosion-resistant magnesium alloys",
    "wrought magnesium alloys",
    "Mg-RE alloy design & LPSO phases",
    # —— 钛合金（doc3）——
    "VAR solidification & macrosegregation",
    "high-strength beta titanium hot deformation & DRX",
    "Ti-Al / gamma-TiAl solidification & phase-field",
    "martensitic transformation thermodynamics",
    "Ti-6Al-4V texture & crystal plasticity",
    # —— 钛增材 / 通用增材（doc4）——
    "additive manufacturing of titanium alloys (LPBF/EBM/DED/WAAM)",
    "AM defects porosity & quality control",
    "AM post-processing & thermo-mechanical route",
    "AM microstructure phase transformation & texture",
    # —— 铝合金（doc1）——
    "aluminum alloys (general)",
    "corrosion of aluminum alloys",
    # —— 通用冶金 / 逆合成主线 ——
    "alloy composition & system design",
    "casting process & solidification control",
    "heat treatment & precipitation strengthening",
    "thermomechanical processing & recrystallization",
    "plastic deformation texture & anisotropy",
    "phase transformation & phase-stability modeling",
    "mechanical properties fatigue & fracture",
    "corrosion behavior & surface engineering",
    "process-structure-property causality & cost",
]


# ═══════════════════════════════════════════════════════════════════════════
# 2) Keywords —— 多维度检索词（折叠 doc1/doc2/doc4/doc5 的全部关键词）
# 用 `Dimension N: [a | b, c, d]`，`|` 为同义词，`,` 为同维度并列词。
# ═══════════════════════════════════════════════════════════════════════════
KEYWORD_DIMENSIONS = [
    # D1 基础合金体系（Mg/Ti/Al/增材）
    ("基础合金体系",
     "magnesium alloy | Mg alloy | AZ31 | AZ91 | WE43 | ZK60 | Mg-Gd | Mg-Y | Mg-Nd | Mg-RE, "
     "titanium alloy | Ti alloy | Ti-6Al-4V | TC4 | Ti64 | beta titanium alloy | near-beta titanium | "
     "gamma TiAl | titanium aluminide, aluminum alloy | Al alloy | aluminium alloy"),
    # D2 铸造/熔炼/凝固
    ("铸造熔炼与凝固",
     "casting | sand casting | permanent mold casting | gravity casting | die casting, "
     "vacuum arc remelting | VAR | remelting, solidification | macrosegregation | centerline segregation | "
     "freckle | dendrite | dendrite arm spacing | mushy zone, melt pool | melt pool evolution | "
     "grain refinement | Zr refiner | inoculation"),
    # D3 形变与热机械加工
    ("形变与热机械加工",
     "hot deformation | hot compression | hot forging | hot rolling | extrusion | ECAP | torsion, "
     "dynamic recrystallization | DRX | recrystallization | flow softening | flow stress, "
     "processing map | Zener-Hollomon | constitutive model | activation energy, "
     "thermo-mechanical processing | TMP | pass schedule"),
    # D4 相变/相场/析出
    ("相变析出与相场",
     "precipitation | precipitate | aging | T6 | solution treatment | age hardening, "
     "martensitic transformation | beta to alpha prime | beta to alpha double-prime | retained beta, "
     "LPSO | long-period stacking order | 14H | 18R, "
     "phase-field | CALPHAD | thermodynamics | Scheil | liquidus | solidus | beta transus"),
    # D5 增材制造
    ("增材制造工艺与缺陷",
     "additive manufacturing | LPBF | SLM | PBF-LB | EBM | E-PBF | DED | L-DED | LMD | WAAM, "
     "laser power | scan speed | hatch spacing | layer thickness | volumetric energy density | scan strategy, "
     "porosity | lack of fusion | keyhole porosity | balling | residual stress | cooling rate | thermal gradient, "
     "HIP | hot isostatic pressing | stress relief | build orientation | as-built"),
    # D6 腐蚀与表面
    ("腐蚀与表面工程",
     "corrosion resistance | corrosion behavior | degradation | electrochemical | corrosion rate, "
     "galvanic corrosion | pitting | localized corrosion | stress corrosion, "
     "coating | surface treatment | anodizing | MAO | corrosion inhibitor"),
    # D7 性能与机制
    ("性能指标与强化机制",
     "yield strength | ultimate tensile strength | elongation | hardness | fatigue life | fracture toughness | creep, "
     "strengthening mechanism | Hall-Petch | Orowan strengthening | solid solution strengthening | grain boundary alpha, "
     "texture | anisotropy | twinning | slip system | crystal plasticity | CPFE, "
     "microstructure-property relationship | process-structure-property | strength-ductility synergy"),
]


# ═══════════════════════════════════════════════════════════════════════════
# 3) Queries —— 逆合成科学问题（含 doc5 原题 + 钛/铝/增材/通用 逆推问题）
# ═══════════════════════════════════════════════════════════════════════════
QUERIES = [
    # doc5 原题（镁，必须包含）
    "如何设计一种高强韧砂型铸造镁合金，铸件本体抗拉强度≥350MPa、断后伸长率≥4%，"
    "同时原材料成本低于100元/kg？输出：合金成分、热处理工艺（固溶温度、时长；时效温度、时长）、原材料成本。",
    # 钛 VAR 凝固
    "给定钛合金锭坯的目标凝固质量（最小化宏观偏析、无雀斑、目标熔池形状/深度），"
    "逆推 VAR 工艺窗口（电流、熔速、电弧间隙、电磁搅拌方式/强度）与对应的多物理场设定。",
    # 高强β钛热加工
    "为获得目标显微组织与强塑性匹配，逆推高强β/近β钛合金的热加工工艺"
    "（变形温度、应变速率、总应变、道次制度）及后续固溶+时效热处理。",
    # Ti-Al / γ-TiAl 相场
    "给定 Ti-Al/γ-TiAl 的目标凝固组织（枝晶形貌、γ/α2 片层间距、相选择路径），"
    "逆推合金成分、凝固方式与相场/界面参数（界面能、迁移率、各向异性）。",
    # Ti-6Al-4V 织构/CPFE
    "给定 Ti-6Al-4V 的目标各向异性与疲劳/变形性能，逆推初始织构、加载路径与"
    "晶体塑性模型参数（滑移/孪生系、CRSS、硬化律）。",
    # 增材
    "给定增材制造钛合金构件的目标致密度、力学性能与残余应力，逆推工艺参数窗口"
    "（激光功率/束流、扫描速度、能量密度、扫描策略、预热/层间温度）及后处理路线（应力消除、HIP、STA）。",
    # 铝
    "给定铝合金目标强度-耐蚀性能，逆推合金成分、热处理（固溶/时效）与表面防护方案。",
    # 通用逆合成主线
    "通用逆合成：给定目标性能指标，沿「目标性能 → 显微组织 → 形变/热处理工艺 → "
    "制备/凝固工艺 → 合金成分」逆推完整因果链，并给出推荐工艺窗口、关键变量敏感性与权衡关系。",
]


# ═══════════════════════════════════════════════════════════════════════════
# 写 domain_prefer txt
# ═══════════════════════════════════════════════════════════════════════════
def build_domain_prefer_text() -> str:
    lines: list[str] = []
    lines.append("# =============================================================================")
    lines.append("# 通用合金逆合成分析 —— domain_prefer 文件（schema_gen 输入）")
    lines.append("# 覆盖：镁 / 钛 / 铝 / 增材制造 + 通用冶金；附件 doc1-6 的子领域/关键词/科学问题已折叠在内。")
    lines.append("# Subdomains / Keywords / Queries 三段必填，缺一不可。")
    lines.append("# =============================================================================")
    lines.append("")
    # Subdomains
    lines.append("# ====== Subdomains ======")
    lines.append("Subdomains: [" + "; ".join(SUBDOMAINS) + "]")
    lines.append("")
    # Keywords
    lines.append("# ====== Keywords ======")
    lines.append("Keywords:")
    for i, (label, kws) in enumerate(KEYWORD_DIMENSIONS, 1):
        lines.append(f"# Dimension {i}: {label}")
        lines.append(f"Dimension {i}: [{kws}]")
        lines.append("")
    # Queries
    lines.append("# ====== Queries ======")
    lines.append("Queries:")
    for q in QUERIES:
        lines.append(q)
    lines.append("")
    return "\n".join(lines)


YAML_TEMPLATE = """# schema_gen 配置 —— 通用合金逆合成分析（自动生成 by prepare_domain_prefer.py）
# 运行： python -m schema_gen -c schema_gen/configs/{project}.yaml

project_name: {project}
usage_scope: 通用合金逆合成分析库

# 领域偏好文件（本脚本生成）
domain_prefer_file: ../../domain_prefer/{project}.txt

# 输出：仅 CSV（提取 schema）
output_dir: ../../schema_output/{project}
csv_filename: refined_schema_{project}.csv

# LLM（凭据从环境变量展开，勿提交真实密钥）
llm:
  api_key: ${{LLM_API_KEY}}
  base_url: ${{LLM_BASE_URL}}
  schema_model: gpt-5.4-pro
  architect_models: []
  endpoint: responses
  temperature: 0.2
  max_retries: 5
  retry_delay: 10

pipeline:
  num_architects: 3
  enable_clustering: true
  resume: true
"""


# ═══════════════════════════════════════════════════════════════════════════
# 可选：合并附件参考 schema CSV（doc3/doc4/doc6）
# ═══════════════════════════════════════════════════════════════════════════
def merge_reference_schemas(src_dir: Path, out_csv: Path) -> int:
    """把目录下所有 *.csv 按第一列（英文字段名）去重合并成一份参考 schema。"""
    csvs = sorted(glob.glob(str(src_dir / "*.csv")))
    if not csvs:
        print(f"[merge][warn] {src_dir} 下没有 CSV，跳过参考 schema 合并")
        return 0
    seen: set[str] = set()
    header: list[str] | None = None
    rows: list[list[str]] = []
    for fp in csvs:
        with open(fp, "r", encoding="utf-8-sig", newline="") as f:
            reader = csv.reader(f)
            try:
                h = next(reader)
            except StopIteration:
                continue
            if header is None:
                header = h
            for row in reader:
                if not row:
                    continue
                key = row[0].strip()
                if not key or key in seen:
                    continue
                seen.add(key)
                rows.append(row)
    if header is None:
        return 0
    out_csv.parent.mkdir(parents=True, exist_ok=True)
    with open(out_csv, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)
    print(f"[merge] 合并 {len(csvs)} 份 → {len(rows)} 个去重字段 → {out_csv}")
    return len(rows)


# ═══════════════════════════════════════════════════════════════════════════
# main
# ═══════════════════════════════════════════════════════════════════════════
def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="生成通用合金逆合成 domain_prefer 文件 + schema_gen 配置")
    ap.add_argument("--project-name", default="general_alloy", help="项目名（影响文件名）")
    ap.add_argument("--domain-prefer-dir", default=str(BASE / "domain_prefer"), help="domain_prefer 输出目录")
    ap.add_argument("--config-dir", default=str(BASE / "schema_gen" / "configs"), help="schema_gen 配置输出目录")
    ap.add_argument("--merge-reference-schemas", default=None,
                    help="放着附件参考 schema CSV（钛/钛增材/镁）的目录；提供则去重合并成参考表")
    ap.add_argument("--force", action="store_true", help="已存在也覆盖")
    args = ap.parse_args(argv)

    project = args.project_name

    # 1) domain_prefer txt
    dp_dir = Path(args.domain_prefer_dir)
    dp_dir.mkdir(parents=True, exist_ok=True)
    dp_path = dp_dir / f"{project}.txt"
    if dp_path.exists() and not args.force:
        print(f"[skip] 已存在（--force 覆盖）: {dp_path}")
    else:
        dp_path.write_text(build_domain_prefer_text(), encoding="utf-8")
        print(f"[ok] 领域偏好文件 → {dp_path}")

    # 2) schema_gen yaml
    cfg_dir = Path(args.config_dir)
    cfg_dir.mkdir(parents=True, exist_ok=True)
    cfg_path = cfg_dir / f"{project}.yaml"
    if cfg_path.exists() and not args.force:
        print(f"[skip] 已存在（--force 覆盖）: {cfg_path}")
    else:
        cfg_path.write_text(YAML_TEMPLATE.format(project=project), encoding="utf-8")
        print(f"[ok] schema_gen 配置 → {cfg_path}")

    # 3) 可选合并参考 schema
    if args.merge_reference_schemas:
        merge_reference_schemas(
            Path(args.merge_reference_schemas),
            dp_dir / f"reference_schema_{project}.csv",
        )

    print("\n下一步（步骤 4 衔接 gen_key）：")
    print(f"  cd {BASE}")
    print(f"  python -m schema_gen -c schema_gen/configs/{project}.yaml")
    print("  # 生成 refined_schema_*.csv 后，喂给 build_kb_kg.py / fast_ingest.py 建库建谱")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
